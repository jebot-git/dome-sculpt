from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;R=P.parent;Q=R/'advanced-normal-context-witness-build-20261118';N=R/'advanced-normal-sampler-range-build-v2-20261118'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
native=N/'native-v1-20261118/status.json';actual=json.loads(native.read_text());assert actual['state']=='terminal'and actual['exit']==0 and not actual['input_drift']and not actual['remaining_owned']and actual['summary']['checked_advanced_families']==17
build=json.loads((P/'link-status-v1.json').read_text());assert build['exit']==0 and not build['input_drift']and not build['remaining_owned']and not build['remaining_own_cgroup'];base=json.loads((P/'link-plan-v1.json').read_text());old=json.loads((Q/'forecast-plan-v1.json').read_text());cal=json.loads((P/'prior-source-calibration-v1.json').read_text());pins=dict(base['input_pins'])
for p,h in json.loads((N/'domain-native-plan-v1.json').read_text())['input_pins'].items():
 assert p not in pins or pins[p]==h,('Conflicting qualified native pin',p)
 assert sha(p)==h,('Native provenance drift',p);pins[p]=h
for p,h in old['input_pins'].items():
 if p.startswith('/usr/')or p.startswith('/opt/')or '/artifacts/sdk-20261111/'in p:assert sha(p)==h,('Prior external drift',p);pins[p]=h
for f in [P/'link-status-v1.json',P/'link-plan-v1.json',P/'run-forecast-v1.py',P/'prepare-forecast-plan-v1.py',P/'prior-source-calibration-v1.json',Path(cal['prior_log']),native,N/'domain-native-plan-v1.json',R/'advanced-normal-filter-render-owner-build-20261118/advanced-render.o',R/'advanced-normal-filter-render-owner-build-20261118/advanced-render.o.d',P/'advanced-render-link.d',R/'advanced-normal-filter-render-owner-build-20261118/libdome-sculpt-render.a',Path(build['product']['path'])]:pins[str(f)]=sha(f)
old['environment'].update(MALLOC_ARENA_MAX='2',MALLOC_MMAP_THRESHOLD_='131072')
j={'source':{'production':'e006869d9ff18a30ea88e51d4037ba88988406e6','graphics_fixture':build['source'],'native_fixture':actual['source']},'scope':'ActualCPU forecast at explicit2048 genuinecheckedsecondBake/source64 for all68views; all37968 independentdensepoints bound.035, old16PBRanchors<=1 plus104prioractualsourcecontrolRGBtriplets (56Mtoon); no GLadmission','driver_sha256':sha(P/'run-forecast-v1.py'),'input_pins':pins,'output':str(P/'CPU-forecast-v1-20261118'),'product':build['product'],'link_status':str(P/'link-status-v1.json'),'native_quality_status':str(native),'monitor':old['monitor'],'common_lease':old['common_lease'],'environment':old['environment'],'target_resolution':2048,'expected_view_labels':cal['expected_view_labels'],'original_probes':cal['original_probes'],'known_control_view':cal['known_control_view'],'known_control_RGB':cal['known_control_RGB'],'prior_source_control_RGB':cal['prior_source_control_RGB']};f=P/'forecast-plan-v1.json';assert not f.exists();f.write_text(json.dumps(j,indent=2)+'\n');print(sha(f),len(pins))
