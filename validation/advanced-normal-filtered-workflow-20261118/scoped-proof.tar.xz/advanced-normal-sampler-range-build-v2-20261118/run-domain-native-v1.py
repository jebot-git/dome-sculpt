"""Actual native legacy/known-draft-resize observation; no GL/UI admission."""
from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,sys
P=Path(__file__).resolve().parent
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
assert len(sys.argv)==2 and sha(P/'domain-native-plan-v1.json')==sys.argv[1]
J=json.loads((P/'domain-native-plan-v1.json').read_text());pins=J['input_pins'];out=Path(J['output']);out.mkdir(exist_ok=False);state={'state':'preflight','exit':1,'source':J['source'],'scope':J['scope'],'steps':[],'plan_sha256':sys.argv[1]};lease=None;known=[]
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def save():write(out/'status.json',state)
try:
 assert sha(__file__)==J['driver_sha256']and not drift(),('Input drift',drift())
 M=Path(J['monitor']);spec=importlib.util.spec_from_file_location('qualified_native_owner',M);mon=importlib.util.module_from_spec(spec);spec.loader.exec_module(mon)
 lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);state['lease']={'owner':mon.identity(os.getpid()),'released':False}
 env=J['environment'];state['environment']=env;write(out/'inputs-before.json',pins)
 for name,argv in [('ldd',['/usr/bin/ldd',J['product']['path']]),('source-maps-regression',[J['regression_product']['path']]),('historical-legacy17',[J['product']['path'],str(out/'historical-legacy17')]),('filtered-workflow',[J['product']['path'],'--filtered-workflow',str(out/'checked-policy1'),J['legacy_fixture'],str(J['target_resolution']),str(J['ordinary_target_resolution'])])]:
  row=mon.run(['/usr/bin/prlimit','--as=2147483648','--core=0','--',*argv],cwd=out,env=env,log=out/(name+'.log'),timeout=900,max_rss=3*1024**3,progress=lambda live:(state.update(live={'phase':name,**live}),save()));row['phase']=name;state['steps'].append(row);known+=row.get('known_processes',[]);state.pop('live',None);save()
  if name=='ldd':
   text=(out/'ldd.log').read_text();assert row['exit']==0 and 'not found'not in text
   import re
   for p in re.findall(r'(/[^\s()]+)',text):
    f=Path(p)
    if f.is_file():assert pins.get(str(f),pins.get(str(f.resolve())))==sha(f),('Unknown loader provider',str(f))
  elif name=='source-maps-regression':
   assert row['exit']==0 and not row.get('error')and not row.get('signals')
   assert 'A valid filtered endpoint passes unchanged strict MToon normal decoding'in (out/(name+'.log')).read_text()
  elif name=='historical-legacy17':
   import re
   text=(out/(name+'.log')).read_text();state['actual_historical_exit']=row['exit'];assert re.search(r'^PASS 263495 advanced source checks$',text,re.M),('Complete historical17 summary absent',row['exit']);assert row['exit']==0 and not row.get('error')and not row.get('signals')
  else:
   text=(out/'filtered-workflow.log').read_text();state['actual_product_exit']=row['exit'];state['legacy_byte_proof']=('PASS Real legacy native file survives byte-exact save'in text);state['legacy_replay_proof']=('PASS Actual recalled legacy64 Bake remains accepted under its persisted old policy'in text)
   assert row['exit']==0 and not row.get('error')and not row.get('signals'),('actual native result',row['exit'],row.get('error'))
   import re
   assert re.search(r'^PASS [1-9][0-9]* filtered Bake workflow positives=17 original64_refusals=8 target_resolution='+str(J['target_resolution'])+' ordinary_target_resolution='+str(J['ordinary_target_resolution'])+r'$',text,re.M),'Complete checked policy1 matrix summary absent'
   assert state['legacy_byte_proof']and state['legacy_replay_proof']
   assert len(re.findall(r'^FILTERED_RESOLUTION_WORKFLOW ',text,re.M))==18
   assert len(re.findall(r'^FILTERED64_REFUSAL ',text,re.M))==9
   assert text.count('PASS The same actual Document first refuses64 and preserves exact scene, history and prior Save before recovery')==9
   assert 'PASS Actual sculpt-to-prepared-target Bake uses filtered generic normals and preserves exact volume authority'in text
   assert 'PASS Ordinary mesh to prepared-target Bake records an actually checked filtered policy'in text
   assert 'PASS Original64M resize-work budget genuinely refuses2048 atomically at unchanged accounting'in text
   assert 'PASS Actual1024 mapped-source fidelity refusal remains a regression with unchanged normal data and angular limit'in text
   state['summary']={'historical_families':17,'historical_checks':263495,'checked_advanced_families':17,'original64_retained_refusals':8,'ordinary_mapped_refusal_and_retry':1,'ordinary_plain_mesh':True,'actual_sculpt':True,'source_resolution':64,'explicit_target_resolution':J['target_resolution'],'ordinary_mapped_explicit_target_resolution':J['ordinary_target_resolution'],'original_64M_work_limit_refused':True,'original_1024_mapped_quality_refused':True,'legacy_byte_exact':True,'same_Document_recoveries':9,'GL_or_UI_qualified':False}

 state['exit']=0
except BaseException as e:state['error']=repr(e)
finally:
 state['input_drift']=drift();state['remaining_owned']=[r for r in known if mon.alive(r)]if'mon'in globals()else[]
 state['exit']=state['exit']or int(bool(state['input_drift'])or bool(state['remaining_owned']))
 if lease:
  if'lease'in state:state['lease']['released']=True
  fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
raise SystemExit(state['exit'])
