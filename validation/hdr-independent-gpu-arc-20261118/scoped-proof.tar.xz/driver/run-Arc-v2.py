"""Exact retained-HDR product on owned Arc context; observers never edit product.
No normal-matrix fixture predicates: this test has105 readback context witnesses,
four material phases, exact source FLOAT coefficients and4422 product checks.
"""
from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,re,stat,sys,threading,time
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n')
assert len(sys.argv)==2 and sha(P/'Arc-plan-v2.json')==sys.argv[1]
J=json.loads((P/'Arc-plan-v2.json').read_text());F=P/'execution-v2';F.mkdir(exist_ok=False);pins=J['input_pins'];state={'state':'preflight','exit':1,'source':J['source'],'plan_sha256':sys.argv[1],'steps':[],'scope':J['scope']};lease=None
stop=threading.Event()
def save():write(F/'status.json',state)
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
try:
 assert sha(__file__)==J['driver_sha256']and not drift(),('Input drift',drift())
 sw=json.loads(Path(J['software_status']).read_text());assert sw['terminal']and sw['exit']==0 and not sw['drift']and not sw['owned']
 assert sha(J['product']['path'])==J['product']['sha256']=='ccd275252164098501c44b19c1c573090023fa2356b3172843b9585689d026f5'
 spec=importlib.util.spec_from_file_location('hdr_owned_monitor',J['monitor']);mon=importlib.util.module_from_spec(spec);spec.loader.exec_module(mon)
 spec=importlib.util.spec_from_file_location('hdr_nonELF_buffers',J['nonELF_buffer_helper']);buffers=importlib.util.module_from_spec(spec);spec.loader.exec_module(buffers)
 cg=Path('/sys/fs/cgroup')/next(v.split(':',2)[2]for v in Path('/proc/self/cgroup').read_text().splitlines()if v.startswith('0::')).lstrip('/');assert cg.name==J['unit']
 lease=Path(J['common_lease']).open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(lease.fileno());state['lease']={'owner':mon.identity(os.getpid()),'device':st.st_dev,'inode':st.st_ino,'released':False,'before_ldd_or_product':True}
 env=dict(J['environment']);assert env['LD_PRELOAD']==':'.join(J['observers'])and 'LIBGL_ALWAYS_SOFTWARE'not in env and 'GALLIUM_DRIVER'not in env
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(F/leaf);Path(env[key]).mkdir(mode=0o700)
 env['DOME_MARKER_DEVICE_REPORT']=str(F/'device');env['XR_RUNTIME_JSON']=str(F/'no-physical-runtime.json');state['environment']=env;write(F/'inputs-before.json',pins)
 def run(stage,argv,collect=False,timeout=180):
  fast={'rows':set(),'fd_records':{},'samples':0,'nonELF_buffers':{},'buffer_errors':{},'sampling_errors':[]};holder=[];stop.clear()
  def progress(row):
   state['live']={'name':stage,**row};save()
   if not collect or holder:return
   root={'pid':row['pid'],'start':row['start'],'pgrp':row['pgrp'],'session':row['root']['session']}
   def sample():
    while not stop.is_set():
     now=mon.identity(root['pid'])
     if not now or any(now[k]!=v for k,v in root.items()):return
     try:
      rows=Path('/proc',str(root['pid']),'maps').read_text().splitlines();fast['rows'].update(rows);fast['samples']+=1
      for text in rows:
       if buffers.eligible(text)and text not in fast['nonELF_buffers']:
        try:fast['nonELF_buffers'][text]=buffers.certify(root,text)
        except(AssertionError,OSError)as e:fast['buffer_errors'].setdefault(text,repr(e))
      for fd in Path('/proc',str(root['pid']),'fd').iterdir():
       try:
        node=os.readlink(fd)
        if not node.startswith('/dev/dri/'):continue
        st=os.stat(fd);assert stat.S_ISCHR(st.st_mode);dev=Path('/sys/dev/char')/(str(os.major(st.st_rdev))+':'+str(os.minor(st.st_rdev)));pci=(dev/'device').resolve(strict=True)
        identity={'path':node,'rdev_major':os.major(st.st_rdev),'rdev_minor':os.minor(st.st_rdev),'sysfs_device':str(pci),'PCI_BDF':pci.name,'vendor':(pci/'vendor').read_text().strip(),'device':(pci/'device').read_text().strip(),'driver':str((pci/'driver').resolve(strict=True))}
        stamp=time.monotonic()
        if node not in fast['fd_records']:fast['fd_records'][node]={'identity':identity,'owner':dict(root),'first_monotonic':stamp,'last_monotonic':stamp,'samples':1,'FD_stat':{'inode':st.st_ino,'mode':st.st_mode,'device':st.st_dev}}
        else:r=fast['fd_records'][node];assert r['identity']==identity;r['last_monotonic']=stamp;r['samples']+=1
       except OSError:pass
     except OSError:pass
     except BaseException as e:fast['sampling_errors'].append(repr(e));return
     stop.wait(.001)
   thread=threading.Thread(target=sample,daemon=True);holder.append(thread);thread.start()
  row=mon.run(argv,cwd=F,env=env,log=F/(stage+'.log'),timeout=timeout,max_rss=J['RSS_bytes'],progress=progress);stop.set()
  if holder:holder[0].join(timeout=3);assert not holder[0].is_alive()
  assert not fast['sampling_errors'],('Sampler errors',fast['sampling_errors'])
  row.update(name=stage,log_sha256=sha(F/(stage+'.log')));state['steps'].append(row);state.pop('live',None);write(F/(stage+'-maps.json'),{'rows':sorted(fast['rows']),'samples':fast['samples'],'live_DRM_FD_records':fast['fd_records'],'certified_nonELF_buffers':fast['nonELF_buffers'],'buffer_errors':fast['buffer_errors'],'sampling_errors':fast['sampling_errors']})
  mapped={};drm_rows=[]
  for text in fast['rows']:
   fields=text.split(None,5)
   if len(fields)!=6 or not fields[5].startswith('/'):continue
   name=fields[5]
   if name.endswith('(deleted)'):assert text in fast['nonELF_buffers'],('Unproven deleted mapping',text);continue
   path=Path(name)
   if name.startswith('/dev/dri/'):
    assert name in fast['fd_records']and name in J['allowed_drm_devices'];rec=fast['fd_records'][name];assert rec['identity']==J['allowed_drm_devices'][name]
    st=path.stat();major,minor=(int(v,16)for v in fields[3].split(':'));assert stat.S_ISCHR(st.st_mode)and'x'not in fields[1]and st.st_ino==int(fields[4])and st.st_dev==os.makedev(major,minor)and rec['FD_stat']['inode']==st.st_ino and rec['FD_stat']['device']==st.st_dev;drm_rows.append(text);continue
   with path.open('rb')as f:magic=f.read(4)
   if magic!=b'\x7fELF':continue
   expected=pins.get(name,pins.get(str(path.resolve())));assert expected and sha(path)==expected,('Unbound mapped ELF',name);mapped[name]=expected
  row.update(mapped_ELFs=mapped,live_DRM_FD_records=fast['fd_records'],live_samples=fast['samples'],certified_live_DRM_mapping_rows=drm_rows);save();assert row['exit']==0 and not row.get('error')and not row['signals'];assert not[v for v in row['known_processes']if mon.alive(v)]
  return(F/(stage+'.log')).read_text(),fast
 text,_=run('ldd',['/usr/bin/ldd',J['product']['path']],timeout=60);assert 'not found'not in text;providers={}
 for literal in re.findall(r'(/[^\s()]+)',text):
  if not Path(literal).is_file():continue
  real=str(Path(literal).resolve());expected=pins.get(literal,pins.get(real));assert expected and sha(literal)==expected,('Unbound loader provider',literal);providers[literal]=expected
 state['loader_providers']=providers;save()
 text,fast=run('hdr-test',[J['product']['path'],'--hardware'],True,J['timeout_seconds']);renderer=J['renderer']
 assert re.search(r'^GL_RENDERER='+re.escape(renderer)+'$',text,re.M)
 assert all(v in text for v in ['STRICT_MARKER_ACTUAL','STRICT_MARKER_DEVICE','STRICT_MARKER_OPEN_FD'])and 'STRICT_MARKER_REFUSAL'not in text and'HDR_ARC_CONTEXT_ERROR'not in text
 assert 'llvmpipe'not in text and 'softpipe'not in text
 phases=re.findall(r'^HDR_MATERIAL edited=([01]) mtoon=([01]) rgb_error=(\d+)$',text,re.M);assert[(a,b)for a,b,_ in phases]==[('0','0'),('0','1'),('1','0'),('1','1')]and all(int(e)<=2 for _,_,e in phases)
 final=re.findall(r'^HDR_GPU coefficient_error=([^ ]+) maximum_RGB_error=(\d+) checks=(\d+)$',text,re.M);assert len(final)==1 and float(final[0][0])==0 and int(final[0][1])==max(int(e)for _,_,e in phases)<=2 and int(final[0][2])==4422
 pattern=r'^HDR_ARC_CONTEXT read=(\d+) context=(0x[0-9a-f]+) display=(0x[0-9a-f]+) width=(\d+) height=(\d+) format=(\d+) type=(\d+) vendor=Intel renderer='+re.escape(renderer)+'$';contexts=re.findall(pattern,text,re.M);assert len(contexts)==105 and[int(r[0])for r in contexts]==list(range(1,106))and len({(r[1],r[2])for r in contexts})==1
 assert tuple(map(int,contexts[0][3:]))==(64,64,6408,5126)and all(tuple(map(int,r[3:]))==(96,96,6408,5121)for r in contexts[1:])
 # Each phase consists of one actual material read plus25 independent controls.
 phase_read_counts=[];reads=0
 for line in text.splitlines():
  if line.startswith('HDR_ARC_CONTEXT read='):reads+=1
  if line.startswith('HDR_MATERIAL '):phase_read_counts.append(reads)
 assert phase_read_counts==[27,53,79,105]
 fds=fast['fd_records'];assert '/dev/dri/renderD129'in fds and fast['samples']>0
 for node,rec in fds.items():assert node in J['allowed_drm_devices']and rec['identity']==J['allowed_drm_devices'][node]and rec['samples']>0
 device=(F/'device/device.txt').read_text();assert all(v in device for v in ['vendor=Intel','renderer='+renderer,'render_node=/dev/dri/renderD129','0000:03:00.0','vendor_id=0x8086','device_id=0x56a0']);assert Path('/sys/dev/char/226:129/device/driver').resolve().name=='i915'
 mapped=state['steps'][-1]['mapped_ELFs'];assert all(p in mapped for p in J['required_mapped_ELFs'])
 state.update(exit=0,summary={'source_resolution':64,'editable_resolution':512,'FLOAT_coefficient_error':0,'material_phases':len(phases),'phase_RGB_errors':[int(e)for _,_,e in phases],'RGB_bound':2,'checks':4422,'actual_hardware_context_readback_witnesses':len(contexts),'phase_cumulative_readbacks':phase_read_counts,'single_actual_EGL_context_and_display':True,'hardware_renderer':renderer,'render_node':'/dev/dri/renderD129','PCI_BDF':'0000:03:00.0','kernel_driver':'i915','product_unchanged':True},device_report=device,context_observer_rows=contexts,context_maps_sha256=sha(F/'device/context-maps.txt'))
except BaseException as e:
 import traceback
 state.update(error=repr(e),traceback=traceback.format_exc())
finally:
 stop.set();state['input_drift']=drift();state['remaining_owned']=[v for row in state['steps']for v in row.get('known_processes',[])if mon.alive(v)]if'mon'in globals()else[];state['remaining_own_cgroup']=[int(v)for v in(cg/'cgroup.procs').read_text().split()if int(v)!=os.getpid()]if'cg'in globals()else[]
 state['exit']=state['exit']or int(bool(state['input_drift'])or bool(state['remaining_owned'])or bool(state['remaining_own_cgroup']))
 if lease:
  state['lease']['released']=True;fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
raise SystemExit(state['exit'])
