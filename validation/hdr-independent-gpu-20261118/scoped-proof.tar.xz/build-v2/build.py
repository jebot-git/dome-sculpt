from pathlib import Path
import concurrent.futures,json,subprocess,hashlib,time,os,shlex
out=Path(__file__).parent;plan=json.loads((out/'plan.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();started=time.time();state={'terminal':False,'steps':[]}
def save(): (out/'status.json').write_text(json.dumps(state,indent=2))
def command(name,argv):
 t=time.time()
 with (out/(name+'.log')).open('wb') as log:r=subprocess.run(['/usr/bin/timeout','--signal=TERM','--kill-after=5s','900s',*argv],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
 return {'name':name,'argv':argv,'cwd':str(out),'exit':r.returncode,'seconds':time.time()-t}
env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','HOME':os.environ['HOME'],'LD_LIBRARY_PATH':'/home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
try:
 drift=[p for p,h in plan['pins'].items() if not Path(p).is_file() or sha(p)!=h];assert not drift,drift[:5]
 receipt=json.loads(Path(plan['core_member_receipt']).read_text());core=plan['archives']['libdome-sculpt-core.a'];members=subprocess.check_output(['/usr/bin/ar','t',core],text=True).splitlines();assert members==[m['member'] for m in receipt]
 for m in receipt:assert hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',core,m['member']])).hexdigest()==m['sha256'],m
 state['reused_core_verified_members']=len(receipt);save()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for result in pool.map(lambda c:command(c['name'],c['argv']),plan['commands']):state['steps'].append(result);save()
 assert all(s['exit']==0 for s in state['steps']),'compile failure'
 for name,argv in [('archive',['/usr/bin/ar','qc',str(out/'libdome-sculpt-render.a'),*[owner['object'] for owner in plan['reused_render_owners']]]),('ranlib',['/usr/bin/ranlib',str(out/'libdome-sculpt-render.a')]),('link',plan['link'])]:
  result=command(name,argv);state['steps'].append(result);save();assert result['exit']==0,name
 deps={};unknown=[]
 for c in plan['commands']:
  p=Path(c['MD']);words=shlex.split(p.read_text().replace('\\\n',' ').split(':',1)[1]);actual={str(Path(v).resolve() if Path(v).is_absolute() else (out/v).resolve()):sha(Path(v) if Path(v).is_absolute() else out/v) for v in words};deps[c['name']]={'MD':str(p),'MD_sha256':sha(p),'object_sha256':sha(c['argv'][c['argv'].index('-o')+1]),'actual_dependencies':actual}
  unknown.extend(p for p in actual if p not in plan['pins'])
 (out/'actual-MD-owners.json').write_text(json.dumps(deps,indent=2));assert not unknown,('unforecast MD dependencies',unknown[:10])
 state['unknown_MD_dependencies']=unknown;state['drift']=[p for p,h in plan['pins'].items() if sha(p)!=h];assert not state['drift'];state['ELF_sha256']=sha(out/'hdr-test');state['exit']=0
except BaseException as error:state['exit']=1;state['error']=repr(error)
state.update(terminal=True,seconds=time.time()-started);save();raise SystemExit(state['exit'])
