from pathlib import Path
import json,subprocess,time,hashlib,shlex
out=Path(__file__).parent;p=json.loads((out/'plan.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();s={'steps':[]};env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
try:
 for name,argv in [('compile',p['commands'][0]['argv']),('link',p['link'])]:
  start=time.time()
  with (out/(name+'.log')).open('wb')as log:r=subprocess.run(['/usr/bin/timeout','300s',*argv],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
  s['steps'].append({'name':name,'argv':argv,'cwd':str(out),'exit':r.returncode,'seconds':time.time()-start});assert not r.returncode,name
 md=Path(p['commands'][0]['MD']);deps={str(Path(f).resolve()):sha(f) for f in shlex.split(md.read_text().replace('\\\n',' ').split(':',1)[1])};assert all(p['pins'].get(f)==h for f,h in deps.items()),[f for f in deps if f not in p['pins']];s['actual_MD_dependencies']=deps;s['MD_sha256']=sha(md);s['ELF_sha256']=sha(out/'legacy-test');s['exit']=0
except BaseException as e:s.update(exit=1,error=repr(e))
(out/'status.json').write_text(json.dumps(s,indent=2));print({k:v for k,v in s.items() if k not in ['steps','actual_MD_dependencies']});raise SystemExit(s['exit'])
