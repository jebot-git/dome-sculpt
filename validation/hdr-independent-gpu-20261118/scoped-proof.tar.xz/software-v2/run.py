from pathlib import Path
import json,os,sys,fcntl,time,hashlib,importlib.util,re,resource
sys.dont_write_bytecode=True;out=Path(__file__).parent;p=json.loads((out/'plan.json').read_text());s={'terminal':False,'steps':[],'source':p['source'],'driver_pid':os.getpid()};lease=None;pins=dict(p['pins']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save():(out/'status.json').write_text(json.dumps(s,indent=2))
def verify():
 bad=[path for path,h in pins.items() if not Path(path).is_file() or sha(path)!=h]
 if bad:raise RuntimeError('Input drift '+str(bad[:8]))
def live(row):
 try:
  proc=Path('/proc',str(row['pid']));stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
  if int(stat[19])==row['start']:
   maps=(proc/'maps').read_text();(out/'actual-live.maps').write_text(maps);s['live']={'pid':row['pid'],'start':row['start'],'exe':os.readlink(proc/'exe')};s['device_fds']=[os.readlink(f) for f in (proc/'fd').iterdir() if f.exists() and os.readlink(f).startswith('/dev/dri/')];save()
 except (FileNotFoundError,ProcessLookupError):pass
try:
 assert resource.getrlimit(resource.RLIMIT_AS)==(resource.RLIM_INFINITY,resource.RLIM_INFINITY)
 pins[str(out/'run.py')]=sha(__file__);verify();spec=importlib.util.spec_from_file_location('monitor',p['monitor']['path']);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
 env={k:v for k,v in os.environ.items() if not k.startswith(('LD_','DYLD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(key,None)
 env.update({k:v for k,v in p['environment'].items() if v is not None});env['XR_RUNTIME_JSON']=str(out/'no-physical-runtime.json');env['PYTHONDONTWRITEBYTECODE']='1'
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_STATE_HOME','state'),('XDG_CACHE_HOME','cache'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(out/leaf);Path(env[key]).mkdir(mode=0o700)
 s['environment']={k:env.get(k) for k in p['environment']};save();lease=Path(p['lease']).open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);s['lease']={'acquired':time.time(),'inode':os.fstat(lease.fileno()).st_ino,'device':os.fstat(lease.fileno()).st_dev,'before_ldd_or_product':True};save()
 row=monitor.run(['/usr/bin/ldd',p['product']],cwd=out,env=env,log=out/'ldd.log',timeout=60,max_rss=p['RSS_bytes']);s['steps'].append(row);save();assert row['exit']==0
 text=(out/'ldd.log').read_text();assert 'not found' not in text;providers={}
 for path in re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text):
  real=str(Path(path).resolve());expected=pins.get(path) or pins.get(real) or p['provider_catalog'].get(path) or p['provider_catalog'].get(real);assert expected and sha(path)==expected,(path,expected);providers[path]=expected;pins[path]=expected;pins[real]=expected
 s['actual_providers']=providers;save();verify()
 row=monitor.run(['/usr/bin/ldd',p['legacy_product']],cwd=out,env=env,log=out/'legacy.ldd',timeout=60,max_rss=p['RSS_bytes']);s['steps'].append(row);save();assert row['exit']==0
 for path in re.findall(r'(?:=>\s*)?(/\S+)\s+\(', (out/'legacy.ldd').read_text()):
  real=str(Path(path).resolve());expected=pins.get(path) or pins.get(real) or p['provider_catalog'].get(path) or p['provider_catalog'].get(real);assert expected and sha(path)==expected,(path,expected);pins[path]=expected;pins[real]=expected
 row=monitor.run([p['legacy_product']],cwd=out,env=env,log=out/'legacy.log',timeout=p['timeout_seconds'],max_rss=p['RSS_bytes'],progress=live);s['steps'].append(row);s.pop('live',None);save();assert row['exit']==0 and not row.get('signals') and not row.get('error');legacy_counts=re.findall(r'^Baked emission GPU (\d+) checks PASS$',(out/'legacy.log').read_text(),re.M);assert len(legacy_counts)==1;s['legacy_checks']=int(legacy_counts[0]);save()
 row=monitor.run(['/usr/bin/ldd',p['mtoon_product']],cwd=out,env=env,log=out/'mtoon.ldd',timeout=60,max_rss=p['RSS_bytes']);s['steps'].append(row);save();assert row['exit']==0
 for path in re.findall(r'(?:=>\s*)?(/\S+)\s+\(', (out/'mtoon.ldd').read_text()):
  real=str(Path(path).resolve());expected=pins.get(path) or pins.get(real) or p['provider_catalog'].get(path) or p['provider_catalog'].get(real);assert expected and sha(path)==expected,(path,expected);pins[path]=expected;pins[real]=expected
 row=monitor.run([p['mtoon_product']],cwd=out,env=env,log=out/'mtoon.log',timeout=p['timeout_seconds'],max_rss=p['RSS_bytes'],progress=live);s['steps'].append(row);s.pop('live',None);save();assert row['exit']==0 and not row.get('signals') and not row.get('error');counts=re.findall(r'^Production MToon/linear target tests complete: (\d+) checks$',(out/'mtoon.log').read_text(),re.M);assert len(counts)==1;s['mtoon_checks']=int(counts[0]);save()
 row=monitor.run([p['product']],cwd=out,env=env,log=out/'product.log',timeout=p['timeout_seconds'],max_rss=p['RSS_bytes'],progress=live);s['steps'].append(row);s.pop('live',None);save();assert row['exit']==0 and not row.get('signals') and not row.get('error')
 text=(out/'product.log').read_text();assert 'llvmpipe' in text or 'softpipe' in text;phases=re.findall(r'^HDR_MATERIAL edited=([01]) mtoon=([01]) rgb_error=(\d+)$',text,re.M);assert len(phases)==4 and {(a,b) for a,b,_ in phases}=={('0','0'),('0','1'),('1','0'),('1','1')} and all(int(v)<=2 for _,_,v in phases);assert re.search(r'^HDR_GPU coefficient_error=0 maximum_RGB_error=[012] checks=\d+$',text,re.M);s['phases']=phases;s['exit']=0
except BaseException as error:s.update(exit=1,error=repr(error))
finally:
 s['drift']=[path for path,h in pins.items() if not Path(path).is_file() or sha(path)!=h];s['owned']=[]
 if 'monitor' in globals():
  for row in s['steps']:
   s['owned'].extend(proc for proc in row.get('known_processes',[]) if monitor.alive(proc))
 if s['drift'] or s['owned']:s['exit']=1
 if lease:
  if 'lease'in s:s['lease']['released']=time.time()
  fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 s['terminal']=True;(out/'actual-inputs.json').write_text(json.dumps(pins,indent=2));save()
raise SystemExit(s['exit'])
