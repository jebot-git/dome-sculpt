from pathlib import Path
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import resource
import sys
import time

sys.dont_write_bytecode = True
out = Path(__file__).parent
plan = json.loads((out / 'plan.json').read_text())
pins = dict(plan['pins'])
lease = None
monitor = None
state = {'state': 'preflight', 'terminal': False, 'source': plan['source'],
         'scope': plan['scope'], 'driver_pid': os.getpid(), 'steps': [], 'providers': {}}
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save():
    (out / 'status.json').write_text(json.dumps(state, indent=2) + '\n')


def verify():
    drift = [path for path, digest in pins.items()
             if not Path(path).is_file() or sha(path) != digest]
    if drift:
        raise RuntimeError('Immutable source/product input drift: ' + repr(drift[:10]))


def authenticate_provider(path):
    resolved = str(Path(path).resolve())
    expected = pins.get(path) or pins.get(resolved) or plan['provider_catalog'].get(path) or plan['provider_catalog'].get(resolved)
    if expected is None or sha(path) != expected:
        raise RuntimeError('Unknown or changed actual loader provider: ' + path)
    pins[path] = pins[resolved] = expected
    return {'literal': path, 'resolved': resolved, 'sha256': expected}


try:
    assert resource.getrlimit(resource.RLIMIT_AS) == (resource.RLIM_INFINITY, resource.RLIM_INFINITY)
    pins[str(out / 'run.py')] = sha(__file__)
    state['driver_sha256'] = pins[str(out / 'run.py')]
    state['plan_sha256'] = sha(out / 'plan.json')
    verify()
    spec = importlib.util.spec_from_file_location('owned_monitor', plan['monitor']['path'])
    monitor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(monitor)
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('LD_', 'DYLD_', 'DOME_', 'MESA_', 'LIBGL_', 'GALLIUM_', 'DRI_'))}
    for key in ['ASAN_OPTIONS', 'UBSAN_OPTIONS', 'LSAN_OPTIONS', 'DISPLAY', 'WAYLAND_DISPLAY',
                'WAYLAND_SOCKET', 'DBUS_SESSION_BUS_ADDRESS', '__EGL_VENDOR_LIBRARY_FILENAMES']:
        env.pop(key, None)
    env.update({key: value for key, value in plan['environment'].items() if value is not None})
    env['XR_RUNTIME_JSON'] = str(out / 'no-physical-runtime.json')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    for key, leaf in [('XDG_CONFIG_HOME', 'config'), ('XDG_STATE_HOME', 'state'),
                      ('XDG_CACHE_HOME', 'cache'), ('XDG_RUNTIME_DIR', 'runtime')]:
        env[key] = str(out / leaf)
        Path(env[key]).mkdir(mode=0o700)
    state['environment'] = {key: env.get(key) for key in plan['environment']}
    save()
    lease = Path(plan['lease']).open('a+')
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    identity = os.fstat(lease.fileno())
    assert (identity.st_ino, identity.st_dev) == (99618, 40)
    state['lease'] = {'acquired': time.time(), 'inode': identity.st_ino,
                      'device': identity.st_dev, 'before_any_ldd_or_product': True}
    state['state'] = 'running'
    save()
    for step in plan['steps']:
        name, argv = step['name'], step['argv']
        assert sha(argv[0]) == step['ELF_sha256']
        row = monitor.run(['/usr/bin/ldd', argv[0]], cwd=out, env=env,
                          log=out / (name + '.ldd'), timeout=60, max_rss=step['RSS_bytes'])
        row['name'] = name + '-ldd'
        state['steps'].append(row)
        save()
        assert row['exit'] == 0 and not row.get('signals') and not row.get('error')
        text = (out / (name + '.ldd')).read_text()
        assert 'not found' not in text and not re.search(r'lib(?:asan|ubsan)\.so', text)
        paths = re.findall(r'(?:=>\s*)?(/\S+)\s+\(', text)
        assert paths
        state['providers'][name] = [authenticate_provider(path) for path in paths]
        last_observation = [0.0]
        observed = {}

        def live(progress):
            state['live'] = {'name': name, **progress}
            now = time.monotonic()
            if now - last_observation[0] < 1:
                return
            last_observation[0] = now
            proc = Path('/proc', str(progress['pid']))
            try:
                current = monitor.identity(progress['pid'])
                if not current:
                    return
                assert current['start'] == progress['start']
                executable = os.readlink(proc / 'exe')
                if str(Path(executable).resolve()) == str(Path(argv[0]).resolve()):
                    if not observed:
                        assert sha(proc / 'exe') == step['ELF_sha256']
                        observed.update(pid=progress['pid'], start=progress['start'],
                                        executable=executable, sha256=step['ELF_sha256'])
                    (out / (name + '.maps')).write_text((proc / 'maps').read_text())
            except (FileNotFoundError, ProcessLookupError):
                pass
            save()

        command = argv
        if step['AS_bytes'] is not None:
            command = ['/usr/bin/prlimit', '--as=' + str(step['AS_bytes']), '--', *argv]
        row = monitor.run(command, cwd=out, env=env, log=out / (name + '.log'),
                          timeout=step['per_command_seconds'], max_rss=step['RSS_bytes'], progress=live)
        row.update(name=name, actual_ELF_observation=observed, intended_AS_bytes=step['AS_bytes'])
        state['steps'].append(row)
        state.pop('live', None)
        save()
        assert row['exit'] == 0 and not row.get('signals') and not row.get('error'), name
        text = (out / (name + '.log')).read_text()
        matches = re.findall('^' + step['success_pattern'] + '$', text, re.M)
        assert matches == [str(step['expected_checks'])], (name, matches)
        row['actual_checks'] = int(matches[0])
        if step['graphics']:
            assert 'llvmpipe' in text or 'softpipe' in text
        if name in ['source-canonical-normal-bake', 'source-writable-normal-bake', 'source-joint-writable-normal-bake']:
            folder = Path(argv[-1])
            case = argv[2]
            native, ordered = folder / (case + '.dsculpt'), folder / (case + '-ordered.dsculpt')
            assert sha(native) == sha(ordered)
            row['ordered_native_pair'] = {'native': str(native), 'ordered': str(ordered), 'sha256': sha(native)}
        save()
    state['exit'] = 0
    state['state'] = 'complete'
except BaseException as error:
    state.update(exit=1, state='failed', error=repr(error))
finally:
    state['drift'] = [path for path, digest in pins.items()
                      if not Path(path).is_file() or sha(path) != digest]
    state['owned'] = []
    if monitor:
        for row in state['steps']:
            state['owned'].extend(proc for proc in row.get('known_processes', []) if monitor.alive(proc))
    if state['drift'] or state['owned']:
        state.update(exit=1, state='failed')
    if lease:
        if 'lease' in state:
            state['lease']['released'] = time.time()
        fcntl.flock(lease, fcntl.LOCK_UN)
        lease.close()
    state['terminal'] = True
    (out / 'actual-inputs.json').write_text(json.dumps(pins, indent=2) + '\n')
    save()
raise SystemExit(state['exit'])
