import json,hashlib,re,importlib.util,time
from pathlib import Path
out=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((out/'plan.json').read_text());original=json.loads((out/'status.json').read_text());pins=json.loads((out/'current-inputs.json').read_text())
assert original['terminal'] and original['exit_code']==1 and original['error']=='AssertionError()' and not original['input_drift'] and not original['remaining_owned']
assert original['lease']['released']>=original['lease']['acquired'] and original['lease']['inode']==99618
expected={'creator-vrm':448,'workspace':44,'controls':352,'fixture':1};assert [r['name']for r in original['steps']]==[name+suffix for name in expected for suffix in ['-ldd','']]
for row in original['steps']:assert row['exit']==0 and not row.get('signals') and not row.get('error')
assert not[f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h]
spec=importlib.util.spec_from_file_location('actual_monitor',plan['monitor']['path']);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
assert not[record for row in original['steps']for record in row.get('known_processes',[])if monitor.alive(record)]
records=[]
for step in plan['steps']:
 name=step['name'];text=(out/(name+'.log')).read_text();m=re.findall(r'^CREATOR(?: VRM)? CHECKS ([0-9]+)$',text,re.M);assert m==[str(expected[name])]
 assert sha(step['argv'][0])==step['elf_sha256'];assert any(v['literal']==step['argv'][0]and v['sha256']==step['elf_sha256']for v in original['live_mappings'][name])
 records.append({'name':name,'command':step['argv'],'actual_checks':expected[name],'actual_product_exit':0,'ELF_sha256':step['elf_sha256'],'log_sha256':sha(out/(name+'.log'))})
text=(out/'creator-vrm.log').read_text();assert len(re.findall(r'^CONSUMER corners=',text,re.M))==6;assert len(re.findall(r'^EXPECTED_REFUSAL ',text,re.M))==6
files=sorted((out/'vrm').glob('*.vrm'));assert {f.name for f in files}=={b+'-'+phase+'.vrm'for b in ['vroid-beta-female','vroid-beta-male']for phase in ['styled','reopened','posed']}
review={'state':'reviewed-positive-products-with-preserved-wrapper-failure','review_exit':0,'production':plan['source'],'fixture':plan['fixture'],'original_driver_exit':1,'original_status_sha256':sha(out/'status.json'),'wrapper_failure_cause':'Prepared fixture expected0 checks but actual authored() intentionally asserts genuine artist paint and prints1; all product exits are0','no_original_result_rewritten':True,'actual_products':records,'total_actual_checks':sum(expected.values()),'source_and_provider_pins_rehashed':len(pins),'ordered_consumer_phases':6,'required_real_refusals':6,'VRM_files':[{'path':str(f),'sha256':sha(f)}for f in files],'input_drift':[],'remaining_owned':[],'lease_free_receipt_sha256':sha(out/'lease-free.json'),'strict_SAN_current_group_fixture_runtime':'unrun','public_GUI_XR':'unrun','physical_HMD':'unrun','timestamp':time.time()}
(out/'reviewed-actual-v1.json').write_text(json.dumps(review,indent=2)+'\n');print('Independent actual review0:448 VRM +44 workspace +352 controls +1 painted input; original driver1 preserved')
