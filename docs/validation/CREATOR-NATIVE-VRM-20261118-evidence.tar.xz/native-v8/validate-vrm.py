import json,pathlib,struct,hashlib
from jsonschema import Draft4Validator,RefResolver
out=pathlib.Path(__file__).parent
schemas=pathlib.Path('/tmp/dome-vrm0-schema');entries=json.loads(pathlib.Path('/tmp/dome-vrm0-schema-list.json').read_text())
for item in entries:
 if item['name'].endswith('.json'):
  b=(schemas/item['name']).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==item['sha']
schema=json.loads((schemas/'vrm.schema.json').read_text());store={p.name:json.loads(p.read_text())for p in schemas.glob('*.json')};validator=Draft4Validator(schema,resolver=RefResolver('',schema,store=store));paths=sorted((out/'vrm').glob('*.vrm'));assert len(paths)==6
reports=[]
for p in paths:
 b=p.read_bytes();assert struct.unpack_from('<III',b)==(0x46546c67,2,len(b));j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);errors=list(validator.iter_errors(j['extensions']['VRM']));reports.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'official_VRM0_schema_errors':[str(e)for e in errors]})
result={'schema_commit':'94e82dd346fa6cf0337c4421728640e5252dd38e','schema_git_blobs':{e['name']:e['sha']for e in entries},'models':reports,'total_errors':sum(len(v['official_VRM0_schema_errors'])for v in reports)}
(out/'official-schema-validation.json').write_text(json.dumps(result,indent=2)+'\n');print('Official schema models',len(paths),'errors',result['total_errors']);assert result['total_errors']==0
