import pathlib,json,subprocess,hashlib,os,time,concurrent.futures,shutil
out=pathlib.Path(__file__).parent;p=json.loads((out/'plan.json').read_text());sha=lambda x:hashlib.sha256(pathlib.Path(x).read_bytes()).hexdigest();s={'state':'preparing','steps':[],'source':p['source'],'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__)}
def drift():return[x for x,h in p['input_pins'].items()if not pathlib.Path(x).is_file()or sha(x)!=h]
def save():(out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
try:
 assert not drift();env=os.environ.copy()
 for k in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']:env.pop(k,None)
 for k,v in p['environment'].items():
  if v is None:env.pop(k,None)
  else:env[k]=v
 def compile(row):
  t=time.monotonic()
  with(out/(row['name']+'.log')).open('w')as log:code=subprocess.run(row['argv'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=900).returncode
  return {**row,'exit':code,'seconds':time.monotonic()-t}
 s['state']='compiling';save()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  for row in pool.map(compile,p['compile']):s['steps'].append(row);save()
 assert all(x['exit']==0 for x in s['steps']);assert not drift()
 shutil.copyfile(p['baseline_core'],out/'libdome-sculpt-core.a');objects=[str(out/(x['name']+'.o'))for x in p['compile']if x['name']!='fixture'];argv=['/usr/bin/ar','r',str(out/'libdome-sculpt-core.a'),*objects];subprocess.run(argv,check=True,env=env)
 with(out/'link.log').open('w')as log:r=subprocess.run(p['link'],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=900)
 s['steps'].append({'name':'link','argv':p['link'],'exit':r.returncode});assert not r.returncode;assert not drift();s.update(state='complete',exit=0,elf_sha256=sha(out/'dome-sculpt-creator-vrm-test'),archive_sha256=sha(out/'libdome-sculpt-core.a'))
except BaseException as e:s.update(state='failed',exit=1,error=repr(e))
finally:s['input_drift']=drift();save()
raise SystemExit(s['exit'])
