from pathlib import Path
import os,json,hashlib,subprocess,time,fcntl,importlib.util,re,sys
sys.dont_write_bytecode=True
out=Path(__file__).parent;os.chdir(out);p=json.loads((out/'plan.json').read_text());pins=dict(p['input_pins']);lease=None;monitor=None;s={'state':'preparing','source':p['source'],'fixture':p['fixture'],'steps':[],'providers':{},'live_mappings':{},'plan_sha256':hashlib.sha256((out/'plan.json').read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
def sha(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():(out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return [f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h]
def provider(f):
 path=Path(f);resolved=path.resolve();want=pins.get(str(path))or pins.get(str(resolved))or p['runtime_provider_expected_catalog'].get(str(path))or p['runtime_provider_expected_catalog'].get(str(resolved));assert want,'Unknown runtime provider '+str(path);assert sha(path)==want,'Provider drift '+str(path);pins[str(path)]=want;pins[str(resolved)]=want;return {'literal':str(path),'resolved':str(resolved),'sha256':want}
try:
 assert not drift();spec=importlib.util.spec_from_file_location('monitor',p['monitor']['path']);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
 lease=open(p['lease']['path'],'a+');assert os.fstat(lease.fileno()).st_ino==p['lease']['inode']and os.fstat(lease.fileno()).st_dev==p['lease']['device'];fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);s['lease']={'acquired':time.time(),'owner_pid':os.getpid(),'inode':os.fstat(lease.fileno()).st_ino,'before_any_ldd_or_product':True};save()
 env=os.environ.copy()
 for k in ['LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS']:env.pop(k,None)
 for k,v in p['environment'].items():
  if v is None:env.pop(k,None)
  else:env[k]=v
 def live(name,row):
  pid=row.get('pid');found=[]
  if pid and Path('/proc/'+str(pid)+'/maps').is_file():
   for line in Path('/proc/'+str(pid)+'/maps').read_text().splitlines():
    fields=line.split();f=fields[-1]if fields else''
    if f.startswith('/')and ('.so'in f or f in {v['argv'][0]for v in p['steps']}):
     if f not in [v['literal']for v in found]:found.append(provider(f))
  if found:s['live_mappings'][name]=found
  s['live']={'name':name,**row};save()
 for step in p['steps']:
  s['state']='running';save();name=step['name'];assert sha(step['argv'][0])==step['elf_sha256'];r=monitor.run(['/usr/bin/ldd',step['argv'][0]],cwd=out,env=env,log=out/(name+'.ldd'),timeout=30,max_rss=p['resources']['aggregate_RSS_bytes']);s['steps'].append({'name':name+'-ldd',**r});assert r['exit']==0 and not r.get('error')and not r.get('signals');text=(out/(name+'.ldd')).read_text();assert 'not found'not in text;s['providers'][name]=[provider(f)for f in re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text)];save()
  r=monitor.run(step['argv'],cwd=out,env=env,log=out/(name+'.log'),timeout=p['resources']['per_command_seconds'],max_rss=p['resources']['aggregate_RSS_bytes'],progress=lambda row:live(name,row));s['steps'].append({'name':name,**r});s.pop('live',None);save();assert r['exit']==0 and not r.get('error')and not r.get('signals');summary=re.search(r'^CREATOR(?: VRM)? CHECKS ([0-9]+)$',(out/(name+'.log')).read_text(),re.M);assert summary;actual_checks=int(summary.group(1));assert actual_checks==step['expected_checks']if step['expected_checks']is not None else actual_checks>0;assert any(v['literal']==step['argv'][0]and v['sha256']==step['elf_sha256']for v in s['live_mappings'].get(name,[])),'No actual matching product ELF mapping observed';assert not drift()
 s.update(state='complete',exit_code=0)
except BaseException as error:s.update(state='failed',exit_code=1,error=repr(error))
finally:
 s['input_drift']=drift();s['remaining_owned']=[]
 if monitor:
  for row in s['steps']:
   for record in row.get('known_processes',[]):
    if monitor.alive(record):s['remaining_owned'].append(record)
 if s['input_drift']or s['remaining_owned']:s.update(state='failed',exit_code=1)
 s['terminal']=True
 if lease:
  if 'lease'in s:s['lease']['released']=time.time()
  save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 (out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');save()
raise SystemExit(s['exit_code'])
