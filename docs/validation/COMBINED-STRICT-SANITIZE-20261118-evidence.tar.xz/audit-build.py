from pathlib import Path
import json,hashlib,shlex,re,subprocess,sys
out=Path(__file__).resolve().parent;plan=json.loads((out/'build-plan.json').read_text());state=json.loads((out/'build-status.json').read_text());assert state['state']=='terminal' and state['exit']==0 and state['input_drift']==[]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();owners=json.loads((out/'planned-selected-owners.json').read_text());pins=dict(plan['source_input_pins']);prior=json.loads((out.parent/'source441-headless-sanitize-20261118/qualified-inputs.json').read_text());catalog={};actual_commands=[]
for line in (out/'build.log').read_text().splitlines():
 match=re.match(r'^\[\d+/\d+\] (.*)$',line)
 if not match:continue
 argv=shlex.split(match[1])
 if '-c' in argv and '-o' in argv:actual_commands.append(argv)
assert len(actual_commands)==len(owners)==217
lookup={str((out/argv[argv.index('-o')+1]).resolve()):argv for argv in actual_commands};assert len(lookup)==217
result=[];unknown={};resolved_expected={}
for owner in owners:
 obj=Path(owner['object']);argv=lookup[str(obj.resolve())];assert argv==owner['planned_argv'],owner['source'];src=Path(argv[argv.index('-c')+1]);assert str(src)==owner['source'];assert src.is_file()
 for flag in ['-fsanitize=address,undefined','-fno-omit-frame-pointer','-g1']:
  assert flag in argv,(str(obj),flag)
 assert not any(arg.startswith('-fno-sanitize') for arg in argv)
 assert '/usr/bin/timeout' in argv and '/usr/bin/prlimit' in argv and '--as=3221225472' in argv and '--cpu=900' in argv
 dep=Path(owner['actual_MD_expected']);assert dep.is_file();text=dep.read_text().replace('\\\n',' ');targets,raw=text.split(':',1);dependencies=shlex.split(raw);assert str(src) in dependencies
 rows=[]
 for literal in dependencies:
  path=Path(literal);path=path if path.is_absolute() else out/path;actual=sha(path);want=pins.get(str(path),pins.get(str(path.resolve())))
  authority='immutable fresh-build source/configure/tool expectation'
  if want is None:
   want=prior.get(str(path),prior.get(str(path.resolve()),catalog.get(str(path),catalog.get(str(path.resolve())))))
   authority='qualified strictSAN441 prior actual dependency/provider expectation'
  if want is None:
   if path.is_relative_to(out):
    authority='genuine newly generated current build dependency; observed post-generation, not called pre-build input';want=actual
   else:unknown[str(path)]=actual
  else:assert actual==want,('Actual compiler dependency drift',str(path),actual,want)
  if want is not None:
   for p in [path,path.resolve()]:
    if str(p) in pins:assert pins[str(p)]==want
    pins[str(p)]=want
  rows.append({'literal':literal,'actual_path':str(path),'sha256':actual,'authority':authority})
 result.append({**owner,'actual_compile_argv':argv,'actual_compile_cwd':str(out),'object_sha256':sha(obj),'actual_MD':str(dep),'actual_MD_sha256':sha(dep),'actual_dependencies':rows})
if unknown:
 (out/'unknown-dependency-expectations.json').write_text(json.dumps(unknown,indent=2)+'\n');raise RuntimeError('Unknown non-generated dependency expectations; no successful audit claimed: '+str(list(unknown)[:8]))
core=[row for row in result if row['role']=='core'];assert len(core)==195;archive=out/'libdome-sculpt-core.a';names=subprocess.check_output(['/usr/bin/ar','t',str(archive)],text=True).splitlines();assert len(names)==195 and len(set(names))==195
expected={Path(row['object']).name:row['object_sha256'] for row in core};assert set(names)==set(expected)
for name in names:
 blob=subprocess.check_output(['/usr/bin/ar','p',str(archive),name]);assert hashlib.sha256(blob).hexdigest()==expected[name]
for row in result:
 for path,want in [(Path(row['object']),row['object_sha256']),(Path(row['actual_MD']),row['actual_MD_sha256'])]:pins[str(path)]=want
for path in [out/'build-status.json',out/'build.log',out/'build-plan.json',out/'build-native.py',out/'audit-build.py',archive]:pins[str(path)]=sha(path)
for name in plan['expected_executables']:
 path=out/name;assert sha(path)==state['executable_sha256'][name];pins[str(path)]=sha(path)
summary={'state':'complete','exit_code':0,'production':plan['production_source'],'source_history':plan['source'],'fresh_actual_compiler_owners':217,'fresh_core_members':195,'fresh_fixtures':7,'support_owners':15,'copied_R_payloads':0,'copied_S_payloads':0,'archive':str(archive),'archive_sha256':sha(archive),'all_compile_commands_instrumented':True,'build_status_sha256':sha(out/'build-status.json'),'input_drift':[p for p,h in pins.items() if not Path(p).is_file() or sha(p)!=h],'owners':result}
assert summary['input_drift']==[];(out/'actual-MD-owners.json').write_text(json.dumps(summary,indent=2)+'\n');pins[str(out/'actual-MD-owners.json')]=sha(out/'actual-MD-owners.json');(out/'qualified-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='owners'},indent=2))
