import json,pathlib,hashlib,subprocess,os,time
out=pathlib.Path(__file__).resolve().parent
plan=json.loads((out/'build-plan.json').read_text())
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def drift():return [p for p,h in plan['source_input_pins'].items() if not pathlib.Path(p).is_file() or sha(p)!=h]
state={'state':'preflight','scope':plan['scope'],'source':plan['source'],'plan_sha256':sha(out/'build-plan.json'),'driver_sha256':sha(__file__),'argv':plan['argv'],'pid':os.getpid(),'input_drift':drift()}
def save():(out/'build-status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 if state['input_drift']:raise RuntimeError('Source/configure/tool input drift')
 env=os.environ.copy()
 for k in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','CMAKE_PREFIX_PATH']:env.pop(k,None)
 for k,v in plan['environment'].items():
  if v is None:env.pop(k,None)
  else:env[k]=v
 state['state']='running';save();t=time.monotonic()
 with (out/'build.log').open('w') as log:
  child=subprocess.Popen(plan['argv'],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);state['child_pid']=child.pid;save();state['exit']=child.wait()
 state['elapsed_seconds']=time.monotonic()-t;state['input_drift']=drift()
 if state['input_drift']:state['exit']=state['exit'] or 1
 state['build_log_sha256']=sha(out/'build.log')
 state['genuine_compiler_depfile_count']=len(list(out.rglob('*.o.d')))
 if state['exit']==0:
  state['executable_sha256']={}
  for name in plan['expected_executables']:
   app=out/name
   if not app.is_file():raise RuntimeError('Native target returned success without output '+name)
   state['executable_sha256'][name]=sha(app)
except BaseException as e:state.update(exit=1,error=repr(e))
finally:state['state']='terminal';save()
raise SystemExit(state['exit'])
