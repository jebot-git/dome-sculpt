#include "dome/baked-emission.hpp"
#include "dome/material-bindings.hpp"
#include "dome/scene.hpp"
#include "paint-overlay-packet.hpp"
#include <iostream>
int main(int argc,char **argv) {
  if(argc!=2)return 1;
  auto scene=dome::Scene::load(argv[1]);
  for(const auto&o:scene.objects())if(o.painted){
    const auto &p=*o.painted;
    auto b=p.baked();
    auto m=o.material_bindings;
    auto packet=dome::detail::PaintOverlayFactory::capture(p);
    std::cout<<o.id<<" "<<o.name<<" visible="<<o.visible<<" res="<<p.resolution()
             <<" layers="<<p.layers().size()<<" stored="<<p.storage_bytes()
             <<" packet="<<packet->storage_bytes()<<" bake="<<(b?b->storage_bytes():0)
             <<" normal="<<(b?b->maps.normal.rgba.size():0)
             <<" normal_field="<<(b&&bool(b->normal_field))
             <<" physical="<<p.has_physical_emission()
             <<" raw_source="<<bool(p.source_maps())<<" domain="<<bool(p.paint_sampling_domain())
             <<" native="<<(m&&bool(m->native_paint_sampling))
             <<" native_frame="<<(m&&bool(m->native_paint_frames))
             <<" canonical="<<(m&&bool(m->canonical_paint_sampling))
             <<" uv_policy="<<int(p.surface_diagnostics().policy)<<"\n";
    for(const auto &l:p.layers())std::cout<<"  "<<l.name<<" visible="<<l.visible
      <<" occupied="<<std::count_if(l.tiles.begin(),l.tiles.end(),[](auto &t){return bool(t);})<<"\n";
  }
}
