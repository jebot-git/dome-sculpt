#!/usr/bin/env python3
"""Exercise default Editable GLB export of a full-resolution keyed native Bake through an isolated native DomeD Wayland session."""
import asyncio,hashlib,json,os,platform,re,shutil,signal,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from dbus_next.aio import MessageBus
from dbus_next import Variant
from Xlib import X,XK,display
from Xlib.ext import xtest
signal.pthread_sigmask(signal.SIG_SETMASK,[])
if os.environ.get('DOME_PROJECTION_WL_BUS')!='1':os.execvpe('dbus-run-session',['dbus-run-session','--',sys.executable,*sys.argv],{**os.environ,'DOME_PROJECTION_WL_BUS':'1'})
root=Path(__file__).resolve().parents[1];build=Path(os.environ.get('DOME_SCULPT_TEST_BUILD',root/'build'));compositor=Path(os.environ['DOME_COMPOSITOR']);out=Path(os.environ['DOME_CAGE_WL_OUT']);out.mkdir(parents=True,exist_ok=True);checks=[];processes=[]
texture_set=os.environ.get('DOME_CAGE_TEXTURE_SET')=='1'
def check(ok,label):
 checks.append({'passed':bool(ok),'check':label});(out/'report.json').write_text(json.dumps({'checks':checks,'complete':False},indent=2)+'\n');print(('PASS ' if ok else 'FAIL ')+label,flush=True);assert ok,label
async def wait(fn,seconds=60):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   value=fn()
   if value:return value
  except (OSError,ValueError,KeyError,StopIteration):pass
  await asyncio.sleep(.08)
 raise TimeoutError('Private DomeD Editable GLB condition timed out')
def start(args,name,env,**kw):
 log=(out/(name+'.log')).open('w');p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,**kw);processes.append(p);return p
async def main():
 with tempfile.TemporaryDirectory(prefix='dome-cage-wl-',ignore_cleanup_errors=True) as home:
  rd,wr=os.pipe();start(['Xvfb','-displayfd',str(wr),'-screen','0','1600x1000x24','-nolisten','tcp','-noreset'],'xvfb',os.environ.copy(),pass_fds=(wr,));os.close(wr)
  with os.fdopen(rd) as pipe:screen=':'+pipe.readline().strip()
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  icd=next(p for p in (Path('/usr/share/vulkan/icd.d/lvp_icd.json'),Path('/usr/share/vulkan/icd.d/lvp_icd.'+platform.machine()+'.json')) if p.is_file())
  config=Path(home,'config/dome');config.mkdir(parents=True);(config/'keyboard.json').write_text(json.dumps({'ime':False,'layout':'us'}))
  env={**os.environ,'HOME':home,'DISPLAY':screen,'XDG_CONFIG_HOME':home+'/config','XDG_DATA_HOME':home+'/data','XDG_CACHE_HOME':home+'/cache','XDG_RUNTIME_DIR':home,'XDG_CURRENT_DESKTOP':'Dome','XDG_SESSION_TYPE':'wayland','VK_DRIVER_FILES':str(icd),'LIBGL_ALWAYS_SOFTWARE':'1','GIO_USE_VFS':'local','LIBGL_KOPPER_DISABLE':'true','LP_NUM_THREADS':'2','DOME_RENDER_CAPTURE':str(out/'render.ppm'),'DOME_LOGIN_SESSION':'0','DOME_PREVIEW_PORT':str(port),'DOME_RENDERER':'vulkan','DOME_START_XR':'0','DOME_START_TRAY':'0','DOME_START_IME':'0','DOME_SESSION_RESTORE':'0','DBUS_SYSTEM_BUS_ADDRESS':'unix:path=/nonexistent/viewport-test-bus','XR_RUNTIME_JSON':'/nonexistent/viewport-no-headset.json','RUST_LOG':'warn','SPNAV_SOCKET':home+'/spnav.sock'}
  for k in ('WAYLAND_DISPLAY','WAYLAND_SOCKET','FLTK_BACKEND','QT_QPA_PLATFORM'):env.pop(k,None)
  host_process=start([str(compositor),'--backend','nested'],'compositor',env);base=f'http://127.0.0.1:{port}'
  def scene():return json.load(urllib.request.urlopen(base+'/api/state',timeout=2))['scene']
  def action(data):urllib.request.urlopen(urllib.request.Request(base+'/api/action',data=json.dumps(data).encode(),headers={'Content-Type':'application/json'}),timeout=2).close()
  await wait(lambda:scene()['source']=='wayland');wayland=re.search(r'Dome Wayland socket: (\S+)',(out/'compositor.log').read_text())[1]
  project=Path(home,'patch.dsculpt')
  shutil.copyfile(os.environ['DOME_AFFINE_PATCH'],project)
  def digest(path):
   with Path(path).open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
  original_sha=digest(project)
  report=Path(home,'widgets.json')
  client=start([os.environ['DOME_CAGE_APP'],str(project)],'client',{**env,'WAYLAND_DISPLAY':wayland,'FLTK_BACKEND':'wayland','LD_PRELOAD':os.environ['DOME_CAGE_PROBE'],'LD_LIBRARY_PATH':os.environ.get('DOME_CAGE_CLIENT_LD_LIBRARY_PATH',env.get('LD_LIBRARY_PATH','')),'DOME_CAGE_WIDGET_REPORT':str(report)},cwd=home)
  def named(title):return next((w for w in scene()['windows'] if title in w['title']),None)
  window=await wait(lambda:named('patch.dsculpt'));(out/'runtime-maps.txt').write_text(Path('/proc/'+str(client.pid)+'/maps').read_text());check(window['app_id']=='org.domed.Sculpt','Native Wayland editable export client publishes the Dome Sculpt identity')
  d=display.Display(screen);host=await wait(lambda:next((w for w in d.screen().root.query_tree().children if 'Dome' in str(w.get_wm_name() or '')),None));host.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync();action({'op':'focus','id':window['id']});await asyncio.sleep(.4)
  async def key(name,down=None):
   code=d.keysym_to_keycode(XK.string_to_keysym(name))
   for kind in ([X.KeyPress,X.KeyRelease] if down is None else [X.KeyPress if down else X.KeyRelease]):xtest.fake_input(d,kind,code);d.sync();await asyncio.sleep(.06)
  async def chord(*names):
   for n in names:await key(n,True)
   for n in reversed(names):await key(n,False)
  bus=await MessageBus().connect();db=bus.get_proxy_object('org.freedesktop.DBus','/org/freedesktop/DBus',await bus.introspect('org.freedesktop.DBus','/org/freedesktop/DBus')).get_interface('org.freedesktop.DBus');menu=None
  end=time.monotonic()+60
  while menu is None and time.monotonic()<end:
   for service in await db.call_list_names():
    if not service.startswith(':'):continue
    try:
     endpoint='/org/de_xr/FLTK/Menu1';candidate=bus.get_proxy_object(service,endpoint,await asyncio.wait_for(bus.introspect(service,endpoint),1)).get_interface('com.canonical.dbusmenu');result=await candidate.call_get_layout(0,-1,[])
     if 'Export editable project (.glb)...' in str(result):menu=candidate;break
    except Exception:pass
   if menu is None:await asyncio.sleep(.1)
  check(menu is not None,'Native Wayland client exports the universal Editable GLB export command')
  async def layout():
   result=await menu.call_get_layout(0,-1,[])
   nodes={}
   def walk(node):
    ident,properties,children=node
    nodes[properties.get('label',Variant('s','')).value.replace('_','')]=(ident,properties)
    for child in children:walk(child.value)
   walk(result[1])
   return nodes
  async def command(label):
   nodes=await layout()
   ident,properties=nodes[label]
   assert properties.get('enabled',Variant('b',True)).value,label
   await menu.call_event(ident,'clicked',Variant('i',0),0)
   await asyncio.sleep(.15)
  def widget(label,window_label="Editable GLB export"):
   try:windows=json.loads(report.read_text())
   except (OSError,ValueError):return None
   def walk(item):
    if item['label']==label:return item
    for c in item.get('children',[]):
     found=walk(c)
     if found:return found
   for w in windows:
    if w['label']==window_label:
     found=walk(w)
     if found:return found
  label='Export editable project (.glb)...'
  title='Editable GLB export'
  async def open_dialog():
   await command(label)
   dialog=await wait(lambda:named(title))
   host.set_input_focus(X.RevertToParent,X.CurrentTime)
   d.sync()
   action({'op':'focus','id':dialog['id']})
   await wait(lambda:scene()['focused']==dialog['id'])
   return dialog
  async def focus_widget(label,caption=title):
   await wait(lambda:widget(label,caption))
   for _ in range(36):
    if widget(label,caption)['focused']:return True
    await key('Tab')
   return False
  async def ready(label,seconds=90):
   deadline=time.monotonic()+seconds
   while time.monotonic()<deadline:
    item=(await layout()).get(label)
    if item and item[1].get('enabled',Variant('b',True)).value:return
    await asyncio.sleep(.15)
   raise AssertionError('Universal command never enabled: '+label)
  package=Path(home,'Project.glb')
  await ready(label)
  dialog=await open_dialog()
  choice=await wait(lambda:widget('Portable textures',title))
  check(dialog['app_id']==window['app_id'] and choice['selected']=='512 pixels',
        'DomeD focuses the native export policy with its default 512 setting')
  await chord('Control_L','w')
  await wait(lambda:named(title) is None)
  check(digest(project)==original_sha and not package.exists(),'Ctrl+W cancels the export policy without authoring or writing')
  await open_dialog()
  check(await focus_widget('Export'),'DomeD keyboard routing reaches Export')
  await key('space')
  chooser=await wait(lambda:named('Export editable project'))
  host.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync()
  action({'op':'focus','id':chooser['id']})
  await wait(lambda:scene()['focused']==chooser['id'])
  check(chooser['app_id']==window['app_id'],'Default export policy opens the actual native file chooser')
  await key('Return')
  await wait(lambda:named('Export editable project') is None)
  await wait(package.is_file,120)
  check(digest(package)==digest(os.environ['DOME_RECIPIENT_EXPECTED']),
        'Default FLTK export matches the full-resolution native package')
  check(digest(project)==original_sha,'The published package preserves the original native input file')
  shutil.copyfile(package,out/'editable.glb')
  await command('Close Window')
  await wait(lambda:client.poll() is not None)
  check(client.returncode==0,'Native Wayland export client closes normally')
  (out/'report.json').write_text(json.dumps({'checks':checks,'complete':True},indent=2)+'\n')
  d.close()
  bus.disconnect()
try:asyncio.run(main())
finally:
 for p in reversed(processes):
  if p.poll() is None:
   p.terminate()
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:p.kill();p.wait()
