from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
destination=repo/"docs/validation"
name="native-hdr-editable-2048-20261127"
product=subprocess.check_output(["git","-C",repo,"rev-parse",sys.argv[1]],text=True).strip()
assert subprocess.check_output(["git","-C",repo,"show","--format=","--binary",product])==(root/"source.patch").read_bytes()
files={}
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
def keep(filename):
    path=root/filename
    files[filename]=path
    return sha(path)
def read(filename):
    return json.loads((root/filename).read_text())

report={"product":product,"source_patch_sha256":keep("source.patch"),"profiles":{},"frontends":{},
        "presets":{},"scope":"Editable GLB at all three portable texture presets from a varying 2048-square HDR Bake with an edited key and converted normal frame. Exact retained native composite, paint, and restore data; finite portable material view."}
for filename in ("product.patch","product-v2.patch","record.py","run-v1.py","run.py","editable.cpp",
                 "inspect.cpp","checks.py","preset.cpp","public-focus.py","wayland.py","xr-focus.py",
                 "registered-release.log","registered-ctest.json"):
    keep(filename)
legacy=root.parent/"native-shared-bake-20261127/release/build/native-writable-first-key-2048/editable-2048.glb"
release={}
for profile in ("release-v2","asan-v2"):
    state=read(f"{profile}/status.json")
    check=read(f"{profile}/checks/status.json")
    assert state["terminal"] and state["exit"]==0 and check["terminal"] and check["exit"]==0
    assert state["diff_sha256"]==sha(root/"product-v2.patch")
    expected={
        "editable.log":"Editable reopens exact native Scene",
        "checks/dense-editable-hdr.log":"PASS 17961 full-resolution Editable HDR checks",
        "checks/dense-editable-ldr.log":"PASS 6 full-resolution Editable GLB checks",
        "checks/dome-sculpt-native-authoring-test.log":"Native authoring package: 28 checks",
        "checks/dome-sculpt-native-authoring-real-test.log":"PASS Real CC0 male19part",
        "checks/dome-sculpt-native-paint32-emission-mixed-test.log":"PASS 29 native32 mixed physical checks",
        "checks/presets.log":"Preset 1024 wrote 33417080 bytes and restores exact native Scene",
    }
    for file,result in expected.items():
        assert result in (root/profile/file).read_text(),(profile,file)
    logs={file:keep(f"{profile}/{file}") for file in (
        "status.json","archive.log","native-authoring-compiler.cpp.log","dome-sculpt-link.log",
        "editable-link.log","checks/status.json",*expected)}
    input=root/profile/"checks/native/portable-varied-hdr-native.dsculpt"
    restored=root/profile/"checks/native/editable-varied-hdr-native.dsculpt"
    assert sha(input)==sha(restored)
    assert sha(root/profile/"checks/legacy/editable-2048.glb")==sha(legacy)
    for resolution,file in (
        (256,f"{profile}/checks/presets/editable-256.glb"),
        (512,f"{profile}/probe/editable.glb"),
        (1024,f"{profile}/checks/presets/editable-1024.glb")):
        data={"bytes":(root/file).stat().st_size,"sha256":sha(root/file)}
        if profile=="release-v2":release[resolution]=data
        else:assert data==release[resolution]
        if resolution==512:assert data["sha256"]==sha(root/profile/"checks/native/editable-varied-hdr-512.glb")
    report["profiles"][profile]={"app_sha256":state["app_sha256"],"native_sha256":sha(input),
                                 "invocation":state["invocation"],"logs_sha256":logs}
for mode in ("wayland","software","arc"):
    folder=f"{mode}-focus-editable-hdr"
    state=read(f"{folder}/status.json")
    assert state["terminal"] and state["exit"]==0 and state["checks"]==(9 if mode=="wayland" else 10)
    assert state["native_sha256"]==release[512]["sha256"]
    for file in ("status.json","run.log","workflow/report.json"):
        keep(f"{folder}/{file}")
    if mode=="wayland":
        for file in ("runtime-maps.txt","client.log","compositor.log"):
            keep(f"{folder}/workflow/{file}")
    else:
        for step in ("accept","focus"):
            for file in ("graphics.json","application.log"):
                keep(f"{folder}/workflow/{step}/{file}")
    report["frontends"][mode]=state
for resolution,file in (
    (256,"release-v2/preset-early-output/editable-256.glb"),
    (512,"release-v2/probe/editable.glb"),
    (1024,"release-v2/preset-early-output/editable-1024.glb"),
):
    assert sha(root/file)==release[resolution]["sha256"]
    validation=read(file+".khronos.json")
    issues=validation["issues"]
    assert issues["numErrors"]==0 and issues["numWarnings"]==1
    assert [m["code"] for m in issues["messages"] if m["severity"]==1]==["NODE_SKINNED_MESH_NON_ROOT"]
    report["presets"][resolution]={**release[resolution],
        "khronos": {"errors":0,"warnings":["NODE_SKINNED_MESH_NON_ROOT"],
                    "report_sha256":keep(file+".khronos.json")}}
probe="texture-set-probe/visible-hdr.log"
log=(root/probe).read_text()
assert "material=0 resolution=64 retained=1 physical=1" in log
assert "material=1 resolution=64 retained=1 physical=1" in log
assert "standard: Texture-set surfaces require their owning subset render/export adapter" in log
assert "editable: Texture-set native HDR export needs its per-material precision-qualified compiler" in log
keep("texture-set-probe/probe.cpp")
report["texture_set_followup"]={"log_sha256":keep(probe),"fixture_sha256":sha(
    root/"texture-set-probe/visible-hdr-output/visible-retained-hdr.dsculpt")}
report["open"]="Per-material HDR for texture sets, full integrated regression and physical headset verification remain open."
archive=destination/(name+".tar.gz")
with archive.open("wb") as raw,gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode="w") as tar:
    for filename,path in sorted(files.items()):
        payload=path.read_bytes()
        item=tarfile.TarInfo(filename)
        item.size=len(payload)
        tar.addfile(item,io.BytesIO(payload))
report["archive"]={"file":archive.name,"sha256":sha(archive),"members":len(files)}
(destination/(name+".json")).write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
print(product,report["archive"])
