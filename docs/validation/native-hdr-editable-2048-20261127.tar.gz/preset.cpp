#include "dome/document.hpp"
#include "dome/native-authoring.hpp"
#include <array>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <nlohmann/json.hpp>
int main(int argc, char **argv) try {
  using namespace dome;
  if(argc!=3)throw std::invalid_argument("Usage: preset input directory");
  const std::filesystem::path input=argv[1],dir=argv[2];
  std::filesystem::create_directories(dir);
  Document doc;
  doc.open(input);
  if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
    throw std::runtime_error(doc.frame().state->error);
  for(auto [resolution,policy]:std::array{std::pair{256,AssetExportFormat::EditableGlb256},
                                        std::pair{1024,AssetExportFormat::EditableGlb1024}}){
    const auto file=dir/("editable-"+std::to_string(resolution)+".glb");
    doc.export_asset(file,policy).get();
    std::ifstream stream(file,std::ios::binary);
    const std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(stream)),{});
    const auto restored=extract_native_authoring(bytes);
    if(!restored||restored->encode()!=Scene::load(input).encode())
      throw std::runtime_error("Editable GLB changed native authoring data");
    std::cout<<"Preset "<<resolution<<" wrote "<<bytes.size()<<" bytes and restores exact native Scene"<<std::endl;
  }
  return 0;
} catch(const std::exception &e) {
  std::cerr<<"Editable preset failure: "<<e.what()<<std::endl;
  return 1;
}
