from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
src = root / "source"
profile = sys.argv[1]
base = root.parent / "hdr-portable-streaming-20261127" / profile
baseline = root.parent / "native-shared-bake-20261127" / profile
older = root.parent / "native-hdr-compact-20261126" / profile / "build"
out = root / profile
out.mkdir(exist_ok=True)
core = out / "libdome-sculpt-core.a"
state = {"profile": profile, "invocation": os.environ.get("INVOCATION_ID")}
toolkit = root.parent / "sdk-20261126/toolkit-sanitize" if profile=="asan" else Path("/opt/fltk-vr/toolkit")
env = dict(os.environ, LD_LIBRARY_PATH=f"{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64", 
           LIBGL_ALWAYS_SOFTWARE="1", EGL_PLATFORM="surfaceless", LP_NUM_THREADS="2",
           ASAN_OPTIONS="detect_leaks=1:halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")

def status(phase, **values):
    state.update(phase=phase, **values)
    (out/"status.json").write_text(json.dumps(state, indent=2)+"\n")

def run(args, name, cwd=out):
    with (out/name).open("w") as log:
        print(shlex.join(map(str,args)), file=log, flush=True)
        subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=720,check=True)

def sha(path):
    with path.open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()

try:
    entries = json.loads((baseline/"build/compile_commands.json").read_text())
    rows = {(Path(row["file"]).name,row["output"].split("CMakeFiles/",1)[1].split("/",1)[0].removesuffix(".dir")):row
            for row in entries}
    previous_src = root.parent/"native-shared-bake-20261127/source"
    def compile_object(name, owner, source=None):
        args=shlex.split(rows[name,owner]["command"].replace(str(previous_src),str(src)))
        object_path=out/(source.stem+".cpp.o" if source else name+".o")
        args[args.index("-o")+1]=str(object_path)
        if source:
            args[-1]=str(source)
            args.insert(1,"-I"+str(src/"src"))
        run(args, object_path.stem+".log")
        return object_path

    status("compile changed core translation units", diff_sha256=sha(root/"source.patch"))
    with ThreadPoolExecutor(max_workers=2) as pool:
        changed = list(pool.map(lambda filename:compile_object(filename,"dome-sculpt-core"),
                                ("paint.cpp","native-authoring-compiler.cpp")))
    shutil.copyfile(base/core.name,core)
    run(["ar","rs",core,*changed],"archive.log")
    assert subprocess.check_output(["ar","t",core])==subprocess.check_output(["ar","t",base/core.name])
    for obj in changed:assert subprocess.check_output(["ar","p",core,obj.name])==obj.read_bytes()

    def relink(target, obj=None, result=None):
        args=shlex.split(subprocess.check_output(["ninja","-t","commands",target],cwd=older,text=True).splitlines()[-1])[2:-2]
        flags=[]
        for word in args:
            if word.startswith("-Wl,--dependency-file"):continue
            if word==core.name:word=str(core)
            elif word=="libdome-sculpt-emission-codec.a":word=str(base/word)
            elif obj and target+".dir/" in word and word.endswith(".o"):word=str(obj)
            elif not word.startswith("/") and word.endswith((".a",".o")):word=str(older/word)
            flags.append(word)
        exe=out/(result or target)
        flags[flags.index("-o")+1]=str(exe)
        run(flags,exe.name+"-link.log")
        return exe

    status("relink exact application and editable fixture")
    probe=compile_object("native-authoring-compiler.cpp","dome-sculpt-core",root/"editable.cpp")
    executable=relink("dome-sculpt-emission-export-test",probe,"editable")
    app=relink("dome-sculpt")
    fixture=root.parent/"native-shared-bake-20261127/release/edited/converted-varied-key.dsculpt"
    status("run full-resolution editable worker",app_sha256=sha(app))
    run([executable,fixture,out/"probe"],"editable.log")
    status("complete", terminal=True, exit=0)
except BaseException as error:
    status("failed",terminal=True,exit=1,error=repr(error))
    raise
