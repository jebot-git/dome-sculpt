#include "dome/document.hpp"
#include "dome/texture-sets.hpp"
#include <array>
#include <filesystem>
#include <iostream>
int main(int argc,char **argv) try {
  using namespace dome;
  if(argc!=3)return 2;
  const std::filesystem::path dir=argv[2];
  std::filesystem::create_directories(dir);
  Document doc;
  doc.open(argv[1]);
  if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
    throw std::runtime_error(doc.frame().state->error);
  auto scene=doc.copy_scene();
  for(const auto &o:scene.objects())scene.object(o.id).visible=bool(o.texture_sets);
  scene.save(dir/"visible-retained-hdr.dsculpt");
  doc.replace(scene);
  if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
    throw std::runtime_error(doc.frame().state->error);
  for(const auto&o:scene.objects())if(o.texture_sets) {
    std::vector<TextureSetId> sets{0};
    for(const auto &field:o.texture_sets->additional())sets.push_back(field.id);
    for(auto set:sets) {
      const auto view=texture_set_view(o,set);
      std::cout<<"object="<<o.id<<" material="<<view.id<<" resolution="<<view.painted->resolution()
               <<" retained="<<bool(view.source)<<" physical="<<view.painted->has_physical_emission()<<'\n';
    }
  }
  for(auto [name,format]:std::array{std::pair{"standard",AssetExportFormat::Glb},
                                   std::pair{"editable",AssetExportFormat::EditableGlb512}}) {
    try {doc.export_asset(dir/(std::string(name)+".glb"),format).get();
      std::cout<<name<<": exported\n";
    } catch(const std::exception &e) {std::cout<<name<<": "<<e.what()<<'\n';}
  }
  return 0;
} catch(const std::exception &e) {std::cerr<<e.what()<<'\n';return 1;}
