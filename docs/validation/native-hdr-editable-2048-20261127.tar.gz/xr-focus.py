from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import signal

signal.pthread_sigmask(signal.SIG_SETMASK, [])
app,runtime,fixture,out=map(Path,sys.argv[1:])
out.mkdir(exist_ok=True)
manifest=out/'runtime.json'
manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(runtime)}}))
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
before_hash=sha(fixture)
checks=[]
def check(ok,label):
    checks.append({'passed':bool(ok),'check':label})
    (out/'report.json').write_text(json.dumps({'checks':checks},indent=2)+'\n')
    assert ok,label
for mode in ('accept','focus'):
    run_dir=out/mode
    run_dir.mkdir(exist_ok=True)
    home=run_dir/'home'
    home.mkdir(exist_ok=True)
    source=run_dir/'converted.dsculpt'
    shutil.copyfile(fixture,source)
    native=run_dir/'after.dsculpt'
    package=source.with_suffix('.glb')
    graphics=run_dir/'graphics.json'
    env={**os.environ,'XR_RUNTIME_JSON':str(manifest),'DOME_XR_FIXTURE_DENSE_EDITABLE':mode,
         'DOME_XR_FIXTURE_REPORT':str(graphics),'HOME':str(home),'XDG_RUNTIME_DIR':str(home),
         'XDG_CONFIG_HOME':str(home/'config'),'XDG_STATE_HOME':str(home/'state')}
    with (run_dir/'application.log').open('w') as log:
        run=subprocess.run([app,'--xr','--open',source,'--frames','95','--save',native],
                           env=env,stdout=log,stderr=subprocess.STDOUT,timeout=200)
    check(run.returncode==0 and native.is_file(),mode+' saves the native project and exits normally')
    result=json.loads(graphics.read_text())
    check(os.environ['DOME_XR_REQUIRE_RENDERER'] in result.get('gl_renderer',''),
          mode+' uses the requested renderer')
    check(result['left_eye_nonblank']>0 and result['right_eye_nonblank']>0 and
          result['acquires']==result['image_waits']==result['releases'] and
          result['frames_waited']==result['frames_begun']==result['frames_ended'],
          mode+' renders both stereo eyes with balanced image and frame ownership')
    if mode=='accept':
        check(package.is_file() and sha(package)==sha(os.environ['DOME_RECIPIENT_EXPECTED']),
              'Controller Editable 512 matches the full-resolution native package')
    else:
        check(result['focus_losses']==1 and result['focus_regains']==1 and not package.exists(),
              'Focus loss before export admission prevents creation of a GLB')
    check(sha(source)==sha(native)==before_hash,mode+' preserves every byte of the native project')
print(len(checks),'actual-loader XR export checks passed')
