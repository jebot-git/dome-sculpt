from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
profile=sys.argv[1]
src=root/"source"
out=root/(profile+"-v2")
work=out/"checks"
work.mkdir(exist_ok=True)
old=root.parent/"native-hdr-compact-20261126"/profile/"build"
shared=root.parent/"native-shared-bake-20261127"/profile
stream=root.parent/"hdr-portable-streaming-20261127"/profile
sdk=root.parent/"sdk-20261126/toolkit-sanitize" if profile=="asan" else Path("/opt/fltk-vr/toolkit")
env=dict(os.environ, LD_LIBRARY_PATH=f"{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
    ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",
    LIBGL_ALWAYS_SOFTWARE="1", LP_NUM_THREADS="2", EGL_PLATFORM="surfaceless")
invocation=os.environ.get("INVOCATION_ID")
names={
    "dome-sculpt-source-writable-normal-bake-test":"source-writable-normal-bake.cpp",
    "dome-sculpt-native-authoring-test":"native-authoring.cpp",
    "dome-sculpt-native-authoring-real-test":"native-authoring-real.cpp",
    "dome-sculpt-native-paint32-emission-mixed-test":"native-paint32-emission-mixed.cpp",
}
def run(args,filename):
    with (work/filename).open("w") as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        subprocess.run(args,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
def record(**values):
    (work/"status.json").write_text(json.dumps({"invocation":invocation,**values},indent=2)+"\n")
try:
    assert (out/"libdome-sculpt-core.a").is_file()
    db=json.loads((shared/"build/compile_commands.json").read_text())
    shared_src=root.parent/"native-shared-bake-20261127/source"
    def build(target):
        if target=="preset":
            owner="dome-sculpt-emission-export-test"
            filename="emission-export.cpp"
        else:
            owner=target
            filename=names[target]
        row=next(c for c in db if f"/{owner}.dir/" in c["output"] and Path(c["file"]).name==filename)
        command=shlex.split(row["command"].replace(str(shared_src),str(src)))
        if target=="preset":
            command[-1]=str(root/"preset.cpp")
        obj=work/(target+".o")
        command[command.index("-o")+1]=str(obj)
        run(command,target+"-compile.log")
        args=shlex.split(subprocess.check_output(["ninja","-t","commands",owner],cwd=old,text=True).splitlines()[-1])[2:-2]
        result=[]
        for word in args:
            if word.startswith("-Wl,--dependency-file"):continue
            if f"{owner}.dir/" in word and word.endswith(".o"):word=str(obj)
            elif word=="libdome-sculpt-core.a":word=str(out/word)
            elif word=="libdome-sculpt-emission-codec.a":word=str(stream/word)
            elif not word.startswith("/") and word.endswith((".a",".o")):word=str(old/word)
            result.append(word)
        exe=work/target
        result[result.index("-o")+1]=str(exe)
        run(result,target+"-link.log")

    registry=[*names,"preset"]
    record(phase="build validation fixtures",targets=registry)
    with ThreadPoolExecutor(max_workers=2) as tasks:list(tasks.map(build,registry))
    record(phase="run selected native tests and presets",targets=registry)
    native=work/"native"
    native.mkdir(exist_ok=True)
    fixture="portable-varied-hdr-native.dsculpt"
    shutil.copyfile(stream/"full-resolution-fixture"/fixture,native/fixture)
    case=work/registry[0]
    run([case,"--dense-hdr-editable",native],"dense-editable-hdr.log")
    fallback=work/"legacy"
    fallback.mkdir(exist_ok=True)
    shutil.copyfile(shared/"build/native-writable-first-key-2048/converted-2048.dsculpt",fallback/"converted-2048.dsculpt")
    run([case,"--dense-editable-export",fallback],"dense-editable-ldr.log")
    completed=[registry[0]]
    for name in registry[1:4]:
        run([work/name,work/(name+"-output")],name+".log")
        completed.append(name)
    run([work/"preset",native/fixture,work/"presets"],"presets.log")
    completed.append("preset")
    record(phase="complete",exit=0,terminal=True,tests=completed)
except BaseException as error:
    record(phase="failed",exit=1,terminal=True,error=repr(error))
    raise
