// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "sculpt-surface-chunks.hpp"
#include <algorithm>
#include <memory>
#include <optional>
#include <stdexcept>
#include <utility>
namespace dome::detail {
inline size_t sculpt_index_sum(size_t a,size_t b) {
  if(b>SIZE_MAX-a)throw std::length_error("Sculpt index accounting overflow");
  return a+b;
}
// Persistent AVL directory. Updates clone only the search/rotation path; a
// complete next manifest does not copy all previous tile/edge metadata. There
// is no parent pointer or global cache retaining obsolete manifests.
template<class K,class V,class Traits> struct PersistentSculptIndex {
  struct Node;
  using Ptr = std::shared_ptr<const Node>;
  struct Node {
    K key;
    V value;
    Ptr left,right;
    unsigned height;
    size_t count,payload_bytes;
    SculptChunkBounds bounds;
    Node(K k,V v,Ptr a,Ptr b) : key(std::move(k)),value(std::move(v)),
        left(std::move(a)),right(std::move(b)),
        height(1+std::max(h(left),h(right))),count(sculpt_index_sum(1,sculpt_index_sum(n(left),n(right)))),
        payload_bytes(sculpt_index_sum(Traits::bytes(value),sculpt_index_sum(left?left->payload_bytes:0,right?right->payload_bytes:0))),
        bounds(Traits::bounds(value)) {
      if(left)bounds.include(left->bounds);
      if(right)bounds.include(right->bounds);
    }
  };
  Ptr root;
  static unsigned h(const Ptr &p) { return p?p->height:0; }
  static size_t n(const Ptr &p) { return p?p->count:0; }
  static Ptr node(const K &k,const V &v,Ptr a,Ptr b,auto &w) {
    w.tick();
    // Requested node/control-block storage plus a conservative allocation
    // allowance. This is an owning working budget, not an RSS measurement.
    if constexpr(requires {w.template node_allocator<Node>(sizeof(Node)+128);}) {
      // The geometry working owner tracks the actual shared allocation's
      // lifetime. Intermediate AVL paths can die between successive edits.
      return std::allocate_shared<const Node>(
          w.template node_allocator<Node>(sizeof(Node)+128),k,v,std::move(a),std::move(b));
    } else {
      w.charge(sizeof(Node)+128);
      return std::make_shared<const Node>(k,v,std::move(a),std::move(b));
    }
  }
  static Ptr balanced(const K &k,const V &v,Ptr a,Ptr b,auto &w) {
    if(h(a)>h(b)+1) {
      if(h(a->left)>=h(a->right))
        return node(a->key,a->value,a->left,node(k,v,a->right,b,w),w);
      auto c=a->right;
      return node(c->key,c->value,node(a->key,a->value,a->left,c->left,w),
                  node(k,v,c->right,b,w),w);
    }
    if(h(b)>h(a)+1) {
      if(h(b->right)>=h(b->left))
        return node(b->key,b->value,node(k,v,a,b->left,w),b->right,w);
      auto c=b->left;
      return node(c->key,c->value,node(k,v,a,c->left,w),
                  node(b->key,b->value,c->right,b->right,w),w);
    }
    return node(k,v,std::move(a),std::move(b),w);
  }
  static Ptr put(Ptr p,const K &k,const V &v,auto &w) {
    w.tick();
    if(!p)return node(k,v,{},{},w);
    if(k<p->key)return balanced(p->key,p->value,put(p->left,k,v,w),p->right,w);
    if(p->key<k)return balanced(p->key,p->value,p->left,put(p->right,k,v,w),w);
    return node(k,v,p->left,p->right,w);
  }
  static Ptr remove(Ptr p,const K &k,auto &w) {
    w.tick();
    if(!p)return {};
    if(k<p->key)return balanced(p->key,p->value,remove(p->left,k,w),p->right,w);
    if(p->key<k)return balanced(p->key,p->value,p->left,remove(p->right,k,w),w);
    if(!p->left)return p->right;
    if(!p->right)return p->left;
    auto next=p->right.get();while(next->left) { w.tick(); next=next->left.get(); }
    return balanced(next->key,next->value,p->left,remove(p->right,next->key,w),w);
  }
  const V *find(const K &k) const {
    auto p=root.get();
    while(p) { if(k<p->key)p=p->left.get();else if(p->key<k)p=p->right.get();else return &p->value; }
    return nullptr;
  }
  // The actual immutable node owner, rather than value equality, is the
  // authority for sharing a complete subtree's retained storage.
  const Ptr *node_owner(const K &k) const {
    const Ptr *p=&root;
    while(*p) {
      if(k<(*p)->key)p=&(*p)->left;
      else if((*p)->key<k)p=&(*p)->right;
      else return p;
    }
    return nullptr;
  }
  void put(const K &k,const V &v,auto &w) { root=put(root,k,v,w); }
  void erase(const K &k,auto &w) { root=remove(root,k,w); }
  // Cold construction is not a sequence of persistent edits. Building a new
  // balanced tree directly from strict sorted keys allocates one final node
  // per key, rather than repeatedly cloning then discarding insertion paths.
  // The old root stays owned until the complete candidate succeeds. Callers
  // must account their input/old owner and the sorted input array separately.
  template<class Next> static Ptr sorted_tree(size_t count,Next &next,auto &w) {
    if(!count)return {};
    auto left=sorted_tree(count/2,next,w);
    auto entry=next();
    auto right=sorted_tree(count-count/2-1,next,w);
    return node(entry.first,entry.second,std::move(left),std::move(right),w);
  }
  template<class Iterator> void assign_sorted(Iterator first,Iterator last,auto &w) {
    size_t count=0;
    for(auto i=first;i!=last;++i){w.tick();if(count==SIZE_MAX)throw std::length_error("Sculpt sorted index size overflow");++count;}
    auto cursor=first;std::optional<K> previous;
    auto next=[&]() -> std::pair<K,V> {
      w.tick();if(cursor==last)throw std::logic_error("Sculpt sorted index input ended early");
      auto entry=*cursor++;
      if(previous&&!(*previous<entry.first))throw std::invalid_argument("Sculpt sorted index keys are not strictly increasing");
      previous=entry.first;return {entry.first,entry.second};
    };
    auto candidate=sorted_tree(count,next,w);
    if(cursor!=last)throw std::logic_error("Sculpt sorted index input changed during construction");
    root=std::move(candidate);
  }
  template<class F> static void visit(const Ptr &p,F &fn,auto &w) {
    if(!p)return;
    visit(p->left,fn,w);w.tick();fn(p->key,p->value);visit(p->right,fn,w);
  }
  template<class F> void visit(F fn,auto &w) const { visit(root,fn,w); }
};
} // namespace dome::detail
