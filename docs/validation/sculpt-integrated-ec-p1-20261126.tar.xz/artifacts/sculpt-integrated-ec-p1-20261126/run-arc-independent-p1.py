import pathlib,json,os,fcntl,subprocess,time,hashlib,signal,re,resource,struct
B=pathlib.Path(__file__).resolve().parent;D=B/'arc-independent-p1-v1';D.mkdir()
exe=B.parent/'production-sculpt-index-integration-release-20261126'/'dome-sculpt-sculpt-sustained';deadline=5400;rsslimit=5*1024**3
status={'production_source':'ec578e561c99ec681e9db57f657c0823526b0151','fixture_source':'ec578e561c99ec681e9db57f657c0823526b0151','terminal':False,'started':time.time(),'command':[str(exe),'--output',str(D/'workflow'),'--device','arc','--tier','production','--objects','4','--voxel','.0125','--independent'],'timeout_seconds':deadline,'rss_limit_bytes':rsslimit,'AS_cap':None,'output_limit_bytes':2*1024**3,'scope':'Original full sustained independent Arc P1: four production .0125m independently authored objects;900strokes360masks6000stereo/360held pairs across3repetitions; no HMD pacing or compute-acceleration claim'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(): (D/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def proc(pid):
 try:
  z=(pathlib.Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'ppid':int(z[1]),'pgrp':int(z[2]),'start':int(z[19]),'RSS':int(z[21])*os.sysconf('SC_PAGE_SIZE'),'state':z[0]}
 except (FileNotFoundError,ProcessLookupError):return None
save();fd=os.open('/tmp/dome-sculpt-arc-device.lock',os.O_RDWR);child=None;known={}
try:
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(fd);status['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino,'before_ldd_and_product':True};save()
 pins=json.loads((B/'runtime-before-input-pins.json').read_text());drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift,drift
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072','EGL_PLATFORM':'surfaceless','DRI_PRIME':'pci-0000_03_00_0!','MESA_LOADER_DRIVER_OVERRIDE':'iris','__EGL_VENDOR_LIBRARY_FILENAMES':'/usr/share/glvnd/egl_vendor.d/50_mesa.json','MESA_SHADER_CACHE_DISABLE':'true'})
 env.pop('LIBGL_ALWAYS_SOFTWARE',None)
 r=subprocess.run(['/usr/bin/ldd',str(exe)],env=env,capture_output=True,text=True,timeout=60);(D/'ldd.txt').write_text(r.stdout+r.stderr);assert r.returncode==0 and 'not found' not in r.stdout
 providers=set()
 for line in r.stdout.splitlines():
  m=re.search(r'(?:=>\s+)?(/\S+)',line)
  if m:providers.add(str(pathlib.Path(m.group(1)).resolve()))
 for seed in ['/usr/lib64/dri/iris_dri.so','/usr/lib64/libEGL_mesa.so.0','/usr/lib64/libGLX_mesa.so.0']:
  q=pathlib.Path(seed);assert q.is_file(),seed;providers.add(str(q.resolve()))
  z=subprocess.run(['/usr/bin/ldd',seed],env=env,capture_output=True,text=True,timeout=60);(D/(q.name+'.ldd')).write_text(z.stdout+z.stderr);assert z.returncode==0 and 'not found' not in z.stdout
  for line in z.stdout.splitlines():
   m=re.search(r'(?:=>\s+)?(/\S+)',line)
   if m:providers.add(str(pathlib.Path(m.group(1)).resolve()))
 providers.add('/usr/share/glvnd/egl_vendor.d/50_mesa.json')
 providers={p:sha(p) for p in sorted(providers)};(D/'provider-before-pins.json').write_text(json.dumps(providers,indent=2)+'\n');status['executable_sha256']=sha(exe);status['providers']=len(providers);save()
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072','EGL_PLATFORM':'surfaceless','DRI_PRIME':'pci-0000_03_00_0!','MESA_LOADER_DRIVER_OVERRIDE':'iris','__EGL_VENDOR_LIBRARY_FILENAMES':'/usr/share/glvnd/egl_vendor.d/50_mesa.json','MESA_SHADER_CACHE_DISABLE':'true'})
 env.pop('LIBGL_ALWAYS_SOFTWARE',None)
 def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 with (D/'product.log').open('w') as out:
  child=subprocess.Popen(status['command'],cwd=B,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits)
  status['pid']=child.pid;first=proc(child.pid);assert first;status['process_identity']=first;start=time.monotonic();peak=0;samples=0;mapped=False;output_bytes=0;next_output=0
  while child.poll() is None:
   own=[]
   for q in pathlib.Path('/proc').iterdir():
    if q.name.isdigit():
     a=proc(int(q.name))
     if a and a['pgrp']==child.pid:own.append(a);known[(a['pid'],a['start'])]=a
   peak=max(peak,sum(a['RSS'] for a in own));samples+=1
   if not mapped:
    try:
     actual=os.readlink('/proc/'+str(child.pid)+'/exe');maps=pathlib.Path('/proc/'+str(child.pid)+'/maps').read_text()
     if actual==str(exe) and maps:
      (D/'actual-maps.txt').write_text(maps);status['actual_executable_path']=actual;mapped=True
    except (FileNotFoundError,ProcessLookupError):pass
   elapsed=time.monotonic()-start
   if elapsed>=next_output:
    output_bytes=sum(p.stat().st_size for p in D.rglob('*') if p.is_file());next_output=elapsed+1
   if elapsed>deadline or peak>rsslimit or output_bytes>2*1024**3:
    status['limit_failure']='deadline' if elapsed>deadline else ('RSS' if peak>rsslimit else 'output bytes');w=proc(child.pid)
    if w and w['start']==first['start']:os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
    break
   time.sleep(.05)
  status.update({'product_exit':child.wait(),'seconds':time.monotonic()-start,'peak_owned_RSS_bytes':peak,'samples':samples,'mapped_witness':mapped,'observed_output_bytes':output_bytes})
 survivors=[x for (pid,start),x in known.items() if (a:=proc(pid)) and a['start']==start and a['state']!='Z'];status['owned_survivors']=survivors;assert not survivors
 status['input_drift']=[p for p,h in pins.items() if sha(p)!=h];status['provider_drift']=[p for p,h in providers.items() if sha(p)!=h];assert not status['input_drift'] and not status['provider_drift']
 log=(D/'product.log').read_text();assert status['product_exit']==0 and mapped and 'production-workload-pass' in log and 'FAIL ' not in log
 report=json.loads((D/'workflow/result.json').read_text());assert report['status']=='production-workload-pass' and report['complete_planned_counts'] and len(report['repetitions'])==3
 expected={'tier':'production','device':'arc','inventory_only':False,'smoke':False,'independent_authored_fields':True,'objects':4,'voxel':struct.unpack('f',struct.pack('f',.0125))[0],'strokes':300,'masks':120,'pairs':2000,'held_pairs':120,'repetitions':3,'width':768,'height':768}
 for k,v in expected.items():assert report['options'][k]==v,(k,report['options'][k])
 assert report['device_witness_initial']['authenticated'] and report['device_witness_final']['authenticated']
 status['completed_repetitions']=3;status['actual_row_counts']={}
 for run in report['repetitions']:
  assert run['size']['visible_triangles']>1000000 and run['gpu_timers']['distribution_qualified'] and all(run['history'].values())
  for row in run['rows']:status['actual_row_counts'][row['kind']]=status['actual_row_counts'].get(row['kind'],0)+1
 for kind,expected_count in {'stroke':900,'mask':360,'view_pair':6000,'held_pair':360}.items():assert status['actual_row_counts'][kind]==expected_count,(kind,status['actual_row_counts'])
 status['device_witness_initial']=report['device_witness_initial'];status['device_witness_final']=report['device_witness_final']
 status.update({'exit':0,'state':'passed'})
except BaseException as e:status.update({'exit':1,'state':'failed','error':repr(e)})
finally:
 status['terminal']=True;status['finished']=time.time()
 if 'lease' in status:status['lease']['released']=time.time()
 save();os.close(fd)
raise SystemExit(status['exit'])
