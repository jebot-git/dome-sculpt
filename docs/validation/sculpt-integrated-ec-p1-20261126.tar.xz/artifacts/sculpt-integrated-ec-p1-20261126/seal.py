from pathlib import Path
import json,tarfile,hashlib,io,shlex
B=Path(__file__).resolve().parent;ROOT=B.parents[1];C=B.parent/'production-sculpt-index-integration-release-20261126';SRC=B.parent/'production-sculpt-index-integration-source-20261126';DOCSRC=B.parent/'sculpt-index-lifetimes-source-20261126';V=DOCSRC/'docs/validation';arc=B/'arc-independent-p1-v1';state=json.loads((arc/'status.json').read_text());assert state['terminal'] and state['exit']==0 and state['completed_repetitions']==3;files={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):p=Path(p).resolve();assert p.is_file(),p;files[str(p.relative_to(ROOT))]=p
for p in B.iterdir():
 if p.is_file():add(p)
for p in arc.iterdir():
 if p.is_file():add(p)
for p in (arc/'workflow').iterdir():
 if p.is_file():add(p)
for name in ['build-plan.json','build-status.json','build.py','prepare.py','build.journal.txt']:
 p=C/name
 if p.exists():add(p)
plan=json.loads((C/'build-plan.json').read_text());assert plan['source']==state['production_source']=='ec578e561c99ec681e9db57f657c0823526b0151'
for c in plan['compiler']:
 md=Path(c['argv'][c['argv'].index('-MF')+1]);add(md)
 for p in shlex.split(md.read_text().replace('\\\n',' ').split(':',1)[1].split('\n')[0]):
  p=Path(p).resolve()
  if p.is_relative_to(ROOT):add(p)
for p in C.glob('*.link.d'):add(p)
for name in ['src/sculpt-chunk-index.hpp','src/sculpt-surface-chunks.cpp','tests/sculpt-sustained.cpp','tests/sculpt-independent-fixture.hpp']:add(SRC/name)
projects=[];unique={}
for p in (arc/'workflow').rglob('*.dsculpt'):
 h=sha(p);assert h=='db9c506daedc1b13992838200b95e9e4569e98155bce306142803aca6cb8edb8';projects.append({'actual_path':str(p),'sha256':h,'bytes':p.stat().st_size});unique.setdefault(h,p)
for h,p in unique.items():files['native-projects/'+h+'.dsculpt']=p
q={'source':state['production_source'],'scope':'Original full sustained independent Arc P1 against exact parent-qualified integrated ec ELF. Distinct from8c component result. NativeCPUbrush/meshing and genuineoffscreenOpenGL; no HMDpacing,computeacceleration,defaultallocatorP1 or7acompactqualification implied.','runtime':state,'build_binding':json.loads((B/'integration-binding.json').read_text()),'actual_environment':json.loads((B/'launch-environment-witness.json').read_text()),'fixed_inputs':json.loads((B/'fixed-input-equality.json').read_text()),'native_projects':projects,'prior_component_proof':{'commit':'9cc18990','archive_sha256':'b649ca2be7dd656d1d1bce902594abd08619cdd6414df9c88e9cc98e83226b62'},'authorities':[]}
report=json.loads((arc/'workflow/result.json').read_text());rows=[json.loads(z) for z in (arc/'workflow/raw-samples.ndjson').read_text().splitlines()]
q['measurement_scope']={k:report[k] for k in ['scope','timing_scope','inclusive_stage_times_must_not_be_summed','allocations_scope','natural_process_scope','raw_rows','backend','options','remaining_costs']}
q['measurement_scope']['limits']='Owned RSS is separately measured by the process observer; optional C++ requested-byte counters are not RSS. This is the original matched allocator profile, not a default-allocator P1 run.'
q['measurement_scope']['comparison']='No controlled performance comparison with component8c or range-search0cdd is claimed.'
q['measurement_scope']['observer_boundaries']='Independent whole-mesher/corner/normal/scalar/frame-mode checkpoints and raw-row writes preserve their explicit excluded observer times; measured draws have no pixel readback or glFinish.'
q['actual_raw_rows']=len(rows);assert len(rows)==7690
q['actual_kind_counts']={k:sum(r['kind']==k for r in rows) for k in sorted({r['kind'] for r in rows})}
q['actual_initial_size']=report['initial_size'];q['checkpoints']=[r for r in rows if r['kind']=='independent_checkpoint'];assert len(q['checkpoints'])==42
q['completed_histories']=[r for r in rows if r['kind']=='exact_history_and_stale_generation'];assert len(q['completed_histories'])==3
q['async_GPU_timers']=[{'repetition':r['index'],**r['gpu_timers']} for r in report['repetitions']];assert all(r['distribution_qualified'] for r in q['async_GPU_timers'])
for name,p in sorted(files.items()):q['authorities'].append({'name':name,'actual_path':str(p),'sha256':sha(p),'size':p.stat().st_size})
payload=(json.dumps(q,indent=2)+'\n').encode();dest=V/'sculpt-integrated-ec-p1-20261126.tar.xz';assert not dest.exists()
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('index.json');info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
with tarfile.open(dest,'r:xz') as tar:
 for a in q['authorities']:assert hashlib.sha256(tar.extractfile(a['name']).read()).hexdigest()==a['sha256'];assert sha(a['actual_path'])==a['sha256']
q['archive']={'name':dest.name,'size':dest.stat().st_size,'sha256':sha(dest),'members':len(files)+1};(V/'sculpt-integrated-ec-p1-20261126.json').write_text(json.dumps(q,indent=2)+'\n');print(q['archive'])
