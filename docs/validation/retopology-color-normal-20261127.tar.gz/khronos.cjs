const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
const names = ['plain','affine','first'].flatMap(f => ['standard','editable'].map(mode =>
  `retopology-prepared-color-normal-${f}/color-${mode}.glb`));
(async () => {
  const results = [];
  for (const file of names) {
    const bytes=fs.readFileSync(path.join(__dirname,'release',file));
    const json=JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)).toString('utf8'));
    const resolved=json.meshes.flatMap(mesh=>mesh.primitives).some(primitive=>{
      const attributes=primitive.attributes;
      const material=json.materials[primitive.material];
      return attributes.TANGENT!==undefined && attributes.COLOR_0===undefined &&
        material.normalTexture && material.pbrMetallicRoughness.baseColorTexture;
    });
    assert.ok(resolved,file);
    const report=await validator.validateBytes(bytes, {uri:file,maxIssues:10000});
    const issues=report.issues;
    assert.equal(issues.numErrors,0,file);
    results.push({file,resolved,report});
    console.log(file,issues.numErrors,'errors',issues.numWarnings,'warnings',issues.messages.filter(e=>e.severity===1).map(e=>e.code));
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results},null,2)+'\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
