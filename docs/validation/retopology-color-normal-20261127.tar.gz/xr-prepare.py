from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

work = Path(__file__).resolve().parent
build = work / "release"
mode = sys.argv[1]
case = sys.argv[2]
slot = work / ("xr-" + mode + "-" + case)
slot.mkdir(exist_ok=True)
data = []
runtime_library = (work / "framed-runtime" if case == "affine" else build) / "libdome-sculpt-test-runtime.so"
for name in ("color-after", "color-common-control", "color-normal-flat-control"):
    output = slot / name
    output.mkdir(exist_ok=True)
    project = build / ("retopology-prepared-color-normal-" + case) / f"{name}.dsculpt"
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="dome-retained-xr-") as temp:
        private = Path(temp)
        runtime = private / "runtime.json"
        runtime.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{
            "library_path":str(runtime_library)}}))
        metadata = output / "report.json"
        saved = output / "closed.dsculpt"
        env = dict(os.environ, HOME=temp, XR_RUNTIME_JSON=str(runtime),
                   DOME_XR_FIXTURE_PBR_VIEW="1", DOME_XR_FIXTURE_REPORT=str(metadata))
        for part in ("config", "state", "data", "cache", "runtime"):
            local = private / part
            local.mkdir(mode=0o700)
            env["XDG_" + part.upper() + ("_DIR" if part=="runtime" else "_HOME")] = str(local)
        with (output / "app.log").open("w") as log:
            subprocess.run([build/"dome-sculpt","--xr","--open",project,"--frames","7","--save",saved],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=45)
        info = json.loads(metadata.read_text())
        assert info["action_syncs"] == 7 and info["stereo_submissions"] == 6
        assert info["acquires"] == info["image_waits"] == info["releases"] == 12
        assert ("Arc(tm) A770" if mode == "arc" else "llvmpipe") in info["gl_renderer"], info["gl_renderer"]
        assert all(info["pbr_preview_images"]["6"][str(eye)]["opaque"] > 0 for eye in (0,1))
        assert project.read_bytes() == saved.read_bytes()
        data.append(info)
def rgb(path):
    return path.read_bytes().split(b"\n", 3)[3]
different = {}
for control in ("color-common-control", "color-normal-flat-control"):
    difference = []
    for eye in (0, 1):
        main, varied = [rgb(slot/name/f"report.json.pbr-6-{eye}.ppm")
                        for name in ("color-after", control)]
        assert len(main) == len(varied)
        count = sum(a != b for a, b in zip(main, varied))
        assert count > 100, (control, eye, count)
        difference.append(count)
    different[control] = difference
report = {"runtime":"synthetic OpenXR", "profiles":data,
          "differing_rgb_components_per_eye":different,
          "horizontal_view_offset_metres":.52 if case == "affine" else 0.,
          "exact_ordered_close":True}
(slot / "compare.json").write_text(json.dumps(report, indent=2)+"\n")
print(f"PASS {mode} independent resolved PBR and normal Bake controls in stereo with exact close", different)
