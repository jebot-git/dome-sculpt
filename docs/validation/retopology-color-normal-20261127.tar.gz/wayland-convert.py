#!/usr/bin/env python3
"""Private native Wayland/DomeD + real Unix stream; no physical-device claim."""
import asyncio,json,os,platform,re,shutil,signal,socket,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from dbus_next.aio import MessageBus
from dbus_next import Variant
from Xlib import X,XK,display
from Xlib.ext import xtest
from PIL import Image,ImageChops
signal.pthread_sigmask(signal.SIG_SETMASK,[])
if os.environ.get('DOME_PROJECTION_WL_BUS')!='1':os.execvpe('dbus-run-session',['dbus-run-session','--',sys.executable,*sys.argv],{**os.environ,'DOME_PROJECTION_WL_BUS':'1'})
root=Path(__file__).resolve().parents[1];build=Path(os.environ.get('DOME_SCULPT_TEST_BUILD',root/'build'));compositor=Path(os.environ['DOME_COMPOSITOR']);out=Path(os.environ['DOME_CAGE_WL_OUT']);out.mkdir(parents=True,exist_ok=True);checks=[];processes=[]
texture_set=os.environ.get('DOME_CAGE_TEXTURE_SET')=='1'
def check(ok,label):
 checks.append({'passed':bool(ok),'check':label});(out/'report.json').write_text(json.dumps({'checks':checks,'complete':False},indent=2)+'\n');print(('PASS ' if ok else 'FAIL ')+label,flush=True);assert ok,label
async def wait(fn,seconds=60):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   value=fn()
   if value:return value
  except (OSError,ValueError,KeyError,StopIteration):pass
  await asyncio.sleep(.08)
 raise TimeoutError('Private DomeD projection condition timed out')
def start(args,name,env,**kw):
 log=(out/(name+'.log')).open('w');p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,**kw);processes.append(p);return p
async def main():
 with tempfile.TemporaryDirectory(prefix='dome-cage-wl-',ignore_cleanup_errors=True) as home:
  rd,wr=os.pipe();start(['Xvfb','-displayfd',str(wr),'-screen','0','1600x1000x24','-nolisten','tcp','-noreset'],'xvfb',os.environ.copy(),pass_fds=(wr,));os.close(wr)
  with os.fdopen(rd) as pipe:screen=':'+pipe.readline().strip()
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  icd=next(p for p in (Path('/usr/share/vulkan/icd.d/lvp_icd.json'),Path('/usr/share/vulkan/icd.d/lvp_icd.'+platform.machine()+'.json')) if p.is_file())
  config=Path(home,'config/dome');config.mkdir(parents=True);(config/'keyboard.json').write_text(json.dumps({'ime':False,'layout':'us'}))
  env={**os.environ,'HOME':home,'DISPLAY':screen,'XDG_CONFIG_HOME':home+'/config','XDG_DATA_HOME':home+'/data','XDG_CACHE_HOME':home+'/cache','XDG_RUNTIME_DIR':home,'XDG_CURRENT_DESKTOP':'Dome','XDG_SESSION_TYPE':'wayland','VK_DRIVER_FILES':str(icd),'LIBGL_ALWAYS_SOFTWARE':'1','GIO_USE_VFS':'local','LIBGL_KOPPER_DISABLE':'true','LP_NUM_THREADS':'2','DOME_RENDER_CAPTURE':str(out/'render.ppm'),'DOME_LOGIN_SESSION':'0','DOME_PREVIEW_PORT':str(port),'DOME_RENDERER':'vulkan','DOME_START_XR':'0','DOME_START_TRAY':'0','DOME_START_IME':'0','DOME_SESSION_RESTORE':'0','DBUS_SYSTEM_BUS_ADDRESS':'unix:path=/nonexistent/viewport-test-bus','XR_RUNTIME_JSON':'/nonexistent/viewport-no-headset.json','RUST_LOG':'warn','SPNAV_SOCKET':home+'/spnav.sock'}
  for k in ('WAYLAND_DISPLAY','WAYLAND_SOCKET','FLTK_BACKEND','QT_QPA_PLATFORM'):env.pop(k,None)
  host_process=start([str(compositor),'--backend','nested'],'compositor',env);base=f'http://127.0.0.1:{port}'
  def scene():return json.load(urllib.request.urlopen(base+'/api/state',timeout=2))['scene']
  def action(data):urllib.request.urlopen(urllib.request.Request(base+'/api/action',data=json.dumps(data).encode(),headers={'Content-Type':'application/json'}),timeout=2).close()
  await wait(lambda:scene()['source']=='wayland');wayland=re.search(r'Dome Wayland socket: (\S+)',(out/'compositor.log').read_text())[1]

  project=Path(home,'accessory.dsculpt')
  shutil.copyfile(os.environ['DOME_ACCESSORY_PROJECT'],project)
  before=project.read_bytes()
  app=start([os.environ['DOME_CAGE_APP'],str(project)],'client',
      {**env,'WAYLAND_DISPLAY':wayland,'FLTK_BACKEND':'wayland'},cwd=home)
  def named(title):return next((win for win in scene()['windows'] if title in win['title']),None)
  win=await wait(lambda:named('accessory.dsculpt'))
  check(win['app_id']=='org.domed.Sculpt','Native retopology editor publishes the canonical Dome Sculpt Wayland identity')
  d=display.Display(screen)
  host=await wait(lambda:next((win for win in d.screen().root.query_tree().children if 'Dome' in str(win.get_wm_name() or '')),None))
  host.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync()
  action({'op':'focus','id':win['id']})
  bus=await MessageBus().connect()
  db=bus.get_proxy_object('org.freedesktop.DBus','/org/freedesktop/DBus',await bus.introspect('org.freedesktop.DBus','/org/freedesktop/DBus')).get_interface('org.freedesktop.DBus')
  menu=None
  label='Convert to portable normals'
  def entries(layout):
   result={}
   def walk(node):
    ident,props,children=node
    values={key:value.value for key,value in props.items()}
    result[values.get('label','').replace('_','')]=(ident,values)
    for child in children:walk(child.value)
   walk(layout[1]);return result
  end=time.monotonic()+45
  while menu is None and time.monotonic()<end:
   for service in await db.call_list_names():
    if not service.startswith(':'):continue
    try:
     endpoint='/org/de_xr/FLTK/Menu1'
     node=bus.get_proxy_object(service,endpoint,await asyncio.wait_for(bus.introspect(service,endpoint),1)).get_interface('com.canonical.dbusmenu')
     commands=entries(await node.call_get_layout(0,-1,[]))
     if label in commands and commands[label][1].get('enabled',True):
      menu=node;break
    except Exception:pass
   if menu is None:await asyncio.sleep(.15)
  check(menu is not None,'The Wayland universal menu enables portable normal conversion for a prepared-color Bake')
  async def when(predicate):
   for _ in range(300):
    current=entries(await menu.call_get_layout(0,-1,[]))
    if predicate(current):return current
    await asyncio.sleep(.05)
   raise TimeoutError("Retopology universal menu did not reach the expected state")
  def enabled(commands,item):
   return commands[item][1].get("enabled",True)
  await menu.call_event(commands[label][0],"clicked",Variant("i",0),0)
  commands=await when(lambda m:not enabled(m,label) and enabled(m,"Start patch"))
  check(not enabled(commands,label),'After conversion the same historical action is disabled')
  stamp=project.stat().st_mtime_ns
  await menu.call_event(commands['Save'][0],'clicked',Variant('i',0),0)
  await wait(lambda:project.stat().st_mtime_ns!=stamp)
  check(project.read_bytes()==Path(os.environ['DOME_CONVERTED_REFERENCE']).read_bytes(),
        'Conversion and universal Save match the native worker reference byte for byte')
  close=entries(await menu.call_get_layout(0,-1,[]))['Close Window'][0]
  await menu.call_event(close,'clicked',Variant('i',0),0)
  await wait(lambda:app.poll() is not None)
  check(app.returncode==0,'Native client releases the compositor and export worker on close')
  (out/'report.json').write_text(json.dumps({'checks':checks,'complete':True},indent=2)+'\n')
  d.close();bus.disconnect()
try:asyncio.run(main())
finally:
 for process in reversed(processes):
  if process.poll() is None:process.terminate()
 for process in reversed(processes):
  try:process.wait(timeout=5)
  except subprocess.TimeoutExpired:process.kill();process.wait()
