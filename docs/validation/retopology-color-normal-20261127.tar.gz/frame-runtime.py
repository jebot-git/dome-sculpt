from pathlib import Path
import shlex
import subprocess

root = Path(__file__).resolve().parent
repo = root.parent.parent
source = repo / 'tests/xr_runtime.cpp'
build = root / 'release'
bin_path = root / 'framed-runtime'
bin_path.mkdir(exist_ok=True)
position = source.read_text()
anchor = '    p[i].fov = {-.6f, .6f, .6f, -.6f};'
assert position.count(anchor) == 1
fixture = str(bin_path/'xr_runtime.cpp')
new_object = str(bin_path/'xr_runtime.o')
expected = 'v.pose.position.x - ((eye ? .032f : -.032f) +'
assert position.count(expected) == 1
position=position.replace(expected,expected+' (pbr_preview_fixture() ? .52f : 0.f) +')
Path(fixture).write_text(position.replace(anchor,
    '    if (pbr_preview_fixture()) p[i].pose.position.x += .52f;\n'+anchor))
commands = subprocess.check_output(['ninja','-C',str(build),'-t','commands','dome-sculpt-test-runtime'],text=True).splitlines()
cc, link = map(shlex.split, commands[-2:])
assert cc[-1] == str(source) and link[:2] == [':','&&'] and link[-2:] == ['&&',':']
object_path = cc[cc.index('-o')+1]
cc[-1] = fixture
for flag, path in [('-o',new_object),('-MF',new_object+'.d'),('-MT',new_object)]:
    cc[cc.index(flag)+1]=path
cc.extend(['-iquote',str(source.parent)])
subprocess.run(cc,cwd=build,check=True)
link = [new_object if arg==object_path else arg for arg in link[2:-2] if not arg.startswith('-Wl,--dependency-file=')]
link[link.index('-o')+1] = str(bin_path/'libdome-sculpt-test-runtime.so')
subprocess.run(link,cwd=build,check=True)
