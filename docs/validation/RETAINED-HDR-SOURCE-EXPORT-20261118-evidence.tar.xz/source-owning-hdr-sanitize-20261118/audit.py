from pathlib import Path
import json,hashlib,subprocess,shlex,collections
out=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
state=json.load(open(out/'build-status.json'));plan=json.load(open(out/'build-plan.json'))
assert state['state']=='terminal' and state['exit']==0 and state['input_drift']==[]
assert not [p for p,h in plan['source_input_pins'].items() if not Path(p).is_file() or sha(p)!=h]
raw=subprocess.check_output(['/usr/bin/ninja','-C',str(out),'-t','commands',*plan['targets']],text=True)
(out/'actual-target-commands.txt').write_text(raw)
commands=[]
for line in raw.splitlines():
 argv=shlex.split(line)
 if '-c' in argv and '-o' in argv:commands.append({'object':argv[argv.index('-o')+1],'source':argv[argv.index('-c')+1],'raw_actual_command':line,'argv':argv})
expected={x['object']:x for x in commands};assert len(expected)==len(commands)
cc=json.load(open(out/'compile_commands.json'));cc={str(Path(x['output']).resolve()):x for x in cc}
log=(out/'build.log').read_text();owners=[];dependencies={};incidences=0;missing_rsp=[];observed_rsp=[]
def rule(path):
 result=''
 for line in path.read_text().splitlines():
  more=line.endswith('\\');result+=line[:-1]+' ' if more else line
  if not more:break
 a,b=result.split(':',1);return shlex.split(a),shlex.split(b)
for rel,entry in expected.items():
 obj=out/rel;md=out/(rel+'.d');assert obj.is_file() and md.is_file();targets,inputs=rule(md);assert rel in targets
 assert inputs and Path(inputs[0]).resolve()==Path(entry['source']).resolve()
 actualcc=cc[str(obj.resolve())];assert Path(actualcc['directory']).resolve()==out.resolve() and Path(actualcc['file']).resolve()==Path(entry['source']).resolve()
 assert entry['raw_actual_command'] in log
 expanded=shlex.split(actualcc['command']);assert '-O1' in expanded and '-DNDEBUG' in expanded and '-g0' in expanded and '-fsanitize=address,undefined' in expanded and '-fno-omit-frame-pointer' in expanded
 rsp=[]
 for token in entry['argv']:
  if not token.startswith('@'):continue
  path=out/'observed-actual-rsp'/token[1:]
  if path.is_file():
   actual=shlex.split(path.read_text());assert actual==[x for x in expanded[1:expanded.index('-o')]],(rel,actual,expanded)
   rsp.append({'path':str(path),'sha256':sha(path),'actual_live_bytes_observed':True});observed_rsp.append(str(path))
  else:
   missing_rsp.append(token[1:]);rsp.append({'original_path':token[1:],'actual_live_bytes_observed':False,'profile_provenance':'pinned Ninja rule/definitions plus expanded compile_commands; missing bytes never synthesized'})
 for dep in inputs:
  p=Path(dep);p=p if p.is_absolute() else out/p;assert p.is_file();dependencies.setdefault(str(p),sha(p));incidences+=1
 owners.append({'object':rel,'sha256':sha(obj),'actual_compiler_MD':str(md.relative_to(out)),'MD_sha256':sha(md),'dependencies':len(inputs),'source':entry['source'],'actual_cwd':actualcc['directory'],'raw_actual_command':entry['raw_actual_command'],'pinned_expanded_compile_commands_row':actualcc,'response_files':rsp})
assert {str(p.relative_to(out))[:-2] for p in out.rglob('*.o.d')}==set(expected)
core=[x for x in owners if x['object'].startswith('CMakeFiles/dome-sculpt-core.dir/')];by={Path(x['object']).name:x for x in core};assert len(by)==len(core)
archive=out/'libdome-sculpt-core.a';members=subprocess.check_output(['/usr/bin/ar','t',str(archive)],text=True).splitlines();assert len(members)==len(core) and set(members)==set(by)
records=[]
for member in members:
 digest=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(archive),member])).hexdigest();assert digest==by[member]['sha256'];records.append({'member':member,'sha256':digest,'object':by[member]['object']})
links=[]
for target in plan['targets']:
 md=out/'CMakeFiles'/(target+'.dir')/'link.d';t,inputs=rule(md);assert target in t
 assert sha(out/target)==state['selected_outputs'][target]
 for dep in inputs:
  p=Path(dep);p=p if p.is_absolute() else out/p;assert p.is_file();links.append({'target':target,'path':str(p),'sha256':sha(p)})
for file,data in [('actual-MD-owners.json',owners),('actual-input-manifest.json',dependencies),('actual-core-members.json',records),('actual-link-inputs.json',links)]: (out/file).write_text(json.dumps(data,indent=2))
s={'profile':'all218 actual owners O1/g0 ASan+UBSan/frame pointers; existing O3 resample-test owners outside selected closure','state':'audit-passed','source':plan['source'],'owners':len(owners),'core_members':len(core),'dependency_incidences':incidences,'actual_dependency_paths':len(dependencies),'actual_link_inputs':len(links),'core_archive_sha256':sha(archive),'input_drift':[],'actual_rsp_observed_count':len(observed_rsp),'actual_rsp_missing_count':len(missing_rsp),'actual_rsp_missing':missing_rsp,'profile_provenance_for_missing_rsp':'Pinned compiler/tool/environment, Ninja response rule/definitions, expanded compile_commands and logged actual invocation; no synthesized actual bytes.','scope':plan['scope']};(out/'audit-status.json').write_text(json.dumps(s,indent=2));print(json.dumps(s,indent=2))
