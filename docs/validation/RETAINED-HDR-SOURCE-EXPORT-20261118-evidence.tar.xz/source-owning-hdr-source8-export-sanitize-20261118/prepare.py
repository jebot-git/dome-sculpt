from pathlib import Path
import json,subprocess,hashlib,shlex
out=Path(__file__).resolve().parent;base=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-sanitize-20261118');src=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-source8-export-20261118')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((base/'build-plan.json').read_text());audit=json.loads((base/'audit-status.json').read_text());status=json.loads((base/'build-status.json').read_text());assert audit['state']=='audit-passed'and status['exit']==0 and audit['core_archive_sha256']==sha(base/'libdome-sculpt-core.a')
oldsrc=Path(next(x.split('=',1)[1]for x in(base/'CMakeCache.txt').read_text().splitlines()if x.startswith('CMAKE_HOME_DIRECTORY:')))
pins=dict(old['source_input_pins']);pins[str(base/'audit-status.json')]=sha(base/'audit-status.json');pins[str(base/'build-status.json')]=sha(base/'build-status.json')
raw=subprocess.check_output(['/usr/bin/ninja','-t','compdb'],cwd=base);(out/'base-actual-compdb.json').write_bytes(raw);compdb=json.loads(raw);byoutput={str((base/x['output']).resolve()):x for x in compdb if x.get('output')}
for name in subprocess.check_output(['git','ls-files','-z'],cwd=src).decode().split('\0'):
 if name and(name=='CMakeLists.txt'or name.startswith(('src/','include/','tests/','cmake/','third_party/','assets/'))):
  p=src/name
  if p.is_file():pins[str(p)]=sha(p)
changed=[];unchanged=[];old_owners=[]
for md in sorted(base.rglob('*.o.d')):
 obj=Path(str(md)[:-2]);record=byoutput[str(obj.resolve())];argv=shlex.split(record['command']);assert '-fsanitize=address,undefined'in argv and '-fno-omit-frame-pointer'in argv and '-O1'in argv and '-g0'in argv
 text=md.read_text().replace('\\\n',' ');target,tail=text.split(':',1);assert(base/shlex.split(target)[0]).resolve()==obj.resolve();deps=[];differences=[];pairs=[]
 pins[str(obj)]=sha(obj);pins[str(md)]=sha(md)
 for name in shlex.split(tail):
  p=Path(name);p=(base/p).resolve()if not p.is_absolute()else p.resolve();deps.append(str(p));pins[str(p)]=sha(p)
  if p.is_relative_to(oldsrc):
   current=src/p.relative_to(oldsrc)
   if not current.is_file()or sha(current)!=sha(p):differences.append(str(current))
   else:pairs.append({'old':str(p),'current':str(current),'sha256':sha(p)})
 owner={'object':str(obj),'object_sha256':sha(obj),'depfile':str(md),'depfile_sha256':sha(md),'actual_command':record['command'],'argv':argv,'cwd':record['directory'],'actual_dependencies':deps};old_owners.append(owner)
 relative=obj.relative_to(base)
 if differences:
  item={'object':str(out/relative),'original_object':str(obj),'original_md':str(md),'original_command':record['command'],'argv':[x.replace(str(oldsrc),str(src))for x in argv],'cwd':str(out),'differences':differences};changed.append(item);(out/relative).parent.mkdir(parents=True,exist_ok=True)
 else:unchanged.append({**owner,'source_pairs':pairs})
assert len(old_owners)==218
new_targets=['dome-sculpt-source-owning-hdr-export-test','dome-sculpt-baked-emission-workflow-test']
for target in new_targets:
 relative=Path('CMakeFiles')/(target+'.dir')/'tests'/('source-owning-hdr-export.cpp.o'if target.endswith('hdr-export-test')else'baked-emission-workflow.cpp.o')
 source=src/'tests'/relative.name[:-2]
 if str((base/relative).resolve())in byoutput:
  record=byoutput[str((base/relative).resolve())];argv=shlex.split(record['command']);original_command=record['command']
 else:
  donor=next(x for x in old_owners if x['object'].endswith('/tests/source-owning-hdr-domain.cpp.o'));argv=donor['argv'];original_command=donor['actual_command'];argv=[x.replace('dome-sculpt-source-owning-hdr-domain-test',target).replace('source-owning-hdr-domain.cpp','source-owning-hdr-export.cpp')for x in argv]
 argv=[x.replace(str(oldsrc),str(src))for x in argv];assert str(source)in argv
 changed.append({'object':str(out/relative),'original_object':None,'original_md':None,'original_command':original_command,'argv':argv,'cwd':str(out),'differences':['new selected complete fixture TU']});(out/relative).parent.mkdir(parents=True,exist_ok=True)
archives=[]
for archive in sorted(base.glob('*.a')):
 record=byoutput[str(archive.resolve())];argv=shlex.split(record['command']);at=next(i for i,v in enumerate(argv)if Path(v).name=='ar');args=argv[at+3:];args=args[:args.index('&&')]if'&&'in args else args;members={Path(name).name:(base/name).resolve()for name in args};names=subprocess.check_output(['/usr/bin/ar','t',str(archive)]).decode().splitlines();assert set(names)==set(members)and len(names)==len(members);rows=[]
 for name in names:
  value=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(archive),name])).hexdigest();assert value==sha(members[name]);rows.append({'name':name,'sha256':value})
 pins[str(archive)]=sha(archive);archives.append({'path':str(archive),'sha256':sha(archive),'members':rows,'actual_command':record})
targets=['dome-sculpt-source-joint-writable-normal-bake-test','dome-sculpt-source-owning-hdr-domain-test',*new_targets];links=[]
for target in targets:
 if str(base/target)in byoutput:record=byoutput[str(base/target)];command=record['command']
 else:
  record=byoutput[str(base/'dome-sculpt-source-owning-hdr-domain-test')];command=record['command'].replace('dome-sculpt-source-owning-hdr-domain-test',target).replace('source-owning-hdr-domain.cpp','source-owning-hdr-export.cpp')
 argv=shlex.split(command)
 if argv[:2]==[':','&&']:argv=argv[2:]
 if argv[-2:]==['&&',':']:argv=argv[:-2]
 assert'&&'not in argv and'-fsanitize=address,undefined'in argv
 for i,value in enumerate(argv):
  if value.endswith('.o')and not Path(value).is_absolute():
   if not any(Path(c['object']).relative_to(out)==Path(value)for c in changed):argv[i]=str(base/value)
  if value.startswith('-Wl,--dependency-file='):(out/value.split('=',1)[1]).parent.mkdir(parents=True,exist_ok=True)
 links.append({'target':target,'argv':argv,'cwd':str(out),'original_command':command})
plan={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src).decode().strip(),'source_tree':str(src),'base':str(base),'base_source':old['source'],'scope':'Strict O1/g0 ASan/UBSan current source: genuine218-owner old owning build, complete actualMD-affected TUs/new fixtures freshly compiled, unchanged owner records preserved, fresh corearchive+links; no runtime claim','changed':changed,'unchanged':unchanged,'archives':archives,'links':links,'input_pins':pins,'environment':{k:v for k,v in old['environment'].items()if v is not None},'base_actual_owners':old_owners}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print({'source':plan['source'],'fresh_whole_TUs':len(changed),'qualified_unchanged_owners':len(unchanged),'fresh_sources':[Path(x['object']).name for x in changed],'pins':len(pins)})
