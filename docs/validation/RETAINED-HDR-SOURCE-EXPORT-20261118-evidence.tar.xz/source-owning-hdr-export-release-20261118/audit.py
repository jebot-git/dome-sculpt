from pathlib import Path
import json,subprocess,hashlib,shlex,time
out=Path(__file__).resolve().parent
plan=json.loads((out/'plan.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
state={'source':plan['source'],'plan_sha256':sha(out/'plan.json'),'state':'auditing','errors':[]}
try:
 build=json.loads((out/'status.json').read_text())
 if build.get('exit')!=0 or build.get('state')!='terminal':raise RuntimeError('Owning build not terminal0')
 raw=subprocess.check_output(['/usr/bin/ninja','-t','compdb'],cwd=out);(out/'actual-compdb.json').write_bytes(raw)
 commands=json.loads(raw);by_output={str((out/record['output']).resolve()):record for record in commands if record.get('output')}
 owners=[];dependencies=set();generated=set();object_hashes={}
 for md in sorted(out.rglob('*.o.d')):
  object_path=Path(str(md)[:-2]);text=md.read_text().replace('\\\n',' ');target,tail=text.split(':',1)
  if (out/shlex.split(target)[0]).resolve()!=object_path.resolve():raise RuntimeError('Actual MD output mismatch '+str(md))
  record=by_output.get(str(object_path.resolve()))
  if not record:raise RuntimeError('No actual compile command for '+str(object_path))
  if '-O3' not in record['command'] or '-DNDEBUG' not in record['command']:raise RuntimeError('Non-Release selected owner '+str(object_path))
  deps=[]
  for name in shlex.split(tail):
   p=Path(name);p=(out/p).resolve() if not p.is_absolute() else p.resolve();name=str(p)
   if not p.is_file():raise RuntimeError('Missing actual dependency '+name)
   if name not in plan['source_input_pins']:
    if p.is_relative_to(out):generated.add(name)
    else:raise RuntimeError('Actual dependency absent from pre-build source/tool closure '+name)
   dependencies.add(name);deps.append(name)
  owners.append({'object':str(object_path),'object_sha256':sha(object_path),'depfile':str(md),'depfile_sha256':sha(md),'command':record['command'],'cwd':record['directory'],'actual_dependencies':deps})
  object_hashes[object_path.name]=sha(object_path)
 archives=[]
 for archive in sorted(out.glob('*.a')):
  archive_record=by_output.get(str(archive.resolve()))
  if not archive_record:raise RuntimeError('No actual archive command '+str(archive))
  argv=shlex.split(archive_record['command']);at=next(i for i,v in enumerate(argv) if Path(v).name=='ar');arguments=argv[at+3:];arguments=arguments[:arguments.index('&&')] if '&&' in arguments else arguments
  actual_members={Path(name).name:(out/name).resolve() for name in arguments}
  if len(actual_members)!=len(arguments):raise RuntimeError('Duplicate actual archive object names')
  names=subprocess.check_output(['/usr/bin/ar','t',str(archive)]).decode().splitlines();members=[]
  if len(names)!=len(set(names)):raise RuntimeError('Duplicate archive member names')
  for name in names:
   value=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(archive),name])).hexdigest()
   if name not in actual_members or sha(actual_members[name])!=value:raise RuntimeError('Archive payload differs from actual owning object '+name)
   if not any(x['object']==str(actual_members[name]) for x in owners):raise RuntimeError('Archive member lacks actual compile/MD owner '+name)
   members.append({'name':name,'sha256':value})
  archives.append({'path':str(archive),'sha256':sha(archive),'actual_command':archive_record,'members':members})
 drift=[p for p,h in plan['source_input_pins'].items() if not Path(p).is_file() or sha(p)!=h]
 if drift:raise RuntimeError('Post owning input drift '+repr(drift))
 state.update(exit=0,actual_owner_count=len(owners),actual_dependency_count=len(dependencies),actual_dependency_incidences=sum(len(x['actual_dependencies']) for x in owners),generated_dependency_hashes={p:sha(p) for p in sorted(generated)},owners=owners,archives=archives,drift=drift)
except BaseException as e:state.update(exit=1,error=repr(e))
state['state']='terminal';(out/'audit-status.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps({k:v for k,v in state.items() if k not in ['owners','archives','generated_dependency_hashes']},indent=2));raise SystemExit(state['exit'])
