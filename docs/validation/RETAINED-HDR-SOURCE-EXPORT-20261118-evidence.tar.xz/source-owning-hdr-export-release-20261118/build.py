import json,pathlib,hashlib,subprocess,os,time,signal,resource
out=pathlib.Path(__file__).resolve().parent
plan=json.loads((out/'plan.json').read_text());sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def drift():return [p for p,h in plan['source_input_pins'].items() if not pathlib.Path(p).is_file() or sha(p)!=h]
state={'state':'preflight','scope':plan['scope'],'source':plan['source'],'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'argv':plan['argv'],'pid':os.getpid(),'input_drift':drift()}
def save():(out/'status.json').write_text(json.dumps(state,indent=2)+'\n')
child=None
save()
def interrupted(sig,frame):raise KeyboardInterrupt('Signal '+str(sig))
signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
try:
 if state['input_drift']:raise RuntimeError('Source/configure/tool input drift')
 env=os.environ.copy()
 for k in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','CMAKE_PREFIX_PATH']:env.pop(k,None)
 env.update(plan['environment']);state['state']='running';save();t=time.monotonic()
 def bounded():resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
 with (out/'build.log').open('w') as log:
  child=subprocess.Popen(['/usr/bin/timeout','--signal=TERM','--kill-after=5s','1800s',*plan['argv']],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=bounded);state['child_pid']=child.pid;state['child_start_ticks']=pathlib.Path('/proc/'+str(child.pid)+'/stat').read_text().split()[21];save();state['exit']=child.wait()
 state['elapsed_seconds']=time.monotonic()-t;state['input_drift']=drift()
 if state['input_drift']:state['exit']=state['exit'] or 1
 state['build_log_sha256']=sha(out/'build.log');state['genuine_compiler_depfile_count']=len(list(out.rglob('*.o.d')))
 if state['exit']==0:state['selected_outputs']={target:sha(out/target) for target in plan['targets']}
except BaseException as e:
 state.update(exit=1,error=repr(e))
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
finally:state['state']='terminal';save()
raise SystemExit(state['exit'])
