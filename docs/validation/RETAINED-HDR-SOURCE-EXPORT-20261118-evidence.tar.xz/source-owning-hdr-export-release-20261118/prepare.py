from pathlib import Path
import json,subprocess,hashlib,shlex,os
out=Path(__file__).resolve().parent
src=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-export-20261118')
base=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-domain-release-20261118')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=set()
for name in subprocess.check_output(['git','ls-files','-z'],cwd=src).decode().split('\0'):
 if name and (name in ['CMakeLists.txt'] or name.startswith(('src/','include/','tests/','cmake/','third_party/','assets/'))):
  p=src/name
  if p.is_file():paths.add(str(p))
for md in base.rglob('*.o.d'):
 text=md.read_text().replace('\\\n',' ')
 for name in shlex.split(text.split(':',1)[1]):
  p=Path(name)
  if not p.is_absolute():p=base/p
  p=p.resolve()
  if '/artifacts/source-owning-hdr-domain-20261118/' in str(p) or str(p).startswith(str(base)+'/'):continue
  if p.is_file():paths.add(str(p))
for name in ['/usr/bin/c++','/usr/bin/ar','/usr/bin/ranlib','/usr/bin/ld','/usr/bin/ninja','/usr/bin/cmake']:
 paths.add(str(Path(name).resolve()))
paths.add(subprocess.check_output(['/usr/bin/c++','-print-prog-name=cc1plus']).decode().strip())
for p in out.rglob('*'):
 if p.is_file() and p.name not in ['configure.log','prepare.py'] and '.ninja_log' not in str(p) and '.ninja_deps' not in str(p):paths.add(str(p))
targets=['dome-sculpt-source-owning-hdr-export-test','dome-sculpt-source-owning-hdr-domain-test','dome-sculpt-source-joint-writable-normal-bake-test','dome-sculpt-baked-emission-workflow-test']
plan={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src).decode().strip(),'source_tree':str(src),'scope':'Fresh Release complete196-core/support +four selected native fixture TUs; no object reuse or runtime/graphics acceptance','cwd':str(out),'targets':targets,'argv':['/usr/bin/ninja','-d','keepdepfile','-d','keeprsp','-v','-j2',*targets],'source_input_pins':{p:sha(p) for p in sorted(paths)},'environment':{'PATH':'/usr/local/bin:/usr/bin','PKG_CONFIG_PATH':'/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig','LD_LIBRARY_PATH':'/home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'source':plan['source'],'pinned_inputs':len(paths),'targets':targets}))
