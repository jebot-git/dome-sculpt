from pathlib import Path
import json,shlex,hashlib,subprocess
out=Path(__file__).resolve().parent;src=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-export-controls-20261118');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();profiles=[]
for name,base in [('release',Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-source8-export-release-20261118')),('sanitize',Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-source8-export-sanitize-20261118'))]:
 p=json.loads((base/'plan.json').read_text());s=json.loads((base/'status.json').read_text());assert s['exit']==0;dest=out/name;dest.mkdir(exist_ok=True);oldsrc=Path(p['source_tree']);target='dome-sculpt-source-owning-hdr-export-test';pins=dict(p['input_pins']);pins[str(base/'plan.json')]=sha(base/'plan.json');pins[str(base/'status.json')]=sha(base/'status.json')
 for f in src.rglob('*'):
  if f.is_file()and f.suffix in ['.hpp','.cpp','.h']:pins[str(f)]=sha(f)
 if name=='sanitize':donor=next(x for x in p['changed']if x['object'].endswith('/source-owning-hdr-export.cpp.o'));argv=list(donor['argv'])
 else:
  oldbase=Path(p['base']);oldplan=json.loads((oldbase/'plan.json').read_text());oldsrc=Path(oldplan['source_tree']);record=next(x for x in json.loads((oldbase/'actual-compdb.json').read_text())if x.get('output','').endswith('/tests/source-owning-hdr-export.cpp.o'));argv=shlex.split(record['command'])
 argv=[x.replace(str(oldsrc),str(src))for x in argv];relative=Path('CMakeFiles')/(target+'.dir')/'tests/source-owning-hdr-export.cpp.o';(dest/relative).parent.mkdir(parents=True,exist_ok=True)
 link=list(next(x['argv']for x in p['links']if x['target']==target))
 for i,value in enumerate(link):
  if value.endswith('/source-owning-hdr-export.cpp.o')or value.endswith('source-owning-hdr-export.cpp.o'):link[i]=str(dest/relative)
  elif value.endswith('.a')and not Path(value).is_absolute():link[i]=str(base/value);pins[str(base/value)]=sha(base/value)
  if value.startswith('-Wl,--dependency-file='):(dest/value.split('=',1)[1]).parent.mkdir(parents=True,exist_ok=True)
 profiles.append({'name':name,'base':str(base),'cwd':str(dest),'object':str(dest/relative),'argv':argv,'link_argv':link,'target':target,'input_pins':pins,'environment':p['environment']})
plan={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src).decode().strip(),'production':'60a1f12296d6e705ac398e70298a9826cef8e120','scope':'Test-only expanded full fixture TUs and fresh links for qualified matching R/S current cores; no product core changes','profiles':profiles};(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print({'fixture':plan['source'],'production':plan['production'],'profiles':[x['name']for x in profiles]})
