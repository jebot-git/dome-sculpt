from pathlib import Path
import json,hashlib,subprocess,os,time,resource,shlex,concurrent.futures
out=Path(__file__).resolve().parent;p=json.loads((out/'plan.json').read_text());sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();s={'state':'running','source':p['source'],'production':p['production'],'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'pid':os.getpid(),'profiles':[]}
def save():(out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def bounded():resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
def profile(v):
 result={'name':v['name'],'steps':[]};cwd=Path(v['cwd']);env=os.environ.copy()
 for k in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','CMAKE_PREFIX_PATH']:env.pop(k,None)
 env.update(v['environment'])
 try:
  assert all(Path(f).is_file()and sha(f)==h for f,h in v['input_pins'].items())
  for name,argv in [('compile',v['argv']),('link',v['link_argv'])]:
   t=time.monotonic()
   with(cwd/(name+'.log')).open('wb')as log:r=subprocess.run(['/usr/bin/timeout','--signal=TERM','--kill-after=5s','300s',*argv],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=bounded)
   result['steps'].append({'name':name,'argv':argv,'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-t});assert r.returncode==0
  obj=Path(v['object']);md=Path(str(obj)+'.d');text=md.read_text().replace('\\\n',' ');target,tail=text.split(':',1);assert(cwd/shlex.split(target)[0]).resolve()==obj.resolve();deps=[]
  for name in shlex.split(tail):
   f=Path(name);f=(cwd/f).resolve()if not f.is_absolute()else f.resolve();assert str(f)in v['input_pins']and sha(f)==v['input_pins'][str(f)];deps.append(str(f))
  assert all(Path(f).is_file()and sha(f)==h for f,h in v['input_pins'].items())
  result.update(exit=0,object_sha256=sha(obj),depfile=str(md),depfile_sha256=sha(md),actual_dependencies=deps,elf=str(cwd/v['target']),elf_sha256=sha(cwd/v['target']))
 except BaseException as e:result.update(exit=1,error=repr(e))
 return result
save()
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for v in pool.map(profile,p['profiles']):s['profiles'].append(v);save()
s.update(state='terminal',exit=int(any(v['exit']for v in s['profiles'])));save();raise SystemExit(s['exit'])
