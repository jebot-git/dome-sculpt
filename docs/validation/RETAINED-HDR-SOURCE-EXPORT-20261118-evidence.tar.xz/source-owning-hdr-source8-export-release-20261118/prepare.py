from pathlib import Path
import json,subprocess,hashlib,shlex
out=Path(__file__).resolve().parent;base=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-export-release-20261118');src=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-source8-export-20261118')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((base/'plan.json').read_text());audit=json.loads((base/'audit-status.json').read_text());assert audit['exit']==0
oldsrc=Path(old['source_tree']);pins=dict(old['source_input_pins']);pins[str(base/'audit-status.json')]=sha(base/'audit-status.json');pins[str(base/'status.json')]=sha(base/'status.json')
for name in subprocess.check_output(['git','ls-files','-z'],cwd=src).decode().split('\0'):
 if name and (name=='CMakeLists.txt' or name.startswith(('src/','include/','tests/','cmake/','third_party/','assets/'))):
  p=src/name
  if p.is_file():pins[str(p)]=sha(p)
changed=[];unchanged=[]
for owner in audit['owners']:
 relative=Path(owner['object']).relative_to(base);differences=[];pairs=[]
 pins[owner['object']]=owner['object_sha256'];pins[owner['depfile']]=owner['depfile_sha256']
 for name in owner['actual_dependencies']:
  p=Path(name)
  if p.is_relative_to(oldsrc):
   current=src/p.relative_to(oldsrc)
   if not current.is_file() or sha(current)!=sha(p):differences.append(str(current))
   else:pairs.append({'old':str(p),'current':str(current),'sha256':sha(p)})
 argv=[x.replace(str(oldsrc),str(src)) for x in shlex.split(owner['command'])]
 if differences:
  item={'object':str(out/relative),'original_object':owner['object'],'original_md':owner['depfile'],'original_command':owner['command'],'argv':argv,'cwd':str(out),'differences':differences}
  changed.append(item);(out/relative).parent.mkdir(parents=True,exist_ok=True)
 else:unchanged.append({'object':owner['object'],'object_sha256':owner['object_sha256'],'depfile':owner['depfile'],'actual_command':owner['command'],'cwd':owner['cwd'],'source_pairs':pairs})
compdb=json.loads((base/'actual-compdb.json').read_text());byoutput={str((base/x['output']).resolve()):x for x in compdb if x.get('output')}
archives=[]
for a in audit['archives']:
 pins[a['path']]=a['sha256'];archives.append(a)
links=[]
for target in old['targets']:
 record=byoutput[str(base/target)];argv=shlex.split(record['command'])
 if argv[:2]==[':','&&']:argv=argv[2:]
 if argv[-2:]==['&&',':']:argv=argv[:-2]
 assert '&&' not in argv and argv[0]=='/usr/bin/c++'
 # The selected fixture's genuine old object remains a separate owner if no
 # actual header/source input changed. Never rename/call it a fresh compile.
 for i,value in enumerate(argv):
  if value.endswith('.o') and not Path(value).is_absolute():
   if not any(Path(c['object']).relative_to(out)==Path(value) for c in changed):argv[i]=str(base/value)
  if value.startswith('-Wl,--dependency-file='):(out/value.split('=',1)[1]).parent.mkdir(parents=True,exist_ok=True)
 links.append({'target':target,'argv':argv,'cwd':str(out),'original_command':record['command']})
plan={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src).decode().strip(),'source_tree':str(src),'base':str(base),'base_source':old['source'],'scope':'Actual-MD selected coherent child: fresh complete affected TUs +fresh archives/links, exact unchanged prior objects retain original commands/MDs; no full-fresh or runtime claim','changed':changed,'unchanged':unchanged,'archives':archives,'links':links,'input_pins':pins,'environment':old['environment']}
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'source':plan['source'],'fresh_owners':len(changed),'qualified_unchanged_owners':len(unchanged),'changed_sources':[str(Path(x['object']).relative_to(out)) for x in changed],'pins':len(pins)},indent=2))
