from pathlib import Path
import json,subprocess,hashlib,shutil,os,time,resource,shlex,concurrent.futures
out=Path(__file__).resolve().parent;p=json.loads((out/'plan.json').read_text());base=Path(p['base']);sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s={'state':'preflight','source':p['source'],'base_source':p['base_source'],'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'pid':os.getpid(),'steps':[]};start=time.monotonic()
def save():(out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return [f for f,h in p['input_pins'].items() if not Path(f).is_file() or sha(f)!=h]
env=os.environ.copy()
for k in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','CMAKE_PREFIX_PATH']:env.pop(k,None)
env.update(p['environment'])
def limits():resource.setrlimit(resource.RLIMIT_AS,(3*1024**3,3*1024**3))
def run(name,argv):
 before=time.monotonic()
 with (out/(name+'.log')).open('wb')as log:r=subprocess.run(['/usr/bin/timeout','--signal=TERM','--kill-after=5s','300s',*argv],cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=limits)
 return {'name':name,'argv':argv,'cwd':str(out),'exit':r.returncode,'seconds':time.monotonic()-before}
try:
 s['input_drift']=drift();save();assert not s['input_drift'];s['state']='compiling';save()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
  futures=[pool.submit(run,'compile-'+str(i),x['argv'])for i,x in enumerate(p['changed'])]
  for future in concurrent.futures.as_completed(futures):s['steps'].append(future.result());save()
 if any(x['exit'] for x in s['steps']):raise RuntimeError('Affected whole-TU compile failed')
 s['fresh_owners']=[]
 for item in p['changed']:
  obj=Path(item['object']);md=Path(str(obj)+'.d');assert obj.is_file()and md.is_file();text=md.read_text().replace('\\\n',' ');target,tail=text.split(':',1);assert (out/shlex.split(target)[0]).resolve()==obj.resolve();deps=[]
  for name in shlex.split(tail):
   f=Path(name);f=(out/f).resolve()if not f.is_absolute()else f.resolve()
   if str(f)not in p['input_pins']:raise RuntimeError('Fresh actualMD dependency absent from pre-pins '+str(f))
   assert sha(f)==p['input_pins'][str(f)];deps.append(str(f))
  s['fresh_owners'].append({**item,'object_sha256':sha(obj),'depfile':str(md),'depfile_sha256':sha(md),'actual_dependencies':deps})
 s['state']='archiving';save()
 for archive in p['archives']:
  dest=out/Path(archive['path']).name;assert sha(archive['path'])==archive['sha256'];shutil.copyfile(archive['path'],dest)
  replacements=[x['object']for x in p['changed']if '/CMakeFiles/dome-sculpt-core.dir/'in x['object']]if dest.name=='libdome-sculpt-core.a'else[]
  if replacements:
   row=run('archive-core',['/usr/bin/ar','r',str(dest),*replacements]);s['steps'].append(row);save();assert row['exit']==0
   row=run('ranlib-core',['/usr/bin/ranlib',str(dest)]);s['steps'].append(row);save();assert row['exit']==0
  expected={x['name']:x['sha256']for x in archive['members']}
  for obj in replacements:expected[Path(obj).name]=sha(obj)
  names=subprocess.check_output(['/usr/bin/ar','t',str(dest)]).decode().splitlines();assert len(names)==len(expected)and set(names)==set(expected)
  for name in names:assert hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(dest),name])).hexdigest()==expected[name]
 s['state']='linking';save()
 for item in p['links']:
  row=run('link-'+item['target'],item['argv']);s['steps'].append(row);save();assert row['exit']==0
 s['input_drift']=drift();assert not s['input_drift'];s['exit']=0;s['selected_outputs']={x['target']:sha(out/x['target'])for x in p['links']};s['core_archive_sha256']=sha(out/'libdome-sculpt-core.a');s['qualified_unchanged_owner_count']=len(p['unchanged']);s['fresh_owner_count']=len(s['fresh_owners'])
except BaseException as error:s.update(exit=1,error=repr(error))
finally:s['state']='terminal';s['seconds']=time.monotonic()-start;save()
raise SystemExit(s['exit'])
