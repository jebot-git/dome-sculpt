from pathlib import Path
import json,hashlib,shutil
out=Path(__file__).resolve().parent;root=Path('/home/blux/de-xr/dome-sculpt/artifacts');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
old=json.loads((root/'source-owning-hdr-source8-export-release-20261118/native-v1/plan.json').read_text());controls=root/'source-owning-hdr-export-controls-build-20261118';legacy=root/'source-owning-hdr-export-legacy-build-20261118'
cp=json.loads((controls/'plan.json').read_text());cs=json.loads((controls/'status.json').read_text());lp=json.loads((legacy/'plan.json').read_text());ls=json.loads((legacy/'status.json').read_text());assert cs['exit']==ls['exit']==0
sanenv=json.loads((root/'authoring-combined-checked-sanitize-20261118/native-selected-v2/plan.json').read_text())
for profile,base in [('release',root/'source-owning-hdr-source8-export-release-20261118'),('sanitize',root/'source-owning-hdr-source8-export-sanitize-20261118')]:
 dest=out/profile;dest.mkdir(exist_ok=True);p=json.loads((base/'plan.json').read_text());s=json.loads((base/'status.json').read_text());assert s['exit']==0;cv=next(x for x in cp['profiles']if x['name']==profile);lv=next(x for x in lp['profiles']if x['name']==profile);cvs=next(x for x in cs['profiles']if x['name']==profile);lvs=next(x for x in ls['profiles']if x['name']==profile);pins={**p['input_pins'],**cv['input_pins'],**lv['input_pins']}
 for directory in [base,controls,legacy]:
  for f in ['plan.json','status.json']:pins[str(directory/f)]=sha(directory/f)
 for v in [cvs,lvs]:
  for k in ['elf','depfile']:pins[v[k]]=sha(v[k])
 seed=root/'source-owning-hdr-export-release-20261118/native-v1/joint-000-512/000.dsculpt';pins[str(seed)]=sha(seed)
 steps=[]
 if profile=='sanitize':
  seed=dest/'joint-000-512/000.dsculpt';steps.extend([{'name':'joint-000-512','argv':[str(base/'dome-sculpt-source-joint-writable-normal-bake-test'),'--checked-case','000','512',str(seed.parent)],'pass_regex':r'PASS (\d+) checked joint-writable SOURCE controls'},{'name':'owner-controls','argv':[str(base/'dome-sculpt-source-owning-hdr-domain-test'),str(seed),str(dest/'owner-controls')],'pass_regex':r'PASS (\d+) owning HDR-domain controls'}])
 steps.extend([{'name':'export-controls','argv':[cvs['elf'],str(seed),str(dest/'export-controls')],'pass_regex':r'PASS (\d+) retained HDR export controls'},{'name':'baked-workflow','argv':[lvs['elf'],str(dest/'baked-workflow')],'pass_regex':r'Baked emission worker (\d+) checks PASS'}])
 for step in steps:step['elf_sha256']=sha(step['argv'][0]);pins[step['argv'][0]]=step['elf_sha256']
 env=dict(old['environment'])
 if profile=='sanitize':env.update(sanenv['environment'])
 plan={**old,'source':'production60a1f122, exportfixtureb5b058e9, legacyfixture061c8a0b','steps':steps,'input_pins':pins,'environment':env,'profile':profile}
 if profile=='sanitize':plan['provider_catalog']={**old['provider_catalog'],**sanenv['runtime_provider_expected_catalog']}
 (dest/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');driver=(root/'source-owning-hdr-source8-export-release-20261118/native-v1/run.py').read_text()
 if profile=='sanitize':
  driver=driver.replace("assert 'not found' not in text and not re.search(r'lib(?:asan|ubsan)\\.so',text)","assert 'not found' not in text and re.search(r'libasan\\.so',text) and re.search(r'libubsan\\.so',text)")
  driver=driver.replace("text=(out/(name+'.log')).read_text();passed=", "text=(out/(name+'.log')).read_text();assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:',text);mapped=(out/(name+'.maps')).read_text();assert 'libasan' in mapped and 'libubsan' in mapped;row['live_ASan_UBSan']=True;passed=")
 (dest/'run.py').write_text(driver)
 print({'profile':profile,'steps':len(steps),'pins':len(pins),'plan_sha256':sha(dest/'plan.json')})
