from pathlib import Path
import os,sys,json,hashlib,fcntl,importlib.util,re,time,resource
sys.dont_write_bytecode=True
out=Path(__file__).parent;p=json.loads((out/'plan.json').read_text());pins=dict(p['input_pins']);lease=None
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def verify():
 drift=[x for x,h in pins.items() if not Path(x).is_file() or sha(x)!=h]
 if drift:raise RuntimeError('Immutable retained-export input drift: '+str(drift))
s={'state':'running','terminal':False,'exit_code':None,'source':p['source'],'driver_pid':os.getpid(),'steps':[],'providers':{},'live_maps':{},'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__)}
def save():(out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def provider(path):
 path=Path(path);resolved=path.resolve();want=pins.get(str(path)) or pins.get(str(resolved)) or p['provider_catalog'].get(str(path)) or p['provider_catalog'].get(str(resolved))
 if want is None:raise RuntimeError('Unknown actual retained-export provider '+str(path))
 assert sha(path)==want and sha(resolved)==want
 pins[str(path)]=want;pins[str(resolved)]=want
 return {'path':str(path),'resolved':str(resolved),'sha256':want}
def live(name,row):
 s['live']={'name':name,**row}
 try:
  proc=Path('/proc',str(row['pid']));stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
  if int(stat[19])==row['start']:
   lines=(proc/'maps').read_text();s['live_maps'].setdefault(name,{'pid':row['pid'],'start':row['start'],'maps_file':str(out/(name+'.maps'))});(out/(name+'.maps')).write_text(lines)
 except FileNotFoundError:pass
 save()
try:
 assert resource.getrlimit(resource.RLIMIT_AS)==(resource.RLIM_INFINITY,resource.RLIM_INFINITY)
 pins[str(out/'run.py')]=sha(__file__);verify();spec=importlib.util.spec_from_file_location('qualified_monitor',p['monitor']['path']);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
 env={k:v for k,v in os.environ.items() if not k.startswith(('LD_','DYLD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(key,None)
 env.update({k:v for k,v in p['environment'].items() if v is not None});env['XR_RUNTIME_JSON']=str(out/'no-physical-runtime.json');env['PYTHONDONTWRITEBYTECODE']='1'
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_STATE_HOME','state'),('XDG_CACHE_HOME','cache'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(out/leaf);Path(env[key]).mkdir(mode=0o700)
 s['environment']={k:env.get(k) for k in list(p['environment'])+['DISPLAY','WAYLAND_DISPLAY','XR_RUNTIME_JSON']};save()
 lease=Path(p['lease']).open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);s['lease']={'acquired':time.time(),'inode':os.fstat(lease.fileno()).st_ino,'before_any_ldd_or_product':True};save()
 for step in p['steps']:
  verify();name=step['name'];assert sha(step['argv'][0])==step['elf_sha256']
  row=monitor.run(['/usr/bin/ldd',step['argv'][0]],cwd=out,env=env,log=out/(name+'.ldd'),timeout=60,max_rss=p['resources']['RSS_bytes']);row['name']=name+'-ldd';s['steps'].append(row);save();assert row['exit']==0 and not row.get('signals') and not row.get('error')
  text=(out/(name+'.ldd')).read_text();assert 'not found' not in text and re.search(r'libasan\.so',text) and re.search(r'libubsan\.so',text);paths=re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text);assert paths;s['providers'][name]=[provider(x) for x in paths];save()
  row=monitor.run(step['argv'],cwd=out,env=env,log=out/(name+'.log'),timeout=p['resources']['per_command_seconds'],max_rss=p['resources']['RSS_bytes'],progress=lambda row:live(name,row));row['name']=name;s['steps'].append(row);s.pop('live',None);save();assert row['exit']==0 and not row.get('signals') and not row.get('error')
  text=(out/(name+'.log')).read_text();assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:',text);mapped=(out/(name+'.maps')).read_text();assert 'libasan' in mapped and 'libubsan' in mapped;row['live_ASan_UBSan']=True;passed=re.findall(step['pass_regex'],text,re.M);assert len(passed)==1 and int(passed[0])>0;row['actual_pass_count']=int(passed[0])
  if name=='export-controls':
   dense=re.findall(r'^INDEPENDENT_MULTI_GRID probes=(\d+) maximum=([\d.eE+-]+)$',text,re.M);assert len(dense)==1 and int(dense[0][0])==23707 and float(dense[0][1])<2e-4;row['independent_multi_grid']=dense[0]
  verify();save()
 s.update(state='complete',exit_code=0)
except BaseException as error:s.update(state='failed',exit_code=1,error=str(error))
finally:
 s['input_drift']=[x for x,h in pins.items() if not Path(x).is_file() or sha(x)!=h];s['remaining_owned']=[]
 if 'monitor' in globals():
  for row in s['steps']:
   for proc in row.get('known_processes',[]):
    if monitor.alive(proc):s['remaining_owned'].append(proc)
 if s['input_drift'] or s['remaining_owned']:s.update(state='failed',exit_code=1)
 s['terminal']=True
 if lease:
  if 'lease' in s:s['lease']['released']=time.time()
  fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 (out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');save()
raise SystemExit(s['exit_code'])
