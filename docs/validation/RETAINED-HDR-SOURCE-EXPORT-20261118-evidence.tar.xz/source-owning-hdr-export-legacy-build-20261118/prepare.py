from pathlib import Path
import json,hashlib,subprocess
out=Path(__file__).resolve().parent;src=Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-export-legacy-controls-20261118');sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();profiles=[];target='dome-sculpt-baked-emission-workflow-test'
for name,base in [('release',Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-source8-export-release-20261118')),('sanitize',Path('/home/blux/de-xr/dome-sculpt/artifacts/source-owning-hdr-source8-export-sanitize-20261118'))]:
 p=json.loads((base/'plan.json').read_text());s=json.loads((base/'status.json').read_text());assert s['exit']==0;dest=out/name;dest.mkdir(exist_ok=True);oldsrc=Path(p['source_tree']);pins=dict(p['input_pins']);pins[str(base/'plan.json')]=sha(base/'plan.json');pins[str(base/'status.json')]=sha(base/'status.json')
 for f in subprocess.check_output(['git','ls-files','-z'],cwd=src).decode().split('\0'):
  if f and(f=='CMakeLists.txt'or f.startswith(('src/','include/','tests/','cmake/','third_party/','assets/'))):
   path=src/f
   if path.is_file():pins[str(path)]=sha(path)
 donor=next(x for x in p['changed']if x['object'].endswith('/baked-emission-workflow.cpp.o'));argv=[x.replace(str(oldsrc),str(src))for x in donor['argv']];relative=Path('CMakeFiles')/(target+'.dir')/'tests/baked-emission-workflow.cpp.o';(dest/relative).parent.mkdir(parents=True,exist_ok=True)
 link=list(next(x['argv']for x in p['links']if x['target']==target))
 for i,value in enumerate(link):
  if value.endswith('baked-emission-workflow.cpp.o'):link[i]=str(dest/relative)
  elif value.endswith('.a')and not Path(value).is_absolute():link[i]=str(base/value);pins[str(base/value)]=sha(base/value)
  if value.startswith('-Wl,--dependency-file='):(dest/value.split('=',1)[1]).parent.mkdir(parents=True,exist_ok=True)
 profiles.append({'name':name,'base':str(base),'cwd':str(dest),'object':str(dest/relative),'argv':argv,'link_argv':link,'target':target,'input_pins':pins,'environment':p['environment']})
plan={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src).decode().strip(),'production':'60a1f12296d6e705ac398e70298a9826cef8e120','scope':'Legacy single-grid corpus explicitly selects policy0; production default1 unchanged. Full fixture TUs and freshR/Slinks againstmatchingcurrent196cores.','profiles':profiles};(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print({'fixture':plan['source'],'production':plan['production'],'profiles':[x['name']for x in profiles]})
