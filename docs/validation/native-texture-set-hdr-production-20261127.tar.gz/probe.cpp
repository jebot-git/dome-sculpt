#include "dome/document.hpp"
#include "dome/emission-native.hpp"
#include "dome/native-authoring.hpp"
#include "dome/texture-sets.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc,char **argv) try {
  using namespace dome;
  if(argc!=4)return 2;
  const std::filesystem::path out=argv[1];
  std::filesystem::create_directories(out);
  const auto size=uint32_t(std::stoul(argv[2]));
  const auto second_size=uint32_t(std::stoul(argv[3]));
  Mesh mesh;
  mesh.positions={{-.8f,-.6f,0},{.8f,-.6f,0},{0,.85f,0},{-.8f,-.6f,.5f},{.8f,-.6f,.5f},{0,.85f,.5f}};
  mesh.normals.assign(6,{0,0,1});
  mesh.uv={{{.1f,.1f}},{{.9f,.1f}},{{.5f,.9f}},{{.1f,.1f}},{{.9f,.1f}},{{.5f,.9f}}};
  mesh.indices={0,1,2,3,4,5};
  Scene scene;
  const auto id=scene.active().id;
  std::array<TextureSetInitialField,2> fields;
  fields[0].resolution=size;
  fields[1].resolution=second_size;
  fields[1].material.name="Second material";
  fields[0].material.double_sided=fields[1].material.double_sided=true;
  TextureSetLimits creation;
  if(std::max(size,second_size)==2048)creation.maximum_work=160'000'000;
  initialize_texture_sets(scene,id,mesh,fields,std::array<TextureSetId,2>{0,1},creation);
  for(TextureSetId set:{0u,1u}){
    const auto authored=edit_texture_set(scene,id,set,[&](PaintedMesh &paint,Material &material){
      material.emissive=set?std::array<float,3>{.2f,.1f,.03f}:std::array<float,3>{.03f,.2f,.1f};
      Brush brush;
      brush.from=brush.to={0,0,set?.5f:0.f};brush.normal={0,0,1};brush.radius=.045f;brush.strength=.81f;
      PaintSettings settings;
      settings.front_only=false;settings.channel=PaintChannel::Emission;settings.emission_units=PaintEmissionUnits::Physical;
      settings.emission=set?std::array<float,3>{.2f,9.f,.8f}:std::array<float,3>{5.f,.12f,.35f};
      paint.begin_stroke();paint.stamp(brush,settings);const bool emission=paint.end_stroke();
      brush.from=brush.to={.2f,-.05f,set?.5f:0.f};brush.radius=.055f;
      settings.channel=PaintChannel::Color;settings.color={.2f,.5f,.1f,.83f};
      paint.begin_stroke();paint.stamp(brush,settings);const bool color=paint.end_stroke();
      return emission&&color;
    });
    if(!authored)throw std::runtime_error("Could not paint actual independent production fields");
  }
  scene.save(out/"source.dsculpt");
  const auto exact=scene.encode();
  Document doc;
  doc.replace(scene);
  if(!doc.wait_asset()||!doc.wait_mesh(std::chrono::seconds(90))||!doc.frame().state->error.empty())
    throw std::runtime_error(doc.frame().state->error);
  bool okay=true;
  for(auto [name,format]:std::array{std::pair{"standard",AssetExportFormat::Glb},
      std::pair{"editable",AssetExportFormat::EditableGlb512}}){
    const auto path=out/(std::string(name)+".glb");
    try {
      doc.export_asset(path,format).get();
      std::ifstream stream(path,std::ios::binary);
      const std::vector<uint8_t> bytes{std::istreambuf_iterator<char>(stream),{}};
      auto restored=format==AssetExportFormat::Glb?extract_native_emission(bytes):extract_native_authoring(bytes);
      if(!restored||restored->encode()!=exact)throw std::runtime_error("Did not restore the exact native material document");
      std::cout<<name<<" "<<size<<"+"<<second_size<<" "<<bytes.size()<<" bytes; exact native restore"<<std::endl;
    }catch(const std::exception &e){
      std::cout<<name<<" refusal: "<<e.what()<<std::endl;
      okay=false;
    }
  }
  return okay?0:1;
} catch(const std::exception &e) {std::cerr<<e.what()<<std::endl;return 1;}
