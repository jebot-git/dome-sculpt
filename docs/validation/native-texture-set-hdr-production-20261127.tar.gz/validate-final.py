from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
artifacts = root.parent
source = root / "source"
profile = sys.argv[1]
out = root / (profile+"-export")
out.mkdir(exist_ok=True)
previous = root / profile
shared = artifacts / "native-shared-bake-20261127" / profile
older = artifacts / "native-hdr-compact-20261126" / profile / "build"
codec = artifacts / "hdr-portable-streaming-20261127" / profile / "libdome-sculpt-emission-codec.a"
toolkit = artifacts / "sdk-20261126/toolkit-sanitize" if profile == "asan" else Path("/opt/fltk-vr/toolkit")
env = dict(os.environ, LD_LIBRARY_PATH=f"{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
           LIBGL_ALWAYS_SOFTWARE="1", EGL_PLATFORM="surfaceless", LP_NUM_THREADS="2",
           ASAN_OPTIONS="detect_leaks=1:halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
core = out / "libdome-sculpt-core.a"
entries = json.loads((shared/"build/compile_commands.json").read_text())
parent = shared.parent / "source"

def run(args, name, check=True):
    with (out/(name+".log")).open("w") as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        return subprocess.run(args, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT,
                              timeout=720, check=check).returncode

def compile_object(filename, target="dome-sculpt-core", override=None):
    row = next(c for c in entries if f"/{target}.dir/" in c["output"] and Path(c["file"]).name==filename)
    args = shlex.split(row["command"].replace(str(parent),str(source)))
    if override is not None:
        args[-1]=str(override)
    obj = out / ((override.name if override is not None else filename)+".o")
    args[args.index("-o")+1] = str(obj)
    run(args,obj.stem+"-compile")
    return obj

def link(target, obj=None, name=None):
    line = subprocess.check_output(["ninja","-t","commands",target],cwd=older,text=True).splitlines()[-1]
    args = []
    for word in shlex.split(line)[2:-2]:
        if word.startswith("-Wl,--dependency-file"):continue
        if word==core.name:word=str(core)
        elif word==codec.name:word=str(codec)
        elif obj is not None and f"{target}.dir/" in word and word.endswith(".o"):word=str(obj)
        elif not word.startswith("/") and word.endswith((".a",".o")):word=str(older/word)
        args.append(word)
    path=out/(name or target)
    args[args.index("-o")+1]=str(path)
    run(args,path.name+"-link")
    return path


exe=link("dome-sculpt-texture-set-export-test",
         compile_object("texture-set-export.cpp","dome-sculpt-texture-set-export-test"),"final-texture-set-export")
run([exe,out/"final-fixtures"],"final-texture-set-export")
retained=out/"texture-set-source-export"
if not retained.exists():
    retained=link("dome-sculpt-texture-set-source-export-test",
                  compile_object("texture-set-source-export.cpp","dome-sculpt-texture-set-source-export-test"),
                  "final-retained-export")
for format in ("editable","standard"):
    run([retained,"--retained-hdr-"+format,out/("retained-"+format)],"retained-"+format)
print(profile,"full-resolution dense comparison and retained controls passed",flush=True)
