from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
source = root / "source"
output = source / "docs/validation"
name = "native-texture-set-hdr-production-20261127"
archive = output / (name + ".tar.gz")
files = set()

def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def keep(path):
    relative = Path(path)
    files.add(relative)
    return sha(root / relative)

def git(*args):
    return subprocess.check_output(["git","-C",source,*args],text=True).strip()

product = git("rev-parse","HEAD")
assert product.startswith("81231961")
receipt = {
    "baseline": git("rev-parse","HEAD^"),
    "product": product,
    "scope": "Full-application sparse preview and native desktop painting for two 1024-square writable HDR PBR texture-set fields. Standard and Editable GLB for 1024+1024 and 2048+1024 plain independent fields, exact native reopen and preserved production albedo, alpha and ORM.",
    "source_patch_sha256": keep("source.patch"),
    "bounds": {
        "texture_set_maximum_bytes": 256 * 1024 * 1024,
        "texture_set_maximum_work": 64_000_000,
        "2048_probe_creation_maximum_work": 160_000_000,
        "open_preview_and_both_export_workers_use_default_limits": True
    },
    "baseline_probe": {
        "preview_blocker": "Texture-set field preview exceeds its charged work bound",
        "next_original_refusal_after_preview_fix": "Texture-set export exceeds its working budget",
        "initial_log_sha256": keep("baseline-1024.log")
    },
    "profiles": {}, "packages": {}, "frontends": {}, "khronos": {},
    "open": "Production-resolution baked and retained multiset scale, typed MToon sets, alternate original emission coordinates, texture-set HDR VRM, full integrated regression and physical headset verification."
}
assert receipt["baseline_probe"]["preview_blocker"] in (root/"baseline-1024.log").read_text()
for file in ("validate.py","validate-export.py","validate-final.py","public-focus-final.py","xr-public-final.py",
             "xr-focus.py","wayland.py","probe.cpp","record.py","khronos.log"):
    keep(file)
suite = {
    "current-paint-preview-native":8425,
    "texture-set-surfaces":72,
    "texture-set-native":45,
    "final-texture-set-export":127,
    "retained-editable":44,
    "retained-standard":50,
}
for profile in ("release","asan"):
    before = Path(profile)
    directory = Path(profile+"-export")
    checks = dict(suite)
    if (root/directory/"texture-set-source-export.log").exists() and "PASS 6074" in (root/directory/"texture-set-source-export.log").read_text():
        checks["texture-set-source-export"]=6074
    leaf = {"application_sha256":sha(root/directory/"dome-sculpt"),
            "core_archive_sha256":sha(root/directory/"libdome-sculpt-core.a"), "checks":checks}
    receipt["profiles"][profile] = leaf
    for test,count in checks.items():
        log = directory/(test+".log")
        assert re.search(rf"^PASS {count} .*", (root/log).read_text(), re.M)
        keep(log)
    for log in (root/directory).glob("*compile.log"):
        keep(log.relative_to(root))
    for log in (root/directory).glob("*-link.log"):
        keep(log.relative_to(root))
    for log in (root/before).glob("*cpp-compile.log"):
        keep(log.relative_to(root))
    for capture in (before/"archive.log",directory/"archive.log"):
        keep(capture)
    for sizes in ("1024-1024","2048-1024"):
        old = before/("probe-"+sizes+".log")
        new = directory/("probe-"+sizes+".log")
        assert (root/old).read_text().count(receipt["baseline_probe"]["next_original_refusal_after_preview_fix"])==2
        assert (root/new).read_text().count("exact native restore")==2
        keep(old)
        keep(new)

for package in [*(f"probe-{sizes}/{fmt}.glb" for sizes in ("1024-1024","2048-1024") for fmt in ("standard","editable")),
                *(f"final-fixtures/production-{fmt}.glb" for fmt in ("standard","editable"))]:
    release, asan = (root / (profile+"-export") / package for profile in ("release","asan"))
    digest = sha(release)
    assert sha(asan)==digest
    receipt["packages"][package] = {"bytes":release.stat().st_size,"sha256":digest}

for base in ("standard-texture-set-hdr","mixed-standard-hdr","editable-texture-set-hdr"):
    path = base+".glb"
    before = root.parent/"texture-set-hdr-portable-20261127/standard-wip/release-final/checks/plain"/path
    assert sha(before)==sha(root/"release-export"/path)==sha(root/"asan-export"/path)
    receipt["packages"][path]={"sha256":sha(before),"identical_to_previous":True}

relevant_hash = receipt["packages"]["probe-1024-1024/standard.glb"]["sha256"]
for mode in ("wayland","software","arc"):
    directory = Path(mode+"-focus-production-texture-set-hdr")
    status = json.loads((root/directory/"status.json").read_text())
    assert status["exit"]==0 and status["terminal"] and status["native_sha256"]==relevant_hash
    report_data = json.loads((root/directory/"workflow/report.json").read_text())
    assert status["checks"]==len(report_data["checks"]) and all(x["passed"] for x in report_data["checks"])
    assert sha(root/"release-export/probe-1024-1024/source.dsculpt")==status["input_sha256"]
    profile = "asan" if mode=="arc" else "release"
    assert status["app_sha256"]==receipt["profiles"][profile]["application_sha256"]
    receipt["frontends"][mode] = status
    for evidence in (root/directory).rglob("*"):
        if evidence.is_file() and evidence.suffix in (".log",".json",".txt") and "home" not in evidence.parts:
            keep(evidence.relative_to(root))

for line in (root/"khronos.log").read_text().splitlines():
    result = json.loads(line)
    assert result["errors"]==0
    report = result["filename"]+".khronos.json"
    result["report_sha256"] = keep(report)
    receipt["khronos"][result["filename"]]=result

with archive.open("wb") as stream:
    with gzip.GzipFile(filename="",fileobj=stream,mode="wb",mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode="w") as bundle:
            for member in sorted(files):
                path = root/member
                info = bundle.gettarinfo(path,str(member))
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                with path.open("rb") as data:
                    bundle.addfile(info,data)
with tarfile.open(archive) as bundle:
    assert set(member.name for member in bundle.getmembers())==set(map(str,files))
    for path in files:
        assert hashlib.file_digest(bundle.extractfile(str(path)),"sha256").hexdigest()==sha(root/path)
receipt["archive"] = {"file":archive.name,"members":len(files),"sha256":sha(archive)}
(output/(name+".json")).write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
