from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
from concurrent.futures import ThreadPoolExecutor

root=Path(__file__).resolve().parent
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
selected=root/'release/build/native-writable-first-key-2048/converted-2048.dsculpt'
def run(args,label,cwd,check=True):
    with (root/(label+'.log')).open('w') as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        return subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=env,check=check,timeout=180).returncode
def build_and_export(variant):
    profile=(root if variant=='candidate' else root.parent/'first-key-2048-v2-20261126')/'release'
    build=profile/'build'
    entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if Path(e['file']).name=='source-writable-normal-bake.cpp')
    obj=root/(variant+'-composite-parity.o')
    program=root/(variant+'-composite-parity')
    cmd=shlex.split(entry['command'])
    cmd[cmd.index('-o')+1]=str(obj)
    cmd[cmd.index('-c')+1]=str(root/'composite-parity.cpp')
    run(cmd,variant+'-composite-compile',build)
    cmd=shlex.split((profile/'dome-sculpt-source-writable-normal-bake-test-link.log').read_text().splitlines()[0])
    cmd=[str(obj) if word.endswith('/source-writable-normal-bake.cpp.o') else word for word in cmd]
    cmd[cmd.index('-o')+1]=str(program)
    run(cmd,variant+'-composite-link',build)
    dest=root/(variant+'-composite.glb')
    if variant=='baseline':
        denied=root/'baseline-default.glb'
        assert run([program,'default',selected,denied],'baseline-default',build,False)==1 and not denied.exists()
        assert 'exceeds cumulative sample budget' in (root/'baseline-default.log').read_text()
    run([program,'default' if variant=='candidate' else 'diagnostic',selected,dest],variant+'-composite-run',build)
    return dest
with ThreadPoolExecutor(max_workers=2) as pool:
    baseline,candidate=pool.map(build_and_export,('baseline','candidate'))
assert baseline.read_bytes()==candidate.read_bytes()
counts=[int(re.search(r'COMPOSITE_PARITY layers=(\d+)',(root/(v+'-composite-run.log')).read_text())[1]) for v in ('baseline','candidate')]
assert counts[0]==counts[1]
result={'exit':0,'input_sha256':hashlib.file_digest(selected.open('rb'),'sha256').hexdigest(),
        'glb_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),
        'glb_bytes':candidate.stat().st_size,'layers':counts[0]}
(root/'composite-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)
