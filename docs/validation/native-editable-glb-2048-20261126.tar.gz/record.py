from pathlib import Path
import gzip
import hashlib
import io
import json
import struct
import subprocess
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
destination=repo/'docs/validation'
name='native-editable-glb-2048-20261126'
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
files={}
def keep(path,reference=None):
    files[reference or str(path.relative_to(root))]=path
    return sha(path)
product=subprocess.check_output(['git','-C',repo,'rev-parse','7b22726e'],text=True).strip()
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',product])==(root/'source.patch').read_bytes()
record={'product':product,'source_patch_sha256':keep(root/'source.patch'),'profiles':{},'frontend':{},
        'scope':'Native LDR Editable GLB of a fully baked 2048 square retained atlas with an edited shapekey and original Restore. Existing sample limits and published output bytes are preserved.'}
for path in ('run.py','public-focus.py','wayland.py','xr-focus.py','xr-portable-runtime.cpp',
             'xr-portable-runtime-observer-v1.cpp','xr-runtime-build.py','expanded.py','record.py',
             'composite-parity.cpp','composite-proof.py','composite-proof.json','composite-proof-v1.json',
             'baseline-default.log','baseline-composite-run.log','candidate-composite-run.log','khronos-editable.json'):
    keep(root/path)
case_name='native-writable-first-key-2048'
def case(profile):return root/profile/'build'/case_name
for profile in ('release','asan'):
    out=root/profile
    run=read(out/'status.json')
    assert run['terminal'] and run['exit']==0 and len(run['tests'])==13
    assert 'DENSE_EDITABLE 331120 container bytes; native source exact' in (out/'ctest.log').read_text()
    for n in ('status.json','ctest.log','build/regressions.xml','app-link.log','native-authoring-compiler.cpp.log',
              'paint.cpp.log','source-writable-normal-bake.cpp.log','xr-portable-runtime-compile.log','xr-portable-runtime-link.log'):
        keep(out/n)
    expanded=root/('expanded-'+profile)
    assert read(expanded/'status.json')['exit']==0
    assert '100% tests passed, 0 tests failed out of 8' in (expanded/'ctest.log').read_text()
    for n in ('status.json','ctest.log'):
        keep(expanded/n)
    keep(out/'build/expanded.xml')
    assert sha(case(profile)/'editable-native-2048.dsculpt')==sha(case(profile)/'converted-2048.dsculpt')
    record['profiles'][profile]={'ctests':13,'expanded_ctests':8,'application_sha256':run['app_sha256'],
                                 'core_sha256':run['core'],'ctest_log_sha256':sha(out/'ctest.log')}
old=root.parent/'first-key-2048-v2-20261126'
portable=case('release')/'editable-2048.glb'
portable_hash=sha(portable)
assert portable_hash==sha(old/'extra-release/editable-diagnostic-2048.glb')
assert portable_hash==sha(case('asan')/'editable-2048.glb')
data=portable.read_bytes()
length=struct.unpack_from('<I',data,12)[0]
meta=json.loads(data[20:20+length])
extent=[]
for image in meta['images']:
    view=meta['bufferViews'][image['bufferView']]
    offset=28+length+view.get('byteOffset',0)
    assert data[offset:offset+8]==b'\x89PNG\r\n\x1a\n'
    extent.append(struct.unpack_from('>II',data,offset+16))
assert extent==[(2048,2048)]*4
checks=read(root/'khronos-editable.json')['issues']
assert checks['numErrors']==0
record['artifact']={'sha256':portable_hash,'bytes':len(data),'png_dimensions':extent,
    'khronos_errors':checks['numErrors'],'khronos_warnings':checks['numWarnings'],
    'embedded_scene_bytes':meta['extras']['domeSculptAuthoring']['native']['decodedBytes'],
    'recovered_scene_sha256':sha(case('release')/'editable-native-2048.dsculpt')}
for mode,checks in [('wayland',9),('software',10),('arc',10)]:
    out=root/(mode+'-focus-editable')
    state=read(out/'status.json')
    assert state['exit']==0 and state['checks']==checks and state['native_sha256']==portable_hash
    keep(out/'status.json')
    keep(out/'run.log')
    keep(out/'workflow/report.json')
    children=('client.log','compositor.log','runtime-maps.txt') if mode=='wayland' else tuple(f'{name}/{path}' for name in ('accept','focus') for path in ('application.log','graphics.json'))
    for path in children:keep(out/'workflow'/path)
    if mode!='wayland':
        p='asan' if mode=='arc' else 'release'
        state['runtime_sha256']=sha(root/p/'libdome-sculpt-portable-test-runtime.so')
    record['frontend'][mode]=state
replay=root/'software-focus-editable-observer-v1'
assert read(replay/'status.json')['exit']==1
for n in ('run.log','status.json','workflow/report.json','workflow/accept/application.log','workflow/accept/graphics.json'):
    keep(replay/n)
parity=read(root/'composite-proof.json')
assert parity['layers']==14 and parity['exit']==0
assert sha(root/'baseline-composite.glb')==sha(root/'candidate-composite.glb')==parity['glb_sha256']
record['multilayer_parity']=parity
probe=root.parent/'native-hdr-first-key-probe-20261126'
assert (probe/'probe.log').read_text().strip()=='Probe refusal: FLOAT Bake retained channels exceed unchanged paint budget'
for path in ('probe.cpp','probe.log'):
    keep(probe/path,'hdr-probe/'+path)
record['pending_physical_bake']={'resolution':2048,'combined_minimum_bytes':2048*2048*(28+13),
                                'per_paint_byte_cap':128*1024*1024,
                                'refusal':(probe/'probe.log').read_text().strip()}
archive=destination/(name+'.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for name_in_archive,path in sorted(files.items()):
        payload=path.read_bytes()
        member=tarfile.TarInfo(name_in_archive)
        member.size=len(payload)
        tar.addfile(member,io.BytesIO(payload))
record['archive']={'file':archive.name,'sha256':sha(archive),'members':len(files)}
(destination/(name+'.json')).write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(product,record['archive'])
