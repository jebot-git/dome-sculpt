// Overlapping sparse native colour/ORM/emission layers over a real 2048 Bake.
#include "dome/document.hpp"
#include "dome/native-authoring.hpp"
#include "dome/source-uv-bake.hpp"
#include <chrono>
#include <fstream>
#include <iostream>

int main(int argc, char **argv) try {
  if(argc!=4)throw std::invalid_argument("Usage: default|diagnostic input output");
  using namespace dome;
  auto scene=Scene::load(argv[2]);
  const auto paint=scene.active().painted->snapshot();
  Brush brush;
  brush.normal={0,0,1};
  brush.radius=.047f;
  brush.strength=.83f;
  for(unsigned n=0;n<12;++n){
    paint->add_layer("Sparse control "+std::to_string(n));
    if(n==11)continue; // Deliberately allocated layer metadata with no tiles.
    PaintSettings settings;
    settings.front_only=false;
    const auto group=n%4;
    settings.channel=group==0?PaintChannel::Color:
        group==1?PaintChannel::Roughness:group==2?PaintChannel::Metallic:PaintChannel::Emission;
    settings.color={float(n+2)/16,.32f,.83f,float(n+1)/13};
    settings.emission={.8f,float(n+1)/13,.3f};
    settings.roughness=float(n+2)/16;
    settings.metallic=.8f;
    brush.from={.01f*float(n)-.062f,.006f*float(n)-.02f,0};
    brush.to=brush.from+Vec3{.02f,.015f,0};
    paint->begin_stroke();
    paint->stamp(brush,settings);
    if(!paint->end_stroke())throw std::runtime_error("Expected occupied sparse tiles");
    paint->layer_properties("Sparse control "+std::to_string(n),n!=0,float(n+4)/16);
  }
  scene.active().painted=paint;
  scene.validate();
  const bool diagnostic=std::string_view(argv[1])=="diagnostic";
  const auto start=std::chrono::steady_clock::now();
  NativeAuthoringExport owner;
  owner.scene=std::make_shared<const Scene>(scene);
  owner.allow_portable_fallback=true;
  SourceUvBakeOptions policy;
  policy.resolution=512;
  if(diagnostic)policy.max_sample_operations=2ull*1024*1024*1024;
  GltfExportOptions options;
  options.recompute_changed_normals=true;
  export_glb_authoring(owner,argv[3],options,policy);
  const auto seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
  std::cout<<"COMPOSITE_PARITY layers="<<paint->layers().size()<<" seconds="<<seconds<<'\n';
  return 0;
} catch(const std::exception &error) {
  std::cerr<<"Composite proof refusal: "<<error.what()<<'\n';
  return 1;
}
