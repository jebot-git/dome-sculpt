from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import signal
import subprocess
import time

out=Path(__file__).resolve().parent
artifacts=out.parent
source=artifacts/'active-texture-set-bake-desktop-source-20261126'
original=artifacts/'active-texture-set-bake-source-20261126'
donor=artifacts/'active-texture-set-bake-guard-toolkit-validation-20261126/asan'
support=artifacts/'texture-set-recipe-and-hdr-validation-20261126/asan/build'
fixture=artifacts/'active-texture-set-openxr-validation-20261126/asan'
sdk=artifacts/'sdk-20261126/toolkit-sanitize'
node='/dev/dri/renderD129'
def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):
    return json.loads(path.read_text())
state={'candidate':git('rev-parse','HEAD'),'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def record(**values):
    state.update(values)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')
def run(cmd,log,timeout,cwd=None):
    with (out/log).open('w') as dest:
        print(shlex.join(map(str,cmd)),file=dest,flush=True)
        subprocess.run(cmd,cwd=cwd or out,stdout=dest,stderr=subprocess.STDOUT,check=True,timeout=timeout)
def descendants(pid):
    yield pid
    try:
        children=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
    except (ProcessLookupError,FileNotFoundError):
        return
    for child in children:
        yield from descendants(int(child))
try:
    assert state['candidate'].startswith('5ef38b52') and not git('status','--porcelain')
    assert git('diff','--name-only','b8eb5515','HEAD','--','src','include','assets','third_party')=='src/bake-editor.cpp'
    prior=read(donor/'status.json')
    assert prior['terminal'] and prior['exit']==0 and prior['candidate'].startswith('8378901c')
    assert prior['core_sha256']==sha(donor/'libdome-sculpt-core.a')
    seed=read(fixture/'status.json')
    helper=fixture/'dome-sculpt-bake-recipes-test'
    assert seed['candidate'].startswith('b8eb5515') and seed['fixture_sha256']==sha(helper)
    runtime=support/'libdome-sculpt-test-runtime.so'
    assert seed['runtime_sha256']==sha(runtime)
    record(phase='compile exact sanitizer editor',core_sha256=prior['core_sha256'],
           fixture_sha256=sha(helper),runtime_sha256=sha(runtime))
    obj=out/'bake-editor.cpp.o'
    app=out/'dome-sculpt'
    compile=shlex.split((donor/'bake-editor.cpp.o.log').read_text().splitlines()[0])
    compile=[word.replace(str(original),str(source)).replace(str(donor/obj.name),str(obj)) for word in compile]
    run(compile,'compile.log',120)
    link=shlex.split((donor/'dome-sculpt-link.log').read_text().splitlines()[0])
    link=[str(app) if arg==str(donor/'build'/app.name) else str(obj) if arg==str(donor/obj.name) else arg for arg in link]
    run(link,'link.log',180,support)
    workflow=out/'workflow'
    workflow.mkdir(exist_ok=True)
    runner=out/'arc-xr.py'
    script=(source/'tests/bake-recipes-xr.py').read_text()
    assert script.count("'LIBGL_ALWAYS_SOFTWARE':'1'")==1 and script.count("'llvmpipe'")==1
    script=script.replace("'LIBGL_ALWAYS_SOFTWARE':'1'","'LIBGL_ALWAYS_SOFTWARE':'0'").replace("'llvmpipe'","'arc'").replace('explicit software renderer','Intel Arc renderer')
    runner.write_text(script)
    settings={
        'PATH':'/usr/bin:/bin', 'HOME':'/tmp', 'DRI_PRIME':'pci-0000_03_00_0',
        'MESA_SHADER_CACHE_DISABLE':'1', 'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
        'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
        'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
    }
    cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
         '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--dev-bind',node,node]
    for key,value in settings.items():cmd.extend(['--setenv',key,value])
    cmd.extend(['/usr/bin/python3.14',runner,app,runtime,helper,workflow,'--texture-set'])
    record(phase='validate the synthetic XR workflow on Arc with leak checking',app_sha256=sha(app),runner_sha256=sha(runner))
    witnessed={}
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lease, (out/'xr.log').open('w') as log:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        process=subprocess.Popen(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        deadline=time.monotonic()+600
        try:
            while process.poll() is None:
                for pid in descendants(process.pid):
                    proc=Path('/proc')/str(pid)
                    try:
                        if (proc/'exe').resolve()!=app:continue
                        maps=(proc/'maps').read_text()
                        args=(proc/'cmdline').read_bytes().split(b'\0')
                        if b'--save' not in args or 'libasan.so' not in maps or 'libubsan.so' not in maps:continue
                        fds=set()
                        for fd in (proc/'fd').iterdir():
                            try:fds.add(os.readlink(fd))
                            except (ProcessLookupError,FileNotFoundError):continue
                        gallium=[row.rsplit(None,1)[-1] for row in maps.splitlines() if '/libgallium' in row]
                        if node not in fds or not gallium:continue
                        case=Path(os.fsdecode(args[args.index(b'--save')+1])).stem
                        observation={'pid':pid,'node':node,'gallium':sorted(set(gallium))}
                        if case not in witnessed:
                            witnessed[case]=observation
                            record(witnesses=witnessed)
                    except (ProcessLookupError,FileNotFoundError,PermissionError):
                        continue
                if time.monotonic()>deadline:raise TimeoutError('Arc workflow deadline')
                time.sleep(.1)
        finally:
            if process.poll() is None:
                os.killpg(process.pid,signal.SIGTERM)
                process.wait(timeout=15)
    assert process.returncode==0
    checks=read(workflow/'report.json')['checks']
    assert all(row['passed'] for row in checks) and len(checks)==19 and set(witnessed)=={'accept','cancel','focus'}
    record(phase='complete',terminal=True,exit=0,checks=len(checks),report_sha256=sha(workflow/'report.json'))
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
