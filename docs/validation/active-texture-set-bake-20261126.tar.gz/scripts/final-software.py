from pathlib import Path
import hashlib
import json
import os
import subprocess
out=Path(__file__).resolve().parent
base=out.parent
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    return json.loads(path.read_text())
state={'invocation':os.getenv('INVOCATION_ID'),'terminal':False}
def record(**values):
    state.update(values)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')
try:
    source=base/'active-texture-set-bake-desktop-source-20261126'
    candidate=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
    app_build=base/'active-texture-set-wayland-validation-20261126'
    app=app_build/'dome-sculpt'
    runtime=base/'texture-set-recipe-and-hdr-validation-20261126/release/build/libdome-sculpt-test-runtime.so'
    seed=base/'active-texture-set-openxr-validation-20261126/release'
    helper=seed/'dome-sculpt-bake-recipes-test'
    native=read(app_build/'status.json')
    prior=read(seed/'status.json')
    assert candidate==native['candidate'] and native['exit']==0 and native['app_sha256']==sha(app)
    assert prior['exit']==0 and prior['runtime_sha256']==sha(runtime) and prior['fixture_sha256']==sha(helper)
    workflow=out/'workflow';workflow.mkdir(exist_ok=True)
    cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
         '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
         '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
         '--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
         '/usr/bin/python3.14',source/'tests/bake-recipes-xr.py',app,runtime,helper,workflow,'--texture-set']
    record(candidate=candidate,app_sha256=sha(app),runtime_sha256=sha(runtime),fixture_sha256=sha(helper),phase='software replay')
    with (out/'xr.log').open('w') as log:
        subprocess.run(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
    report=workflow/'report.json'
    checks=read(report)['checks']
    assert len(checks)==19 and all(row['passed'] for row in checks)
    record(terminal=True,exit=0,checks=len(checks),report_sha256=sha(report),phase='complete')
except Exception as err:
    record(terminal=True,exit=1,error=repr(err))
    raise
