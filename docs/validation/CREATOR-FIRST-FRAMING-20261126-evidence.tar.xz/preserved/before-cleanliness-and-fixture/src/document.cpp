#include "polygon-surface-preview.hpp"
#include "canonical-paint-native.hpp"
#include "dome/bake-distance.hpp"
#include "dome/bake-recipe.hpp"
#include "paint-overlay-packet.hpp"
// SPDX-License-Identifier: GPL-3.0-or-later
#include "emission-export.hpp"
#include "emission-control-scale.hpp"
#include "emission-source-info.hpp"
#include "dome/document.hpp"
#include "skin-methods.hpp"
#include "native-paint-sampling.hpp"
#include "dome/scene-file.hpp"
#include "dome/native-authoring.hpp"
#include "dome/source-uv-bake.hpp"
#include "dome/normal-sampling.hpp"
#include "normal-preparation-state.hpp"
#include "cut-color.hpp"
#include "affine-surface.hpp"
#include "source-skin-world.hpp"
#include "shapekey-preview.hpp"
#include "shapekey-mirror-controls.hpp"
#include "document-authority.hpp"
#include "polygon-conversion.hpp"
#include "document-polygon-authority.hpp"
#include "document-authority-transition.hpp"
#include "dome/tangents.hpp"
#include "dome/creation.hpp"
#include "dome/rig-edit.hpp"
#include "dome/vrm.hpp"
#include "dome/vrm-authoring.hpp"
#include "editable-avatar-eligibility.hpp"
#include "dome/gltf-export.hpp"
#include "dome/mesh-processing.hpp"
#include "dome/mesh-authoring.hpp"
#include "dome/material-visibility.hpp"
#include "dome/frame-clock.hpp"
#include "normal-frame-runtime.hpp"
#include "paint-source-admission.hpp"
#include "emission-authority.hpp"
#include "export-corner-coordinates.hpp"
#include "dome/paint-sampling.hpp"
#include "dome/normal-preview.hpp"
#include "current-colors.hpp"
#include "prepared-color-state.hpp"
#include "sculpt-ui-values.hpp"
#include "dome/local-surface.hpp"
#include "geometry-identity.hpp"
#include "texture-set-worker.hpp"
#include "texture-set-stroke.hpp"
#include "texture-set-controls.hpp"
#include "texture-set-surface.hpp"
#include "sculpt-scene-chunks.hpp"
#include "document-transaction.hpp"
#include "document-retopo-input.hpp"
#include "spatial-history-levels.hpp"
#include <unistd.h>
#include <utility>
#include <numeric>
#include <unordered_map>
#include <unordered_set>
#include <limits>
namespace dome {
namespace {
ob::Vec3 obv(Vec3 p) { return {p.x, p.y, p.z}; }
Vec3 vec(ob::Vec3 p) { return {p.x, p.y, p.z}; }
bool retained_avatar(const SculptObject &object) {
  if (!object.appearance)
    return false;
  if (object.appearance->vrm_json)
    return true;
  const auto &asset = object.appearance->asset;
  return asset && asset->mode == ImportMode::PreserveGltf &&
         asset->avatar_version != ImportedAvatarVersion::None;
}
uint64_t avatar_group(const Scene &scene, uint64_t object) {
  auto group = scene.object(object).group;
  auto path = scene.group_path(group);
  for (auto it = path.rbegin(); it != path.rend(); ++it)
    if (it->humanoid)
      return it->id;
  const auto &appearance = scene.object(object).appearance;
  if (retained_avatar(scene.object(object)))
    for (auto it = path.rbegin(); it != path.rend(); ++it) {
      if (!it->source_placement || !it->source_placement->model ||
          it->source_placement->model->asset != appearance->asset ||
          it->source_placement->model->original_bytes !=
              appearance->original_bytes)
        continue;
      const auto instance = it->source_placement->source_instance;
      if (std::any_of(path.begin(), path.end(),
                      [&](const auto &g) { return g.id == instance; }))
        return instance;
    }
  return group;
}
bool in_group(const Scene &scene, const SculptObject &object, uint64_t group) {
  auto path = scene.group_path(object.group);
  return group && std::any_of(path.begin(), path.end(), [group](const auto &g) { return g.id == group; });
}
} // namespace
Document::Document() : input_(volume()) {
  input_.radius = state_.radius;
  input_.allowed = [this](SpatialCommand command) {
    return command_enabled_locked(command);
  };
  input_.parameter_allowed = [this](VrParameter parameter) {
    return parameter_enabled_locked(parameter);
  };
  input_.control_accept = [this] {
    return !uv_ || (!uv_solving_ && !uv_accept_pending_ &&
                    (uv_->view().valid || uv_->view().validating));
  };
  input_.committed = [this] { record_stroke_locked(); };
  input_.backend = {[this] { return action_active_locked(); },
                    [this] { begin_action_locked(); },
                    [this] { cancel_action_locked(); },
                    [this](const Brush &b) { stamp_action_locked(b); },
                    [this] { return end_action_locked(); }};
  published_.store(std::make_shared<EditorState>(state_));
  mesh_.store(std::make_shared<MeshSnapshot>());
  try {
    mesh_thread_ = std::thread([this] { mesh_loop(); });
    input_thread_ = std::thread([this] { input_loop(); });
    file_thread_ = std::thread([this] { file_loop(); });
    uv_thread_ = std::thread([this] { uv_loop(); });
    retopo_thread_ = std::thread([this] { retopo_loop(); });
    cut_thread_ = std::thread([this] { cut_loop(); });
    native_thread_ = std::thread([this] { native_loop(); });
    polygon_thread_ = std::thread([this] { polygon_loop(); });
  } catch (...) {
    request_worker_stop();
    {
      std::lock_guard lock(file_mutex_);
      files_stopping_ = true;
    }
    file_changed_.notify_all();
    if (input_thread_.joinable())
      input_thread_.join();
    if (mesh_thread_.joinable())
      mesh_thread_.join();
    if (file_thread_.joinable())
      file_thread_.join();
    if (uv_thread_.joinable())
      uv_thread_.join();
    if (retopo_thread_.joinable()) retopo_thread_.join();
    if (cut_thread_.joinable()) cut_thread_.join();
    if (native_thread_.joinable()) native_thread_.join();
    if (polygon_thread_.joinable()) polygon_thread_.join();
    throw;
  }
}
void Document::request_worker_stop() {
  stopping_ = true;
  // The flag is atomic for long-running jobs, but condition waiters still
  // require a handshake with EACH predicate mutex. Otherwise a notification
  // can arrive after a false predicate check and before wait registration.
  { std::lock_guard lock(mesh_mutex_); mesh_changed_.notify_all(); }
  { std::lock_guard lock(input_mutex_); input_changed_.notify_all(); }
  { std::lock_guard lock(uv_mutex_); uv_changed_.notify_all(); }
  { std::lock_guard lock(retopo_mutex_); retopo_changed_.notify_all(); }
  { std::lock_guard lock(cut_mutex_); cut_changed_.notify_all(); }
  { std::lock_guard lock(native_mutex_); native_changed_.notify_all(); }
  { std::lock_guard lock(polygon_mutex_); polygon_changed_.notify_all(); }
}
Document::~Document() {
  drain_polygon_shutdown();
  drain_native_shutdown();
  drain_asset_shutdown();
  request_worker_stop();
  input_thread_.join();
  {
    std::lock_guard lock(file_mutex_);
    files_stopping_ = true;
  }
  file_changed_.notify_all();
  mesh_thread_.join();
  file_thread_.join();
  uv_thread_.join();
  retopo_thread_.join();
  cut_thread_.join();
  native_thread_.join();
  polygon_thread_.join();
}
EditorSnapshot Document::frame() const {
  auto state = published_.load();
  auto mesh = mesh_.load();
  if (mesh->generation != state->generation) {
    static const auto empty = std::make_shared<MeshSnapshot>();
    mesh = empty;
  }
  return {state, mesh};
}
Volume Document::copy_volume() const {
  std::lock_guard lock(model_mutex_);
  return volume().geometry_snapshot();
}
Scene Document::copy_scene() const {
  std::lock_guard lock(model_mutex_);
  return scene_.snapshot();
}
bool Document::action_active_locked() const {
  if(native_stroke_)return true;
  if (polygon_stroking_) return true;
  if (retopo_stroking_) return true;
  if (weight_stroking_) return true;
  auto &o = scene_.active();
  return o.mesh_active ? o.painted->in_stroke() : volume().in_stroke();
}
bool Document::pending_locked() const {
  if(state_.creator)return true;
  if(state_.expressions)return true;
  if(state_.polygon)return state_.polygon->changed||polygon_stroking_||polygon_pending_.load()!=0;
  if(state_.object_grabbing)return true;
  if(native_stroke_)return true;
  if(state_.cut)return state_.cut->busy||(state_.cut->preview&&state_.cut->preview->changed);
  if (state_.retopology) return state_.retopology->changed || retopo_stroking_ || retopo_pending_ != 0;
  if (weight_stroking_) return !weight_samples_.empty();
  auto &o = scene_.active();
  return o.mesh_active ? o.painted->pending_changes()
                       : volume().pending_changes();
}
bool Document::reject_texture_paint_locked() {
  const auto &o=scene_.active();
  if(!o.mesh_active || !o.painted)return false;
  const auto field=active_texture_set(o);const auto&paint=*field.painted;
  const bool raw_physical=paint.surface_diagnostics().policy==PaintUvPolicy::SourceAuthored &&
      !paint.source_sampling_prepared() &&
      (detail::hdr_emission(field.material.emissive)||paint.has_physical_emission()||
       (field.material_bindings&&detail::physical_emission(*field.material_bindings))||
       (state_.paint.channel==PaintChannel::Emission&&state_.paint.emission_units==PaintEmissionUnits::Physical));
  if(!raw_physical&&!detail::paint_requires_editable_atlas(paint))return false;
  Transaction transaction(*this);
  state_.message=detail::editable_texture_atlas_notice;
  state_.error.clear();publish_locked(false,false);transaction.commit(false);
  return true;
}
void Document::begin_action_locked() {
  if(state_.polygon)throw std::logic_error("Use polygon selection and move controls while polygon editing is open");
  if(scene_.active().polygon&&scene_.active().polygon->active&&!scene_.active().mesh_active)throw std::logic_error("The empty polygon object has no sculptable surface; reopen polygon tools or restore its source");
  require_object_editable_locked(scene_.active().id);
  state_.message.clear();
  if (state_.retopology) {
    queue_retopology_locked(RetopoAction::BeginGesture);
    retopo_stroking_ = true; retopo_sampled_ = false; return;
  }
  if (state_.weights.enabled) {
    if (!state_.can_paint_weights || state_.asset_busy)
      throw std::logic_error("Skin weight painting is unavailable");
    auto mesh = mesh_.load();
    if (mesh->generation != state_.generation || mesh->revision != state_.revision)
      throw std::logic_error("Wait for the current weight view before painting");
    state_.weights.validate(scene_.active().deformation->skeleton->bones.size());
    state_.error.clear();
    weight_stroking_ = true; weight_samples_.clear();
    ++weight_epoch_; weight_base_ = std::move(mesh);
    weight_source_ = {state_.generation, state_.revision, scene_.active().id,state_.edit_authority};
    weight_stroke_settings_ = state_.weights;
    if(state_.object_grabbing || (state_.isolate_held&&state_.held_object))weight_stroke_settings_.linked=false;
    weight_joint_ = uint32_t(state_.rig_joint);
    return;
  }
  if(scene_.active().texture_sets)throw std::logic_error("Texture-set painting requires its owning native field transaction");
  if(reject_texture_paint_locked())throw std::logic_error(detail::editable_texture_atlas_notice);
  if (scene_.active().mesh_active)
    scene_.active().painted->begin_stroke();
  else
    volume().begin_stroke();
}
void Document::stamp_action_locked(const Brush &b) {
  require_object_editable_locked(scene_.active().id);
  if (retopo_stroking_) {
    if (b.pressure > 0) {
      queue_retopology_locked(RetopoAction::Sample, b.to, retopo_sampled_);
      retopo_sampled_ = true;
    }
    return;
  }
  if (weight_stroking_) {
    if (!finite(b.from) || !finite(b.to) || !std::isfinite(b.radius) || b.radius <= 0 ||
        !std::isfinite(b.pressure) || b.pressure < 0 || b.pressure > 1)
      throw std::invalid_argument("Invalid weight stroke geometry or pressure");
    if (!b.pressure) return;
    if (weight_samples_.size() >= 4096) throw std::length_error("Weight gesture sample budget exceeded");
    WeightBrush sample; sample.from = b.from; sample.to = b.to;
    sample.radius = b.radius; sample.pressure = b.pressure; sample.strength = 1;
    sample.joint = weight_joint_; weight_samples_.push_back(sample);
    return;
  }
  if (scene_.active().mesh_active)
    scene_.active().painted->stamp(b, state_.paint);
  else {
    size_t used = 0;
    for (auto &o : scene_.objects())
      if (o.id != scene_.active().id)
        used += std::max(o.volume->stored_samples(), o.volume->voxels().size());
    if (used > 4'000'000)
      throw std::length_error("Scene sculpt sample budget exceeded");
    volume().stamp(b, 4'000'000 - used);
  }
}
bool Document::end_action_locked() {
  if(polygon_stroking_){PolygonJob job;job.action=PolygonAction::EndDrag;queue_polygon_locked(std::move(job));polygon_stroking_=false;return false;}
  if (retopo_stroking_) {
    queue_retopology_locked(RetopoAction::EndGesture);
    retopo_stroking_ = retopo_sampled_ = false; return false;
  }
  if (weight_stroking_) {
    weight_stroking_ = false;
    auto base = weight_base_;
    invalidate_weight_view_locked(false);
    auto samples = std::move(weight_samples_); weight_samples_.clear();
    if (samples.empty()) { restore_weight_view_locked(base); return false; }
    auto settings = weight_stroke_settings_;
    if(state_.isolate_held&&state_.held_object)settings.linked=false;
    auto object = weight_source_.object;
    auto report = std::make_shared<std::string>(); auto changed = std::make_shared<bool>(false);
    try {
    auto held_work=std::make_shared<AssetWork>();held_work->held_weight=state_.object_grabbing;
    queue_scene_operation_locked("Paint skin weights",
      [samples = std::move(samples), settings, object, report, changed](Scene &scene, const auto &cancelled) {
        auto result = paint_scene_weights(scene, object, samples, settings, cancelled);
        *changed = result.changed != 0;
        *report = std::to_string(result.changed) + " vertices changed, " +
                  std::to_string(result.constrained) + " constrained";
        for (const auto &message : result.diagnostics) *report += "; " + message;
      }, weight_source_, report, held_work, changed, base);
    } catch (...) { restore_weight_view_locked(base); throw; }
    return false;
  }
  return scene_.active().mesh_active ? scene_.active().painted->end_stroke()
                                     : volume().end_stroke();
}
void Document::cancel_action_locked() {
  if(polygon_stroking_){PolygonJob job;job.action=PolygonAction::CancelDrag;queue_polygon_locked(std::move(job));polygon_stroking_=false;return;}
  if (retopo_stroking_) {
    queue_retopology_locked(RetopoAction::CancelGesture);
    retopo_stroking_ = retopo_sampled_ = false; return;
  }
  if (weight_stroking_) {
    weight_stroking_ = false; weight_samples_.clear();
    invalidate_weight_view_locked(true);
    state_.error.clear(); state_.message = "Weight gesture cancelled"; return;
  }
  if (scene_.active().mesh_active)
    scene_.active().painted->cancel_stroke();
  else
    volume().cancel_stroke();
}
void Document::restore_weight_view_locked(const std::shared_ptr<const MeshSnapshot> &base) {
  if (!base || base->generation != state_.generation || base->revision != state_.revision || base->view_epoch!=state_.view_epoch) return;
  std::lock_guard lock(mesh_mutex_);
  mesh_.store(base);
  mesh_changed_.notify_all();
}
void Document::invalidate_weight_view_locked(bool restore) {
  std::lock_guard lock(mesh_mutex_);
  ++weight_epoch_;
  if (pending_mesh_ && pending_mesh_->weight_gesture) pending_mesh_.reset();
  if (restore && weight_base_ && weight_base_->generation == state_.generation &&
      weight_base_->revision == state_.revision && weight_base_->view_epoch==state_.view_epoch) mesh_.store(weight_base_);
  weight_base_.reset();
  mesh_changed_.notify_all();
}
void Document::record_locked(History entry) {
  if(transaction_){transaction_->record(std::move(entry));return;}
  if(next_content_==UINT64_MAX)throw std::overflow_error("Document history identity exhausted");
  entry.from = content_;
  entry.to = next_content_;
  // Allocate the history node before changing redo or content identities.
  // Callers that swap authority before constructing History still need their
  // own staging/rollback; this does not make those generic callers atomic.
  undo_.push_back(std::move(entry));
  content_ = next_content_++;
  redo_.clear();
  while (undo_.size() > 128)undo_.pop_front();
}

void Document::record_stroke_locked() {
  History h;
  if (scene_.active().mesh_active)
    h.paint = scene_.active().painted;
  else
    h.sculpt = scene_.active().volume;
  auto volume_target = h.sculpt;
  auto paint_target = h.paint;
  record_locked(std::move(h));
  auto matches = [&](const History &entry) {
    return paint_target ? entry.paint == paint_target
                        : entry.sculpt == volume_target;
  };
  size_t available =
      paint_target ? paint_target->undo_count() : volume_target->undo_count();
  size_t count = std::count_if(undo_.begin(), undo_.end(), matches);
  for (auto it = undo_.begin(); count > available && it != undo_.end();) {
    if (matches(*it)) {
      it = undo_.erase(it);
      --count;
    } else
      ++it;
  }
}
void Document::bind_locked(bool preserve_menu) {
  input_.bind(volume(),preserve_menu);
  bound_volume_ = scene_.active().volume;
  last_volume_ = volume().revision();
  last_paint_ =
      scene_.active().mesh_active ? scene_.active().painted->revision() : 0;
  ++state_.input_epoch;
  if(transaction_){transaction_->rebind();return;}
  std::lock_guard lock(input_mutex_);
  inputs_.clear();
  reset_input_ = false;
  input_changed_.notify_all();
}
void Document::scene_changed_locked(Scene before) {
  // Put authority back before constructing any allocating rollback/history
  // state. A failure even in the Transaction constructor retains the source.
  Scene candidate=std::move(scene_);scene_=std::move(before);
  Transaction transaction(*this);
  if(state_.polygon)transaction.cancel_polygon();
  scene_=std::move(candidate);
  detail::require_trusted_polygon_transition(transaction.before(),scene_);
  scene_.validate(false);
  if(state_.selection_focus&&scene_.active().id!=transaction.before().active().id)state_.selected_objects={scene_.active().id};
  record_locked({{},transaction.before(),scene_});
  bind_locked();publish_locked(true,false);transaction.commit();
}
bool Document::undo_locked(bool redo) {
  AuthorityTransition authority(*this);
  auto &source=redo?redo_:undo_,&dest=redo?undo_:redo_;
  if(source.empty())return false;
  const auto &h=source.back();
  const bool cut_held=h.held_before&&h.held_after&&state_.held_object==(redo?h.held_before:h.held_after);
  if(state_.held_object){invalidate_object_authority_locked();state_.held_object=0;}
  Transaction transaction(*this);
  std::shared_ptr<Volume> sculpt;
  std::shared_ptr<PaintedMesh> paint;
  if(h.paint){
    paint=std::make_shared<PaintedMesh>(*h.paint);
    if(!(redo?paint->redo():paint->undo()))return false;
    bool found=false;
    for(const auto &o:scene_.objects())if(o.painted==h.paint){auto &target=scene_.object(o.id);target.painted=paint;target.mesh_active=true;scene_.select(o.id);found=true;}
    if(!found)throw std::logic_error("Paint history target is unavailable");
  }else if(h.sculpt){
    sculpt=std::make_shared<Volume>(*h.sculpt);
    if(!(redo?sculpt->redo():sculpt->undo()))return false;
    bool found=false;
    for(const auto &o:scene_.objects())if(o.volume==h.sculpt){auto &target=scene_.object(o.id);target.volume=sculpt;target.mesh_active=false;scene_.select(o.id);found=true;}
    if(!found)throw std::logic_error("Sculpt history target is unavailable");
  }else scene_=redo?*h.after:*h.before;
  if(cut_held){state_.held_object=redo?h.held_after:h.held_before;state_.selected_objects={state_.held_object};}
  if(state_.selection_focus&&scene_.active().id!=transaction.before().active().id)state_.selected_objects={scene_.active().id};
  transaction.move_history(source,dest);
  content_=redo?h.to:h.from;bind_locked();publish_locked(true,false);
  // Preserve the target identities referenced by all older history commands.
  // No throwing work remains, and meshing owns its detached immutable copy.
  if(paint){
    h.paint->swap_state(*paint);
    for(const auto &o:scene_.objects())if(o.painted==paint)scene_.object(o.id).painted=h.paint;
  }
  if(sculpt){
    h.sculpt->swap_state(*sculpt);
    for(const auto &o:scene_.objects())if(o.volume==sculpt)scene_.object(o.id).volume=h.sculpt;
    input_.refresh_volume(volume());bound_volume_=scene_.active().volume;
  }
  transaction.commit();authority.commit();return true;
}
void Document::replace(Volume next, bool clean) {
  Scene scene;
  scene.active().volume = std::make_shared<Volume>(std::move(next));
  replace(std::move(scene), clean);
}
uint64_t Document::add_object(bool sphere) {
  std::lock_guard lock(model_mutex_);
  if(state_.isolate_held && state_.held_object)throw std::logic_error("Release held-object isolation before creating another object");
  finish_locked();
  Scene before = scene_;
  Volume next(volume().voxel_size());
  if (sphere) {
    next.begin_stroke();
    Brush b;
    b.radius = .25f;
    b.blend = 0;
    next.stamp(b);
    next.end_stroke();
  }
  CanvasTransform transform = scene_.world_transform(scene_.active().id);
  transform.position.x += .6f;
  auto id = scene_.add(sphere ? "Clay sphere" : "Empty sculpt", std::move(next),
                       transform);
  scene_changed_locked(std::move(before));
  return id;
}
void Document::duplicate_object() {
  std::lock_guard lock(model_mutex_);
  require_object_editable_locked(scene_.active().id);
  if(state_.isolate_held&&state_.held_object)throw std::logic_error("Release held-object isolation before duplicating an object");
  finish_locked();
  Scene before = scene_;
  auto id = scene_.duplicate(scene_.active().id);
  auto &o = scene_.object(id);
  o.transform.position.x = std::min(100.f, o.transform.position.x + .6f);
  scene_changed_locked(std::move(before));
}
void Document::delete_object() {
  std::lock_guard lock(model_mutex_);
  require_object_editable_locked(scene_.active().id);
  if(state_.held_object==scene_.active().id){invalidate_object_authority_locked();state_.held_object=0;}
  finish_locked();
  Scene before = scene_;
  scene_.erase(scene_.active().id);
  scene_changed_locked(std::move(before));
}
void Document::select_object(uint64_t id) {
  std::lock_guard lock(model_mutex_);
  if(state_.selection_focus){select_objects_locked(std::span<const uint64_t>(&id,1),ObjectSelection::Replace);return;}
  if(state_.object_grabbing&&id!=state_.held_object)throw std::logic_error("Release the moving object before changing selection");
  finish_locked();
  scene_.select(id);
  bind_locked();
  publish_locked();
}
void Document::object_properties(uint64_t id, std::string name, bool visible,
                                 bool locked, CanvasTransform transform,
                                 Material material,AssetSource expected) {
  object_properties(id,std::move(name),visible,locked,transform,std::move(material),expected,{});
}
void Document::object_properties(uint64_t id, std::string name, bool visible,
                                 bool locked, CanvasTransform transform,
                                 Material material,AssetSource expected,
                                 std::optional<std::array<float,3>> emission_override) {
  if(emission_override)for(float v:*emission_override)if(!std::isfinite(v)||v<0||v>maximum_native_emission)
    throw std::invalid_argument("Absolute emission must remain within the native linear radiance bound");
  material.validate();
  validate_transform(transform);
  std::lock_guard lock(model_mutex_);
  AuthorityTransition authority(*this);require_authority_locked(expected);
  if((expected.generation&&expected.generation!=state_.generation)||(expected.revision&&expected.revision!=state_.revision)||(expected.object&&expected.object!=id))throw std::logic_error("Object properties changed; reopen the editor");
  const auto &old=scene_.object(id);
  if(emission_override&&(!old.material_bindings||!old.material_bindings->physical_emission))
    throw std::logic_error("The absolute emission source changed; reopen object properties");
  const bool emission_changed=emission_override&&*emission_override!=*old.material_bindings->physical_emission;
  const bool visibility_only=!emission_changed && old.name==name && old.locked==locked && detail::same_transform(old.transform,transform) && detail::same_material(old.material,material);
  const bool lock_only=!emission_changed && old.name==name && old.visible==visible && detail::same_transform(old.transform,transform) && detail::same_material(old.material,material) && (!state_.isolate_held || !state_.held_object || id==state_.held_object);
  if(!visibility_only && !lock_only)require_object_editable_locked(id);
  if(state_.held_object==id && (!visible || locked)){invalidate_object_authority_locked();state_.held_object=0;}
  finish_locked();
  auto emission_binding=scene_.object(id).material_bindings;
  if(emission_changed){
    auto binding=std::make_shared<SourceMaterialBindings>(*emission_binding);
    binding->physical_emission=emission_override;binding->validate();emission_binding=std::move(binding);
  }
  Scene before = scene_;
  auto &o = scene_.object(id);
  o.material_bindings=std::move(emission_binding);
  o.name = std::move(name);
  o.visible = visible;
  o.locked = locked;
  o.transform = transform;
  o.material = std::move(material);
  scene_changed_locked(std::move(before));authority.commit();
}
void Document::publish_locked(bool force,bool checkpoint) {
  auto previous_state=state_;
  const auto previous_volume=last_volume_,previous_paint=last_paint_,previous_rig=rig_object_;
  const auto previous_control_changed=control_changed_,previous_solving=uv_solving_;
  const auto previous_control_source=control_source_;
  try {
  auto &active = scene_.active();
  if(state_.selection_focus&&active.id!=state_.active_object&&std::find(state_.selected_objects.begin(),state_.selected_objects.end(),active.id)==state_.selected_objects.end())state_.selected_objects={active.id};
  const bool cancel_polygon_publication=state_.polygon &&
    (polygon_source_.generation!=state_.generation || polygon_source_.object!=active.id || polygon_source_.edit_authority!=state_.edit_authority);
  if(cancel_polygon_publication){state_.polygon.reset();state_.polygon_object=0;
    if(polygon_accept_&&asset_work_.load()==polygon_accept_->work)state_.asset_busy=false;}
  if(state_.shape_sculpt&&(state_.shape_sculpt_object!=active.id||!active.mesh_active||!active.deformation||
    !active.deformation->morphs||active.deformation->morphs->targets.empty()||state_.weights.enabled||state_.polygon||state_.cut||state_.retopology||uv_)){
    state_.shape_sculpt=false;state_.shape_sculpt_object=0;force=true;
  }
  uint64_t paint_revision = active.mesh_active ? active.painted->revision() : 0;
  bool changed = force || last_volume_ != volume().revision() ||
                 last_paint_ != paint_revision;
  if (changed) {
    last_volume_ = volume().revision();
    last_paint_ = paint_revision;
    ++state_.revision;
  }
  if(state_.expressions&&!expression_source_matches_locked()){
    if(state_.view_epoch==UINT64_MAX)throw std::overflow_error("Expression view identity exhausted");
    state_.expressions.reset();++state_.view_epoch;
  }
  if(state_.rig_fit&&!rig_fit_source_matches_locked())state_.rig_fit.reset();
  if(state_.polygon_handoff&&state_.polygon_handoff_revision==UINT64_MAX)state_.polygon_handoff_revision=state_.revision;
  if(state_.polygon_handoff&&(state_.polygon_handoff_generation!=state_.generation||state_.polygon_handoff_revision!=state_.revision||state_.polygon_handoff_object!=active.id||!object_editable_locked(active.id))) {
    state_.polygon_handoff.reset();state_.polygon_handoff_object=0;
  }
  state_.can_polygon=!state_.asset_busy&&!state_.recovery_busy&&!uv_&&!state_.retopology&&!state_.cut&&!import_view_&&object_editable_locked(active.id);
  state_.polygon_requires_conversion=polygon_conversion_required(active);
  state_.polygon_has_source=active.polygon&&bool(active.polygon->origin);
  state_.project_path = path_;
  state_.importing = import_view_;
  state_.active_object = scene_.active().id;
  state_.can_select_objects=selection_ready_locked();
  selection_hierarchy_locked();
  state_.objects.clear();
  for (auto &o : scene_.objects()) {
    const bool affine=scene_.has_affine_placement(o.id);
    state_.objects.push_back({o.id, o.name, o.visible, o.locked, o.transform,
                              o.material, o.mesh_active, bool(o.painted),object_editable_locked(o.id),
                              o.visible && ((state_.isolate_held && state_.held_object && o.id!=state_.held_object) || (state_.selection_focus && std::find(state_.selected_objects.begin(),state_.selected_objects.end(),o.id)==state_.selected_objects.end())),
                              affine?CanvasTransform{}:object_world_transform_locked(o.id),!affine});
    auto &display=state_.objects.back();
    display.selected=std::find(state_.selected_objects.begin(),state_.selected_objects.end(),o.id)!=state_.selected_objects.end();
    display.active=display.selected&&o.id==state_.active_object;display.selection_accent=state_.accent;
    display.hovered=state_.selection_mode&&(state_.selection_hover[0]==o.id||state_.selection_hover[1]==o.id);
    if(affine)display.affine_world=object_world_matrix_locked(o.id);
  }
  if (uv_)
    control_changed_ = uv_changed(
        *uv_->view().mesh, scene_.object(control_object_).painted->mesh())||uv_retention_changes_locked();
  auto uv_job=prepare_uv_schedule_locked();
  const bool reset_uv=uv_&&!uv_accept_pending_&&!uv_solving_&&!uv_->view().validating&&!uv_scheduled_.expired();
  if(uv_job&&uv_job->workspace){
    control_source_={state_.generation,state_.revision,control_object_,state_.edit_authority};uv_solving_=true;state_.message="Preparing UV charts...";
  }
  if (uv_) {
    auto view = std::make_shared<UvView>(uv_->view());
    const auto &source=scene_.object(control_object_);
    view->normal_sampling_available=source.material_bindings&&(source.material_bindings->canonical_attributes||(source.painted&&source.painted->normal_projection()&&source.material_bindings->normal_preparation));
    view->normal_sampling_required=view->normal_sampling_available&&(source.material_bindings->canonical_attributes||(source.painted->normal_projection()&&source.painted->normal_projection()->version==2));
    view->retain_normal_sampling=uv_retention_requested_locked();
    view->paint_sampling_available=uv_paint_retention_available_locked();
    view->paint_sampling_required=detail::canonical_paint_retention_supported(source)||bool(source.painted&&source.painted->paint_sampling_domain());
    view->retain_paint_sampling=uv_paint_retention_requested_locked();
    view->can_restore_paint_source=detail::canonical_paint_source_restorable(source)||detail::native_paint_source_restorable(source);
    view->committing = uv_accept_pending_;
    view->solving = uv_solving_;
    if (view->solving) { view->can_undo = view->can_redo = false; view->valid = false; }
    if (view->committing) {
      view->valid = false;
      view->can_undo = view->can_redo = false;
      view->error = "Applying UVs...";
    }
    state_.uv = std::move(view);
  } else
    state_.uv.reset();
  state_.deformation = active.deformation;
  if (rig_object_ != active.id) {
    rig_object_ = active.id;
    state_.rig_joint = state_.morph_target = 0;
    state_.weights.locks.clear();
  }
  if (active.deformation) {
    auto &d = *active.deformation;
    if (d.skeleton) state_.rig_joint = std::min(state_.rig_joint, d.skeleton->bones.size() - 1);
    if (d.morphs && !d.morphs->targets.empty())
      state_.morph_target = std::min(state_.morph_target, d.morphs->targets.size() - 1);
  }
  state_.mesh_active = active.mesh_active;
  state_.can_author_shapes=shape_target_ready_locked();
  state_.can_restore_shapes=state_.can_author_shapes&&bool(active.shape_source);
  state_.can_select_shape=state_.can_author_shapes&&active.deformation&&active.deformation->morphs&&!active.deformation->morphs->targets.empty();
  state_.can_cut = !state_.shape_sculpt && detail::cut_color_supported(active) && !state_.polygon && !state_.cut && !state_.retopology && !uv_ && !state_.asset_busy && !state_.recovery_busy && !control_before_ &&
      !action_active_locked() && object_editable_locked(active.id) && scene_.objects().size()<=254 && scene_.groups().size()<128 &&
      (active.mesh_active||!active.volume->voxels().empty());
  state_.skin_sources=skin_sources_locked(state_.skin_options.mode);
  if(std::find(state_.skin_sources.begin(),state_.skin_sources.end(),state_.skin_options.reference)==state_.skin_sources.end()) {
    auto self=std::find(state_.skin_sources.begin(),state_.skin_sources.end(),active.id);
    state_.skin_options.reference=self!=state_.skin_sources.end()?active.id:
      state_.skin_sources.empty()?0:state_.skin_sources.front();
  }
  state_.can_configure_skin=skin_target_ready_locked() && !skin_sources_locked(SkinAuthoringMode::Automatic).empty();
  state_.can_bind_skin=skin_target_ready_locked() && !state_.skin_sources.empty() &&
    !(state_.skin_options.mode==SkinAuthoringMode::SurfaceHeat&&state_.selected_objects.size()>1&&!selected_skin_ready_locked(SkinAuthoringMode::SurfaceHeat));
  state_.can_retopologize = !state_.polygon && !state_.cut && !state_.retopology && !uv_ && !state_.asset_busy && !state_.recovery_busy &&
      !control_before_ && !action_active_locked() && object_editable_locked(active.id) &&
      scene_.objects().size() < 256 && (active.mesh_active || !active.volume->voxels().empty());
  if(state_.bake_settings_object!=active.id||state_.bake_recipe!=active.bake_recipe){
    if(active.bake_recipe){state_.bake_source=active.bake_recipe->source.object;state_.bake_settings=active.bake_recipe->settings;}
    state_.bake_settings_object=active.id;state_.bake_recipe=active.bake_recipe;
  }
  state_.bake_sources = bake_sources_locked();
  state_.bake_cages = bake_cages_locked();
  if(std::find(state_.bake_sources.begin(),state_.bake_sources.end(),state_.bake_source)==state_.bake_sources.end())
    state_.bake_source=state_.bake_sources.empty()?0:state_.bake_sources.front();
  state_.can_bake=!state_.object_grabbing && bake_target_ready_locked() && !state_.bake_sources.empty();
  state_.can_clear_bake=!state_.object_grabbing && bake_target_ready_locked() && bool(active.painted->baked());
  state_.can_blur_color_layer=command_enabled_locked(SpatialCommand::BlurColorLayer);
  state_.can_convert_bake=canonical_conversion_ready_locked();
  auto work=asset_status();state_.can_cancel_asset=state_.asset_busy && work.cancellable;
  state_.can_cancel_asset|=bool(state_.creator);
  state_.can_cancel_asset|=projection_load_&&!projection_load_->done.load()&&!projection_load_->cancelled.load();
  const auto asset=asset_work_.load();
  state_.can_save_after_asset=state_.asset_busy&&asset&&asset->accepted_scene&&!asset->cancelled.load();
  state_.pending_exports=0;
  for(const auto &export_work:exports_)if(export_work) {
    ++state_.pending_exports;
    state_.can_cancel_asset|=export_work->cancellable();
  }
  state_.asset_progress=work.progress;
  state_.can_paint_weights = !scene_.has_affine_placement(active.id) && active.mesh_active && active.painted && object_editable_locked(active.id) &&
      active.deformation && active.deformation->skeleton && active.deformation->skin;
  if (!state_.can_paint_weights) state_.weights.enabled = false;
  state_.can_voxel_remesh = parameter_enabled_locked(VrParameter::VoxelSize);
  auto avatar = avatar_group(scene_, active.id);
  state_.can_export_avatar = avatar && std::any_of(scene_.objects().begin(), scene_.objects().end(),
      [&](const auto &o) { return retained_avatar(o) && in_group(scene_, o, avatar); });
  state_.sculpt_settings = volume().sculpt_settings();
  state_.sculpt_transform = scene_.has_affine_placement(active.id)?CanvasTransform{}:scene_.world_transform(active.id);
  state_.can_configure_sculpt = sculpt_target_ready_locked();
  state_.can_change_resolution = resolution_target_ready_locked();
  state_.sculpt_voxel_mm = double(volume().voxel_size())*state_.sculpt_transform.scale*1000;
  state_.sculpt_mask_visible = !active.mesh_active && active.visible && !state_.retopology &&
      !state_.weights.enabled && state_.sculpt_settings.mask_visible;
  state_.active_sculpt_layer = volume().active_layer();
  state_.sculpt_layers.clear();
  state_.sculpt_editable = volume().editable_layer();
  for (auto &l : volume().layers()) {
    state_.sculpt_layers.push_back(l.name);
    if (l.id == state_.active_sculpt_layer) {
      state_.sculpt_layer_name = l.name;
      state_.sculpt_layer_visible = l.visible;
      state_.sculpt_layer_locked = l.locked;
      state_.sculpt_layer_opacity = l.opacity;
    }
  }
  const auto selected_field=active.mesh_active?std::optional<TextureSetView>(active_texture_set(active)):std::nullopt;
  if(texture_face_object_!=active.id||!active.mesh_active||!active.painted||texture_face_geometry_!=active.painted->mesh_owner()){state_.texture_faces.clear();state_.texture_face_select=false;texture_face_geometry_.reset();texture_face_object_=0;}
  state_.texture_sets.clear();state_.active_texture_set=active.texture_sets?active.texture_sets->active():0;
  state_.texture_material=selected_field?selected_field->material:active.material;
  state_.can_edit_texture_sets=selected_field&&(!active.polygon||active.texture_sets)&&detail::texture_set_plain_fields(active)&&object_editable_locked(active.id)&&!state_.asset_busy&&!state_.recovery_busy&&!native_stroke_&&!control_before_&&!state_.polygon&&!state_.retopology&&!state_.cut&&!uv_;
  state_.can_resize_bake_target=selected_field&&detail::unpainted_bake_resolution_target(active)&&object_editable_locked(active.id)&&!state_.asset_busy&&!state_.recovery_busy&&!native_stroke_&&!control_before_&&!state_.polygon&&!state_.retopology&&!state_.cut&&!uv_;
  if(selected_field){
    const auto primary=texture_set_view(active,0);state_.texture_sets.push_back({0,primary.name,primary.painted->resolution(),primary.domain?primary.domain->triangles().size():primary.painted->mesh().indices.size()/3});
    if(active.texture_sets)for(const auto&s:active.texture_sets->additional())state_.texture_sets.push_back({s.id,s.name,s.painted->resolution(),s.domain->triangles().size()});
  }
  state_.active_layer = selected_field ? selected_field->painted->active_layer() : 0;
  state_.paint_layers.clear();
  state_.layer_visible = false;
  if (selected_field)
    for (auto &l : selected_field->painted->layers()) {
      state_.paint_layers.push_back(l.name);
      if (l.id == state_.active_layer)
        state_.layer_visible = l.visible;
    }
  state_.native_pending=bool(native_stroke_);
  state_.native_gesture=native_stroke_?native_stroke_->epoch:0;
  state_.native_accepting=native_stroke_&&!native_stroke_->accepted.load()&&!(transaction_&&transaction_->native_ending());
  if(!native_stroke_)state_.native_samples=0;
  state_.stroking = action_active_locked();
  state_.weight_gesture = weight_stroking_ ? weight_epoch_.load() : 0;
  state_.weight_samples = weight_stroking_ ? weight_samples_.size() : 0;
  state_.dirty = content_ != saved_content_ || pending_locked() ||
                 control_changed_ || state_.asset_busy;
  state_.tool = input_.tool();
  state_.menu = input_.menu_open();
  state_.menu_index = input_.menu_index();
  state_.menu_page = input_.menu_page();
  state_.can_undo = command_enabled_locked(SpatialCommand::Undo);
  state_.can_redo = command_enabled_locked(SpatialCommand::Redo);
  state_.can_preview=command_enabled_locked(SpatialCommand::PreviewPbr);
  for (int i = 0; i < 12; ++i) {
    auto command = spatial_action(state_.menu_page, i);
    auto parameter = spatial_parameter(state_.menu_page, i);
    state_.menu_enabled[i] = parameter ? parameter_enabled_locked(*parameter)
                             : command ? command_enabled_locked(*command)
                                       : true;
    if(state_.menu_page==26&&i>3&&i!=8)state_.menu_enabled[i]=false;

  }
  bool weight_preview = weight_stroking_ && !weight_samples_.empty() &&
      (weight_scheduled_epoch_ != state_.weight_gesture || weight_scheduled_samples_ != weight_samples_.size());
  std::optional<MeshJob> mesh_job;
  std::shared_ptr<const Scene> source;
  const auto previous_view=published_.load();
  const bool view_changed=!previous_view||previous_view->view_epoch!=state_.view_epoch;
  if(changed||weight_preview||view_changed){
    mesh_job.emplace(MeshJob{state_.revision,state_.generation,scene_.snapshot(),state_.weights.enabled,
        state_.weights.linked,uint32_t(state_.rig_joint),0,{}, {}});
    source=std::make_shared<const Scene>(mesh_job->scene);
    if(state_.shape_sculpt)detail::shape_sculpt_preview(mesh_job->scene,active.id,state_.morph_target);
    mesh_job->sculpt_mask_view=state_.sculpt_mask_visible;
    mesh_job->pbr_view=state_.pbr_view;
    mesh_job->view_epoch=state_.view_epoch;
    mesh_job->expressions=state_.expressions;
    if(state_.retopology&&active.retopology){
      mesh_job->scene.object(active.id).visible=false;
      mesh_job->scene.object(active.retopology->source).visible=true;
    }
    if(weight_stroking_&&!weight_samples_.empty()){
      mesh_job->weight_gesture=state_.weight_gesture;mesh_job->weight_samples=weight_samples_;
      mesh_job->weight_settings=weight_stroke_settings_;
    }
  }
  auto publication=std::make_shared<EditorState>(state_);
  // No allocation or source validation after the first externally visible
  // store. Workers cannot take either candidate until its state is published.
  {
    std::scoped_lock lock(mesh_mutex_,uv_mutex_);
    if(mesh_job){
      pending_mesh_=std::move(mesh_job);native_source_scene_=std::move(source);
      if(weight_preview){weight_scheduled_epoch_=state_.weight_gesture;weight_scheduled_samples_=weight_samples_.size();}
    }
    if(uv_job){uv_job->request=++uv_request_;uv_scheduled_=uv_job->mesh;uv_validation_=std::move(uv_job);}
    else if(reset_uv){++uv_request_;uv_scheduled_.reset();uv_validation_.reset();}
    if(transaction_)transaction_->release_native();
    published_.store(std::move(publication));
  }
  mesh_changed_.notify_one();uv_changed_.notify_all();
  {std::lock_guard lock(retopo_mutex_);retopo_changed_.notify_all();}
  {std::lock_guard lock(cut_mutex_);cut_changed_.notify_all();}
  if(cancel_polygon_publication)cancel_polygon_locked();
  if(polygon_predicate_locked_)polygon_changed_.notify_all();
  else {std::lock_guard lock(polygon_mutex_);polygon_changed_.notify_all();}
  }catch(...){
    state_=std::move(previous_state);last_volume_=previous_volume;last_paint_=previous_paint;
    rig_object_=previous_rig;control_changed_=previous_control_changed;control_source_=previous_control_source;
    uv_solving_=previous_solving;throw;
  }
  if(checkpoint&&!transaction_)try{checkpoint_locked();}catch(...){}
}

void Document::finish_locked() {
  if(state_.creator)throw std::logic_error("Apply or cancel the humanoid creator before changing or saving the document");
  if(state_.expressions)throw std::logic_error("Apply or cancel expression preview before changing or saving the document");
  if(state_.polygon)throw std::logic_error("Apply or cancel polygon editing before changing the document");
  if(state_.object_grabbing)finish_object_grab_locked(true,false);
  if(native_stroke_)throw std::logic_error("Wait for the accepted desktop stroke, or cancel it, before changing the document");
  if(state_.cut)throw std::logic_error("Apply or cancel the plane cut before changing the document");
  if (state_.retopology)
    throw std::logic_error("Apply or cancel retopology before changing the document");
  // Starting another command may accept scalar property previews, but must
  // not implicitly execute an action such as creating a remeshed object.
  finish_control_locked(state_.controls.parameter != VrParameter::ShapeMirror &&
                        state_.controls.parameter != VrParameter::ShapeRestore &&
                        state_.controls.parameter != VrParameter::PolygonConversion &&
                        state_.controls.parameter != VrParameter::PolygonDistance &&
                        state_.controls.parameter != VrParameter::PolygonCuts &&
                        state_.controls.parameter != VrParameter::ImportUnitScale &&
                        state_.controls.parameter != VrParameter::SculptResolution &&
                        state_.controls.parameter != VrParameter::VoxelSize &&
                        state_.controls.parameter != VrParameter::TriangleEdge &&
                        state_.controls.parameter != VrParameter::TextureResolution &&
                        state_.controls.parameter != VrParameter::RigRotation &&
                        state_.controls.parameter != VrParameter::MorphWeight &&
                        state_.controls.parameter != VrParameter::BakeSource &&
                        state_.controls.parameter != VrParameter::BakeDistances &&
                        state_.controls.parameter != VrParameter::BakeQuality &&
                        state_.controls.parameter != VrParameter::BakeProjection &&
                        state_.controls.parameter != VrParameter::BakeColors &&
                        !skin_parameter(state_.controls.parameter) &&
                        !sculpt_parameter(state_.controls.parameter) &&
                        !procedural_parameter(state_.controls.parameter));
  if (uv_accept_pending_)
    throw std::logic_error("Wait for the accepted UV edit to finish");
  bool weight_action = weight_stroking_;
  if (action_active_locked() && end_action_locked())
    record_stroke_locked();
  desktop_ = false;
  input_.cancel();
  navigation_.reset();
  if (weight_action && state_.asset_busy) {
    publish_locked();
    throw std::logic_error("Wait for the accepted weight gesture to finish");
  }
}
void Document::replace(Scene next, bool clean) {
  next.validate();
  std::lock_guard lock(model_mutex_);
  replace_locked(std::move(next), clean);
}
void Document::replace_locked(Scene next,bool clean,std::filesystem::path adopted_path,std::string message) {
  if(state_.creator)end_humanoid_creator_locked(false);
  AuthorityTransition authority(*this);invalidate_object_authority_locked();state_.held_object=0;
  if(native_stroke_)cancel_native_locked();
  if(state_.cut){finish_control_locked(false);cancel_cut_locked();}
  if(state_.retopology)cancel_retopology_locked();
  if(weight_stroking_){cancel_action_locked();desktop_=false;input_.cancel();}
  finish_control_locked(false);finish_locked();
  Transaction transaction(*this);
  if(next_content_==UINT64_MAX)throw std::overflow_error("Document history identity exhausted");
  scene_=std::move(next);
  initial_creator_={}; // Opening/replacing even identical bytes is an existing workspace.
  state_.selection_mode=state_.selection_focus=state_.hierarchy_open=state_.hierarchy_anchored=false;
  state_.selected_objects.clear();state_.collapsed_groups.clear();state_.selection_hover={};
  state_.selection_pressed={true,true};state_.selection_release={true,true};
  bind_locked();transaction.clear_history();path_=std::move(adopted_path);
  ++state_.generation;
  state_.bake_settings.cage_object=0; // Object references never alias a new document.
  transaction.invalidate_import();
  transaction.invalidate_projection();
  if(recovery_){recovery_source_={new_recovery_id(),state_.generation,path_};recovery_content_=0;}
  ++state_.input_epoch;state_.error.clear();state_.message=std::move(message);anchored_=false;
  state_.asset_busy=false;state_.recovery_busy=false;content_=next_content_++;
  if(clean)saved_content_=content_;
  publish_locked(true,false);transaction.commit(false);asset_work_.store({});
  if(recovery_)try{recovery_->set_source(recovery_source_);checkpoint_locked();}catch(...){}
  authority.commit();
}
void Document::seed() {
  Volume next(.03f);
  next.begin_stroke();
  Brush b;
  b.radius = .4f;
  b.blend = 0;
  next.stamp(b);
  next.end_stroke();
  Scene scene;scene.active().volume=std::make_shared<Volume>(std::move(next));
  std::lock_guard lock(model_mutex_);
  replace_locked(std::move(scene),false);
  initial_creator_={state_.generation,content_};
}
bool Document::begin_desktop() {
  std::lock_guard lock(model_mutex_);
  if(state_.cut)return false;
  if(scene_.active().texture_sets&&!state_.weights.enabled&&!state_.retopology)return begin_native_locked(0,NativeStrokeSpace::EvaluatedWorldBrush);
  if (control_before_ || uv_ || state_.asset_busy || action_active_locked() ||
      input_.menu_open() || !scene_.active().visible ||
      !object_editable_locked(scene_.active().id) ||
      (!state_.retopology && !scene_.active().mesh_active && !volume().editable_layer() && !volume().sculpt_settings().mask_edit))
    return false;
  if (state_.retopology && (!state_.retopology->source || retopo_accepting_)) return false;
  if(!state_.weights.enabled && !state_.retopology && reject_texture_paint_locked())return false;
  RetopoInputScope admission(*this,bool(state_.retopology));
  input_.cancel();
  begin_action_locked();
  desktop_ = true;
  publish_locked();admission.commit();
  return true;
}
void Document::stamp_desktop(Brush b) {
  std::lock_guard lock(model_mutex_);
  if (!desktop_)
    throw std::logic_error("Desktop does not own the active stroke");
  if(native_stroke_&&native_stroke_->texture_set){NativeStrokeSample sample;sample.space=NativeStrokeSpace::EvaluatedWorldBrush;sample.brush=b;if(!sample_native_locked(std::move(sample)))throw std::logic_error("The selected field no longer accepts desktop samples");return;}
  RetopoInputScope admission(*this,bool(state_.retopology));
  auto t = state_.retopology ? state_.retopology->transform
                            : object_world_transform_locked(scene_.active().id);
  b.from = world_to_model(t, b.from);
  b.to = world_to_model(t, b.to);
  b.radius /= t.scale;
  b.blend /= t.scale;
  auto n = ob::rotate(ob::conjugate(t.orientation), obv(b.normal));
  b.normal = vec(n);
  stamp_action_locked(b);
  publish_locked();admission.commit();
}
void Document::end_desktop() {
  std::lock_guard lock(model_mutex_);
  if(native_stroke_){end_native_locked(true);publish_locked();return;}
  RetopoInputScope admission(*this,bool(state_.retopology));
  if (desktop_) {
    if (end_action_locked())
      record_stroke_locked();
    desktop_ = false;
    input_.cancel();
    publish_locked();
  }
  admission.commit();
}
void Document::cancel_desktop() {
  std::lock_guard lock(model_mutex_);
  if(native_stroke_){cancel_native_locked();publish_locked();return;}
  RetopoInputScope admission(*this,bool(state_.retopology));
  if (desktop_) {
    cancel_action_locked();
    desktop_ = false;
    input_.cancel();
    publish_locked();
  }
  admission.commit();
}
std::optional<Vec3> Document::raycast(Vec3 p, Vec3 d) const {
  return raycast(p, d, render_frame_time());
}
std::optional<Vec3> Document::raycast(Vec3 p, Vec3 d, double material_time) const {
  if (!std::isfinite(material_time)) throw std::invalid_argument("Invalid material pick time");
  std::lock_guard lock(model_mutex_);
  if(scene_.active().polygon&&scene_.active().polygon->active&&!scene_.active().mesh_active)return {};
  if(!state_.retopology && scene_.has_affine_placement(scene_.active().id)) {
    auto snapshot=mesh_.load();
    if(!object_editable_locked(scene_.active().id)||snapshot->generation!=state_.generation||snapshot->revision!=state_.revision||!snapshot->picking)return {};
    auto hit=snapshot->picking->raycast_target(p,d,10,material_time,scene_.active().id);
    return hit?std::optional<Vec3>(hit->surface.position):std::nullopt;
  }
  if (state_.weights.enabled) {
    auto mesh = mesh_.load();
    if (mesh->generation != state_.generation || mesh->revision != state_.revision || !mesh->picking) return {};
    const bool held=state_.object_grabbing&&state_.held_object==scene_.active().id;
    auto delta=held?ob::compose(object_world_transform_locked(state_.held_object),ob::inverse(scene_.world_transform(state_.held_object))):CanvasTransform{};
    auto origin=held?world_to_model(delta,p):p;
    auto direction=held?vec(ob::rotate(ob::conjugate(delta.orientation),obv(d))):d;
    auto hit = mesh->picking->raycast_target(origin, direction, held?20/delta.scale:20, material_time,(held||state_.isolate_held)?state_.held_object:0);
    if (!hit) return {};
    // A separate ordinary Volume is an unselected occluder. It has no packed
    // weight vertex and cannot be mapped into a different object's namespace.
    if(!hit->packed())return {};
    if(held)hit->surface.position=vec(ob::transform(delta,obv(hit->surface.position)));
    auto vertex = mesh->mesh.indices.at(size_t(hit->surface.triangle) * 3);
    return mesh->selected_weights.at(vertex) >= 0 ? std::optional<Vec3>(hit->surface.position) : std::nullopt;
  }
  const auto &active=scene_.active();
  if(!state_.retopology && active.mesh_active && active.polygon && active.polygon->active && active.polygon->colors) {
    auto mesh=mesh_.load();
    if(mesh->generation!=state_.generation || mesh->revision!=state_.revision || !mesh->picking)return {};
    const bool held=state_.object_grabbing && state_.held_object==active.id;
    auto delta=held?ob::compose(object_world_transform_locked(active.id),ob::inverse(scene_.world_transform(active.id))):CanvasTransform{};
    auto origin=held?world_to_model(delta,p):p;
    auto direction=held?vec(ob::rotate(ob::conjugate(delta.orientation),obv(d))):d;
    auto hit=mesh->picking->raycast_target(origin,direction,held?20/delta.scale:20,material_time,active.id);
    if(!hit)return {};
    return held?std::optional<Vec3>(vec(ob::transform(delta,obv(hit->surface.position)))):std::optional<Vec3>(hit->surface.position);
  }
  auto t = state_.retopology ? state_.retopology->transform
                            : object_world_transform_locked(scene_.active().id);
  if (state_.retopology) {
    if (!state_.retopology->source || retopo_accepting_) return {};
    auto direction = vec(ob::rotate(ob::conjugate(t.orientation), obv(d)));
    SurfaceQueryOptions options; options.max_triangle_tests = 65'536;
    auto hit = state_.retopology->source->raycast(world_to_model(t, p), direction, 20 / t.scale, options);
    return hit ? std::optional<Vec3>(vec(ob::transform(t, obv(hit->position)))) : std::nullopt;
  }
  if (!object_editable_locked(scene_.active().id))
    return {};
  auto direction = vec(ob::rotate(ob::conjugate(t.orientation), obv(d)));
  auto hit =
      scene_.active().mesh_active
          ? scene_.active().painted->raycast(world_to_model(t, p), direction,
                                             10 / t.scale)
          : volume().raycast(world_to_model(t, p), direction, 10 / t.scale);
  return hit ? std::optional<Vec3>(vec(ob::transform(t, obv(*hit))))
             : std::nullopt;
}
Vec3 Document::gradient(Vec3 p) const {
  std::lock_guard lock(model_mutex_);
  if (state_.retopology) {
    if (!state_.retopology->source || retopo_accepting_)
      throw std::logic_error("Wait for the retopology source before querying its normal");
    const auto &t = state_.retopology->transform;
    SurfaceQueryOptions options; options.max_triangle_tests = 65'536;
    const auto hit = state_.retopology->source->closest(world_to_model(t, p), options);
    return vec(ob::rotate(t.orientation, obv(hit.normal)));
  }
  if(scene_.has_affine_placement(scene_.active().id)) {
    auto snapshot=mesh_.load();
    if(snapshot->generation!=state_.generation||snapshot->revision!=state_.revision||!snapshot->picking)
      throw std::logic_error("Wait for the current affine surface before querying its normal");
    return snapshot->picking->closest_target(p,scene_.active().id).surface.normal;
  }
  if (state_.weights.enabled) {
    auto mesh = mesh_.load();
    if (mesh->generation == state_.generation && mesh->revision == state_.revision && mesh->picking)
      return mesh->picking->closest_target(p).surface.normal;
  }
  auto t = object_world_transform_locked(scene_.active().id);
  return vec(
      ob::rotate(t.orientation,
                 obv(scene_.active().mesh_active
                         ? scene_.active().painted->normal(world_to_model(t, p))
                         : volume().gradient(world_to_model(t, p)))));
}
bool Document::undo() {
  std::lock_guard lock(model_mutex_);
  if(state_.creator)return creator_history_locked(false);
  if(state_.polygon){if(polygon_accepting_||!state_.polygon->surface)return false;bool available=state_.polygon->can_undo||polygon_stroking_;PolygonJob job;job.action=polygon_stroking_?PolygonAction::CancelDrag:PolygonAction::Undo;queue_polygon_locked(std::move(job));polygon_stroking_=false;return available;}
  if(native_stroke_){cancel_native_locked();publish_locked();return true;}
  if(state_.cut){bool available=!cut_undo_.empty()||bool(control_before_);cut_history_locked(false);publish_locked();return available;}
  if (state_.retopology) {
    if (retopo_accepting_ || !state_.retopology->source) return false;
    RetopoInputScope admission(*this,true);
    bool available = state_.retopology->can_undo || retopo_stroking_;
    if (retopo_stroking_) { cancel_action_locked(); desktop_ = false; input_.cancel(); }
    else queue_retopology_locked(RetopoAction::Undo);
    publish_locked();admission.commit();return available;
  }
  if (uv_accept_pending_ || uv_solving_)
    return false;
  if (uv_) {
    bool available = uv_->view().can_undo;
    uv_->edit(UvAction::Undo);
    publish_locked();
    return available;
  }
  if (weight_stroking_) {
    cancel_action_locked(); desktop_ = false; input_.cancel(); publish_locked(); return true;
  }
  if (state_.asset_busy)
    return false;
  finish_locked();
  if(undo_locked(false))return true;
  publish_locked();return false;
}
bool Document::redo() {
  std::lock_guard lock(model_mutex_);
  if(state_.creator)return creator_history_locked(true);
  if(state_.polygon){if(polygon_accepting_||polygon_stroking_||!state_.polygon->surface)return false;bool available=state_.polygon->can_redo;PolygonJob job;job.action=PolygonAction::Redo;queue_polygon_locked(std::move(job));return available;}
  if(state_.cut){bool available=!cut_redo_.empty()&&!control_before_;cut_history_locked(true);publish_locked();return available;}
  if (state_.retopology) {
    if (retopo_accepting_ || retopo_stroking_ || !state_.retopology->source) return false;
    RetopoInputScope admission(*this,true);
    bool available = state_.retopology->can_redo;
    queue_retopology_locked(RetopoAction::Redo);publish_locked();admission.commit();return available;
  }
  if (weight_stroking_) return false;
  if (uv_accept_pending_ || uv_solving_)
    return false;
  if (uv_) {
    bool available = uv_->view().can_redo;
    uv_->edit(UvAction::Redo);
    publish_locked();
    return available;
  }
  if (state_.asset_busy)
    return false;
  finish_locked();
  if(undo_locked(true))return true;
  publish_locked();return false;
}
void Document::configure(Tool tool, float radius) {
  if (int(tool) < 0 || int(tool) > 3 || !std::isfinite(radius) ||
      radius < .005f || radius > 2)
    throw std::invalid_argument("Invalid tool settings");
  std::lock_guard lock(model_mutex_);
  input_.select_tool(tool);
  state_.radius = radius;
  input_.radius = radius;
  publish_locked();
}
void Document::submit(SpatialFrame frame) {
  submit(std::span<const SpatialFrame>(&frame, 1));
}
void Document::submit(std::span<const SpatialFrame> frames) {
  std::lock_guard lock(input_mutex_);
  if (!spatial_accepting_)
    return;
  for (auto &frame : frames) {
    // A focus boundary cancels the unconfirmed action after preceding events
    // have been processed. Clearing here loses queued release/Apply actions.
    if (inputs_.size() >= 64) {
      inputs_.clear();
      reset_input_ = true;
    }
    inputs_.emplace_back(published_.load()->input_epoch, frame);
  }
  input_changed_.notify_one();
}

void Document::appearance(std::string file, int pixels, bool light,
                          uint32_t accent, int opacity) {
  std::lock_guard lock(model_mutex_);
  state_.font_file = std::move(file);
  state_.font_pixels = std::clamp(pixels, 4, 256);
  state_.light = light;
  state_.accent = accent;
  state_.opacity = std::clamp(opacity, 0, 255);
  publish_locked();
}
void Document::report_error(std::string error) {
  std::lock_guard lock(model_mutex_);
  state_.error = std::move(error);
  publish_locked();
}
void Document::shading(bool toon) {
  std::lock_guard lock(model_mutex_);
  command_locked(toon?SpatialCommand::PreviewToon:SpatialCommand::PreviewPbr);
}
void Document::authored_shading() {
  std::lock_guard lock(model_mutex_);
  command_locked(SpatialCommand::PreviewAuthored);
}
void Document::shading_locked(bool pbr,bool toon) {
  if(state_.pbr_view==pbr&&state_.toon==toon&&!state_.weights.enabled)return;
  if(action_active_locked()||state_.object_grabbing||navigation_.grabbing()||control_before_||(state_.projection&&state_.projection->placing)||(state_.rig_fit&&state_.rig_fit->placing))
    throw std::logic_error("Release the active gesture and close its tool before changing the material preview");
  const auto expression_owner=expression_source_matches_locked()&&input_.menu_open()&&
      input_.menu_page()==vrm_expression_page?input_.menu_device():0;
  const auto expression_sector=input_.menu_index();
  Transaction transaction(*this);
  input_.cancel();++state_.input_epoch;transaction.rebind();
  if(expression_owner)input_.retain_page(vrm_expression_page,expression_owner,expression_sector);
  state_.selection_pressed={true,true};state_.selection_release={true,true};state_.selection_hover={};
  state_.pbr_view=pbr;
  ++state_.view_epoch;
  state_.toon = toon;
  state_.weights.enabled=false;
  state_.error.clear();state_.message=pbr?"Core PBR material preview":toon?"Toon preview":"Authored material preview";
  publish_locked(false,false);
  transaction.commit(false);
}
void Document::paint_settings(PaintSettings settings) {
  settings.validate();
  std::lock_guard lock(model_mutex_);
  finish_locked();
  bool weights = std::exchange(state_.weights.enabled, false);
  state_.paint = settings;
  publish_locked(weights);
}
void Document::weight_settings(WeightToolSettings settings, std::optional<uint32_t> joint, AssetSource expected) {
  std::lock_guard lock(model_mutex_);
  require_authority_locked(expected);
  finish_locked();
  if ((expected.generation && expected.generation != state_.generation) ||
      (expected.revision && expected.revision != state_.revision) ||
      (expected.object && expected.object != scene_.active().id))
    throw std::logic_error("The weight editor source changed; reopen the editor");
  if (state_.asset_busy || state_.recovery_busy)
    throw std::logic_error("Wait for pending authoring work before changing the weight tool");
  const auto &o = scene_.active();
  if (settings.enabled && !state_.can_paint_weights)
    throw std::logic_error("Select a visible, unlocked skinned mesh");
  size_t bones = o.deformation && o.deformation->skeleton ? o.deformation->skeleton->bones.size() : 1;
  if (!o.deformation) settings.locks.clear();
  settings.validate(bones);
  if (joint && *joint >= bones) throw std::out_of_range("Weight joint identity is out of range");
  if (settings.symmetry && (!o.deformation || !o.deformation->humanoid))
    throw std::logic_error("Symmetry requires explicit humanoid joint mapping");
  state_.weights = std::move(settings);
  if (joint) state_.rig_joint = *joint;
  publish_locked(true);
}
void Document::paint_command(SpatialCommand command) {
  std::lock_guard lock(model_mutex_);
  if(command==SpatialCommand::BlurColorLayer){PaintBlurOptions options;options.strength=state_.paint.flow;queue_blur_color_locked(options);return;}
  finish_locked();
  bool normal_paint = command == SpatialCommand::MakeMesh || command == SpatialCommand::EditSource ||
      (command >= SpatialCommand::PaintColor && command <= SpatialCommand::LayerOpacity);
  bool weight_view = normal_paint && std::exchange(state_.weights.enabled, false);
  auto publication=published_.load();
  command_locked(command);
  if(published_.load()==publication)publish_locked(weight_view);
}
void Document::begin_uv() {
  std::lock_guard lock(model_mutex_);
  finish_locked();
  control_event_locked({VrControlEventType::Begin, VrParameter::UvEdit});
  desktop_ = true;
  publish_locked();
}
void Document::begin_voxel_remesh() {
  std::lock_guard lock(model_mutex_);
  finish_locked();
  control_event_locked({VrControlEventType::Begin, VrParameter::VoxelSize});
  desktop_ = true;
  state_.error.clear();
  publish_locked();
}
void Document::edit_voxel_size(float mm) {
  std::lock_guard lock(model_mutex_);
  if (!control_before_ || state_.controls.parameter != VrParameter::VoxelSize)
    throw std::logic_error("Open the voxel remesh controls first");
  auto &c = state_.controls;
  if (!std::isfinite(mm) || mm < c.minimum || mm > c.maximum)
    throw std::invalid_argument("Voxel size is outside the object's supported range");
  c.value[0] = state_.voxel_size_mm = mm;
  state_.error.clear();
  publish_locked();
}
void Document::end_voxel_remesh(bool accept) {
  std::lock_guard lock(model_mutex_);
  if (control_before_ && state_.controls.parameter != VrParameter::VoxelSize)
    throw std::logic_error("Another control owns the document");
  finish_control_locked(accept);
  desktop_ = false;
  publish_locked();
}
void Document::begin_triangle_remesh() {
  std::lock_guard lock(model_mutex_);finish_locked();
  control_event_locked({VrControlEventType::Begin,VrParameter::TriangleEdge});
  desktop_=true;state_.error.clear();publish_locked();
}
void Document::edit_triangle_edge(float mm) {
  std::lock_guard lock(model_mutex_);
  if(!control_before_||state_.controls.parameter!=VrParameter::TriangleEdge)
    throw std::logic_error("Open the isotropic remesh controls first");
  auto &c=state_.controls;
  if(!std::isfinite(mm)||mm<c.minimum||mm>c.maximum)
    throw std::invalid_argument("Edge length is outside the supported range");
  c.value[0]=mm;state_.error.clear();publish_locked();
}
void Document::end_triangle_remesh(bool accept) {
  std::lock_guard lock(model_mutex_);
  if(control_before_&&state_.controls.parameter!=VrParameter::TriangleEdge)
    throw std::logic_error("Another control owns the document");
  finish_control_locked(accept);desktop_=false;publish_locked();
}
void Document::end_uv(bool accept) {
  std::lock_guard lock(model_mutex_);
  if (accept && uv_ && !uv_->view().valid && !uv_->view().validating)
    throw std::runtime_error(uv_->view().error);
  auto publication=published_.load();
  finish_control_locked(accept);
  if (!uv_accept_pending_)
    desktop_ = false;
  if(published_.load()==publication)publish_locked();
}
void Document::queue_uv_locked(std::shared_ptr<const Mesh> mesh) {
  auto &o = scene_.active();
  FileJob job{scene_.snapshot(), {},       state_.revision,
              state_.generation, content_, false};
  job.uv_mesh = std::move(mesh);
  job.uv_source_vertices = uv_->view().source_vertices;
  job.paint_identity = o.painted;
  job.object = o.id;job.edit_authority=state_.edit_authority;
  job.source_revision = o.painted->revision();
  job.uv_session = uv_session_;
  job.uv_desktop = desktop_;
  job.uv_keep_normals=uv_retention_requested_locked();
  job.uv_keep_paint=uv_paint_retention_requested_locked();
  job.work=std::make_shared<AssetWork>();job.work->accepted_scene=true;job.operation_label="UV paint transfer";auto work=job.work;
  std::lock_guard lock(file_mutex_);
  if (files_.size() >= 8)
    throw std::runtime_error("File and asset work queue is full");
  Transaction transaction(*this);files_.push_back(std::move(job));
  try{
    uv_accept_pending_=true;state_.asset_busy=true;asset_work_.store(work);state_.message="Transferring paint to edited UVs...";state_.error.clear();
    if(!desktop_)input_.resume_control(VrParameter::UvEdit);
    publish_locked(false,false);transaction.commit();
  }catch(...){files_.pop_back();throw;}
  invalidate_uv_locked();file_changed_.notify_one();

}
void Document::use_source() { paint_command(SpatialCommand::EditSource); }
void Document::use_mesh() { paint_command(SpatialCommand::PaintColor); }
void Document::prepare_mesh(uint32_t resolution) {
  std::lock_guard lock(model_mutex_);
  finish_locked();
  prepare_locked(resolution);
}
bool Document::wait_asset(std::chrono::milliseconds timeout) const {
  auto deadline = std::chrono::steady_clock::now() + timeout;
  // An accepted patch may still be draining topology input before it queues
  // the ordered asset job. Waiting only for asset_busy can save too early at
  // an XR shutdown boundary. Unconfirmed workspaces do not block this helper.
  auto native=published_.load();
  if(native->native_pending&&!native->native_accepting&&!wait_native_stroke(timeout))return false;
  auto polygon=published_.load()->polygon;
  if(polygon&&polygon->committing&&!wait_polygon(std::max(std::chrono::milliseconds(0),std::chrono::duration_cast<std::chrono::milliseconds>(deadline-std::chrono::steady_clock::now()))))return false;
  auto topology = published_.load()->retopology;
  if (topology && topology->committing && !wait_retopology(timeout)) return false;
  auto cut=published_.load()->cut;
  if(cut&&cut->committing&&!wait_cut(std::max(std::chrono::milliseconds(0),std::chrono::duration_cast<std::chrono::milliseconds>(deadline-std::chrono::steady_clock::now()))))return false;
  std::unique_lock lock(file_mutex_);
  return file_changed_.wait_until(lock, deadline,
                                [&] { return !published_.load()->asset_busy; });
}
void Document::prepare_locked(uint32_t resolution) {
  if (resolution < 64 || resolution > 2048 || (resolution & (resolution - 1)))
    throw std::invalid_argument("Invalid paint resolution");
  if (state_.asset_busy)
    throw std::logic_error("A painting mesh is already being prepared");
  auto &o = scene_.active();
  if(o.texture_sets)throw std::logic_error("Texture-set geometry replacement needs its owning membership/field remap");
  if(o.polygon&&o.polygon->active)throw std::logic_error("Use the polygon or UV editor for this native polygon mesh; restore its source before rebuilding sculpt geometry");
  if (o.painted && o.painted->has_paint_data())
    throw std::logic_error("The existing mesh has paint data; use the UV editor or transfer paint before rebuilding its geometry");
  if (o.retopology)
    throw std::logic_error("The mesh retains editable retopology; use a separate sculpt target before replacing its geometry");
  if (o.deformation)
    throw std::logic_error("Explicitly remove or transfer rig data before replacing its rest mesh");
  if (o.appearance || o.material_bindings)
    throw std::logic_error("The prepared mesh retains original materials; create a separate sculpt target and reproject or bake before replacing it");
  if (!object_editable_locked(o.id))
    throw std::logic_error(
        "Show and unlock the object before preparing a painting mesh");
  FileJob job{scene_.snapshot(), {},       state_.revision,
              state_.generation, content_, false};
  job.prepare_mesh = true;
  job.object = o.id;job.edit_authority=state_.edit_authority;
  job.source_revision = o.volume->revision();
  job.edit_authority=state_.edit_authority;
  job.source_identity = o.volume;
  job.resolution = resolution;
  job.work=std::make_shared<AssetWork>();
  job.operation_label="Painting mesh preparation";
  auto work=job.work;
  std::lock_guard lock(file_mutex_);
  if (files_.size() >= 8)
    throw std::runtime_error("File and asset work queue is full");
  Transaction transaction(*this);files_.push_back(std::move(job));
  try{state_.asset_busy=true;asset_work_.store(work);state_.error.clear();state_.message="Preparing painting mesh and UVs...";publish_locked(false,false);transaction.commit();}
  catch(...){files_.pop_back();throw;}
  file_changed_.notify_one();

}
void Document::begin_spatial() {
  std::lock_guard lock(model_mutex_);
  RetopoInputScope admission(*this,bool(state_.retopology)||(input_.menu_open()&&input_.menu_page()==16));
  rebase_space_locked({},admission);
  state_.error.clear();publish_locked();admission.commit();
  // There is no fallible second publication after accepting the rebase or
  // exposing its producer. A refusal leaves the producer's old policy intact.
  {std::lock_guard input_lock(input_mutex_);spatial_accepting_ = true;}
}
void Document::rebase_space(std::optional<CanvasTransform> old_from_new) {
  std::lock_guard lock(model_mutex_);
  RetopoInputScope admission(*this,bool(state_.retopology)||(input_.menu_open()&&input_.menu_page()==16));
  rebase_space_locked(old_from_new,admission);publish_locked();admission.commit();
}
void Document::rebase_space_locked(std::optional<CanvasTransform> old_from_new,RetopoInputScope &admission) {
  if(initial_creator_.seen_focused)cancel_initial_creator_fit_locked();
  if (!desktop_) {
    if(state_.creator)end_humanoid_creator_locked(false);
    if(state_.expressions)end_expression_preview_locked(false);
    bool accepted_uv = uv_accept_pending_;
    if (!accepted_uv) finish_control_locked(false);
    input_.cancel();
    if (accepted_uv) input_.take_controls();
  }
  navigation_.reset();object_navigation_.reset();
  state_.hands = detail::history_only_hands(state_.hands);
  ++state_.input_epoch;
  if(!initial_creator_.seen_focused&&initial_creator_.target_group)initial_creator_.target_input_epoch=state_.input_epoch;
  if(admission.active())admission.retire_inputs();
  else {
    std::lock_guard queue_lock(input_mutex_);
    inputs_.clear();reset_input_ = false;input_changed_.notify_all();
  }
  if (old_from_new && ob::finite(*old_from_new)) {
    auto inverse = ob::inverse(*old_from_new);
    state_.canvas = ob::compose(inverse, state_.canvas);
    state_.panel = ob::compose(inverse, state_.panel);
    state_.hierarchy_panel=ob::compose(inverse,state_.hierarchy_panel);
  } else {anchored_ = false;state_.hierarchy_anchored=false;}
  state_.selection_pressed={true,true};state_.selection_release={true,true};state_.selection_hover={};
}
void Document::finish_spatial() {
  {
    std::lock_guard lock(input_mutex_);
    spatial_accepting_ = false;
  }
  // The producer has stopped. Drain its last transitions before cancelling an
  // unfinished action; in particular preserve an Apply just before shutdown.
  if (!wait_input())
    throw std::runtime_error("Spatial edit worker did not finish");
  std::lock_guard lock(model_mutex_);
  if(initial_creator_.seen_focused)cancel_initial_creator_fit_locked();
  RetopoInputScope admission(*this,bool(state_.retopology)||(input_.menu_open()&&input_.menu_page()==16));
  if (!desktop_) {
    if(state_.creator)end_humanoid_creator_locked(false);
    if(state_.expressions)end_expression_preview_locked(false);
    bool accepted_uv = uv_accept_pending_;
    if (!accepted_uv) finish_control_locked(false);
    input_.cancel();
    if(state_.object_grabbing){if(held_polygon_pending_locked()){object_navigation_.reset();}else if(held_weight_pending_locked()){held_preview_transform_=held_start_transform_;object_navigation_.reset();}else finish_object_grab_locked(false,true);}
    if (accepted_uv) input_.take_controls();
    navigation_.reset();
    publish_locked();
  }
  admission.commit();
}
void Document::process_locked(const SpatialFrame &incoming) {
  SpatialFrame f=incoming;
  // History is a press event. In particular a terminal modal command consumes
  // simultaneous buttons; holding one cannot undo a different namespace on
  // the following frame. The existing published hands provide the latches.
  const bool undo_requested=(f.hands[0].undo&&!state_.hands[0].undo)||(f.hands[1].undo&&!state_.hands[1].undo);
  const bool redo_requested=(f.hands[0].redo&&!state_.hands[0].redo)||(f.hands[1].redo&&!state_.hands[1].redo);
  for(size_t i=0;i<2;++i)if(state_.selection_release[i]){
    if(f.hands[i].tracked.trigger<=.02f)state_.selection_release[i]=false;
    else f.hands[i].tracked.trigger=0;
  }
  const bool focused_presentation=f.focused&&f.head_valid&&ob::finite(f.head)&&std::isfinite(f.time)&&f.time>=0;
  if(focused_presentation&&f.views)initial_creator_.seen_focused=true;
  if(!focused_presentation&&initial_creator_.seen_focused)cancel_initial_creator_fit_locked();
  if(state_.creator&&(!f.focused||!f.head_valid||!ob::finite(f.head)||!std::isfinite(f.time)||f.time<0)){state_.hands=detail::history_only_hands(state_.hands);end_humanoid_creator_locked(false);return;}
  if(process_rig_fit_spatial_locked(f)){return;}
  if(process_projection_spatial_locked(f)){return;}
  if(native_stroke_&&native_stroke_->spatial_owner){if(native_stroke_->space==NativeStrokeSpace::Ray)process_shape_spatial_locked(f);else process_affine_paint_spatial_locked(f);return;}
  if (desktop_){return;}
  if (!f.focused || !f.head_valid || !ob::finite(f.head) ||
      !std::isfinite(f.time) || f.time < 0) {
    if(held_polygon_pending_locked()){
      input_.cancel();object_navigation_.reset();navigation_.reset();state_.hands=detail::history_only_hands(state_.hands);publish_locked(false,false);return;
    }
    if(state_.object_grabbing&&held_weight_pending_locked()){
      input_.cancel();held_preview_transform_=held_start_transform_;object_navigation_.reset();navigation_.reset();state_.hands=detail::history_only_hands(state_.hands);publish_locked(false,false);return;
    }
    if(state_.creator)end_humanoid_creator_locked(false);
    if(state_.expressions)end_expression_preview_locked(false);
    bool accepted_uv = uv_accept_pending_;
    if (!accepted_uv) finish_control_locked(false);
    input_.cancel();
    if (accepted_uv) input_.take_controls();
    if(state_.held_object||state_.object_grabbing){invalidate_object_authority_locked();state_.held_object=0;}
    navigation_.reset();
    state_.hands = detail::history_only_hands(state_.hands);state_.selection_hover={};state_.hierarchy_hover={-1,-1};
    state_.selection_pressed={true,true};state_.selection_release={true,true};
    publish_locked();
    return;
  }
  if (!anchored_) {
    state_.canvas.position =
        f.head.position + ob::rotate(f.head.orientation, {0, -.12f, -.85f});
    state_.canvas.orientation = {};
    anchored_ = true;
  }
  if(state_.texture_face_select&&!input_.menu_open()&&!control_before_&&!state_.asset_busy){
    for(size_t i=0;i<2;++i){const auto&h=f.hands[i];const bool pressed=h.tracked.valid&&std::isfinite(h.tracked.trigger)&&h.tracked.trigger>.02f;
      if(pressed&&!texture_face_pressed_[i]&&!h.joystick){const auto aim=h.tracked.aimValid?h.tracked.aim:h.tracked.grip;if(ob::finite(aim)){
        const auto local=ob::inverse(state_.canvas);const auto p=ob::transform(local,aim.position);const auto d=ob::rotate(ob::conjugate(state_.canvas.orientation),ob::rotate(aim.orientation,{0,0,-1}));
        texture_face_pointer_locked({p.x,p.y,p.z},{d.x,d.y,d.z},true,f.time);}}
      texture_face_pressed_[i]=pressed;
    }
  }
  if(!state_.texture_face_select&&process_object_selection_locked(f)){
    // The hierarchy owns trigger events, but the shared menu still receives
    // neutral releases so a thumbstick/menu button can reopen it immediately.
    for(size_t i=0;i<2;++i){SpatialSample release;release.id=i+1;release.sequence=f.sequence;release.time=f.time;release.focused=f.focused;release.tracked=f.hands[i].tracked.valid;input_.update(release);}
    state_.hands=f.hands;publish_locked(false,false);return;
  }
  std::array<TrackedHand, 2> hands{f.hands[0].tracked, f.hands[1].tracked};
  if(!state_.selection_mode&&state_.object_grab_mode && !input_.menu_open()) {
    const auto session=retopo_session_.load();
    update_object_grab_locked(f);
    // A real authority publication already consumed this frame and retired
    // its old tool. Do not add a second fallible publication or reinterpret
    // the same physical event in the new namespace.
    if(retopo_session_.load()!=session)return;
  }
  if (!state_.selection_mode && !state_.object_grab_mode && !input_.menu_open()) {
    if (auto transform = navigation_.update(hands, state_.canvas)) {
      if (action_active_locked())
        if (end_action_locked())
          record_stroke_locked();
      input_.cancel();
      state_.canvas = *transform;
    }
    if (navigation_.grabbing()) {
      initial_creator_.navigated=true;cancel_initial_creator_fit_locked();
      input_.cancel();
      state_.hands = f.hands;
      publish_locked();
      return;
    }
  }
  if(!state_.texture_face_select&&!state_.selection_mode&&process_affine_paint_spatial_locked(f)){return;}
  const bool affine_target=scene_.has_affine_placement(scene_.active().id);
  auto object_canvas = state_.retopology
      ? ob::compose(state_.canvas, state_.retopology->transform)
      : affine_target ? state_.canvas : ob::compose(state_.canvas, object_world_transform_locked(scene_.active().id));
  input_.radius = state_.radius / object_canvas.scale;
  input_.edit_allowed =
      !affine_target && (!scene_.active().mesh_active||!scene_.active().deformation||state_.weights.enabled) && !state_.asset_busy && object_editable_locked(scene_.active().id) &&
      (scene_.active().mesh_active || volume().editable_layer() || volume().sculpt_settings().mask_edit) &&
      (!state_.weights.enabled || (mesh_.load()->generation == state_.generation && mesh_.load()->revision == state_.revision));
  if(state_.texture_face_select||state_.shape_sculpt||state_.selection_mode||state_.rig_fit)input_.edit_allowed=false;
  if (state_.retopology) input_.edit_allowed = bool(state_.retopology->source) && !retopo_accepting_ && !state_.asset_busy;
  if(state_.cut)input_.edit_allowed=false;
  if(scene_.active().texture_sets&&!state_.weights.enabled)input_.edit_allowed=false;
  input_.painting = scene_.active().mesh_active&&!state_.shape_sculpt;
  input_.retopology = bool(state_.retopology);
  input_.cutting = bool(state_.cut);
  input_.polygon_editing=bool(state_.polygon);
  if(state_.polygon||(scene_.active().polygon&&scene_.active().polygon->active&&!scene_.active().mesh_active))input_.edit_allowed=false;
  input_.sculpt_mask_edit = !scene_.active().mesh_active && volume().sculpt_settings().mask_edit;
  if(state_.selection_mode)input_.edit_allowed=false;
  const auto displayed=mesh_.load();
  // Material-role publication gates mesh sampling. Direct voxel sculpt/mask
  // input remains valid while its first or updated display mesh is extracting.
  if(scene_.active().mesh_active&&
      (displayed->pbr_view!=state_.pbr_view||displayed->view_epoch!=state_.view_epoch)){
    input_.edit_allowed=false;
    // A press begun against the previous policy cannot become a stroke when
    // its replacement arrives. Modal controls still own their own events.
    if(!input_.menu_open())for(size_t i=0;i<2;++i)if(f.hands[i].tracked.trigger>.02f)state_.selection_release[i]=true;
  }
  bool menu_was = input_.menu_open();
  for (int i = 0; i < 2; ++i) {
    const auto &h = f.hands[i];
    SpatialSample s;
    s.id = i + 1;
    s.sequence = f.sequence;
    s.time = f.time;
    s.focused = f.focused;
    s.tracked = h.tracked.valid;
    s.tip = world_to_model(object_canvas, vec(h.tracked.grip.position));
    s.normal =
        vec(ob::rotate(ob::conjugate(object_canvas.orientation),
                       ob::rotate(h.tracked.grip.orientation, {0, 0, 1})));
    s.pressure = std::clamp(h.tracked.trigger, 0.f, 1.f);
    const bool owned_control=control_before_&&!state_.asset_busy&&!uv_accept_pending_&&
      control_object_==scene_.active().id&&control_source_.generation==state_.generation&&
      control_source_.edit_authority==state_.edit_authority&&input_.owns_control(state_.controls.parameter);
    if((state_.texture_face_select||state_.selection_mode)&&!owned_control)s.pressure=0;
    s.trigger = s.pressure > .02f;
    s.joystick_press = h.joystick;
    s.stick_x = h.x;
    s.stick_y = h.y;
    s.kind = h.kind;
    if (state_.controls.parameter != VrParameter::None && h.tracked.aimValid) {
      if (auto hit = panel_ray(state_.panel, h.tracked.aim)) {
        s.panel_hit = true;
        s.panel_u = hit->u;
        s.panel_v = hit->v;
      }
    }
    input_.update(s);
  }
  if(state_.polygon&&!menu_was)process_polygon_pointer_locked(f);
  for (auto event : input_.take_controls())
    control_event_locked(event);
  if (control_before_ && !uv_accept_pending_ && !input_.menu_open())
    finish_control_locked(false);
  if (!menu_was && input_.menu_open()) {
    state_.panel = {ob::transform(object_canvas, obv(input_.menu_anchor())),
                    f.head.orientation, 1};
    state_.panel.position = state_.panel.position +
                            ob::rotate(f.head.orientation, {0, .08f, -.18f});
  }
  bool import_published=false;
  if (auto c = input_.take_command()) {
    const auto command_page=input_.menu_page(),command_sector=input_.menu_index();const auto command_owner=input_.command_device();
    if (uv_ && !uv_->view().valid) {
      input_.resume_control(VrParameter::UvEdit);
      publish_locked();
      return;
    }
    state_.hands=f.hands;
    // Mask page commands already end their gesture on menu entry. Retain the
    // live page so toggles and Fill can be followed by Resume without losing it.
    if (!state_.retopology && !state_.cut && !sculpt_mask_command(*c) && !import_command(*c) && !projection_command(*c) && !preview_command(*c) && !rig_fit_command(*c) && !expression_command(*c) && !creator_command(*c) && !state_.creator &&
        !(input_.menu_page()==15 && *c==SpatialCommand::CancelWork) &&
        input_.menu_page()!=31 && input_.menu_page()!=30 && input_.menu_page()!=24 && input_.menu_page()!=18 && input_.menu_page()!=20 && input_.menu_page()!=19 && input_.menu_page()!=22 && !state_.polygon) finish_locked();
    const bool creator_owned_command=bool(state_.creator)||creator_command(*c);
    auto command_publication=published_.load();
    command_locked(*c);
    import_published=(import_command(*c)||projection_command(*c)||rig_fit_command(*c)||expression_command(*c)||creator_owned_command||
                      *c==SpatialCommand::RetopoBegin||*c==SpatialCommand::RetopoApply||*c==SpatialCommand::RetopoCancel)&&
                     published_.load()!=command_publication;
    if((command_page==31&&*c!=SpatialCommand::TexturePickFaces)||(command_page==30)||(command_page==20)||(command_page==24&&*c!=SpatialCommand::ShapeSculpt)){input_.retain_page(command_page,command_owner,command_sector);publish_locked(false,false);}
    // Opening/Apply/Cancel already published this frame's actual hands and
    // immutable owner. Do not reinterpret simultaneous history against the
    // newly opened/closed namespace or add a fallible second publication.
    if(import_published&&(creator_owned_command||*c==SpatialCommand::RetopoBegin||*c==SpatialCommand::RetopoApply||*c==SpatialCommand::RetopoCancel))return;
  }

  if (undo_requested) {
    if(state_.creator){creator_history_locked(false);
    }else if(state_.polygon){polygon_command_locked(SpatialCommand::Undo);
    } else if(state_.cut){cut_history_locked(false);
    } else if (state_.retopology) {
      if (!retopo_accepting_ && state_.retopology->source) {
        if (retopo_stroking_) { cancel_action_locked(); input_.cancel(); }
        else queue_retopology_locked(RetopoAction::Undo);
      }
    } else if (uv_) {
      if (!uv_accept_pending_ && !uv_solving_) apply_uv_action_locked(UvAction::Undo);
    } else if (weight_stroking_) {
      cancel_action_locked(); input_.cancel(); desktop_ = false;
    } else if (!state_.asset_busy) {
      finish_locked();
      undo_locked(false);
    }
  }
  if (redo_requested) {
    if(state_.creator){creator_history_locked(true);
    }else if(state_.polygon){polygon_command_locked(SpatialCommand::Redo);
    } else if(state_.cut){cut_history_locked(true);
    } else if (state_.retopology) {
      if (!retopo_accepting_ && !retopo_stroking_ && state_.retopology->source) queue_retopology_locked(RetopoAction::Redo);
    } else if (uv_) {
      if (!uv_accept_pending_ && !uv_solving_) apply_uv_action_locked(UvAction::Redo);
    } else if (!state_.asset_busy && !weight_stroking_) {
      finish_locked();
      undo_locked(true);
    }
  }
  if(!state_.creator&&!state_.selection_mode&&state_.shape_sculpt)process_shape_spatial_locked(f);
  state_.hands = f.hands;
  // Detached import/image admission already published the current hands/menu. A second
  // fallible publication must not report failure after accepting its file job.
  // Independent history buttons in this same frame still need normal handling.
  if(!import_published || undo_requested || redo_requested)
    if(!fit_initial_creator_locked(f))publish_locked();

}
void Document::cancel_spatial_menu() {
  std::lock_guard lock(model_mutex_);
  if(state_.creator){end_humanoid_creator_locked(false);return;}
  RetopoInputScope admission(*this,bool(state_.retopology)||(input_.menu_open()&&input_.menu_page()==16));
  finish_control_locked(false);
  if (!desktop_)
    input_.cancel();
  publish_locked();admission.commit();
}
void Document::input_loop() {
  while (!stopping_) {
    if(input_notice_pending_.load()){std::lock_guard lock(model_mutex_);retry_worker_notices_locked(true);}
    SpatialFrame f;
    bool reset = false;
    uint64_t generation = 0;
    {
      std::unique_lock lock(input_mutex_);
      input_changed_.wait(lock, [&] { return stopping_ || !inputs_.empty() || input_notice_pending_.load(); });
      if (stopping_)break;
      if(inputs_.empty()) {
        input_changed_.wait_for(lock,std::chrono::milliseconds(25),[&]{return stopping_||!inputs_.empty();});
        if(inputs_.empty())continue;
      }
      generation = inputs_.front().first;
      f = std::move(inputs_.front().second);
      inputs_.pop_front();
      reset = std::exchange(reset_input_, false);
      processing_ = true;
    }
    {
      std::lock_guard lock(model_mutex_);
      try {
        RetopoInputScope admission(*this,generation==state_.input_epoch &&
                                        (bool(state_.retopology)||(input_.menu_open()&&input_.menu_page()==16)));
        if(!state_.retopology)admission.opening_only();
        if (generation == state_.input_epoch) {
          // Resume only after this worker has cancelled/reported its failed
          // control. Recovery is independent of long file/authoring jobs.
          if(!worker_notices_[0]){if(reset&&!desktop_)input_.cancel();process_locked(f);}
        }
        admission.commit();
      } catch (...) {
        input_worker_error_locked(std::current_exception());
      }
    }
    {
      std::lock_guard lock(input_mutex_);
      processing_ = false;
    }
    input_changed_.notify_all();
  }
}
void Document::mesh_loop() {
  detail::SculptSceneChunks::Ptr sculpt_cache;
  struct FrameLayoutCache {
    std::weak_ptr<const Mesh> mesh;
    std::weak_ptr<const NormalFrameSet> frames;
    std::weak_ptr<const PaintSamplingAttachment> paint;
    std::shared_ptr<const std::vector<std::array<float,2>>> paint_coordinates;
    std::shared_ptr<const detail::NormalFrameLayout> layout;
    size_t bytes=0;
    bool dynamic_canonical=false;
  };
  std::unordered_map<uint64_t,FrameLayoutCache> frame_layouts;
  std::unordered_map<uint64_t,std::shared_ptr<const detail::TextureSetPackedGeometry>> texture_layouts;
  size_t texture_layout_bytes=0;
  size_t frame_layout_bytes=0;uint64_t frame_layout_builds=0;
  constexpr size_t frame_layout_limit=128*1024*1024;
  auto reserve_layout=[&](size_t bytes){
    if(bytes>frame_layout_limit)throw std::length_error("Immutable surface layout exceeds the shared cache budget");
    while(frame_layouts.size()+texture_layouts.size()>=256||frame_layout_bytes+texture_layout_bytes>frame_layout_limit-bytes){
      if(!frame_layouts.empty()){auto old=frame_layouts.begin();frame_layout_bytes-=old->second.bytes;frame_layouts.erase(old);}
      else if(!texture_layouts.empty()){auto old=texture_layouts.begin();texture_layout_bytes-=old->second->owned_bytes();texture_layouts.erase(old);}
      else break;
    }
  };
  std::shared_ptr<const geometry_detail::Identity> geometry_identity;
  while (!stopping_) {
    std::optional<MeshJob> job;
    {
      std::unique_lock lock(mesh_mutex_);
      mesh_changed_.wait(
          lock, [&] { return stopping_ || pending_mesh_.has_value(); });
      if (stopping_)
        break;
      job = std::move(pending_mesh_);
      pending_mesh_.reset();
    }
    auto cancelled = [&] {
      auto state = published_.load();
      return stopping_.load() || state->generation != job->generation || state->revision != job->revision || state->pbr_view!=job->pbr_view || state->view_epoch!=job->view_epoch ||
             (job->weight_gesture && weight_epoch_.load() != job->weight_gesture) ||
             (job->native_gesture && native_epoch_.load()!=job->native_gesture);
    };
    std::shared_ptr<VrmExpressionView> expression_result;
    try {
      if(job->expressions){
        expression_result=std::make_shared<VrmExpressionView>(*job->expressions);
        if(expression_result->entries.empty()){
          const auto catalog=describe_vrm1_expressions(*expression_result->baseline_,expression_result->object,cancelled);
          for(const auto &entry:catalog)expression_result->entries.push_back({entry.name,entry.custom,entry.binary,0});
          if(expression_result->entries.empty())throw std::logic_error("The actual VRM1 source has no expressions");
        }
        job->scene=bake_vrm1_expression_pose(*expression_result->baseline_,expression_result->object,expression_result->weights_,cancelled);
        expression_result->ready=true;expression_result->error.clear();
      }
      std::optional<Scene> proposed;
      if (job->weight_gesture) {
        proposed = job->scene.snapshot();
        paint_scene_weights(*proposed, job->scene.active().id, job->weight_samples,
                            job->weight_settings, cancelled);
      }
      // All geometry/scalar/query preparation stays on this worker. Candidate
      // owners remain detached until the exact generation/revision/view fences
      // accept the completed immutable snapshot below.
      const auto policy=published_.load();
      const bool wants_query=job->weight_view||policy->selection_mode||policy->object_grab_mode||
        std::any_of(job->scene.objects().begin(),job->scene.objects().end(),[](const auto &o){return o.visible&&(o.mesh_active||(o.polygon&&o.polygon->active));})||
        std::any_of(job->scene.objects().begin(),job->scene.objects().end(),[&](const auto &o){return o.visible&&job->scene.has_affine_placement(o.id);});
      SculptMeshingStats meshing;
      auto worker_start=std::chrono::steady_clock::now();
      auto sculpt_preview=detail::SculptSceneChunks::capture(job->scene,
          {job->generation,job->revision,job->view_epoch,job->sculpt_mask_view,wants_query},
          sculpt_cache,{},cancelled);
      auto objects=std::move(sculpt_preview.legacy);
      for(const auto &object:sculpt_preview.chunks->objects()) {
        const auto *previous=sculpt_cache?sculpt_cache->find(object.object):nullptr;
        const auto &report=object.geometry->report();
        if(previous&&previous->geometry==object.geometry)++meshing.objects_reused;
        else {
          if(report.kind==detail::SculptChunkReport::Kind::Local)++meshing.local_updates;
          else {++meshing.full_rebuilds;if(previous)++meshing.history_fallbacks;}
          meshing.rebuilt_tiles+=report.extracted_tiles;
        }
      }
      auto dependencies=std::make_shared<geometry_detail::Identity>();
      dependencies->generation=job->generation;
      dependencies->objects.reserve(job->scene.objects().size());
      for(const auto &o:job->scene.objects())if(o.visible&&!sculpt_preview.chunks->captures(o.id)) {
        geometry_detail::Dependency dep;dep.object=o.id;
        if(job->scene.has_affine_placement(o.id))dep.affine_world=job->scene.world_matrix(o.id);
        else dep.world=job->scene.world_transform(o.id);
        if(o.mesh_active){dep.paint=o.painted->mesh_owner();dep.paint_sampling_attachment=o.painted->paint_sampling_attachment();if(o.painted->source_maps()){dep.source_uv1=o.painted->source_maps()->uv1;dep.source_extra_uv=o.painted->source_maps()->extra_uv_sets;}}
        else {dep.volume=o.volume->geometry_owner();dep.voxel=o.volume->voxel_size();dep.band=o.volume->band();}
        dep.deformation=o.deformation;dep.appearance=o.appearance;dep.material_bindings=o.material_bindings;dep.polygon=o.polygon;
        if(auto frames=o.material_bindings?o.material_bindings->normal_frames:nullptr){
          dep.frame_positions=frames->position_domain;
          dep.frame_role=!job->pbr_view&&o.material_bindings->has_mtoon&&!geometry_detail::same_owner(frames->pbr,frames->mtoon)?1:0;
        }
        auto surface=std::find_if(objects.begin(),objects.end(),[&](const auto &s){return s.id==o.id;});
        dep.canonical=surface!=objects.end()&&surface->textures&&(!surface->textures->normal.rgba.empty()||
          (surface->textures->overlay&&surface->textures->overlay->source_baked_geometry()&&surface->textures->overlay->source_baked_normal()));
        if(surface!=objects.end()&&surface->texture_set_surface){
          const auto&plan=*surface->texture_set_surface;dep.texture_membership=plan.collection()->primary_domain();
          for(const auto&field:plan.fields())dep.texture_frames.push_back({field.id,field.painted->baked()&&!field.painted->baked()->maps.normal.rgba.empty()});
        }
        dependencies->objects.push_back(std::move(dep));
      }
      std::shared_ptr<const geometry_detail::Identity> identity=geometry_identity&&geometry_identity->matches(*dependencies)?geometry_identity:std::move(dependencies);
      auto snapshot = std::make_shared<MeshSnapshot>();
      snapshot->geometry_identity=identity;
      snapshot->sculpt_chunks=sculpt_preview.chunks;
      snapshot->sculpt_meshing=meshing;
      snapshot->revision = job->revision;
      snapshot->generation = job->generation;
      snapshot->pbr_view=job->pbr_view;
      snapshot->view_epoch=job->view_epoch;
      snapshot->weight_gesture = job->weight_gesture;
      snapshot->weight_samples = job->weight_samples.size();
      snapshot->native_gesture=job->native_gesture;snapshot->native_samples=job->native_samples;
      auto weighted = job->weight_view ? weight_objects(job->scene, job->scene.active().id, job->linked_weights)
                                      : std::vector<uint64_t>{};
      std::unordered_set<uint64_t> frame_objects,texture_objects;
      for (auto &o : objects) {
        if(o.texture_set_surface){
          texture_objects.insert(o.id);TextureSetLimits limits;limits.cancelled=cancelled;
          auto cached=texture_layouts.find(o.id);std::shared_ptr<const detail::TextureSetPackedGeometry>layout;
          if(cached!=texture_layouts.end()&&cached->second->matches_plan(*o.texture_set_surface))layout=cached->second;
          else{
            layout=detail::prepare_texture_set_packed(o.texture_set_surface,limits);const auto bytes=layout->owned_bytes();
            if(bytes>frame_layout_limit)throw std::length_error("Texture-set geometry exceeds the immutable layout cache bound");
            if(cached!=texture_layouts.end()){texture_layout_bytes-=cached->second->owned_bytes();texture_layouts.erase(cached);}
            reserve_layout(bytes);
            texture_layouts.emplace(o.id,layout);texture_layout_bytes+=bytes;++frame_layout_builds;
          }
          detail::TextureSetWorkerView view;view.render_only=true;view.pbr=job->pbr_view;view.weights=job->weight_view;view.masks=job->sculpt_mask_view;
          view.selected=std::find(weighted.begin(),weighted.end(),o.id)!=weighted.end();view.joint=job->weight_joint;
          view.weight_values=proposed?proposed->object(o.id).deformation:o.deformation;
          if(view.masks&&o.id==job->scene.active().id)view.mask=[&](uint32_t v){return job->scene.object(o.id).volume->mask_sample(layout->posed()->positions.at(v));};
          detail::append_texture_set_surface(*snapshot,o,layout,view,limits);continue;
        }
        auto colors=detail::current_vertex_colors(o,cancelled);
        const auto paint_attachment=o.paint_sampling_attachment;
        const auto polygon_field=o.textures?o.textures->polygon_surface:nullptr;
        if(polygon_field){polygon_field->validate_maps(*o.textures);if(!polygon_field->matches(o.material_bindings,paint_attachment))throw std::invalid_argument("Polygon worker field lost its current paint/material attachment");polygon_field->validate_world(o.world_matrix(),1e-6,cancelled);}
        if(paint_attachment&&snapshot->paint_coordinates.empty())snapshot->paint_coordinates=snapshot->mesh.uv;
        std::shared_ptr<const std::vector<std::array<float,2>>> paint_coordinates;
        const auto normal_domain=detail::retained_normal_coordinates(o.material_bindings.get(),o.textures.get());
        if(normal_domain){
          normal_domain->validate(cancelled);
          if(normal_domain->coordinates.size()!=o.mesh.positions.size()||normal_domain->indices!=o.mesh.indices)
            throw std::invalid_argument("Retained normal worker correspondence differs from current REST geometry");
          if(snapshot->normal_coordinates.empty()){
            snapshot->normal_coordinates.reserve(snapshot->mesh.positions.size());
            for(auto uv:snapshot->mesh.uv)snapshot->normal_coordinates.push_back({uv[0],uv[1],uv[0],uv[1]});
          }
        }
        if(!colors.empty() && snapshot->source_colors.empty())snapshot->source_colors.assign(snapshot->mesh.positions.size(),{1,1,1,1});
        auto retained=o.material_bindings?o.material_bindings->normal_frames:nullptr;
        const bool source8_normal=o.textures&&o.textures->overlay&&o.textures->overlay->source_baked_geometry()&&bool(o.textures->overlay->source_baked_normal());
        const bool canonical=!polygon_field && o.textures && !o.textures->normal_projection && (!o.textures->normal.rgba.empty()||source8_normal);
        // Existing bakes without captured canonical authority use the historical
        // posed-mesh Mikk basis. Do not invent a persisted/rest export basis.
        const bool dynamic_canonical=retained && canonical && !retained->canonical;
        std::shared_ptr<const detail::NormalFrameLayout> retained_layout;
        std::optional<detail::PosedNormalFrames> retained_pose;
        const size_t source_role=o.material_bindings&&o.material_bindings->has_mtoon&&!job->pbr_view&&(!retained||!geometry_detail::same_owner(retained->pbr,retained->mtoon))?1:0;
        if(retained) {
          detail::normal_frame_current_authority(*o.material_bindings,o.mesh,o.deformation.get(),cancelled);
          if(!(source_role?retained->mtoon:retained->pbr))throw std::invalid_argument("Selected material has no retained source normal frame");
        }
        if(!polygon_field&&(retained||paint_attachment)) {
          frame_objects.insert(o.id);auto mesh_owner=job->scene.object(o.id).painted->mesh_owner();
          auto old=frame_layouts.find(o.id);
          if(old!=frame_layouts.end() && old->second.mesh.lock()==mesh_owner && old->second.frames.lock()==retained && old->second.paint.lock()==paint_attachment && old->second.dynamic_canonical==dynamic_canonical) {
            retained_layout=old->second.layout;paint_coordinates=old->second.paint_coordinates;
          } else {
            if(dynamic_canonical||(!retained&&canonical)) {
              auto layout=std::make_shared<detail::NormalFrameLayout>();
              layout->vertices=o.mesh.indices;
              layout->corners.resize(o.mesh.indices.size());
              std::iota(layout->corners.begin(),layout->corners.end(),0u);
              layout->indices=layout->corners;
              retained_layout=std::move(layout);
            } else if(retained) retained_layout=std::make_shared<const detail::NormalFrameLayout>(detail::normal_frame_layout(o.mesh,*retained,cancelled));
            else {
              auto layout=std::make_shared<detail::NormalFrameLayout>();
              std::vector<uint32_t> map(o.mesh.positions.size(),UINT32_MAX);
              layout->indices.reserve(o.mesh.indices.size());
              for(size_t c=0;c<o.mesh.indices.size();++c) {
                if((c&1023)==0&&cancelled())throw std::runtime_error("Stale paint coordinate layout");
                auto v=o.mesh.indices[c];auto &packed=map.at(v);
                if(packed==UINT32_MAX){packed=uint32_t(layout->vertices.size());layout->vertices.push_back(v);layout->corners.push_back(uint32_t(c));}
                layout->indices.push_back(packed);
              }
              retained_layout=std::move(layout);
            }
            if(paint_attachment) {
              auto split=detail::split_frame_corner_coordinates(o.mesh,*retained_layout,o.paint_corner_coordinates,cancelled);
              retained_layout=std::make_shared<const detail::NormalFrameLayout>(std::move(split.frames));
              paint_coordinates=std::make_shared<const std::vector<std::array<float,2>>>(std::move(split.coordinates));
            }
            size_t bytes=(retained_layout->vertices.size()+retained_layout->corners.size()+retained_layout->indices.size())*sizeof(uint32_t)+(paint_coordinates?paint_coordinates->size()*sizeof(std::array<float,2>):0);
            if(bytes>frame_layout_limit)throw std::length_error("Immutable surface layout exceeds cache budget");
            if(old!=frame_layouts.end()){frame_layout_bytes-=old->second.bytes;frame_layouts.erase(old);}
            reserve_layout(bytes);
            frame_layouts.emplace(o.id,FrameLayoutCache{mesh_owner,retained,paint_attachment,paint_coordinates,retained_layout,bytes,dynamic_canonical});frame_layout_bytes+=bytes;++frame_layout_builds;
          }
        }
        if(polygon_field){
          auto layout=std::make_shared<detail::NormalFrameLayout>();layout->vertices=o.mesh.indices;layout->corners.resize(o.mesh.indices.size());std::iota(layout->corners.begin(),layout->corners.end(),0u);layout->indices=layout->corners;retained_layout=std::move(layout);
          paint_coordinates=std::make_shared<const std::vector<std::array<float,2>>>(polygon_field->paint_coordinates());
          if(snapshot->source_normals.empty()){snapshot->source_normals=snapshot->mesh.normals;snapshot->canonical_normals=snapshot->mesh.normals;snapshot->source_tangents.assign(snapshot->mesh.positions.size(),{1,0,0,1});}
          if(polygon_field->model()==detail::PolygonSurfaceNormalModel::PreparedCorePbr&&snapshot->normal_coordinates.empty()){for(auto uv:snapshot->mesh.uv)snapshot->normal_coordinates.push_back({uv[0],uv[1],uv[0],uv[1]});}
        }
        if(retained) {
          retained_pose=detail::normal_frame_preview(*retained,*retained_layout,o.deformation.get(),cancelled,(1u<<source_role)|(canonical?4u:0u));
          if(snapshot->source_normals.empty()) {
            snapshot->source_normals=snapshot->mesh.normals;snapshot->canonical_normals=snapshot->mesh.normals;
            snapshot->source_tangents.assign(snapshot->mesh.positions.size(),{1,0,0,1});
          }
        }
        const auto source_world_positions=detail::source_skin_world_positions(o,cancelled);
        if (o.deformation) o.mesh = o.preview_mesh();
        if(dynamic_canonical) {
          retained_pose->tangents[2]=tangent_corners(o.mesh,cancelled);
          retained_pose->normals[2].reserve(retained_layout->vertices.size());
          for(size_t v=0;v<retained_layout->vertices.size();++v) {
            if((v&1023)==0 && cancelled())throw std::runtime_error("Stale canonical bake preview");
            retained_pose->normals[2].push_back(o.mesh.normals.at(retained_layout->vertices[v]));
          }
        }
        if (cancelled()) throw std::runtime_error("Stale surface preview");
        const bool affine=bool(polygon_field)||bool(o.affine_edit)||std::any_of(o.groups.begin(),o.groups.end(),[](const auto &g){return g.source_placement||g.affine_edit;});
        const auto frame=affine?std::optional<detail::AffineInteractionFrame>(detail::placement_frame(o)):std::nullopt;
        const bool reflected=frame&&frame->orientation()==AffineOrientation::Reversing;
        auto world = affine?CanvasTransform{}:o.world_transform();
        size_t offset = snapshot->mesh.positions.size(), first = snapshot->mesh.indices.size();
        const size_t packed_vertices=retained_layout?retained_layout->vertices.size():canonical?o.mesh.indices.size():o.mesh.positions.size();
        if(packed_vertices>std::numeric_limits<size_t>::max()-offset ||
           (packed_vertices && offset+packed_vertices-1>std::numeric_limits<uint32_t>::max()) ||
           o.mesh.indices.size()>std::numeric_limits<size_t>::max()-first)
          throw std::length_error("Packed surface preview exceeds index or container address range");
        bool selected = std::find(weighted.begin(), weighted.end(), o.id) != weighted.end();
        if(retained && canonical && retained_pose->tangents[2].empty())
          throw std::invalid_argument("Baked normal detail requires a complete canonical preview basis");
        auto frames = canonical && !retained ? tangent_corners(o.mesh, cancelled)
                                            : std::vector<Tangent>{};
        std::shared_ptr<std::vector<std::array<float,2>>> packed_uv1;
        std::vector<uint32_t> overlay_vertices;
        if(o.textures&&o.textures->overlay)overlay_vertices.reserve(packed_vertices);
        std::map<uint32_t,std::shared_ptr<std::vector<std::array<float,2>>>> packed_extra_uv;
        if(o.textures&&o.textures->source_maps&&!o.textures->source_maps->extra_uv_sets.empty()){o.textures->source_maps->validate_surface(o.mesh);for(const auto &[set,owner]:o.textures->source_maps->extra_uv_sets){auto values=std::make_shared<std::vector<std::array<float,2>>>();values->reserve(packed_vertices);packed_extra_uv.emplace(set,std::move(values));}}
        if(o.textures&&o.textures->source_maps&&o.textures->source_maps->uv1){
          o.textures->source_maps->validate_surface(o.mesh);packed_uv1=std::make_shared<std::vector<std::array<float,2>>>();packed_uv1->reserve(packed_vertices);
        }
        auto append = [&](uint32_t vertex, Tangent tangent, size_t frame_vertex=SIZE_MAX) {
          if(o.textures&&o.textures->overlay)overlay_vertices.push_back(vertex);
          if(paint_attachment||!snapshot->paint_coordinates.empty())snapshot->paint_coordinates.push_back(paint_attachment?paint_coordinates->at(frame_vertex):o.mesh.uv.empty()?std::array<float,2>{}:o.mesh.uv.at(vertex));
          if(packed_uv1)packed_uv1->push_back(o.textures->source_maps->uv1->at(vertex));
          for(auto &[set,values]:packed_extra_uv)values->push_back(o.textures->source_maps->extra_uv_sets.at(set)->at(vertex));
          if(normal_domain||polygon_field&&polygon_field->model()==detail::PolygonSurfaceNormalModel::PreparedCorePbr||!snapshot->normal_coordinates.empty()){
            const auto uv=polygon_field&&polygon_field->model()==detail::PolygonSurfaceNormalModel::PreparedCorePbr?polygon_field->normal_coordinates().at(frame_vertex):normal_domain?normal_domain->coordinates.at(vertex):o.mesh.uv.empty()?std::array<float,2>{}:o.mesh.uv.at(vertex);
            const auto toon=normal_domain&&!normal_domain->mtoon_coordinates.empty()?normal_domain->mtoon_coordinates.at(vertex):uv;
            snapshot->normal_coordinates.push_back({uv[0],uv[1],toon[0],toon[1]});
          }
          if(!colors.empty() || !snapshot->source_colors.empty())snapshot->source_colors.push_back(colors.empty()?std::array<float,4>{1,1,1,1}:colors.at(vertex));
          snapshot->mesh.positions.push_back(source_world_positions?source_world_positions->at(vertex):frame?detail::placed_position(*frame,o.mesh.positions.at(vertex)):vec(ob::transform(world, obv(o.mesh.positions.at(vertex)))));
          snapshot->mesh.normals.push_back(frame?detail::placed_normal(*frame,o.mesh.normals.at(vertex)):vec(ob::rotate(world.orientation, obv(o.mesh.normals.at(vertex)))));
          snapshot->mesh.uv.push_back(o.mesh.uv.empty() ? std::array<float,2>{0,0} : o.mesh.uv.at(vertex));
          auto direction = vec(ob::rotate(world.orientation, obv({tangent[0],tangent[1],tangent[2]})));
          snapshot->tangents.push_back(frame?detail::placed_tangent(*frame,tangent):Tangent{direction.x,direction.y,direction.z,tangent[3]});
          // A first polygon-field object has no earlier mesh to seed these arrays.
          // Publish its actual before attributes even while the packed prefix is empty.
          if(polygon_field || retained || !snapshot->source_normals.empty()) {
            auto source=o.mesh.normals.at(vertex),canonical_normal=source;
            std::array<float,4> source_tangent{1,0,0,1};
            if(polygon_field){source=polygon_field->normals().at(frame_vertex);if(!polygon_field->tangents().empty())source_tangent=polygon_field->tangents().at(frame_vertex);}
            if(retained) {
              source=retained_pose->normals[source_role].at(frame_vertex);
              if(!retained_pose->normals[2].empty())canonical_normal=retained_pose->normals[2].at(frame_vertex);
              if(!retained_pose->tangents[source_role].empty())source_tangent=retained_pose->tangents[source_role].at(frame_vertex);
            }
            snapshot->source_normals.push_back(frame?detail::placed_normal(*frame,source):vec(ob::rotate(world.orientation,obv(source))));
            snapshot->canonical_normals.push_back(frame?detail::placed_normal(*frame,canonical_normal):vec(ob::rotate(world.orientation,obv(canonical_normal))));
            auto t=vec(ob::rotate(world.orientation,obv({source_tangent[0],source_tangent[1],source_tangent[2]})));
            snapshot->source_tangents.push_back(frame?detail::placed_tangent(*frame,source_tangent):Tangent{t.x,t.y,t.z,source_tangent[3]});
          }
          if (job->sculpt_mask_view)
            snapshot->sculpt_masks.push_back(o.id == job->scene.active().id
                ? job->scene.object(o.id).volume->mask_sample(o.mesh.positions.at(vertex)) : -1.f);
          if (job->weight_view) {
            float value = selected ? 0.f : -1.f;
            const auto &deformation = proposed ? proposed->object(o.id).deformation : o.deformation;
            if (selected) for (auto influence : deformation->skin->vertices.at(vertex))
              if (influence.joint == job->weight_joint) value = influence.weight;
            snapshot->selected_weights.push_back(value);
          }
        };
        std::shared_ptr<const CreatorAppearance> appearance = o.appearance;
        if(retained_layout) {
          std::shared_ptr<CreatorAppearance> expanded;
          if(o.appearance){expanded=std::make_shared<CreatorAppearance>(*o.appearance);expanded->source_vertices.clear();expanded->source_vertices.reserve(retained_layout->vertices.size());}
          for(size_t v=0;v<retained_layout->vertices.size();++v) {
            auto vertex=retained_layout->vertices[v];auto tangent=canonical?(retained?retained_pose->tangents[2].at(v):frames.at(retained_layout->corners[v])):Tangent{1,0,0,1};
            append(vertex,tangent,v);if(expanded)expanded->source_vertices.push_back(o.appearance->source_vertices.at(vertex));
          }
          for(auto v:retained_layout->indices)snapshot->mesh.indices.push_back(uint32_t(offset+v));
          if(expanded)appearance=std::move(expanded);
        } else if (canonical) {
          std::shared_ptr<CreatorAppearance> expanded;
          if (o.appearance) {
            if (o.appearance->source_vertices.size() != o.mesh.positions.size())
              throw std::runtime_error("Render-only source remap differs from rest vertex count");
            expanded = std::make_shared<CreatorAppearance>(*o.appearance);
            expanded->source_vertices.clear(); expanded->source_vertices.reserve(o.mesh.indices.size());
          }
          // Expand only this render snapshot. Rest meshes, skin/morph indices
          // and original source records remain immutable in Scene/history.
          for (size_t corner = 0; corner < o.mesh.indices.size(); ++corner) {
            auto vertex = o.mesh.indices[corner]; append(vertex, frames.at(corner));
            snapshot->mesh.indices.push_back(uint32_t(offset + corner));
            if (expanded) expanded->source_vertices.push_back(o.appearance->source_vertices.at(vertex));
          }
          if (expanded) appearance = std::move(expanded);
        } else {
          for (size_t vertex = 0; vertex < o.mesh.positions.size(); ++vertex) append(uint32_t(vertex), {1,0,0,1});
          for (auto vertex : o.mesh.indices) snapshot->mesh.indices.push_back(uint32_t(offset + vertex));
        }
        // Packed vertices are already in world coordinates. Compensate the
        // reflected orientation once so GPU and material-aware ray front faces
        // agree with the original local primitive. Rest indices stay untouched.
        if(reflected)for(size_t c=first;c<snapshot->mesh.indices.size();c+=3)std::swap(snapshot->mesh.indices[c+1],snapshot->mesh.indices[c+2]);
        auto textures=o.textures;
        // Original logical UV0 is independent of image-role carriers. Even an
        // empty-role Source8 packet must follow the actual packed->current
        // vertex map when canonical Mikk expands shared vertices to corners.
        const bool packed_logical=textures&&textures->overlay&&textures->overlay->original_uv0();
        if(packed_uv1||!packed_extra_uv.empty()||packed_logical){auto maps=std::make_shared<PaintSourceMaps>(*textures->source_maps);if(packed_uv1)maps->uv1=std::move(packed_uv1);for(auto &[set,values]:packed_extra_uv)maps->extra_uv_sets[set]=std::move(values);auto packed=std::make_shared<TextureMaps>(*textures);packed->source_maps=std::move(maps);
          if(packed->overlay)packed->overlay=detail::PaintOverlayFactory::pack_source_maps(packed->overlay,packed->source_maps,overlay_vertices,cancelled);
          textures=std::move(packed);}
        snapshot->ranges.push_back({o.id, first, o.mesh.indices.size(), o.material, std::move(textures), std::move(appearance), offset, o.material_bindings, bool(retained), bool(retained && canonical), bool(retained && retained_pose->tangents[source_role].empty()),world,!affine});
        snapshot->ranges.back().paint_sampling_attachment=paint_attachment;
        if(o.normal_preview_proof&&o.normal_preview_proof->matches(o.material_bindings,snapshot->ranges.back().textures))snapshot->ranges.back().normal_preview_proof=o.normal_preview_proof;
        snapshot->ranges.back().paint_winding_reversed=reflected;
        snapshot->ranges.back().pbr_view=job->pbr_view;
        if(polygon_field){snapshot->ranges.back().source_frame=true;snapshot->ranges.back().canonical_frame=false;snapshot->ranges.back().source_normal_only=polygon_field->model()==detail::PolygonSurfaceNormalModel::NativeNOnly;}
        if(frame)snapshot->ranges.back().affine_world=frame->world();
      }
      for(auto it=frame_layouts.begin();it!=frame_layouts.end();)if(!frame_objects.contains(it->first) || it->second.mesh.expired() || (it->second.frames.expired()&&it->second.paint.expired())){frame_layout_bytes-=it->second.bytes;it=frame_layouts.erase(it);}else ++it;
      for(auto it=texture_layouts.begin();it!=texture_layouts.end();)if(!texture_objects.contains(it->first)){texture_layout_bytes-=it->second->owned_bytes();it=texture_layouts.erase(it);}else ++it;
      snapshot->normal_frame_layout_builds=frame_layout_builds;
      const bool has_polygon_colors=std::any_of(objects.begin(),objects.end(),[](const ObjectSurface &o){return bool(o.polygon_colors);});
      if (!texture_objects.empty()||has_polygon_colors||!snapshot->paint_coordinates.empty()||wants_query) {
        // The actual typed owner retains separate packed and chunk triangle
        // spaces, with one total query budget. No whole sculpt flatten occurs.
        if(!snapshot->mesh.indices.empty()||!snapshot->sculpt_chunks->objects().empty())
          snapshot->picking=std::make_shared<MaterialSurfaceQuery>(snapshot->mesh,snapshot->ranges,cancelled,
              snapshot->source_colors,PaintVertexCoordinates{snapshot->paint_coordinates},snapshot->sculpt_chunks);
      }
      snapshot->sculpt_meshing.worker_ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-worker_start).count();
      if(expression_result){
        std::lock_guard model_lock(model_mutex_);
        if(cancelled()||!state_.expressions||state_.expressions->request!=job->expressions->request)continue;
        expression_result->selected=state_.expressions->selected;
        Transaction transaction(*this);state_.expressions=std::move(expression_result);state_.message="Expression preview only; Apply static pose or Cancel";publish_locked(false,false);
        {std::lock_guard mesh_lock(mesh_mutex_);geometry_identity=std::move(identity);sculpt_cache=snapshot->sculpt_chunks;mesh_.store(std::move(snapshot));}
        transaction.commit(false);
      }else{
        std::lock_guard lock(mesh_mutex_);
        if(!cancelled()){geometry_identity=std::move(identity);sculpt_cache=snapshot->sculpt_chunks;mesh_.store(std::move(snapshot));}
      }
    } catch (const std::exception &e) {
      if (!cancelled()) {
        std::lock_guard lock(model_mutex_);
        if (cancelled()) continue;
        if(job->expressions&&state_.expressions&&state_.expressions->request==job->expressions->request){
          auto failed=expression_result?expression_result:std::make_shared<VrmExpressionView>(*state_.expressions);
          failed->selected=state_.expressions->selected;failed->ready=false;failed->error=e.what();state_.expressions=std::move(failed);
        }
        state_.error=e.what();publish_locked(false,false);
      }
    }
    mesh_changed_.notify_all();
  }
}
bool Document::wait_mesh(std::chrono::milliseconds timeout) const {
  auto wanted = published_.load();
  std::unique_lock lock(mesh_mutex_);
  auto ready = [&] {
    auto m = mesh_.load();
    return m->generation == wanted->generation && m->revision >= wanted->revision && m->pbr_view==wanted->pbr_view && m->view_epoch==wanted->view_epoch &&
           (!wanted->cut || (m->cut_session==wanted->cut->session && m->cut_request>=wanted->cut->request)) &&
           (!wanted->native_samples || (m->native_gesture==wanted->native_gesture && m->native_samples>=wanted->native_samples)) &&
           (!wanted->weight_samples || (m->weight_gesture == wanted->weight_gesture &&
                                       m->weight_samples >= wanted->weight_samples));
  };
  return mesh_changed_.wait_for(lock, timeout, [&] {
    auto current=published_.load();
    return ready() || stopping_.load() || current->generation != wanted->generation || current->pbr_view!=wanted->pbr_view || current->view_epoch!=wanted->view_epoch ||
           (wanted->cut && (!current->cut || current->cut->session!=wanted->cut->session ||
             (!current->cut->busy && !current->cut->error.empty()))) ||
           (wanted->expressions&&current->expressions&&current->expressions->request==wanted->expressions->request&&!current->expressions->error.empty()) ||
           (wanted->weight_samples && weight_epoch_.load() != wanted->weight_gesture);
  }) && ready();
}
bool Document::wait_input(std::chrono::milliseconds timeout) const {
  std::unique_lock lock(input_mutex_);
  return input_changed_.wait_for(
      lock, timeout, [&] { return inputs_.empty() && !processing_; });
}
void Document::open(const std::filesystem::path &path) { open_async(path).get(); }
void Document::save(const std::filesystem::path &path) { save_async(path).get(); }
std::future<void> Document::open_async(const std::filesystem::path &path) {
  if (path.empty()) throw std::invalid_argument("Choose a project filename");
  auto completion = std::make_shared<std::promise<void>>();
  auto result = completion->get_future();
  std::lock_guard lock(model_mutex_);
  finish_locked();
  if (state_.asset_busy || state_.recovery_busy)
    throw std::logic_error("Wait for pending authoring work before opening a project");
  auto work = std::make_shared<AssetWork>();
  FileJob job{};
  job.path = path; job.revision = state_.revision; job.generation = state_.generation;
  job.content = content_; job.open_project = true; job.completion = completion;
  job.work = work; job.operation_label = "Open project";
  std::lock_guard file_lock(file_mutex_);
  if(files_.size()>=8)throw std::runtime_error("File work queue is full");
  Transaction transaction(*this);files_.push_back(std::move(job));
  try{
    asset_work_.store(std::move(work));state_.asset_busy=true;state_.error.clear();state_.message="Opening "+path.string();
    publish_locked(false,false);transaction.commit();
  }catch(...){files_.pop_back();throw;}
  file_changed_.notify_one();
  return result;
}
std::future<void> Document::save_async(const std::filesystem::path &path) {
  if (path.empty()) throw std::invalid_argument("Choose a project filename");
  auto completion = std::make_shared<std::promise<void>>();
  auto result = completion->get_future();
  {
    std::lock_guard lock(model_mutex_);
    if(state_.asset_busy) {
      auto token=asset_work_.load();
      if(token&&token->accepted_scene) {
      FileJob job{};job.path=path;job.adopt_path=true;job.completion=completion;
      job.asset_capture=std::move(token);job.generation=state_.generation;
      std::lock_guard file_lock(file_mutex_);
      if(files_.size()>=8)throw std::runtime_error("File work queue is full");
      // The accepted operation is already ahead of us on this ordered worker.
      // No worker may wait for work queued behind itself.
      files_.push_back(std::move(job));
      files_.back().asset_capture->save_requested.store(true);
      file_changed_.notify_one();return result;
      }
    }
    if(polygon_accepting_.load()&&polygon_accept_) {
      FileJob job{};job.path=path;job.adopt_path=true;job.completion=completion;
      job.polygon_capture=polygon_accept_;job.generation=polygon_accept_->source.generation;
      std::lock_guard file_lock(file_mutex_);if(files_.size()>=8)throw std::runtime_error("File work queue is full");
      files_.push_back(std::move(job));file_changed_.notify_one();return result;
    }
    if(native_stroke_) {
      FileJob job{};job.path=path;job.adopt_path=true;job.completion=completion;job.native_capture=native_stroke_;
      Transaction transaction(*this);std::lock_guard file_lock(file_mutex_);
      if(files_.size()>=8)throw std::runtime_error("File work queue is full");
      files_.push_back(std::move(job));
      try{transaction.stage_native_end();state_.message="Finishing desktop stroke before saving";publish_locked(false,false);transaction.commit();}
      catch(...){files_.pop_back();throw;}
      file_changed_.notify_one();return result;
    }
    if(!state_.polygon)finish_locked();
    if (state_.asset_busy || state_.recovery_busy)
      throw std::logic_error("Wait for pending authoring work before saving");
    if(last_volume_!=volume().revision()||last_paint_!=(scene_.active().mesh_active?scene_.active().painted->revision():0))publish_locked();
    Transaction transaction(*this);
    std::lock_guard file_lock(file_mutex_);
      if (files_.size() >= 8) throw std::runtime_error("File work queue is full");
      FileJob job{};job.path=path;job.revision=state_.revision;job.generation=state_.generation;
      job.content=content_;job.adopt_path=true;job.completion=completion;job.object=scene_.active().id;
      // The authoritative cache already shares the frozen mesh-job snapshot.
      // Clone paint/volume metadata only on the file worker. The initial empty
      // document has no mesh publication yet and needs its tiny fallback.
      job.capture_scene=native_source_scene_?native_source_scene_:std::make_shared<const Scene>(scene_.snapshot());
      job.recovery_source=recovery_source_;
      files_.push_back(std::move(job));
    try{
    state_.error.clear(); state_.message = "Saving " + path.string();
    publish_locked(false,false);transaction.commit();
    }catch(...){files_.pop_back();throw;}
  }
  file_changed_.notify_one();
  return result;
}

std::future<void> Document::export_asset(const std::filesystem::path &path,
                                       AssetExportFormat format) {
  if (path.empty() || (format != AssetExportFormat::Glb && format != AssetExportFormat::Avatar &&
      format != AssetExportFormat::EditableGlb256 && format != AssetExportFormat::EditableGlb512 &&
      format != AssetExportFormat::EditableGlb1024 && format != AssetExportFormat::EditableAvatar256 &&
      format != AssetExportFormat::EditableAvatar512 && format != AssetExportFormat::EditableAvatar1024))
    throw std::invalid_argument("Choose an export filename and supported format");
  auto completion = std::make_shared<std::promise<void>>();
  auto result = completion->get_future();
  std::lock_guard lock(model_mutex_);
  finish_locked();
  if (state_.asset_busy || state_.recovery_busy)
    throw std::logic_error("Wait for pending authoring work before exporting");
  if ((format == AssetExportFormat::Avatar || format == AssetExportFormat::EditableAvatar256 ||
       format == AssetExportFormat::EditableAvatar512 || format == AssetExportFormat::EditableAvatar1024) && !state_.can_export_avatar)
    throw std::logic_error("Select a source avatar group to export");
  FileJob job{scene_.snapshot(), path, state_.revision, state_.generation, content_, true};
  job.object = scene_.active().id; job.export_format = format; job.completion = completion;
  queue_export_locked(std::move(job));
  return result;
}
void Document::queue_export_locked(FileJob job) {
  std::lock_guard file_lock(file_mutex_);
  if(files_.size()>=8)throw std::runtime_error("File work queue is full");
  auto slot=std::find(exports_.begin(),exports_.end(),nullptr);
  if(slot==exports_.end())throw std::runtime_error("Export work queue is full");
  auto work=std::make_shared<ExportWork>();job.export_work=work;
  job.operation_label="Export";
  auto message="Exporting "+job.path.string();
  Transaction transaction(*this);files_.push_back(std::move(job));
  *slot=work;
  try{state_.error.clear();state_.message=std::move(message);publish_locked(false,false);transaction.commit();}
  catch(...){slot->reset();files_.pop_back();throw;}
  file_changed_.notify_one();
}
void Document::retire_export_locked(const std::shared_ptr<ExportWork> &work) noexcept {
  if(!work)return;
  for(auto &slot:exports_)if(slot==work){slot.reset();break;}
  work->phase.store(ExportWork::Phase::Finished);
}
void Document::file_locked(bool export_mesh, AssetExportFormat format) {
  auto token=asset_work_.load();
  const bool accepted=state_.asset_busy&&token&&token->accepted_scene;
  if (state_.asset_busy&&(!accepted||export_mesh))
    throw std::logic_error(
        "Wait for mesh/UV preparation before saving or exporting");
  auto path = path_;
  bool create_parent = path.empty();
  if (path.empty()) {
    const char *state = getenv("XDG_STATE_HOME"), *home = getenv("HOME");
    auto dir =
        state ? std::filesystem::path(state)
              : std::filesystem::path(home ? home : "/tmp") / ".local/state";
    dir /= "dome-sculpt";
    path = dir / ("Recovery-" + std::to_string(getpid()) + ".dsculpt");
  }
  if (export_mesh)
    path.replace_extension((format == AssetExportFormat::Avatar || format == AssetExportFormat::EditableAvatar256 ||
      format == AssetExportFormat::EditableAvatar512 || format == AssetExportFormat::EditableAvatar1024) ? ".vrm" : ".glb");
  if(accepted) {
    FileJob job{};job.path=path;job.create_parent=create_parent;
    job.asset_capture=std::move(token);job.generation=state_.generation;
    std::lock_guard lock(file_mutex_);
    if(files_.size()>=8)throw std::runtime_error("File work queue is full");
    files_.push_back(std::move(job));
    files_.back().asset_capture->save_requested.store(true);
    file_changed_.notify_one();return;
  }
  FileJob job{scene_.snapshot(),path,state_.revision,state_.generation,content_,export_mesh};
  job.recovery_source=recovery_source_;job.create_parent=create_parent;job.export_format=format;job.object=scene_.active().id;
  if(export_mesh){queue_export_locked(std::move(job));return;}
  std::lock_guard lock(file_mutex_);
  if(files_.size()>=8)throw std::runtime_error("File work queue is full");
  files_.push_back(std::move(job)); // No throwing preparation after handoff.
  file_changed_.notify_one();

}
void Document::request_save(bool export_mesh) {
  std::lock_guard lock(model_mutex_);
  finish_locked();
  publish_locked();
  file_locked(export_mesh);
}
bool Document::parameter_enabled_locked(VrParameter parameter) const {
  if(state_.creator||parameter==VrParameter::CreatorValue)return parameter==VrParameter::CreatorValue&&creator_source_matches_locked()&&!state_.asset_busy&&!control_before_;
  if(parameter==VrParameter::ShapeMirror){const auto &o=scene_.active();return shape_target_ready_locked()&&o.deformation&&o.deformation->morphs&&state_.morph_target<o.deformation->morphs->targets.size();}
  if(parameter==VrParameter::MorphWeight&&state_.shape_sculpt)return false;
  if(parameter==VrParameter::ShapeRestore)return state_.can_restore_shapes;
  if(parameter==VrParameter::PolygonConversion)return !state_.polygon&&state_.can_polygon&&(polygon_conversion_required(scene_.active())||state_.polygon_has_source);
  if(parameter==VrParameter::PolygonDistance||parameter==VrParameter::PolygonCuts)return state_.polygon&&state_.polygon->surface&&!polygon_accepting_&&!polygon_stroking_&&!state_.asset_busy;
  if(state_.polygon)return false;
  if(parameter==VrParameter::ImportUnitScale)return import_view_&&!import_view_->busy&&!state_.asset_busy&&!state_.recovery_busy&&!action_active_locked()&&!state_.cut&&!state_.retopology;
  if(!object_editable_locked(scene_.active().id) && parameter!=VrParameter::BrushRadius && parameter!=VrParameter::Flow)return false;
  if(parameter==VrParameter::CutOffset||parameter==VrParameter::CutDirection||parameter==VrParameter::CutCapColor)
    return state_.cut&&cut_bake_source_&&!state_.cut->committing&&!state_.asset_busy;
  if(state_.cut)return false;
  if (procedural_parameter(parameter)) return resolution_target_ready_locked();
  if (parameter==VrParameter::SculptResolution) return resolution_target_ready_locked();
  if (sculpt_parameter(parameter)) return sculpt_target_ready_locked();
  if (parameter == VrParameter::RetopoDistance)
    return state_.retopology && state_.retopology->source && !retopo_accepting_ && !state_.asset_busy;
  if (state_.retopology) return false;
  if(skin_parameter(parameter)) return !(state_.skin_options.mode==SkinAuthoringMode::SurfaceHeat&&parameter==VrParameter::SkinFalloff) && (state_.skin_options.mode!=SkinAuthoringMode::Anatomical || parameter==VrParameter::SkinSource || parameter==VrParameter::SkinMode) && skin_target_ready_locked() &&
    (parameter==VrParameter::SkinSource ? !skin_sources_locked(state_.skin_options.mode).empty()
      : !skin_sources_locked(SkinAuthoringMode::Automatic).empty());
  if(parameter==VrParameter::BakeSource&&canonical_conversion_ready_locked())return true;
  if(parameter==VrParameter::BakeSource || parameter==VrParameter::BakeDistances || parameter==VrParameter::BakeQuality || parameter==VrParameter::BakeProjection || parameter==VrParameter::BakeColors)
    return bake_target_ready_locked() && !bake_sources_locked().empty();
  if (parameter == VrParameter::WeightStrength || parameter == VrParameter::WeightValue)
    return !state_.asset_busy && !state_.recovery_busy && state_.can_paint_weights;
  if (parameter == VrParameter::RigRotation || parameter == VrParameter::MorphWeight) {
    const auto &o = scene_.active();
    if (state_.asset_busy || state_.recovery_busy || !o.visible || o.locked ||
        !o.mesh_active || !o.painted || !o.deformation) return false;
    const auto &d = *o.deformation;
    return parameter == VrParameter::RigRotation
        ? d.skeleton && d.skin && !d.skeleton->bones.empty()
        : d.morphs && !d.morphs->targets.empty();
  }
  if (parameter == VrParameter::TriangleEdge) {
    const auto &o=scene_.active();
    return !state_.asset_busy&&!state_.recovery_busy&&o.visible&&!o.locked&&
      scene_.objects().size()<256&&(o.mesh_active?bool(o.painted):!o.volume->voxels().empty());
  }
  if (parameter == VrParameter::VoxelSize) {
    const auto &o = scene_.active();
    return !scene_.has_affine_placement(o.id) && !state_.asset_busy && !state_.recovery_busy && o.visible && !o.locked &&
           scene_.objects().size() < 256 &&
           (o.mesh_active ? bool(o.painted) : !o.volume->voxels().empty());
  }
  if (parameter == VrParameter::SculptOpacity)
    return !state_.asset_busy && !scene_.active().mesh_active &&
           scene_.active().visible && !scene_.active().locked;
  if (parameter == VrParameter::UvEdit) {
    auto &o = scene_.active();
    return !state_.asset_busy && o.mesh_active && o.painted && o.visible &&
           !o.locked;
  }
  if (state_.asset_busy || parameter == VrParameter::None)
    return false;
  auto &o = scene_.active();
  if(parameter==VrParameter::TextureResolution&&!o.texture_sets)return object_editable_locked(o.id)&&detail::unpainted_bake_resolution_target(o)&&!action_active_locked()&&!state_.recovery_busy;
  if(o.texture_sets&&detail::texture_set_control(parameter))return object_editable_locked(o.id)&&detail::texture_set_plain_fields(o)&&!action_active_locked()&&!state_.recovery_busy;
  if (parameter == VrParameter::LayerOpacity ||
      parameter == VrParameter::LayerOrder)
    return o.mesh_active && o.painted &&
           (parameter != VrParameter::LayerOrder ||
            active_texture_set(o).painted->layers().size() > 1);
  return true;
}
void Document::finish_control_locked(bool accept) {
  if(state_.controls.parameter==VrParameter::CreatorValue){finish_creator_control_locked(accept);return;}
  if (!control_before_)
    return;
  if((control_before_->object(control_object_).texture_sets||(state_.controls.parameter==VrParameter::TextureResolution&&detail::unpainted_bake_resolution_target(control_before_->object(control_object_))))&&detail::texture_set_control(state_.controls.parameter)){
    auto controls=std::move(state_.controls);const auto source=control_source_;
    auto before=std::move(control_before_);control_before_.reset();state_.controls={};const bool changed=control_changed_;control_changed_=false;
    try{if(accept&&changed){auto edit=detail::texture_set_control_request(before->object(control_object_),controls);queue_texture_set_locked(std::move(edit),source);}}
    catch(...){control_before_=std::move(before);state_.controls=std::move(controls);control_changed_=changed;input_.resume_control(state_.controls.parameter);throw;}
    return;
  }
  if(state_.controls.parameter==VrParameter::BakeSource){
    static_assert(std::is_nothrow_move_constructible_v<VrControlState> && std::is_nothrow_move_assignable_v<VrControlState>);
    auto controls=std::move(state_.controls);
    auto before=std::move(control_before_);control_before_.reset();state_.controls={};control_changed_=false;
    try{
      if(accept){
        require_authority_locked(control_source_);
        if(control_source_.generation!=state_.generation||control_source_.revision!=state_.revision||control_source_.object!=scene_.active().id)
          throw std::logic_error("Bake source changed; reopen source and cage controls");
        if(controls.components!=2||!std::isfinite(controls.value[0])||!std::isfinite(controls.value[1])||
            controls.value[0]<0||controls.value[0]>1||controls.value[1]<0||controls.value[1]>1)
          throw std::invalid_argument("Invalid source and cage controls");
        auto ids=bake_sources_locked(),cages=bake_cages_locked();
        if(ids.empty())return; // Conversion-only legacy project: Done changes no bake binding.
        const auto source=ids.at(size_t(std::lround(controls.value[0]*float(ids.size()-1))));
        const auto cage=cages.at(size_t(std::lround(controls.value[1]*float(cages.size()-1))));
        Transaction transaction(*this);
        if(controls.bake_preset)state_.bake_settings=controls.bake_preset->settings;
        state_.bake_source=source;state_.bake_settings.cage_object=cage;
        publish_locked(false,false);transaction.commit(false);
      }
    }catch(...){control_before_=std::move(before);state_.controls=std::move(controls);input_.resume_control(VrParameter::BakeSource);throw;}
    return;
  }
  if(state_.controls.parameter==VrParameter::ShapeMirror){
    static_assert(std::is_nothrow_move_constructible_v<VrControlState> && std::is_nothrow_move_assignable_v<VrControlState>);
    auto controls=std::move(state_.controls);const auto source=control_source_;
    auto before=std::move(control_before_);control_before_.reset();state_.controls={};control_changed_=false;
    try{
      if(accept){auto edit=detail::mirror_control_request(controls);
        if(state_.morph_target!=edit.target)throw std::logic_error("Shape selection changed; reopen Mirror controls");
        queue_shape_locked(std::move(edit),source);
      }
    }catch(...){control_before_=std::move(before);state_.controls=std::move(controls);input_.resume_control(VrParameter::ShapeMirror);throw;}
    return;
  }
  if(state_.controls.parameter==VrParameter::ShapeRestore){
    auto controls=state_.controls;auto source=control_source_;bool restore=accept&&controls.value[0]>=.5f;
    auto before=std::move(control_before_);control_before_.reset();state_.controls={};control_changed_=false;
    try{if(restore){ShapeKeyEdit edit;edit.action=ShapeKeyAction::Restore;queue_shape_locked(std::move(edit),source);}}
    catch(...){control_before_=std::move(before);state_.controls=controls;input_.resume_control(VrParameter::ShapeRestore);throw;}
    return;
  }
  if(state_.controls.parameter==VrParameter::PolygonConversion){
    const auto controls=state_.controls;const auto source=control_source_;
    const unsigned choice=accept?unsigned(std::lround(controls.value[0])):0;
    auto before=std::move(control_before_);control_before_.reset();state_.controls={};control_changed_=false;
    try{
      if(choice==2)restore_polygon_source_locked(source);
      else if(choice==1)begin_polygon_locked(polygon_conversion_required(scene_.active()));
    }catch(...){control_before_=std::move(before);state_.controls=controls;input_.resume_control(VrParameter::PolygonConversion);throw;}
    return;
  }
  if(state_.controls.parameter==VrParameter::PolygonDistance||state_.controls.parameter==VrParameter::PolygonCuts){
    if(accept){if(state_.controls.parameter==VrParameter::PolygonDistance)state_.polygon_controls.distance_mm=state_.controls.value[0];else state_.polygon_controls.cuts=unsigned(std::lround(state_.controls.value[0]));}
    control_before_.reset();control_changed_=false;state_.controls={};return;
  }
  if(state_.controls.parameter==VrParameter::ImportUnitScale){
    if(accept&&import_view_){auto next=std::make_shared<ImportView>(*import_view_);
      if(control_changed_)next->settings.choices.custom_metres_per_unit=state_.controls.value[0];
      next->settings.choices.units=ImportUnits::Custom;next->settings.validate();import_view_=std::move(next);}
    control_before_.reset();control_changed_=false;state_.controls={};return;
  }
  if(state_.controls.parameter==VrParameter::CutOffset||state_.controls.parameter==VrParameter::CutDirection||state_.controls.parameter==VrParameter::CutCapColor){
    finish_cut_parameter_locked(accept);return;
  }
  if(procedural_parameter(state_.controls.parameter)) {
    const auto c=state_.controls;
    if(accept) {
      auto options=state_.procedural_options;
      if(c.parameter==VrParameter::ProceduralPattern)options.pattern=ProceduralSculptOptions::Pattern(unsigned(std::lround(c.value[0])));
      else if(c.parameter==VrParameter::ProceduralFace){auto face=unsigned(std::lround(c.value[0]));options.axis=face/2;options.reverse=(face%2)!=0;}
      else if(c.parameter==VrParameter::ProceduralGrid){options.rows=unsigned(std::lround(c.value[0]));options.columns=unsigned(std::lround(c.value[1]));}
      else if(c.parameter==VrParameter::ProceduralCoverage){options.density=c.value[0];options.gap=c.value[1]*.9f;options.rounding=c.value[2];}
      else if(c.parameter==VrParameter::ProceduralDepth)options.depth=std::clamp(float(double(c.value[0])/(double(scene_.world_transform(control_object_).scale)*1000)),.00001f,10.f);
      else options.seed=uint32_t(std::lround(c.value[0]));
      options.validate();state_.procedural_options=std::move(options);
    }
    control_before_.reset();control_changed_=false;state_.controls={};return;
  }
  if(state_.controls.parameter==VrParameter::SculptResolution) {
    const float mm=state_.controls.value[0];
    auto before=std::move(control_before_);control_before_.reset();
    if(accept) {
      SculptResolutionOptions options;const double factor=double(scene_.world_transform(control_object_).scale)*1000;
      options.voxel_size=mm==float(double(control_resolution_voxel_)*factor)?control_resolution_voxel_:
          std::clamp(float(double(mm)/factor),.00001f,1.f);
      try {queue_resolution_locked(options,control_source_);}
      catch(...) {control_before_=std::move(before);throw;}
    }
    control_changed_=false;state_.controls={};return;
  }
  if (sculpt_parameter(state_.controls.parameter)) {
    auto settings = volume().sculpt_settings();
    const auto c = state_.controls;
    auto before = std::move(control_before_); control_before_.reset();
    if (accept) {
      if (c.parameter == VrParameter::SculptMaskMode) settings.mask_tool = Volume::MaskTool(int(std::lround(c.value[0])));
      else if (c.parameter == VrParameter::SculptMaskStrength) settings.mask_strength = c.value[0];
      else {
        float *axes[]={&settings.symmetry_origin.x,&settings.symmetry_origin.y,&settings.symmetry_origin.z};
        for(int k=0;k<3;++k) if(c.value[k]!=sculpt_plane_slider(*axes[k])) *axes[k]=sculpt_plane_metres(c.value[k]);
        settings.mask_visible = c.value[3] >= .5f;
      }
      try { sculpt_settings_locked(settings, control_source_); }
      catch (...) { control_before_ = std::move(before); throw; }
    }
    control_changed_ = false; state_.controls = {}; return;
  }
  if(skin_parameter(state_.controls.parameter)) {
    const auto c=state_.controls;
    if(accept) {
      auto &options=state_.skin_options;
      if(c.parameter==VrParameter::SkinSource) {
        auto ids=skin_sources_locked(options.mode); options.reference=ids.at(size_t(std::lround(c.value[0])));
      } else if(c.parameter==VrParameter::SkinMode) options.mode=detail::skin_method_mode(int(std::lround(c.value[0])));
      else if(c.parameter==VrParameter::SkinDistances) {
        options.seed_distance=skin_distance_metres(c.value[0]);
        options.seed_margin=skin_distance_metres(c.value[1]);
        options.transfer_distance=skin_distance_metres(c.value[2]);
      } else if(c.parameter==VrParameter::SkinFalloff) options.falloff=c.value[0];
      else if(c.parameter==VrParameter::SkinInfluences) options.limits.max_influences=uint32_t(std::lround(c.value[0]));
      else if(c.parameter==VrParameter::SkinPrune) options.limits.prune=c.value[0];
    }
    control_before_.reset();control_changed_=false;state_.controls={};return;
  }
  if (state_.controls.parameter == VrParameter::RetopoDistance) {
    retopo_snap_mm_ = accept ? state_.controls.value[0] : control_retopo_mm_;
    if (state_.retopology) {
      auto view = std::make_shared<RetopoView>(*state_.retopology);
      view->snap_mm = retopo_snap_mm_; state_.retopology = view;
    }
    control_before_.reset(); control_changed_ = false; state_.controls = {}; return;
  }
  if(state_.controls.parameter==VrParameter::BakeDistances || state_.controls.parameter==VrParameter::BakeQuality || state_.controls.parameter==VrParameter::BakeProjection || state_.controls.parameter==VrParameter::BakeColors){
    auto c=state_.controls;
    if(accept){
      if(c.parameter==VrParameter::BakeDistances){state_.bake_settings.front_mm=c.value[0];state_.bake_settings.back_mm=c.value[1];state_.bake_settings.ao_distance_mm=c.value[2];}
      else if(c.parameter==VrParameter::BakeColors){state_.bake_settings.prepare_colors=c.value[0]>=.5f;state_.bake_settings.color_error=c.value[1];state_.bake_settings.prepare_normals=c.value[2]>=.5f;state_.bake_settings.normal_error=c.value[3]*.25f;}
      else if(c.parameter==VrParameter::BakeProjection){state_.bake_settings.allow_partial=c.value[0]>=.5f;state_.bake_settings.allow_backfaces=c.value[1]>=.5f;}
      else {state_.bake_settings.ao_samples=uint32_t(std::lround(c.value[0]*256));state_.bake_settings.padding=uint32_t(std::lround(c.value[1]*64));}
    }
    control_before_.reset();control_changed_=false;state_.controls={};return;
  }
  if (state_.controls.parameter == VrParameter::RigRotation ||
      state_.controls.parameter == VrParameter::MorphWeight) {
    auto controls = state_.controls;
    if (accept && control_changed_) {
      RigEdit edit;
      if (controls.parameter == VrParameter::RigRotation)
        edit.joint = JointAdjustment{uint32_t(control_rig_index_),
                                     {controls.value[0], controls.value[1], controls.value[2]}, {}};
      else edit.morph = MorphWeightEdit{uint32_t(control_rig_index_), controls.value[0]};
      auto before = std::move(control_before_);
      control_before_.reset();
      try {
        auto object = control_object_;
        queue_scene_operation_locked("Edit rig and shapekeys",
          [object, edit](Scene &scene, const auto &cancelled) { edit_rig(scene, object, edit, cancelled); },
          control_source_, {});
      } catch (...) {
        control_before_ = std::move(before);
        throw;
      }
    } else control_before_.reset();
    control_changed_ = false;
    state_.controls = {};
    return;
  }
  if (state_.controls.parameter == VrParameter::TriangleEdge) {
    if(accept){
      auto before=std::move(control_before_);control_before_.reset();
      try{queue_triangle_remesh_locked(state_.controls.value[0],control_source_);}
      catch(...){control_before_=std::move(before);throw;}
    }else control_before_.reset();
    control_changed_=false;state_.controls={};return;
  }
  if (state_.controls.parameter == VrParameter::VoxelSize) {
    if (accept) {
      auto before = std::move(control_before_);
      control_before_.reset();
      try {
        queue_voxel_sculpt_locked(state_.controls.value[0], control_source_);
      } catch (...) {
        control_before_ = std::move(before);
        throw;
      }
    } else {
      control_before_.reset();
      state_.voxel_size_mm = control_voxel_mm_;
    }
    control_changed_ = false;
    state_.controls = {};
    return;
  }
  if (uv_) {
    if (accept && (uv_solving_ || !uv_->view().topology))
      throw std::logic_error("Wait for the UV workspace before applying");
    if (accept && uv_accept_pending_)
      return;
    if (accept && !uv_->view().valid && !uv_->view().validating)
      throw std::runtime_error(uv_->view().error);
    if (accept) {
      auto draft = uv_->view().mesh;
      auto &old = scene_.active().painted->mesh();
      bool changed = uv_changed(*draft, old)||uv_retention_changes_locked();
      if (changed) {
        uv_->edit(UvAction::EndGesture);
        queue_uv_locked(draft);
        return;
      }
    }
    Transaction transaction(*this);transaction.finish_uv();
    publish_locked(false,false);transaction.commit();return;
  }
  Transaction transaction(*this);
  bool sculpt_control = state_.controls.parameter == VrParameter::SculptOpacity;
  bool changed = control_changed_;
  if (accept && changed) record_locked({{},*control_before_,scene_});
  else scene_=*control_before_;
  if(!accept){state_.paint=control_settings_;state_.weights=control_weights_;state_.radius=control_radius_;}
  control_before_.reset();control_changed_=false;state_.controls={};
  if(sculpt_control){input_.refresh_volume(volume());bound_volume_=scene_.active().volume;}
  publish_locked(changed,false);transaction.commit();
}

void Document::control_event_locked(VrControlEvent event) {
  if(event.parameter==VrParameter::CreatorValue){creator_control_locked(event);return;}
  if(event.type==VrControlEventType::Begin&&event.parameter==VrParameter::ShapeMirror){
    finish_control_locked(false);
    if(!parameter_enabled_locked(event.parameter))throw std::logic_error("Choose an editable shapekey before mirroring");
    Transaction transaction(*this);
    const auto &target=scene_.active().deformation->morphs->targets.at(state_.morph_target);
    VrControlState controls;controls.parameter=VrParameter::ShapeMirror;controls.title="Mirror / "+target.name;
    controls.components=3;controls.value={0,.5f,1.f/3.f,float(state_.morph_target)};
    control_before_=scene_;control_object_=scene_.active().id;
    control_source_={state_.generation,state_.revision,control_object_,state_.edit_authority};
    control_changed_=false;state_.controls=std::move(controls);state_.message.clear();
    publish_locked(false,false);transaction.commit(false);return;
  }
  if (event.type == VrControlEventType::Begin) {
    finish_control_locked(false);
    if (!parameter_enabled_locked(event.parameter))
      throw std::logic_error("This XR control is unavailable");
    control_before_ = scene_;
    control_settings_ = state_.paint;
    control_weights_ = state_.weights;
    control_radius_ = state_.radius;
    control_object_ = scene_.active().id;
    control_source_ = {state_.generation, state_.revision, control_object_,state_.edit_authority};
    control_changed_ = false;
    auto &o = scene_.active();
    auto &c = state_.controls;
    c = {};
    c.parameter = event.parameter;
    if (event.parameter == VrParameter::UvEdit) {
      try {
        ++uv_session_;
        uv_.emplace(std::shared_ptr<const Mesh>(o.painted, &o.painted->mesh()),
                    o.painted->resolution());
        c.value[3]=(detail::canonical_paint_retention_supported(o)||o.painted->paint_sampling_domain())?2.f:(o.material_bindings&&o.material_bindings->canonical_attributes)||(o.painted->normal_projection()&&o.painted->normal_projection()->version==2)?1.f:0.f;
        c.title = "UV editor";
      } catch (...) {
        control_before_.reset();
        state_.controls = {};
        throw;
      }
      state_.message.clear();
      return;
    }
    switch (event.parameter) {
    case VrParameter::ShapeRestore:
      c.title="Restore original mesh, paint and rig?";c.minimum=0;c.maximum=1;c.value[0]=0;break;
    case VrParameter::PolygonConversion:
      c.title=state_.polygon_has_source?"Edit current shape or restore retained source":"Convert visible shape; retain original source?";c.minimum=0;c.maximum=state_.polygon_has_source&&!state_.object_grabbing?2:1;c.value[0]=0;break;
    case VrParameter::PolygonDistance:
      c.title="Polygon operation distance (world mm)";c.minimum=.001f;c.maximum=1e6f;c.logarithmic=true;c.value[0]=state_.polygon_controls.distance_mm;break;
    case VrParameter::PolygonCuts:
      c.title="Polygon edge subdivision cuts";c.minimum=1;c.maximum=64;c.value[0]=state_.polygon_controls.cuts;break;
    case VrParameter::ImportUnitScale:
      c.title="Input metres per unit";c.minimum=1e-12f;c.maximum=1e12f;c.logarithmic=true;
      c.value[0]=std::clamp(float(import_view_->settings.choices.custom_metres_per_unit),c.minimum,c.maximum);break;
    case VrParameter::CutOffset:
      control_cut_settings_=cut_settings_;c.title="Cut offset (document mm)";
      c.minimum=-state_.cut->offset_limit_mm;c.maximum=state_.cut->offset_limit_mm;c.value[0]=cut_settings_.offset_mm;break;
    case VrParameter::CutDirection:
      control_cut_settings_=cut_settings_;c.title="Cut yaw / pitch (degrees)";c.components=2;
      c.minimum=-180;c.maximum=180;c.value={cut_settings_.yaw,cut_settings_.pitch,0,0};break;
    case VrParameter::CutCapColor:
      control_cut_settings_=cut_settings_;c.title="Cut cap RGBA";c.components=4;c.value=cut_settings_.cap_material.color;break;
    case VrParameter::ProceduralPattern:
      c.title="Detail: panels / recesses / mixed";c.maximum=2;c.value[0]=unsigned(state_.procedural_options.pattern);break;
    case VrParameter::ProceduralFace:
      c.title="Object-local projection face";c.maximum=5;c.value[0]=state_.procedural_options.axis*2+state_.procedural_options.reverse;break;
    case VrParameter::ProceduralGrid:
      c.title="Detail grid: rows / columns";c.minimum=1;c.maximum=32;c.components=2;
      c.value={float(state_.procedural_options.rows),float(state_.procedural_options.columns),0,0};break;
    case VrParameter::ProceduralCoverage:
      c.title="Density / gap / rounding";c.components=3;
      c.value={state_.procedural_options.density,state_.procedural_options.gap/.9f,state_.procedural_options.rounding,0};break;
    case VrParameter::ProceduralDepth: {
      const double factor=double(scene_.world_transform(o.id).scale)*1000;
      c.title="Detail depth (world mm)";c.minimum=float(.00001*factor);c.maximum=float(10*factor);c.logarithmic=true;
      c.value[0]=float(state_.procedural_options.depth*factor);break;
    }
    case VrParameter::ProceduralSeed:
      c.title="Detail random seed";c.maximum=65535;c.value[0]=float(state_.procedural_options.seed&65535);break;
    case VrParameter::SculptResolution: {
      const double factor=double(scene_.world_transform(o.id).scale)*1000;
      control_resolution_voxel_=volume().voxel_size();
      c.title="Sculpt resolution (world mm)";c.minimum=float(double(.00001f)*factor);
      c.maximum=float(factor);c.value[0]=float(double(control_resolution_voxel_)*factor);c.logarithmic=true;break;
    }
    case VrParameter::SculptMaskMode:
      c.title="Sculpt mask tool"; c.maximum=2; c.value[0]=int(volume().sculpt_settings().mask_tool); break;
    case VrParameter::SculptMaskStrength:
      c.title="Sculpt mask strength"; c.value[0]=volume().sculpt_settings().mask_strength; break;
    case VrParameter::SculptPlanes: {
      const auto settings=volume().sculpt_settings();
      c.title="Local mirror planes / protection view"; c.components=4;
      c.value={sculpt_plane_slider(settings.symmetry_origin.x),sculpt_plane_slider(settings.symmetry_origin.y),sculpt_plane_slider(settings.symmetry_origin.z),settings.mask_visible?1.f:0.f}; break;
    }
    case VrParameter::SkinSource: {
      auto ids=skin_sources_locked(state_.skin_options.mode);c.title="Skin reference (rest space)";
      c.maximum=float(ids.size()-1);
      auto found=std::find(ids.begin(),ids.end(),state_.skin_options.reference);
      c.value[0]=found==ids.end()?0:float(found-ids.begin());break;
    }
    case VrParameter::SkinMode: {
      c.title="Method: Legacy / transfer / source / Automatic";
      c.maximum=3;
      c.value[0]=float(detail::skin_method_choice(state_.skin_options.mode));break;
    }
    case VrParameter::SkinDistances:
      c.title=state_.skin_options.mode==SkinAuthoringMode::SurfaceHeat?"Seed radius (world mm)":"Seed / margin / transfer (world mm)";c.components=state_.skin_options.mode==SkinAuthoringMode::SurfaceHeat?1:3;
      c.value={skin_distance_slider(state_.skin_options.seed_distance),skin_distance_slider(state_.skin_options.seed_margin),skin_distance_slider(state_.skin_options.transfer_distance),0};break;
    case VrParameter::SkinFalloff:
      c.title="Automatic bind distance falloff";c.minimum=1;c.maximum=8;c.value[0]=state_.skin_options.falloff;break;
    case VrParameter::SkinInfluences:
      c.title="Maximum skin influences";c.minimum=1;c.maximum=32;c.value[0]=state_.skin_options.limits.max_influences;break;
    case VrParameter::SkinPrune:
      c.title="Prune influences below";c.maximum=.99f;c.value[0]=state_.skin_options.limits.prune;break;
    case VrParameter::RetopoDistance:
      control_retopo_mm_ = retopo_snap_mm_;
      c.title = "Retopology projection distance (mm)";
      c.minimum = 1; c.maximum = 200; c.logarithmic = true; c.value[0] = retopo_snap_mm_; break;
    case VrParameter::BakeSource: {
      auto ids=bake_sources_locked(),cages=bake_cages_locked();
      c.title="Bake source / editable cage (hidden meshes allowed)";c.components=2;
      auto found=std::find(ids.begin(),ids.end(),state_.bake_source);
      c.value[0]=ids.size()<2||found==ids.end()?0:float(found-ids.begin())/float(ids.size()-1);
      auto cage=std::find(cages.begin(),cages.end(),state_.bake_settings.cage_object);
      c.value[1]=cages.size()<2||cage==cages.end()?0:float(cage-cages.begin())/float(cages.size()-1);break;
    }
    case VrParameter::BakeDistances:
      c.title="Projection / AO distance (world mm)";c.components=3;c.minimum=0;c.maximum=float(bake_distance_max_mm);c.logarithmic=true;
      c.value={state_.bake_settings.front_mm,state_.bake_settings.back_mm,state_.bake_settings.ao_distance_mm,0};
      for(int k=0;k<3;++k)c.value[k]=std::clamp(c.value[k],c.minimum,c.maximum);
      break;
    case VrParameter::TextureResolution:
      if(!o.texture_sets&&!detail::unpainted_bake_resolution_target(o))throw std::logic_error("Choose an actual texture field before resizing");
      c.title=o.texture_sets?"Selected material paint resolution":"Target paint resolution";c.minimum=0;c.maximum=5;c.value[0]=float(std::countr_zero(active_texture_set(o).painted->resolution())-6);break;
    case VrParameter::BakeColors:
      c.title="Color / normal preparation and maximum errors";c.components=4;
      c.value={state_.bake_settings.prepare_colors?1.f:0.f,state_.bake_settings.color_error,state_.bake_settings.prepare_normals?1.f:0.f,state_.bake_settings.normal_error*4};break;
    case VrParameter::BakeProjection:
      c.title="Projection: partial / backfaces";c.components=2;
      c.value={state_.bake_settings.allow_partial?1.f:0.f,state_.bake_settings.allow_backfaces?1.f:0.f,0,0};break;
    case VrParameter::BakeQuality:
      c.title="AO samples / seam padding";c.components=2;
      c.value={state_.bake_settings.ao_samples/256.f,state_.bake_settings.padding/64.f,0,0};break;
    case VrParameter::WeightStrength:
      c.title = "Weight stroke strength"; c.value[0] = state_.weights.strength;
      break;
    case VrParameter::WeightValue:
      c.title = "Target weight"; c.value[0] = state_.weights.value;
      break;
    case VrParameter::RigRotation:
      control_rig_index_ = state_.rig_joint;
      c.title = o.deformation->skeleton->bones.at(control_rig_index_).name + " rotation delta";
      c.components = 3; c.minimum = -180; c.maximum = 180;
      break;
    case VrParameter::MorphWeight:
      control_rig_index_ = state_.morph_target;
      c.title = o.deformation->morphs->targets.at(control_rig_index_).name;
      c.minimum = -1; c.maximum = 1;
      c.value[0] = o.deformation->morph_weights.empty() ? 0 : o.deformation->morph_weights.at(control_rig_index_);
      break;
    case VrParameter::TriangleEdge:
      c.title="Isotropic remesh edge (mm)";c.minimum=.01f;c.maximum=1000;
      c.logarithmic=true;c.value[0]=50;break;
    case VrParameter::VoxelSize:
      control_voxel_mm_ = state_.voxel_size_mm;
      c.title = "Voxel remesh size (mm)";
      c.minimum = std::max(.01f, .01f * o.transform.scale);
      c.maximum = std::min(1000.f, 1000.f * o.transform.scale);
      c.logarithmic = true;
      c.value[0] = state_.voxel_size_mm =
          std::clamp(state_.voxel_size_mm, c.minimum, c.maximum);
      break;
    case VrParameter::BrushRadius:
      c.title = "Brush size";
      c.minimum = .005f;
      c.maximum = 2;
      c.logarithmic = true;
      c.value[0] = state_.radius;
      break;
    case VrParameter::Flow:
      c.title = "Paint flow";
      c.value[0] = state_.paint.flow;
      break;
    case VrParameter::Metallic:
      c.title = "Material metalness";
      c.value[0] = o.texture_sets?active_texture_set(o).material.metallic:o.material.metallic;
      break;
    case VrParameter::Roughness:
      c.title = "Material roughness";
      c.value[0] = o.texture_sets?active_texture_set(o).material.roughness:o.material.roughness;
      break;
    case VrParameter::Opacity:
      c.title = "Material opacity";
      c.value[0] = o.texture_sets?active_texture_set(o).material.color[3]:o.material.color[3];
      break;
    case VrParameter::BaseColor:
      c.title = "Material color";
      c.components = 4;
      c.value = o.texture_sets?active_texture_set(o).material.color:o.material.color;
      break;
    case VrParameter::InkColor:
      c.title = "Brush color";
      c.components = 4;
      c.value = state_.paint.color;
      break;
    case VrParameter::EmissionSource: {
      c.title="No associated original emission";c.components=0;
      if(auto info=detail::emission_source_info(o)){c.title="Retained original emission";for(size_t k=0;k<3;++k)c.value[k]=info->factor[k];c.value[3]=info->strength;}
      break;
    }
    case VrParameter::InkEmissionUnits:
      c.title="Brush units / relative normalizes";c.value[0]=state_.paint.emission_units==PaintEmissionUnits::Physical?1:0;break;
    case VrParameter::MaterialEmission: {
      const auto material=o.texture_sets?active_texture_set(o).material:o.material;
      const auto binding=o.texture_sets?active_texture_set(o).material_bindings:o.material_bindings;
      c.title=material.unlit?"Unlit material ignores emission":binding&&binding->physical_emission?"Absolute background radiance":"Material emission / linear radiance";
      c.components=3;c.maximum=maximum_native_emission;const auto &value=binding&&binding->physical_emission?*binding->physical_emission:material.emissive;
      for(size_t k=0;k<3;++k)c.value[k]=value[k];break;
    }
    case VrParameter::InkEmission:
      c.title = state_.paint.emission_units==PaintEmissionUnits::Physical?"Physical brush / linear radiance":"Material-relative emission brush";
      c.maximum=state_.paint.emission_units==PaintEmissionUnits::Physical?maximum_native_emission:1;
      c.components = 3;
      for (int i = 0; i < 3; ++i)
        c.value[i] = state_.paint.emission[i];
      break;
    case VrParameter::InkMetallic:
      c.title = "Paint metalness";
      c.value[0] = state_.paint.metallic;
      break;
    case VrParameter::InkRoughness:
      c.title = "Paint roughness";
      c.value[0] = state_.paint.roughness;
      break;
    case VrParameter::Mask:
      c.title = "Mask value";
      c.value[0] = state_.paint.mask;
      break;
    case VrParameter::SculptOpacity: {
      c.title = "Sculpt layer strength";
      c.value[0] = state_.sculpt_layer_opacity;
      o.volume = std::make_shared<Volume>(o.volume->geometry_snapshot());
      break;
    }
    case VrParameter::LayerOpacity:
    case VrParameter::LayerOrder: {
      const auto field=active_texture_set(o);const auto &layers = field.painted->layers();
      auto it = std::find_if(layers.begin(), layers.end(), [&](auto &l) {
        return l.id == field.painted->active_layer();
      });
      c.title = event.parameter == VrParameter::LayerOpacity ? "Layer opacity"
                                                             : "Layer order";
      c.value[0] = event.parameter == VrParameter::LayerOpacity
                       ? it->opacity
                       : float(it - layers.begin());
      if (event.parameter == VrParameter::LayerOrder)
        c.maximum = float(layers.size() - 1);
      if(!o.texture_sets)o.painted = o.painted->snapshot();
      break;
    }
    default:
      break;
    }
    state_.message=o.texture_sets&&detail::texture_set_control(event.parameter)?"Texture-set changes are staged until Apply":std::string{};
    return;
  }
  if (!control_before_ || event.parameter != state_.controls.parameter)
    return;
  if ((uv_accept_pending_ || uv_solving_) && event.type != VrControlEventType::Cancel)
    return;
  auto &c = state_.controls;
  if(event.type==VrControlEventType::ConvertCanonicalNormals){
    if(c.parameter!=VrParameter::BakeSource||!canonical_conversion_ready_locked())return;
    const auto source=control_source_;require_authority_locked(source);
    auto controls=std::move(state_.controls);auto before=std::move(control_before_);
    control_before_.reset();state_.controls={};control_changed_=false;
    try{queue_convert_bake_locked(source);input_.complete_control();}
    catch(...){control_before_=std::move(before);state_.controls=std::move(controls);input_.resume_control(VrParameter::BakeSource);throw;}
    return;
  }
  if(event.type==VrControlEventType::RecallBakeRecipe){
    if(c.parameter!=VrParameter::BakeSource)return;
    const auto recipe=scene_.active().bake_recipe;
    if(!recipe){state_.message="No successful bake has been saved for this target";return;}
    require_authority_locked(control_source_);
    if(control_source_.generation!=state_.generation||control_source_.revision!=state_.revision||control_source_.object!=scene_.active().id)
      throw std::logic_error("Bake recipe target changed; reopen controls");
    const auto sources=bake_sources_locked(),cages=bake_cages_locked();
    const auto source=std::find(sources.begin(),sources.end(),recipe->source.object);
    const auto cage=std::find(cages.begin(),cages.end(),recipe->settings.cage_object);
    if(source==sources.end()||cage==cages.end())throw std::logic_error("Saved bake dependency is unavailable; select its replacement");
    Transaction transaction(*this);
    c.bake_preset=recipe;c.title="Source / cage - recipe staged";c.value[0]=sources.size()<2?0:float(source-sources.begin())/float(sources.size()-1);
    c.value[1]=cages.size()<2?0:float(cage-cages.begin())/float(cages.size()-1);
    publish_locked(false,false);transaction.commit(false);return;
  }
  if (uv_ && event.type != VrControlEventType::Confirm &&
      event.type != VrControlEventType::Cancel) {
    try {
      if (event.type == VrControlEventType::UvPick)
        apply_uv_action_locked(UvAction::Pick, event.value, event.second);
      else if (event.type == VrControlEventType::UvMove)
        apply_uv_action_locked(UvAction::Move, event.value, event.second);
      else if (event.type == VrControlEventType::UvCommand &&
               event.component >= 0 &&
               event.component <= int(UvAction::RestorePaintSource))
        apply_uv_action_locked(UvAction(event.component), event.value, event.second);
      state_.error.clear();
    } catch (const std::exception &e) {
      state_.error = e.what();
    }
    return;
  }
  if (event.type == VrControlEventType::Confirm ||
      event.type == VrControlEventType::Cancel) {
    if (event.type == VrControlEventType::Confirm && uv_ &&
        (!uv_->view().topology || (!uv_->view().valid && !uv_->view().validating))) {
      state_.error = uv_->view().error;
      input_.resume_control(VrParameter::UvEdit);
      return;
    }
    finish_control_locked(event.type == VrControlEventType::Confirm);
    return;
  }
  if (event.component < 0 || event.component >= c.components ||
      !std::isfinite(event.value))
    return;
  c.selected = event.component;
  if (event.type == VrControlEventType::Select)
    return;
  float value = c.value[event.component];
  if (event.type == VrControlEventType::Absolute) {
    float t = std::clamp(event.value, 0.f, 1.f);
    value = c.parameter==VrParameter::BakeDistances ? float(bake_distance_from_unit(t)) : detail::emission_control_scale(c)?detail::emission_control_value(t,c.maximum):c.logarithmic ? std::exp(std::log(c.minimum) +
                                     t * std::log(c.maximum / c.minimum))
                          : c.minimum + t * (c.maximum - c.minimum);
  } else
    value = c.parameter==VrParameter::BakeDistances ? float(bake_distance_step(value,event.value*.69314718056)) : detail::emission_control_scale(c)?detail::emission_control_value(std::clamp(detail::emission_control_fraction(value,c.maximum)+event.value*.5f,0.f,1.f),c.maximum):c.logarithmic ? value * std::exp(event.value * .69314718056f)
                          : value + event.value * .5f * (c.maximum - c.minimum);
  value = std::clamp(value, c.minimum, c.maximum);
  if (value == c.value[event.component])
    return;
  if(c.parameter==VrParameter::ShapeMirror&&event.component==0)value=std::round(value*2)/2;
  c.value[event.component] = value;
  auto &o = scene_.object(control_object_);
  auto &before = control_before_->object(control_object_);
  if((o.texture_sets||(c.parameter==VrParameter::TextureResolution&&detail::unpainted_bake_resolution_target(o)))&&detail::texture_set_control(c.parameter)){
    const auto original=active_texture_set(before);auto request=detail::texture_set_control_request(before,c);
    if(request.action==TextureSetAction::Resolution)control_changed_=request.resolution!=original.painted->resolution();
    else if(request.action==TextureSetAction::Material)control_changed_=!detail::same_texture_material(request.material,original.material);
    else{const auto&layers=original.painted->layers();const auto at=std::find_if(layers.begin(),layers.end(),[&](const auto&l){return l.id==request.layer;});
      if(at==layers.end())throw std::logic_error("Texture-set controls lost their selected layer");
      control_changed_=request.action==TextureSetAction::LayerOpacity?request.value!=at->opacity:int(std::lround(request.value))!=int(at-layers.begin());}
    publish_locked(false,false);return;
  }
  bool scene_changed = false;
  switch (c.parameter) {
  case VrParameter::CutOffset:
  case VrParameter::CutDirection:
  case VrParameter::CutCapColor: {
    auto settings=cut_settings_;
    if(c.parameter==VrParameter::CutOffset)settings.offset_mm=value;
    else if(c.parameter==VrParameter::CutDirection){settings.yaw=c.value[0];settings.pitch=c.value[1];}
    else settings.cap_material.color=c.value;
    edit_cut_locked(std::move(settings),false);break;
  }
  case VrParameter::PolygonDistance:
  case VrParameter::PolygonCuts:
  case VrParameter::PolygonConversion:
  case VrParameter::ShapeRestore:
  case VrParameter::ShapeMirror:
    break;
  case VrParameter::ImportUnitScale:
    control_changed_=true;break;
  case VrParameter::ProceduralPattern:
  case VrParameter::ProceduralFace:
  case VrParameter::ProceduralGrid:
  case VrParameter::ProceduralCoverage:
  case VrParameter::ProceduralDepth:
  case VrParameter::ProceduralSeed:
  case VrParameter::SculptResolution:
  case VrParameter::SculptMaskMode:
  case VrParameter::SculptMaskStrength:
  case VrParameter::SculptPlanes:
  case VrParameter::RetopoDistance:
    break; // Projection settings take effect only on confirmation.
  case VrParameter::BakeSource:
  case VrParameter::BakeDistances:
  case VrParameter::BakeQuality:
  case VrParameter::BakeProjection:
  case VrParameter::BakeColors:
    break; // Staged operation settings do not mutate the scene or history.
  case VrParameter::SkinSource:
  case VrParameter::SkinMode:
  case VrParameter::SkinDistances:
  case VrParameter::SkinFalloff:
  case VrParameter::SkinInfluences:
  case VrParameter::SkinPrune:
    break; // Staged operation configuration never changes scene/history.
  case VrParameter::WeightStrength:
    state_.weights.strength = value;
    break;
  case VrParameter::WeightValue:
    state_.weights.value = value;
    break;
  case VrParameter::RigRotation:
    control_changed_ = c.value[0] != 0 || c.value[1] != 0 || c.value[2] != 0;
    break;
  case VrParameter::MorphWeight:
    control_changed_ = c.value[0] != (before.deformation->morph_weights.empty() ? 0 : before.deformation->morph_weights.at(control_rig_index_));
    break;
  case VrParameter::TriangleEdge:
    break; // Staged configuration; only explicit Confirm queues the worker.
  case VrParameter::VoxelSize:
    state_.voxel_size_mm = value;
    break;
  case VrParameter::SculptOpacity: {
    auto &v = *o.volume;
    auto &ls = v.layers();
    auto l = *std::find_if(ls.begin(), ls.end(),
                           [&](auto &l) { return l.id == v.active_layer(); });
    v.layer_properties(l.id, l.name, l.visible, l.locked, value);
    control_changed_ =
        value != std::find_if(before.volume->layers().begin(),
                              before.volume->layers().end(),
                              [&](auto &l) {
                                return l.id == before.volume->active_layer();
                              })
                     ->opacity;
    scene_changed = true;
    break;
  }
  case VrParameter::BrushRadius:
    state_.radius = value;
    break;
  case VrParameter::Flow:
    state_.paint.flow = value;
    break;
  case VrParameter::InkColor:
    state_.paint.color[event.component] = value;
    break;
  case VrParameter::InkEmissionUnits: {
    state_.paint.emission_units=value>=.5f?PaintEmissionUnits::Physical:PaintEmissionUnits::MaterialRelative;
    if(state_.paint.emission_units==PaintEmissionUnits::MaterialRelative){const auto peak=*std::max_element(state_.paint.emission.begin(),state_.paint.emission.end());if(peak>1)for(auto &v:state_.paint.emission)v/=peak;}
    break;
  }
  case VrParameter::MaterialEmission: {
    if(o.material_bindings&&o.material_bindings->physical_emission){auto binding=std::make_shared<SourceMaterialBindings>(*o.material_bindings);binding->physical_emission=std::array<float,3>{c.value[0],c.value[1],c.value[2]};binding->validate();o.material_bindings=std::move(binding);control_changed_=o.material_bindings->physical_emission!=before.material_bindings->physical_emission;}
    else{o.material.emissive[event.component]=value;control_changed_=o.material.emissive!=before.material.emissive;}
    scene_changed=true;break;
  }
  case VrParameter::InkEmission:
    state_.paint.emission[event.component] = value;
    break;
  case VrParameter::InkMetallic:
    state_.paint.metallic = value;
    break;
  case VrParameter::InkRoughness:
    state_.paint.roughness = value;
    break;
  case VrParameter::Mask:
    state_.paint.mask = value;
    break;
  case VrParameter::BaseColor:
    o.material.color[event.component] = value;
    control_changed_ = o.material.color != before.material.color;
    scene_changed = true;
    break;
  case VrParameter::Metallic:
    o.material.metallic = value;
    control_changed_ = value != before.material.metallic;
    scene_changed = true;
    break;
  case VrParameter::Roughness:
    o.material.roughness = value;
    control_changed_ = value != before.material.roughness;
    scene_changed = true;
    break;
  case VrParameter::Opacity:
    o.material.color[3] = value;
    control_changed_ = value != before.material.color[3];
    scene_changed = true;
    break;
  case VrParameter::LayerOpacity: {
    auto &layers = o.painted->layers();
    auto it = std::find_if(layers.begin(), layers.end(), [&](auto &l) {
      return l.id == o.painted->active_layer();
    });
    auto &old = before.painted->layers();
    auto original = std::find_if(old.begin(), old.end(),
                                 [&](auto &l) { return l.id == it->id; });
    o.painted->layer_properties(it->name, it->visible, value);
    control_changed_ = value != original->opacity;
    scene_changed = true;
    break;
  }
  case VrParameter::LayerOrder: {
    auto &layers = o.painted->layers();
    auto it = std::find_if(layers.begin(), layers.end(), [&](auto &l) {
      return l.id == o.painted->active_layer();
    });
    int index = int(it - layers.begin()), target = int(std::lround(value));
    while (index != target) {
      int direction = target > index ? 1 : -1;
      o.painted->move_layer(direction);
      index += direction;
    }
    auto &old = before.painted->layers();
    control_changed_ = false;
    for (size_t i = 0; i < old.size(); ++i)
      control_changed_ |= old[i].id != o.painted->layers()[i].id;
    scene_changed = true;
    break;
  }
  default:
    break;
  }
  if (scene_changed)
    publish_locked(true);
}

bool Document::command_enabled_locked(SpatialCommand command) const {
  if(creator_command(command)||state_.creator)return creator_command_enabled_locked(command);
  if(command==SpatialCommand::BlurColorLayer){
    const auto&o=scene_.active();const auto field=o.painted?active_texture_set(o):TextureSetView{};
    return !state_.asset_busy&&!state_.recovery_busy&&!control_before_&&!action_active_locked()&&!state_.polygon&&!state_.cut&&!state_.retopology&&!state_.expressions&&!state_.object_grabbing&&!uv_&&object_editable_locked(o.id)&&o.mesh_active&&field.painted&&field.painted->gpu_color_blur_eligible();
  }
  if(texture_set_command(command))return texture_set_command_enabled_locked(command);
  if(expression_command(command))return expression_command_enabled_locked(command);
  if(state_.expressions&&!preview_command(command)&&command!=SpatialCommand::CancelWork&&command!=SpatialCommand::Center)return false;
  if(editable_avatar_export_command(command))return
      detail::editable_avatar_source(scene_.active())&&command_enabled_locked(SpatialCommand::ExportAvatar);
  if(command>=SpatialCommand::EmissionRelative&&command<=SpatialCommand::EmissionBlack)return !control_before_&&!action_active_locked()&&!state_.asset_busy&&!state_.recovery_busy&&object_editable_locked(scene_.active().id);
  if(editable_export_command(command))return command_enabled_locked(SpatialCommand::Export);
  if(rig_fit_command(command))return rig_fit_command_enabled_locked(command);
  if(projection_command(command))return projection_command_enabled_locked(command);
  if(preview_command(command))return !action_active_locked()&&!state_.object_grabbing&&!navigation_.grabbing()&&!control_before_&&(!state_.projection||!state_.projection->placing)&&(!state_.rig_fit||!state_.rig_fit->placing);
  if(command==SpatialCommand::Save&&state_.asset_busy)return state_.can_save_after_asset;
  if(command==SpatialCommand::CancelWork)
    return bool(state_.expressions) || (state_.asset_busy && asset_status().cancellable) ||
      (projection_load_&&!projection_load_->done.load()&&!projection_load_->cancelled.load()) ||
      std::any_of(exports_.begin(),exports_.end(),[](const auto &work){return work && work->cancellable();});
  if(command==SpatialCommand::SelectionMode||command==SpatialCommand::SelectionFocus)return selection_ready_locked();
  if(command==SpatialCommand::ObjectHierarchy)return true;
  if(shape_command(command))return shape_target_ready_locked()&&
    ((command==SpatialCommand::ShapeNew||command==SpatialCommand::ShapeCapture)||state_.can_select_shape);
  if(polygon_command(command))return polygon_command_enabled_locked(command);
  if(state_.polygon && command!=SpatialCommand::ObjectGrabMode&&command!=SpatialCommand::HoldObject&&command!=SpatialCommand::ReleaseObject&&command!=SpatialCommand::GhostOthers&&command!=SpatialCommand::CancelObjectGrab&&command!=SpatialCommand::CancelWork)return polygon_command_enabled_locked(command);
  if(import_command(command)) {
    if(command==SpatialCommand::ImportApply && (state_.object_grabbing || (state_.isolate_held && state_.held_object)))return false;
    return import_command_enabled_locked(command);
  }
  if(command==SpatialCommand::ObjectGrabMode||command==SpatialCommand::GhostOthers)return true;
  if(command==SpatialCommand::HoldObject)return scene_.active().visible&&!scene_.active().locked;
  if(command==SpatialCommand::ReleaseObject)return state_.held_object!=0;
  if(command==SpatialCommand::CancelObjectGrab)return state_.object_grabbing;
  if(state_.isolate_held && state_.held_object){
    if(command==SpatialCommand::NewSphere||command==SpatialCommand::NewEmpty||command==SpatialCommand::Duplicate||command==SpatialCommand::CreateFemale||command==SpatialCommand::CreateMale||command==SpatialCommand::DeleteGroup||command==SpatialCommand::Ungroup||command==SpatialCommand::RetopoBegin)return false;
    if(!object_editable_locked(scene_.active().id))switch(command){
      case SpatialCommand::Next:case SpatialCommand::Previous:case SpatialCommand::Visibility:
      case SpatialCommand::Undo:case SpatialCommand::Redo:case SpatialCommand::Save:case SpatialCommand::Export:
      case SpatialCommand::ExportAvatar:case SpatialCommand::CancelWork:case SpatialCommand::Center:break;
      default:return false;
    }
  }
  if(command==SpatialCommand::ProceduralApply || command==SpatialCommand::ProceduralNextSeed)return resolution_target_ready_locked();
  if(command==SpatialCommand::CutBegin)return state_.can_cut;
  if(command>=SpatialCommand::CutHand&&command<=SpatialCommand::CutCancel){
    if(!state_.cut||control_before_)return false;
    auto &v=*state_.cut;
    if(command==SpatialCommand::CutCancel)return !v.committing||(state_.asset_busy&&asset_status().cancellable);
    if(v.committing||state_.asset_busy)return false;
    if(!cut_bake_source_)return false;
    if(command==SpatialCommand::CutApply)return !v.busy&&v.preview&&v.preview_request==v.request&&v.preview->changed;
    return true;
  }
  if(state_.cut){
    if(state_.cut->committing)return false;
    if(command==SpatialCommand::Undo)return !cut_undo_.empty()||bool(control_before_);
    if(command==SpatialCommand::Redo)return !cut_redo_.empty()&&!control_before_;
    return false;
  }
  if (sculpt_mask_command(command)) return sculpt_target_ready_locked();
  if (command == SpatialCommand::RetopoBegin)
    return state_.retopology ? state_.retopology->source && !retopo_accepting_ && !state_.asset_busy && !control_before_
                             : state_.can_retopologize;
  if (command >= SpatialCommand::RetopoMode && command <= SpatialCommand::RetopoCancel) {
    if (!state_.retopology || control_before_) return false;
    if (command == SpatialCommand::RetopoCancel)
      return !state_.asset_busy || asset_status().cancellable;
    if (retopo_accepting_ || state_.asset_busy) return false;
    auto &v = *state_.retopology;
    if (!v.source || !v.topology) return false;
    if (command == SpatialCommand::RetopoFace) return v.selected.size() >= 3;
    if (command == SpatialCommand::RetopoWire) return v.selected.size() == 2 || v.selected.size() == 4;
    if (command == SpatialCommand::RetopoSeam) return v.selected.size() == 2;
    if (command == SpatialCommand::RetopoDelete || command == SpatialCommand::RetopoPin) return !v.selected.empty();
    if (command == SpatialCommand::RetopoApply) return !v.topology->faces().empty() && v.changed;
    return true;
  }
  if (state_.retopology) {
    if (retopo_accepting_ || !state_.retopology->source) return false;
    if (command == SpatialCommand::Undo) return retopo_stroking_ || state_.retopology->can_undo;
    if (command == SpatialCommand::Redo) return !retopo_stroking_ && state_.retopology->can_redo;
    return false;
  }
  if(command==SpatialCommand::BakeSurface)return !control_before_ && bake_source_eligible_locked(state_.bake_source) && state_.bake_settings.cage_object!=unavailable_bake_object && bake_target_ready_locked();
  if(command==SpatialCommand::ClearBake)return !control_before_ && bake_target_ready_locked() && bool(scene_.active().painted->baked());
  if(command==SpatialCommand::BindSkin) return !control_before_ && skin_target_ready_locked() &&
    !skin_sources_locked(state_.skin_options.mode).empty() &&
    !(state_.skin_options.mode==SkinAuthoringMode::SurfaceHeat&&state_.selected_objects.size()>1&&!selected_skin_ready_locked(SkinAuthoringMode::SurfaceHeat));
  if(command==SpatialCommand::SkinUseLocks) return !control_before_ && skin_target_ready_locked() && state_.can_paint_weights;
  if (uv_solving_ && (command == SpatialCommand::Undo || command == SpatialCommand::Redo)) return false;
  if (command >= SpatialCommand::WeightToggle && command <= SpatialCommand::WeightLinked)
    return !state_.asset_busy && !state_.recovery_busy && !control_before_ && !action_active_locked() &&
           state_.can_paint_weights && (command != SpatialCommand::WeightSymmetry || bool(scene_.active().deformation->humanoid));
  if (command == SpatialCommand::ExportAvatar)
    return !state_.asset_busy && !state_.recovery_busy && !control_before_ && state_.can_export_avatar;
  if (command >= SpatialCommand::RigNextJoint && command <= SpatialCommand::RigResetPose) {
    auto parameter = command == SpatialCommand::RigNextMorph || command == SpatialCommand::RigPreviousMorph
        ? VrParameter::MorphWeight : VrParameter::RigRotation;
    return !control_before_ && !action_active_locked() && parameter_enabled_locked(parameter);
  }
  if(command==SpatialCommand::CreateMakeHuman)return false;
  if (command >= SpatialCommand::CreateFemale && command <= SpatialCommand::Ungroup) {
    if (state_.asset_busy || state_.recovery_busy || control_before_ || action_active_locked()) return false;
    if (command == SpatialCommand::CreateFemale || command == SpatialCommand::CreateMale) return scene_.objects().size() <= 237 && scene_.groups().size() < 128;
    auto group = scene_.active().group;
    if (!group) return false;
    for (auto &o : scene_.objects())
      for (auto &g : scene_.group_path(o.group)) if (g.id == group && o.locked) return false;
    return true;
  }
  if (command >= SpatialCommand::RecoveryRefresh && command <= SpatialCommand::RecoveryRestore) {
    if (!recovery_ || state_.recovery_busy) return false;
    if (command == SpatialCommand::RecoveryRefresh) return true;
    if (command == SpatialCommand::RecoveryRestore)
      return !state_.dirty && !state_.asset_busy && !recovery_catalog_.empty();
    return recovery_catalog_.size() > 1;
  }
  auto &o = scene_.active();
  if (command >= SpatialCommand::SculptAdd &&
      command <= SpatialCommand::SculptOpacity) {
    if (state_.asset_busy || o.mesh_active || !o.visible || o.locked)
      return false;
    auto n = volume().layers().size();
    return command == SpatialCommand::SculptAdd ? n < 16
           : command == SpatialCommand::SculptDelete ||
                   command == SpatialCommand::SculptNext ||
                   command == SpatialCommand::SculptPrevious
               ? n > 1
               : true;
  }
  if (state_.asset_busy) {
    switch (command) {
    case SpatialCommand::Undo:
    case SpatialCommand::Redo:
    case SpatialCommand::Save:
    case SpatialCommand::Export:
    case SpatialCommand::MakeMesh:
    case SpatialCommand::EditSource:
    case SpatialCommand::PaintColor:
    case SpatialCommand::PaintMetal:
    case SpatialCommand::PaintRough:
    case SpatialCommand::PaintGlow:
    case SpatialCommand::PaintMask:
    case SpatialCommand::AddLayer:
    case SpatialCommand::DeleteLayer:
    case SpatialCommand::NextLayer:
    case SpatialCommand::LayerVisible:
    case SpatialCommand::LayerOpacity:
      return false;
    default:
      break;
    }
  }
  switch (command) {
  case SpatialCommand::Undo:
    return (transaction_?transaction_->history_size(false):undo_.size()) || pending_locked() || control_changed_;
  case SpatialCommand::Redo:
    return (transaction_?transaction_->history_size(true):redo_.size()) && !pending_locked() && !control_changed_;
  case SpatialCommand::Delete:
    return scene_.objects().size() > 1;
  case SpatialCommand::Next:
  case SpatialCommand::Previous:
    return scene_.objects().size() > 1;
  case SpatialCommand::NewSphere:
  case SpatialCommand::NewEmpty:
  case SpatialCommand::Duplicate:
    return scene_.objects().size() < 256;
  case SpatialCommand::MakeMesh:
    return !o.texture_sets&&o.visible && !o.locked && !o.deformation;
  case SpatialCommand::EditSource:
    return !o.texture_sets&&o.visible && !o.locked && (o.mesh_active || volume().sculpt_settings().mask_edit);
  case SpatialCommand::PaintColor:
  case SpatialCommand::PaintMetal:
  case SpatialCommand::PaintRough:
  case SpatialCommand::PaintGlow:
  case SpatialCommand::PaintMask:
    return o.visible && !o.locked;
  case SpatialCommand::AddLayer:
    return o.mesh_active && o.painted && active_texture_set(o).painted->layers().size() < 16;
  case SpatialCommand::DeleteLayer:
  case SpatialCommand::NextLayer:
    return o.mesh_active && o.painted && active_texture_set(o).painted->layers().size() > 1;
  case SpatialCommand::LayerVisible:
  case SpatialCommand::LayerOpacity:
    return o.mesh_active && bool(o.painted);
  case SpatialCommand::Larger:
    return state_.radius < 2;
  case SpatialCommand::Smaller:
    return state_.radius > .005f;
  default:
    return true;
  }
}
void Document::sculpt_layer_properties(uint64_t object, uint64_t id,
                                       std::string name, bool visible,
                                       bool locked, float opacity) {
  std::lock_guard lock(model_mutex_);
  finish_locked();
  auto &o = scene_.object(object);
  if (state_.asset_busy || o.mesh_active || !object_editable_locked(o.id))
    throw std::logic_error("Sculpt layer properties unavailable");
  auto next = std::make_shared<Volume>(o.volume->geometry_snapshot());
  next->layer_properties(id, std::move(name), visible, locked, opacity);
  Scene before = scene_;
  o.volume = std::move(next);
  scene_changed_locked(std::move(before));
}
void Document::sculpt_command(SpatialCommand command) {
  std::lock_guard lock(model_mutex_);
  finish_locked();
  if ((!sculpt_mask_command(command) && (command < SpatialCommand::SculptAdd ||
      command > SpatialCommand::SculptOpacity)) ||
      !command_enabled_locked(command))
    throw std::logic_error("Sculpt layer command unavailable");
  auto publication=published_.load();
  command_locked(command);
  if(published_.load()==publication)publish_locked();
}
void Document::command_locked(SpatialCommand command) {
  if(creator_command(command)||(state_.creator&&(command==SpatialCommand::Undo||command==SpatialCommand::Redo||command==SpatialCommand::CancelWork))){creator_command_locked(command);return;}
  if(state_.creator&&command!=SpatialCommand::Center)return;
  if(command==SpatialCommand::BlurColorLayer){if(command_enabled_locked(command)){PaintBlurOptions options;options.strength=state_.paint.flow;queue_blur_color_locked(options);}return;}
  if(texture_set_command(command)){texture_set_command_locked(command);return;}
  if(expression_command(command)){expression_command_locked(command);return;}
  if(state_.expressions&&command==SpatialCommand::CancelWork){end_expression_preview_locked(false);return;}
  if(state_.expressions&&!preview_command(command)&&command!=SpatialCommand::Center)return;
  if(editable_avatar_export_command(command)){
    if(!command_enabled_locked(command))return;
    file_locked(true,command==SpatialCommand::ExportEditableAvatar256?AssetExportFormat::EditableAvatar256:
        command==SpatialCommand::ExportEditableAvatar512?AssetExportFormat::EditableAvatar512:AssetExportFormat::EditableAvatar1024);
    return;
  }
  if(command>=SpatialCommand::EmissionRelative&&command<=SpatialCommand::EmissionBlack){
    if(!command_enabled_locked(command))return;
    if(command==SpatialCommand::EmissionBlack)state_.paint.emission={};
    else if(command==SpatialCommand::EmissionPhysical)state_.paint.emission_units=PaintEmissionUnits::Physical;
    else{const auto peak=*std::max_element(state_.paint.emission.begin(),state_.paint.emission.end());if(peak>1)for(auto &v:state_.paint.emission)v/=peak;state_.paint.emission_units=PaintEmissionUnits::MaterialRelative;}
    return;
  }
  if(editable_export_command(command)){
    if(!command_enabled_locked(command))return;
    file_locked(true,command==SpatialCommand::ExportEditable256?AssetExportFormat::EditableGlb256:
        command==SpatialCommand::ExportEditable512?AssetExportFormat::EditableGlb512:AssetExportFormat::EditableGlb1024);
    return;
  }
  if(rig_fit_command(command)){rig_fit_command_locked(command);return;}
  if(projection_command(command)){projection_command_locked(command);return;}
  if(preview_command(command)){shading_locked(command==SpatialCommand::PreviewPbr,command==SpatialCommand::PreviewToon);return;}
  if(command==SpatialCommand::SelectionMode){if(selection_ready_locked())configure_selection_locked(!state_.selection_mode);return;}
  if(command==SpatialCommand::ObjectHierarchy){state_.hierarchy_open=!state_.hierarchy_open;state_.hierarchy_anchored=false;input_.cancel();publish_locked(false,false);return;}
  if(command==SpatialCommand::SelectionFocus){if(selection_ready_locked()){Transaction transaction(*this);invalidate_object_authority_locked();state_.selection_focus=!state_.selection_focus;publish_locked(false,false);transaction.commit(false);}return;}
  if(shape_command(command)){
    if(!command_enabled_locked(command))return;
    if(command==SpatialCommand::ShapeSculpt){configure_shape_sculpt_locked(!state_.shape_sculpt);return;}
    ShapeKeyEdit edit;edit.target=state_.morph_target;
    edit.action=command==SpatialCommand::ShapeNew?ShapeKeyAction::Create:command==SpatialCommand::ShapeCapture?ShapeKeyAction::CaptureMix:command==SpatialCommand::ShapeDuplicate?ShapeKeyAction::Duplicate:ShapeKeyAction::Mirror;
    if(edit.action==ShapeKeyAction::Mirror)edit.mirror_frames=ShapeKeyMirrorFrames::VertexPositions;
    queue_shape_locked(std::move(edit));return;
  }

  if(polygon_command(command)||(state_.polygon&&(command==SpatialCommand::Undo||command==SpatialCommand::Redo))){polygon_command_locked(command);return;}
  if(import_command(command)){if(command_enabled_locked(command))import_command_locked(command);return;}
  if(command>=SpatialCommand::ObjectGrabMode&&command<=SpatialCommand::CancelObjectGrab){
    if(!command_enabled_locked(command))return;
    if(command==SpatialCommand::ObjectGrabMode||command==SpatialCommand::GhostOthers){configure_object_grab_locked(command==SpatialCommand::ObjectGrabMode?!state_.object_grab_mode:state_.object_grab_mode,command==SpatialCommand::GhostOthers?!state_.isolate_held:state_.isolate_held);return;}
    if(command==SpatialCommand::HoldObject&&state_.held_object==scene_.active().id)return;
    AuthorityTransition authority(*this);
    if((command==SpatialCommand::ReleaseObject||command==SpatialCommand::CancelObjectGrab)&&state_.object_grabbing){finish_object_grab_locked(command==SpatialCommand::ReleaseObject,true);authority.commit();return;}
    const bool changed=invalidate_object_authority_locked();
    if(command==SpatialCommand::ObjectGrabMode){state_.object_grab_mode=!state_.object_grab_mode;if(!state_.object_grab_mode)state_.held_object=0;}
    else if(command==SpatialCommand::GhostOthers)state_.isolate_held=!state_.isolate_held;
    else if(command==SpatialCommand::HoldObject)state_.held_object=scene_.active().id;
    else state_.held_object=0;
    publish_locked(changed||command==SpatialCommand::ObjectGrabMode,false);authority.commit();return;
  }
  if(state_.isolate_held&&state_.held_object&&!command_enabled_locked(command))return;
  if(command==SpatialCommand::ProceduralApply || command==SpatialCommand::ProceduralNextSeed) {
    if(!command_enabled_locked(command))return;
    if(command==SpatialCommand::ProceduralNextSeed)++state_.procedural_options.seed;
    else queue_procedural_locked(state_.procedural_options);
    return;
  }
  if(command==SpatialCommand::CutBegin){begin_cut_locked();return;}
  if(command>=SpatialCommand::CutHand&&command<=SpatialCommand::CutCancel){
    if(!command_enabled_locked(command))return;
    if(command==SpatialCommand::CutHand)cut_from_hand_locked();
    else if(command==SpatialCommand::CutApply||command==SpatialCommand::CutCancel)end_cut_locked(command==SpatialCommand::CutApply);
    else{auto settings=cut_settings_;if(command==SpatialCommand::CutFlip)settings.flipped=!settings.flipped;else settings.cap=!settings.cap;edit_cut_locked(settings);}
    return;
  }
  if(state_.cut&&(command==SpatialCommand::Undo||command==SpatialCommand::Redo)){cut_history_locked(command==SpatialCommand::Redo);return;}
  if (sculpt_mask_command(command)) {
    if (!command_enabled_locked(command)) return;
    if (command == SpatialCommand::SculptMaskFill || command == SpatialCommand::SculptMaskClear || command == SpatialCommand::SculptMaskInvert) {
      queue_sculpt_mask_locked(command == SpatialCommand::SculptMaskInvert ? std::optional<float>{} : command == SpatialCommand::SculptMaskFill ? 1.f : 0.f);
    } else {
      auto settings=volume().sculpt_settings();
      if(command==SpatialCommand::SculptMaskResume) settings.mask_edit=true;
      else if(command==SpatialCommand::SculptMaskToggle) settings.mask_edit=!settings.mask_edit;
      else if(command==SpatialCommand::SculptMaskVisible) settings.mask_visible=!settings.mask_visible;
      else settings.symmetry_axes ^= command==SpatialCommand::SculptMirrorX?1u:command==SpatialCommand::SculptMirrorY?2u:4u;
      sculpt_settings_locked(settings);
    }
    return;
  }
  if (command == SpatialCommand::RetopoBegin) {
    if (!command_enabled_locked(command)) return;
    if (!state_.retopology) begin_retopology_locked();
    return; // Existing workspaces resume through the input menu-close boundary.
  }
  if (command >= SpatialCommand::RetopoMode && command <= SpatialCommand::RetopoCancel) {
    if (!command_enabled_locked(command)) return;
    if (command == SpatialCommand::RetopoApply || command == SpatialCommand::RetopoCancel)
      end_retopology_locked(command == SpatialCommand::RetopoApply);
    else {
      auto action = command == SpatialCommand::RetopoMode ? RetopoAction::Mode
          : command == SpatialCommand::RetopoFace ? RetopoAction::Face
          : command == SpatialCommand::RetopoWire ? (state_.retopology->selected.size() == 4 ? RetopoAction::BridgeEdges : RetopoAction::Wire)
          : command == SpatialCommand::RetopoDelete ? RetopoAction::Delete
          : command == SpatialCommand::RetopoRelax ? RetopoAction::Relax
          : command == SpatialCommand::RetopoPin ? RetopoAction::Pin : RetopoAction::Seam;
      queue_retopology_locked(action);
    }
    return;
  }
  if (state_.retopology && (command == SpatialCommand::Undo || command == SpatialCommand::Redo)) {
    if (command_enabled_locked(command)) queue_retopology_locked(command == SpatialCommand::Undo ? RetopoAction::Undo : RetopoAction::Redo);
    return;
  }
  if(command==SpatialCommand::CancelWork){cancel_background_work_locked();return;}
  if(command==SpatialCommand::BakeSurface){if(command_enabled_locked(command))queue_bake_locked(state_.bake_source,state_.bake_settings);return;}
  if(command==SpatialCommand::ClearBake){if(command_enabled_locked(command))queue_clear_bake_locked();return;}
  if(command==SpatialCommand::BindSkin) {
    if(command_enabled_locked(command)) {
      auto options=state_.skin_options;
      if(state_.skin_use_locks && state_.can_paint_weights) options.locks=state_.weights.locks;
      else options.locks.clear();
      const bool selected=options.mode==SkinAuthoringMode::SurfaceHeat&&state_.selected_objects.size()>1;
      queue_bind_skin_locked(std::move(options),{},selected,selected?state_.selected_objects:std::vector<uint64_t>{});
    }
    return;
  }
  if(command==SpatialCommand::SkinUseLocks) {
    if(command_enabled_locked(command)) state_.skin_use_locks=!state_.skin_use_locks;
    return;
  }
  if (command >= SpatialCommand::WeightToggle && command <= SpatialCommand::WeightLinked) {
    if (!command_enabled_locked(command)) return;
    auto &settings = state_.weights;
    if (command == SpatialCommand::WeightToggle) settings.enabled = !settings.enabled;
    if (command == SpatialCommand::WeightLinked) settings.linked = !settings.linked;
    if (command == SpatialCommand::WeightSymmetry) settings.symmetry = !settings.symmetry;
    if (command == SpatialCommand::WeightMode) settings.mode = WeightBrushMode((int(settings.mode) + 1) % 4);
    if (command == SpatialCommand::WeightLock) {
      settings.locks.resize(scene_.active().deformation->skeleton->bones.size());
      settings.locks.at(state_.rig_joint) = !settings.locks.at(state_.rig_joint);
    }
    publish_locked(command == SpatialCommand::WeightToggle || command == SpatialCommand::WeightLinked);
    return;
  }
  if (command == SpatialCommand::ExportAvatar) {
    if (command_enabled_locked(command)) file_locked(true, AssetExportFormat::Avatar);
    return;
  }
  if (command >= SpatialCommand::RigNextJoint && command <= SpatialCommand::RigResetPose) {
    if (!command_enabled_locked(command)) return;
    const auto &d = *scene_.active().deformation;
    if (command == SpatialCommand::RigResetPose) {
      auto object = scene_.active().id;
      queue_scene_operation_locked("Reset grouped rig pose", [object](Scene &scene, const auto &cancelled) {
        RigEdit edit; edit.reset_pose = true; edit_rig(scene, object, edit, cancelled);
      }, {}, {});
    } else {
      bool morph = command == SpatialCommand::RigNextMorph || command == SpatialCommand::RigPreviousMorph;
      auto &index = morph ? state_.morph_target : state_.rig_joint;
      auto count = morph ? d.morphs->targets.size() : d.skeleton->bones.size();
      bool next = command == SpatialCommand::RigNextJoint || command == SpatialCommand::RigNextMorph;
      index = (index + count + (next ? 1 : count - 1)) % count;
      if ((state_.weights.enabled && !morph)||(state_.shape_sculpt&&morph)) publish_locked(true,false);
    }
    return;
  }
  if (command >= SpatialCommand::CreateFemale && command <= SpatialCommand::Ungroup) {
    if (!command_enabled_locked(command)) return;
    if (command == SpatialCommand::CreateFemale || command == SpatialCommand::CreateMale) {
      std::string baseline = command == SpatialCommand::CreateFemale ? "vroid-beta-female" : "vroid-beta-male";
      create_humanoid_avatar_locked(humanoid_baseline_defaults(baseline),"Humanoid",{},true);
    } else {
      auto group = scene_.active().group;
      bool erase = command == SpatialCommand::DeleteGroup;
      queue_scene_operation_locked(erase ? "Delete avatar group" : "Ungroup avatar",
        [group, erase](Scene &scene, const auto &) { scene.erase_group(group, erase); }, {}, {});
    }
    return;
  }
  if (command >= SpatialCommand::RecoveryRefresh && command <= SpatialCommand::RecoveryRestore) {
    if (!command_enabled_locked(command)) return;
    if (command == SpatialCommand::RecoveryRefresh) refresh_recovery_locked();
    else if (command == SpatialCommand::RecoveryRestore)
      restore_recovery_locked(state_.recovery_selected);
    else {
      auto n = recovery_catalog_.size();
      state_.recovery_selected = (state_.recovery_selected + n +
          (command == SpatialCommand::RecoveryNext ? 1 : -1)) % n;
    }
    return;
  }
  if (command >= SpatialCommand::SculptAdd &&
      command <= SpatialCommand::SculptOpacity) {
    if (!command_enabled_locked(command))
      return;
    Scene before = scene_;
    auto next = std::make_shared<Volume>(volume().geometry_snapshot());
    auto ls = next->layers();
    auto i = std::find_if(ls.begin(), ls.end(), [&](auto &l) {
      return l.id == next->active_layer();
    });
    auto l = *i;
    switch (command) {
    case SpatialCommand::SculptAdd:
      next->add_layer("Sculpt " + std::to_string(ls.size() + 1));
      break;
    case SpatialCommand::SculptNext:
    case SpatialCommand::SculptPrevious:
      next->select_layer(ls[(size_t(i - ls.begin()) + ls.size() +
                             (command == SpatialCommand::SculptNext ? 1 : -1)) %
                            ls.size()]
                             .id);
      break;
    case SpatialCommand::SculptDelete:
      next->erase_layer(l.id);
      break;
    default:
      next->layer_properties(
          l.id, l.name,
          command == SpatialCommand::SculptVisible ? !l.visible : l.visible,
          command == SpatialCommand::SculptLock ? !l.locked : l.locked,
          command == SpatialCommand::SculptOpacity
              ? (l.opacity >= 1 ? .25f : std::min(1.f, l.opacity + .25f))
              : l.opacity);
      break;
    }
    scene_.active().volume = std::move(next);
    scene_changed_locked(std::move(before));
    return;
  }

  if (command == SpatialCommand::MakeMesh) {
    prepare_locked(512);
    return;
  }
  if (command == SpatialCommand::EditSource) {
    if (scene_.active().mesh_active) {
      Scene before = scene_;
      scene_.active().mesh_active = false;
      scene_changed_locked(std::move(before));
    }
    if (volume().sculpt_settings().mask_edit && sculpt_target_ready_locked()) {
      auto settings=volume().sculpt_settings(); settings.mask_edit=false; sculpt_settings_locked(settings);
    }
    const auto &source=scene_.active();
    state_.message=source_is_dormant(source)
        ? "Volume preview; prepared mesh data is retained. Return to mesh mode to view it."
        : "Sculpt volume selected";
    return;
  }
  if (command >= SpatialCommand::PaintColor &&
      command <= SpatialCommand::PaintMask) {
    state_.message.clear();
    state_.paint.channel =
        PaintChannel(int(command) - int(SpatialCommand::PaintColor));
    auto &o = scene_.active();
    if (!o.painted)
      prepare_locked(512);
    else if (!o.mesh_active) {
      Scene before = scene_;
      o.mesh_active = true;
      scene_changed_locked(std::move(before));
    }
    return;
  }
  switch (command) {
  case SpatialCommand::PaintRed:
    state_.paint.color = {.9f, .02f, .01f, 1};
    return;
  case SpatialCommand::PaintGreen:
    state_.paint.color = {.02f, .8f, .03f, 1};
    return;
  case SpatialCommand::PaintBlue:
    state_.paint.color = {.02f, .04f, .9f, 1};
    return;
  case SpatialCommand::PaintWhite:
    state_.paint.mask = 1;
    state_.paint.color = {1, 1, 1, 1};
    return;
  case SpatialCommand::PaintBlack:
    state_.paint.mask = 0;
    state_.paint.color = {0, 0, 0, 1};
    return;
  case SpatialCommand::PaintWarm:
    state_.paint.color = {.8f, .25f, .05f, 1};
    return;
  case SpatialCommand::FlowUp:
    state_.paint.flow = std::min(1.f, state_.paint.flow + .1f);
    return;
  case SpatialCommand::FlowDown:
    state_.paint.flow = std::max(.05f, state_.paint.flow - .1f);
    return;
  case SpatialCommand::ErasePaint:
    state_.paint.erase = !state_.paint.erase;
    return;
  default:
    break;
  }
  if (command == SpatialCommand::NextLayer ||
      command == SpatialCommand::AddLayer ||
      command == SpatialCommand::DeleteLayer ||
      command == SpatialCommand::LayerVisible ||
      command == SpatialCommand::LayerOpacity) {
    auto &o = scene_.active();
    if (!o.painted || !o.mesh_active)
      throw std::logic_error("Prepare or select a painting mesh first");
    if(o.texture_sets){
      const auto field=active_texture_set(o);TextureSetEdit edit;edit.set=field.id;edit.layer=field.painted->active_layer();
      if(command==SpatialCommand::AddLayer)edit.action=TextureSetAction::AddLayer;
      else if(command==SpatialCommand::DeleteLayer)edit.action=TextureSetAction::DeleteLayer;
      else if(command==SpatialCommand::NextLayer)edit.action=TextureSetAction::NextLayer;
      else if(command==SpatialCommand::LayerVisible)edit.action=TextureSetAction::ToggleLayer;
      else{edit.action=TextureSetAction::LayerOpacity;const auto&layers=field.painted->layers();const auto at=std::find_if(layers.begin(),layers.end(),[&](const auto&l){return l.id==edit.layer;});if(at==layers.end())throw std::logic_error("Texture-set layer is unavailable");edit.value=at->opacity>.26f?at->opacity-.25f:1.f;}
      queue_texture_set_locked(std::move(edit));return;
    }
    if (command == SpatialCommand::NextLayer) {
      auto &layers = o.painted->layers();
      auto i = std::find_if(layers.begin(), layers.end(), [&](auto &l) {
        return l.id == o.painted->active_layer();
      });
      o.painted->select_layer(
          layers[(size_t(i - layers.begin()) + 1) % layers.size()].id);
      return;
    }
    Scene before = scene_;
    auto next = o.painted->snapshot();
    if (command == SpatialCommand::AddLayer)
      next->add_layer("Paint " +
                      std::to_string(o.painted->layers().size() + 1));
    else if (command == SpatialCommand::DeleteLayer)
      next->delete_layer();
    else {
      auto &layers = next->layers();
      auto &l = *std::find_if(layers.begin(), layers.end(), [&](auto &v) {
        return v.id == next->active_layer();
      });
      next->layer_properties(
          l.name,
          command == SpatialCommand::LayerVisible ? !l.visible : l.visible,
          command == SpatialCommand::LayerOpacity
              ? (l.opacity > .26f ? l.opacity - .25f : 1.f)
              : l.opacity);
    }
    o.painted = std::move(next);
    scene_changed_locked(std::move(before));
    return;
  }
  switch (command) {
  case SpatialCommand::Undo:
    undo_locked(false);
    return;
  case SpatialCommand::Redo:
    undo_locked(true);
    return;
  case SpatialCommand::Save:
    file_locked(false);
    return;
  case SpatialCommand::Export:
    file_locked(true);
    return;
  case SpatialCommand::Larger:
    state_.radius = std::min(2.f, state_.radius * 1.25f);
    return;
  case SpatialCommand::Smaller:
    state_.radius = std::max(.005f, state_.radius * .8f);
    return;
  default:
    break;
  }
  if(scene_.active().texture_sets&&((command>=SpatialCommand::Warm&&command<=SpatialCommand::Opacity))){
    TextureSetEdit edit;edit.action=TextureSetAction::Material;const auto field=active_texture_set(scene_.active());edit.set=field.id;edit.material=field.material;auto&m=edit.material;
    switch(command){
    case SpatialCommand::Warm:m.color={.58f,.30f,.15f,1};break;case SpatialCommand::Blue:m.color={.04f,.12f,.8f,1};break;
    case SpatialCommand::White:m.color={.8f,.8f,.8f,1};break;case SpatialCommand::Dark:m.color={.04f,.04f,.04f,1};break;
    case SpatialCommand::MetalUp:m.metallic=std::min(1.f,m.metallic+.1f);break;case SpatialCommand::MetalDown:m.metallic=std::max(0.f,m.metallic-.1f);break;
    case SpatialCommand::RoughUp:m.roughness=std::min(1.f,m.roughness+.1f);break;case SpatialCommand::RoughDown:m.roughness=std::max(0.f,m.roughness-.1f);break;
    case SpatialCommand::Toon:m.toon=true;break;case SpatialCommand::Pbr:m.toon=false;break;case SpatialCommand::Opacity:m.color[3]=m.color[3]>.26f?m.color[3]-.25f:1.f;break;
    default:throw std::logic_error("Unknown material command");}
    queue_texture_set_locked(std::move(edit));return;
  }
  Scene before = scene_;
  auto &o = scene_.active();
  switch (command) {
  case SpatialCommand::NewSphere:
  case SpatialCommand::NewEmpty: {
    Volume next(volume().voxel_size());
    if (command == SpatialCommand::NewSphere) {
      next.begin_stroke();
      Brush b;
      b.radius = .25f;
      b.blend = 0;
      next.stamp(b);
      next.end_stroke();
    }
    auto transform = scene_.world_transform(o.id);
    transform.position.x = std::min(100.f, transform.position.x + .6f);
    scene_.add(command == SpatialCommand::NewSphere ? "Clay sphere"
                                                    : "Empty sculpt",
               std::move(next), transform);
    break;
  }
  case SpatialCommand::Duplicate: {
    auto id = scene_.duplicate(o.id);
    auto &copy = scene_.object(id);
    copy.transform.position.x =
        std::min(100.f, copy.transform.position.x + .6f);
    break;
  }
  case SpatialCommand::Delete:
    scene_.erase(o.id);
    break;
  case SpatialCommand::Next:
  case SpatialCommand::Previous: {
    auto &objects = scene_.objects();
    auto it = std::find_if(objects.begin(), objects.end(),
                           [&](auto &v) { return v.id == o.id; });
    int index = int(it - objects.begin()), count = int(objects.size());
    scene_.select(
        objects[(index + count + (command == SpatialCommand::Next ? 1 : -1)) %
                count]
            .id);
    bind_locked();
    publish_locked();
    return;
  }
  case SpatialCommand::Visibility:
    if(state_.held_object==o.id){invalidate_object_authority_locked();state_.held_object=0;}
    o.visible = !o.visible;
    break;
  case SpatialCommand::Lock:
    o.locked = !o.locked;
    break;
  case SpatialCommand::Left:
    o.transform.position.x = std::max(-100.f, o.transform.position.x - .1f);
    break;
  case SpatialCommand::Right:
    o.transform.position.x = std::min(100.f, o.transform.position.x + .1f);
    break;
  case SpatialCommand::Center:
    o.transform.position = {};
    break;
  case SpatialCommand::Warm:
    o.material.color = {.58f, .30f, .15f, 1};
    break;
  case SpatialCommand::Blue:
    o.material.color = {.04f, .12f, .8f, 1};
    break;
  case SpatialCommand::White:
    o.material.color = {.8f, .8f, .8f, 1};
    break;
  case SpatialCommand::Dark:
    o.material.color = {.04f, .04f, .04f, 1};
    break;
  case SpatialCommand::MetalUp:
    o.material.metallic = std::min(1.f, o.material.metallic + .1f);
    break;
  case SpatialCommand::MetalDown:
    o.material.metallic = std::max(0.f, o.material.metallic - .1f);
    break;
  case SpatialCommand::RoughUp:
    o.material.roughness = std::min(1.f, o.material.roughness + .1f);
    break;
  case SpatialCommand::RoughDown:
    o.material.roughness = std::max(0.f, o.material.roughness - .1f);
    break;
  case SpatialCommand::Toon:
    o.material.toon = true;
    break;
  case SpatialCommand::Pbr:
    o.material.toon = false;
    break;
  case SpatialCommand::Opacity:
    o.material.color[3] =
        o.material.color[3] > .26f ? o.material.color[3] - .25f : 1.f;
    break;
  default:
    return;
  }
  scene_changed_locked(std::move(before));
}
void Document::file_loop() {
  for (;;) {
    if(projection_notice_pending_.load()){
      std::lock_guard lock(model_mutex_);retry_projection_failure_locked();
    }
    if(worker_notices_pending_.load()) {
      std::lock_guard lock(model_mutex_);retry_worker_notices_locked();
    }
    std::optional<FileJob> job;
    {
      std::unique_lock lock(file_mutex_);
      file_changed_.wait(lock,[&]{return files_stopping_||!files_.empty()||worker_notices_pending_.load()||projection_notice_pending_.load();});
      // Exception delivery normally allocates nothing. If a library needs
      // memory, retain that one promise before accepting more file work.
      if(worker_completion_pending_.load()) {
        file_changed_.wait_for(lock,std::chrono::milliseconds(25));continue;
      }
      if(files_.empty()&&files_stopping_)return;
      if(files_.empty()) {
        file_changed_.wait_for(lock,std::chrono::milliseconds(25),[&]{return files_stopping_||!files_.empty();});
        if(files_.empty())continue;
      }
      job=std::move(files_.front());files_.pop_front();
    }
    struct ProjectionDone {
      std::shared_ptr<ProjectionLoad> task;
      std::mutex &mutex;std::condition_variable &changed;std::atomic_bool &notice;
      ~ProjectionDone(){if(task){{std::lock_guard lock(mutex);task->done.store(true);if(task->failure)notice=true;}changed.notify_all();}}
    } projection_done{job->projection_load,file_mutex_,file_changed_,projection_notice_pending_};
    try {
      if(job->export_work && job->export_work->cancelled())
        throw std::runtime_error("Export cancelled");
      if(job->projection_load){projection_file(*job);continue;}
      if(job->discover_import){discover_import_file(*job);continue;}
      if(job->asset_capture) {
        auto token=std::move(job->asset_capture);
        if(token->failure)std::rethrow_exception(token->failure);
        const auto result=token->completed;
        if(!result||!result->scene)
          throw std::runtime_error("Accepted authoring operation did not publish; dependent Save cancelled");
        job->generation=result->generation;job->revision=result->revision;
        job->content=result->content;job->object=result->object;
        job->recovery_source=result->recovery;job->capture_scene=result->scene;
      }
      if(job->native_capture)capture_native_file(*job);
      if(job->polygon_capture)capture_polygon_file(*job);
      if(job->capture_scene){job->scene=job->capture_scene->snapshot();job->scene.select(job->object);job->capture_scene.reset();}
      if (job->open_project) {
        auto cancelled = [&] {
          return stopping_.load() || job->work->cancelled.load() ||
                 published_.load()->generation != job->generation;
        };
        auto loaded = load_scene_file(job->path, cancelled);
        std::lock_guard lock(model_mutex_);
        if (cancelled() || content_ != job->content || action_active_locked() || control_before_)
          throw std::runtime_error("Project loading cancelled or document changed");
        const bool package = loaded.kind == SceneFileKind::AuthoringPackage;
        replace_locked(std::move(loaded.scene), !package,
                       package ? std::filesystem::path{} : job->path,
                       package ? "Restored editable package as an unsaved project; save to a new project path"
                               : "Opened " + job->path.string());
        job->completion->set_value();
        {
          std::lock_guard file_lock(file_mutex_);
          file_changed_.notify_all();
        }
        continue;
      }
      if (job->scene_operation) {
        auto isolated_before=job->isolation_target?std::optional<Scene>(job->scene.snapshot()):std::nullopt;
        auto cancelled = [&] {
          auto state = published_.load();
          return stopping_.load() || (job->work && job->work->cancelled.load()) || state->generation != job->generation ||
                 state->revision != job->revision || state->active_object != job->object || state->edit_authority!=job->edit_authority;
        };
        if(job->texture_set_source){job->texture_set_source->authenticate_owner(job->texture_set_source);job->texture_set_source->authenticate_scene(job->scene);}
        job->scene_operation(job->scene, cancelled);
        if (cancelled()) throw std::runtime_error("Scene changed during " + job->operation_label);
        if(job->cut_handoff){
          if(!job->cut_session)throw std::logic_error("Cut structural permit has no accepted session");
          // Source preparation/validation stays on the worker, outside the UI lock.
          // The existing job scene before mutation is retained only under isolation.
          if(isolated_before)validate_cut_handoff(*isolated_before,job->scene,*job->cut_handoff);
          else if(!job->cut_handoff->sealed)throw std::logic_error("Cut structural permit is unsealed");
        }else if(isolated_before)detail::require_isolated_scene(*isolated_before,job->scene,job->isolation_target);
        auto prepared = job->scene.snapshot();
        prepared.validate();
        std::shared_ptr<AssetAcceptedSnapshot> accepted_result;
        if(job->work&&job->work->accepted_scene) {
          accepted_result=std::make_shared<AssetAcceptedSnapshot>();
          accepted_result->scene=std::make_shared<const Scene>(prepared.snapshot());
          accepted_result->generation=job->generation;
          accepted_result->object=prepared.active().id;
        }
        std::lock_guard lock(model_mutex_);
        if (job->generation == state_.generation) {
          if(job->work && job->work->cancelled.load())throw std::runtime_error("Asset operation cancelled");
          if (job->content != content_ || job->revision != state_.revision ||
              job->object != scene_.active().id || state_.edit_authority!=job->edit_authority || action_active_locked() || control_before_)
            throw std::runtime_error("Scene changed during " + job->operation_label);
          if(job->texture_set_source)job->texture_set_source->authenticate_scene(scene_);
          if(accepted_result)accepted_result->recovery=recovery_source_;
          Transaction transaction(*this);
          state_.asset_busy=false;
          if(job->retopo_session&&job->retopo_session==retopo_session_.load())transaction.finish_retopo();
          if(job->cut_session&&job->cut_session==cut_session_.load())transaction.finish_cut();
          bool changed=!job->operation_changed||*job->operation_changed;
          // Preserve a still-open tools page and its observed button latches.
          // Clearing devices here would consume the next real selection as a
          // first sample. Closed/focus-lost menus retain ordinary cancellation.
          const bool keep_shapes=job->work&&job->work->morph_target.load()!=UINT32_MAX&&
            input_.menu_open()&&input_.menu_page()==24;
          if(changed){
            History history{{},transaction.before(),prepared};
            if(job->cut_handoff&&job->cut_handoff->held_source){
              const auto &permit=*job->cut_handoff;
              if(state_.held_object!=permit.held_source||state_.edit_authority==UINT64_MAX)
                throw std::logic_error("Held cut authority changed before publication");
              history.held_before=permit.held_source;history.held_after=permit.shell;
              state_.held_object=permit.shell;state_.selected_objects={permit.shell};++state_.edit_authority;
            }
            scene_=std::move(prepared);record_locked(std::move(history));bind_locked(keep_shapes);
          }
          if(job->work&&job->work->morph_target.load()!=UINT32_MAX)state_.morph_target=job->work->morph_target.load();
          state_.error.clear();state_.message=job->operation_label+" complete";
          if(job->operation_report&&!job->operation_report->empty())state_.message+=" | "+*job->operation_report;
          publish_locked(changed,false);transaction.commit();asset_work_.store({});
          // Presentation only: the ordered operation authenticates the accepted
          // new group. The input worker waits for this exact published mesh.
          if(initial_creator_.pending==job->work&&job->work){
            initial_creator_.pending.reset();
            if(!initial_creator_.navigated&&initial_creator_.generation==job->generation&&initial_creator_.content==job->content){
              initial_creator_.target_generation=state_.generation;initial_creator_.target_revision=state_.revision;
              initial_creator_.target_content=content_;initial_creator_.target_group=scene_.active().group;initial_creator_.target_input_epoch=state_.input_epoch;
            }
          }
          if(accepted_result) {
            accepted_result->revision=state_.revision;accepted_result->content=content_;
            job->work->completed=std::move(accepted_result);
            {std::lock_guard file_lock(file_mutex_);job->work->done.store(true);}
            file_changed_.notify_all();
          }
          if(!changed)restore_weight_view_locked(job->rollback_preview);
          if(job->work)job->work->progress.store(1);
          if(job->work&&job->work->held_weight&&state_.object_grabbing&&!desktop_&&!object_navigation_.grabbing())finish_object_grab_locked(true,true);
        } else throw std::runtime_error("Scene changed during " + job->operation_label);
        {
          std::lock_guard file_lock(file_mutex_);
          file_changed_.notify_all();
        }
        continue;
      }
      if (job->discover_recovery || job->restore_recovery) {
        if (job->discover_recovery) {
          auto found = RecoveryService::discover(job->path);
          std::lock_guard lock(model_mutex_);
          recovery_catalog_ = std::move(found.candidates);
          state_.recovery_candidates.clear();
          state_.recovery_selected = 0;
          for (auto &c : recovery_catalog_)
            state_.recovery_candidates.push_back(c.source.source_path.empty()
                ? "Untitled (" + c.source.id.substr(0, 8) + ")"
                : c.source.source_path.string());
          recovery_discovery_error_.clear();
          for (auto &error : found.errors) recovery_discovery_error_ += error + "\n";
          if (found.truncated) recovery_discovery_error_ += "Recovery scan limit reached";
          state_.recovery_busy = false;
          publish_locked();
        } else {
          auto recovered = RecoveryService::load(*job->restore_recovery);
          std::lock_guard lock(model_mutex_);
          if (job->generation != state_.generation || job->content != content_)
            throw std::runtime_error("Document changed while recovery was loading");
          replace_locked(std::move(recovered),false,{},"Recovered as an unsaved project; save to a new path");
        }
        {
          std::lock_guard file_lock(file_mutex_);
          file_changed_.notify_all();
        }
        continue;
      }
      if (job->uv_mesh) {
        process_uv_transfer(*job);
        continue;
      }
      if (job->prepare_mesh) {
        auto &source = job->scene.object(job->object);
        auto cancelled = [&] {
          auto state=published_.load();
          return stopping_.load() || (job->work && job->work->cancelled.load()) ||
                 state->generation!=job->generation || state->edit_authority!=job->edit_authority;
        };
        auto mesh = surface_mesh(*source.volume, cancelled);
        condition_sculpt_normals(mesh,cancelled);
        unwrap(mesh, job->resolution, 4, cancelled);
        if(cancelled())throw std::runtime_error("Painting mesh preparation cancelled");
        auto painted =
            std::make_shared<PaintedMesh>(std::move(mesh), job->resolution);
        std::lock_guard lock(model_mutex_);
        if (job->generation == state_.generation) {
          auto it =
              std::find_if(scene_.objects().begin(), scene_.objects().end(),
                           [&](auto &o) { return o.id == job->object; });
          if (cancelled() || it == scene_.objects().end() ||
              it->volume != job->source_identity ||
              it->volume->revision() != job->source_revision ||
              job->edit_authority!=state_.edit_authority || !object_editable_locked(job->object) ||
              action_active_locked())
            throw std::runtime_error(
                "The source changed while its painting mesh was being "
                "prepared; retry on the current object");
          Transaction transaction(*this);
          auto &o=scene_.object(job->object);o.painted=std::move(painted);o.mesh_active=true;
          state_.asset_busy=false;state_.message="Painting mesh ready";state_.error.clear();
          record_locked({{},transaction.before(),scene_});bind_locked();publish_locked(true,false);transaction.commit();
          asset_work_.store({});
          if(job->work)job->work->progress.store(1);

        }
        {
          std::lock_guard file_lock(file_mutex_);
          file_changed_.notify_all();
        }
        continue;
      }
      if (job->create_parent) {
        std::filesystem::create_directories(job->path.parent_path());
        std::filesystem::permissions(job->path.parent_path(), std::filesystem::perms::owner_all);
      }
      std::string export_diagnostics;
      if (job->export_mesh) {
        // Accepted snapshots drain on close and survive document replacement.
        // Only the explicit Cancel command changes this per-export token.
        auto work=job->export_work;
        auto cancelled=[work]{return work && work->cancelled();};
        auto before_commit=[work]{if(work)work->begin_commit();};
        if (job->export_format == AssetExportFormat::EditableAvatar256 ||
            job->export_format == AssetExportFormat::EditableAvatar512 ||
            job->export_format == AssetExportFormat::EditableAvatar1024) {
          auto group=avatar_group(job->scene,job->object);
          if(!group)throw std::runtime_error("Select a grouped avatar to export");
          NativeAuthoringExport owner;
          owner.scene=std::make_shared<const Scene>(job->scene.snapshot());
          owner.scope=NativeAuthoringExport::Scope::ExportedObjects;
          owner.allow_portable_fallback=true;
          for(const auto &object:job->scene.objects())
            if(object.visible&&in_group(job->scene,object,group))owner.objects.push_back(object.id);
          VrmExportOptions options;options.cancelled=cancelled;options.before_commit=before_commit;
          options.paint_resolution=job->export_format==AssetExportFormat::EditableAvatar256?256:
              job->export_format==AssetExportFormat::EditableAvatar512?512:1024;
          auto report=export_vrm_authoring(owner,job->path,options);
          for(size_t i=0;i<std::min<size_t>(8,report.diagnostics.size());++i)
            export_diagnostics+=" | "+report.diagnostics[i].substr(0,200);
        } else if (job->export_format == AssetExportFormat::Avatar) {
          auto group = avatar_group(job->scene, job->object);
          if (!group) throw std::runtime_error("Select a grouped avatar to export");
          for (const auto &object : job->scene.objects())
            if (!in_group(job->scene, object, group)) job->scene.object(object.id).visible = false;
          job->scene.require_exportable_sources();
          std::vector<uint64_t> subject_ids;for(const auto &object:job->scene.objects())if(object.visible)subject_ids.push_back(object.id);
          auto subject=detail::emission_export_subset(job->scene,subject_ids);
          const bool physical=detail::requires_native_emission_package(subject,cancelled);
          auto native_owner=physical?std::make_shared<const Scene>(std::move(subject)):nullptr;
          auto surfaces=physical?emission_export_surfaces(*native_owner,cancelled):job->scene.export_surfaces(cancelled);
          VrmExportOptions options;options.cancelled=cancelled;options.before_commit=before_commit;
          if(physical){auto emission=std::make_shared<NativeEmissionExport>();emission->scene=std::move(native_owner);emission->scope=NativeEmissionExport::Scope::ExportedObjects;emission->allow_measured_core_fallback=true;options.emission=std::move(emission);}
          auto report = export_vrm(surfaces, job->path,options);
          for (size_t i = 0; i < std::min<size_t>(8, report.diagnostics.size()); ++i)
            export_diagnostics += " | " + report.diagnostics[i].substr(0, 200);
        } else if (job->export_format == AssetExportFormat::EditableGlb256 ||
                   job->export_format == AssetExportFormat::EditableGlb512 ||
                   job->export_format == AssetExportFormat::EditableGlb1024) {
          NativeAuthoringExport owner;
          owner.scene = std::make_shared<const Scene>(job->scene.snapshot());
          owner.scope = NativeAuthoringExport::Scope::WholeScene;
          owner.allow_portable_fallback = true;
          SourceUvBakeOptions policy;
          policy.resolution = job->export_format == AssetExportFormat::EditableGlb256 ? 256 :
                              job->export_format == AssetExportFormat::EditableGlb512 ? 512 : 1024;
          GltfExportOptions options;
          options.recompute_changed_normals = true;
          options.cancelled = cancelled;
          options.before_commit = before_commit;
          auto report = export_glb_authoring(owner,job->path,options,policy);
          for (size_t i=0;i<std::min<size_t>(8,report.diagnostics.size());++i)
            export_diagnostics += " | " + report.diagnostics[i].substr(0,200);
        } else {
          job->scene.require_exportable_sources();
          const bool physical=detail::requires_native_emission_package(job->scene,cancelled);
          auto native_owner=physical?std::make_shared<const Scene>(job->scene.snapshot()):nullptr;
          auto surfaces = physical?emission_export_surfaces(*native_owner,cancelled):job->scene.export_surfaces(cancelled);
          for (auto &surface : surfaces)
            if (!surface.texture_set_surface && surface.mesh.uv.empty()) unwrap(surface.mesh,1024,4,cancelled);
          GltfExportOptions options; options.recompute_changed_normals = true;
          options.cancelled=cancelled;options.before_commit=before_commit;
          if(physical){auto emission=std::make_shared<NativeEmissionExport>();emission->scene=std::move(native_owner);emission->scope=NativeEmissionExport::Scope::WholeScene;emission->allow_measured_core_fallback=true;options.emission=std::move(emission);}
          auto report = export_glb(surfaces, job->path, options);
          for (size_t i = 0; i < std::min<size_t>(8, report.diagnostics.size()); ++i)
            export_diagnostics += " | " + report.diagnostics[i].substr(0, 200);
        }
      } else
        job->scene.save(job->path);
      std::lock_guard lock(model_mutex_);
      retire_export_locked(job->export_work);
      if(job->generation==state_.generation){
        Transaction transaction(*this);
        bool current_recovery=recovery_&&job->recovery_source.id==recovery_source_.id&&job->recovery_source.generation==recovery_source_.generation;
        bool source_changed=false;
        if(!job->export_mesh){
          saved_content_=job->content;
          if(job->adopt_path){
            path_=job->path;
            if(recovery_&&recovery_source_.source_path!=path_){recovery_source_.source_path=path_;recovery_content_=0;source_changed=true;}
          }
        }
        state_.error.clear();state_.message=std::string(job->export_mesh?"Exported ":"Saved ")+job->path.string()+export_diagnostics;
        publish_locked(false,false);transaction.commit(false);
        if(recovery_)try{
          if(source_changed)recovery_->set_source(recovery_source_);
          if(!job->export_mesh&&current_recovery)recovery_->discard(recovery_source_,job->revision);
          checkpoint_locked();
        }catch(...){}
      }else if(job->export_work)publish_locked(false,false);
      if (job->completion)
        job->completion->set_value();
    } catch (...) {
      const auto error=std::current_exception();
      std::lock_guard lock(model_mutex_);file_worker_error_locked(*job,error);
    }
  }
}
} // namespace dome
