import os
from pathlib import Path
import shlex
import subprocess

work=Path(__file__).resolve().parent
previous=work.parent/'retopology-mtoon-shared-shade-20261127/release'
commands=subprocess.check_output(['ninja','-C',previous,'-t','commands','dome-sculpt-texture-set-source-export-test'],text=True).splitlines()
compile=shlex.split(next(line for line in commands if line.endswith('/tests/texture-set-source-export.cpp')))
obj=work/'baseline-fixture.o'
compile[compile.index('-o')+1]=str(obj)
if '-MF' in compile: compile[compile.index('-MF')+1]=str(work/'baseline-fixture.d')
link=shlex.split(commands[-1])[2:-2]
link[link.index('-o')+1]=str(work/'baseline-fixture')
link[link.index(next(arg for arg in link if arg.endswith('/texture-set-source-export.cpp.o')))]=str(obj)
link=[arg for arg in link if not arg.startswith('-Wl,--dependency-file=')]
env=dict(os.environ,LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',LIBGL_ALWAYS_SOFTWARE='1')
with (work/'baseline-fixture.log').open('w') as log:
    subprocess.run(compile,cwd=previous,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(link,cwd=previous,stdout=log,stderr=subprocess.STDOUT,check=True)
    outcome=subprocess.run([work/'baseline-fixture','--imported-mtoon',work/'baseline','painted'],env=env,stdout=log,stderr=subprocess.STDOUT)
    assert outcome.returncode!=0
assert 'FAIL Apply publishes a separate native MToon field' in (work/'baseline-fixture.log').read_text()
