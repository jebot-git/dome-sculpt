from hashlib import file_digest, sha256
import gzip
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'


def digest(path):
    with path.open('rb') as file:
        return file_digest(file, 'sha256').hexdigest()


def head(path):
    return subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()


def read(name):
    return json.loads((work / name).read_text())


baseline = 'baseline-fixture.log'
assert 'FAIL Apply publishes a separate native MToon field' in (work / baseline).read_text()
members = [
    'record.py','baseline.py',baseline,'check.sh','check-final.sh','check-incremental-asan.py',
    'khronos.cjs','khronos.json','khronos.log','run-render.py','xr-first-material.py',
    'run-wayland.py','wayland-first-material.py','bind-wayland.log',
    'wayland-first-material/report.json','wayland-first-material/corners.json',
    'wayland-first-material/source-viewport.png','render-authorities.cpp','render-authorities.py',
]
views = {}
for name, renderer in [('software','llvmpipe'),('arc','Arc(tm) A770')]:
    rendered = f'render-authorities-{name}.log'
    log = (work / rendered).read_text()
    assert renderer in log and 'PASS exact Editable GLB replay and live ink in both material views' in log
    measurements = tuple(map(int,re.search(r'modes=(\d+) typed_ink=(\d+) core_ink=(\d+)',log).groups()))
    assert all(v >= 100 for v in measurements)
    replay = f'xr-{name}-affine/compare.json'
    report = read(replay)
    assert report['runtime'] == 'synthetic OpenXR' and report['exact_ordered_close']
    assert len(report['profiles']) == 2
    for data in report['profiles']:
        assert renderer in data['gl_renderer'] and data['stereo_submissions'] == 6
        assert data['acquires'] == data['image_waits'] == data['releases'] == 12
    views[name] = {'renderer':report['profiles'][0]['gl_renderer'],
                   'pixels_differing_between_typed_and_core':measurements[0],
                   'visible_ink_pixels_typed':measurements[1],'visible_ink_pixels_core':measurements[2],
                   'same_pixels_after_editable_glb_reopen':True,'exact_openxr_close':True,
                   'stereo_submissions_per_project':6,'stereo_differences':report['differing_rgb_components_per_eye']}
    members += [rendered,replay,f'verified-affine-{name}.log']

khronos = read('khronos.json')
assert len(khronos['results']) == 7
for item in khronos['results']:
    original = item['file'].endswith('original-import.glb')
    issues = item['issues']
    assert issues['numErrors'] == 0 and issues['numWarnings'] == (0 if original else 1)
    if not original:
        assert [entry['code'] for entry in issues['messages'] if entry['severity']==1] == ['MESH_PRIMITIVE_GENERATED_TANGENT_SPACE']
    item['sha256'] = digest(work / item['file'])

wayland = read('wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks']) == 7 and all(item['passed'] for item in wayland['checks'])
variants = ('painted','tinted','unprepared')
profiles = {}
samples = {}
regular_asan = work / 'asan-final-tests.log'
whole_asan = regular_asan.is_file() and '0 tests failed out of 14' in regular_asan.read_text()
asan_dir = work / ('asan' if whole_asan else 'exact-asan')
profile_dirs = {'release':work/'release','asan':asan_dir}
if not whole_asan:
    members.append('asan-tests.log')
    for unit in ('paint.cpp','retopo-authoring.cpp','emission-bake-source.cpp','bake.cpp',
                 'bake-authoring.cpp','texture-set-surface.cpp','texture-set-source-export.cpp'):
        members.append('exact-asan/'+unit+'.build.log')
for profile, count in [('release',18),('asan',14)]:
    build = f'{profile}-final-build.log'
    name = f'{profile}-final-tests.log'
    incremental = profile=='asan' and not whole_asan
    if incremental: name='asan-incremental-tests.log'
    log = (work / name).read_text()
    passed = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',log)
    assert len(passed) == len(set(passed)) == count and f'0 tests failed out of {count}' in log
    profiles[profile] = passed
    members += [name] if incremental else [name,build]
    controls = (profile_dirs[profile] / 'Testing/Temporary/LastTest.log').read_text()
    samples[profile] = {}
    for mode in variants:
        case = 'retopology-imported-mtoon-'+mode
        match = re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.',controls,re.M | re.S)
        assert match and case in passed
        fixture = match[1]
        actual = re.search(r'IMPORTED_MTOON samples=(\d+) max_role=([\d.]+) max_core=([\d.]+) min_typed_dot=([\d.]+) min_core_dot=([\d.]+)',fixture)
        samples_count,role,core,typed_normal,core_normal = map(float,actual.groups())
        assert samples_count>=70 and max(role,core)<.006 and min(typed_normal,core_normal)>.9997
        checks = int(re.search(r'PASS (\d+) imported MToon retopology checks',fixture)[1])
        samples[profile][mode] = {'checks':checks,'samples':int(samples_count),'maximum_role_error':role,
                                  'maximum_pbr_error':core,'minimum_typed_normal_dot':typed_normal,
                                  'minimum_pbr_normal_dot':core_normal}
        fixture_log=f'{profile}-{mode}-native-controls.log'
        (work / fixture_log).write_text(fixture)
        members.append(fixture_log)
assert samples['release'] == samples['asan']

artifact_checksums = {}
for variant in variants:
    case = 'retopology-imported-mtoon-'+variant
    outputs = ['original-import.glb','raw-guide.dsculpt','raw-patch.dsculpt','raw-editable.glb']
    if variant == 'painted': outputs.append('raw-reapplied.dsculpt')
    for file in outputs:
        relative = Path(case) / file
        checksum = digest(work / 'release' / relative)
        assert checksum == digest(asan_dir / relative)
        assert checksum == digest(work / ('qualified-debug-'+variant) / file)
        artifact_checksums[str(relative)] = checksum

archive = validation / (work.name + '.tar.gz')
archive_members = {}
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as output:
        for name in members:
            data = (work / name).read_bytes()
            archive_members[name] = sha256(data).hexdigest()
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            output.addfile(entry, io.BytesIO(data))

receipt = {
    'product':head(repo),'previous_main':'863cbfdc8dfee53a7b49482fe30070a550c0ba87',
    'canonical_domed':head(repo.parent / 'DomeD'),
    'canonical_compositor_sha256':digest(work.parent/'creator-public-build-20261126/wayland-reference/dome-compositor'),
    'release_application_sha256':digest(work/'release/dome-sculpt'),
    'asan_test_sha256':digest(asan_dir/'dome-sculpt-texture-set-source-export-test'),
    'asan_build':'regular CMake/Ninja' if whole_asan else 'changed translation units incrementally rebuilt from the completed sanitizer core',
    'tests':profiles,'native_samples':samples,'identical_native_and_glb_outputs_sha256':artifact_checksums,
    'renderers':views,'physical_headset':False,'dome_wayland':wayland,'khronos':khronos,
    'portable_preview':'Core PBR with generated tangent space, native MToon recovered by Editable GLB',
    'archive_sha256':digest(archive),'archive_members_sha256':archive_members,
}
(validation/(work.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
