#include "dome/material-bindings.hpp"
#include "dome/render.hpp"
#include "dome/texture-sets.hpp"
#include "graphics.h"
#include <iostream>

using namespace dome;
namespace {
constexpr int width = 128;
constexpr int height = 128;
const Mat4 identity{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
using Pixels = std::array<uint8_t,width*height*4>;

Pixels draw(SurfaceRenderer &renderer, const Scene &scene,bool pbr=false) {
  Document document;
  document.replace(scene);
  if (pbr) document.shading(false);
  if (!document.wait_asset() || !document.wait_mesh() || !document.frame().state->error.empty())
    throw std::runtime_error(document.frame().state->error);
  renderer.draw(document.frame().surface,{},identity,{0,0,2},width,height,true);
  Pixels result{};
  glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,result.data());
  if (glGetError()!=GL_NO_ERROR) throw std::runtime_error("Fixture framebuffer read failed");
  return result;
}

}

int main(int argc, char **argv) try {
  if (argc!=3) return 2;
  NativeGraphics graphics;
  std::cout<<"GPU "<<glGetString(GL_RENDERER)<<'\n';
  GLuint framebuffer=0, color=0, depth=0;
  glGenFramebuffers(1,&framebuffer);
  glBindFramebuffer(GL_FRAMEBUFFER,framebuffer);
  glGenTextures(1,&color);
  glBindTexture(GL_TEXTURE_2D,color);
  glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
  glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,color,0);
  glGenRenderbuffers(1,&depth);
  glBindRenderbuffer(GL_RENDERBUFFER,depth);
  glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,width,height);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,depth);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)
    throw std::runtime_error("Incomplete fixture framebuffer");
  SurfaceRenderer renderer;
  const auto scene=Scene::load(argv[1]);
  const auto portable=Scene::load(argv[2]);
  if (scene.encode()!=portable.encode()) throw std::runtime_error("Editable GLB differs from native project");
  const auto authored=draw(renderer,scene);
  const auto core=draw(renderer,scene,true);
  if (authored!=draw(renderer,portable)||core!=draw(renderer,portable,true))
    throw std::runtime_error("Cold Editable GLB changed either viewport interpretation");
  auto reveal=scene.snapshot();
  reveal.active().painted->layer_properties("Original hidden ink",true,.37f);
  const auto paint=draw(renderer,reveal);
  const auto paint_core=draw(renderer,reveal,true);
  const auto count=[](const Pixels &a,const Pixels &b) {
    size_t different=0,opaque=0;
    for(size_t i=0;i<a.size();i+=4){
      opaque+=a[i+3]>240&&b[i+3]>240;
      int error=0;
      for(size_t k=0;k<3;++k)error=std::max(error,std::abs(int(a[i+k])-b[i+k]));
      different+=a[i+3]>0&&b[i+3]>0&&error>1;
    }
    if(opaque<200||different<100)throw std::runtime_error("The comparison did not see the actual relevant surface");
    return different;
  };
  const auto modes=count(authored,core), ink=count(authored,paint), core_ink=count(core,paint_core);
  std::cout<<"PASS exact Editable GLB replay and live ink in both material views: modes="<<modes
           <<" typed_ink="<<ink<<" core_ink="<<core_ink<<'\n';
  glDeleteRenderbuffers(1,&depth);
  glDeleteTextures(1,&color);
  glDeleteFramebuffers(1,&framebuffer);
} catch (const std::exception &error) {
  std::cerr<<"FAIL "<<error.what()<<'\n';
  return 1;
}
