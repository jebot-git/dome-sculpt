from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
for x in m:
 p=r/x['path'];assert p.is_file()and p.stat().st_size==x['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']
for profile in ['release','sanitize']:
 root=r/'authoring-eligible-owning-20261111'
 c=json.loads((root/(profile+'-v3')/'status.json').read_text());assert c['exit']==0 and c['state']=='terminal'and not c['audit_only']and len(c['target_outputs'])==65 and len(c['steps'])==63 and not c['pin_drift']and not c['output_drift']
 g=json.loads((root/(profile+'-gates')/'status.json').read_text());assert g['exit']==0 and g['selected_results']['pass']==g['selected_results']['total']==56 and not g['provider_drift']and all(s['exit']==0 and s['external_guard']is None for s in g['steps'])
 o=json.loads((r/'authoring-query-owning-20261111'/(profile+'-gates')/'status.json').read_text());assert o['exit']==1 and o['selected_results']['pass']==54 and o['selected_results']['total']==56
 for case,n in [('original',64),('large',63)]:
  a=json.loads((r/'authoring-eligible-capacity-arc-20261111'/(profile+'-'+case)/'status.json').read_text());assert a['exit']==a['native_exit']==0 and a['expected_original_native_checks']==n and a['actual_device_authenticated']and a['native_check_count_exact']and not a['guard']and not a['sanitizer_diagnostics']and not a['input_drift']and not a['output_drift']and not a['source_drift']and not a['mapped_ELF_provider_drift']
print('All evidence member hashes and unchanged raw positive/negative scopes verified; no application or GPU run.')
