#!/usr/bin/env python3
"""Four bounded FUNCTIONAL Arc capacity controls, not a quiet performance gate.

Exact current-v3 consumer ELF/arguments/assertions; only an unchanged-result
GL-renderer query observer authenticates actual EGLDevice/DRM/PCI/openFD/maps.
Shared flock is acquired separately per case and released before posthashing.
"""
import argparse,fcntl,hashlib,json,os,re,resource,signal,subprocess,time
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('profile',choices=['release','sanitize']);ap.add_argument('case',choices=['original','large']);args=ap.parse_args()
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];SOURCE=ROOT/'artifacts/authoring-eligible-integration-20261111';BUILD=ROOT/'artifacts/authoring-eligible-owning-20261111'/(args.profile+'-v3');CLOSURE=BUILD/'status.json';SOURCE_COMMIT='e9931f7286f75746af47d52f2d901b731510cbb5';DEST=OUT/(args.profile+'-'+args.case);SDK=ROOT/'artifacts/sdk-20261111'/('toolkit-'+args.profile)
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(*cmd):return subprocess.check_output(['git',*cmd],cwd=SOURCE,text=True).strip()
def drift(pins):return [p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def dump(value):
 t=DEST/'status.writing';t.write_text(json.dumps(value,indent=2)+'\n');t.replace(DEST/'status.json')
assert git('rev-parse','HEAD')==SOURCE_COMMIT and not git('status','--porcelain');closure=json.loads(CLOSURE.read_text());assert closure['source']==SOURCE_COMMIT and closure['state']=='terminal'and closure['exit']==0 and not closure['pin_drift']and not closure['output_drift']and len(closure['target_outputs'])==65
pins=dict(closure['pins']);pins[str(CLOSURE)]=sha(CLOSURE);pins[str(Path(__file__).resolve())]=sha(__file__)
for row in closure['target_outputs'].values():pins[row['path']]=row['sha256']
pins[str(BUILD/'libdome-sculpt-core.a')]=closure['core_archive']['sha256']
observer=OUT/('device-auth-'+args.profile+'.so');observer_build=json.loads((OUT/'observer-build.json').read_text());ob=next(x for x in observer_build['profiles']if x['profile']==args.profile);assert ob['exit']==0 and sha(observer)==ob['elf_sha256']and sha(OUT/'device-auth.cpp')==ob['source_sha256']
for p in [observer,OUT/'device-auth.cpp',OUT/'observer-build.json']:pins[str(p)]=sha(p)
assert not drift(pins)
binary=Path(closure['target_outputs']['dome-sculpt-document-render-capacity-test']['path']);assert binary.parent==BUILD/'plan';command=[str(binary),'--hardware'if args.case=='original'else'--large-buffer']
DEST.mkdir();env=os.environ.copy()
for key in ['DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','XR_RUNTIME_JSON','LD_PRELOAD','DRI_PRIME','LIBGL_ALWAYS_SOFTWARE','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','MESA_VK_DEVICE_SELECT','VK_ICD_FILENAMES','LIBGL_DRIVERS_PATH','__EGL_VENDOR_LIBRARY_FILENAMES','EGL_PLATFORM','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']:env.pop(key,None)
env.update(LD_LIBRARY_PATH=str(SDK/'lib')+':/usr/lib64',LD_PRELOAD=str(observer),DRI_PRIME='pci-0000_03_00_0',LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',DOME_MARKER_DEVICE_REPORT=str(DEST/'device'))
if args.profile=='sanitize':
 asan=Path('/usr/lib64/libasan.so.8');assert asan.is_file();pins[str(asan)]=sha(asan);env.update(LD_PRELOAD=str(asan)+':'+str(observer),ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
record={'state':'prepared','source':SOURCE_COMMIT,'profile':args.profile,'case':args.case,'command':command,'scope':__doc__,'observer':ob,'closure':str(CLOSURE),'closure_sha256':sha(CLOSURE),'pins':pins,'environment':{k:env.get(k)for k in ['LD_LIBRARY_PATH','LD_PRELOAD','DRI_PRIME','LIBGL_ALWAYS_SOFTWARE','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','LSAN_OPTIONS','ASAN_OPTIONS','UBSAN_OPTIONS','DOME_MARKER_DEVICE_REPORT','LP_NUM_THREADS']},'limits':{'seconds':240,'rss_bytes':(4 if args.profile=='release'else 8)*1024**3},'performance_claim':False,'cpu_contention':'Other authorized CPU/software validation may run; functional evidence only.'};dump(record)
lease=None;process=None;maps=set();first_mapped_hashes={};fds=set();samples=0;peak=0;guard=None;start=None
try:
 lease=open('/tmp/dome-sculpt-arc-device.lock','a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);record['lease_acquired_epoch']=time.time();record['state']='running';dump(record)
 with (DEST/'process.log').open('w')as log:
  start=time.monotonic();process=subprocess.Popen(command,cwd=DEST,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);record['pid']=process.pid;dump(record);print(json.dumps({'state':'running','profile':args.profile,'case':args.case,'pid':process.pid,'shared_Arc_lease':'HELD','status':str(DEST/'status.json')}),flush=True)
  while process.poll()is None:
   try:
    for row in Path(f'/proc/{process.pid}/maps').read_text().splitlines():
     parts=row.split(None,5)
     if len(parts)==6 and parts[5].startswith('/')and not parts[5].endswith('(deleted)'):
      name=parts[5];maps.add(name)
      if name not in first_mapped_hashes:
       try:
        with Path(name).open('rb')as f:magic=f.read(4)
        if magic==b'\x7fELF':first_mapped_hashes[name]=sha(name)
       except OSError:pass
    for fd in Path(f'/proc/{process.pid}/fd').iterdir():
     try:
      name=os.readlink(fd)
      if name.startswith('/dev/dri/'):fds.add(name)
     except OSError:pass
    line=next(x for x in Path(f'/proc/{process.pid}/status').read_text().splitlines()if x.startswith('VmRSS:'));rss=int(line.split()[1])*1024;peak=max(peak,rss);samples+=1
    if rss>record['limits']['rss_bytes']:guard='original_upfront_RSS_limit'
   except(OSError,StopIteration):pass
   if time.monotonic()-start>240:guard='original240s_deadline'
   if guard:os.killpg(process.pid,signal.SIGKILL);break
   time.sleep(.01)
  record['native_exit']=process.wait();record['seconds']=time.monotonic()-start
except Exception as error:
 record['error']=repr(error)
 if process and process.poll()is None:os.killpg(process.pid,signal.SIGKILL);record['native_exit']=process.wait()
finally:
 if lease:
  fcntl.flock(lease,fcntl.LOCK_UN);lease.close();record['lease_released_epoch']=time.time()
 record['state']='postcheck';dump(record)
text=(DEST/'process.log').read_text()if (DEST/'process.log').exists()else''
context=DEST/'device/context-maps.txt'
if context.exists():
 for row in context.read_text().splitlines():
  fields=row.split(None,5)
  if len(fields)==6 and fields[5].startswith('/')and not fields[5].endswith('(deleted)'):maps.add(fields[5])
providers={}
for m in sorted(maps):
 try:
  p=Path(m)
  if p.is_file():
   with p.open('rb')as f:magic=f.read(4)
   if magic==b'\x7fELF':providers[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size,'first_live_mapped_sha256':first_mapped_hashes.get(str(p))}
 except OSError:pass
expected_count=64 if args.case=='original'else 63;countline=f'{expected_count} '+('Document capacity checks passed'if args.case=='original'else'Separate large-buffer checks passed')
device=(DEST/'device/device.txt').read_text()if (DEST/'device/device.txt').exists()else''
auth=('STRICT_MARKER_ACTUAL' in text and 'STRICT_MARKER_DEVICE' in text and 'STRICT_MARKER_OPEN_FD' in text and 'STRICT_MARKER_REFUSAL' not in text and 'A770' in device and 'render_node=/dev/dri/renderD129' in device and '/0000:03:00.0' in device and 'vendor_id=0x8086' in device and 'device_id=0x56a0' in device and '/dev/dri/renderD129' in fds and str(observer)in providers)
record.update(guard=guard,maxrss_bytes=peak,live_proc_samples=samples,actual_live_DRM_FDs=sorted(fds),actual_device_authenticated=auth,device_report=device,mapped_ELF_providers=providers,expected_original_native_checks=expected_count,native_check_count_exact=countline in text,source_head_after=git('rev-parse','HEAD'),source_git_status_after=git('status','--porcelain'),input_drift=drift(pins),mapped_ELF_provider_drift=[p for p,r in providers.items()if not Path(p).is_file()or sha(p)!=r['sha256']or (r['first_live_mapped_sha256']and r['first_live_mapped_sha256']!=r['sha256'])],process_log_sha256=sha(DEST/'process.log')if (DEST/'process.log').exists()else None)
record['output_drift']=[r['path']for r in closure['target_outputs'].values()if sha(r['path'])!=r['sha256']]
record['source_drift']=[p for p,h in closure['source_pins'].items()if sha(p)!=h]
record['sanitizer_diagnostics']=bool(re.search(r'ERROR: (AddressSanitizer|LeakSanitizer)|SUMMARY: (AddressSanitizer|LeakSanitizer)|runtime error:',text))
record['state']='terminal';record['exit']=0 if record.get('native_exit')==0 and not guard and auth and record['native_check_count_exact']and not record['input_drift']and not record['output_drift']and not record['source_drift']and not record['source_git_status_after']and record['source_head_after']==SOURCE_COMMIT and not record['mapped_ELF_provider_drift']and not record['sanitizer_diagnostics']else 1;dump(record)
print(json.dumps({k:record.get(k)for k in ['state','profile','case','pid','native_exit','exit','guard','seconds','maxrss_bytes','actual_device_authenticated','native_check_count_exact','input_drift','source_drift','output_drift','mapped_ELF_provider_drift','lease_released_epoch','error']},indent=2),flush=True)
raise SystemExit(record['exit'])
