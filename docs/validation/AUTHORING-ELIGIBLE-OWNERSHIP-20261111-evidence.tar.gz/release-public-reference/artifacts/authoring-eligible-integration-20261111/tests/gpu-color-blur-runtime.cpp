// Public blur workflow derived from texture-set-resolution-runtime.cpp SHA256 931454ae4c1f8d9737472d0f0f81d037fa1d4fcd29f60a9df608b9e02fd5c864
// Existing resolution runtime and its117 checks remain separate and unchanged.
// Source base tests/xr_runtime.cpp SHA256 9ecf93ce86fbd1d33b20ee39acb34ae4659cf9cdefd5135f7ceabba3ef5a063a
// Reuses actual loader/swapchain plumbing; blur actions and native Save gates are below.
#include "../include/dome/bake-distance.hpp"
#include "gpu-color-blur-visual-reference.hpp"
// SPDX-License-Identifier: GPL-3.0-or-later
// A deterministic OpenXR test runtime. It creates real GL swapchain images;
// poses and actions are synthetic fixtures, never evidence of hardware
// tracking.
#define XR_NO_PROTOTYPES
#define XR_USE_PLATFORM_EGL
#define XR_USE_GRAPHICS_API_OPENGL
#define GL_GLEXT_PROTOTYPES
#include <EGL/egl.h>
#include <GL/gl.h>
#include <GL/glext.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <fstream>
#include <filesystem>
#include <map>
#include <memory>
#include <string_view>
#include <nlohmann/json.hpp>
#include <openxr/openxr.h>
#include <openxr/openxr_loader_negotiation.h>
#include <openxr/openxr_platform.h>
#include <thread>
#include <vector>
namespace {
using Json = nlohmann::json;
struct Action {
  std::string name;
  XrActionType type;
};
struct Space {
  Action *action = nullptr;
  XrPath hand = 0;
  XrReferenceSpaceType reference = XR_REFERENCE_SPACE_TYPE_LOCAL;
};
struct Swap {
  GLuint texture[2]{};
  GLuint read_fbo = 0;
  int64_t format = GL_RGBA8;
  uint32_t width, height, index = 0;
  bool acquired = false, waited = false;
  int eye;
};
std::vector<std::unique_ptr<Action>> actions;
std::vector<std::unique_ptr<Space>> spaces;
std::vector<std::unique_ptr<Swap>> chains;
std::map<std::string, XrPath> paths;
std::map<XrPath, std::string> names;
Json report = Json::object();
int instance_tag, session_tag, action_set_tag;
unsigned frame = 0, physical_frame = 0, event = 0, restart_phase = 0;
unsigned menu_completion_event = 0;
unsigned field_step=0;bool field_panel_ready=false;
std::array<std::map<unsigned,std::pair<unsigned,unsigned>>,2> blur_page_visible;
std::array<std::vector<uint8_t>,2> field_root_signatures;
std::array<std::map<unsigned,std::pair<unsigned,unsigned>>,2> field_root_visible;
std::array<std::map<unsigned,std::pair<unsigned,unsigned>>,2> field_menu_closed;
std::array<bool,2> field_root_eye_open{};
bool field_root_open=false;
blur_visual_reference::Reference&visual_reference(){
 const auto*file=getenv("DOME_XR_PAINT_TITLE_REFERENCE");if(!file)throw std::runtime_error("Missing source-font reference input");static blur_visual_reference::Reference reference(file);return reference;
}
blur_visual_reference::Match visual_match(const std::string&name,int eye,int width,int height,std::span<const uint8_t>pixels,blur_visual_reference::Background background=blur_visual_reference::Background::Panel,bool empty=false){
 try{return visual_reference().match(name,eye,width,height,pixels,background,empty);}catch(const std::exception&e){blur_visual_reference::Match m;m.error=e.what();return m;}
}
size_t visual_checkbox_difference(int eye,int width,int height){try{return visual_reference().difference("checkbox-checked","checkbox-unchecked",eye,width,height);}catch(...){return 0;}}


std::string field_mode(){const auto*p=getenv("DOME_XR_PAINT_BLUR");return p?p:"";}
bool field_history(){return field_mode()=="apply";}
bool field_root_gate(){return field_step==61||field_step==77||field_step==91;}
bool field_close_gate(){return field_step==65||field_step==79||field_step==93;}
bool field_reset(){return false;}
bool field_mark(const char*name){const auto*p=getenv("DOME_XR_PAINT_GATES");return p&&std::filesystem::exists(std::filesystem::path(p)/name);}
uint32_t field_target(){return 64;}
bool blur_page_gate(){return field_step==21||field_step==31||field_step==43||field_step==49||field_step==55;}
bool field_wait(){
 if(field_step==9&&(field_root_signatures[0].empty()||field_root_signatures[1].empty()))return true;
 auto pending=[&](const auto&eyes){for(const auto&visible:eyes){const auto at=visible.find(field_step);if(at==visible.end()||at->second.second+1!=physical_frame||physical_frame<at->second.first+3)return true;}return false;};
 if(field_root_gate())return pending(field_root_visible);
 if(field_close_gate())return pending(field_menu_closed);
 if(blur_page_gate())return pending(blur_page_visible);
 return (field_step==67&&!field_mark("accepted"))||(field_step==81&&!field_mark("undone"))||(field_step==95&&!field_mark("redone"));
}
bool field_click(){
 if(field_root_gate()||field_step==31)return !field_root_open&&physical_frame%4==0;
 return field_step==8||field_step==14||field_step==20||field_step==26||field_step==30||field_step==36||field_step==42||field_step==48||field_step==54||field_step==60||field_step==64||field_step==76||field_step==78||field_step==90||field_step==92;
}
int field_sector(){
 if(field_root_gate())return field_root_open?6:-1;
 if(field_step>=12&&field_step<=14)return 9;
 if(field_step>=18&&field_step<=20)return 3;
 if(field_step>=21&&field_step<=26)return 10; // Real Painting/Erase toggle.
 if(field_step==31)return field_root_open?9:-1;
 if(field_step>=34&&field_step<=36)return 9;
 if(field_step>=40&&field_step<=42)return 3;
 if(field_step>=43&&field_step<=48)return 11;
 if(field_step>=49&&field_step<=54)return 10;
 if(field_step>=55&&field_step<=60)return 1;
 if((field_step>=62&&field_step<=64)||field_step==78||field_step==92)return 6;
 return -1;
}

std::string canonical_conversion_mode(){auto p=getenv("DOME_XR_FIXTURE_CANONICAL");return p?p:"";}
std::string cage_mode(){auto p=getenv("DOME_XR_FIXTURE_CAGE");return p?p:canonical_conversion_mode();}
bool canonical_conversion_click(){return frame==8||frame==14||frame==20||frame==26||frame==32;}
int canonical_conversion_sector(){if(frame>=12&&frame<=14)return 8;if(frame>=18&&frame<=20)return 9;if(frame>=24&&frame<=26)return 6;if(frame>=30&&frame<=32)return 0;return -1;}
bool bake_recipe_fixture(){return getenv("DOME_XR_FIXTURE_RECIPE")!=nullptr;}

std::string expression_mode(){auto p=getenv("DOME_XR_FIXTURE_EXPRESSIONS");return p?p:"";}
bool expression_click(){return frame==8||frame==16||frame==24||frame==32||frame==52||frame==60||frame==72||frame==80||(frame==100&&expression_mode()!="focus");}
int expression_sector(){if(frame>=14&&frame<=16)return 9;if(frame>=22&&frame<=24)return 9;if(frame>=30&&frame<=32)return 3;if((frame>=50&&frame<=52)||(frame>=58&&frame<=60))return 3;if(frame>=70&&frame<=72)return 9;if(frame>=78&&frame<=80)return 7;if(frame>=98&&frame<=100&&expression_mode()!="focus")return expression_mode()=="cancel"?6:5;return -1;}
bool cage_click(){return frame==8||frame==14||frame==20||frame==26||frame==32||frame==44||frame==50||(cage_mode()=="accept"&&(frame==62||frame==68));}
int cage_sector(){if(frame>=12&&frame<=14)return 8;if(frame>=18&&frame<=20)return 9;if(frame>=24&&frame<=26)return 6;if(frame>=30&&frame<=32)return 1;if(frame>=48&&frame<=50)return 0;if(frame>=66&&frame<=68&&cage_mode()=="accept")return 3;return -1;}
std::string mirror_mode(){auto p=getenv("DOME_XR_FIXTURE_MIRROR");return p?p:"";}
int mirror_method(){auto p=getenv("DOME_XR_FIXTURE_MIRROR_METHOD");return p?std::clamp(std::atoi(p),0,2):0;}
bool mirror_click(){return frame==8||frame==14||frame==20||frame==26||frame==32;}
int mirror_sector(){if(frame>=12&&frame<=14)return 8;if(frame>=18&&frame<=20)return 9;if(frame>=24&&frame<=26)return 7;if(frame>=30&&frame<=32)return 3;return -1;}
std::string corner_uv_mode(){auto mode=getenv("DOME_XR_FIXTURE_CORNER_UV");return mode?mode:"";}
std::string rig_fit_mode(){auto p=getenv("DOME_XR_FIXTURE_RIG_FIT");return p?p:"";}
bool rig_fit_click(){return frame==8||frame==14||frame==20||frame==26||frame==32||frame==38||frame==58;}
int rig_fit_sector(){if(frame>=12&&frame<=14)return 8;if(frame>=18&&frame<=20)return 10;if(frame>=24&&frame<=26)return 5;if(frame>=30&&frame<=32)return 7;if(frame>=36&&frame<=38)return 2;if(frame>=56&&frame<=58)return 10;return -1;}
std::string projection_mode(){auto p=getenv("DOME_XR_FIXTURE_PROJECTION");return p?p:"";}
bool projection_click(){return frame==8||frame==14||frame==20||frame==26||frame==32||frame==38||frame==50||frame==62||frame==68;}
int projection_sector(){if(frame>=12&&frame<=14)return 9;if(frame>=18&&frame<=20)return 3;if(frame>=24&&frame<=26)return 11;if(frame>=30&&frame<=32)return 9;if(frame>=36&&frame<=38)return 0;if(frame>=48&&frame<=50)return 3;if(frame>=60&&frame<=62)return 8;if(frame>=66&&frame<=68)return 2;return -1;}
std::string affine_contact_mode(){auto p=getenv("DOME_XR_FIXTURE_AFFINE_CONTACT");return p?p:"";}
std::string import_atlas_mode(){auto value=getenv("DOME_XR_FIXTURE_IMPORT_ATLAS");return value?value:"";}
bool import_atlas_click(){if(frame==50&&getenv("DOME_XR_FIXTURE_IMPORT_EXTRA_RAW"))return false;return frame==8||frame==14||frame==20||frame==26||frame==42||frame==50||frame==58||frame==66||frame==74||frame==82||(import_atlas_mode()=="accept"&&frame==90);}
int import_atlas_sector(){
 if(frame>=12&&frame<=14)return 8;if(frame>=18&&frame<=20)return 9;if(frame>=24&&frame<=26)return 10;
 if(frame>=40&&frame<=42)return 5;if(frame>=48&&frame<=50)return 9;
 if((frame>=56&&frame<=58)||(frame>=64&&frame<=66)||(frame>=72&&frame<=74))return 4;
 if(frame>=80&&frame<=82)return 8;if(import_atlas_mode()=="accept"&&frame>=88&&frame<=90)return 6;return -1;
}
bool pbr_preview_fixture(){return getenv("DOME_XR_FIXTURE_PBR_VIEW")!=nullptr;}
bool selection_fixture(){return getenv("DOME_XR_FIXTURE_SELECTION")!=nullptr;}
std::string_view editable_avatar_mode(){const auto *p=getenv("DOME_XR_FIXTURE_EDITABLE_AVATAR");return p?p:"";}
bool editable_avatar_path(const char *name){const auto *directory=getenv("DOME_TEST_EXPORT_GATE_DIR");return directory&&std::filesystem::exists(std::filesystem::path(directory)/name);}
bool menu_gate() { return getenv("DOME_XR_FIXTURE_MENU_GATE") != nullptr; }
bool lost = false, regained = false, reference_event = false;
bool ink() { return getenv("DOME_XR_FIXTURE_STYLUS") != nullptr; }
std::string bake_mode(){auto mode=getenv("DOME_XR_FIXTURE_BAKE");return mode?mode:"";}
std::string skin_mode(){auto mode=getenv("DOME_XR_FIXTURE_SKIN");return mode?mode:"";}
std::string retopo_mode(){auto mode=getenv("DOME_XR_FIXTURE_RETOPO");return mode?mode:"";}
bool retopo_history(){return retopo_mode().starts_with("history-");}
bool history_undo(unsigned n){return (n>=4&&n<=16)||(n>=20&&n<=23)||(n>=48&&n<=54);}
bool history_redo(unsigned n){return (n>=26&&n<=29)||(n>=33&&n<=36)||(n>=48&&n<=54);}
std::string cut_mode(){auto mode=getenv("DOME_XR_FIXTURE_CUT");return mode?mode:"";}
unsigned cut_step=0;
bool cut_held(){return getenv("DOME_XR_FIXTURE_CUT_HELD")!=nullptr;}
unsigned cut_stage(){return !cut_held()?cut_step:cut_step<28?0:cut_step-14;}
bool cut_preview_ready=false,cut_apply_ready=false;
std::string mask_mode(){auto mode=getenv("DOME_XR_FIXTURE_SCULPT_MASK");return mode?mode:"";}
bool bake_normal_mode(){return getenv("DOME_XR_FIXTURE_BAKE_NORMAL")!=nullptr;}
bool bake_color_mode(){return getenv("DOME_XR_FIXTURE_BAKE_COLOR")!=nullptr||bake_normal_mode();}
std::string bake_policy_mode(){auto mode=getenv("DOME_XR_FIXTURE_BAKE_POLICY");if(!mode)mode=getenv("DOME_XR_FIXTURE_BAKE_COLOR");if(!mode)mode=getenv("DOME_XR_FIXTURE_BAKE_NORMAL");return mode?mode:"";}
bool bake_projection_mode(){return getenv("DOME_XR_FIXTURE_BAKE_POLICY")!=nullptr;}
// Projection-policy tests first select their live source explicitly. The saved
// recipe can correctly retain an unavailable historical source after deletion.
unsigned bake_policy_stage(){return !bake_projection_mode()||frame<=20?frame:frame<=22?0:frame-8;}
std::string procedural_mode(){auto mode=getenv("DOME_XR_FIXTURE_PROCEDURAL");return mode?mode:"";}
std::string resolution_mode(){auto mode=getenv("DOME_XR_FIXTURE_RESOLUTION");return mode?mode:"";}
std::string polygon_mode(){auto mode=getenv("DOME_XR_FIXTURE_POLYGON");return mode?mode:"";}
unsigned polygon_step=0;bool polygon_initial_ready=false,polygon_source_ready=false,polygon_selection_ready=false,polygon_edit_ready=false,polygon_motion_base_ready=false,polygon_motion_visible=false;
bool polygon_color(){return getenv("DOME_XR_FIXTURE_POLYGON_COLOR")!=nullptr;}
bool polygon_color_conversion(){return polygon_color() && !polygon_mode().starts_with("restore") && polygon_step>=17 && polygon_step<=22;}
unsigned polygon_stage(){
  if(!polygon_color() || polygon_mode().starts_with("restore"))return polygon_step;
  if(polygon_step>=23)return polygon_step-4;
  return polygon_step>=17?0:polygon_step;
}
std::vector<uint8_t> polygon_motion_before;
unsigned mask_step=0;bool mask_work_ready=false, mask_work_completed=false, mask_released=false;
unsigned retopo_step = 0;
bool retopo_source_ready = false, retopo_apply_ready = false;

std::string voxel_mode() {
  auto mode = getenv("DOME_XR_FIXTURE_VOXEL");
  return mode ? mode : "";
}
XrPath path(std::string text) {
  auto found = paths.find(text);
  if (found != paths.end())
    return found->second;
  XrPath value = paths.size() + 1;
  paths[text] = value;
  names[value] = text;
  return value;
}
bool right(XrPath p) { return names[p].find("right") != std::string::npos; }
void count(const char *key) { report[key] = report.value(key, 0) + 1; }
void save() {
  auto out = getenv("DOME_XR_FIXTURE_REPORT");
  if (out) {
    std::ofstream file(out);
    file << report.dump(2) << '\n';
  }
}
#define FN(name, ...) XrResult XRAPI_CALL f_##name(__VA_ARGS__)
FN(EnumerateInstanceExtensionProperties, const char *, uint32_t cap,
   uint32_t *n, XrExtensionProperties *out) {
  std::vector<const char *> values = {
      XR_KHR_OPENGL_ENABLE_EXTENSION_NAME, XR_MNDX_EGL_ENABLE_EXTENSION_NAME,
      "XR_LOGITECH_mx_ink_stylus_interaction", "XR_META_touch_controller_plus"};
  if (!getenv("DOME_XR_FIXTURE_NO_OVERLAY"))
    values.push_back(XR_EXTX_OVERLAY_EXTENSION_NAME);
  *n = values.size();
  if (!cap)
    return XR_SUCCESS;
  if (cap < *n)
    return XR_ERROR_SIZE_INSUFFICIENT;
  for (uint32_t i = 0; i < *n; ++i) {
    out[i].type = XR_TYPE_EXTENSION_PROPERTIES;
    strcpy(out[i].extensionName, values[i]);
    out[i].extensionVersion = 1;
  }
  return XR_SUCCESS;
}
FN(CreateInstance, const XrInstanceCreateInfo *info, XrInstance *out) {
  report = Json::object();
  report["application"] = info->applicationInfo.applicationName;
  *out = reinterpret_cast<XrInstance>(&instance_tag);
  return XR_SUCCESS;
}
FN(DestroyInstance, XrInstance) {
  save();
  actions.clear();
  spaces.clear();
  chains.clear();
  return XR_SUCCESS;
}
FN(GetInstanceProperties, XrInstance, XrInstanceProperties *p) {
  strcpy(p->runtimeName, "Dome Sculpt deterministic test runtime");
  p->runtimeVersion = XR_MAKE_VERSION(1, 0, 0);
  return XR_SUCCESS;
}
FN(GetSystem, XrInstance, const XrSystemGetInfo *, XrSystemId *id) {
  *id = 1;
  return XR_SUCCESS;
}
FN(GetSystemProperties, XrInstance, XrSystemId, XrSystemProperties *p) {
  p->systemId = 1;
  strcpy(p->systemName, "Synthetic stereo fixture");
  p->graphicsProperties = {1024, 1024, 8};
  p->trackingProperties = {XR_TRUE, XR_TRUE};
  return XR_SUCCESS;
}
FN(GetOpenGLGraphicsRequirementsKHR, XrInstance, XrSystemId,
   XrGraphicsRequirementsOpenGLKHR *p) {
  p->minApiVersionSupported = XR_MAKE_VERSION(3, 3, 0);
  p->maxApiVersionSupported = XR_MAKE_VERSION(4, 6, 0);
  return XR_SUCCESS;
}
FN(CreateSession, XrInstance, const XrSessionCreateInfo *info, XrSession *out) {
  auto binding = static_cast<const XrGraphicsBindingEGLMNDX *>(info->next);
  if (!binding || binding->type != XR_TYPE_GRAPHICS_BINDING_EGL_MNDX ||
      eglGetCurrentContext() != binding->context)
    return XR_ERROR_GRAPHICS_DEVICE_INVALID;
  report["egl_binding"] = true;
  report["overlay"] = binding->next != nullptr;
  *out = reinterpret_cast<XrSession>(&session_tag);
  return XR_SUCCESS;
}
FN(DestroySession, XrSession) {
  count("sessions_destroyed");
  save();
  return XR_SUCCESS;
}
FN(EnumerateReferenceSpaces, XrSession, uint32_t cap, uint32_t *n,
   XrReferenceSpaceType *p) {
  *n = 3;
  if (!cap)
    return XR_SUCCESS;
  if (cap < 3)
    return XR_ERROR_SIZE_INSUFFICIENT;
  p[0] = XR_REFERENCE_SPACE_TYPE_STAGE;
  p[1] = XR_REFERENCE_SPACE_TYPE_LOCAL;
  p[2] = XR_REFERENCE_SPACE_TYPE_VIEW;
  return XR_SUCCESS;
}
FN(CreateReferenceSpace, XrSession, const XrReferenceSpaceCreateInfo *p,
   XrSpace *out) {
  auto s = std::make_unique<Space>();
  s->reference = p->referenceSpaceType;
  *out = reinterpret_cast<XrSpace>(s.get());
  spaces.push_back(std::move(s));
  return XR_SUCCESS;
}
FN(DestroySpace, XrSpace p) {
  auto s = reinterpret_cast<Space *>(p);
  std::erase_if(spaces, [&](auto &v) { return v.get() == s; });
  return XR_SUCCESS;
}
FN(CreateActionSet, XrInstance, const XrActionSetCreateInfo *,
   XrActionSet *out) {
  *out = reinterpret_cast<XrActionSet>(&action_set_tag);
  return XR_SUCCESS;
}
FN(DestroyActionSet, XrActionSet) {
  actions.clear();
  return XR_SUCCESS;
}
FN(CreateAction, XrActionSet, const XrActionCreateInfo *p, XrAction *out) {
  auto a = std::make_unique<Action>(Action{p->actionName, p->actionType});
  *out = reinterpret_cast<XrAction>(a.get());
  actions.push_back(std::move(a));
  return XR_SUCCESS;
}
FN(DestroyAction, XrAction) { return XR_SUCCESS; }
FN(StringToPath, XrInstance, const char *value, XrPath *out) {
  *out = path(value);
  return XR_SUCCESS;
}
FN(PathToString, XrInstance, XrPath p, uint32_t cap, uint32_t *n, char *out) {
  if (!names.contains(p))
    return XR_ERROR_PATH_INVALID;
  *n = names[p].size() + 1;
  if (!cap)
    return XR_SUCCESS;
  if (cap < *n)
    return XR_ERROR_SIZE_INSUFFICIENT;
  memcpy(out, names[p].c_str(), *n);
  return XR_SUCCESS;
}
FN(SuggestInteractionProfileBindings, XrInstance,
   const XrInteractionProfileSuggestedBinding *p) {
  std::string profile = names[p->interactionProfile];
  for (uint32_t i = 0; i < p->countSuggestedBindings; ++i) {
    auto a = reinterpret_cast<Action *>(p->suggestedBindings[i].action);
    auto binding = names[p->suggestedBindings[i].binding];
    report["bindings"][profile][a->name].push_back(binding);
  }
  return XR_SUCCESS;
}
FN(AttachSessionActionSets, XrSession, const XrSessionActionSetsAttachInfo *) {
  return XR_SUCCESS;
}
FN(CreateActionSpace, XrSession, const XrActionSpaceCreateInfo *p,
   XrSpace *out) {
  auto s = std::make_unique<Space>();
  s->action = reinterpret_cast<Action *>(p->action);
  s->hand = p->subactionPath;
  *out = reinterpret_cast<XrSpace>(s.get());
  spaces.push_back(std::move(s));
  return XR_SUCCESS;
}
FN(EnumerateEnvironmentBlendModes, XrInstance, XrSystemId,
   XrViewConfigurationType, uint32_t cap, uint32_t *n,
   XrEnvironmentBlendMode *p) {
  *n = 1;
  if (cap)
    p[0] = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
  return XR_SUCCESS;
}
FN(EnumerateViewConfigurationViews, XrInstance, XrSystemId,
   XrViewConfigurationType, uint32_t cap, uint32_t *n,
   XrViewConfigurationView *p) {
  *n = 2;
  if (!cap)
    return XR_SUCCESS;
  if (cap < 2)
    return XR_ERROR_SIZE_INSUFFICIENT;
  for (int i = 0; i < 2; ++i) {
    p[i].recommendedImageRectWidth = p[i].recommendedImageRectHeight = (mirror_mode().empty()&&expression_mode().empty())&&cage_mode().empty()&&editable_avatar_mode().empty()?320:1024;
    p[i].maxImageRectWidth = p[i].maxImageRectHeight = 1024;
    p[i].recommendedSwapchainSampleCount = p[i].maxSwapchainSampleCount = 1;
  }
  return XR_SUCCESS;
}
FN(EnumerateSwapchainFormats, XrSession, uint32_t cap, uint32_t *n,
   int64_t *p) {
  *n = 1;
  if (cap)
    p[0] = getenv("DOME_XR_FIXTURE_SRGB") ? GL_SRGB8_ALPHA8 : GL_RGBA8;
  return XR_SUCCESS;
}
FN(CreateSwapchain, XrSession, const XrSwapchainCreateInfo *p,
   XrSwapchain *out) {
  auto s = std::make_unique<Swap>();
  s->width = p->width;
  s->height = p->height;
  s->eye = chains.size();
  s->format = p->format;
  report["swapchain_format"] = p->format;
  if(auto v=glGetString(GL_VENDOR))report["gl_vendor"]=reinterpret_cast<const char*>(v);
  if(auto v=glGetString(GL_RENDERER))report["gl_renderer"]=reinterpret_cast<const char*>(v);
  glGenFramebuffers(1, &s->read_fbo);
  glGenTextures(2, s->texture);
  for (auto id : s->texture) {
    glBindTexture(GL_TEXTURE_2D, id);
    glTexImage2D(GL_TEXTURE_2D, 0, p->format, s->width, s->height, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, nullptr);
  }
  *out = reinterpret_cast<XrSwapchain>(s.get());
  chains.push_back(std::move(s));
  count("swapchains_created");
  return XR_SUCCESS;
}
FN(DestroySwapchain, XrSwapchain p) {
  auto s = reinterpret_cast<Swap *>(p);
  glDeleteTextures(2, s->texture);
  glDeleteFramebuffers(1, &s->read_fbo);
  count("swapchains_destroyed");
  return XR_SUCCESS;
}
FN(EnumerateSwapchainImages, XrSwapchain p, uint32_t cap, uint32_t *n,
   XrSwapchainImageBaseHeader *out) {
  *n = 2;
  if (!cap)
    return XR_SUCCESS;
  if (cap < 2)
    return XR_ERROR_SIZE_INSUFFICIENT;
  auto s = reinterpret_cast<Swap *>(p);
  auto images = reinterpret_cast<XrSwapchainImageOpenGLKHR *>(out);
  for (int i = 0; i < 2; ++i)
    images[i].image = s->texture[i];
  return XR_SUCCESS;
}
FN(AcquireSwapchainImage, XrSwapchain p, const XrSwapchainImageAcquireInfo *,
   uint32_t *index) {
  auto s = reinterpret_cast<Swap *>(p);
  if (s->acquired)
    return XR_ERROR_CALL_ORDER_INVALID;
  s->acquired = true;
  s->waited = false;
  s->index = (s->index + 1) % 2;
  *index = s->index;
  count("acquires");
  return XR_SUCCESS;
}
FN(WaitSwapchainImage, XrSwapchain p, const XrSwapchainImageWaitInfo *) {
  auto s = reinterpret_cast<Swap *>(p);
  if (!s->acquired)
    return XR_ERROR_CALL_ORDER_INVALID;
  s->waited = true;
  count("image_waits");
  return XR_SUCCESS;
}
FN(ReleaseSwapchainImage, XrSwapchain p, const XrSwapchainImageReleaseInfo *) {
  auto s = reinterpret_cast<Swap *>(p);
  if (!s->acquired || !s->waited)
    return XR_ERROR_CALL_ORDER_INVALID;
  s->acquired = false;
  count("releases");
  std::vector<uint8_t> bytes(size_t(s->width) * s->height * 4);
  // Inspect the actual released image, independent of the application's read
  // framebuffer binding. RGBA8 swapchains contain linear premultiplied RGB;
  // SRGB8 swapchains store the corresponding sRGB transfer encoding.
  GLint previous_read = 0;
  glGetIntegerv(GL_READ_FRAMEBUFFER_BINDING, &previous_read);
  glBindFramebuffer(GL_READ_FRAMEBUFFER, s->read_fbo);
  glFramebufferTexture2D(GL_READ_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D,
                         s->texture[s->index], 0);
  if (glCheckFramebufferStatus(GL_READ_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    return XR_ERROR_RUNTIME_FAILURE;
  glReadPixels(0, 0, s->width, s->height, GL_RGBA, GL_UNSIGNED_BYTE,
               bytes.data());
  glBindFramebuffer(GL_READ_FRAMEBUFFER, GLuint(previous_read));
  if (glGetError() != GL_NO_ERROR) return XR_ERROR_RUNTIME_FAILURE;
  auto displayed = [&](uint8_t value) {
    if (s->format == GL_SRGB8_ALPHA8) return int(value);
    float linear = value / 255.f;
    float encoded = linear <= .0031308f ? linear * 12.92f
        : 1.055f * std::pow(linear, 1 / 2.4f) - .055f;
    return int(std::lround(encoded * 255));
  };
  if(pbr_preview_fixture()&&(frame==6||frame==18||frame==34)){
    size_t solid=0;for(size_t at=3;at<bytes.size();at+=4)solid+=bytes[at]>240;
    report["pbr_preview_images"][std::to_string(frame)][std::to_string(s->eye)]={{"opaque",solid}};
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".pbr-"+std::to_string(frame)+"-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!canonical_conversion_mode().empty()&&(frame==34||frame==40)){
    report["canonical_images"][std::to_string(frame)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t v){return v!=0;});
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".canonical-"+std::to_string(frame)+"-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!cage_mode().empty()&&(frame==54||frame==58||frame==64||(bake_recipe_fixture()&&(frame==34||frame==40)))){
    report["cage_images"][std::to_string(frame)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t v){return v!=0;});
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".cage-"+std::to_string(frame)+"-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!expression_mode().empty()&&(frame==43||frame==68||frame==85||frame==114)){
    report["expression_images"][std::to_string(frame)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t v){return v!=0;});
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".expressions-"+std::to_string(frame)+"-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!mirror_mode().empty()&&(frame==36||frame==66||frame==110)){
    report["mirror_images"][std::to_string(frame)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t v){return v!=0;});
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".mirror-"+std::to_string(frame)+"-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!import_atlas_mode().empty()&&(frame==54||frame==78||frame==110)){
    report["import_atlas_images"][std::to_string(frame)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t value){return value!=0;});
    if(s->eye==0)if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".import-atlas-"+std::to_string(frame)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!editable_avatar_mode().empty()&&(frame==13||frame==27)){
    report["editable_avatar_images"][std::to_string(frame)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t v){return v!=0;});
    if(const auto *path=getenv("DOME_XR_FIXTURE_REPORT")){std::ofstream capture(std::string(path)+".editable-avatar-"+std::to_string(frame)+"-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));}
  }
  if(getenv("DOME_XR_FIXTURE_FILES") && frame==32){
    report["file_export_images"]["32"][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t value){return value!=0;});
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".file-export-32-"+std::to_string(s->eye)+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(selection_fixture()&&(frame==24||frame==29||frame==40)){
    unsigned red=0,green=0,ghost=0,solid=0;
    for(size_t k=0;k<bytes.size();k+=4){
      if(bytes[k+3]>240)++solid;
      if(bytes[k+3]>240&&bytes[k]>150&&bytes[k+1]<100)++red;
      if(bytes[k+3]>240&&bytes[k+1]>150&&bytes[k]<100)++green;
      if(bytes[k+3]>20&&bytes[k+3]<80)++ghost;
    }
    report["selection_images"][std::to_string(frame)][std::to_string(s->eye)]={{"red_solid",red},{"green_solid",green},{"ghost",ghost},{"opaque",solid}};
    if(s->eye==0)if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
      std::ofstream capture(std::string(path)+".selection-"+std::to_string(frame)+".ppm",std::ios::binary);
      capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!field_mode().empty()){
    // Public palette geometry/colors from palette.cpp: the 640px panel spans
    // .6m at z=-.66, ROOT title is at (320,345); radial cells have radius220,
    // 110x40 extents. Save6 is centered(100,320), Redo5(129,210).
    // Inspect displayed sRGB, including the renderer's real linear conversion.
    // This observes released GL images, never Document state or a test marker.
    {
      // Each actual eye has its own projection, observations and consecutive
      // acknowledgments. A left-eye glyph cannot authorize the right eye.
      const double eye=s->eye?.032:-.032;
      auto&field_root_signature=field_root_signatures[s->eye];
      auto&root_visible=field_root_visible[s->eye];auto&menu_closed=field_menu_closed[s->eye];auto&page_visible=blur_page_visible[s->eye];
      auto point=[&](double px,double py){const double wx=(px/640-.5)*.6,wy=1.56+(.5-py/640)*.6;return std::pair{int(std::lround(s->width*.5*(1+(wx-eye)/(.66*std::tan(.6))))),int(std::lround(s->height*.5*(1+(wy-1.6)/(.66*std::tan(.6)))))};};
      auto pixels=[&](double left,double top,double right,double bottom,auto inspect){
        const auto a=point(left,top),b=point(right,bottom);
        for(int y=std::max(0,std::min(a.second,b.second));y<=std::min(int(s->height)-1,std::max(a.second,b.second));++y)
          for(int x=std::max(0,std::min(a.first,b.first));x<=std::min(int(s->width)-1,std::max(a.first,b.first));++x){const auto at=(size_t(y)*s->width+x)*4;inspect(displayed(bytes[at]),displayed(bytes[at+1]),displayed(bytes[at+2]));}
      };
      std::vector<uint8_t> signature;
      pixels(245,334,395,358,[&](int r,int g,int b){signature.push_back(r>180&&g>180&&b>180);});
      const auto lit=std::count(signature.begin(),signature.end(),uint8_t(1));
      if(field_step==9){
        const auto root_shape=visual_match("Dome Sculpt",s->eye,s->width,s->height,bytes);report["blur_root_font_shape"][std::to_string(s->eye)]=root_shape.json();
        // Keep the inherited ROOT foreground condition, additionally requiring
        // the literal source bitmap at the actual eye projection before use.
        if(lit>=12&&root_shape.matching){field_root_signature=signature;report["field_root_signature_pixels"][std::to_string(s->eye)]=lit;}
      }
      const bool same=!field_root_signature.empty()&&signature==field_root_signature;
      // Four empty panel margins distinguish an absent palette from a changed
      // title or page. Dark bg=(31,37,45), fg=(231,235,241), disabled fg is their
      // integer midpoint. The separated bands allow framebuffer quantization.
      int background=0,background_total=0,accent=0,accent_total=0,redo_bright=0,redo_dim=0,undo_bright=0;
      // The root's selection toolbar occupies y12..64; sample below it.
      for(const auto &corner:std::array<std::array<int,2>,4>{{{16,100},{600,100},{16,500},{600,500}}})
        pixels(corner[0],corner[1],corner[0]+24,corner[1]+24,[&](int r,int g,int b){++background_total;background+=r>=25&&r<=40&&g>=30&&g<=45&&b>=38&&b<=55;});
      // Left interior of Save's cell excludes its centered text and border.
      pixels(56,307,70,333,[&](int r,int g,int b){++accent_total;accent+=r<150&&g>130&&b>220;});
      pixels(100,195,160,225,[&](int r,int g,int b){redo_bright+=r>180&&g>180&&b>180;redo_dim+=r>=112&&r<=170&&g>=116&&g<=175&&b>=120&&b<=185;});
      pixels(180,115,240,155,[&](int r,int g,int b){undo_bright+=r>180&&g>180&&b>180;});
      const bool panel=background_total&&background*4>=background_total*3;
      field_root_eye_open[s->eye]=same&&panel;field_root_open=field_root_eye_open[0]&&field_root_eye_open[1];
      const bool selected=accent_total&&accent*4>=accent_total*3;
      const bool redo_enabled=redo_bright>=4;
      const bool redo_disabled=redo_bright==0&&redo_dim>=4;
      const bool closed=!same&&background_total&&background*4<background_total;
      auto &ui=report["field_ui"][std::to_string(field_step)][std::to_string(s->eye)];
      if(!ui.contains("first_physical_frame"))ui["first_physical_frame"]=physical_frame;
      ui["last_physical_frame"]=physical_frame;ui["root_title"]=same;ui["panel_present"]=panel;
      ui["save_selected"]=selected;ui["redo_enabled"]=redo_enabled;ui["redo_disabled"]=redo_disabled;ui["menu_absent"]=closed;
      ui["background_pixels"]=background;ui["background_samples"]=background_total;ui["save_accent_pixels"]=accent;ui["save_samples"]=accent_total;ui["redo_bright_pixels"]=redo_bright;ui["redo_dim_pixels"]=redo_dim;
      if(blur_page_gate()){
        // Source palette cells have radius220 and110x40 dimensions. The Erase
        // checkbox is x-51,y-4 (8x8), with a4x4 selected fill at offset2.
        const int sector=field_step==31?9:field_step==43?11:field_step==55?1:10;
        const float a=sector*3.14159265358979323846f/6;
        const int x=int(320+220*std::cos(a)),y=int(320-220*std::sin(a));
        int selected_pixels=0,selected_samples=0,label_bright=0,erase_fill=0,erase_mark=0;
        pixels(x-48,y-12,x-39,y+12,[&](int r,int g,int b){++selected_samples;selected_pixels+=r<150&&g>130&&b>220;});
        pixels(x-36,y-15,x+49,y+15,[&](int r,int g,int b){label_bright+=r>180&&g>180&&b>180;});
        const float erase_angle=10*3.14159265358979323846f/6;
        const int ex=int(320+220*std::cos(erase_angle)),ey=int(320-220*std::sin(erase_angle));
        pixels(ex-48,ey-1,ex-47,ey,[&](int r,int g,int b){erase_fill+=r>180&&g>180&&b>180;});
        pixels(ex-52,ey-5,ex-43,ey+4,[&](int r,int g,int b){erase_mark+=r>180&&g>180&&b>180;});
        const char*title=field_step==31?"Dome Sculpt":field_step==49?"Brush controls":field_step==55?"Paint filters / controls":"Painting";
        const auto title_shape=visual_match(title,s->eye,s->width,s->height,bytes);
        const size_t checkbox_difference=visual_checkbox_difference(s->eye,s->width,s->height);
        blur_visual_reference::Match checkbox_shape;bool checkbox=true;
        if(field_step==21||field_step==43||field_step==49){
          const bool absent=field_step==49;const char*mask=absent?"checkbox-absent":field_step==43?"checkbox-checked":"checkbox-unchecked";
          checkbox_shape=visual_match(mask,s->eye,s->width,s->height,bytes,field_step==43?blur_visual_reference::Background::Cell:blur_visual_reference::Background::Accent,absent);
          checkbox=checkbox_shape.matching&&checkbox_difference>0;
          if(field_step==21)checkbox=checkbox&&erase_fill==0&&erase_mark>=4;
          if(absent)checkbox=checkbox&&erase_mark==0;
        }
        const bool ready=panel&&title_shape.matching&&selected_samples&&selected_pixels*4>=selected_samples*3&&label_bright>=6&&checkbox&&(field_step!=31||same);
        auto&detail=report["blur_page_ui"][std::to_string(field_step)][std::to_string(s->eye)];detail={{"page",field_step==31?0:field_step==49?6:field_step==55?32:3},{"sector",sector},{"panel_present",panel},{"title_pixels",lit},{"label_bright_pixels",label_bright},{"selected_pixels",selected_pixels},{"selected_samples",selected_samples},{"erase_checkbox_fill_pixels",erase_fill},{"erase_checkbox_mark_pixels",erase_mark},{"checkbox_state_valid",checkbox},{"ready",ready}};
        detail["title_reference"]=title;detail["title_shape"]=title_shape.json();detail["checkbox_shape"]=checkbox_shape.json();detail["checkbox_distinguishing_pixels"]=checkbox_difference;
        if(ready){auto[it,first]=page_visible.try_emplace(field_step,physical_frame,physical_frame);it->second.second=physical_frame;detail["first"]=it->second.first;detail["last"]=physical_frame;}
        else page_visible.erase(field_step);
      }
      if(field_root_gate()){
        report["field_root_title_match"][std::to_string(field_step)][std::to_string(s->eye)]=same;
        // Undo77 must expose a real available Redo; accepted61 and redone91
        // must expose it disabled. A stale ROOT title alone cannot pass.
        const bool history_ready=field_step==77?(redo_enabled&&undo_bright==0):(redo_disabled&&undo_bright>=4);
        const bool ready=field_root_eye_open[s->eye]&&selected&&history_ready;
        ui["undo_bright_pixels"]=undo_bright;ui["expected_redo_enabled"]=field_step==77;ui["valid_root_acknowledgment"]=ready;
        if(ready){auto[it,first]=root_visible.try_emplace(field_step,physical_frame,physical_frame);it->second.second=physical_frame;report["field_root_visible"][std::to_string(field_step)][std::to_string(s->eye)]={{"first",it->second.first},{"last",physical_frame},{"title_pixels",lit},{"save_selected",selected},{"redo_enabled",redo_enabled},{"redo_disabled",redo_disabled}};}
        else root_visible.erase(field_step);
      }
      if(field_close_gate()){
        if(closed){auto[it,first]=menu_closed.try_emplace(field_step,physical_frame,physical_frame);it->second.second=physical_frame;report["field_menu_closed"][std::to_string(field_step)][std::to_string(s->eye)]={{"first",it->second.first},{"last",physical_frame},{"root_title",same},{"panel_present",panel}};}
        else menu_closed.erase(field_step);
      }
    }
    report["field_images"][std::to_string(field_step)][std::to_string(s->eye)]=std::count_if(bytes.begin(),bytes.end(),[](uint8_t v){return v!=0;});
    const bool save_attempt=field_history()&&(field_step==64||field_step==78||field_step==92);
    const bool capture=field_step==9||blur_page_gate()||field_step==59||field_step==61||field_step==65||field_step==68||field_step==96||save_attempt;
    const bool root_capture=field_root_gate()&&field_root_visible[s->eye].contains(field_step)&&field_root_visible[s->eye].at(field_step).second==physical_frame;
    const bool closed_capture=field_close_gate()&&field_menu_closed[s->eye].contains(field_step)&&field_menu_closed[s->eye].at(field_step).second==physical_frame;
    const bool waiting_capture=(field_step==9||blur_page_gate()||field_root_gate()||field_close_gate()||(field_history()&&(field_step==67||field_step==81||field_step==95)))&&physical_frame%300==0;
    const auto key=std::to_string(field_step)+(waiting_capture?"-wait-"+std::to_string(physical_frame)+"-":root_capture?"-root-":closed_capture?"-closed-":"-")+std::to_string(s->eye);
    auto save_image=[&](const std::string&name){
      if(report["field_captures"].contains(name))return;
      if(const auto*path=getenv("DOME_XR_FIXTURE_REPORT")){
        const auto target=std::string(path)+".field-"+name+".ppm";std::ofstream image(target,std::ios::binary);image<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
        for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)image.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
        std::ofstream raw(target+".rgba",std::ios::binary);raw.write(reinterpret_cast<const char*>(bytes.data()),std::streamsize(bytes.size()));
        report["field_captures"][name]=target;report["field_capture_layout"][name]={{"width",s->width},{"height",s->height},{"raw",target+".rgba"},{"row_order","bottom_to_top"},{"encoding","linearRGBA8;xr.cpp palette linearOutput=true"}};
      }
    };
    if(capture||root_capture||closed_capture||waiting_capture)save_image(key);
    if(blur_page_gate()){
      const auto&ui=report["blur_page_ui"][std::to_string(field_step)][std::to_string(s->eye)];
      // Diagnostic evidence ignores the title predicate, never the gate. Both
      // first frames and actual highlighted/checkbox frames survive failures.
      if(ui.value("panel_present",false)&&ui.value("checkbox_state_valid",false)&&ui.value("label_bright_pixels",0)>=6&&ui.value("selected_pixels",0)*4>=ui.value("selected_samples",1)*3)
        save_image(std::to_string(field_step)+"-page-evidence-"+std::to_string(s->eye));
      if(blur_page_visible[s->eye].contains(field_step))save_image(std::to_string(field_step)+"-page-ready-"+std::to_string(s->eye));
    }
  }
  int opaque = 0, blue = 0;
  for (size_t i = 0; i < bytes.size(); i += 4) {
    if (bytes[i + 3] > 0)
      ++opaque;
    if (displayed(bytes[i]) < 150 && displayed(bytes[i + 1]) > 130 && displayed(bytes[i + 2]) > 220)
      ++blue;
  }
  if (opaque > 100)
    count(s->eye ? "right_eye_nonblank" : "left_eye_nonblank");
  if (blue > 30) {
    count("palette_images");
    if(!editable_avatar_mode().empty()){
      if(frame==18||frame==19)report["editable_avatar_save_menu_seen"]=true;
      if(frame==22||frame==23)report["editable_avatar_cancel_root_seen"]=true;
      if(frame==27)report["editable_avatar_cancel_menu_seen"]=true;
    }
  }
  if((!mask_mode().empty() && s->eye==0 && mask_step==35) || (!resolution_mode().empty() && s->eye==0 && frame==19)) {
    if(auto path=getenv("DOME_XR_FIXTURE_REPORT")) {
      std::ofstream capture(std::string(path)+(!resolution_mode().empty()?".resolution-"+std::to_string(frame):".mask-"+std::to_string(mask_step))+".ppm",std::ios::binary);
      capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)
        capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(!polygon_mode().empty()&&(polygon_stage()==15||polygon_stage()==19||polygon_stage()==25||polygon_stage()==27)){
    const int sector=(polygon_stage()==25||polygon_stage()==27)?(polygon_mode()=="focus"?4:polygon_mode()=="noop"?10:7):0;
    const float a=sector*6.28318530718f/12;
    const float wx=.6f*220.f/640*std::cos(a),wy=1.56f+.6f/640*(220.f*std::sin(a)+16.f);
    const float eye=(s->eye?.032f:-.032f);
    const int cx=int(std::lround(s->width*.5f*(1+(wx-eye)/(.66f*std::tan(.6f)))));
    const int cy=int(std::lround(s->height*.5f*(1+(wy-1.6f)/(.66f*std::tan(.6f)))));
    int accent=0,total=0;
    for(int y=std::max(0,cy-1);y<=std::min(int(s->height)-1,cy+1);++y)for(int x=std::max(0,cx-8);x<=std::min(int(s->width)-1,cx+8);++x){
      size_t at=(size_t(y)*s->width+x)*4;++total;if(displayed(bytes[at])<150&&displayed(bytes[at+1])>130&&displayed(bytes[at+2])>220)++accent;
    }
    auto key=polygon_stage()==15?"polygon_initial_ready":polygon_stage()==19?"polygon_source_ready":polygon_stage()==25?"polygon_selection_ready":"polygon_edit_ready";
    report[std::string(key)+"_accent"]=std::max(report.value(std::string(key)+"_accent",0),accent);
    if(polygon_mode()=="focus"&&polygon_stage()==27){
      if(s->eye==0&&total&&accent==0){polygon_motion_before=bytes;polygon_motion_base_ready=true;report["polygon_motion_base_ready"]=true;}
    }else if(total&&accent*2>total){
      bool &ready=polygon_stage()==15?polygon_initial_ready:polygon_stage()==19?polygon_source_ready:polygon_stage()==25?polygon_selection_ready:polygon_edit_ready;
      if(!ready&&s->eye==0)if(auto path=getenv("DOME_XR_FIXTURE_REPORT")){
        std::ofstream capture(std::string(path)+"."+key+".ppm",std::ios::binary);capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
        for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
      }
      ready=true;report[key]=true;
    }
  }
  if(polygon_color() && polygon_stage()==19 && s->eye==0 && report.value("polygon_gate_wait_frames",0)>30) {
    static bool captured=false;
    if(!captured)if(auto path=getenv("DOME_XR_FIXTURE_REPORT")) {
      captured=true;std::ofstream capture(std::string(path)+".color-source-gate.ppm",std::ios::binary);
      capture<<"P6\n"<<s->width<<' '<<s->height<<"\n255\n";
      for(int y=int(s->height)-1;y>=0;--y)for(unsigned x=0;x<s->width;++x)for(int c=0;c<3;++c)
        capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+c])));
    }
  }
  if(polygon_mode()=="focus"&&polygon_stage()==29&&s->eye==0&&!polygon_motion_before.empty()){
    // Count only real surface coverage/shading, excluding grip/aim/ring and
    // selection colors so a changing cursor cannot acknowledge geometry.
    auto body=[&](const auto &image,size_t i){int r=displayed(image[i]),g=displayed(image[i+1]),b=displayed(image[i+2]);return image[i+3]>250&&b<220&&b>g+3&&g>r+3;};
    size_t changed=0;for(size_t i=0;i<bytes.size();i+=4){bool a=body(bytes,i),b=body(polygon_motion_before,i);
      if((a||b)&&(a||bytes[i+3]<5)&&(b||polygon_motion_before[i+3]<5)&&
        std::abs(int(bytes[i])-polygon_motion_before[i])+std::abs(int(bytes[i+1])-polygon_motion_before[i+1])+std::abs(int(bytes[i+2])-polygon_motion_before[i+2])>12)++changed;
    }
    report["polygon_motion_changed_pixels"]=std::max(report.value("polygon_motion_changed_pixels",size_t(0)),changed);
    if(changed>100){polygon_motion_visible=true;report["polygon_motion_visible"]=true;}
  }
  const bool cut_wait=!cut_mode().empty() && (cut_stage()==20 || (cut_mode()=="accept" && cut_stage()==30));
  const bool mask_gate=!mask_mode().empty() && (mask_step==68 || mask_step==79);
  if (cut_wait || mask_gate || (!retopo_mode().empty() && (retopo_step == 27 || retopo_step == 60))) {
    const bool initial=cut_wait?cut_stage()==20:retopo_step==27;
    const int sector = cut_wait?7:mask_gate || initial?0:10;
    float angle = sector * 6.28318530718f / 12;
    float world_x = (cut_wait?.045f:0.f) + .6f * 220.f / 640 * std::cos(angle);
    float world_y = 1.56f + .6f / 640 * (220.f * std::sin(angle) + (mask_gate ? 16.f : 0.f));
    float eye_x = (s->eye ? .032f : -.032f) + (frame >= 38 ? -.2f : 0);
    int cx = int(std::lround(s->width * .5f * (1 + (world_x - eye_x) / (((mask_gate||cut_wait)?.66f:1.01f) * std::tan(.6f)))));
    int cy = int(std::lround(s->height * .5f * (1 + (world_y - 1.6f) / (((mask_gate||cut_wait)?.66f:1.01f) * std::tan(.6f)))));
    int accent = 0, transparent=0, inspected = 0;
    const int half_height=mask_gate?1:3; // Sample the mask cell background above its text.
    for (int y = std::max(0,cy-half_height); y <= std::min(int(s->height)-1,cy+half_height); ++y)
      for (int x = std::max(0,cx-8); x <= std::min(int(s->width)-1,cx+8); ++x) {
        size_t at = (size_t(y) * s->width + x) * 4;
        ++inspected;
        transparent+=bytes[at+3]<5;
        if (displayed(bytes[at]) < 150 && displayed(bytes[at+1]) > 130 && displayed(bytes[at+2]) > 220) ++accent;
      }
    const char *pixels_key = cut_wait?(initial?"cut_preview_accent_pixels":"cut_apply_accent_pixels"):mask_gate ? "mask_work_accent_pixels" : retopo_step == 27 ? "retopo_source_accent_pixels" : "retopo_apply_accent_pixels";
    report[pixels_key] = std::max(report.value(pixels_key,0),accent);
    if(mask_gate && mask_step==68 && inspected && transparent*2>inspected) {
      mask_work_completed=true;report["mask_work_completed"]=true;
    }
    if ((!mask_gate || mask_step==79) && inspected && accent * 2 > inspected) {
      bool first = cut_wait?(initial?!cut_preview_ready:!cut_apply_ready):mask_gate ? !mask_work_ready : retopo_step == 27 ? !retopo_source_ready : !retopo_apply_ready;
      if (first) if (auto path = getenv("DOME_XR_FIXTURE_REPORT")) {
        std::ofstream capture(std::string(path) + (cut_wait?(initial?".cut-preview-ready.ppm":".cut-apply-ready.ppm"):mask_gate ? ".work-ready.ppm" : retopo_step == 27 ? ".source-ready.ppm" : ".apply-ready.ppm"), std::ios::binary);
        capture << "P6\n" << s->width << ' ' << s->height << "\n255\n";
        for (int y = int(s->height)-1; y >= 0; --y) for (unsigned x = 0; x < s->width; ++x)
          for (int channel = 0; channel < 3; ++channel)
            capture.put(char(displayed(bytes[(size_t(y)*s->width+x)*4+channel])));
      }
      if(cut_wait){
        if(initial){cut_preview_ready=true;report["cut_preview_ready"]=true;}
        else{cut_apply_ready=true;report["cut_apply_ready"]=true;}
      }else if (mask_gate) { mask_work_ready=true;report["mask_work_ready"]=true; }
      else if (retopo_step == 27) { retopo_source_ready = true; report["retopo_source_ready"] = true; }
      else { retopo_apply_ready = true; report["retopo_apply_ready"] = true; }
    }
  }
  return XR_SUCCESS;
}
FN(BeginSession, XrSession, const XrSessionBeginInfo *) {
  count("sessions_begun");
  return XR_SUCCESS;
}
FN(EndSession, XrSession) {
  count("sessions_ended");
  return XR_SUCCESS;
}
FN(RequestExitSession, XrSession) { return XR_SUCCESS; }
FN(PollEvent, XrInstance, XrEventDataBuffer *out) {
  if (event < 2) {
    auto e = reinterpret_cast<XrEventDataSessionStateChanged *>(out);
    e->type = XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    e->state = event++ == 0 ? XR_SESSION_STATE_READY : XR_SESSION_STATE_FOCUSED;
    return XR_SUCCESS;
  }
  if (event == 2) {
    ++event;
    auto e = reinterpret_cast<XrEventDataInteractionProfileChanged *>(out);
    e->type = XR_TYPE_EVENT_DATA_INTERACTION_PROFILE_CHANGED;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    return XR_SUCCESS;
  }
  if ((!editable_avatar_mode().empty() || menu_gate()) && frame >= 45 && menu_completion_event < 2) {
    auto e = reinterpret_cast<XrEventDataSessionStateChanged *>(out);
    e->type = XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    e->state = menu_completion_event++ == 0 ? XR_SESSION_STATE_STOPPING : XR_SESSION_STATE_EXITING;
    return XR_SUCCESS;
  }
  if(!polygon_mode().empty()&&polygon_stage()>=36&&menu_completion_event<2){
    auto e=reinterpret_cast<XrEventDataSessionStateChanged*>(out);e->type=XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;
    e->session=reinterpret_cast<XrSession>(&session_tag);e->state=menu_completion_event++==0?XR_SESSION_STATE_STOPPING:XR_SESSION_STATE_EXITING;return XR_SUCCESS;
  }
  if (getenv("DOME_XR_FIXTURE_RESTART") && frame >= 23 && restart_phase < 8) {
    static constexpr XrSessionState states[] = {
        XR_SESSION_STATE_VISIBLE,  XR_SESSION_STATE_SYNCHRONIZED,
        XR_SESSION_STATE_STOPPING, XR_SESSION_STATE_IDLE,
        XR_SESSION_STATE_READY,    XR_SESSION_STATE_SYNCHRONIZED,
        XR_SESSION_STATE_VISIBLE,  XR_SESSION_STATE_FOCUSED};
    if (restart_phase == 3 && report.value("sessions_ended", 0) != 1)
      return XR_ERROR_RUNTIME_FAILURE;
    auto e = reinterpret_cast<XrEventDataSessionStateChanged *>(out);
    e->type = XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    e->state = states[restart_phase++];
    count("restart_states");
    return XR_SUCCESS;
  }
  if(!field_mode().empty()&&field_step>=102&&menu_completion_event<2){
    auto*e=reinterpret_cast<XrEventDataSessionStateChanged*>(out);e->type=XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;e->session=reinterpret_cast<XrSession>(&session_tag);e->state=menu_completion_event++==0?XR_SESSION_STATE_STOPPING:XR_SESSION_STATE_EXITING;return XR_SUCCESS;
  }
  if(field_mode()=="reference"&&field_step>=34&&!reference_event){
    reference_event=true;auto*e=reinterpret_cast<XrEventDataReferenceSpaceChangePending*>(out);e->type=XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING;e->session=reinterpret_cast<XrSession>(&session_tag);e->referenceSpaceType=XR_REFERENCE_SPACE_TYPE_STAGE;e->changeTime=1000000000+(physical_frame+1)*18000000;e->poseValid=XR_TRUE;e->poseInPreviousSpace={{0,0,0,1},{0,0,0}};count("reference_changes");return XR_SUCCESS;
  }
  auto retopo = retopo_mode();
  unsigned focus_frame = !polygon_mode().empty()?polygon_stage():!cut_mode().empty()?cut_step:!mask_mode().empty() ? mask_step : retopo.empty() ? frame : retopo_step;
  unsigned focus_at = retopo_history()?7:!cut_mode().empty()?90:!mask_mode().empty() ? (mask_mode()=="focus"?40:90) : retopo.empty() ? 30 : retopo == "focus" ? 40 : 90;
  if(!field_mode().empty()){focus_frame=field_step;focus_at=field_mode()=="focus"?34:1000000;}
  if(!bake_policy_mode().empty())focus_at=bake_policy_mode()=="focus"?(bake_projection_mode()?28:20):90;
  if(!procedural_mode().empty())focus_at=procedural_mode()=="focus"?20:90;
  if(!polygon_mode().empty())focus_at=polygon_mode()=="focus"?30:90;
  if(!resolution_mode().empty())focus_at=resolution_mode()=="focus"?20:90;
  if(!corner_uv_mode().empty()){focus_frame=frame;focus_at=corner_uv_mode()=="focus"?24:90;}
  if(selection_fixture()||pbr_preview_fixture())focus_at=90;
  if(!expression_mode().empty())focus_at=expression_mode()=="focus"?88:1000;
  if(!cage_mode().empty())focus_at=cage_mode()=="focus"?60:1000;
  if(!canonical_conversion_mode().empty())focus_at=canonical_conversion_mode()=="focus"?36:1000;
  if(!mirror_mode().empty())focus_at=mirror_mode()=="focus"?70:1000;
  if(!import_atlas_mode().empty())focus_at=1000;
  if(!rig_fit_mode().empty())focus_at=rig_fit_mode()=="focus"?47:1000;
  if(getenv("DOME_XR_FIXTURE_FILES"))focus_at=90;
  if(!editable_avatar_mode().empty())focus_at=1000;
  if(!projection_mode().empty())focus_at=projection_mode()=="focus"?78:1000;
  if(!affine_contact_mode().empty())focus_at=affine_contact_mode()=="focus"?12:90;
  if (focus_frame >= focus_at && !lost) {
    lost = true;
    auto e = reinterpret_cast<XrEventDataSessionStateChanged *>(out);
    e->type = XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    e->state = XR_SESSION_STATE_VISIBLE;
    count("focus_losses");
    return XR_SUCCESS;
  }
  if (focus_frame >= focus_at + 3 && !regained) {
    regained = true;
    auto e = reinterpret_cast<XrEventDataSessionStateChanged *>(out);
    e->type = XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    e->state = XR_SESSION_STATE_FOCUSED;
    count("focus_regains");
    return XR_SUCCESS;
  }
  if(retopo_history()&&frame>=12&&!reference_event){
    reference_event=true;auto e=reinterpret_cast<XrEventDataReferenceSpaceChangePending*>(out);
    e->type=XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING;e->session=reinterpret_cast<XrSession>(&session_tag);
    e->referenceSpaceType=XR_REFERENCE_SPACE_TYPE_STAGE;e->changeTime=1000000000+(physical_frame+1)*18000000;
    e->poseValid=XR_TRUE;e->poseInPreviousSpace={{0,0,0,1},{0,0,0}};count("reference_changes");return XR_SUCCESS;
  }
  if (field_mode().empty() && editable_avatar_mode().empty() && (cage_mode().empty()&&(mirror_mode().empty()&&expression_mode().empty())&&import_atlas_mode().empty()&&projection_mode().empty()&&rig_fit_mode().empty()) && !pbr_preview_fixture() && !selection_fixture() && (polygon_mode().empty()&&corner_uv_mode().empty()) && bake_policy_mode().empty() && procedural_mode().empty() && resolution_mode().empty() && retopo.empty() && mask_mode().empty() && cut_mode().empty() && frame >= 35 && !reference_event) {
    reference_event = true;
    auto e = reinterpret_cast<XrEventDataReferenceSpaceChangePending *>(out);
    e->type = XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING;
    e->session = reinterpret_cast<XrSession>(&session_tag);
    e->referenceSpaceType = XR_REFERENCE_SPACE_TYPE_STAGE;
    e->changeTime = 1000000000 + (physical_frame + 3) * 18000000;
    e->poseValid = XR_TRUE;
    e->poseInPreviousSpace = {{0, 0, 0, 1}, {.2f, 0, 0}};
    count("reference_changes");
    return XR_SUCCESS;
  }
  return XR_EVENT_UNAVAILABLE;
}
FN(WaitFrame, XrSession, const XrFrameWaitInfo *, XrFrameState *p) {
  std::this_thread::sleep_for(std::chrono::milliseconds(18));
  ++physical_frame;
  if(!field_mode().empty()){
    const bool waiting=field_wait();if(!waiting)++field_step;else count("field_gate_wait_frames");
    report["field_step"]=field_step;report["field_mode"]=field_mode();report["field_target"]=field_target();
    if(physical_frame==10)if(const auto*p=getenv("DOME_XR_FIXTURE_REPORT")){std::ifstream maps("/proc/self/maps");std::ofstream saved(std::string(p)+".maps");saved<<maps.rdbuf();}
    if(physical_frame>6000){report["field_gate_exhausted"]=true;save();return XR_ERROR_RUNTIME_FAILURE;}
  }

  if(!expression_mode().empty()&&physical_frame==10)if(const auto *path=getenv("DOME_XR_FIXTURE_REPORT")){std::ifstream maps("/proc/self/maps");std::ofstream capture(std::string(path)+".maps");capture<<maps.rdbuf();}
  // Keep delivering released input and real stereo frames until the menu has
  // actually reached a released swapchain. Advancing straight from click8 to
  // click10 can process open+close on the input worker between two snapshots.
  // This is a test-runtime acknowledgement, never an XR application wait.
  const bool avatar_wait=!editable_avatar_mode().empty()&&editable_avatar_mode()!="recover"&&
    ((frame==15&&!editable_avatar_path("entered"))||
     (frame==19&&!report.value("editable_avatar_save_menu_seen",false))||
     (editable_avatar_mode()=="cancel"&&((frame==23&&!report.value("editable_avatar_cancel_root_seen",false))||
      (frame==27&&!report.value("editable_avatar_cancel_menu_seen",false)))));
  if(avatar_wait){count("editable_avatar_wait_frames");if(physical_frame>3000){report["editable_avatar_gate_exhausted"]=true;save();return XR_ERROR_RUNTIME_FAILURE;}}
  if (!avatar_wait && !(menu_gate() && frame == 9 && report.value("palette_images", 0) == 0)) ++frame;
  else if(!avatar_wait) count("menu_gate_wait_frames");
  if(!editable_avatar_mode().empty()){
    report["editable_avatar_script_step"]=frame;
    if(physical_frame==10)if(const auto *path=getenv("DOME_XR_FIXTURE_REPORT")){std::ifstream maps("/proc/self/maps");std::ofstream capture(std::string(path)+".maps");capture<<maps.rdbuf();}
    if(frame>=16&&editable_avatar_mode()!="recover")report["editable_avatar_durable_gate_observed"]=editable_avatar_path("entered");
    if(frame==31){if(const auto *directory=getenv("DOME_TEST_EXPORT_GATE_DIR")){std::ofstream release(std::filesystem::path(directory)/"release");}}
  }
  if (menu_gate()) {
    report["menu_script_step"] = frame;
    if (physical_frame > 1200) {
      report["menu_gate_exhausted"] = true; save();
      return XR_ERROR_RUNTIME_FAILURE;
    }
  }
  if (auto mode=retopo_mode(); !mode.empty()) {
    bool waiting = !retopo_history()&&((retopo_step == 27 && !retopo_source_ready) ||
                   (mode!="unconfirmed" && retopo_step == 60 && !retopo_apply_ready));
    if (!waiting) ++retopo_step;
    report["retopo_script_step"] = retopo_step;
  }
  if(auto mode=cut_mode();!mode.empty()){
    bool waiting=(cut_stage()==20&&!cut_preview_ready)||(mode=="accept"&&cut_stage()==30&&!cut_apply_ready);
    if(!waiting)++cut_step;
    report["cut_script_step"]=cut_stage();report["cut_raw_step"]=cut_step;report["cut_held_prefix"]=cut_held();
  }
  if(auto mode=mask_mode();!mode.empty()) {
    // A completed radial action disarms its input lease. The first released
    // sample rearms; a second released sample selects the next sector.
    if(mask_step==17 && !mask_released) mask_released=true;
    else if(!((mode=="fill" || mode=="undo") && ((mask_step==68 && !mask_work_completed) || (mask_step==79 && !mask_work_ready)))) ++mask_step;
    report["mask_script_step"]=mask_step;
  }
  if(auto mode=polygon_mode();!mode.empty()){
    const bool restore=mode.starts_with("restore");
    const bool waiting=(polygon_stage()==15&&!polygon_initial_ready)||(!restore&&polygon_stage()==19&&!polygon_source_ready)||(!restore&&polygon_stage()==25&&!polygon_selection_ready)||
      (mode=="focus"&&((polygon_stage()==27&&!polygon_motion_base_ready)||(polygon_stage()==29&&!polygon_motion_visible)))||
      ((mode=="accept"||mode=="cancel"||mode=="unconfirmed")&&polygon_stage()==27&&!polygon_edit_ready);
    if(!waiting)++polygon_step;else count("polygon_gate_wait_frames");
    report["polygon_script_step"]=polygon_stage();
    if(physical_frame>1200){report["polygon_gate_exhausted"]=true;save();return XR_ERROR_RUNTIME_FAILURE;}
  }
  p->predictedDisplayTime = 1000000000 + physical_frame * 18000000;
  p->predictedDisplayPeriod = 18000000;
  p->shouldRender = frame % 7 ? XR_TRUE : XR_FALSE;
  count("frames_waited");
  return XR_SUCCESS;
}
FN(BeginFrame, XrSession, const XrFrameBeginInfo *) {
  count("frames_begun");
  return XR_SUCCESS;
}
FN(EndFrame, XrSession, const XrFrameEndInfo *p) {
  count("frames_ended");
  if (p->layerCount) {
    if (p->layerCount != 1 ||
        p->layers[0]->type != XR_TYPE_COMPOSITION_LAYER_PROJECTION)
      return XR_ERROR_LAYER_INVALID;
    auto layer =
        reinterpret_cast<const XrCompositionLayerProjection *>(p->layers[0]);
    if (layer->viewCount != 2)
      return XR_ERROR_LAYER_INVALID;
    for (int eye = 0; eye < 2; ++eye) {
      auto &v = layer->views[eye];
      auto *swap = reinterpret_cast<Swap *>(v.subImage.swapchain);
      auto known = std::find_if(chains.begin(), chains.end(),
                                [swap](const auto &chain) { return chain.get() == swap; });
      if (known == chains.end() || swap->eye != eye ||
          v.subImage.imageRect.offset.x != 0 || v.subImage.imageRect.offset.y != 0 ||
          v.subImage.imageRect.extent.width != int32_t(swap->width) ||
          v.subImage.imageRect.extent.height != int32_t(swap->height) ||
          std::abs(v.pose.position.x - ((eye ? .032f : -.032f) +
                                        (field_mode().empty() && frame >= 38 && (cage_mode().empty()&&(mirror_mode().empty()&&expression_mode().empty())&&import_atlas_mode().empty()&&projection_mode().empty()&&rig_fit_mode().empty()) && (polygon_mode().empty()&&corner_uv_mode().empty()) && !selection_fixture() ? -.2f : 0))) > .0001f)
        return XR_ERROR_POSE_INVALID;
    }
    count("stereo_submissions");
  } else
    count("empty_submissions");
  // Synchronize external interruption with a real in-progress controller
  // stroke; the parent never relies on an arbitrary startup delay.
  if(frame==16) if(auto marker=getenv("DOME_XR_FIXTURE_SIGNAL_READY"))
    std::ofstream(marker)<<frame<<'\n';
  if(menu_gate() && frame==9)save();
  if(!field_mode().empty()||!cut_mode().empty()||!polygon_mode().empty())save(); // Preserve actual progress even if a later stage stalls.
  return XR_SUCCESS;
}
FN(LocateViews, XrSession, const XrViewLocateInfo *, XrViewState *state,
   uint32_t cap, uint32_t *n, XrView *p) {
  *n = 2;
  state->viewStateFlags = field_mode().empty() && frame == 27 && !getenv("DOME_XR_FIXTURE_FILES") && (cage_mode().empty()&&(mirror_mode().empty()&&expression_mode().empty())&&import_atlas_mode().empty()&&projection_mode().empty()&&rig_fit_mode().empty()) && !selection_fixture() && affine_contact_mode().empty() && (polygon_mode().empty()&&corner_uv_mode().empty()) && bake_policy_mode().empty() && procedural_mode().empty() && resolution_mode().empty() && skin_mode()!="focus" && retopo_mode().empty() && mask_mode().empty() && cut_mode().empty() ? 0
                                      : XR_VIEW_STATE_POSITION_VALID_BIT |
                                            XR_VIEW_STATE_ORIENTATION_VALID_BIT;
  if (cap < 2)
    return XR_ERROR_SIZE_INSUFFICIENT;
  for (int i = 0; i < 2; ++i) {
    p[i].pose = {{0, 0, 0, 1},
                 {(i ? .032f : -.032f) + (field_mode().empty() && frame >= 38 && (cage_mode().empty()&&(mirror_mode().empty()&&expression_mode().empty())&&import_atlas_mode().empty()&&projection_mode().empty()&&rig_fit_mode().empty()) && (polygon_mode().empty()&&corner_uv_mode().empty()) && !selection_fixture() ? -.2f : 0), 1.6f, 0}};
    p[i].fov = {-.6f, .6f, .6f, -.6f};
  }
  return XR_SUCCESS;
}
FN(SyncActions, XrSession, const XrActionsSyncInfo *) {
  count("action_syncs");
  return XR_SUCCESS;
}
FN(GetActionStateBoolean, XrSession, const XrActionStateGetInfo *p,
   XrActionStateBoolean *out) {
  auto a = reinterpret_cast<Action *>(p->action);
  bool button = right(p->subactionPath) && a->name == "recenter";
  out->isActive = XR_TRUE;
  if(!field_mode().empty()){
    bool value=button&&field_click();if(right(p->subactionPath)&&a->name=="undo")value=field_history()&&field_step==74;if(right(p->subactionPath)&&a->name=="redo")value=field_history()&&field_step==88;
    static std::map<std::pair<Action*,XrPath>,bool>previous;auto&old=previous[{a,p->subactionPath}];out->currentState=value;out->changedSinceLastSync=value!=old;old=value;
    if(value)report["field_buttons"].push_back({{"step",field_step},{"action",a->name},{"physical_frame",physical_frame}});return XR_SUCCESS;
  }
  if(retopo_history()){
    const bool hand=right(p->subactionPath);bool current=false,previous=false;
    if(hand&&a->name=="undo"){current=history_undo(frame);previous=frame&&history_undo(frame-1);count("history_undo_queries");}
    if(hand&&a->name=="redo"){current=history_redo(frame);previous=frame&&history_redo(frame-1);count("history_redo_queries");}
    if(button){current=frame==42||frame==44||frame==48;previous=frame==43||frame==45||frame==49;}
    out->currentState=current;out->changedSinceLastSync=current!=previous;
    if(hand&&(a->name=="undo"||a->name=="redo")){
      report["history_levels"].push_back({{"frame",frame},{"action",a->name},{"current",current},{"changed",current!=previous}});
      if(current&&!out->changedSinceLastSync)count("history_held_queries");
    }
    return XR_SUCCESS;
  }
  if(!expression_mode().empty()){out->currentState=button&&expression_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(auto mode=editable_avatar_mode();!mode.empty()){
    out->currentState=button&&(mode=="recover"?(frame==8||frame==10):(frame==8||frame==10||frame==14||frame==18||frame==20||(mode=="cancel"&&(frame==22||frame==24||frame==28))));
    out->changedSinceLastSync=button;return XR_SUCCESS;
  }
  if(auto mode=corner_uv_mode();!mode.empty()){
    out->currentState=button&&(frame==8||frame==10||frame==12||frame==14||(mode=="accept"&&frame==28)||(mode!="accept"&&frame==32));
    out->changedSinceLastSync=button;return XR_SUCCESS;
  }
  if(!canonical_conversion_mode().empty()){out->currentState=button&&canonical_conversion_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(!cage_mode().empty()){out->currentState=button&&cage_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(!mirror_mode().empty()){out->currentState=button&&mirror_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(!rig_fit_mode().empty()){out->currentState=button&&rig_fit_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(!projection_mode().empty()){out->currentState=button&&projection_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(!import_atlas_mode().empty()){out->currentState=button&&import_atlas_click();out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(pbr_preview_fixture()){out->currentState=button&&(frame==8||frame==16||frame==22||frame==30);out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(selection_fixture()){out->currentState=button&&(frame==8||frame==12||frame==32);out->changedSinceLastSync=button;return XR_SUCCESS;}
  if(!affine_contact_mode().empty()){out->currentState=XR_FALSE;out->changedSinceLastSync=XR_FALSE;return XR_SUCCESS;}
  out->currentState =
      button &&
      (frame == 8 || frame == 10 ||
       (getenv("DOME_XR_FIXTURE_PAINT") &&
        (frame == 12 || frame == 14 || frame == 16 || frame == 18 || frame == 20)) ||
       (getenv("DOME_XR_FIXTURE_CONTROLS") && (frame == 12 || frame == 21)) ||
       (getenv("DOME_XR_FIXTURE_UV") && frame == 12) ||
       (getenv("DOME_XR_FIXTURE_LAYERS") && (frame == 12 || frame == 14)) ||
       (getenv("DOME_XR_FIXTURE_SCENE") &&
        (frame == 12 || frame == 16 || frame == 18 || frame == 20)) ||
       (getenv("DOME_XR_FIXTURE_FILES") &&
        (frame == 24 || frame == 26 || frame == 28 || frame == 30 || frame == 34)));
  out->changedSinceLastSync = button && ((frame >= 8 && frame <= 11) ||
      (getenv("DOME_XR_FIXTURE_FILES") && frame >= 24 && frame <= 35));
  if (auto mode = voxel_mode(); !mode.empty()) {
    out->currentState = button &&
        (frame == 8 || frame == 10 || frame == 12 || frame == 14 ||
         ((mode == "accept" || mode == "undo") && frame == 18) ||
         (mode == "undo" && (frame == 42 || frame == 44)));
    out->changedSinceLastSync = button;
  }
  if(auto mode=bake_mode();!mode.empty()){
    out->currentState=button && (frame==8||frame==10||frame==12||frame==14||frame==16||((mode=="accept"||mode=="undo")&&(frame==20||frame==24))||(mode=="undo"&&(frame==42||frame==44)));
    out->changedSinceLastSync=button;
  }
  if(auto mode=skin_mode();!mode.empty()) {
    out->currentState=button && (frame==8 || frame==10 || frame==12 || frame==14 || frame==16 || frame==18 || frame==20 ||
      (mode!="focus" && (frame==24 || frame==26)));
    out->changedSinceLastSync=button;
  }
  if (auto mode = retopo_mode(); !mode.empty()) {
    auto step = retopo_step;
    bool common = step==8 || step==10 || step==12 || step==16 || step==18 || step==20 ||
                  step==22 || step==24 || step==26 || step==28;
    bool apply = (mode=="accept" || mode=="focus") && (step==56 || step==58 || step==62);
    out->currentState = button && (common || apply);
    out->changedSinceLastSync = button;
  }
  if(auto mode=cut_mode();!mode.empty()){
    auto step=cut_stage();
    const bool setup=cut_held()&&cut_step<28&&(cut_step==8||cut_step==10||cut_step==12||cut_step==14||cut_step==16||cut_step==19||cut_step==22||cut_step==25);
    out->currentState=button&&(setup||step==8||step==10||step==12||step==14||step==16||step==18||step==22||
                               (mode=="accept"&&(step==26||step==32)));
    out->changedSinceLastSync=button;
  }
  if(auto mode=mask_mode();!mode.empty()) {
    auto step=mask_step;
    bool common=step==8 || step==10 || step==12 || step==14 || step==16 || step==18 || step==22 || step==24 || step==28 || step==30 || step==46 || step==48 || step==50 || step==52 || step==54;
    bool fill=(mode=="fill" || mode=="undo") && (step==66 || step==70 || step==72 || step==74 || step==76 || step==80);
    bool undo=mode=="undo" && (step==84 || step==86);
    out->currentState=button && (common || fill || undo);out->changedSinceLastSync=button;
    if(button)report["mask_buttons"][std::to_string(step)]=bool(out->currentState);
  }
  if(auto mode=bake_policy_mode();!mode.empty()) {
    const auto step=bake_policy_stage();out->currentState=button && (step==8 || step==10 || step==12 || step==14 || step==16 || (mode!="focus" && (!bake_normal_mode()||mode=="accept") && step==24));
    out->changedSinceLastSync=button;
  }
  if(!procedural_mode().empty()) {
    out->currentState=button && (frame==8 || frame==10 || frame==12 || frame==14 || frame==16);
    out->changedSinceLastSync=button;
  }
  if(!resolution_mode().empty()) {
    out->currentState=button && (frame==8 || frame==10 || frame==12 || frame==14);
    out->changedSinceLastSync=button;
  }
  if(auto mode=polygon_mode();!mode.empty()){
    auto step=polygon_stage();const bool restore=mode.starts_with("restore");
    bool press=step==8||step==10||step==12||step==14||step==16;
    if(!restore)press|=step==18||step==20||step==24||step==26||((mode=="accept"||mode=="cancel")&&step==30);
    out->currentState=button&&press;out->changedSinceLastSync=button;
  }
  return XR_SUCCESS;
}
FN(GetActionStateFloat, XrSession, const XrActionStateGetInfo *p,
   XrActionStateFloat *out) {
  auto a = reinterpret_cast<Action *>(p->action);
  bool active = a->name == "paint_pressure" || a->name == "canvas_grab" ||
                (a->name == "tip_force" && ink());
  out->isActive = active;
  out->currentState = 0;
  if(!field_mode().empty()){
    // Blur uses only real joystick Boolean/vector actions; no paint stroke.
    if(out->currentState>0)report["field_pressures"].push_back({{"step",field_step},{"pressure",out->currentState}});return XR_SUCCESS;
  }
  if(retopo_history())return XR_SUCCESS;
  if(!expression_mode().empty())return XR_SUCCESS;
  if(!editable_avatar_mode().empty())return XR_SUCCESS;
  if(!corner_uv_mode().empty()){if(corner_uv_mode()=="cancel"&&right(p->subactionPath)&&a->name=="paint_pressure"&&frame==28)out->currentState=.9f;return XR_SUCCESS;}
  if(!rig_fit_mode().empty()){if(right(p->subactionPath)&&a->name=="paint_pressure"&&frame>=44&&frame<=48)out->currentState=.8f;return XR_SUCCESS;}
  if(!projection_mode().empty()){if(right(p->subactionPath)&&a->name=="paint_pressure"&&frame>=76&&frame<=82)out->currentState=1;return XR_SUCCESS;}
  if(!canonical_conversion_mode().empty()){if(right(p->subactionPath)&&a->name=="paint_pressure"&&frame>=38&&frame<=42)out->currentState=.9f;return XR_SUCCESS;}
  if(!cage_mode().empty()){if(right(p->subactionPath)&&a->name=="paint_pressure"&&(frame==38||frame==56||(frame==62&&cage_mode()=="cancel")))out->currentState=.9f;return XR_SUCCESS;}
  if(!mirror_mode().empty()){if(right(p->subactionPath)&&a->name=="paint_pressure"&&(frame==40||frame==50||frame==60||(frame==78&&mirror_mode()!="focus")))out->currentState=.9f;return XR_SUCCESS;}
  if(!import_atlas_mode().empty())return XR_SUCCESS;
  if(selection_fixture()){if(right(p->subactionPath)){if(a->name=="paint_pressure"&&(frame==18||frame==22||frame==26||frame==36))out->currentState=.9f;if(a->name=="canvas_grab"&&frame>=25&&frame<=27)out->currentState=1;}return XR_SUCCESS;}
  if (right(p->subactionPath)) {
    bool stroke =
        (frame >= 2 && frame <= 5) ||
        (!getenv("DOME_XR_FIXTURE_SCENE") && frame >= 13 && frame <= 18);
    if(pbr_preview_fixture())stroke=frame==12||frame==26;
    if (getenv("DOME_XR_FIXTURE_PAINT"))
      // Frame22 deliberately drops controller tracking in the generic runtime.
      // Paint after the recovered neutral frame so the real release guard stays
      // exercised instead of discarding the only blue pressure sample.
      stroke = (frame >= 2 && frame <= 5) || (frame == 24);
    if (getenv("DOME_XR_FIXTURE_CONTROLS"))
      stroke = frame == 19;
    if (getenv("DOME_XR_FIXTURE_UV"))
      stroke = frame == 14 || frame == 20;
    if (const auto mode=getenv("DOME_XR_FIXTURE_NORMAL_DOMAIN"))
      stroke = frame==15 || frame==18 || (std::string_view(mode)!="focus" && frame==26);
    if (getenv("DOME_XR_FIXTURE_LAYERS"))
      stroke = frame >= 18 && frame <= 20;
    if (getenv("DOME_XR_FIXTURE_RESTART"))
      stroke = (frame >= 2 && frame <= 5) || (frame >= 13 && frame <= 18) ||
               frame == 25;
    if (auto mode = voxel_mode(); !mode.empty())
      stroke = frame == 16 || (mode == "cancel" && frame == 18);
    if(auto mode=bake_mode();!mode.empty())stroke=frame==18||(mode=="cancel"&&frame==20);
    if(!skin_mode().empty())stroke=frame==22;
    if (auto mode = retopo_mode(); !mode.empty()) {
      auto step = retopo_step;
      stroke = mode!="committed" && (step==32 || (mode=="focus" ? (step>=36 && step<=41) || step==48 || step==52
                                                                             : step==36 || step==40));
    }
    if(!cut_mode().empty())stroke=cut_stage()==24;
    if(auto mode=mask_mode();!mode.empty()) {
      auto step=mask_step;stroke=step==20 || step==26 || step==32 || step==56 || step==58 || step==62 || (mode=="focus" && step>=36 && step<=41);
    }
    if(auto mode=resolution_mode();!mode.empty())stroke=(mode!="noop" && frame==18) || ((mode=="accept" || mode=="cancel" || mode=="noop") && frame==22);
    if(auto mode=procedural_mode();!mode.empty())stroke=mode!="accept" && (frame==18 || (mode=="cancel" && frame==22));
    if(auto mode=bake_policy_mode();!mode.empty()){const auto step=bake_policy_stage();stroke=(bake_projection_mode()&&(frame==18||frame==20))||step==18||(mode!="focus"&&step==20);}
    if(auto mode=polygon_mode();!mode.empty()){
      const bool restore=mode.starts_with("restore");
      stroke=restore?((mode!="restore-default"&&polygon_stage()==18)||polygon_stage()==22):
        mode=="noop"?false:polygon_stage()==22||(mode=="focus"&&polygon_stage()>=28&&polygon_stage()<=32);
      if(polygon_color_conversion())stroke=polygon_step==18||polygon_step==22;
    }
    if(!affine_contact_mode().empty())stroke=frame>=8&&frame<=18;
    bool correct =
        a->name == (ink() && frame >= 13 ? "tip_force" : "paint_pressure");
    if (stroke && correct) {
      out->currentState = .9f;
      if (!retopo_mode().empty()) count("retopo_pressure_samples");
      if(!polygon_mode().empty())count("polygon_pressure_samples");
      if (!cut_mode().empty()) count("cut_slider_samples");
      if (!mask_mode().empty()) count("mask_pressure_samples");
      count(a->name == "tip_force" ? "tip_pressure_samples"
                                   : "trigger_pressure_samples");
    }
  }
  return XR_SUCCESS;
}
FN(GetActionStateVector2f, XrSession, const XrActionStateGetInfo *p,
   XrActionStateVector2f *out) {
  auto a = reinterpret_cast<Action *>(p->action);
  out->isActive = XR_TRUE;
  if(!field_mode().empty()){
    out->currentState={0,0};if(right(p->subactionPath)&&a->name=="right_stick"){const int sector=field_sector();if(sector>=0){const float angle=sector*6.28318530718f/12;out->currentState={std::cos(angle),std::sin(angle)};}}return XR_SUCCESS;
  }
  if(retopo_history()){
    out->currentState={0,0};
    if(right(p->subactionPath)&&a->name=="right_stick"){
      int sector=(frame==43||frame==44)?2:(frame==47||frame==48)?(retopo_mode()=="history-cancel"?11:10):-1;
      if(sector>=0){const float angle=sector*6.283185307f/12;out->currentState={std::cos(angle),std::sin(angle)};}
    }
    return XR_SUCCESS;
  }
  if(!canonical_conversion_mode().empty()){int sector=canonical_conversion_sector();float angle=sector*3.14159265358979323846f/6;out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!expression_mode().empty()){int sector=expression_sector();float angle=sector*3.14159265358979323846f/6;out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!cage_mode().empty()){int sector=cage_sector();float angle=sector*3.14159265358979323846f/6;out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!mirror_mode().empty()){int sector=mirror_sector();float angle=sector*3.14159265358979323846f/6;out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!rig_fit_mode().empty()){int sector=rig_fit_sector();float angle=sector*3.14159265358979323846f/6;out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!projection_mode().empty()){int sector=projection_sector();float angle=sector*3.14159265358979323846f/6;out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!import_atlas_mode().empty()){
    int sector=import_atlas_sector();float angle=sector*3.14159265358979323846f/6;
    out->currentState=right(p->subactionPath)&&a->name=="right_stick"&&sector>=0?XrVector2f{std::cos(angle),std::sin(angle)}:XrVector2f{0,0};return XR_SUCCESS;
  }
  if(!corner_uv_mode().empty()){
    out->currentState={0,0};if(right(p->subactionPath)&&a->name=="right_stick"){
      int sector=-1;if(frame==9||frame==10)sector=8;if(frame==11||frame==12)sector=9;if(frame==13||frame==14)sector=3;
      if(sector>=0){float angle=sector*6.28318530718f/12;out->currentState={std::cos(angle),std::sin(angle)};}
      if(frame>=18&&frame<=22)out->currentState={-1,0};
    }return XR_SUCCESS;
  }
  if(auto mode=editable_avatar_mode();!mode.empty()){
    out->currentState={0,0};if(!right(p->subactionPath)||a->name!="right_stick")return XR_SUCCESS;
    if(mode=="recover"){if(frame==9||frame==10)out->currentState={-1,0};return XR_SUCCESS;}
    if(frame==9||frame==10||frame==23||frame==24)out->currentState={-.8660254f,-.5f};
    if(frame==13||frame==14)out->currentState=mode=="512"?XrVector2f{.5f,-.8660254f}:mode=="1024"?XrVector2f{.8660254f,-.5f}:XrVector2f{-1,0};
    if(frame==19||frame==20)out->currentState={-1,0};
    if(frame==27||frame==28)out->currentState={-.8660254f,-.5f};
    return XR_SUCCESS;
  }
  if(pbr_preview_fixture()){out->currentState=right(p->subactionPath)&&a->name=="right_stick"?(frame==15||frame==16?XrVector2f{.8660254f,.5f}:frame==29||frame==30?XrVector2f{1,0}:XrVector2f{0,0}):XrVector2f{0,0};return XR_SUCCESS;}
  if(selection_fixture()){out->currentState=right(p->subactionPath)&&frame>=9&&frame<=12?XrVector2f{.8660254f,-.5f}:XrVector2f{0,0};return XR_SUCCESS;}
  if(!affine_contact_mode().empty()){out->currentState={0,0};return XR_SUCCESS;}
  out->currentState = right(p->subactionPath) && a->name == "right_stick" &&
                              frame >= 9 && frame <= 10
                          ? XrVector2f{.8660254f, .5f}
                          : XrVector2f{0, 0};
  if (getenv("DOME_XR_FIXTURE_FILES") && right(p->subactionPath) &&
      a->name == "right_stick") {
    if (frame == 25 || frame == 26)
      out->currentState = {-1, 0};
    if (frame == 29 || frame == 30)
      out->currentState = {-.8660254f, -.5f};
    // The main-page sector opens Export options. Release/re-arm, then
    // explicitly choose Strict glTF on the current policy page.
    if (frame == 33 || frame == 34)
      out->currentState = {1, 0};
  }
  if (getenv("DOME_XR_FIXTURE_SCENE") && right(p->subactionPath) &&
      a->name == "right_stick") {
    if (frame == 9 || frame == 10)
      out->currentState = {-.5f, -.8660254f};
    if (frame == 11 || frame == 12)
      out->currentState = {1, 0};
    if (frame == 17 || frame == 18)
      out->currentState = {0, -1};
    if (frame == 19 || frame == 20)
      out->currentState = {.8660254f, .5f};
  }
  if (getenv("DOME_XR_FIXTURE_PAINT") && right(p->subactionPath) &&
      a->name == "right_stick") {
    if (frame == 9 || frame == 10)
      out->currentState = {0, -1};
    if (frame == 11 || frame == 12)
      out->currentState = {0, 1};
    if (frame == 13 || frame == 14)
      out->currentState = {.8660254f, -.5f};
    if (frame == 15 || frame == 16)
      out->currentState = {0, -1};
    // Paint controls now expose projection first; its presets cell reaches
    // the original colour palette. Exercise both real submenu transitions.
    if (frame == 17 || frame == 18)
      out->currentState = {0, -1};
    if (frame == 19 || frame == 20)
      out->currentState = {.5f, .8660254f};
  }
  if (getenv("DOME_XR_FIXTURE_CONTROLS") && right(p->subactionPath) &&
      a->name == "right_stick") {
    if (frame == 9 || frame == 10)
      out->currentState = {0, -1};
    if (frame == 11 || frame == 12)
      out->currentState = {-.5f, .8660254f};
    if (frame >= 14 && frame <= 18)
      out->currentState = {1, 0};
  }
  if (getenv("DOME_XR_FIXTURE_UV") && right(p->subactionPath) &&
      a->name == "right_stick") {
    if (frame == 9 || frame == 10)
      out->currentState = {0, -1};
    if (frame == 11 || frame == 12)
      out->currentState = {-.8660254f, -.5f};
    if (frame >= 15 && frame <= 18)
      out->currentState = {-1, 0};
    if(getenv("DOME_XR_FIXTURE_NORMAL_DOMAIN"))
      out->currentState=frame>=20&&frame<=23?XrVector2f{-1,0}:frame>=15?XrVector2f{0,0}:out->currentState;
  }
  if (getenv("DOME_XR_FIXTURE_LAYERS") && right(p->subactionPath) &&
      a->name == "right_stick") {
    if (frame == 9 || frame == 10)
      out->currentState = {-.5f, -.8660254f};
    if (frame == 11 || frame == 12)
      out->currentState = {.8660254f, -.5f};
    if (frame == 13 || frame == 14)
      out->currentState = {1, 0};
  }
  if (auto mode = voxel_mode(); !mode.empty() && right(p->subactionPath) &&
      a->name == "right_stick") {
    out->currentState = {0, 0};
    if (frame == 9 || frame == 10) out->currentState = {-.5f, -.8660254f};
    if (frame == 11 || frame == 12) out->currentState = {0, -1};
    if (frame == 13 || frame == 14) out->currentState = {.8660254f, .5f};
    if (mode == "undo" && (frame == 43 || frame == 44))
      out->currentState = {-.5f, .8660254f};
  }
  if(auto mode=bake_mode();!mode.empty() && right(p->subactionPath) && a->name=="right_stick"){
    out->currentState={0,0};
    if(frame==9||frame==10)out->currentState={-.5f,-.8660254f};
    if(frame==11||frame==12)out->currentState={0,-1};
    if(frame==13||frame==14)out->currentState={-1,0};
    if(frame==15||frame==16)out->currentState={.8660254f,.5f};
    if((mode=="accept"||mode=="undo") && frame>=21 && frame<=24)out->currentState={0,1};
    if(mode=="undo"&&(frame==43||frame==44))out->currentState={-.5f,.8660254f};
  }
  if(!skin_mode().empty() && right(p->subactionPath) && a->name=="right_stick") {
    out->currentState={0,0};
    if(frame==9 || frame==10)out->currentState={-.5f,-.8660254f};
    if(frame==11 || frame==12 || frame==15 || frame==16)out->currentState={.5f,-.8660254f};
    if(frame==13 || frame==14)out->currentState={-.8660254f,.5f};
    if(frame==17 || frame==18)out->currentState={.8660254f,-.5f};
    if(frame==19 || frame==20)out->currentState={.8660254f,.5f};
    if(frame==25 || frame==26)out->currentState={-.8660254f,-.5f};
  }
  if (!retopo_mode().empty() && right(p->subactionPath) && a->name=="right_stick") {
    auto step=retopo_step;
    out->currentState={0,0};
    if(step==9 || step==10 || step==19 || step==20) out->currentState={0,-1};
    if(step==11 || step==12) out->currentState={.8660254f,.5f};
    if(step==17 || step==18) out->currentState={-.5f,-.8660254f};
    if(step==21 || step==22) out->currentState={.8660254f,-.5f};
    if(step==23 || step==24 || step==27 || step==28) out->currentState={1,0};
    if(step==57 || step==58) out->currentState={.5f,.8660254f};
    if(step>=60 && step<=62) out->currentState={.5f,-.8660254f};
  }
  if(!cut_mode().empty()&&right(p->subactionPath)&&a->name=="right_stick"){
    auto step=cut_stage();out->currentState={0,0};
    if(cut_held()&&cut_step<28){
      int sector=-1;
      if(cut_step==9||cut_step==10||cut_step==24||cut_step==25)sector=8;
      if(cut_step==11||cut_step==12||cut_step==13||cut_step==14)sector=9;
      if(cut_step==15||cut_step==16)sector=0;
      if(cut_step==18||cut_step==19)sector=1;
      if(cut_step==21||cut_step==22)sector=3;
      if(cut_step==27)sector=4;
      if(sector>=0){const float angle=sector*6.283185307f/12;out->currentState={std::cos(angle),std::sin(angle)};}
    }
    if(step==9||step==10)out->currentState={-.5f,-.8660254f};
    if(step==11||step==12)out->currentState={0,-1};
    if(step==13||step==14)out->currentState={-.5f,.8660254f};
    if(step==15||step==16)out->currentState={1,0};
    if(step==19||step==20||(step>=29&&step<=32))out->currentState={-.8660254f,-.5f};
    if(step==21||step==22)out->currentState={.8660254f,.5f};
  }
  if(!mask_mode().empty() && right(p->subactionPath) && a->name=="right_stick") {
    auto step=mask_step;out->currentState={0,0};
    int sector=-1;
    if(step==9 || step==10 || step==47 || step==48) sector=8;
    if(step==11 || step==12 || step==13 || step==14 || step==49 || step==50 || step==51 || step==52) sector=11;
    if(step==15 || step==16) sector=6;
    if(step==17 || step==18) sector=2;
    if(step==23 || step==24) sector=1;
    if(step==29 || step==30 || (step>=68 && step<=69) || (step>=77 && step<=80)) sector=0;
    if(step==71 || step==72) sector=8;
    if(step==73 || step==74 || step==75 || step==76) sector=11;
    if(step==53 || step==54) sector=10;
    if(step==65 || step==66) sector=3;
    if(step==85 || step==86) sector=4;
    if(sector>=0) {float angle=sector*6.28318530718f/12;out->currentState={std::cos(angle),std::sin(angle)};}
    report["mask_vectors"][std::to_string(step)]={out->currentState.x,out->currentState.y};
  }
  if(!bake_policy_mode().empty() && right(p->subactionPath) && a->name=="right_stick") {
    out->currentState={0,0};int sector=-1;const auto step=bake_policy_stage();
    if(step==9 || step==10)sector=8;
    if(step==11 || step==12)sector=9;
    if(step==13 || step==14)sector=6;
    if(step==15 || step==16)sector=bake_projection_mode()&&frame<=20?0:bake_color_mode()?9:11;
    if(step==23 || step==24)sector=3;
    if(sector>=0){float angle=sector*6.28318530718f/12;out->currentState={std::cos(angle),std::sin(angle)};}
  }
  if(auto mode=procedural_mode();!mode.empty() && right(p->subactionPath) && a->name=="right_stick") {
    out->currentState={0,0};int sector=-1;
    if(frame==9 || frame==10)sector=8;
    if(frame==11 || frame==12)sector=11;
    if(frame==13 || frame==14)sector=9;
    if(frame==15 || frame==16)sector=mode=="accept"?6:4;
    if(sector>=0){float angle=sector*6.28318530718f/12;out->currentState={std::cos(angle),std::sin(angle)};}
  }
  if(!resolution_mode().empty() && right(p->subactionPath) && a->name=="right_stick") {
    out->currentState={0,0};int sector=-1;
    if(frame==9 || frame==10)sector=8;
    if(frame==11 || frame==12)sector=11;
    if(frame==13 || frame==14)sector=7;
    if(sector>=0){float angle=sector*6.28318530718f/12;out->currentState={std::cos(angle),std::sin(angle)};}
  }
  if(auto mode=polygon_mode();!mode.empty()&&right(p->subactionPath)&&a->name=="right_stick"){
    int sector=-1;auto step=polygon_stage();
    if(step==9||step==10)sector=8;
    if(step==11||step==12)sector=9;
    if(step==13||step==14)sector=2;
    if(step==15||step==16||step==19||step==20)sector=0;
    if(step>=25&&step<=27)sector=mode=="focus"?4:mode=="noop"?10:7;
    if(step>=28&&step<=30)sector=mode=="cancel"?11:10;
    out->currentState={0,0};if(sector>=0){float a=sector*6.28318530718f/12;out->currentState={std::cos(a),std::sin(a)};}
  }
  return XR_SUCCESS;
}
FN(GetActionStatePose, XrSession, const XrActionStateGetInfo *,
   XrActionStatePose *p) {
  p->isActive = XR_TRUE;
  return XR_SUCCESS;
}
FN(GetCurrentInteractionProfile, XrSession, XrPath hand,
   XrInteractionProfileState *p) {
  p->interactionProfile =
      path(right(hand) && ink()
               ? "/interaction_profiles/logitech/mx_ink_stylus_logitech"
               : "/interaction_profiles/meta/touch_controller_plus");
  return XR_SUCCESS;
}
FN(LocateSpace, XrSpace handle, XrSpace, XrTime, XrSpaceLocation *p) {
  auto s = reinterpret_cast<Space *>(handle);
  p->locationFlags = XR_SPACE_LOCATION_POSITION_VALID_BIT |
                     XR_SPACE_LOCATION_ORIENTATION_VALID_BIT;
  if(!field_mode().empty()){
    p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.48f}:XrVector3f{0,1.6f,0};
    return XR_SUCCESS;
  }
  if(!canonical_conversion_mode().empty()){
    p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.48f}:XrVector3f{0,1.6f,0};
    if(s->action&&right(s->hand)&&s->action->name=="aim_pose"&&frame>=38&&frame<=42){
      const float x=canonical_conversion_mode()=="cancel"?170:320,y=canonical_conversion_mode()=="cancel"?609:492;
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
    }
    return XR_SUCCESS;
  }
  if(!expression_mode().empty()){p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.5f}:XrVector3f{0,1.6f,0};return XR_SUCCESS;}
  if(!cage_mode().empty()){
    p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.48f}:XrVector3f{0,1.6f,0};
    if(s->action&&right(s->hand)&&s->action->name=="aim_pose"&&(frame==38||frame==56||(frame==62&&cage_mode()=="cancel"))){
      float x=frame==38?100+420*float(dome::bake_distance_to_unit(bake_recipe_fixture()?40:100)):frame==56?(bake_recipe_fixture()?320:520):170;
      float y=frame==38?240:frame==56?(bake_recipe_fixture()?432:320):609;
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
    }
    return XR_SUCCESS;
  }
  if(!mirror_mode().empty()){
    p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.5f}:XrVector3f{0,1.6f,0};
    if(s->action&&right(s->hand)&&frame>=38){
      float x=100+420*(mirror_method()*.5f),y=240;
      if(frame>=48){x=100+420*float(.5+.5*std::log1p(70.)/std::log1p(1e9));y=320;}
      if(frame>=58){x=240;y=400;}
      if(frame>=76){x=mirror_mode()=="cancel"?170:470;y=609;}
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.43f};
    }
    return XR_SUCCESS;
  }
  if(!rig_fit_mode().empty()){p->pose.orientation={0,0,0,1};p->pose.position=s->action?(right(s->hand)&&frame>=44?XrVector3f{.01f,2.48f,-.85f}:XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.5f}):XrVector3f{0,1.6f,0};return XR_SUCCESS;}
  if(!projection_mode().empty()){p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,frame>=72?-.85f:-.5f}:XrVector3f{0,1.6f,0};return XR_SUCCESS;}
  if(!import_atlas_mode().empty()){p->pose.orientation={0,0,0,1};p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.5f}:XrVector3f{0,1.6f,0};return XR_SUCCESS;}
  if(selection_fixture()){
    p->pose.orientation={0,0,0,1};
    if(!s->action)p->pose.position={0,1.6f,0};
    else if(!right(s->hand))p->pose.position={-.8f,1.4f,-.4f};
    else if(frame>=16&&frame<=19)p->pose.position={.602f,1.844f,-.7f};
    else if(frame>=34)p->pose.position={.34f,1.824f,-.61f};
    else p->pose.position={frame>=25?.16f:-.16f,1.48f,-.83f};
    return XR_SUCCESS;
  }
  if (field_mode().empty() && frame == 22 && editable_avatar_mode().empty() && !pbr_preview_fixture() && !getenv("DOME_XR_FIXTURE_NORMAL_DOMAIN") && affine_contact_mode().empty() && (polygon_mode().empty()&&corner_uv_mode().empty()) && bake_policy_mode().empty() && procedural_mode().empty() && resolution_mode().empty() && s->action && voxel_mode() != "focus" && bake_mode().empty() && skin_mode().empty() && retopo_mode().empty() && mask_mode().empty() && cut_mode().empty()) {
    p->locationFlags = 0;
    count("tracking_losses");
  }
  p->pose.orientation = {0, 0, 0, 1};
  if(!affine_contact_mode().empty()){p->pose.position=s->action?XrVector3f{right(s->hand)?0.f:-.3f,1.48f,-.85f}:XrVector3f{0,1.6f,0};return XR_SUCCESS;}
  if (s->reference == XR_REFERENCE_SPACE_TYPE_VIEW && !s->action)
    p->pose.position = {frame >= 38 && (cage_mode().empty()&&(mirror_mode().empty()&&expression_mode().empty())&&import_atlas_mode().empty()&&projection_mode().empty()&&rig_fit_mode().empty()) && (polygon_mode().empty()&&corner_uv_mode().empty()) && !selection_fixture() ? -.2f : 0, 1.6f, 0};
  else
    p->pose.position = {(right(s->hand) ? float((frame % 5) * .015f) : -.3f) +
                            (frame >= 38 ? -.2f : 0),
                        1.48f, -.48f};
  if(corner_uv_mode()=="cancel"&&s->action&&s->action->name=="aim_pose"&&right(s->hand)&&frame==28){
    p->pose.position={.045f+(170.f/640-.5f)*.6f,1.56f+(.5f-609.f/640)*.6f,-.3f};
  }
  // Cut controls use an independently specified world-space ray. Keep their
  // menu anchor fixed when the Holding preamble shifts the frame timeline.
  if(!cut_mode().empty()&&s->action&&right(s->hand))p->pose.position={.045f,1.48f,-.48f};
  if (getenv("DOME_XR_FIXTURE_RESTART") && s->action && right(s->hand) &&
      frame >= 24 && frame <= 26)
    p->pose.position = {-.22f, 1.48f, -.48f};
  if(pbr_preview_fixture()&&s->action)p->pose.position={right(s->hand)?.045f:-.3f,1.48f,-.3f};
  if(pbr_preview_fixture()&&s->action&&s->action->name=="aim_pose"&&right(s->hand)&&(frame==12||frame==26)){
    p->pose.position={.045f,1.56f+(.5f-.06f)*.6f,-.3f};
  }
  if (getenv("DOME_XR_FIXTURE_CONTROLS") && s->action &&
      s->action->name == "aim_pose" && right(s->hand) && frame == 19) {
    p->pose.position = {.045f + (((100 + 420 * .75f) / 640) - .5f) * .6f,
                        1.56f + (.5f - 300.f / 640) * .6f, -.3f};
  }
  if (getenv("DOME_XR_FIXTURE_UV") && s->action &&
      s->action->name == "aim_pose" && right(s->hand) &&
      (frame == 14 || frame == 20)) {
    float x = frame == 14 ? 178 : 470, y = frame == 14 ? 85 : 609;
    p->pose.position = {.045f + (x / 640 - .5f) * .6f,
                        1.56f + (.5f - y / 640) * .6f, -.3f};
  }
  if (const auto mode=getenv("DOME_XR_FIXTURE_NORMAL_DOMAIN");mode && s->action &&
      s->action->name=="aim_pose" && right(s->hand) && (frame==15||frame==18||frame==26)) {
    const float x=frame==15?55:frame==18?178:std::string_view(mode)=="cancel"?170:470;
    const float y=frame==15?(getenv("DOME_XR_FIXTURE_PAINT_DOMAIN")?322:270):frame==18?85:609;
    p->pose.position={.045f+(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
  }
  if (auto mode = voxel_mode(); !mode.empty() && s->action &&
      s->action->name == "aim_pose" && right(s->hand) &&
      (frame == 16 || (mode == "cancel" && frame == 18))) {
    float t = std::log(50.f / .01f) / std::log(1000.f / .01f);
    float x = frame == 16 ? 100 + 420 * t : 170;
    float y = frame == 16 ? 300 : 609;
    p->pose.position = {.045f + (x / 640 - .5f) * .6f,
                        1.56f + (.5f - y / 640) * .6f, -.3f};
  }
  if(auto mode=bake_mode();!mode.empty() && s->action && s->action->name=="aim_pose" && right(s->hand) && (frame==18||(mode=="cancel"&&frame==20))){
    float t=std::log(20.f/.01f)/std::log(10000.f/.01f);
    float x=frame==18?100+420*t:170,y=frame==18?240:609;
    p->pose.position={.045f+(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
  }
  if(auto mode=skin_mode();!mode.empty() && s->action && s->action->name=="aim_pose" && right(s->hand) && frame==22) {
    float t=mode=="fitted"?0.f:1.f;
    p->pose.position={.045f+((100+420*t)/640-.5f)*.6f,1.56f+(.5f-300.f/640)*.6f,-.3f};
  }
  if(!cut_mode().empty()&&s->action&&s->action->name=="aim_pose"&&right(s->hand)&&cut_stage()==24){
    p->pose.position={.045f+((100+420*.6f)/640-.5f)*.6f,1.56f+(.5f-300.f/640)*.6f,-.3f};
  }
  if (auto mode=retopo_mode(); !mode.empty() && s->action && right(s->hand)) {
    float x=0,y=0;
    auto step=retopo_step;
    if(step==32) { x=-.2f; y=-.2f; }
    else if(mode=="focus" && step>=36 && step<=41) { x=.35f; y=.25f; }
    else if(step==36 || step==48) { x=.2f; y=-.2f; }
    else if(step==40 || step==52) { x=0; y=.2f; }
    p->pose.position={x,1.48f+y,-.83f};
  }
  if(auto mode=mask_mode();!mode.empty() && s->action && right(s->hand)) {
    auto step=mask_step;p->pose.position={0,1.48f,-.48f};
    if(step==32) p->pose.position={.11f,1.48f,-.67f};
    if(mode=="focus" && step>=36 && step<=41) p->pose.position={-.1f,1.60f,-.68f};
    if(s->action->name=="aim_pose" && (step==20 || step==26 || step==56 || step==58 || step==62)) {
      float x=100+420*.35f,y=300;
      if(step==26)x=100;
      if(step==56){x=100+420*.6f;y=210;}
      if(step==58){x=100;y=420;}
      if(step==62){x=mode=="accept"?470:170;y=609;}
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
    }
  }
  if(auto mode=bake_policy_mode();!mode.empty() && s->action && right(s->hand)) {
    p->pose.position={0,1.48f,-.48f};const auto step=bake_policy_stage();
    if(s->action->name=="aim_pose" && (step==18 || step==20)) {
      float x=520,y=bake_normal_mode()?350:bake_color_mode()?210:240;if(bake_projection_mode()&&frame<=20){x=100;y=210;if(frame==20){x=470;y=609;}}else if(step==20){x=mode=="cancel"?170:470;y=609;}
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
    }
  }
  if(auto mode=procedural_mode();!mode.empty() && s->action && right(s->hand)) {
    p->pose.position={0,1.48f,-.48f};
    if(s->action->name=="aim_pose" && (frame==18 || frame==22)) {
      float x=100+420*.6f,y=300;
      if(frame==22){x=170;y=609;}
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
    }
  }
  if(auto mode=resolution_mode();!mode.empty() && s->action && right(s->hand)) {
    p->pose.position={0,1.48f,-.48f};
    if(s->action->name=="aim_pose" && (frame==18 || frame==22)) {
      float x=100+420*float(std::log(.02/.00001)/std::log(100000.)),y=300;
      if(frame==22){x=mode=="cancel"?170:470;y=609;}
      p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
    }
  }
  if(!polygon_mode().empty()&&s->action&&!right(s->hand))p->pose.position={-.3f,1.48f,-.48f};
  if(auto mode=polygon_mode();!mode.empty()&&s->action&&right(s->hand)){
    p->pose.position={0,1.48f,-.48f};
    if(s->action->name=="aim_pose"){
      p->pose.position={mode=="focus"&&polygon_stage()>=29?.1f:0.f,1.48f,-.1f};
      if((mode.starts_with("restore")&&(polygon_stage()==18||polygon_stage()==22)) ||
          (polygon_color_conversion()&&(polygon_step==18||polygon_step==22))){
        const bool slider=polygon_color_conversion()?polygon_step==18:polygon_stage()==18;
        float x=slider?520:mode=="restore-cancel"?170:470,y=slider?300:609;
        p->pose.position={(x/640-.5f)*.6f,1.56f+(.5f-y/640)*.6f,-.3f};
      }
    }
  }
  return XR_SUCCESS;
}
FN(ApplyHapticFeedback, XrSession, const XrHapticActionInfo *,
   const XrHapticBaseHeader *) {
  count("haptics");
  return XR_SUCCESS;
}
FN(StopHapticFeedback, XrSession, const XrHapticActionInfo *) {
  return XR_SUCCESS;
}
FN(GetInstanceProcAddr, XrInstance, const char *name, PFN_xrVoidFunction *out) {
#define ENTRY(s)                                                               \
  if (!strcmp(name, "xr" #s)) {                                                \
    *out = reinterpret_cast<PFN_xrVoidFunction>(f_##s);                        \
    return XR_SUCCESS;                                                         \
  }
  ENTRY(GetInstanceProcAddr)
  ENTRY(EnumerateInstanceExtensionProperties)
  ENTRY(CreateInstance)
  ENTRY(DestroyInstance)
  ENTRY(GetInstanceProperties)
  ENTRY(GetSystem)
  ENTRY(GetSystemProperties)
  ENTRY(GetOpenGLGraphicsRequirementsKHR)
  ENTRY(CreateSession)
  ENTRY(DestroySession)
  ENTRY(EnumerateReferenceSpaces)
  ENTRY(CreateReferenceSpace)
  ENTRY(DestroySpace)
  ENTRY(CreateActionSet)
  ENTRY(DestroyActionSet)
  ENTRY(CreateAction)
  ENTRY(DestroyAction) ENTRY(StringToPath) ENTRY(PathToString)
      ENTRY(SuggestInteractionProfileBindings) ENTRY(AttachSessionActionSets)
          ENTRY(CreateActionSpace) ENTRY(EnumerateEnvironmentBlendModes) ENTRY(
              EnumerateViewConfigurationViews) ENTRY(EnumerateSwapchainFormats)
              ENTRY(CreateSwapchain) ENTRY(DestroySwapchain) ENTRY(
                  EnumerateSwapchainImages) ENTRY(AcquireSwapchainImage)
                  ENTRY(WaitSwapchainImage) ENTRY(ReleaseSwapchainImage) ENTRY(
                      BeginSession) ENTRY(EndSession) ENTRY(RequestExitSession)
                      ENTRY(PollEvent) ENTRY(WaitFrame) ENTRY(BeginFrame)
                          ENTRY(EndFrame) ENTRY(LocateViews) ENTRY(SyncActions)
                              ENTRY(GetActionStateBoolean)
                                  ENTRY(GetActionStateFloat)
                                      ENTRY(GetActionStateVector2f)
                                          ENTRY(GetActionStatePose) ENTRY(
                                              GetCurrentInteractionProfile)
                                              ENTRY(LocateSpace)
                                                  ENTRY(ApplyHapticFeedback)
                                                      ENTRY(StopHapticFeedback)
#undef ENTRY
                                                          *out = nullptr;
  return XR_ERROR_FUNCTION_UNSUPPORTED;
}
} // namespace
extern "C" XRAPI_ATTR XrResult XRAPI_CALL xrNegotiateLoaderRuntimeInterface(
    const XrNegotiateLoaderInfo *loader, XrNegotiateRuntimeRequest *request) {
  if (!loader || !request || loader->maxInterfaceVersion < 1)
    return XR_ERROR_INITIALIZATION_FAILED;
  request->runtimeInterfaceVersion = 1;
  request->runtimeApiVersion = XR_MAKE_VERSION(1, 0, 0);
  request->getInstanceProcAddr = f_GetInstanceProcAddr;
  return XR_SUCCESS;
}
