#!/usr/bin/env python3
from pathlib import Path
import os,json,hashlib,subprocess,time,sys,fcntl,importlib.util,signal,re
from cohort import R,P,S,admit
C=R/'artifacts/strict-arc-20261111/control';OBS=R/'artifacts/paint-workflow-dso-build-20261111'
def sha(f):
 with Path(f).open('rb')as s:return hashlib.file_digest(s,'sha256').hexdigest()
def write(f,d):
 q=f.with_suffix('.writing');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(f)
profile=sys.argv[1];domain=sys.argv[2];assert profile in ['release','sanitize']and domain in ['source','plain'];tag=sys.argv[3]if len(sys.argv)>3 else'v1';cohort=admit(profile)
lease=open('/tmp/dome-sculpt-arc-device.lock','a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=P/(profile+'-producer-'+domain+'-'+tag);out.mkdir();home=out/'home';home.mkdir()
build=P/('cohort-'+profile)/'receipt.json';receipt=cohort
binary=Path(cohort['targets']['dome-sculpt-gpu-color-blur-native-test']['path']);observer=OBS/('device-auth-all-egl-'+profile+'.so')
pins=dict(cohort['pins'])
for f in [build,Path(__file__),observer,OBS/'device-auth-all-egl.cpp',OBS/'device-auth-all-egl-derivation.json',C/'graphics-v3.py',C/'mount_identity.py']:pins[str(f)]=sha(f)
sys.path.insert(0,str(C));spec=importlib.util.spec_from_file_location('monitor',C/'graphics-v3.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
env={k:v for k,v in os.environ.items()if not k.startswith(('MESA_','GALLIUM_','LIBGL_','DOME_','DRI_'))}
for k in ['DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','XR_RUNTIME_JSON']:env.pop(k,None)
env.update(LD_LIBRARY_PATH=str(R/('artifacts/sdk-20261111/toolkit-'+profile+'/lib'))+':/usr/lib64',LD_PRELOAD=('/usr/lib64/libasan.so.8:'if profile=='sanitize'else'')+str(observer),DRI_PRIME='pci-0000_03_00_0',MESA_LOADER_DRIVER_OVERRIDE='iris',EGL_PLATFORM='surfaceless',MESA_SHADER_CACHE_DISABLE='1',LP_NUM_THREADS='2',__EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json',HOME=str(home),DOME_MARKER_DEVICE_REPORT=str(out/'actual-device'))
for k,part in [('XDG_RUNTIME_DIR','runtime'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state')]:env[k]=str(home/part);Path(env[k]).mkdir(mode=0o700)
if profile=='sanitize':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
state={'state':'running','scope':'Current audited-incremental actual source/plain native fixture producer on authenticated hardware; unchanged native Flow1/independent-oracle/typed/hidden/source/history authority. Root native/software suite retains independent scope; no oldABI or GUI/XR/whole-goal completion claim.','profile':profile,'source':cohort['source'],'domain':domain,'owning_targets':65,'command':[str(binary),'--plain-workflow-fixtures'if domain=='plain'else'--workflow-fixtures',str(out/'native')],'environment':{k:env.get(k)for k in ['LD_LIBRARY_PATH','LD_PRELOAD','DRI_PRIME','MESA_LOADER_DRIVER_OVERRIDE','EGL_PLATFORM','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']},'build_receipt':{'path':str(build),'sha256':sha(build)},'flock':'/tmp/dome-sculpt-arc-device.lock','timeout_seconds':180,'RSS_cap':4*2**30,'pins':pins};write(out/'status.json',state)
critical={};critical_stat={}
for name,f in [('consumer',binary),('observer',observer),('system_EGL',Path('/usr/lib64/libEGL_mesa.so.0.0.0')),('system_gallium',Path('/usr/lib64/libgallium-26.2.5.so'))]:
 st=f.stat();identity=g.current_identity(f);critical[name]=(identity['map_device'],st.st_ino);critical_stat[name]=(st.st_dev,st.st_ino);pins[str(f)]=sha(f)
owned={};seen=set();mapped={};dris={};peak=0;t=time.monotonic();log=out/'process.log';active=None
try:
 with log.open('w')as stream:
  active=subprocess.Popen(state['command'],env=env,cwd=out,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=g.no_core);state['pid']=active.pid;write(out/'status.json',state)
  while active.poll()is None:
   peak=max(peak,g.monitor(active,owned,critical,critical_stat,seen,mapped,dris,out));assert peak<=state['RSS_cap']and time.monotonic()-t<180;time.sleep(.001)
  code=active.wait()
 state.update(native_exit=code,seconds=time.monotonic()-t,peak_RSS=peak,critical_observed=sorted(seen));write(out/'status.json',state)
 text=log.read_text();assert code==0,(code,text[-3000:]);assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:',text)
 devices=sorted((out/'actual-device').glob('*/device.txt'));assert devices
 for f in devices:
  device=dict(x.split('=',1)for x in f.read_text().splitlines()if '='in x and not x.startswith('fd='));assert 'Arc'in device['renderer']and'A770'in device['renderer']and device['vendor']=='Intel'
  assert device['render_node']=='/dev/dri/renderD129'and device['pci'].endswith('/0000:03:00.0')and device['vendor_id']=='0x8086'and device['device_id']=='0x56a0'
  assert int(device['egl_context'],16)and int(device['egl_display'],16)and int(device['thread_id'])and re.search(r'^fd=\d+$',f.read_text(),re.M)
  assert (f.parent/'context-maps.txt').is_file()
 assert Path('/sys/dev/char/226:129/device/driver').resolve().name=='i915'and set(critical).issubset(seen)
 values=re.findall(r'^PASS (\d+) '+('plain current-grid native workflow fixture controls'if domain=='plain'else'native workflow fixture controls')+r'$',text,re.M);assert len(values)==1
 manifest=json.loads((out/'native/manifest.json').read_text());assert int(values[0])==manifest['native_checks']+1 and (domain!='plain'or(manifest['domain']=='plain-current-grid'and manifest['physical_emission']and manifest['producer_render_packet']))and manifest['independent_pixel_oracle']and manifest['flow']==1 and manifest['resolution']==64
 state.update(exit=0,native_checks=int(values[0]),manifest_checks_before_write=manifest['native_checks'],manifest_sha256=sha(out/'native/manifest.json'),device_reports={str(f):sha(f)for f in devices},context_maps={str(f.parent/'context-maps.txt'):sha(f.parent/'context-maps.txt')for f in devices},native_files={k:{'path':str(out/'native'/v),'sha256':sha(out/'native'/v)}for k,v in manifest['files'].items()},log_sha256=sha(log))
except BaseException as e:
 state.update(exit=1,error=repr(e))
 if active is not None and active.poll()is None:g.cleanup(active,owned)
finally:
 state.update(state='terminal',input_drift=[f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h]);state['exit']=state['exit']or int(bool(state['input_drift']));write(out/'status.json',state);write(out/'mapped-ELFs.json',mapped);write(out/'readable-DRI.json',dris);fcntl.flock(lease,fcntl.LOCK_UN)
print(profile,state['state'],state['exit'],str(out),flush=True);raise SystemExit(state['exit'])
