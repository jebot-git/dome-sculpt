from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent
R=P.parents[1]
S=R/'artifacts/authoring-eligible-integration-20261111'
B=R/'artifacts/authoring-eligible-owning-20261111'
HEAD='e9931f7286f75746af47d52f2d901b731510cbb5'
OLD=R/'artifacts/authoring-public-workflows-20261111'
def sha(f):
 with Path(f).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(f,d):
 q=f.with_suffix('.writing');q.write_text(json.dumps(d,indent=2)+'\n');q.replace(f)
def verify(pins):return [f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h]
def admit(profile):
 assert profile in ['release','sanitize']
 out=P/('cohort-'+profile)
 if (out/'receipt.json').exists():
  d=json.loads((out/'receipt.json').read_text());assert not verify(d['pins']);return d
 raw=B/(profile+'-v3/status.json');state=json.loads(raw.read_text())
 gate=B/(profile+'-gates/status.json');gates=json.loads(gate.read_text())
 assert state['source']==HEAD and state['state']=='terminal' and state['exit']==0 and not state['audit_only']
 assert not state['pin_drift'] and not state['output_drift'] and len(state['target_outputs'])==65
 assert gates['source']==HEAD and gates['state']=='terminal' and gates['exit']==0 and not gates['provider_drift']
 assert gates['selected_results']=={'total':56,'required_total':56,'pass':56,'failed_or_skipped':[],'exit':0}
 assert all(x['exit']==0 and not x['external_guard'] for x in gates['steps'])
 assert {(x['name'],x.get('expected_controls')) for x in gates['steps']} >= {('dome-sculpt-sculpt-chunk-workspace-test',27),('dome-sculpt-sculpt-placed-workspace-test',373)}
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True).strip()
 pins=dict(state['pins']);pins[str(raw)]=sha(raw);pins[str(gate)]=sha(gate)
 for path in [Path(state['audit_path']),B/'build-closure-v3.py',Path(__file__)]:pins[str(path)]=sha(path)
 # Freeze the actual current core and all current65 linked outputs, not old
 # baseline ELFs. All307 selected whole-object providers are already in pins.
 core=B/(profile+'-v3/libdome-sculpt-core.a');assert sha(core)==state['core_archive']['sha256'];pins[str(core)]=sha(core)
 targets={}
 for name,row in state['target_outputs'].items():
  f=Path(row['path']);assert f.is_file() and sha(f)==row['sha256']
  targets[name]={'path':str(f),'sha256':row['sha256'],'bytes':f.stat().st_size,'origin':row['origin']};pins[str(f)]=row['sha256']
 # The actual public scenarios/oracles execute from the NEW canonical source,
 # authenticated byteexact to the original qualified public workflow source.
 oldsource=R/'artifacts/authoring-production-union-20261111'
 names=['tests/gpu-color-blur-menu.py','tests/gpu-color-blur-xr.py']
 for n in names:
  assert sha(S/n)==sha(oldsource/n);pins[str(S/n)]=sha(S/n);pins[str(oldsource/n)]=sha(oldsource/n)
 original_scripts={str(OLD/n):sha(OLD/n) for n in ['cohort.py','producer.py','font.py','gui.py','xr.py']};pins.update(original_scripts)
 for n in ['producer.py','font.py','gui.py','xr.py']:pins[str(P/n)]=sha(P/n)
 assert not verify(pins)
 out.mkdir(exist_ok=False);write(out/'root-status-at-admission.json',state);write(out/'root-gates-at-admission.json',gates)
 for f in [out/'root-status-at-admission.json',out/'root-gates-at-admission.json']:pins[str(f)]=sha(f)
 d={'state':'audited-current-owning-provider-input-admitted','source':HEAD,'profile':profile,
 'scope':'Audited incremental current65: four qualified2ef completeTUs and7old44be fullTUs plus296 unchanged a904 whole providers;192 core members190 unchanged. Current core and all65 current outputs pinned.63fresh current links+2byteexact qualified matched consumers; not freshwholebuild. Native/software56 and27/373 positively admitted before public cases; no whole-goal claim.',
 'source_files':1654,'SDK_pins':state['verified_sdk_pins'],'owning_outputs':65,
 'selected_provider_objects':len(state['borrowed_objects']),'targets':targets,
 'closure_receipt':{'path':str(raw),'sha256':sha(raw)},'CPU_gate_receipt':{'path':str(gate),'sha256':sha(gate)},
 'current_core':{'path':str(core),'sha256':sha(core)},'original_orchestration_pins':original_scripts,'pins':pins}
 write(out/'receipt.json',d);return d
