from pathlib import Path
import os,json,subprocess,sys,time
from cohort import P,R,S,sha,write,verify,admit
profile=sys.argv[1];cohort=admit(profile);out=P/('font-'+profile);out.mkdir(exist_ok=False);home=out/'home';home.mkdir()
binary=Path(cohort['targets']['dome-sculpt-gpu-color-blur-font-reference']['path']);pins=dict(cohort['pins']);receipt=P/('cohort-'+profile)/'receipt.json';pins[str(receipt)]=sha(receipt)
env={k:v for k,v in os.environ.items()if not k.startswith(('DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
for k in ['LD_PRELOAD','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','XR_RUNTIME_JSON']:env.pop(k,None)
env.update(HOME=str(home),LD_LIBRARY_PATH=str(R/('artifacts/sdk-20261111/toolkit-'+profile+'/lib'))+':/usr/lib64')
for k,part in [('XDG_RUNTIME_DIR','runtime'),('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state')]:env[k]=str(home/part);Path(env[k]).mkdir(mode=0o700)
if profile=='sanitize':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
command=[str(binary),str(out/'titles.json')];t=time.monotonic()
with (out/'process.log').open('wb')as stream:code=subprocess.call(command,env=env,stdout=stream,stderr=subprocess.STDOUT)
state={'state':'terminal','source':cohort['source'],'scope':'Current audited-incremental font/reference CLI, actual bitmap source/style, no GL or document callback','command':command,'exit':code,'seconds':time.monotonic()-t,'log_sha256':sha(out/'process.log'),'provider_drift':verify(pins)}
if code==0:
 d=json.loads((out/'titles.json').read_text());font=Path(d['font_file']);state.update(reference_sha256=sha(out/'titles.json'),font={'path':str(font),'sha256':sha(font)},actual_style={k:d[k]for k in ['font_pixels','unit','light','opacity']})
state['exit']=state['exit']or int(bool(state['provider_drift']));write(out/'status.json',state);print(profile,state['state'],state['exit'],flush=True);raise SystemExit(state['exit'])
