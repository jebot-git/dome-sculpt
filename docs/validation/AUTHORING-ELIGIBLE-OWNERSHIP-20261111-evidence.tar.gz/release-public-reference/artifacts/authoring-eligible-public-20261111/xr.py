from pathlib import Path
from cohort import admit
import os,json,hashlib,subprocess,time,sys,fcntl,importlib.util,signal,types,re
r=Path('/home/blux/de-xr/dome-sculpt');p=Path(__file__).resolve().parent;c=r/'artifacts/strict-arc-20261111/control';s=r/'artifacts/authoring-eligible-integration-20261111';bundle=r/'artifacts/gui-recovery-20261111';build=r/'artifacts/authoring-eligible-owning-20261111';sha=lambda f:hashlib.file_digest(Path(f).open('rb'),'sha256').hexdigest();signal.pthread_sigmask(signal.SIG_SETMASK,[])
def write(f,d):f.write_text(json.dumps(d,indent=2)+'\n')
profile=sys.argv[1];domain=sys.argv[2];tag=sys.argv[3]if len(sys.argv)>3 else'v1';mode='normal';assert profile in ['release','sanitize']and domain in ['source','plain'];cohort=admit(profile);out=p/(profile+'-xr-'+domain+'-'+tag);out.mkdir();lease=open('/tmp/dome-sculpt-arc-device.lock','a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
app=Path(cohort['targets']['dome-sculpt']['path']);inspector=Path(cohort['targets']['dome-sculpt-native-authoring-inspect']['path']);manifest=p/(profile+'-producer-'+domain+'-v1/native/manifest.json');producer=p/(profile+'-producer-'+domain+'-v1/status.json');production=json.loads(producer.read_text());assert production['state']=='terminal'and production['exit']==0 and not production['input_drift'];observer=r/('artifacts/paint-workflow-dso-build-20261111/device-auth-all-egl-'+profile+'.so');receipt=p/('cohort-'+profile)/'receipt.json';base={'owned':cohort['pins'],'source':cohort['source']};assert not subprocess.check_output(['git','status','--porcelain'],cwd=s,text=True).strip();script=s/'tests/gpu-color-blur-xr.py';runtime=Path(cohort['targets']['dome-sculpt-gpu-color-blur-runtime']['path']);reference=p/('font-'+profile)/'titles.json';font_file=Path(json.loads(reference.read_text())['font_file']);files=[app,inspector,manifest,producer,receipt,script,observer,r/'artifacts/paint-workflow-dso-build-20261111/device-auth-all-egl.cpp',*(manifest.parent/x for x in json.loads(manifest.read_text())['files'].values())];files.extend([runtime,reference,font_file])
pins={str(f):sha(f)for f in files};pins.update(cohort['pins']);pins[str(Path(__file__))]=sha(Path(__file__))
env={k:v for k,v in os.environ.items()if not k.startswith(('MESA_','GALLIUM_','LIBGL_','DOME_','DRI_'))}
for key in ['LD_PRELOAD','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','XR_RUNTIME_JSON']:env.pop(key,None)
env.update(MESA_LOADER_DRIVER_OVERRIDE='iris',DOME_BLUR_XR_REQUIRE_RENDERER='Arc',PATH=str(bundle/'bin')+':'+os.environ['PATH'],LD_LIBRARY_PATH=str(r/('artifacts/sdk-20261111/toolkit-'+profile+'/lib'))+':/usr/lib64',DRI_PRIME='pci-0000_03_00_0',EGL_PLATFORM='surfaceless',MESA_SHADER_CACHE_DISABLE='1',LP_NUM_THREADS='2',__EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json',DOME_BLUR_APP_PRELOAD=('/usr/lib64/libasan.so.8:'if profile=='sanitize'else'')+str(observer),DOME_MARKER_DEVICE_REPORT=str(out/'actual-device'),DOME_BLUR_MENU_SCREEN='1100x800x24'if mode=='normal'else'1000x540x24')
if profile=='sanitize':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
command=[sys.executable,str(script),str(app),str(runtime),str(inspector),str(manifest),str(reference),str(out/'workflow')];state={'state':'running','scope':'Actuale993 current audited-incremental ordinaryXR app/realOpenXRloader+newDSO, both-eyepublicpalette+nativeacceptedSave/history, syntheticactions, authenticatedArc; no physicalHMD/installedclaim.','profile':profile,'domain':domain,'mode':mode,'owning_targets':65,'owning_receipt_sha256':sha(receipt),'command':command,'test_source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip(),'application_source':base['source'],'pins':pins,'timeout_seconds':240,'RSS_cap':4*2**30,'environment':{k:env.get(k)for k in ['LD_LIBRARY_PATH','DRI_PRIME','LIBGL_ALWAYS_SOFTWARE','DOME_BLUR_APP_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']}};write(out/'status.json',state)
sys.path.insert(0,str(c));spec=importlib.util.spec_from_file_location('monitor',c/'graphics-v3.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
critical={};critical_stat={}
for key,f in [('consumer',app),('runtime',runtime),('observer',observer),('system_EGL',Path('/usr/lib64/libEGL_mesa.so.0.0.0')),('system_gallium',Path('/usr/lib64/libgallium-26.2.5.so')),('canonical_FLTK',r/('artifacts/sdk-20261111/toolkit-'+profile+'/lib/libfltk.so')),('real_OpenXR_loader',Path('/usr/lib64/libopenxr_loader.so.1'))]:
 st=f.stat();ident=g.current_identity(f);critical[key]=(ident['map_device'],st.st_ino);critical_stat[key]=(st.st_dev,st.st_ino)
seen=set();mapped={};dris={};app_owned={};all_owned={};app_pids=set();peak=0;t=time.monotonic();log=out/'process.log';active=None
try:
 with log.open('w')as stream:
  active=subprocess.Popen(command,env=env,cwd=bundle,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=g.no_core);state['pid']=active.pid;write(out/'status.json',state)
  while active.poll()is None:
   rss=0
   for pid in g.descendants(active.pid):
    ident=g.identity(pid)
    if not ident:continue
    all_owned[pid]=ident
    try:
     for line in Path('/proc',str(pid),'status').read_text().splitlines():
      if line.startswith('VmRSS:'):rss+=int(line.split()[1])*1024
     if Path('/proc',str(pid),'exe').resolve()==app:
      app_pids.add(pid);stage=out/('app-'+str(pid));stage.mkdir(exist_ok=True);g.monitor(types.SimpleNamespace(pid=pid),app_owned,critical,critical_stat,seen,mapped,dris,stage)
    except(FileNotFoundError,ProcessLookupError):pass
   peak=max(peak,rss);assert peak<=state['RSS_cap']and time.monotonic()-t<240;time.sleep(.01)
  code=active.wait()
 state.update(process_exit=code,seconds=time.monotonic()-t,peak_RSS=peak,actual_app_pids=sorted(app_pids),critical_observed=sorted(seen),log_sha256=sha(log));write(out/'status.json',state)
 report=json.loads((out/'workflow/report.json').read_text());assert code==0 and report['complete']and not report['error']and not report['drift']and all(x['passed']for x in report['checks']),(code,report)
 assert set(critical).issubset(seen);devices=sorted((out/'actual-device').glob('*/device.txt'));assert devices and all('Arc'in f.read_text()and'A770'in f.read_text()and'renderD129'in f.read_text()for f in devices);assert Path('/sys/dev/char/226:129/device/driver').resolve().name=='i915'
 text='\n'.join(x.read_text()for x in (out/'workflow').glob('**/app.log'));assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:',text)
 state.update(exit=0,checks=len(report['checks']),device_reports={str(f):sha(f)for f in devices},report_sha256=sha(out/'workflow/report.json'))
except BaseException as error:
 state.update(exit=1,error=repr(error))
 if active is not None and active.poll()is None:g.cleanup(active,all_owned)
finally:
 state.update(state='terminal',input_drift=[f for f,h in pins.items()if sha(f)!=h],provider_drift=[f for f,h in base['owned'].items()if sha(f)!=h]);state['exit']=state['exit']or int(bool(state['input_drift']or state['provider_drift']));write(out/'status.json',state);write(out/'mapped-app-ELFs.json',mapped);write(out/'readable-app-DRI.json',dris);fcntl.flock(lease,fcntl.LOCK_UN)
print(state['state'],state['exit'],str(out));raise SystemExit(state['exit'])
