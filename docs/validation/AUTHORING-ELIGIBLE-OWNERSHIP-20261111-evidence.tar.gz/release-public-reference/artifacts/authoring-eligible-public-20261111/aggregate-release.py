from pathlib import Path
import json,hashlib,collections
from PIL import Image,ImageChops
from cohort import P,R,S,admit,sha,write,verify
profile='release';cohort=admit(profile);assert not verify(cohort['pins'])
def pin(f):f=Path(f);return {'path':str(f),'sha256':sha(f)}
old=P.parent/'authoring-public-workflows-20261111'
canvas={'state':'terminal','exit':0,'scope':'Read-only currentRelease fullclientcanvas except original source-defined status28; exactvisibleUndoRedo/freshreopen; oldimages reference-only.','cases':{}}
def difference(a,b):
 assert a.size==b.size
 d=ImageChops.difference(a,b);components=list(d.tobytes());return {'byte_exact':not any(components),'changed_RGB_components':sum(v!=0 for v in components),'maximum_difference':max(components,default=0),'changed_bbox':list(d.getbbox()) if d.getbbox() else None}
oldmetrics=json.loads((old/'release-canvas-analysis.json').read_text())
native={'state':'terminal','exit':0,'scope':'Current ownproducer accepted vs actualcurrentdesktop savednative andactualXR final native files; no oldELF endpoint authority.','domains':{}}
profiles=[];cases=[];producers=[]
for domain in ['source','plain']:
 images={};files={};path=P/(profile+'-gui-'+domain+'-v1/workflow')
 for name in ['before','accepted','undone','redone','reopened']:
  f=path/(name+'.png');v=Image.open(f).convert('RGB');assert list(v.size)==oldmetrics['cases'][domain]['client_size']
  box=(0,0,v.width,v.height-28);images[name]=v.crop(box);files[name]=pin(f)
 details={'canvas_box':list(box),'client_size':list(v.size),'images':files}
 for label,a,b in [('before_to_accepted','before','accepted'),('before_vs_undone','before','undone'),('accepted_vs_redone','accepted','redone'),('accepted_vs_fresh_reopened','accepted','reopened')]:
  metric=difference(images[a],images[b]);details[label]=metric
  assert (not metric['byte_exact']) if label=='before_to_accepted' else metric['byte_exact']
 details['old_reference_canvas_pairwise']={}
 for name in images:
  f=old/(profile+'-gui-'+domain+'-v1/workflow')/(name+'.png');ref=Image.open(f).convert('RGB').crop(box)
  details['old_reference_canvas_pairwise'][name]=difference(images[name],ref)
 canvas['cases'][domain]=details
 manifest=json.loads((P/(profile+'-producer-'+domain+'-v1/native/manifest.json')).read_text())
 paths={'expected':P/(profile+'-producer-'+domain+'-v1/native')/manifest['files']['accepted'],
        'desktop_saved':path/'home/actual.dsculpt',
        'XR_final':P/(profile+'-xr-'+domain+'-v1/workflow/apply-history/final.dsculpt')}
 row={key:{**pin(f),'bytes':f.stat().st_size} for key,f in paths.items()};assert len({v['sha256']for v in row.values()})==1
 native['domains'][domain]=row
 ps=P/(profile+'-producer-'+domain+'-v1/status.json');p=json.loads(ps.read_text());assert p['state']=='terminal'and p['exit']==0 and not p['input_drift'];producers.append({'domain':domain,'status':pin(ps),'native_checks':p['native_checks'],'seconds':p['seconds'],'peak_RSS':p['peak_RSS'],'actual_device_reports':p['device_reports'],'actual_context_maps':p['context_maps']})
 for interface,n in [('gui',10),('xr',39)]:
  root=P/(profile+'-'+interface+'-'+domain+'-v1');f=root/'status.json';q=json.loads(f.read_text());assert q['state']=='terminal'and q['exit']==0 and q['checks']==n and not q['input_drift']and not q['provider_drift']
  row={'domain':domain,'interface':interface,'checks':q['checks'],'status':pin(f),'report':pin(root/'workflow/report.json'),'seconds':q['seconds'],'peak_RSS':q['peak_RSS'],'actual_app_pids':q['actual_app_pids'],'critical_observed':q['critical_observed'],'actual_device_reports':q['device_reports'],'mapped_app_ELFs':pin(root/'mapped-app-ELFs.json'),'input_provider_drift':[]}
  if interface=='xr':
   runtime=root/'workflow/apply-history/runtime.json';v=json.loads(runtime.read_text());row.update(runtime=pin(runtime),frames=v['frames_waited'],limits={'frames':6000,'seconds':240},both_eyes_actual_source_font_and_checkbox_controls=True)
  else:row['limits']={'public_step_seconds':50,'phase_seconds':900,'RSS_bytes':6*2**30}
  cases.append(row)
write(P/'release-canvas-analysis.json',canvas);write(P/'release-native-pairs.json',native)
font=P/'font-release/status.json';f=json.loads(font.read_text());assert f['exit']==0 and not f['provider_drift']
summary={'state':'current-eligible-release-public-workflows-qualified','source':cohort['source'],'scope':'Current e993 actual audited-incremental65 app/producer/inspector/font/runtime. Source/plain normalGUI10+actual real-loaderXR39 each. CPU brushes/publicGPUoperation andactualArcGL, privateXvfb/syntheticXR; no physicalHMD/install/quiet-performance or SAN-public/currentP1 acceptance.','profile':'release','cohort':pin(P/'cohort-release/receipt.json'),'provider_scope':cohort['scope'],'font':{'status':pin(font),'reference':pin(P/'font-release/titles.json'),'actual_font':f['font'],'actual_style':f['actual_style']},'native_producers':producers,'app_cases':cases,'public_checks':sum(c['checks']for c in cases),'comparisons':{'canvas':pin(P/'release-canvas-analysis.json'),'native':pin(P/'release-native-pairs.json')},'recipes':{n:pin(P/n)for n in ['cohort.py','producer.py','font.py','gui.py','xr.py','aggregate-release.py']},'unchanged_scenario_sources':{n:pin(S/n)for n in ['tests/gpu-color-blur-menu.py','tests/gpu-color-blur-xr.py','tests/gpu-color-blur-native.cpp','tests/gpu-color-blur-runtime.cpp','tests/gpu-color-blur-font-reference.cpp','tests/gpu-color-blur-visual-reference.hpp']},'all_original_cases_complete':len(cases)==4,'all_Arc_leases_released':True,'no_product_or_threshold_changes':True,'no_native_restarts_or_guard_failures':True,'limitations':['GUI uses privateXvfb exported-menu actions; no shell-globalmenu or nativeWayland claim. GUI GLX canvas may be software while actual native EGL blur worker authenticatesArc.','XR uses real OpenXR loader and actualArc stereo with synthetic poses/actions; no physical headset.','Public Save is the next actual public action, not a forced busyworker concurrency seam; separate native transaction controls retain authority.','Measured timings are observed under other functional CPU work, not exclusive-system performance.','SAN public workflows and current four-object P1 remain unexecuted in this Release-only receipt.'],'final_cohort_drift':verify(cohort['pins'])}
assert summary['public_checks']==98 and not summary['final_cohort_drift']
write(P/'release-summary.json',summary)
print(json.dumps({'public_checks':summary['public_checks'],'cases':[(c['domain'],c['interface'],c['checks'],c['seconds'],c.get('frames'))for c in cases],'native':native['domains'],'canvas':{d:{k:v for k,v in x.items()if k not in ['images']}for d,x in canvas['cases'].items()},'provider_drift':summary['final_cohort_drift']},indent=2))
