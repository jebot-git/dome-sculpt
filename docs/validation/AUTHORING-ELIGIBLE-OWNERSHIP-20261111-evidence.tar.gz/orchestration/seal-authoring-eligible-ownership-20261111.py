#!/usr/bin/env python3
"""Docs-only evidence seal; reads frozen providers, runs no application/test/GPU."""
from pathlib import Path
import hashlib,json,subprocess,tarfile,gzip,io,time
ROOT=Path('/home/blux/de-xr/dome-sculpt');SRC=ROOT/'artifacts/authoring-eligible-seal-20261111';ART=ROOT/'artifacts';STAGE=ART/'authoring-eligible-ownership-evidence-20261111';STAGE.mkdir(exist_ok=True)
SOURCE='e9931f7286f75746af47d52f2d901b731510cbb5';BASE='e2efd373a319b477c56f4da96920d4d2f82de368';OWN=ART/'authoring-eligible-owning-20261111';OLD=ART/'authoring-query-owning-20261111';ARC=ART/'authoring-eligible-capacity-arc-20261111';PUB=ART/'authoring-eligible-public-20261111'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
def load(p):return json.loads(Path(p).read_text())
def copied(path,rel=None):
 path=Path(path);rel=Path(rel)if rel else path.relative_to(ART);dest=STAGE/rel;dest.parent.mkdir(parents=True,exist_ok=True);payload=path.read_bytes();dest.write_bytes(payload);assert sha(path)==sha(dest);return {'path':str(path),'archive_path':str(rel),'sha256':sha(path),'bytes':len(payload)}
def group(folder,extensions=('.json','.log','.xml','.py','.cpp','.hpp','.txt','.diff'),recursive=False):
 for p in sorted(folder.rglob('*')if recursive else folder.iterdir()):
  if p.is_file()and p.suffix in extensions:copied(p)
def reference(p):return {'path':str(p),'sha256':sha(p)}
assert subprocess.check_output(['git','merge-base','HEAD',BASE],cwd=SRC,text=True).strip()==BASE
assert not subprocess.check_output(['git','diff',BASE,'HEAD','--','src','include','assets','third_party','tests','CMakeLists.txt','docs/HANDOFF.md','docs/REQUIREMENTS.md','REQUIREMENTS.md'],cwd=SRC,text=True)
cutoff=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());profiles={};old_profiles={}
for profile in ['release','sanitize']:
 p=OWN/(profile+'-v3');closure=load(p/'status.json');audit=load(p/'audit.json');gates=load(OWN/(profile+'-gates/status.json'))
 assert closure['source']==SOURCE and closure['state']=='terminal'and closure['exit']==0 and not closure['audit_only']and not closure['pin_drift']and not closure['output_drift']
 assert len(closure['steps'])==63 and all(s['exit']==0 for s in closure['steps'])and len(closure['target_outputs'])==65
 assert sum(x['origin']=='fresh-currentcore-link'for x in closure['target_outputs'].values())==63 and sum(x['origin']=='byteexact-qualified-fresh2ef-consumer'for x in closure['target_outputs'].values())==2
 assert len(closure['borrowed_objects'])==307 and closure['qualified_core']['members']==192 and closure['qualified_core']['independently_equal_unchanged_members']==190
 assert len(closure['pins'])==7390 and closure['verified_sdk_pins']==418 and sha(p/'audit.json')==closure['audit_sha256']
 assert sum(row['uses_current_core']for row in closure['link_plan'].values())==58
 routes={route:sum(x['route']==route for x in closure['borrowed_objects'].values())for route in ['qualified2ef-completeTU','44be-completeTU-actual-recorded-o','a904-authenticated-unchanged-object']};assert list(routes.values())==[4,7,296]
 assert gates['state']=='terminal'and gates['exit']==0 and gates['source']==SOURCE and not gates['provider_drift']and gates['selected_results']=={'total':56,'required_total':56,'pass':56,'failed_or_skipped':[],'exit':0}
 assert [x['total']for x in gates['batch_results']]==[2,54]and [x['pass']for x in gates['batch_results']]==[2,54]
 for step in gates['steps']:
  assert step['exit']==0 and step['external_guard']is None;assert sha(OWN/(profile+'-gates')/(step['name']+'.log'))==step['log_sha256']
 assert [s['expected_controls']for s in gates['steps']if 'expected_controls'in s]==[27,373]
 assert gates['closure_status_path']==str(p/'status.json')and gates['closure_status_sha256']==sha(p/'status.json')
 for folder in [p,OWN/(profile+'-gates')]:group(folder)
 for name in ['CMakeCache.txt','compile_commands.json','CTestTestfile.cmake','cmake_install.cmake']:copied(p/'plan'/name)
 partial=load(OLD/profile/'status.json');resumed=load(OLD/(profile+'-resume/status.json'));oldgates=load(OLD/(profile+'-gates/status.json'))
 assert partial['state']=='terminal'and partial['exit']==1 and partial['error']=="AssertionError('-Wl,-soname,libdome-sculpt-texture-resolution-runtime.so')"and len(partial['fresh_objects'])==11 and len(partial['target_outputs'])==24
 assert resumed['state']=='terminal'and resumed['exit']==0 and len(resumed['target_outputs'])==65 and len(resumed['steps'])==41 and not resumed['pin_drift']and not resumed['output_drift']
 assert oldgates['state']=='terminal'and oldgates['exit']==1 and oldgates['source']=='44be6d0d7ffc4c7d7f94d9e629c3aa8ed69beb2e'and not oldgates['provider_drift']and oldgates['selected_results']['pass']==54 and oldgates['selected_results']['total']==56
 assert oldgates['selected_results']['failed_or_skipped']==['document-render-capacity','document-render-large-buffer']
 for folder in [OLD/profile,OLD/(profile+'-resume'),OLD/(profile+'-gates')]:group(folder)
 profiles[profile]={'closure':reference(p/'status.json'),'audit':reference(p/'audit.json'),'native_software':reference(OWN/(profile+'-gates/status.json')),'state':'terminal','exit':0,'actual_fresh_links':63,'retained_byteexact_qualified_current_consumers':2,'selected_outputs':65,'core_owning_targets':58,'genuine_independent_targets':7,'objects':307,'object_routes':routes,'core_member_count':192,'independently_equal_unchanged_core_members':190,'sdk_pins':418,'postchecked_pins_including_audit':7390,'historical_source_proof':closure['historical_source_proof'],'literal_asset_macro':closure['source_proof']['intentional_asset_macro'],'core_sha256':closure['core_archive']['sha256'],'native_software_suites':56,'version_exit':0,'workspaces':[27,373],'all_original_guard_limits':gates['limits'],'runtime_environment':gates['environment'],'all_drift_lists_empty':True,'actual_link_seconds_not_performance':sum(x['seconds']for x in closure['steps'])}
 old_profiles[profile]={'source':oldgates['source'],'raw_partial_soname_driver_failure':reference(OLD/profile/'status.json'),'partial_exit':1,'completed_compiled_TUs':11,'completed_links_before_driver_refusal':24,'raw_resume':reference(OLD/(profile+'-resume/status.json')),'resume_exit':0,'additional_links_without_recompiling':41,'raw_gates':reference(OLD/(profile+'-gates/status.json')),'raw_gates_exit':1,'actual_native_software_pass':54,'actual_native_software_total':56,'preserved_failures':oldgates['selected_results']['failed_or_skipped'],'meaning':'Old44be scope only; no current e993 success is attributed to these raw records.'}
for name in ['build-closure.py','build-closure-v2.py','build-closure-v3.py','run-gates.py']:copied(OWN/name)
for name in ['build-closure.py','resume-links.py','run-gates.py']:copied(OLD/name)
for name in ['release','release-v2']:
 group(OWN/name)
for name in ['build-closure.py','build-closure-v2.py','build-closure-v3.py']:
 pass
v1=load(OWN/'release/audit.json');v2=load(OWN/'release-v2/audit.json');assert v1['exit']==1 and not v1['pin_drift']and v2['exit']==0 and not v2['pin_drift'];assert sha(OWN/'build-closure-v3.py')=='770244da50fb38fdb3f6ec2776cef2d297999d3abd4c063593272cfe3dcfc535'
arc_summary=load(ARC/'summary.json');assert arc_summary['exit']==0 and arc_summary['source']==SOURCE and len(arc_summary['case_records'])==4
group(ARC)
arc_records=[]
for profile in ['release','sanitize']:
 for case in ['original','large']:
  p=ARC/(profile+'-'+case);d=load(p/'status.json');assert d['state']=='terminal'and d['exit']==0 and d['native_exit']==0 and d['actual_device_authenticated']and d['native_check_count_exact']and not d['guard']and not d['sanitizer_diagnostics']
  assert not d['input_drift']and not d['source_drift']and not d['output_drift']and not d['mapped_ELF_provider_drift'];assert d['source']==SOURCE and d['performance_claim']is False
  assert d['limits']=={'seconds':240,'rss_bytes':(4 if profile=='release'else 8)*1024**3};assert d['expected_original_native_checks']==(64 if case=='original'else 63)
  assert all(x['first_live_mapped_sha256']==x['sha256']for x in d['mapped_ELF_providers'].values());assert sha(p/'process.log')==d['process_log_sha256']
  if profile=='sanitize':assert d['environment']['ASAN_OPTIONS']=='detect_leaks=1:halt_on_error=1:abort_on_error=1'and d['environment']['LSAN_OPTIONS']is None and d['environment']['LD_PRELOAD'].startswith('/usr/lib64/libasan.so.8:')
  group(p,recursive=True);arc_records.append({'status':reference(p/'status.json'),'profile':profile,'case':case,'native_checks':d['expected_original_native_checks'],'exit':0,'actual_device_authenticated':True,'mapped_ELFs_first_live_and_posthash':len(d['mapped_ELF_providers']),'seconds_functional_only':d['seconds'],'maxrss_bytes':d['maxrss_bytes'],'limits':d['limits'],'lease_released':d['lease_released_epoch']>d['lease_acquired_epoch'],'all_drift_lists_empty':True})
# The Release public summary is a scoped reference. SAN public and P1 are not
# inspected or claimed by this seal, even if later work creates their receipts.
public=load(PUB/'release-summary.json');assert public['source']==SOURCE and public['public_checks']==98 and public['all_original_cases_complete']and public['all_Arc_leases_released']and not public['final_cohort_drift']
assert sum(row['checks']for row in public['app_cases'])==98 and len(public['app_cases'])==4 and [row['checks']for row in public['app_cases']]==[10,39,10,39]
public_refs={}
def walk_refs(value):
 if isinstance(value,dict):
  if 'path'in value and 'sha256'in value:
   p=Path(value['path']);assert p.is_file()and sha(p)==value['sha256'],('Releasepublic referenced file changed',p);public_refs[str(p)]=value['sha256']
  for k,v in value.items():
   if isinstance(k,str)and k.startswith('/')and isinstance(v,str)and len(v)==64:
    p=Path(k);assert p.is_file()and sha(p)==v;public_refs[str(p)]=v
   else:walk_refs(v)
 elif isinstance(value,list):
  for v in value:walk_refs(v)
walk_refs(public);copied(PUB/'release-summary.json')
for p,h in public_refs.items():
 p=Path(p)
 if p.suffix in ['.json','.log','.py','.cpp','.hpp','.txt']:
  copied(p,Path('release-public-reference')/p.relative_to(ROOT))
# Small public API counterfactual is independent and retains all three cohorts.
small=ART/'small-query-policy-counterfactual-20261111';group(small)
assert load(small/'status.json')['exit']==0 and load(small/'intermediate-c84.json')['raw_exit']!=0 and load(small/'fixed-2ef.json')['raw_exit']==0
assert (small/'native.log').read_bytes()==(small/'fixed-2ef.log').read_bytes()
# Current private query implementation+caller sources are text snapshots in
# the evidence archive, never modifications to main or the frozen source.
canonical=ART/'authoring-eligible-integration-20261111'
for rel in ['src/mesh-processing.cpp','src/material-visibility.cpp','src/packed-material-query.hpp','tests/packed-material-query.cpp','tests/document-render-capacity.cpp','src/render-store-ledger.hpp','src/sculpt-gpu-arena.hpp','src/render.cpp','include/dome/render.hpp']:
 copied(canonical/rel,Path('qualified-source')/rel)
for commit in ['38c7577d','ad73d6e9','2ef16028']:
 p=STAGE/'private-source-patches'/(commit+'.patch');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','--format=fuller','--binary',commit],cwd=canonical))
copied(Path(__file__),Path('orchestration')/Path(__file__).name)
receipt={'schema':1,'captured_UTC':cutoff,'documentation_branch_base_main':BASE,'candidate_source':SOURCE,'qualified_private_runtime_code':'2ef16028ae3928a7907f8f7fc46a76d673eb261d','scope':'Docs-only bounded current owning/runtime milestone. No source, handoff, requirements, main, frozen provider or canonical edits; no new tests, GPU, installation or session actions.','ownership':'Audited incremental integration, NOT a new zero-object fresh whole compilation.307 required object providers:4 qualified2ef complete TUs+7 complete44be manually compiled TUs at actual recorded-o+296 authenticated unchanged a904 objects.192-member core with190 independently byteequal unchanged members; exactly63 fresh links plus2 already fresh qualified matched consumers perprofile.58 targets really own current core,7 genuinely independent helpers retain original CMake dependency shapes.','profiles':profiles,'history':{'initial_v1_audit':{'receipt':reference(OWN/'release/audit.json'),'exit':1,'phase':'Preprocessor dependency-path metadata validation; compiler emitted tests/../src lexical path. No C++ compilation, link or GPU execution.','source_provider_drift':[]},'v2_audit':{'receipt':reference(OWN/'release-v2/audit.json'),'exit':0,'change':'Resolve actual filesystem dependency paths only; compiler -D literals remain exact.','scope':'307object/418SDK/63link+2matchedconsumer current-byte/flags/member proof; no execute.'},'v3_audits':{'script':reference(OWN/'build-closure-v3.py'),'change':'Explicitly authenticate all1654 old44be and1651 a904 source/public-header/asset/third-party/tool bytes against historical qualified provider receipt hashes, rather than only current clean Git/tree equality.','both_profiles_exit':0},'old44be':old_profiles,'small_query_counterfactual':{'old44be_actual_exit':0,'intermediate_c84_actual_exit':1,'fixed2ef_actual_exit':0,'input':'Same public-header TU/object;65000coplanar triangles/eight nonmatching exclusions, four legacy/typed object/material calls.','old_and_fixed_log_sha256':sha(small/'native.log'),'raw_files':str(small)}},'limits_and_identity':{'standalone_SurfaceQuery_structural_vertex_and_triangle_caps':2000000,'packed_retained_CPU_bytes':512*1024**2,'packed_retained_plus_build_peak_CPU_bytes':768*1024**2,'packed_max_parts':128,'packed_triangles_per_part':262144,'packed_total_BVH_nodes':4194304,'packed_interval_sidecar_bytes_per_node':8,'legacy_default_closest_total_triangle_tests':2000000,'filtered_and_mixed_total_triangle_tests':65536,'new_partitioned_metadata_policy_tests':262144,'small_delegated_metadata_policy':'New comparison charge disabled; original standalone/small/mixed behavior retained.','capacity_case_geometry_endpoint_TEST_BOUND_bytes':512*1024**2,'actual_flat_ContextStoreLedger_default_geometry_limit_bytes':1024*1024**2,'actual_SculptGpuArena_separate_hard_GPU_limit_bytes':512*1024**2,'actual_material_default_bytes':1024*1024**2,'actual_material_default_images':1024,'actual_material_default_samplers':128,'ledger_max_stores':65536,'ledger_CPU_metadata_bytes':128*1024**2,'budget_wording_correction':'Earlier PACKED-MATERIAL-QUERY note called512MiB the flat geometry budget. It is the capacity test endpoint envelope; actual flat ledger default is1GiB, while the separate sculpt arena hardcap is512MiB. No cap, native data, assertions or result changed.','identity':'All original native draw arrays/material/source/global triangle IDs,barycentrics,normal/UV/color/paint authority retained.Eligibility skips only min/max intervals proved wholly ineligible under known object/material policy. Arbitrary filters spend the unchanged shared budget; alpha/dynamicUV never imply coarse eligibility.'},'actual_capacity':{'ordinary_vertices':4800012,'ordinary_VBO_bytes':230400576,'ordinary_EBO_bytes':72,'large_vertices':9600024,'large_VBO_bytes':460801152,'large_EBO_bytes':144,'indexed_vertices':1083603,'indexed_indices':6480000,'indexed_VBO_bytes':52012944,'indexed_EBO_bytes':25920000,'actual_vertex_streams':['position12','normal12','UV0_8','canonical_tangent16'],'full_native_inputs_and_exact_pixel_bary_picking_recovery_zero_eye_assertions_unchanged':True},'Arc_functional_cases':arc_records,'Arc_scope':'Actual IntelArcA770/DG2 GL4.6, current EGLDevice to PCI0000:03:00.0/8086:56a0/renderD129, actual open DRM FDs and first-live/posthash mapped ELF identities; observational unchanged-result GL query only. Four separately released common-flock leases. Functional under permitted CPU contention, NOT quiet performance/P1.','Release_public_reference':{'summary':reference(PUB/'release-summary.json'),'verified_referenced_file_hashes':len(public_refs),'public_checks':98,'source_plain_GUI10_and_XR39_each':True,'native_producer_checks':[57853,67677],'font':'Actual current bitmap Unifont17.0.04,16pixels/unit1,dark/opacity255.','limitations':public['limitations'],'admission':'Only the verified Release summary is referenced; its own partial public scope is retained. Full SAN-public98 is not admitted by this seal.'},'remaining_not_admitted':['Full current public SAN98 workflow receipt','Current quiet full original four-object sustained P1','Main PRODUCT source admission and any install or physical headset acceptance','Original full layered painting/material/baking/source/projected/physical adapter objective'], 'full_goal_complete':False,'no_product_or_threshold_changes':True}
# Independent stdlib-only offline evidence verification, not an application test.
verify='''from pathlib import Path\nimport json,hashlib\nr=Path(__file__).resolve().parent\nm=json.loads((r/'MANIFEST.json').read_text())\nfor x in m:\n p=r/x['path'];assert p.is_file()and p.stat().st_size==x['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256']\nfor profile in ['release','sanitize']:\n root=r/'authoring-eligible-owning-20261111'\n c=json.loads((root/(profile+'-v3')/'status.json').read_text());assert c['exit']==0 and c['state']=='terminal'and not c['audit_only']and len(c['target_outputs'])==65 and len(c['steps'])==63 and not c['pin_drift']and not c['output_drift']\n g=json.loads((root/(profile+'-gates')/'status.json').read_text());assert g['exit']==0 and g['selected_results']['pass']==g['selected_results']['total']==56 and not g['provider_drift']and all(s['exit']==0 and s['external_guard']is None for s in g['steps'])\n o=json.loads((r/'authoring-query-owning-20261111'/(profile+'-gates')/'status.json').read_text());assert o['exit']==1 and o['selected_results']['pass']==54 and o['selected_results']['total']==56\n for case,n in [('original',64),('large',63)]:\n  a=json.loads((r/'authoring-eligible-capacity-arc-20261111'/(profile+'-'+case)/'status.json').read_text());assert a['exit']==a['native_exit']==0 and a['expected_original_native_checks']==n and a['actual_device_authenticated']and a['native_check_count_exact']and not a['guard']and not a['sanitizer_diagnostics']and not a['input_drift']and not a['output_drift']and not a['source_drift']and not a['mapped_ELF_provider_drift']\nprint('All evidence member hashes and unchanged raw positive/negative scopes verified; no application or GPU run.')\n'''
(STAGE/'verify-evidence.py').write_text(verify)
manifest=[{'path':str(p.relative_to(STAGE)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(STAGE.rglob('*'))if p.is_file()and p.name!='MANIFEST.json'];(STAGE/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['/usr/bin/python3',str(STAGE/'verify-evidence.py')],check=True)
archive=SRC/'docs/validation/AUTHORING-ELIGIBLE-OWNERSHIP-20261111-evidence.tar.gz';archive.parent.mkdir(parents=True,exist_ok=True)
with archive.open('wb')as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0)as zipped:
  with tarfile.open(mode='w',fileobj=zipped,format=tarfile.PAX_FORMAT)as tar:
   for p in sorted(STAGE.rglob('*')):
    if p.is_file():
     b=p.read_bytes();i=tarfile.TarInfo(str(p.relative_to(STAGE)));i.size=len(b);i.mtime=0;i.mode=0o644;i.uid=i.gid=0;i.uname=i.gname='';tar.addfile(i,io.BytesIO(b))
with tarfile.open(archive,'r:gz')as tar:
 assert len(tar.getmembers())==len(manifest)+1
 for row in manifest:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
receipt['evidence']={'path':str(archive.relative_to(SRC)),'sha256':sha(archive),'bytes':archive.stat().st_size,'members':len(manifest)+1,'all_members_fully_decoded_and_sha256_verified':True,'offline_verifier':'Extract archive then python3 verify-evidence.py; integrity/scope only, no application/GPU invocation.','binary_ELFs_and_native_saved_assets':'Retained in actual artifact paths, deliberately not packaged.'}
(SRC/'docs/validation/AUTHORING-ELIGIBLE-OWNERSHIP-20261111.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt['evidence'],indent=2))
