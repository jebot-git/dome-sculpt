#!/usr/bin/env python3
"""Actual current-provider native/software gates, preserving original bounds."""
import argparse, hashlib, json, os, re, signal, subprocess, time
from pathlib import Path
from xml.etree import ElementTree

ap=argparse.ArgumentParser();ap.add_argument('profile',choices=['release','sanitize']);ap.add_argument('--closure',type=Path);args=ap.parse_args()
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];BUILD=OUT/args.profile;PLAN=BUILD/'plan'
closure_path=args.closure.resolve() if args.closure else BUILD/'status.json'
closure=json.loads(closure_path.read_text())
assert closure['state']=='terminal' and closure['exit']==0 and not closure['audit_only']
assert not closure['pin_drift'] and not closure['output_drift']
DEST=OUT/(args.profile+'-gates');DEST.mkdir()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
pins=dict(closure['pins']);pins[str(Path(__file__).resolve())]=sha(Path(__file__).resolve())
pins.update({str(BUILD/obj):row['sha256'] for obj,row in closure['fresh_objects'].items()})
pins.update({row['path']:row['sha256'] for row in closure['target_outputs'].values()})
pins[str(BUILD/'libdome-sculpt-core.a')]=closure['core_archive']['sha256']
assert all(sha(p)==h for p,h in pins.items())
env=dict(os.environ,LD_LIBRARY_PATH=str(ROOT/'artifacts/sdk-20261111'/('toolkit-'+args.profile)/'lib')+':/usr/lib64',LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
for k in ['LD_PRELOAD','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS','DRI_PRIME','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','LIBGL_DRIVERS_PATH','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(k,None)
if args.profile=='sanitize':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
limit=(4 if args.profile=='release' else 8)*1024**3
state={'state':'running','profile':args.profile,'source':closure['source'],'scope':__doc__,
       'closure_status_path':str(closure_path),'closure_status_sha256':sha(closure_path),'limits':{'per_process_RSS_bytes':limit,'selected_tests_seconds':2400,'capacity_test_seconds':240,'default_test_seconds':180},
       'environment':{k:env.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS','LIBGL_ALWAYS_SOFTWARE','LP_NUM_THREADS']},'pins':pins,'steps':[]}
def write():
 p=DEST/'status.writing';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(DEST/'status.json')
def children(pid):
 try:direct=[int(x) for x in Path(f'/proc/{pid}/task/{pid}/children').read_text().split()]
 except (FileNotFoundError,ProcessLookupError):return []
 result=[]
 for child in direct:result.append(child);result.extend(children(child))
 return result
def run(name,cmd,timeout):
 start=time.monotonic();peak=0;guard=None;seen=set();log=DEST/(name+'.log')
 with log.open('wb') as f:
  p=subprocess.Popen(cmd,cwd=PLAN,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  state.update(phase=name,child_pid=p.pid);write()
  while p.poll() is None:
   current=[p.pid,*children(p.pid)];seen.update(current)
   for pid in current:
    try:
     rss=next(int(x.split()[1])*1024 for x in Path(f'/proc/{pid}/status').read_text().splitlines() if x.startswith('VmRSS:'));peak=max(peak,rss)
     if rss>limit:guard='preselected per-process RSS bound'
    except (FileNotFoundError,ProcessLookupError,StopIteration):pass
   if time.monotonic()-start>timeout:guard='original outer command deadline'
   if guard:
    for pid in reversed(current):
     try:os.kill(pid,signal.SIGTERM)
     except ProcessLookupError:pass
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:
     try:os.killpg(p.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     p.wait()
    break
   time.sleep(.1)
  rc=p.wait()
 row={'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start,'peak_individual_process_RSS':peak,'external_guard':guard,'observed_processes':sorted(seen),'log_sha256':sha(log)}
 state['steps'].append(row);write();return row
try:
 version=run('app-version',[closure['target_outputs']['dome-sculpt']['path'],'--version'],60)
 if version['exit'] or version['external_guard']:raise RuntimeError('Current owning app version execution failed')
 old=json.loads((ROOT/'artifacts/authoring-production-build-20261111'/(args.profile+'-selected-tests.json')).read_text())
 expected={x['name'] for x in old['tests']}|{'document-render-large-buffer','surface-query-callback-lifetime','packed-material-query'}
 assert len(expected)==56
 regex='^('+ '|'.join(re.escape(x) for x in sorted(expected))+')$'
 listing=subprocess.check_output(['ctest','--test-dir',str(PLAN),'--show-only=json-v1','-R',regex],env=env,text=True)
 (DEST/'selected-tests.json').write_text(listing)
 tests=json.loads(listing)['tests'];assert len(tests)==56 and {x['name'] for x in tests}==expected
 outputs={v['path'] for v in closure['target_outputs'].values()}
 for test in tests:
  assert test['command'][0] in outputs,(test['name'],test['command'])
  if test['name'] in ['document-render-capacity','document-render-large-buffer']:
   assert next(p['value'] for p in test['properties'] if p['name']=='TIMEOUT')==240
 state['selected_test_names']=sorted(expected);state['batch_results']=[];write()
 first={'surface-query-callback-lifetime','packed-material-query'}
 completed=set();failed=[]
 for name,names,deadline in [('new-query-native',first,360),('selected-native-software',expected-first,2400)]:
  batch_regex='^('+'|'.join(re.escape(x) for x in sorted(names))+')$';junit=DEST/(name+'.xml')
  row=run(name,['ctest','--test-dir',str(PLAN),'--output-on-failure','--timeout','180','--output-junit',str(junit),'-R',batch_regex],deadline)
  xml=ElementTree.parse(junit).getroot();cases=list(xml.iter('testcase'))
  assert len(cases)==len(names) and {c.attrib['name'] for c in cases}==names
  bad=[c.attrib['name'] for c in cases if c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None]
  completed.update(names);failed.extend(bad)
  state['batch_results'].append({'name':name,'total':len(names),'pass':len(names)-len(bad),'failed_or_skipped':bad,'exit':row['exit']})
  state['selected_results']={'total':len(completed),'required_total':56,'pass':len(completed)-len(failed),'failed_or_skipped':failed,'exit':int(any(r['exit'] for r in state['batch_results']))};write()
  if row['external_guard']:raise RuntimeError(row['external_guard'])
  if name=='new-query-native' and (bad or row['exit']):raise RuntimeError('New native query controls failed; broad gates not started')
 assert completed==expected
 # These required scopes are not CTest registered. Keep their actual commands
 # even if a native regression fails; a resource/deadline guard stops further work.
 if row['external_guard']:raise RuntimeError(row['external_guard'])
 for target,controls in [('dome-sculpt-sculpt-chunk-workspace-test',27),('dome-sculpt-sculpt-placed-workspace-test',373)]:
  binary=closure['target_outputs'][target]['path'];r=run(target,[binary],300)
  r['expected_controls']=controls
  if r['exit']==0:
   ending='PASS total 27' if controls==27 else 'PASS 373 placed-owner workspace controls'
   assert (DEST/(target+'.log')).read_text().splitlines()[-1]==ending
  if r['external_guard']:raise RuntimeError(r['external_guard'])
 state['exit']=int(bool(failed) or any(r['exit'] or r['external_guard'] for r in state['steps']))
except Exception as error:state.update(exit=1,error=repr(error))
finally:
 state['provider_drift']=[p for p,h in pins.items() if not Path(p).is_file() or sha(p)!=h]
 if state['provider_drift']:state['exit']=1
 state['state']='terminal';write()
print(json.dumps({k:state.get(k) for k in ['state','profile','source','exit','error','phase','selected_results','provider_drift']}))
raise SystemExit(state['exit'])
