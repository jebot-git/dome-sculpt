#!/usr/bin/env python3
"""Build an audited incremental closure without mutating a904's owning outputs.

Not a fresh whole build: unchanged objects/archives come from the authenticated
complete a904 profile. Changed source, dependency or compile flags force a full
TU rebuild. All selected consumers are freshly linked against the new core.
Run only after the final integration source is committed and frozen.
"""
import argparse, hashlib, json, os, shlex, shutil, signal, subprocess, time
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('profile', choices=['release', 'sanitize'])
ap.add_argument('source_commit')
ap.add_argument('--additional-target', action='append', default=[])
ap.add_argument('--audit-only', action='store_true', help='Configure and validate all provider decisions; compile/link/run nothing.')
args = ap.parse_args()
OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = ROOT / 'artifacts/authoring-query-final-20261111'
OLD_SOURCE = ROOT / 'artifacts/authoring-production-union-20261111'
BASE = ROOT / 'artifacts/authoring-production-build-20261111' / args.profile
DEST = OUT / (args.profile + ('-audit' if args.audit_only else ''))
SDK = ROOT / 'artifacts/sdk-20261111' / ('toolkit-' + args.profile)

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def git(*cmd):
    return subprocess.check_output(['git', *cmd], cwd=SOURCE, text=True).strip()

assert git('rev-parse', 'HEAD') == args.source_commit
assert not git('status', '--porcelain')
delta = git('diff', '--name-only', 'a904a2d6', 'HEAD').splitlines()
product = [p for p in delta if p.startswith(('src/', 'include/', 'assets/', 'third_party/'))]
assert set(product) <= {'src/mesh-processing.cpp', 'src/material-visibility.cpp', 'src/packed-material-query.hpp'}, product
assert {'src/mesh-processing.cpp', 'src/material-visibility.cpp'} <= set(product)
baseline = json.loads((BASE.parent / (args.profile + '-owning-status.json')).read_text())
assert baseline['state'] == 'terminal' and not baseline['source_drift'] and not baseline['sdk_drift']
assert next(s for s in baseline['steps'] if s['name'] == 'build')['exit'] == 0
pins = dict(baseline['owned'])
pins[str(Path(__file__).resolve())] = sha(Path(__file__).resolve())
pins.update(json.loads((BASE.parent / 'sdk-pins.json').read_text()))
pins.update(json.loads((BASE.parent / 'source-before.json').read_text()))
pins.update({str(SOURCE / p): sha(SOURCE / p) for p in git('ls-files', '-z').split('\0') if p})
assert all(sha(p) == h for p, h in pins.items())
DEST.mkdir()  # Never overwrite a prior closure or an observation timeout.
PLAN = DEST / 'plan'
state = {'state': 'running', 'source': args.source_commit, 'profile': args.profile,
         'audit_only': args.audit_only,
         'scope': __doc__, 'product_delta': product, 'steps': [], 'fresh_objects': {},
         'borrowed_objects': {}, 'target_outputs': {}, 'pins': pins,
         'intentional_asset_macro': {
             'effective_root': str(OLD_SOURCE/'assets/humanoid'),
             'reason': 'Preserve the actual old runtime asset path for all consumers; asset bytes are unchanged and both source trees are pinned.',
             'original_plan_root': str(SOURCE/'assets/humanoid')}}

def write():
    temporary = DEST / 'status.writing'
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(DEST / 'status.json')

env = dict(os.environ, PKG_CONFIG_PATH='/usr/lib64/pkgconfig',
           LD_LIBRARY_PATH=str(SDK / 'lib') + ':/usr/lib64')
for k in ['LD_PRELOAD', 'ASAN_OPTIONS', 'LSAN_OPTIONS', 'UBSAN_OPTIONS']: env.pop(k, None)

class AuditComplete(Exception): pass

def run(name, cmd, cwd=DEST, timeout=1800):
    start = time.monotonic()
    log = DEST / (name + '.log')
    with log.open('wb') as f:
        p = subprocess.Popen(cmd, cwd=cwd, env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        state.update(phase=name, child_pid=p.pid); write()
        try: p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try: p.wait(timeout=3)
            except subprocess.TimeoutExpired: os.killpg(p.pid, signal.SIGKILL); p.wait()
            raise RuntimeError((name, 'explicit command deadline', timeout))
    row = {'name': name, 'command': cmd, 'exit': p.returncode, 'seconds': time.monotonic()-start,
           'log_sha256': sha(log)}
    state['steps'].append(row)
    write()
    if p.returncode: raise RuntimeError((name, p.returncode))

try:
    write()
    flags = '-O3 -DNDEBUG -ffunction-sections -fdata-sections' if args.profile == 'release' else '-O1 -g1 -DNDEBUG -ffunction-sections -fdata-sections -fsanitize=address,undefined -fno-omit-frame-pointer'
    linker = '-Wl,--gc-sections' + (' -fsanitize=address,undefined' if args.profile == 'sanitize' else '')
    run('configure', ['cmake', '-G', 'Ninja', '-S', str(SOURCE), '-B', str(PLAN),
                     '-DCMAKE_BUILD_TYPE=Release', '-DBUILD_TESTING=ON', '-DDOME_BUILD_UI=ON',
                     '-DDOME_BUILD_XR=ON', '-DDOME_COMPUTE_BACKEND=CPU', '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
                     '-DFLTK_DIR='+str(SDK/'share/fltk'), '-DCMAKE_CXX_FLAGS_RELEASE='+flags,
                     '-DCMAKE_EXE_LINKER_FLAGS='+linker], timeout=180)
    def commands(path):
        result = {}
        for item in json.loads((path/'compile_commands.json').read_text()):
            cmd = shlex.split(item['command'])
            # This is an explicit literal-preserving override, not a claim that
            # different embedded source asset paths are equivalent compiler flags.
            cmd = [x.replace(str(SOURCE/'assets/humanoid'), str(OLD_SOURCE/'assets/humanoid'))
                   if x.startswith('-DDOME_SCULPT_SOURCE_ASSETS=') else x for x in cmd]
            result[cmd[cmd.index('-o')+1]] = (item, cmd)
        return result
    old_cc, new_cc = commands(BASE), commands(PLAN)
    dep_text = subprocess.check_output(['ninja', '-C', str(BASE), '-t', 'deps'], text=True)
    deps, current = {}, None
    for line in dep_text.splitlines():
        if line and not line.startswith(' '):
            current = line.split(': #deps', 1)[0]; deps[current] = []
        elif current and line.startswith('    '): deps[current].append(line.strip())
    changed_old = {str(OLD_SOURCE/p) for p in delta}
    def normalized(cmd, source, build):
        # Preserve executable macro literals exactly. Normalize only build/input
        # path arguments; unequal macro tokens force complete recompilation.
        return [x if x.startswith('-D') else x.replace(str(source), '@SOURCE').replace(str(build), '@BUILD') for x in cmd]
    def archive_inputs(build, name):
        text = subprocess.check_output(['ninja', '-C', str(build), '-t', 'query', name], text=True)
        body = text.split('  outputs:', 1)[0]
        return [line.strip() for line in body.splitlines() if line.startswith('    ') and not line.strip().startswith('|')]
    archives, noncore_members = {}, set()
    for p in baseline['owned']:
        if not p.endswith('.a'): continue
        name = Path(p).name
        old_inputs, new_inputs = archive_inputs(BASE, name), archive_inputs(PLAN, name)
        assert old_inputs == new_inputs and all(x.endswith('.o') for x in old_inputs), name
        archives[name] = old_inputs
        if name != 'libdome-sculpt-core.a': noncore_members.update(old_inputs)
    state['archive_member_inputs'] = archives
    targets = list(dict.fromkeys(baseline['targets'] + args.additional_target))
    links = {}
    for target in targets:
        line = subprocess.check_output(['ninja', '-C', str(PLAN), '-t', 'commands', target], text=True).splitlines()[-1]
        tokens = shlex.split(line)
        assert tokens[:2] == [':', '&&'] and tokens[-2:] == ['&&', ':'], (target, tokens)
        links[target] = tokens[2:-2]
    needed = {x for cmd in links.values() for x in cmd if x.endswith('.o') and not x.startswith('/')}
    for members in archives.values(): needed.update(members)
    mapping = {}
    fresh = []
    for obj in sorted(needed):
        assert obj in new_cc, obj
        item, cmd = new_cc[obj]
        reusable = obj in old_cc and obj in deps and not changed_old.intersection(deps[obj])
        if reusable:
            reusable = normalized(cmd, SOURCE, PLAN) == normalized(old_cc[obj][1], OLD_SOURCE, BASE)
        if reusable:
            provider = BASE/obj; assert str(provider) in baseline['owned']
            mapping[obj] = str(provider); state['borrowed_objects'][obj] = {'provider': str(provider), 'sha256': sha(provider)}
        else:
            assert obj not in noncore_members, ('Non-core archive member affected; expand owning build before borrowing archive', obj)
            output = DEST/obj; output.parent.mkdir(parents=True, exist_ok=True)
            compile_cmd = list(cmd); compile_cmd[compile_cmd.index('-o')+1] = str(output)
            mapping[obj] = str(output); fresh.append((obj, compile_cmd))
    state['fresh_object_plan'] = [obj for obj, cmd in fresh]; write()
    if args.audit_only: raise AuditComplete()
    # Sequential compile avoids shared receipt races; each is a complete TU.
    for index, (obj, cmd) in enumerate(fresh):
        run('compile-'+str(index), ['nice', '-n', '10', *cmd], cwd=PLAN)
        state['fresh_objects'][obj] = {'sha256': sha(mapping[obj]), 'command': cmd}
    archive = DEST/'libdome-sculpt-core.a'
    shutil.copy2(BASE/archive.name, archive)
    members_before = subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines()
    replacements = [mapping[obj] for obj, cmd in fresh if obj.startswith('CMakeFiles/dome-sculpt-core.dir/')]
    assert replacements
    run('archive', ['ar', 'rcs', str(archive), *replacements])
    assert subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines() == members_before
    replaced_names = {Path(p).name for p in replacements}
    untouched = [name for name in members_before if name not in replaced_names]
    assert len(untouched) + len(replaced_names) == len(members_before)
    # Verify archive contents, not just the pre-copy archive and object paths.
    if untouched:
        old_members = subprocess.check_output(['ar', 'p', str(BASE/archive.name), *untouched])
        new_members = subprocess.check_output(['ar', 'p', str(archive), *untouched])
        assert old_members == new_members
    for replacement in replacements:
        assert subprocess.check_output(['ar', 'p', str(archive), Path(replacement).name]) == Path(replacement).read_bytes()
    state['core_archive'] = {'sha256': sha(archive), 'members': len(members_before), 'replaced': replacements}
    for target, cmd in links.items():
        cmd = list(cmd)
        output = PLAN/Path(cmd[cmd.index('-o')+1]).name
        for i, token in enumerate(cmd):
            if token in mapping: cmd[i] = mapping[token]
            elif token == archive.name: cmd[i] = str(archive)
            elif token.endswith(('.a', '.so')) and not token.startswith('/'):
                provider = BASE/token; assert str(provider) in baseline['owned'], token
                cmd[i] = str(provider)
            elif token.startswith('-Wl,--dependency-file='): cmd[i] = '-Wl,--dependency-file='+str(DEST/(target+'.link.d'))
        cmd[cmd.index('-o')+1] = str(output)
        run('link-'+target, ['nice', '-n', '10', *cmd], cwd=PLAN)
        state['target_outputs'][target] = {'path': str(output), 'sha256': sha(output)}
    state['exit'] = 0
except AuditComplete:
    state['exit'] = 0
except Exception as error:
    state.update(exit=1, error=repr(error))
finally:
    state['pin_drift'] = [p for p, h in pins.items() if not Path(p).is_file() or sha(p) != h]
    outputs = {str(DEST/obj): row['sha256'] for obj, row in state['fresh_objects'].items()}
    outputs.update({row['path']: row['sha256'] for row in state['target_outputs'].values()})
    if 'core_archive' in state: outputs[str(DEST/'libdome-sculpt-core.a')] = state['core_archive']['sha256']
    state['output_drift'] = [p for p,h in outputs.items() if not Path(p).is_file() or sha(p) != h]
    if state['pin_drift'] or state['output_drift']: state['exit'] = 1
    state['state'] = 'terminal'; write()
print(json.dumps({**{k:state.get(k) for k in ['state','source','profile','audit_only','exit','error','pin_drift','output_drift']},
                  'fresh_objects':len(state['fresh_objects']), 'borrowed_objects':len(state['borrowed_objects']),
                  'linked_targets':len(state['target_outputs'])}))
raise SystemExit(state['exit'])
