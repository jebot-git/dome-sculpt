#!/usr/bin/env python3
"""Finish a verified partial closure after the linker-option classification error.

Original status1 and all completed outputs remain untouched. No compilation;
already completed links are authenticated and reused, remaining links are fresh.
"""
import argparse,hashlib,json,os,shlex,signal,subprocess,time
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('profile',choices=['release','sanitize']);args=ap.parse_args()
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];BUILD=OUT/args.profile;PLAN=BUILD/'plan'
old_path=BUILD/'status.json';old=json.loads(old_path.read_text())
assert old['state']=='terminal' and old['exit']==1
assert old['error']=="AssertionError('-Wl,-soname,libdome-sculpt-texture-resolution-runtime.so')"
assert len(old['fresh_objects'])==11 and len(old['target_outputs'])==24
assert not old['pin_drift'] and not old['output_drift']
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
pins=dict(old['pins']);pins[str(old_path)]=sha(old_path);pins[str(Path(__file__).resolve())]=sha(Path(__file__).resolve())
pins.update({str(BUILD/obj):row['sha256'] for obj,row in old['fresh_objects'].items()})
pins.update({row['path']:row['sha256'] for row in old['target_outputs'].values()})
pins[str(BUILD/'libdome-sculpt-core.a')]=old['core_archive']['sha256']
assert all(sha(p)==h for p,h in pins.items())
DEST=OUT/(args.profile+'-resume');DEST.mkdir()
state={k:v for k,v in old.items() if k not in ['state','exit','error','phase','child_pid','pins','pin_drift','output_drift','steps','target_outputs']}
state.update(state='running',pins=pins,steps=[],target_outputs=dict(old['target_outputs']),
             origin_partial_status=str(old_path),origin_partial_status_sha256=sha(old_path),
             origin_partial_exit=1,scope=__doc__,resume_correction='Only plain relative .a/.so filenames are mapped; -Wl,-soname is a literal compiler option.',
             already_linked_targets=list(old['target_outputs']))
def write():
 p=DEST/'status.writing';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(DEST/'status.json')
BASE=ROOT/'artifacts/authoring-production-build-20261111'/args.profile
baseline=json.loads((BASE.parent/(args.profile+'-owning-status.json')).read_text())
targets=list(dict.fromkeys(baseline['targets']+['dome-sculpt-surface-query-callback-lifetime-test','dome-sculpt-packed-material-query-test']))
assert len(targets)==65
mapping={obj:row['provider'] for obj,row in old['borrowed_objects'].items()}
mapping.update({obj:str(BUILD/obj) for obj in old['fresh_objects']})
env=dict(os.environ,LD_LIBRARY_PATH=str(ROOT/'artifacts/sdk-20261111'/('toolkit-'+args.profile)/'lib')+':/usr/lib64')
for k in ['LD_PRELOAD','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']:env.pop(k,None)
try:
 write()
 for target in targets:
  if target in old['target_outputs']:continue
  tokens=shlex.split(subprocess.check_output(['ninja','-C',str(PLAN),'-t','commands',target],text=True).splitlines()[-1]);assert tokens[:2]==[':','&&'] and tokens[-2:]==['&&',':'];cmd=tokens[2:-2]
  output=PLAN/Path(cmd[cmd.index('-o')+1]).name
  assert not output.exists(),('Never overwrite previous output',output)
  for i,token in enumerate(cmd):
   if token in mapping:cmd[i]=mapping[token]
   elif token=='libdome-sculpt-core.a':cmd[i]=str(BUILD/token)
   elif not token.startswith(('-','/')) and token.endswith(('.a','.so')):
    provider=BASE/token;assert str(provider) in baseline['owned'];cmd[i]=str(provider)
   elif token.startswith('-Wl,--dependency-file='):cmd[i]='-Wl,--dependency-file='+str(DEST/(target+'.link.d'))
  cmd[cmd.index('-o')+1]=str(output);command=['nice','-n','10',*cmd];start=time.monotonic();log=DEST/(target+'.log')
  with log.open('wb') as f:
   p=subprocess.Popen(command,cwd=PLAN,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);state.update(phase='link-'+target,child_pid=p.pid);write()
   try:p.wait(timeout=1800)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise RuntimeError((target,'explicit1800s link deadline'))
  state['steps'].append({'name':'link-'+target,'command':command,'exit':p.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(log)});write()
  if p.returncode:raise RuntimeError((target,p.returncode))
  state['target_outputs'][target]={'path':str(output),'sha256':sha(output)}
 assert set(state['target_outputs'])==set(targets)
 state['exit']=0
except Exception as error:state.update(exit=1,error=repr(error))
finally:
 state['pin_drift']=[p for p,h in pins.items() if not Path(p).is_file() or sha(p)!=h]
 state['output_drift']=[r['path'] for r in state['target_outputs'].values() if not Path(r['path']).is_file() or sha(r['path'])!=r['sha256']]
 if state['pin_drift'] or state['output_drift']:state['exit']=1
 state['state']='terminal';write()
print(json.dumps({**{k:state.get(k) for k in ['state','source','profile','exit','error','pin_drift','output_drift']},'total_linked':len(state['target_outputs']),'links_this_resume':len(state['steps'])}))
raise SystemExit(state['exit'])
