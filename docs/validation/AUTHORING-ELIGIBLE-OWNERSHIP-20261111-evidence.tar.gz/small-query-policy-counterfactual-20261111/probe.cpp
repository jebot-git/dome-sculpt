// SPDX-License-Identifier: GPL-3.0-or-later
#include "dome/document.hpp"
#include "dome/material-visibility.hpp"
#include <array>
#include <iostream>
using namespace dome;
int main() try {
  Mesh mesh;
  mesh.positions={{-1,-1,0},{1,-1,0},{0,1,0}};
  mesh.normals.assign(3,{0,0,1});
  constexpr size_t triangles=65000;
  mesh.indices.reserve(3*triangles);
  for(size_t i=0;i<triangles;++i)mesh.indices.insert(mesh.indices.end(),{0,1,2});
  mesh.validate();
  Material material;material.double_sided=true;
  const SurfaceRange range{7,0,mesh.indices.size(),material};
  MaterialSurfaceQuery query(mesh,std::span(&range,1));
  const std::array<uint64_t,8> excluded{100,101,102,103,104,105,106,107};
  const std::array<SurfaceMaterialIdentity,8> materials{{{100,0},{101,0},{102,0},{103,0},{104,0},{105,0},{106,0},{107,0}}};
  auto valid=[](const SurfaceHit&hit){return hit.triangle<triangles&&hit.distance==2&&length(hit.position)<1e-6f&&hit.normal.z==1;};
  const auto legacy=query.raycast_excluding({0,0,2},{0,0,-1},5,0,excluded);
  if(!legacy||!valid(*legacy))throw std::runtime_error("Previously admitted small legacy exclusion query lost its actual hit");
  const auto typed=query.raycast_excluding_target({0,0,2},{0,0,-1},5,0,excluded);
  if(!typed||typed->object!=7||!typed->packed()||!valid(typed->surface))throw std::runtime_error("Previously admitted small typed exclusion query lost its actual hit");
  const auto slot=query.raycast_excluding_materials({0,0,2},{0,0,-1},5,0,materials);
  if(!slot||!valid(*slot))throw std::runtime_error("Previously admitted small material exclusion query lost its actual hit");
  const auto typed_slot=query.raycast_excluding_materials_target({0,0,2},{0,0,-1},5,0,materials);
  if(!typed_slot||typed_slot->object!=7||!valid(typed_slot->surface))throw std::runtime_error("Previously admitted small typed material exclusion query lost its actual hit");
  std::cout<<"PASS four actual small legacy/typed object/material exclusion calls;65000 native triangles,8 nonmatching exclusions, original65536 triangle budget\n";
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
