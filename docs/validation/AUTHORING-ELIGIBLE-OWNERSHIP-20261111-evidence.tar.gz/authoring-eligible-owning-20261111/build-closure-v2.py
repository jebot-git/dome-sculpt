#!/usr/bin/env python3
"""Audit, then link the frozen eligible authoring65-consumer owning closure.

No C++ compilation: four complete qualified2ef TUs and its current192-member
core are reused after byte/flags/member proofs; other providers come from the
qualified44be closure. All63 other consumers are freshly linked. The two already
fresh matched qualified2ef consumers are copied byteexact only after command
comparison. Execute requires the immutable successful audit and unchanged pins.
"""
import argparse,copy,hashlib,json,os,shlex,shutil,signal,subprocess,time
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['audit','execute']);ap.add_argument('profile',choices=['release','sanitize']);args=ap.parse_args()
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1];SOURCE=ROOT/'artifacts/authoring-eligible-integration-20261111';OLD_SOURCE=ROOT/'artifacts/authoring-query-final-20261111';ORIGINAL_SOURCE=ROOT/'artifacts/authoring-production-union-20261111';QUAL_SOURCE=ROOT/'artifacts/packed-query-eligibility-20261111';PROVIDER=ROOT/'artifacts/authoring-query-owning-20261111';QUAL=ROOT/'artifacts/packed-eligibility-final-proof-20261111'/args.profile;ORIGINAL=ROOT/'artifacts/authoring-production-build-20261111'/args.profile;DEST=OUT/(args.profile+'-v2');PLAN=DEST/'plan';SDK=ROOT/'artifacts/sdk-20261111'/('toolkit-'+args.profile);COMMIT='e9931f7286f75746af47d52f2d901b731510cbb5';RUNTIME='2ef16028ae3928a7907f8f7fc46a76d673eb261d'
QUAL_KEYS={'CMakeFiles/dome-sculpt-core.dir/src/mesh-processing.cpp.o':'compile-mesh-processing.cpp.o','CMakeFiles/dome-sculpt-core.dir/src/material-visibility.cpp.o':'compile-material-visibility.cpp.o','CMakeFiles/dome-sculpt-packed-material-query-test.dir/tests/packed-material-query.cpp.o':'compile-packed-material-query.cpp.o','CMakeFiles/dome-sculpt-document-render-capacity-test.dir/tests/document-render-capacity.cpp.o':'compile-document-render-capacity.cpp.o'}
QUAL_TARGETS={'dome-sculpt-packed-material-query-test','dome-sculpt-document-render-capacity-test'}
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(source,*cmd):return subprocess.check_output(['git',*cmd],cwd=source,text=True).strip()
def write_json(p,value):
 t=p.with_suffix('.writing');t.write_text(json.dumps(value,indent=2)+'\n');t.replace(p)
def checked_pins(pins):return [p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def archive_members(path):
 """Hash real GNU archive member payloads independently, without unpacking."""
 result=[];long_names=b''
 with Path(path).open('rb')as f:
  assert f.read(8)==b'!<arch>\n',('Unsupported nonordinary archive',path)
  while header:=f.read(60):
   assert len(header)==60 and header[58:]==b'`\n',path
   raw=header[:16].decode('ascii').strip();size=int(header[48:58]);start=f.tell()
   if raw=='//':long_names=f.read(size)
   elif raw in ['/','/SYM64/']:pass
   else:
    if raw.startswith('/'):
     offset=int(raw[1:]);end=long_names.index(b'/\n',offset);name=long_names[offset:end].decode()
    else:assert not raw.startswith('#1/'),('UnsupportedBSDmember',path);name=raw.rstrip('/')
    h=hashlib.sha256();remaining=size
    while remaining:
     data=f.read(min(1024*1024,remaining));assert data;h.update(data);remaining-=len(data)
    result.append({'name':name,'bytes':size,'sha256':h.hexdigest()})
   f.seek(start+size+(size%2))
 assert len(result)==len({r['name']for r in result}),('Duplicate member names',path)
 return result

env=dict(os.environ,PKG_CONFIG_PATH='/usr/lib64/pkgconfig',LD_LIBRARY_PATH=str(SDK/'lib')+':/usr/lib64')
for k in ['LD_PRELOAD','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']:env.pop(k,None)
def run(state,name,command,cwd=PLAN,timeout=1800):
 log=DEST/(name+'.log');start=time.monotonic()
 with log.open('wb')as f:
  proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);state.update(phase=name,child_pid=proc.pid);write_json(DEST/'status.json',state)
  try:proc.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGTERM)
   try:proc.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   raise RuntimeError((name,'explicitdeadline',timeout))
 state['steps'].append({'name':name,'command':command,'exit':proc.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(log)});write_json(DEST/'status.json',state)
 assert proc.returncode==0,(name,proc.returncode)
 return log

def compile_commands(build,asset_override=False):
 result={}
 for row in json.loads((build/'compile_commands.json').read_text()):
  cmd=shlex.split(row['command']);key=cmd[cmd.index('-o')+1]
  if asset_override:
   expected='-DDOME_SCULPT_SOURCE_ASSETS="'+str(SOURCE/'assets/humanoid')+'"'
   replacement='-DDOME_SCULPT_SOURCE_ASSETS="'+str(ORIGINAL_SOURCE/'assets/humanoid')+'"'
   for i,token in enumerate(cmd):
    if token.startswith('-DDOME_SCULPT_SOURCE_ASSETS='):assert token==expected,(key,token);cmd[i]=replacement
  result[key]=cmd
 return result

def normalized_compile(cmd,source,build):
 result=[];i=0
 while i<len(cmd):
  token=cmd[i]
  if token=='-o':result+=['-o','@OBJECT'];i+=2;continue
  # Preserve every literal -D token exactly, including the embedded asset path.
  if not token.startswith('-D'):token=token.replace(str(source),'@SOURCE').replace(str(build),'@BUILD')
  result.append(token);i+=1
 return result

def query_archive(build,name):
 txt=subprocess.check_output(['ninja','-C',str(build),'-t','query',name],text=True).split('  outputs:',1)[0]
 return [x.strip()for x in txt.splitlines()if x.startswith('    ')and not x.strip().startswith('|')]
def link_command(build,target):
 row=shlex.split(subprocess.check_output(['ninja','-C',str(build),'-t','commands',target],text=True).splitlines()[-1]);assert row[:2]==[':','&&']and row[-2:]==['&&',':'],(target,row);return row[2:-2]
def tree(source,folders):
 rows=git(source,'ls-files','-z',*folders).split('\0');return {r:sha(source/r)for r in rows if r}

def audit():
 assert git(SOURCE,'rev-parse','HEAD')==COMMIT and not git(SOURCE,'status','--porcelain')
 assert git(OLD_SOURCE,'rev-parse','HEAD')=='44be6d0d7ffc4c7d7f94d9e629c3aa8ed69beb2e'and not git(OLD_SOURCE,'status','--porcelain')
 assert not git(QUAL_SOURCE,'diff',RUNTIME,'HEAD','--','src','include','assets','third_party','tests','CMakeLists.txt')and not git(QUAL_SOURCE,'status','--porcelain')
 DEST.mkdir();state={'state':'running','source':COMMIT,'runtime_product':RUNTIME,'profile':args.profile,'audit_only':True,'scope':__doc__,'steps':[],'pins':{},'target_outputs':{},'fresh_objects':{},'borrowed_objects':{}}
 def pin(p,h=None):p=Path(p).resolve();value=sha(p);assert h is None or h==value,(str(p),h,value);state['pins'][str(p)]=value;return value
 try:
  state['pins'][str(Path(__file__).resolve())]=sha(__file__)
  old_path=PROVIDER/(args.profile+'-resume/status.json');old=json.loads(old_path.read_text());pin(old_path)
  assert old['state']=='terminal'and old['exit']==0 and not old['pin_drift']and not old['output_drift']and len(old['target_outputs'])==65
  qual=json.loads((QUAL/'build.json').read_text());pin(QUAL/'build.json');assert qual['exit']==0 and qual['source']==RUNTIME and not qual['source_drift']and not qual['provider_drift']
  assert not checked_pins(qual['pins'])and not checked_pins(qual['outputs'])and not checked_pins(qual['source_pins'])
  for mode in ['native','original','large']:
   p=QUAL/(mode+'.json');q=json.loads(p.read_text());pin(p);assert q['exit']==0 and not q['guard']and not q['source_drift']and not q['provider_drift']and not q['output_drift']and q['source']==RUNTIME
  sdk_path=ORIGINAL.parent/'sdk-pins.json';sdk=json.loads(sdk_path.read_text());pin(sdk_path)
  for p,h in sdk.items():pin(p,h)
  assert len(sdk)==418,len(sdk);state['verified_sdk_pins']=len(sdk)
  relevant=['src','include','assets','third_party','tests','CMakeLists.txt','cmake','tools']
  current=tree(SOURCE,relevant);before=tree(OLD_SOURCE,relevant);qualified=tree(QUAL_SOURCE,relevant)
  assert set(current)==set(before)==set(qualified)
  assert current==qualified,('Canonical runtime/source not byteexact qualified runtime',[(p,current[p],qualified[p])for p in current if current[p]!=qualified[p]])
  changed=sorted(p for p in current if current[p]!=before[p]);assert changed==['src/material-visibility.cpp','src/mesh-processing.cpp','src/packed-material-query.hpp','tests/document-render-capacity.cpp','tests/packed-material-query.cpp'],changed
  for source,fingerprint in [(SOURCE,current),(OLD_SOURCE,before),(QUAL_SOURCE,qualified)]:
   for p,h in fingerprint.items():pin(source/p,h)
  # Literal runtime source assets stay the old compiled root. Prove the entire
  # effective asset tree is byteidentical; no other -D differences are ignored.
  assets={p:h for p,h in current.items()if p.startswith('assets/')};original_assets=tree(ORIGINAL_SOURCE,['assets']);assert assets==original_assets
  for p,h in original_assets.items():pin(ORIGINAL_SOURCE/p,h)
  state['source_proof']={'changed_since44be':changed,'canonical_equals_qualified_relevant_tree':True,'public_headers_byteidentical':True,'relevant_files':len(current),'intentional_asset_macro':{'effective_root':str(ORIGINAL_SOURCE/'assets/humanoid'),'configured_root':str(SOURCE/'assets/humanoid'),'exact_asset_files':len(assets),'semantics':'The exact old literal token is used for command comparison/reuse. Full asset bytes are pinned/equal; no other -D token is normalized.'}}
  flags='-O3 -DNDEBUG -ffunction-sections -fdata-sections'if args.profile=='release'else'-O1 -g1 -DNDEBUG -ffunction-sections -fdata-sections -fsanitize=address,undefined -fno-omit-frame-pointer'
  linker='-Wl,--gc-sections'+(' -fsanitize=address,undefined'if args.profile=='sanitize'else'')
  run(state,'configure',['cmake','-G','Ninja','-S',str(SOURCE),'-B',str(PLAN),'-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON','-DDOME_BUILD_UI=ON','-DDOME_BUILD_XR=ON','-DDOME_COMPUTE_BACKEND=CPU','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DFLTK_DIR='+str(SDK/'share/fltk'),'-DCMAKE_CXX_FLAGS_RELEASE='+flags,'-DCMAKE_EXE_LINKER_FLAGS='+linker],cwd=DEST,timeout=180)
  current_cc=compile_commands(PLAN,True);original_cc=compile_commands(ORIGINAL)
  targets=list(old['target_outputs']);assert len(targets)==65
  links={t:link_command(PLAN,t)for t in targets};archives=old['archive_member_inputs'];needed={x for cmd in links.values()for x in cmd if x.endswith('.o')and not x.startswith(('-','/'))}
  for name,inputs in archives.items():
   assert query_archive(PLAN,name)==inputs,(name,'archive input changed');needed.update(inputs)
  deps_text=subprocess.check_output(['ninja','-C',str(ORIGINAL),'-t','deps'],text=True);deps={};node=None
  for line in deps_text.splitlines():
   if line and not line.startswith(' '):node=line.split(': #deps',1)[0];deps[node]=[];assert 'VALID'in line,(node,line)
   elif node and line.startswith('    '):deps[node].append(line.strip())
  pin(ORIGINAL/'.ninja_deps');pin(ORIGINAL/'compile_commands.json')
  source_diff_from_original={p for p,h in current.items()if not (ORIGINAL_SOURCE/p).exists()or sha(ORIGINAL_SOURCE/p)!=h}
  mapping={};object_proof={}
  qsteps={x['name']:x for x in qual['steps']}
  for key in sorted(needed):
   assert key in current_cc,key;newcmd=current_cc[key];route=''
   if key in QUAL_KEYS:
    row=qsteps[QUAL_KEYS[key]];cmd=row['command'];provider=Path(cmd[cmd.index('-o')+1]);assert row['exit']==0;expected=qual['outputs'][str(provider)];source=QUAL_SOURCE;build=QUAL;route='qualified2ef-completeTU'
   elif key in old['fresh_objects']:
    row=old['fresh_objects'][key];cmd=row['command'];provider=Path(cmd[cmd.index('-o')+1]);expected=row['sha256'];source=OLD_SOURCE;build=PROVIDER/args.profile;route='44be-completeTU-actual-recorded-o'
    # These seven complete manually compiled TUs have no Ninja deps. Obtain
    # preprocessing-only dependency metadata from their exact literal command.
    probe=list(cmd);pos=probe.index('-o');del probe[pos:pos+2];probe.remove('-c');probe+=['-M','-MT','__DOME_AUDIT__'];log=run(state,'deps-'+Path(key).name,probe,timeout=180)
    text=log.read_text().replace('\\\n',' ');tokens=shlex.split(text);assert tokens[0]=='__DOME_AUDIT__:',key
    own_deps=tokens[1:];changed_deps=[]
    for dependency in own_deps:
     p=Path(dependency).resolve()
     if p.is_relative_to(OLD_SOURCE):
      rel=str(p.relative_to(OLD_SOURCE));assert rel in current;pin(p,before[rel]);assert sha(p)==current[rel],(key,'Changed dependency',rel)
     elif p.is_relative_to(SDK):pin(p)
    object_proof[key]={'dependency_probe_log':str(log),'dependency_probe_sha256':sha(log),'dependency_count':len(own_deps)}
   else:
    row=old['borrowed_objects'][key];provider=Path(row['provider']);expected=row['sha256'];cmd=original_cc[key];source=ORIGINAL_SOURCE;build=ORIGINAL;route='a904-authenticated-unchanged-object'
    assert key in deps and deps[key],('Unknown dependencies require owning rebuild',key)
    for dependency in deps[key]:
     p=Path(dependency).resolve()
     if p.is_relative_to(ORIGINAL_SOURCE):
      rel=str(p.relative_to(ORIGINAL_SOURCE));assert rel not in source_diff_from_original,(key,'Changed original source dependency',rel);pin(p,current[rel])
     elif p.is_relative_to(SDK):pin(p)
    object_proof[key]={'recorded_dependency_count':len(deps[key])}
   assert normalized_compile(newcmd,SOURCE,PLAN)==normalized_compile(cmd,source,build),(key,'Compiler command difference',normalized_compile(newcmd,SOURCE,PLAN),normalized_compile(cmd,source,build))
   pin(provider,expected);mapping[key]=str(provider);state['borrowed_objects'][key]={'provider':str(provider),'sha256':expected,'route':route};object_proof.setdefault(key,{}).update(route=route,provider=str(provider),sha256=expected,command=cmd,planned_command=newcmd,flags_match_with_literal_macros=True)
  state['object_proof']=object_proof
  old_core=PROVIDER/args.profile/'libdome-sculpt-core.a';pin(old_core,old['core_archive']['sha256']);qcore=QUAL/'libdome-sculpt-core.a';pin(qcore,qual['core']['sha256']);old_members=archive_members(old_core);new_members=archive_members(qcore);assert [x['name']for x in old_members]==[x['name']for x in new_members]and len(new_members)==192
  replaced={Path(mapping[k]).name for k in QUAL_KEYS if k.startswith('CMakeFiles/dome-sculpt-core.dir/')};assert replaced=={'mesh-processing.cpp.o','material-visibility.cpp.o'}
  for a,b in zip(old_members,new_members):
   if a['name']not in replaced:assert a==b,('Unchanged core member drift',a,b)
   else:assert b['sha256']==sha(next(Path(p)for k,p in mapping.items()if k.startswith('CMakeFiles/dome-sculpt-core.dir/')and Path(p).name==b['name']))
  state['qualified_core']={'provider':str(qcore),'sha256':sha(qcore),'members':192,'independently_equal_unchanged_members':190,'replaced':sorted(replaced),'member_payloads':new_members}
  noncore={}
  for name,inputs in archives.items():
   if name=='libdome-sculpt-core.a':continue
   provider=ORIGINAL/name;assert str(provider)in old['pins'];pin(provider,old['pins'][str(provider)]);actual=archive_members(provider);expected_members=[{'name':Path(mapping[key]).name,'bytes':Path(mapping[key]).stat().st_size,'sha256':sha(mapping[key])}for key in inputs];assert actual==expected_members,(name,'Noncore member proof mismatch');noncore[name]={'provider':str(provider),'sha256':sha(provider),'members':actual}
  state['noncore_archives']=noncore;state['targets']=targets
  output_names={t:Path(cmd[cmd.index('-o')+1]).name for t,cmd in links.items()};by_output={n:t for t,n in output_names.items()};assert len(by_output)==65
  commands={};dependencies={}
  for target,raw in links.items():
   cmd=list(raw);required=[];output_index=cmd.index('-o')+1
   for i,token in enumerate(cmd):
    if i==output_index:continue
    if token in mapping:cmd[i]=mapping[token]
    elif token=='libdome-sculpt-core.a':cmd[i]=str(DEST/'libdome-sculpt-core.a')
    elif not token.startswith(('-','/'))and token.endswith(('.a','.so')):
     if token in noncore:cmd[i]=noncore[token]['provider']
     elif token in by_output:required.append(by_output[token]);cmd[i]=str(PLAN/token)
     else:raise AssertionError((target,'Unknown relative link provider',token))
    elif token.startswith('-Wl,--dependency-file='):cmd[i]='-Wl,--dependency-file='+str(DEST/(target+'.link.d'))
   cmd[cmd.index('-o')+1]=str(PLAN/output_names[target])
   for token in cmd:
    if token.startswith('/')and Path(token).is_file()and token not in [str(PLAN/output_names[target]),str(DEST/'libdome-sculpt-core.a')]:pin(token)
   commands[target]=cmd;dependencies[target]=required
  # All newly linked consumers use the selected current core where the real
  # CMake target owns one. Standalone helper/kernel targets keep their real
  # dependency shape rather than gaining an unrelated forced core dependency.
  state['link_plan']={t:{'command':commands[t],'output':str(PLAN/output_names[t]),'uses_current_core':str(DEST/'libdome-sculpt-core.a')in commands[t],'depends_on_targets':dependencies[t]}for t in targets}
  def normalized_link(cmd,object_path,core_path):
   cmd=list(cmd)
   if cmd[:3]==['nice','-n','10']:cmd=cmd[3:]
   result=[];i=0
   while i<len(cmd):
    token=cmd[i]
    if token=='-o':result+=['-o','@OUTPUT'];i+=2;continue
    if token.startswith('-Wl,--dependency-file='):i+=1;continue
    if token==object_path:token='@MATCHED_OBJECT'
    if token==core_path:token='@MATCHED_CORE_BYTES'
    result.append(token);i+=1
   return result
  state['retained_consumers']={}
  for target in QUAL_TARGETS:
   key=next(k for k in QUAL_KEYS if '/'+target+'.dir/'in k);qcmd=qsteps['link-'+target]['command'];provider=QUAL/target;pin(provider,qual['outputs'][str(provider)])
   assert normalized_link(commands[target],mapping[key],str(DEST/'libdome-sculpt-core.a'))==normalized_link(qcmd,mapping[key],str(qcore)),(target,'Retained consumer linker command mismatch',commands[target],qcmd)
   state['retained_consumers'][target]={'provider':str(provider),'sha256':sha(provider),'command':qcmd,'new_plan_command':commands[target],'explicit_nonELF_difference':'Only output location and linker dependency-file reporting are ignored; all ELF-producing flags/inputs, literal macros, matchedobject/core bytes and external providers match.'}
  completed=set(QUAL_TARGETS);order=[]
  pending=[t for t in targets if t not in completed]
  while pending:
   ready=next((t for t in pending if set(dependencies[t])<=completed),None);assert ready is not None,('Dependency cycle',pending);order.append(ready);completed.add(ready);pending.remove(ready)
  assert len(order)==63;state['fresh_link_order']=order;state['source_pins']={str(SOURCE/p):h for p,h in current.items()}
  for p in [PLAN/'compile_commands.json',PLAN/'CMakeCache.txt',PLAN/'build.ninja',PLAN/'CTestTestfile.cmake',PLAN/'cmake_install.cmake']:pin(p)
  state.update(state='terminal',phase='audited-no-links',exit=0,pin_drift=checked_pins(state['pins']),output_drift=[]);assert not state['pin_drift'];write_json(DEST/'audit.json',state);write_json(DEST/'status.json',state)
 except Exception as e:
  state.update(state='terminal',exit=1,error=repr(e),pin_drift=checked_pins(state['pins']),output_drift=[]);write_json(DEST/'audit.json',state);write_json(DEST/'status.json',state);raise
 print(json.dumps({'source':state['source'],'profile':args.profile,'audit_exit':state['exit'],'objects':len(state['borrowed_objects']),'verified_sdk_pins':state.get('verified_sdk_pins'),'fresh_link_plan':len(state.get('fresh_link_order',[])),'retained_fresh_matched_consumers':len(state.get('retained_consumers',{})),'pin_drift':state['pin_drift']}))

def execute():
 path=DEST/'audit.json';audited=json.loads(path.read_text());assert audited['state']=='terminal'and audited['audit_only']and audited['exit']==0 and not audited['pin_drift']and len(audited['fresh_link_order'])==63
 assert git(SOURCE,'rev-parse','HEAD')==COMMIT and not git(SOURCE,'status','--porcelain');assert not checked_pins(audited['pins'])
 state=copy.deepcopy(audited);state.update(state='running',audit_only=False,phase='stage-qualifiedcore',steps=[],target_outputs={},audit_path=str(path),audit_sha256=sha(path));state['pins'][str(path)]=sha(path)
 try:
  core=DEST/'libdome-sculpt-core.a';assert not core.exists();shutil.copy2(state['qualified_core']['provider'],core);assert sha(core)==state['qualified_core']['sha256'];state['core_archive']={'sha256':sha(core),'members':192,'replaced':[],'reused_byteexact_qualified_source':RUNTIME,'independently_proven_unchanged_members':190}
  for target,row in state['retained_consumers'].items():
   output=Path(state['link_plan'][target]['output']);assert not output.exists();shutil.copy2(row['provider'],output);assert sha(output)==row['sha256'];state['target_outputs'][target]={'path':str(output),'sha256':sha(output),'origin':'byteexact-qualified-fresh2ef-consumer'}
  write_json(DEST/'status.json',state)
  for target in state['fresh_link_order']:
   row=state['link_plan'][target];assert not Path(row['output']).exists();assert set(row['depends_on_targets'])<=state['target_outputs'].keys();run(state,'link-'+target,['nice','-n','10',*row['command']]);state['target_outputs'][target]={'path':row['output'],'sha256':sha(row['output']),'origin':'fresh-currentcore-link'};write_json(DEST/'status.json',state)
  assert len(state['target_outputs'])==65;state['exit']=0
 except Exception as e:state.update(exit=1,error=repr(e))
 finally:
  state['pin_drift']=checked_pins(state['pins']);outputs={r['path']:r['sha256']for r in state['target_outputs'].values()}
  if 'core_archive'in state:outputs[str(DEST/'libdome-sculpt-core.a')]=state['core_archive']['sha256']
  state['output_drift']=checked_pins(outputs)
  if state['pin_drift']or state['output_drift']:state['exit']=1
  state.update(state='terminal',phase='terminal');write_json(DEST/'status.json',state)
 print(json.dumps({k:state.get(k)for k in ['source','profile','exit','error','pin_drift','output_drift']}));raise SystemExit(state['exit'])
if args.mode=='audit':audit()
else:execute()
