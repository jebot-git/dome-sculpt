from pathlib import Path
import os
import subprocess

work = Path(__file__).resolve().parent
public = work.parent / "creator-public-build-20261126"
build = work / "release"
fixture = build / "texture-set-retained-shapekeys"
env = {
    "PATH": str(public / "private-bin-v3") + ":/usr/bin:/bin",
    "HOME": "/tmp",
    "PYTHONPATH": str(public / "private-python"),
    "PYTHONDONTWRITEBYTECODE": "1",
    "LD_LIBRARY_PATH": ("/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:"
                        + str(public / "private-x11/usr/lib64") + ":/usr/lib64"),
    "LP_NUM_THREADS": "2",
    "DOME_CAGE_WL_OUT": str(work / "wayland"),
    "DOME_CAGE_APP": str(build / "dome-sculpt"),
    "DOME_COMPOSITOR": str(public / "wayland-reference/dome-compositor"),
    "DOME_ACCESSORY_PROJECT": str(fixture / "prepared-before.dsculpt"),
    "DOME_ACCESSORY_REFERENCE": str(fixture / "prepared-neutral-default.dsculpt"),
}
args = ["bwrap", "--die-with-parent", "--unshare-all", "--ro-bind", "/", "/",
        "--bind", work, work, "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
        "--tmpfs", "/run/user", "--clearenv"]
for key, value in env.items():
    args.extend(["--setenv", key, value])
with (work / "wayland.log").open("w") as log:
    subprocess.run([*args, "/usr/bin/python3.14", work / "wayland-shape.py"],
                   stdout=log, stderr=subprocess.STDOUT, check=True, timeout=180)
