from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parents[1]
dest = repo / "docs" / "validation"
stem = "retained-texture-set-shapekeys-20261127"
revision = subprocess.check_output(["git", "-C", repo, "rev-parse", "HEAD"], text=True).strip()

def text(name):
    return (work / name).read_text()

def obj(name):
    return json.loads(text(name))

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

selected = {}
for mode in ("release", "asan"):
    log = text(f"{mode}-selected.log")
    assert "100% tests passed, 0 tests failed out of 7" in log
    names = re.findall(r"Test #\d+: (\S+)\s+\.+\s+Passed", log)
    assert len(names) == 7
    native = text(f"{mode}/Testing/Temporary/LastTest.log")
    checks = re.search(r"^PASS (\d+) retained texture-set shapekey controls$", native, re.M)
    assert checks and int(checks[1]) == 698
    selected[mode] = {"registered_cases": sorted(names), "retained_shape_assertions": int(checks[1])}
    selected[mode]["native_test_sha256"] = digest(work / mode / "dome-sculpt-texture-set-source-export-test")

software = {}
xr = {}
for mode in ("software", "arc"):
    renderer = re.search(r"^GL_RENDERER (.+)$", text(f"render-{mode}.log"), re.M)[1]
    expected = "Arc(tm) A770" if mode == "arc" else "llvmpipe"
    assert expected in renderer
    oracle = obj(f"render-{mode}/oracle.json")
    assert len(oracle["cases"]) == 8
    error = max(r["shaped"]["maximum_byte_error"] for r in oracle["cases"])
    counter = min(r["shaped"]["stale_frame_counter"] for r in oracle["cases"])
    assert error <= 1 and counter >= 45
    checks = re.search(r"^PASS (\d+) actual sourceful same-object field appearance controls$",
                       text(f"render-{mode}.log"), re.M)
    assert checks
    software[mode] = {"renderer":renderer, "assertions":int(checks[1]), "cases":8,
                      "maximum_shaped_rgb_error":error, "minimum_stale_frame_counterexample":counter}
    profile = obj(f"xr-{mode}/compare.json")
    assert profile["exact_ordered_close"]
    assert all(r["stereo_submissions"] == 6 and r["releases"] == 12 and
               expected in r["gl_renderer"] for r in profile["profiles"])
    xr[mode] = {"renderer":profile["profiles"][1]["gl_renderer"], "app_processes":2,
                "stereo_submissions_each":6, "swapchain_releases_each":12,
                "differing_rgb_components_per_eye":profile["differing_rgb_components_per_eye"],
                "exact_ordered_close":True}

schemas = obj("khronos.json")
assert len(schemas["reports"]) == 8 and all(
    item["report"]["issues"]["numErrors"] == 0 and item["report"]["issues"]["numWarnings"] == 0
    for item in schemas["reports"])
wayland = obj("wayland/report.json")
assert wayland["complete"] and len(wayland["checks"]) == 9 and all(r["passed"] for r in wayland["checks"])

path = "texture-set-retained-shapekeys"
identical = {}
for f in sorted((work/"release"/path).iterdir()):
    if f.is_file() and f.suffix in (".dsculpt", ".glb"):
        assert digest(f) == digest(work/"asan"/path/f.name), f.name
        identical[f.name] = digest(f)
assert len(identical) == 21

members = ["receipt.py", "release-selected.log", "asan-selected.log",
           "release/Testing/Temporary/LastTest.log", "asan/Testing/Temporary/LastTest.log",
           "release-dedup-build.log", "asan-dedup-build.log",
           "render-software.log", "render-arc.log", "render-software/oracle.json", "render-arc/oracle.json",
           "run-wayland.py", "wayland-shape.py", "wayland.log", "wayland/report.json",
           "xr-pose.py", "xr-software.log", "xr-arc.log", "xr-software/compare.json", "xr-arc/compare.json",
           "khronos.cjs", "khronos.log", "khronos.json"]
members += [f"release/{path}/prepared-{name}" for name in
            ("before.dsculpt", "shaped.dsculpt", "after-stroke.dsculpt", "standard.glb", "editable.glb")]
archive = dest / (stem + ".tar.gz")
with archive.open("wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as bundle:
        for name in sorted(members):
            item = bundle.gettarinfo(str(work/name), arcname=name)
            item.uid = item.gid = item.mtime = 0
            item.uname = item.gname = ""
            item.mode = 0o644
            with (work/name).open("rb") as stream:
                bundle.addfile(item, stream)

report = {
    "revision": revision,
    "canonical_domed_revision": "acc2b70ae61dedec2a23727f67c60c0303d0f76f",
    "release_fltk": "/opt/fltk-vr/toolkit", "asan_fltk": "artifacts/sdk-20261126/toolkit-sanitize",
    "release_application_sha256": digest(work/"release/dome-sculpt"),
    "native":selected,
    "sanitizer_environment":{"ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1",
                             "UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1"},
    "opengl_render":software,
    "nested_domed_wayland_assertions":len(wayland["checks"]),
    "synthetic_openxr_cold_pose":xr,
    "gltf_validator":{"version":schemas["version"],"files":8,"errors":0,"warnings":0},
    "identical_release_asan_files_sha256":identical,
    "physical_headset_tested":False,
    "archive":{"path":archive.name,"sha256":digest(archive),
               "members_sha256":{name:digest(work/name) for name in sorted(members)}},
}
(dest/(stem+".json")).write_text(json.dumps(report, indent=2)+"\n")
