const fs = require('fs');
const path = require('path');
const validator = require(path.join(__dirname, '../hdr-khronos-validation-20261126/module/package'));
(async () => {
  const reports = [];
  const directory = path.join(__dirname, 'release', 'texture-set-retained-shapekeys');
  for (const name of fs.readdirSync(directory).filter(name => name.endsWith('.glb')).sort()) {
    const report = await validator.validateBytes(fs.readFileSync(path.join(directory, name)), {uri: name});
    reports.push({name, report});
    console.log(name, report.issues.numErrors, 'errors', report.issues.numWarnings, 'warnings');
  }
  fs.writeFileSync(path.join(__dirname, 'khronos.json'), JSON.stringify({version: validator.version(), reports}, null, 2)+'\n');
  if (reports.length !== 8 || reports.some(item => item.report.issues.numErrors)) process.exitCode = 1;
})().catch(error => {console.error(error); process.exitCode = 1});
