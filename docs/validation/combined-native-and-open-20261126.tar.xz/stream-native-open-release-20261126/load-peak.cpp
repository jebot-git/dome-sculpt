#include "dome/scene.hpp"
#include <iostream>
#include <sys/resource.h>

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  const auto scene = dome::Scene::load(argv[1]);
  rusage usage{};
  if (getrusage(RUSAGE_SELF, &usage)) return 3;
  std::cout << "LOAD_PEAK_KIB " << usage.ru_maxrss << std::endl;
  scene.save(argv[2]);
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
