from pathlib import Path
import hashlib
import json
import os
import re
from owned_monitor import run

here = Path(__file__).resolve().parent
plan = json.loads((here / 'plan.json').read_text())
status = dict(plan, terminal=False, steps=[])

def save():
    tmp = here / 'status.tmp'
    tmp.write_text(json.dumps(status, indent=2) + '\n')
    tmp.replace(here / 'status.json')

def digest(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

save()
try:
    for case in plan['cases']:
        command = case['argv']
        exe = command[0]
        assert digest(exe) == case['sha256']
        log = here / (case['target'] + '.log')
        row = run(command, cwd=here.parent, env=os.environ.copy(), log=log,
                  timeout=900, max_rss=4 * 1024**3)
        output = log.read_text()
        reported = {int(val) for group in re.findall(r'\bPASS\s+(\d+)\b|\b(\d+)\s+checks\b', output) for val in group if val}
        reported.update(int(x) for x in re.findall(r'^PASS independent production sculpt workflow checks=(\d+) objects=4 voxel=\.0125\b', output, re.M))
        literal = sum(line.startswith('PASS ') for line in output.splitlines())
        passed = row['exit'] == 0 and 'error' not in row and (case['checks'] in reported or literal == case['checks'])
        row.update(target=case['target'], reported=sorted(reported), literal=literal,
                   expected=case['checks'], accepted=passed, ELF_sha256=digest(exe))
        status['steps'].append(row)
        save()
        assert row['ELF_sha256'] == case['sha256']
    status['exit'] = int(not all(row['accepted'] for row in status['steps']))
except BaseException as error:
    status.update(exit=1, error=repr(error))
finally:
    status['terminal'] = True
    save()
raise SystemExit(status['exit'])
