from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import shutil
import subprocess

here = Path(__file__).resolve().parent
plan = json.loads((here / 'build-plan.json').read_text())
original = Path(plan['cwd'])
archive = here / 'libdome-sculpt-core.a'


def stage(step):
    with (here / (step['name'] + '.log')).open('w') as log:
        result = subprocess.run(step['argv'], cwd=original, stdout=log,
                                stderr=subprocess.STDOUT, check=False)
    return {'name': step['name'], 'exit': result.returncode}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


status = {'terminal': False, 'exit': None}
try:
    with ThreadPoolExecutor(max_workers=3) as tasks:
        status['compile'] = list(tasks.map(stage, plan['compiler']))
    if any(step['exit'] for step in status['compile']):
        raise RuntimeError('Compile step failed')
    original_archive = original / archive.name
    original_digest = digest(original_archive)
    shutil.copyfile(original_archive, archive)
    subprocess.run(['ar', 'r', str(archive), *plan['replacement_objects']], check=True)
    members = subprocess.check_output(['ar', 't', str(original_archive)], text=True).splitlines()
    rebuilt = subprocess.check_output(['ar', 't', str(archive)], text=True).splitlines()
    assert members == rebuilt and len(members) == len(set(members))
    replacements = {Path(path).name: Path(path) for path in plan['replacement_objects']}
    for name in members:
        member_bytes = subprocess.check_output(['ar', 'p', str(archive), name])
        if name in replacements:
            assert member_bytes == replacements[name].read_bytes()
        else:
            assert member_bytes == subprocess.check_output(['ar', 'p', str(original_archive), name])
    status['linked_archive'] = {'members': len(members), 'sha256': digest(archive),
                                'replacements': sorted(replacements)}
    status['links'] = [stage(step) for step in plan['links']]
    assert digest(original_archive) == original_digest
    status['exit'] = int(any(step['exit'] for step in status['links']))
except Exception as error:
    status.update(exit=1, error=repr(error))
finally:
    status['terminal'] = True
    (here / 'build-status.json').write_text(json.dumps(status, indent=2) + '\n')
raise SystemExit(status['exit'])
