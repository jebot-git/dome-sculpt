from pathlib import Path
import hashlib
import json
import shlex
import subprocess

here = Path(__file__).resolve().parent
parent = here.parent / 'hdr-projection-sharing-sanitize-20261126'
build = parent / 'release'
source = here.parent / 'stream-native-open-strict-source-20261126'
base = json.loads((parent / 'plan.json').read_text())
audit = json.loads((parent / 'audit.json').read_text())
strict = json.loads((parent / 'strict-profile-audit.json').read_text())
assert audit['exit'] == strict['exit'] == 0
old_source = base['source_dir']
checked_archives = {}
for archive in audit['archives']:
    path = Path(archive['path'])
    with path.open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == archive['sha256'], path
    assert path.name not in checked_archives
    checked_archives[path.name] = archive

commands = json.loads((build / 'compile_commands.json').read_text())
compiles, links = [], []
objects = {}
for stem, bucket in [('src/scene-file.cpp', 'core'), ('tests/scene-file.cpp', 'fixture'),
                     ('tests/document-recovery.cpp', 'fixture')]:
    entry, = [x for x in commands if x['file'] == f'{old_source}/{stem}']
    command = shlex.split(entry['command'].replace(old_source, str(source)))
    obj = here / bucket / (Path(stem).name + '.o')
    obj.parent.mkdir(exist_ok=True)
    command[command.index('-o') + 1] = str(obj)
    command[1:1] = ['-MD', '-MT', str(obj), '-MF', str(obj) + '.d']
    for required in ('-O1', '-g1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'):
        assert required in command
    compiles.append({'name': f'{bucket}-{obj.name}', 'argv': command})
    objects[stem] = str(obj)
    assert (source / stem).read_bytes() == (here.parent / 'stream-native-open-source-20261126' / stem).read_bytes()

for fixture in ('scene-file', 'document-recovery'):
    target = f'dome-sculpt-{fixture}-test'
    commands = subprocess.check_output(['ninja', '-t', 'commands', target], cwd=build, text=True)
    _, main, _ = commands.splitlines()[-1].split(' && ')
    line = shlex.split(main)
    link = []
    for item in line:
        if item.startswith('-Wl,--dependency-file='):
            item = f'-Wl,--dependency-file={here}/{fixture}.link.d'
        elif item.endswith(f'/tests/{fixture}.cpp.o'):
            item = objects[f'tests/{fixture}.cpp']
        elif item == target:
            item = str(here / target)
        elif item == 'libdome-sculpt-core.a':
            item = str(here / item)
        elif item.endswith('.a'):
            item = checked_archives[item]['path']
        link.append(item)
    links.append({'name': target, 'argv': link})

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
plan = {'source': head, 'parent': base['source'], 'cwd': str(build), 'verified_archives': checked_archives,
        'compiler': compiles, 'replacement_objects': [objects['src/scene-file.cpp']], 'links': links}
(here / 'build-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(head, len(checked_archives), len(compiles), len(links))
