from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

here = Path(__file__).resolve().parent
plan = json.loads((here / 'build-plan.json').read_text())
build = json.loads((here / 'build-status.json').read_text())
assert build['terminal'] and build['exit'] == 0
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',
           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
env.pop('LSAN_OPTIONS', None)
work = here / 'runtime'
work.mkdir()
results = []
for fixture, arguments, pattern, expected in [
    ('scene-file-test', [str(work / 'scene-file')], r'Native scene file: (\d+) checks', 20),
    ('document-recovery-test', [], r'Native Document recovery: (\d+) checks', 21),
]:
    elf = here / f'dome-sculpt-{fixture}'
    libraries = subprocess.check_output(['readelf', '-d', str(elf)], text=True)
    assert 'libasan.so.' in libraries and 'libubsan.so.' in libraries
    start = time.monotonic()
    run = subprocess.run([str(elf), *arguments], cwd=work, env=env, stderr=subprocess.STDOUT,
                         stdout=subprocess.PIPE, text=True, timeout=90)
    (work / f'{fixture}.log').write_text(run.stdout)
    with elf.open('rb') as file:
        digest = hashlib.file_digest(file, 'sha256').hexdigest()
    checks = [int(x) for x in re.findall(pattern, run.stdout)]
    results.append(dict(elf_sha256=digest, fixture=fixture, checks=checks, expected=expected,
                        exit=run.returncode, seconds=time.monotonic() - start))
    print(fixture, checks, run.returncode, flush=True)
exit_code = int(any(x['exit'] or x['checks'] != [x['expected']] for x in results))
(work / 'status.json').write_text(json.dumps({'source': plan['source'], 'terminal': True,
    'exit': exit_code, 'sanitizer_options': {k: env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS')},
    'cases': results}, indent=2) + '\n')
raise SystemExit(exit_code)
