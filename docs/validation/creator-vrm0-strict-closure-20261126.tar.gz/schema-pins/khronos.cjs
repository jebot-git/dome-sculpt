const fs = require("node:fs");
const path = require("node:path");
const validator = require(process.argv[2]);
async function validate() {
  const [output, ...files] = process.argv.slice(3);
  const results = [];
  for (const file of files) {
    const data = new Uint8Array(fs.readFileSync(file));
    const report = await validator.validateBytes(data, {
      uri: path.basename(file),
      maxIssues: 10000,
    });
    results.push({file, report});
    console.log(path.basename(file), report.issues.numErrors, report.issues.numWarnings);
  }
  fs.writeFileSync(output, JSON.stringify({version: validator.version(), results}, null, 2) + "\n");
  process.exitCode = results.some(result => result.report.issues.numErrors ||
    result.report.issues.truncated) ? 1 : 0;
}
validate().catch(error => { console.error(error); process.exitCode = 1; });
