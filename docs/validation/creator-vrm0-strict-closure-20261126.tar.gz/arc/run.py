from pathlib import Path
import fcntl
import hashlib
import json
import os
import re
import shlex
import subprocess
import time

out=Path(__file__).resolve().parent
art=out.parent
native=art/'current-creator-vrm0-validation-v3-20261126/release'
sdk=Path('/opt/fltk-vr/toolkit')
candidate='90c10c285038fdfdf5e415ca8efbc7c494debb34'
state={'candidate':candidate,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}

def write(**fields):
    state.update(fields)
    temporary=out/'status.tmp'
    temporary.write_text(json.dumps(state,indent=2)+'\n')
    temporary.replace(out/'status.json')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

try:
    write(phase='verify completed software consumer and matching optimized Release binary')
    record=json.loads((native/'status.json').read_text())
    software=(native/'ctest.log').read_text()
    assert record['candidate']==candidate and record.get('binaries')
    assert re.search(r'Test\s+#375: normal-frame-vrm-consumer\s+\.+\s+Passed',software)
    target=native/'build/dome-sculpt-normal-frame-vrm-consumer-test'
    assert sha(target)==record['binaries'][target.name]
    node='/dev/dri/renderD129'
    pci=Path('/sys/class/drm/renderD129/device')
    assert pci.resolve().name=='0000:03:00.0'
    assert (pci/'vendor').read_text().strip()=='0x8086' and (pci/'device').read_text().strip()=='0x56a0'
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--dev-bind',node,node,'--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    variables={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'0',
               'DRI_PRIME':'pci-0000_03_00_0','MESA_SHADER_CACHE_DISABLE':'1',
               'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
               'LP_NUM_THREADS':'2'}
    for key,value in variables.items():prefix.extend(['--setenv',key,value])
    cmd=[*prefix,target,out/'frame-vrm-consumer','--hardware']
    write(phase='run the independent optimized Arc image consumer',binary_sha256=sha(target),arc_node=node)
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock, (out/'arc.log').open('w') as trace:
        fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,cmd)),file=trace,flush=True)
        subprocess.run(cmd,cwd=out,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=450)
    trace=out/'arc.log'
    text=trace.read_text()
    renderer=next(line[4:] for line in text.splitlines() if line.startswith('GPU '))
    assert 'Arc(tm) A770' in renderer and 'Actual VRM frame consumer checks 27' in text
    write(phase='complete',terminal=True,exit=0,renderer=renderer,checks=27,trace_sha256=sha(trace))
except Exception as error:
    write(terminal=True,exit=1,error=repr(error))
    raise
