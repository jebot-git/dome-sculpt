from pathlib import Path
from xml.etree import ElementTree
import gzip
import hashlib
import json
import subprocess
import tarfile

native=Path(__file__).resolve().parent
art=native.parent
root=art.parent
output=root/'docs/validation'
arc=art/'current-creator-vrm0-arc-v2-20261126'
wayland=art/'current-creator-vrm0-wayland-v2-20261126'
interop=art/'current-creator-vrm0-interoperability-v3-20261126'
expected='90c10c285038fdfdf5e415ca8efbc7c494debb34'
files={}

def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def add(prefix,folder,*members):
    for name in members:
        item=folder/name
        assert item.is_file(),item
        files[prefix+'/'+name]=item

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

subprocess.run(['git','-C',root,'merge-base','--is-ancestor',expected,'HEAD'],check=True)
assert git('diff','--name-only',expected,'HEAD','--','src','include','assets','third_party','CMakeLists.txt')==''
test_changes=set(git('diff','--name-only',expected,'HEAD','--','tests').splitlines())
assert test_changes=={'tests/object-selection.cpp','tests/object-isolation.cpp','tests/modal-selection-controls.cpp'}
before=read(native/'baseline/status.json')
assert before['diagnostic']=='FAIL VRM0: every source part needs coordinate basis provenance'
add('baseline',native/'baseline','run.py','control.log','link.log','status.json')
approved={}
for profile in ('release','asan'):
    run=native/profile
    state=read(run/'status.json')
    assert state['candidate']==expected and state['terminal'] and state['exit']==0 and state['tests']==11 and not state['failures']
    assert sha(run/'build/dome-sculpt')==state['app_sha256']
    assert sha(run/'ctest.log')==state['ctest_sha256']
    xml=run/'build/creator-vrm-tests.xml'
    assert sha(xml)==state['junit_sha256']
    cases=ElementTree.parse(xml).getroot().findall('.//testcase')
    assert len(cases)==11 and all(case.find('failure') is None and case.find('skipped') is None for case in cases)
    assert 'CREATOR VRM CHECKS 460' in (run/'ctest.log').read_text()
    add(profile+'/native',run,'status.json','configure.log','dome-sculpt-link.log','ctest.log','build/creator-vrm-tests.xml')
    for number in (1,2):
        qualifier='' if number==1 else '-v2'
        earlier=art/f'current-creator-vrm0-validation{qualifier}-20261126'/profile
        compiler=earlier/'tests/dome-sculpt-creator-vrm-test/creator-vrm.cpp.log'
        assert 'error:' in compiler.read_text()
        add(f'{profile}/initial-fixture-{number}',earlier,'status.json',
            'tests/dome-sculpt-creator-vrm-test/creator-vrm.cpp.log')
    donor=art/'current-creator-vrm0-validation-v2-20261126'/profile
    add(profile+'/product-build',donor,'creation.cpp.log','creator-vrm.cpp.log','material-bindings.cpp.log',
         'vrm.cpp.log','vroid-creator.cpp.log','core-index.log')
    approved[profile]=state
gpu=read(arc/'status.json')
wl=read(wayland/'status.json')
intop=read(interop/'status.json')
assert gpu['candidate']==wl['candidate']==intop['candidate']==expected
assert gpu['exit']==wl['exit']==intop['exit']==0
assert gpu['binary_sha256']==approved['release']['binaries']['dome-sculpt-normal-frame-vrm-consumer-test']
assert gpu['checks']==27 and wl['checks']==10 and intop['schemas']==15 and intop['validated_files']==32
assert intop['errors']==0 and len(intop['binary_equal_release_and_asan'])==31 and len(intop['binary_equal_arc'])==7
assert wl['app_sha256']==approved['release']['app_sha256']
assert sha(wayland/'workflow/Avatar.vrm')==wl['output_sha256']
assert sha(arc/'arc.log')==gpu['trace_sha256']
assert sha(interop/'official-vrm0.json')==intop['official_sha256'] and sha(interop/'khronos.json')==intop['khronos_sha256']
add('runner',native,'run.py','record-closure.py')
add('arc',arc,'run.py','status.json','arc.log')
first_arc=art/'current-creator-vrm0-arc-20261126'
assert read(first_arc/'status.json')['exit']==1
assert 'FAIL Actual avatar worker accepts explicitly authored flat frames' in (first_arc/'arc.log').read_text()
add('asan-arc-combined',first_arc,'run.py','status.json','arc.log')
add('wayland',wayland,'run.py','replay.py','status.json','wayland.log','workflow/report.json')
add('wayland-wrapper-count-v1',art/'current-creator-vrm0-wayland-20261126','status.json','workflow/report.json')
add('interoperability',interop,'run.py','status.json','official-vrm0.json','khronos.json','khronos.log')
spec=art/'creator-vrm-placement-spec-20261126'
add('schema-pins',spec,'khronos.cjs','schema-blobs.txt')
diagnosis=art/'creator-canonical-preview-diagnosis-20261126'
add('diagnostic-runner',diagnosis,'run.py')
for profile in ('arc','software'):
    report=read(diagnosis/profile/'status.json')
    assert report['source']==expected and report['exit']==0
    assert report['binary_sha256']==approved['asan']['binaries']['dome-sculpt-normal-frame-vrm-consumer-test']
    assert 'Actual VRM frame consumer checks 5' in (diagnosis/profile/'run.log').read_text()
    add('canonical-diagnosis-'+profile,diagnosis/profile,'status.json','run.log','stacks.log')
add('validator-pin',art/'hdr-khronos-validation-20261126','npm-pack.json')
archive=output/'creator-vrm0-strict-closure-20261126.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as stream:
    with tarfile.open(fileobj=stream,mode='w') as tar:
        for name,path in sorted(files.items()):
            entry=tar.gettarinfo(str(path),arcname=name)
            entry.uid=entry.gid=entry.mtime=0
            entry.uname=entry.gname=''
            entry.mode=0o644
            with path.open('rb') as data:
                tar.addfile(entry,data)
digests={name:sha(path) for name,path in sorted(files.items())}
with tarfile.open(archive,'r:gz') as tar:
    assert {entry.name for entry in tar.getmembers()}==set(digests)
    for name,digest in digests.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
receipt={'candidate':expected,'main_merge':git('rev-parse','HEAD'),'prior_control':before,'native':approved,
         'arc':gpu,'wayland':wl,'interoperability':intop,'concurrent_selection_fixtures':sorted(test_changes),
         'raw':{'archive':archive.name,'sha256':sha(archive),'members':digests}}
(output/'creator-vrm0-strict-closure-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(files),'evidence files',sha(archive))
