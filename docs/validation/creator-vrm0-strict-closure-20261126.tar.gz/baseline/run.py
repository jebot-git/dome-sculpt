from pathlib import Path
import hashlib
import json
import shlex
import subprocess

out=Path(__file__).resolve().parent
art=out.parents[1]
current=out.parent/'release'
parent=art/'renderer-projection-combined-validation-20261126/release'
owner=art/'sculpt-projection-occlusion-validation-v2-20261126/release'
previous=json.loads((parent/'status.json').read_text())
core=owner/'libdome-sculpt-core.a'
fixture='dome-sculpt-creator-vrm-test'
linklog=current/'tests'/fixture/'link.log'
candidate=json.loads((current/'status.json').read_text())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

assert previous['exit']==0 and candidate['donor']==previous['candidate'] and sha(core)==previous['core_sha256']
words=shlex.split(linklog.read_text().splitlines()[0])
words=[str(core) if Path(word).name==core.name else word for word in words]
binary=out/'creator-vrm-prior-core'
words[words.index('-o')+1]=str(binary)
with (out/'link.log').open('w') as trace:
    print(shlex.join(words),file=trace,flush=True)
    subprocess.run(words,cwd=current/'build',stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=120)
argv=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,'--proc','/proc','--dev','/dev',
      '--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','HOME','/tmp',binary,out/'models']
with (out/'control.log').open('w') as trace:
    result=subprocess.run(argv,cwd=out,stdout=trace,stderr=subprocess.STDOUT,timeout=90)
text=(out/'control.log').read_text()
diagnostic=next(line for line in text.splitlines() if line.startswith('FAIL '))
assert result.returncode==1 and ('not support' in diagnostic or 'basis provenance' in diagnostic or
    'nonlinear' in diagnostic or 'generated' in diagnostic), text
(out/'status.json').write_text(json.dumps({'candidate_fixture':candidate['candidate'],'prior':previous['candidate'],
    'core_sha256':sha(core),'binary_sha256':sha(binary),'exit':result.returncode,'diagnostic':diagnostic},indent=2)+'\n')
print(diagnostic)
