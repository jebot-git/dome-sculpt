from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
art=root.parent
profile=sys.argv[1]
hardware=profile=='arc'
out=root/profile
out.mkdir(exist_ok=True)
candidate=art/'current-creator-vrm0-validation-v3-20261126/asan'
state=json.loads((candidate/'status.json').read_text())
target=candidate/'build/dome-sculpt-normal-frame-vrm-consumer-test'
digest=hashlib.sha256(target.read_bytes()).hexdigest()
assert state['candidate'].startswith('90c10c28') and digest==state['binaries'][target.name]
sdk=art/'sdk-20261126/toolkit-sanitize'
prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
             'LIBGL_ALWAYS_SOFTWARE':'0' if hardware else '1',
             'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
             'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if hardware:
    node='/dev/dri/renderD129'
    prefix.extend(['--dev-bind',node,node])
    environment.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1')
for key,value in environment.items():prefix.extend(['--setenv',key,value])
command=[*prefix,target,out/'frame-vrm-consumer','--canonical-only']

def children(pid):
    spec=Path(f'/proc/{pid}/task/{pid}/children')
    try:
        for value in spec.read_text().split():
            desc=int(value);yield desc;yield from children(desc)
    except (FileNotFoundError,ProcessLookupError):return

with (out/'run.log').open('w') as log, (out/'stacks.log').open('w') as stacks, open('/tmp/dome-sculpt-arc-device.lock','rb') as lock:
    if hardware:fcntl.flock(lock,fcntl.LOCK_EX)
    print(shlex.join(map(str,command)),file=log,flush=True)
    start=time.monotonic()
    with subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,cwd=out) as run:
        watch=[2,5,9,14,20,26,31,39,47,57]
        for t in watch:
            try:
                run.wait(timeout=max(.01,start+t-time.monotonic()))
                break
            except subprocess.TimeoutExpired:pass
            for pid in children(run.pid):
                try: binary=os.readlink(f'/proc/{pid}/exe')
                except (FileNotFoundError,PermissionError):continue
                if binary!=str(target):continue
                print(f'Elapsed {time.monotonic()-start:.3f}s process {pid}',file=stacks,flush=True)
                try:
                    subprocess.run(['eu-stack','-p',str(pid),'-n','22'],stdout=stacks,stderr=subprocess.STDOUT,timeout=4)
                except subprocess.TimeoutExpired:
                    print('Stack sample exceeded four seconds',file=stacks,flush=True)
        result=run.wait(timeout=120)
        (out/'status.json').write_text(json.dumps({'source':state['candidate'],'binary_sha256':digest,'profile':profile,
            'elapsed_seconds':round(time.monotonic()-start,3),'exit':result,'invocation':os.getenv('INVOCATION_ID')},indent=2)+'\n')
