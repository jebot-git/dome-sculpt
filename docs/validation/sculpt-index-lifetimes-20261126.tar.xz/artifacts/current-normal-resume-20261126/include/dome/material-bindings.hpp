// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "mtoon.hpp"
#include "source-maps.hpp"
#include "normal-frames.hpp"
#include <optional>
namespace dome {
namespace detail { class PolygonColorArchive; class SourceKeyDerivation; class CanonicalNormalConversion; class CanonicalNormalUv; class NativePaintSampling; class NativePaintFrameSource; class CanonicalPaintSampling; class PolygonSurfaceOwner; }
class PaintedMesh;
class CreatorAssetArchive;
class NormalSamplingArchive;
class PaintSamplingArchive;
struct CreatorAppearance;
struct DeformationState;
struct SourceColorPreparation;
struct SourceNormalPreparation;
struct SourcePaintDecodeContext;
enum class SourceUvAnimationPolicy { RejectAnimated, FreezeAtTime };
// Canonical Mikk normals belong to PaintedMesh::baked(), not this role table.
enum class SourceMaterialNormalFrame { UvDerivative, OriginalAttributes };
struct SourceNativeMaterial {
  // Native inspector factors at the start of this explicit material binding.
  // These are a comparison baseline, not factors baked into role pixels.
  std::array<float,4> color{.58f,.30f,.15f,1};
  std::array<float,3> emission{};
  int alpha = 1; // Native Material::AlphaMode::Opaque.
  float alpha_cutoff = .5f;
  bool double_sided = false;
  void validate() const;
};
struct SourceUvOrigin {
  std::shared_ptr<const PaintedMesh> paint;
  std::shared_ptr<const CreatorAppearance> appearance;
  std::optional<MToonMaterial> material;
  std::array<PaintSourceTexture, size_t(MToonSlot::Count)> roles;
  std::shared_ptr<const DeformationState> deformation;
  std::string creator_kind,creator_parameters;
  uint32_t creator_version=0;
};
struct SourceMaterialBindings {
  // A generic PBR UV bake uses this holder only for immutable source provenance.
  bool has_mtoon = true;
  MToonMaterial material;
  // Typed material owns UV selection, affine transforms and animation. Views
  // hold images/samplers only: identity affine and texcoord zero.
  std::array<PaintSourceTexture, size_t(MToonSlot::Count)> roles;
  SourceMaterialNormalFrame normal_frame = SourceMaterialNormalFrame::UvDerivative;
  SourceUvAnimationPolicy animation_policy = SourceUvAnimationPolicy::RejectAnimated;
  double freeze_seconds = 0;
  bool animation_frozen = false;
  SourceNativeMaterial native_reference;
  // First original source, propagated unchanged through repeated UV edits.
  // PaintedMesh has no material holder, so this ownership cannot recurse.
  std::shared_ptr<const SourceUvOrigin> uv_origin;
  std::shared_ptr<const NormalFrameSet> normal_frames;
  bool sampling_reparameterized=false;
  std::shared_ptr<const SourceColorPreparation> color_preparation;
  std::shared_ptr<const SourceNormalPreparation> normal_preparation;
  // Explicit absolute background radiance (linear cd/m^2), including zero.
  // Absent preserves historical typed-strength/native-factor correction.
  std::optional<std::array<float,3>> physical_emission;
  std::shared_ptr<const detail::SourceKeyDerivation> key_derivation;
  // Durable attribute provenance survives clearing the active baked detail.
  std::shared_ptr<const detail::CanonicalNormalConversion> canonical_attributes;
  // Editable atlas correspondence; its authentic root survives Clear Bake.
  std::shared_ptr<const detail::CanonicalNormalUv> canonical_uv;
  // Scene32/wire14: independent native writable-grid authority.
  std::shared_ptr<const detail::NativePaintSampling> native_paint_sampling;
  // Scene36: independent current normal capture, separate from writable UV history.
  std::shared_ptr<const detail::NativePaintFrameSource> native_paint_frames;
  // Scene37: writable paint correspondence with independent canonical normals.
  std::shared_ptr<const detail::CanonicalPaintSampling> canonical_paint_sampling;
  // Reserved Scene39: actual original-field/current-polygon transfer. The
  // writer stays fail-closed until its owning codec/publication is connected.
  std::shared_ptr<const detail::PolygonSurfaceOwner> polygon_surface_transfer;
  void validate(bool deep=true) const;
};
using SourceUvMaterialBindings = SourceMaterialBindings;
// One bounded native archive deduplicates immutable holders and first-source
// origins by identity; all role/source images use the document image archive.
class SourceMaterialArchive {
public:
  uint32_t add(std::shared_ptr<const SourceMaterialBindings>,bool deep=true);
  const std::shared_ptr<const SourceMaterialBindings> &at(uint32_t) const;
  const std::vector<std::shared_ptr<const SourceMaterialBindings>> &bindings() const { return bindings_; }
  const std::vector<std::shared_ptr<const SourceUvOrigin>> &origins() const { return origins_; }
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &) const;
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,detail::PolygonColorArchive *) const;
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,detail::PolygonColorArchive *,NormalSamplingArchive *) const;
  nlohmann::json encode(PaintImageArchive &,CreatorAssetArchive &,detail::PolygonColorArchive *,NormalSamplingArchive *,PaintSamplingArchive *) const;
  static size_t deformation_entries(const nlohmann::json &);
  static SourceMaterialArchive decode(const nlohmann::json &, const PaintImageArchive &, const CreatorAssetArchive &);
  static SourceMaterialArchive decode(const nlohmann::json &, const PaintImageArchive &, const CreatorAssetArchive &,const detail::PolygonColorArchive *);
  static SourceMaterialArchive decode(const nlohmann::json &, const PaintImageArchive &, const CreatorAssetArchive &,const detail::PolygonColorArchive *,const NormalSamplingArchive *);
  static SourceMaterialArchive decode(const nlohmann::json &,const PaintImageArchive &,const CreatorAssetArchive &,const detail::PolygonColorArchive *,const NormalSamplingArchive *,const PaintSamplingArchive *);
  static SourceMaterialArchive decode(const nlohmann::json &,const PaintImageArchive &,const CreatorAssetArchive &,const detail::PolygonColorArchive *,const NormalSamplingArchive *,const PaintSamplingArchive *,const SourcePaintDecodeContext &);
private:
  std::vector<std::shared_ptr<const SourceMaterialBindings>> bindings_;
  std::vector<std::shared_ptr<const SourceUvOrigin>> origins_;
};
} // namespace dome
