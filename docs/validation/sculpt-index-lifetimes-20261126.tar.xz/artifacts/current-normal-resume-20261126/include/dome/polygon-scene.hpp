// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "polygon.hpp"
#include "scene.hpp"
namespace dome {
struct SourcePlacementCapsule;
struct PolygonOrigin;
class PolygonColorField;
// Stable editable topology, not the triangulated display/paint derivative.
// An active authority with no faces intentionally displays no surface, even if
// the retained object Volume still contains an earlier sculpt.
struct PolygonAuthority {
  PolygonMesh topology;
  bool active = true;
  std::shared_ptr<const PolygonOrigin> origin;
  // Scene14 current geometry-side linear RGBA, never an appearance alias.
  std::shared_ptr<const PolygonColorField> colors;
};
// Detached immutable authoring snapshot. Ordinary topology edits retain the
// first origin. An explicit later conversion may retain a prior authority;
// native archives bound and validate that DAG rather than following live IDs.
struct PolygonOrigin {
  std::shared_ptr<const Volume> volume;
  std::shared_ptr<const PaintedMesh> paint;
  Material material;
  std::shared_ptr<const DeformationState> deformation;
  std::shared_ptr<const CreatorAppearance> appearance;
  std::shared_ptr<const SourceMaterialBindings> material_bindings;
  std::shared_ptr<const RetopoPatch> retopology;
  std::shared_ptr<const PolygonAuthority> polygon;
  bool mesh_active = false;
  CanvasTransform world_transform{};
  std::string name;
  // Provenance only; zero and deleted source IDs remain valid and restorable.
  uint64_t source_object = 0;
  // Scene13 exact placement authority; world_transform remains legacy-only
  // provenance. IDs in the capsule are snapshots, not live hierarchy links.
  std::shared_ptr<const SourcePlacementCapsule> placement{};
  std::shared_ptr<const PolygonOrigin> shape_source{};
  std::shared_ptr<const PolygonOrigin> rig_source{};
  std::shared_ptr<const ObjectBakeRecipe> bake_recipe{};
  // Scene40/polygon_sources8 complete original material-slot state.
  std::shared_ptr<const TextureSetCollection> texture_sets{};
};
// Compare the active painted REST derivative only. Posed preview positions and
// unrelated source attributes must not replace the editable topology authority.
void validate_polygon_derivative(const PolygonAuthority &, const PaintedMesh *,
                                 bool mesh_active, const PolygonLimits & = {});
} // namespace dome
