// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "emission.hpp"
#include "baked-emission.hpp"
#include "mesh.hpp"
#include "paint-blur.hpp"
#include <deque>
#include <map>
#include <memory>
namespace dome {
namespace detail {class PaintOverlayPacket;struct PaintOverlayFactory;struct EmissionExportAccess;class BakedNormalField;class BakedEmissionDomain;struct NativeWeightPaintAccess;struct TextureSetPaintAccess;class TextureSetFieldSource;class PolygonSurfaceOwner;class PolygonSurfacePreview;struct PolygonSurfaceStage;struct PolygonSurfacePaintCodec;}
struct Material;
namespace detail {class CurrentGridPaintPreview;}
class PaintProjection;
class PaintSamplingDomain;
class PaintSamplingAttachment;
class TextureSetFaceDomain;
class PaintSamplingArchive;
struct SourcePaintDecodeContext;
struct PaintSourceMaps;
class PaintImageArchive;
struct Image {
  uint32_t width = 0, height = 0;
  std::vector<uint8_t> rgba;
  void validate() const;
  std::vector<uint8_t> png() const;
};
struct BakedTextures;
struct NormalSamplingDomain;
struct NormalDetailAuthority;
class NormalSamplingArchive;
struct PaintColorProjection {
  // Linear RGBA in the current writable atlas. Original accessor data remains
  // in the immutable source appearance and preparation receipt.
  uint32_t version = 1;
  std::shared_ptr<const Image> vertex_rgba;
  std::array<float,4> maximum_error{};
  uint64_t quality_cells=0;
  void validate(uint32_t resolution) const;
};
// Intrinsic normal encodings in the explicit prepared attribute model. These
// are unit-strength tangent vectors, not historical canonical/world blends.
// PBR and versioned MToon can evaluate the same attributes differently.
struct PaintNormalProjection {
  uint32_t version=1;
  std::shared_ptr<const Image> pbr,mtoon;
  // Version2 only. This structural leaf requires the full owning normal
  // preparation replay before it may be admitted to an editable surface.
  std::shared_ptr<const NormalSamplingDomain> sampling_domain;
  void validate(uint32_t resolution) const;
  void validate(uint32_t resolution,bool geometry) const;
};
struct TextureMaps {
  Image color, metal_rough, emission;
  bool transparent = false;
  std::shared_ptr<const PaintSourceMaps> source_maps;
  bool source_only = false;
  // Linear R: visible source replacement by baked base and editable color.
  Image color_coverage;
  Image normal; // Canonical Mikk composite for generic PBR consumers.
  // Original immutable baked payload; no recursive baked payload is allowed.
  std::shared_ptr<const BakedTextures> baked_base;
  // Padded raw canonical normal and linear R coverage for typed MToon blending.
  Image baked_normal, baked_coverage;
  // Linear R replacement below/through editable emission, on its own exact grid.
  Image emission_coverage;
  // Optional prepared PBR result. The ordinary color image remains the typed
  // MToon correction authority; MToon ignores original vertex colors.
  Image pbr_color;
  bool pbr_transparent = false;
  std::shared_ptr<const PaintColorProjection> color_projection;
  Image mtoon_normal;
  std::shared_ptr<const PaintNormalProjection> normal_projection;
  // Transient sparse GPU contribution input; never a serialized image authority.
  std::shared_ptr<const detail::PaintOverlayPacket> overlay;
  // Explicit render-only current-grid owner. CPU materialization APIs never
  // return this marker in place of their actual Image payloads.
  std::shared_ptr<const detail::CurrentGridPaintPreview> current_grid_preview;
  // Scene39 current surface field. Independent from colour/F32 grid sampling;
  // a generic baked-normal/source-frame interpretation cannot replace it.
  std::shared_ptr<const detail::PolygonSurfacePreview> polygon_surface;
};
enum class BakedColorInterpretation { VertexComponent, ResolvedPbr };
enum class BakedNormalInterpretation { CanonicalMikk, PreparedAttributes };
struct BakedTextures {
  TextureMaps maps;
  // Linear coverage below editable paint layers: 0 intrinsic material,
  // 255 baked surface. Fractional values retain filtered UV boundary coverage.
  std::vector<uint8_t> coverage;
  BakedColorInterpretation color_interpretation = BakedColorInterpretation::VertexComponent;
  BakedNormalInterpretation normal_interpretation = BakedNormalInterpretation::CanonicalMikk;
  // Scene21 only. This identity distinguishes an authenticated retained
  // normal field from a later byte-identical bake operation. Its coverage is
  // normal-specific and independent of the common RGBA coverage above.
  std::shared_ptr<const NormalDetailAuthority> normal_authority;
  // Independently owned resolved baked normals; never intrinsic material data.
  std::shared_ptr<const detail::BakedNormalField> normal_field;
  // Independent, immutable linear replacement coefficients. When present,
  // maps.emission is empty: RGB8 is not a second emission authority.
  std::shared_ptr<const BakedEmissionField> emission_field;
  // Explicit source-grid authority, mutually exclusive with emission_field.
  std::shared_ptr<const detail::BakedEmissionDomain> emission_domain;
  void validate(uint32_t resolution) const;
  size_t storage_bytes() const;
};
enum class BakedNormalWrite { Replace, PreserveRetained };
struct PaintCompositeCacheStats {
  size_t retained_bytes = 0, retained_maps = 0, limit_bytes = 0;
  uint64_t hits = 0, builds = 0;
};
PaintCompositeCacheStats paint_composite_cache_stats();
// Global strong retention only; zero disables it without invalidating readers.
void set_paint_composite_cache_budget(size_t bytes);
enum class PaintChannel : int { Color, Metallic, Roughness, Emission, Mask };
struct PaintSettings {
  PaintChannel channel = PaintChannel::Color;
  std::array<float, 4> color{.8f, .03f, .02f, 1};
  std::array<float, 3> emission{.8f, .1f, .02f};
  float metallic = 1, roughness = .25f, mask = 0, flow = 1;
  bool erase = false, front_only = true;
  PaintEmissionUnits emission_units = PaintEmissionUnits::MaterialRelative;
  void validate() const;
};
struct PaintPixel {
  // sRGB color RGBA (alpha linear), metal, roughness, sRGB emission,
  // separate coverage for color/metal/rough/emission, then a linear mask.
  std::array<uint8_t, 14> data{};
  PaintPixel() { data[13] = 255; }
  auto operator<=>(const PaintPixel &) const = default;
};
struct PaintTile {
  static constexpr uint32_t size = 32;
  std::array<PaintPixel, size * size> pixels;
};
struct PaintColorTile {
  // Sparse optional second color plane. Ordinary PaintPixel/Tile layouts do
  // not grow; coverage/masks/other channels remain in the common paint tile.
  std::array<std::array<uint8_t,4>, PaintTile::size * PaintTile::size> pixels{};
};
struct PaintEmissionTile {
  // Optional Scene27 physical emission; common tile coverage/mask is shared.
  std::array<PaintEmissionValue, PaintTile::size * PaintTile::size> pixels{};
};
struct PaintLayer {
  uint64_t id = 0;
  std::string name = "Paint";
  bool visible = true;
  float opacity = 1;
  std::vector<std::shared_ptr<const PaintTile>> tiles;
  std::vector<std::shared_ptr<const PaintColorTile>> pbr_tiles;
  std::vector<std::shared_ptr<const PaintEmissionTile>> emission_tiles;
};
enum class PaintUvPolicy { Strict, SourceAuthored, PolygonAuthored };
struct PaintSurfaceOptions {
  PaintUvPolicy policy = PaintUvPolicy::Strict;
  size_t max_raster_samples = 128 * 1024 * 1024;
  size_t max_additional_candidates = 4 * 1024 * 1024;
  size_t max_candidate_checks = 128 * 1024 * 1024;
  uint32_t max_candidates_per_texel = 64;
  std::function<bool()> cancelled;
};
struct PaintSurfaceDiagnostics {
  PaintUvPolicy policy = PaintUvPolicy::Strict;
  std::vector<uint32_t> unpaintable_uv_faces;
  size_t linked_texels = 0, additional_candidates = 0, covered_texels = 0;
  size_t raster_samples = 0, candidate_checks = 0;
};
class PaintedMesh {
public:
  PaintedMesh(Mesh, uint32_t resolution = 512);
  static std::shared_ptr<PaintedMesh> from_mesh(Mesh, uint32_t resolution, const PaintSurfaceOptions &);
  static std::shared_ptr<PaintedMesh> from_maps(Mesh, std::shared_ptr<const PaintSourceMaps>, uint32_t resolution = 512);
  static std::shared_ptr<PaintedMesh> from_maps(Mesh, std::shared_ptr<const PaintSourceMaps>, uint32_t resolution, const PaintSurfaceOptions &);
  const PaintSurfaceDiagnostics &surface_diagnostics() const;
  const std::shared_ptr<const PaintSourceMaps> &source_maps() const noexcept { return source_maps_; }
  const Mesh &mesh() const;
  std::shared_ptr<const Mesh> mesh_owner() const;
  std::shared_ptr<const PaintSamplingDomain> paint_sampling_domain() const noexcept;
  const std::shared_ptr<const PaintSamplingAttachment> &paint_sampling_attachment() const noexcept { return sampling_attachment_; }
  bool valid_paint_sampling_attachment() const noexcept;
  uint32_t resolution() const;
  uint64_t revision() const { return revision_; }
  const std::vector<PaintLayer> &layers() const { return layers_; }
  const std::shared_ptr<const PaintColorProjection> &color_projection() const { return color_projection_; }
  const std::shared_ptr<const PaintNormalProjection> &normal_projection() const { return normal_projection_; }
  std::array<uint8_t,4> pbr_pixel(uint64_t layer, uint32_t x, uint32_t y) const;
  PaintEmissionValue emission_pixel(uint64_t layer, uint32_t x, uint32_t y) const;
  bool has_physical_emission() const noexcept;
  uint64_t active_layer() const { return active_; }
  void select_layer(uint64_t);
  void add_layer(std::string name = "Paint");
  void delete_layer();
  void layer_properties(std::string, bool visible, float opacity);
  void move_layer(int direction);
  struct Evaluation;
  std::shared_ptr<const Evaluation> evaluate(std::shared_ptr<const Mesh>, const std::function<bool()> &cancelled = {}) const;
  void stamp_evaluated(const Brush &, const PaintSettings &, const Evaluation &, const std::function<bool()> &cancelled = {});
  void begin_stroke();
  void stamp(const Brush &, const PaintSettings &);
  void stamp(const Brush &, const PaintSettings &, const std::function<bool()> &cancelled);
  void stamp_projection(const Brush &, const PaintSettings &, const PaintProjection &);
  // Projector, brush and Evaluation must share the same evaluated metric frame.
  void stamp_projection(const Brush &, const PaintSettings &, const PaintProjection &,
                        const Evaluation &, const std::function<bool()> &cancelled = {});
  bool end_stroke();
  void cancel_stroke();
  bool in_stroke() const { return editing_; }
  bool pending_changes() const;
  size_t undo_count() const { return undo_.size(); }
  // Conservative retained data, including hidden/zero-opacity/mask-only tiles.
  bool has_paint_data() const noexcept { return allocated_tiles_ != 0 || bool(source_maps_) || bool(baked_) || bool(sampling_attachment_); }
  bool undo();
  bool redo();
  // Synchronous detached authoring operation; run only on an owning background
  // worker. Mutates genuine active-layer COW fields, never a render composite.
  PaintBlurReport blur_color_layer_gpu(const PaintBlurOptions & = {},
      const std::function<bool()> &cancelled = {});
  bool gpu_color_blur_eligible()const noexcept;
  std::shared_ptr<PaintedMesh> snapshot() const;
  bool source_sampling_prepared() const noexcept;
  bool valid_source_sampling_attachment() const noexcept;
  std::shared_ptr<const PaintedMesh> source_sampling_original() const noexcept;
  std::shared_ptr<const std::vector<std::array<float,2>>> source_sampling_authored_uv1() const noexcept;
  std::span<const uint32_t> source_sampling_vertices() const noexcept;
  std::shared_ptr<PaintedMesh>
  reparameterize(Mesh, const std::function<bool()> &cancelled = {}) const;
  std::shared_ptr<const TextureMaps> composite(const Material &) const;
  std::shared_ptr<const TextureMaps> composite(const Material &, const std::function<bool()> &) const;
  std::shared_ptr<const TextureMaps> preview(const Material &) const;
  std::shared_ptr<const TextureMaps> preview(const Material &, const std::function<bool()> &) const;
  std::shared_ptr<const BakedTextures> baked() const { return baked_; }
  void install_bake(BakedTextures);
  void install_bake(BakedTextures,BakedNormalWrite);
  void clear_bake();
  size_t storage_bytes() const;
  const PaintPixel &pixel(uint64_t layer, uint32_t x, uint32_t y) const;
  std::optional<Vec3> raycast(Vec3, Vec3, float maximum = 20) const;
  Vec3 normal(Vec3) const;
  nlohmann::json encode(PaintImageArchive * = nullptr) const;
  nlohmann::json encode(PaintImageArchive *,NormalSamplingArchive *) const;
  nlohmann::json encode(PaintImageArchive *,NormalSamplingArchive *,PaintSamplingArchive *) const;
  static std::shared_ptr<PaintedMesh> decode(const nlohmann::json &, const PaintImageArchive * = nullptr);
  // Internal Scene12 decoding must subsequently authenticate the exact polygon derivative.
  static std::shared_ptr<PaintedMesh> decode(const nlohmann::json &, const PaintImageArchive *, bool allow_polygon);
  // Structural owning-archive overload. Its model/recipe closure must be
  // authenticated before exposing an editable surface.
  static std::shared_ptr<PaintedMesh> decode(const nlohmann::json &, const PaintImageArchive *,
                                           bool allow_polygon,const NormalSamplingArchive *);
  static std::shared_ptr<PaintedMesh> decode(const nlohmann::json &, const PaintImageArchive *,
      bool allow_polygon,const NormalSamplingArchive *,const PaintSamplingArchive *);
  static std::shared_ptr<PaintedMesh> decode(const nlohmann::json &, const PaintImageArchive *,
      bool allow_polygon,const NormalSamplingArchive *,const PaintSamplingArchive *,const SourcePaintDecodeContext &);
  // Scene27 physical data is an explicit decoder capability. Legacy overloads
  // refuse Paint3 before any SurfaceMap reconstruction, even if it is empty.
  static std::shared_ptr<PaintedMesh> decode(const nlohmann::json &, const PaintImageArchive *,
      bool allow_polygon,const NormalSamplingArchive *,const PaintSamplingArchive *,bool allow_physical_emission);

private:
  friend class Document;
  void swap_state(PaintedMesh &) noexcept;
  friend struct SourceUvBakeAccess;
  friend struct SourcePaintAccess;
  friend struct SourceColorPreparationAccess;
  friend struct detail::PaintOverlayFactory;
  friend struct detail::EmissionExportAccess;
  friend struct detail::NativeWeightPaintAccess;
  friend struct detail::TextureSetPaintAccess;
  friend struct PolygonPaintAccess;
  friend struct SourceNormalPreparationAccess;
  friend struct SourcePaintSamplingAccess;
  friend struct SourceKeyPaintAccess;
  friend struct detail::PolygonSurfacePaintCodec;
  nlohmann::json encode_native_payload(PaintImageArchive *,NormalSamplingArchive *,PaintSamplingArchive *,
      const detail::PolygonSurfaceOwner *) const;
  static std::shared_ptr<PaintedMesh> decode_native_payload(const nlohmann::json &,const PaintImageArchive *,
      bool,const NormalSamplingArchive *,const PaintSamplingArchive *,const SourcePaintDecodeContext &,
      const detail::PolygonSurfaceStage *);
  void seal_paint_sampling_attachment();
  // Only the owning Scene40 membership archive may omit the current geometry.
  // Legacy/public paint entry points never supply this sealed domain.
  nlohmann::json encode_impl(PaintImageArchive *,NormalSamplingArchive *,PaintSamplingArchive *,
      const std::shared_ptr<const TextureSetFaceDomain> &,const detail::PolygonSurfaceOwner * = nullptr,
      const detail::TextureSetFieldSource*source_field=nullptr) const;
  static std::shared_ptr<PaintedMesh> decode_impl(const nlohmann::json &,const PaintImageArchive *,
      bool,const NormalSamplingArchive *,const PaintSamplingArchive *,const SourcePaintDecodeContext &,
      const std::shared_ptr<const TextureSetFaceDomain> &,const detail::PolygonSurfaceStage * = nullptr,
      const PaintedMesh*shared_raster=nullptr,const detail::TextureSetFieldSource*source_field=nullptr);
  PaintedMesh() = default;
  PaintedMesh(Mesh, uint32_t, const PaintSurfaceOptions &);
  PaintedMesh(Mesh, uint32_t, const PaintSurfaceOptions &,std::shared_ptr<const PaintSamplingDomain>);
  PaintedMesh(std::shared_ptr<const Mesh>,uint32_t,const PaintSurfaceOptions &,std::shared_ptr<const PaintSamplingDomain>,std::shared_ptr<const TextureSetFaceDomain> = {});
  struct PaintSample { PaintSettings settings; float opacity = 1; };
  using PaintSampler = std::function<std::optional<PaintSample>(Vec3,Vec3)>;
  void stamp_sampled(const Brush &, const PaintSettings &, const PaintSampler &, const std::function<bool()> &cancelled = {}, const Evaluation * = nullptr);
  void stamp_projected(const Brush &, const PaintSettings &, const PaintProjection &,
                       const Evaluation *, const std::function<bool()> &);
  struct SurfaceMap;
  struct CompositeCache;
  std::shared_ptr<const TextureMaps> build_composite(const Material &) const;
  std::shared_ptr<const TextureMaps> build_composite(const Material &, const std::function<bool()> &) const;
  std::shared_ptr<CompositeCache> composite_cache_;
  uint64_t composite_token_ = 0, before_composite_token_ = 0;
  std::shared_ptr<const SurfaceMap> surface_;
  // Independent writable membership; geometry/raster can be shared by sets.
  std::shared_ptr<const TextureSetFaceDomain> texture_set_domain_;
  std::shared_ptr<const PaintSamplingAttachment> sampling_attachment_;
  std::shared_ptr<const PaintSourceMaps> source_maps_;
  std::shared_ptr<const PaintColorProjection> color_projection_;
  std::shared_ptr<const PaintNormalProjection> normal_projection_;
  std::vector<PaintLayer> layers_;
  std::shared_ptr<const BakedTextures> baked_;
  uint64_t active_ = 1, next_ = 2, revision_ = 1;
  bool editing_ = false;
  using Tiles = std::vector<std::shared_ptr<const PaintTile>>;
  using ColorTiles = std::vector<std::shared_ptr<const PaintColorTile>>;
  using EmissionTiles = std::vector<std::shared_ptr<const PaintEmissionTile>>;
  struct Stroke {
    uint64_t layer;
    Tiles before, after;
    size_t bytes;
    size_t before_tiles = 0, after_tiles = 0;
    ColorTiles color_before, color_after;
    size_t before_color_tiles = 0, after_color_tiles = 0;
    EmissionTiles emission_before, emission_after;
  };
  Tiles before_;
  ColorTiles before_colors_;
  EmissionTiles before_emission_;
  std::deque<Stroke> undo_, redo_;
  size_t history_bytes_ = 0;
  PaintLayer &active();
  const PaintLayer &layer(uint64_t) const;
  size_t allocated_tiles_ = 0, before_allocated_tiles_ = 0;
  size_t allocated_color_tiles_ = 0, before_allocated_color_tiles_ = 0;
};
float srgb_to_linear(float);
float linear_to_srgb(float);
} // namespace dome
