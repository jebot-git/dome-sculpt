// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "affine.hpp"
#include "mesh-processing.hpp"
#include "polygon-color.hpp"
#include "polygon.hpp"
#include <deque>
namespace dome {
// Geometry operation data, not a material/paint authority. Persistent immutable
// nodes retain exact local gesture deltas and world-metric operation witnesses.
struct PolygonReplayStep {PolygonEdit edit;std::optional<AffineTransform> world;};
struct PolygonReplayNode {
 PolygonReplayStep step;
 std::shared_ptr<const PolygonReplayNode> previous;
 size_t depth=0,entries=0;
};
struct PolygonDrawData {
  std::vector<float> move_weights;
  // For each packed corner, N(delta) = N(0) + cross(delta, coefficient).
  // Prepared once per selection; the shader updates N-gon normals per motion.
  std::vector<Vec3> normal_coefficients;
  std::vector<uint32_t> wire_indices, selected_edges, selected_points;
  Vec3 selection_center{};
  bool has_selection = false;
};
struct PolygonView {
  std::shared_ptr<const PolygonMesh> topology;
  std::shared_ptr<const PolygonRender> surface;
  std::shared_ptr<const PolygonSelection> selection;
  std::shared_ptr<const PolygonDrawData> display;
  std::shared_ptr<const PolygonColorField> colors;
  Vec3 move_delta{}; // GPU preview only; source triangles/BVH stay immutable.
  uint64_t revision = 1;
  bool changed = false, can_undo = false, can_redo = false;
  bool moving = false, busy = false, committing = false;
  std::string error;
  std::shared_ptr<const PolygonReplayNode> replay;
  bool replay_complete=true;
};
// Worker-owned component workspace. All snapshots own immutable geometry and
// selection; frontends never build triangulations/BVHs or mutate this object.
class PolygonWorkspace {
public:
  explicit PolygonWorkspace(PolygonMesh, const PolygonLimits & = {});
  PolygonWorkspace(PolygonMesh, std::shared_ptr<const PolygonColorField>,
                   const PolygonLimits &);
  const PolygonView &view() const { return *current_.view; }
  void mode(PolygonSelectionMode, const PolygonLimits & = {});
  void select(PolygonId, bool additive = false, bool toggle = false,
              const PolygonLimits & = {});
  void select_all(const PolygonLimits & = {});
  void clear_selection(const PolygonLimits & = {});
  bool select_ray(Vec3 origin, Vec3 direction, float maximum_distance,
                  float component_radius, bool additive = false,
                  bool toggle = false, const PolygonLimits & = {},
                  bool preserve_selected_group = false);
  void apply(PolygonOperation, Vec3 delta = {}, float amount = 0,
             unsigned cuts = 1, const PolygonLimits & = {});
  // Exact world metric; topology, stable IDs, UV/color provenance and history
  // remain local. These do not fit a similarity transform to an affine frame.
  bool select_ray_affine(const AffineTransform &, Vec3 world_origin,
                         Vec3 world_direction, float maximum_world_distance,
                         float world_component_radius, bool additive = false,
                         bool toggle = false, const PolygonLimits & = {},
                         bool preserve_selected_group = false);
  void apply_affine(const AffineTransform &, PolygonOperation,
                    float world_amount, unsigned cuts = 1,
                    const PolygonLimits & = {});
  void begin_move();
  // Total displacement from Begin, not a sum of lossy floating-point deltas.
  void move_to(Vec3 total_delta, const PolygonLimits & = {});
  void end_move(bool accept, const PolygonLimits & = {});
  bool undo();
  bool redo();
  PolygonId identity_cursor() const { return high_water_; }

private:
  struct Snapshot {
    std::shared_ptr<const PolygonView> view;
    std::shared_ptr<const SurfaceQuery> query;
  };
  Snapshot current_;
  std::shared_ptr<const PolygonMesh> original_;
  std::deque<Snapshot> undo_, redo_;
  std::optional<Snapshot> gesture_;
  PolygonId high_water_ = 1;
  size_t maximum_history_components_ = 8'000'000;
  Snapshot prepare(PolygonMesh, PolygonSelection, const PolygonLimits &,
                   std::shared_ptr<const PolygonColorField> = {}) const;
  Snapshot decorate(Snapshot, bool can_undo, bool can_redo, bool moving) const;
  void selection(PolygonSelection, const PolygonLimits &);
  void commit(Snapshot, Snapshot before);
  void trim_history();
};
} // namespace dome
