// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "dome/texture-sets.hpp"
namespace dome::detail {
struct TextureSetDraw {
  TextureSetId set=0;
  size_t first=0,count=0;
};
// One current geometry authority, one partitioned EBO and one explicit logical
// corner stream. No per-set Mesh or deformation copy. Plain fields and genuine
// retained polygon field descriptors have separate owning producers; unsupported
// source roles and posed retained frames remain explicitly guarded.
class TextureSetSurfacePlan {
public:
  uint64_t object()const noexcept{return object_;}
  size_t preparation_work()const noexcept{return preparation_work_;}
  size_t preparation_bytes()const noexcept{return preparation_bytes_;}
  void authenticate_owner(const std::shared_ptr<const TextureSetSurfacePlan>&)const;
  const std::shared_ptr<const Mesh>&geometry()const noexcept{return geometry_;}
  const std::shared_ptr<const DeformationState>&deformation()const noexcept{return deformation_;}
  const std::shared_ptr<const TextureSetCollection>&collection()const noexcept{return collection_;}
  std::span<const TextureSetView>fields()const noexcept{return fields_;}
  std::span<const TextureSetDraw>draws()const noexcept{return draws_;}
  std::span<const uint32_t>indices()const noexcept{return indices_;}
  std::span<const uint32_t>logical_corners()const noexcept{return corners_;}
  // Worker-only exact REST replay before evaluating pose/world transforms.
  void authenticate_rest(const Mesh&,const std::shared_ptr<const DeformationState>&,
                         const TextureSetLimits & = {})const;
private:
  friend std::shared_ptr<const TextureSetSurfacePlan> prepare_texture_set_surface(const SculptObject&,const TextureSetLimits&);
  TextureSetSurfacePlan()=default;
  TextureSetSurfacePlan(const TextureSetSurfacePlan&)=delete;
  TextureSetSurfacePlan(TextureSetSurfacePlan&&)=default;
  uint64_t object_=0;
  size_t preparation_work_=0,preparation_bytes_=0;
  mutable std::weak_ptr<const TextureSetSurfacePlan>self_;
  std::shared_ptr<const Mesh>geometry_;
  std::shared_ptr<const DeformationState>deformation_;
  std::shared_ptr<const TextureSetCollection>collection_;
  std::vector<TextureSetView>fields_;
  std::vector<TextureSetDraw>draws_;
  std::vector<uint32_t>indices_,corners_;
};
bool texture_set_plain_fields(const SculptObject&)noexcept;
std::shared_ptr<const TextureSetSurfacePlan> prepare_texture_set_surface(
    const SculptObject&,const TextureSetLimits & = {});
} // namespace dome::detail
