#include "canonical-paint-native.hpp"
// SPDX-License-Identifier: GPL-3.0-or-later
#include "dome/document.hpp"
#include "dome/import.hpp"
#include "dome/import-authoring.hpp"
#include "dome/mesh-authoring.hpp"
#include "document-transaction.hpp"
#include "native-paint-sampling.hpp"
#include "text-utf8.hpp"
#include "texture-set-stroke.hpp"
namespace dome {
SceneDraft Document::draft_scene() const {
  std::lock_guard lock(model_mutex_);
  if (state_.creator || state_.cut || state_.retopology || state_.asset_busy || state_.recovery_busy || control_before_ || action_active_locked())
    throw std::logic_error("Finish the current action before opening the asset editor");
  return {scene_.snapshot(), {state_.generation, state_.revision, scene_.active().id,state_.edit_authority}};
}
void Document::edit_scene(std::string label, SceneOperation operation, AssetSource expected) {
  queue_scene_operation(std::move(label), std::move(operation), expected, {});
}
void Document::queue_scene_operation(std::string label, SceneOperation operation,
                                    AssetSource expected, std::shared_ptr<std::string> report) {
  std::lock_guard lock(model_mutex_);
  queue_scene_operation_locked(std::move(label), std::move(operation), expected, std::move(report));
}
void Document::queue_scene_operation_locked(std::string label, SceneOperation operation,
                                      AssetSource expected, std::shared_ptr<std::string> report, std::shared_ptr<AssetWork> work, std::shared_ptr<bool> changed,
                                      std::shared_ptr<const MeshSnapshot> rollback_preview, uint64_t retopo_session, uint64_t cut_session, std::shared_ptr<CutHandoff> cut_handoff, std::optional<BakeAdmission> bake_admission, uint64_t uv_restore_session, std::optional<SkinAdmission> skin_admission, std::shared_ptr<const detail::TextureSetStrokeLease> texture_set_source) {
  require_authority_locked(expected);
  if(state_.creator)throw std::logic_error("Apply or cancel the humanoid creator before starting authoring work");
  if(state_.expressions)throw std::logic_error("Apply or cancel expression preview before starting authoring work");
  if(state_.object_grabbing && !(work&&work->held_weight))throw std::logic_error("Release object motion before starting asset work");
  if(state_.isolate_held && state_.held_object)require_object_editable_locked(scene_.active().id);
  if (label.empty() || label.size() > 256 || label.find('\0') != std::string::npos || !operation)
    throw std::invalid_argument("Invalid asset operation");
  if ((expected.generation && expected.generation != state_.generation) ||
      (expected.revision && expected.revision != state_.revision) ||
      (expected.object && expected.object != scene_.active().id))
    throw std::logic_error("The asset editor source changed; reopen the editor");
  // A source Restore consumes only its exact ready UV workspace, within the
  // queue's existing rollback transaction. It never bypasses stroke ownership.
  const bool restore_uv=uv_restore_session&&uv_restore_session==uv_session_&&uv_&&control_before_&&
      !uv_accept_pending_&&!uv_solving_&&uv_->view().topology&&!uv_->view().validating&&
      state_.controls.parameter==VrParameter::UvEdit&&control_object_==scene_.active().id&&
      (detail::native_paint_source_restorable(scene_.active())||detail::canonical_paint_source_restorable(scene_.active()));
  if(uv_restore_session&&!restore_uv)throw std::logic_error("The source Restore lost its exact ready UV workspace");
  if (state_.asset_busy || state_.recovery_busy || (control_before_&&!restore_uv) || action_active_locked())
    throw std::logic_error("Finish the current action before starting asset work");
  if(state_.polygon)throw std::logic_error("Apply or cancel polygon editing before starting asset work");
  if (state_.retopology && (!retopo_session || retopo_session != retopo_session_.load()))
    throw std::logic_error("Apply or cancel retopology before starting asset work");
  if (state_.cut && (!cut_session || cut_session != cut_session_.load()))
    throw std::logic_error("Apply or cancel the plane cut before starting asset work");
  if(cut_handoff && (!cut_session || state_.cut!=cut_handoff->draft || !cut_handoff->accepting ||
      cut_handoff->accepting->session!=cut_session || !cut_handoff->accepting->committing))
    throw std::logic_error("Cut Apply admission lost its exact ready draft");
  if(texture_set_source){texture_set_source->authenticate_owner(texture_set_source);texture_set_source->authenticate_scene(scene_);}
  FileJob job{scene_.snapshot(), {}, state_.revision, state_.generation, content_, false};
  job.texture_set_source=std::move(texture_set_source);
  job.object = scene_.active().id;job.edit_authority=state_.edit_authority;job.isolation_target=state_.isolate_held?state_.held_object:0;
  job.scene_operation = std::move(operation);
  job.operation_label = std::move(label);
  job.operation_report = std::move(report);
  job.work = work ? std::move(work) : std::make_shared<AssetWork>();
  job.work->accepted_scene = true;
  job.operation_changed = std::move(changed);
  job.rollback_preview = std::move(rollback_preview);
  job.retopo_session = retopo_session;
  job.cut_session = cut_session;
  job.cut_handoff = std::move(cut_handoff);
  std::lock_guard file_lock(file_mutex_);
  if (files_.size() >= 8) throw std::runtime_error("File and asset work queue is full");
  Transaction transaction(*this);
  if(restore_uv){transaction.finish_uv();desktop_=false;}
  files_.push_back(std::move(job));
  try {
  asset_work_.store(files_.back().work);
  state_.asset_busy = true;
  if(bake_admission){
    static_assert(std::is_nothrow_copy_assignable_v<ObjectBakeSettings>);
    state_.bake_source=bake_admission->source;
    state_.bake_settings=bake_admission->settings;
  }
  if(skin_admission){
    static_assert(std::is_nothrow_move_assignable_v<SkinAuthoringOptions>);
    state_.skin_options=std::move(skin_admission->options);
    state_.skin_use_locks=skin_admission->use_locks;
    if(skin_admission->use_locks)state_.weights.locks.swap(skin_admission->locks);
  }
  if(files_.back().cut_handoff){
    state_.cut=files_.back().cut_handoff->accepting;
    input_.cancel();
  }
  state_.error.clear();
  state_.message = files_.back().operation_label + "...";
  publish_locked(false,false);transaction.commit();
  }catch(...){files_.pop_back();throw;}
  file_changed_.notify_one();
}
void Document::remesh_to_sculpt(float world_voxel_mm, AssetSource expected) {
  std::lock_guard lock(model_mutex_);
  queue_voxel_sculpt_locked(world_voxel_mm, expected);
}
void Document::queue_voxel_sculpt_locked(float world_voxel_mm, AssetSource expected) {
  if (!std::isfinite(world_voxel_mm) || world_voxel_mm < .01f || world_voxel_mm > 1000)
    throw std::invalid_argument("Voxel size must be between 0.01 and 1000 mm");
  queue_scene_operation_locked("Voxel remesh", [world_voxel_mm](Scene &scene, const auto &cancelled) {
    create_voxel_sculpt(scene, world_voxel_mm, cancelled);
  }, expected, {});
}
void Document::remesh_to_triangles(float world_edge_mm,AssetSource expected) {
  std::lock_guard lock(model_mutex_);
  queue_triangle_remesh_locked(world_edge_mm,expected);
}
void Document::queue_triangle_remesh_locked(float world_edge_mm,AssetSource expected) {
  if(!std::isfinite(world_edge_mm)||world_edge_mm<.01f||world_edge_mm>1000)
    throw std::invalid_argument("Edge length must be between 0.01 and 1000 mm");
  queue_scene_operation_locked("Isotropic remesh",[world_edge_mm](Scene &scene,const auto &cancelled){
    create_triangle_remesh(scene,world_edge_mm,cancelled);
  },expected,{});
}
void Document::import_asset(const std::filesystem::path &path,uint32_t resolution) {
  ImportSettings settings;settings.paint_resolution=resolution;import_asset(path,settings);
}
AssetSource Document::begin_import() const {
  std::lock_guard lock(model_mutex_);
  return {state_.generation,state_.revision,scene_.active().id,state_.edit_authority};
}
void Document::import_asset(const std::filesystem::path &path,const ImportSettings &settings,AssetSource expected) {
  settings.validate();std::lock_guard lock(model_mutex_);import_asset_locked(path,settings,expected);
}
void Document::import_asset_locked(const std::filesystem::path &path,const ImportSettings &settings,AssetSource expected) {
  settings.validate();require_authority_locked(expected);
  if(state_.object_grabbing)throw std::logic_error("Release object motion before importing a model");
  if(state_.isolate_held && state_.held_object)throw std::logic_error("Release held-object isolation before importing another object");
  if(!expected.generation && !expected.revision && !expected.object && !expected.edit_authority)
    expected={state_.generation,state_.revision,scene_.active().id,state_.edit_authority};
  auto report = std::make_shared<std::string>();
  auto view=import_view_?std::make_shared<ImportView>(*import_view_):nullptr;
  if(view)view->settings=settings;
  queue_scene_operation_locked("Import mesh", [path, settings, report](Scene &scene, const auto &cancelled) {
    ImportAuthoringOptions options;options.paint_resolution=settings.paint_resolution;options.choices=settings.choices;options.prepare_texture_atlas=settings.prepare_texture_atlas;options.limits.cancelled=cancelled;options.limits.max_file_bytes=256*1024*1024;
    auto prepared=prepare_authoring_import(scene,path,std::move(options));
    for(size_t i=0;i<std::min<size_t>(prepared.diagnostics.size(),8);++i){if(!report->empty())*report+="; ";*report+=text::utf8_prefix(prepared.diagnostics[i],200);}
    if(prepared.diagnostics.size()>8)*report+="; additional import diagnostics omitted";
    scene=std::move(prepared.scene);
  }, expected, report);
  // Queue publication is transactional. All remaining assignments are noexcept;
  // never report a rejected import after its worker has already been accepted.
  import_settings_=settings;
  if(view){import_view_=std::move(view);state_.importing=import_view_;}
}
} // namespace dome
