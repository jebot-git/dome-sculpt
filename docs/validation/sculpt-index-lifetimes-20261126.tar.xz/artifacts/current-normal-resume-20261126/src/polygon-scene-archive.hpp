// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "dome/creator-archive.hpp"
#include "dome/material-bindings.hpp"
#include "dome/polygon-scene.hpp"
#include "polygon-color-archive.hpp"
#include <functional>
#include <memory>
#include <set>
namespace dome::detail {
class SourcePlacementArchive;
class PolygonSceneReader;
class TextureSetArchive;
// Bounded immutable graph archive. Source IDs are data, never object lookups.
class PolygonSceneArchive {
public:
  uint32_t add(std::shared_ptr<const PolygonAuthority>, bool deep = true);
  uint32_t add_origin(std::shared_ptr<const PolygonOrigin>, bool deep = true);
  uint32_t add_rig_origin(std::shared_ptr<const PolygonOrigin> origin,
                          bool deep = true) {
    direct_rig_origins_ = true;
    return add_origin(std::move(origin), deep);
  }
  const std::shared_ptr<const PolygonAuthority> &at(uint32_t) const;
  const auto &authorities() const { return authorities_; }
  const auto &origins() const { return origins_; }
  const auto &volumes() const { return volumes_; }
  const auto &paints() const { return paints_; }
  size_t component_entries() const { return entries_; }
  const PolygonColorArchive &color_archive() const { return colors_; }
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,
                        SourceMaterialArchive &,
                        SourcePlacementArchive * = nullptr) const;
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,
                        SourceMaterialArchive &, SourcePlacementArchive *,
                        PolygonColorArchive *) const;
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,
                        SourceMaterialArchive &, SourcePlacementArchive *,
                        PolygonColorArchive *, NormalSamplingArchive *) const;
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,
                        SourceMaterialArchive &, SourcePlacementArchive *,
                        PolygonColorArchive *, NormalSamplingArchive *,
                        PaintSamplingArchive *) const;
  nlohmann::json encode(PaintImageArchive &, CreatorAssetArchive &,
                        SourceMaterialArchive &, SourcePlacementArchive *,
                        PolygonColorArchive *, NormalSamplingArchive *,
                        PaintSamplingArchive *, TextureSetArchive *) const;
  static void preflight(const nlohmann::json &, const nlohmann::json &objects);
  static void preflight(const nlohmann::json &, const nlohmann::json &objects,
                        const nlohmann::json *materials);
  static void preflight(const nlohmann::json &, const nlohmann::json &objects,
                        const nlohmann::json *materials,
                        const nlohmann::json *canonical_paint);
  static void preflight(const nlohmann::json &, const nlohmann::json &objects,
                        const nlohmann::json *materials,
                        const nlohmann::json *canonical_paint,
                        const nlohmann::json *polygon_surfaces);
  static void preflight(const nlohmann::json &, const nlohmann::json &,
                        const nlohmann::json *, const nlohmann::json *,
                        const nlohmann::json *,
                        const nlohmann::json *texture_geometry);
  // The owning Scene supplies its real, short-lived native read capability.
  // Retained origins must receive the same context as current paint records.
  static void preflight(const nlohmann::json &, const nlohmann::json &,
                        const nlohmann::json *, const nlohmann::json *,
                        const nlohmann::json *, const nlohmann::json *,
                        const SourcePaintDecodeContext &);
  static PolygonSceneArchive decode(const nlohmann::json &,
                                    const PaintImageArchive &,
                                    const CreatorAssetArchive &,
                                    const SourceMaterialArchive &,
                                    const SourcePlacementArchive * = nullptr);
  static PolygonSceneArchive
  decode(const nlohmann::json &, const PaintImageArchive &,
         const CreatorAssetArchive &, const SourceMaterialArchive &,
         const SourcePlacementArchive *, const PolygonColorArchive *);
  static PolygonSceneArchive
  decode(const nlohmann::json &, const PaintImageArchive &,
         const CreatorAssetArchive &, const SourceMaterialArchive &,
         const SourcePlacementArchive *, const PolygonColorArchive *,
         const NormalSamplingArchive *);
  static PolygonSceneArchive
  decode(const nlohmann::json &, const PaintImageArchive &,
         const CreatorAssetArchive &, const SourceMaterialArchive &,
         const SourcePlacementArchive *, const PolygonColorArchive *,
         const NormalSamplingArchive *, const PaintSamplingArchive *);
  static PolygonSceneArchive
  decode(const nlohmann::json &, const PaintImageArchive &,
         const CreatorAssetArchive &, const SourceMaterialArchive &,
         const SourcePlacementArchive *, const PolygonColorArchive *,
         const NormalSamplingArchive *, const PaintSamplingArchive *,
         const SourcePaintDecodeContext &);
  static PolygonSceneArchive
  decode(const nlohmann::json &, const PaintImageArchive &,
         const CreatorAssetArchive &, const SourceMaterialArchive &,
         const SourcePlacementArchive *, const PolygonColorArchive *,
         const NormalSamplingArchive *, const PaintSamplingArchive *,
         bool physical_emission);

  static PolygonSceneArchive
  decode(const nlohmann::json &, const PaintImageArchive &,
         const CreatorAssetArchive &, const SourceMaterialArchive &,
         const SourcePlacementArchive *, const PolygonColorArchive *,
         const NormalSamplingArchive *, const PaintSamplingArchive *,
         const SourcePaintDecodeContext &, TextureSetArchive *);

private:
  friend class PolygonSceneReader;
  size_t entries_ = 0;
  PolygonColorArchive colors_;
  std::set<const PolygonAuthority *> deeply_validated_;
  std::set<const PolygonOrigin *> deeply_validated_origins_;
  bool direct_origins_ = false, direct_rig_origins_ = false;
  void collect(std::shared_ptr<const PolygonAuthority>,
               std::shared_ptr<const PolygonOrigin>, bool deep);
  std::vector<std::shared_ptr<const PolygonAuthority>> authorities_;
  std::vector<std::shared_ptr<const PolygonOrigin>> origins_;
  std::vector<std::shared_ptr<const Volume>> volumes_;
  std::vector<std::shared_ptr<const PaintedMesh>> paints_;
};
// Scene37 can own a material -> before-origin -> earlier-material DAG. Resolve
// only the origins requested while a material prefix is complete, then finish
// the actual Scene roots. The enclosing Scene preflight still charges every
// record before this reader allocates any payload; this is not a validity
// cache.
class PolygonSceneReader {
public:
  using MaterialResolver =
      std::function<std::shared_ptr<const SourceMaterialBindings>(uint32_t)>;
  PolygonSceneReader(const nlohmann::json &, const PaintImageArchive &,
                     const CreatorAssetArchive &, MaterialResolver,
                     const SourcePlacementArchive *,
                     const PolygonColorArchive *, const NormalSamplingArchive *,
                     const PaintSamplingArchive *,
                     const SourcePaintDecodeContext &,
                     std::function<bool()> cancelled = {},
                     TextureSetArchive *texture_sets = nullptr);
  ~PolygonSceneReader();
  PolygonSceneReader(const PolygonSceneReader &) = delete;
  PolygonSceneReader &operator=(const PolygonSceneReader &) = delete;
  const std::shared_ptr<const PolygonOrigin> &origin_at(uint32_t);
  const std::shared_ptr<const PolygonAuthority> &authority_at(uint32_t);
  // Resolve only through this owning reader's currently installed material
  // prefix. Remains readable after finish; no new origin/replay is opened.
  std::shared_ptr<const SourceMaterialBindings> material_at(uint32_t)const;
  MaterialResolver material_resolver(MaterialResolver);
  void restore_material_resolver(MaterialResolver) noexcept;
  PolygonSceneArchive finish();

private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};
uint32_t polygon_archive_index(const nlohmann::json &, size_t count);
} // namespace dome::detail
