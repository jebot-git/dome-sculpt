// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "dome/scene.hpp"
#include "source-morph.hpp"
#include <nlohmann/json.hpp>
namespace dome::detail {
class NativeAuthoringCapture;
struct EmissionExportPrepared;
struct GltfObjectIdentity {
  int node = -1, mesh = -1, material = -1;
  std::vector<uint32_t> joints;
  PaintSourceTexture canonical_normal,prepared_normal;
};
struct GltfDocument {
  nlohmann::json json;
  std::vector<uint8_t> binary;
  std::vector<GltfObjectIdentity> objects;
  size_t normal_targets_recomputed = 0;
};
GltfDocument make_gltf(const std::vector<ObjectSurface> &,
                       SourceMorphSpace = SourceMorphSpace::Native,
                       bool recompute_changed_normals = false,
                       std::function<bool()> cancelled = {});
// Private Scene-owner path only; public strict writers retain their guard.
GltfDocument make_gltf_authoring(const NativeAuthoringCapture &,
    const std::vector<ObjectSurface> &, bool recompute_changed_normals,
    std::function<bool()> cancelled = {});
GltfDocument make_gltf_emission(const EmissionExportPrepared &, bool recompute_changed_normals, std::function<bool()> cancelled);
class Vrm1AuthoringCompilation;
// Authenticated typed Scene compilation only. The ordinary exporter retains
// all prior transformed-normal guards and never receives this authority.
GltfDocument make_vrm1_authoring_gltf(const Vrm1AuthoringCompilation &,
 const std::function<bool()> &);
void write_glb(GltfDocument, const std::filesystem::path &);
void write_glb(GltfDocument, const std::filesystem::path &,
               const std::function<bool()> &cancelled,
               const std::function<void()> &before_commit);
} // namespace dome::detail
