// SPDX-License-Identifier: GPL-3.0-or-later
#include "dome/skin-authoring.hpp"
#include "skin-affine.hpp"
#include "automatic-humanoid-bind.hpp"
#include "normal-frame-runtime.hpp"
#include "polygon-conversion.hpp"
#include "source-rest-scene.hpp"
#include <nlohmann/json.hpp>
namespace dome {
namespace {
void stop(const std::function<bool()> &cancelled) {
  if (cancelled && cancelled()) throw std::runtime_error("Skin authoring cancelled");
}
Vec3 point(const CanvasTransform &t, Vec3 p) {
  auto result=ob::transform(t,{p.x,p.y,p.z}); return {result.x,result.y,result.z};
}
Vec3 direction(const CanvasTransform &t, Vec3 p) {
  auto result=ob::rotate(t.orientation,{p.x,p.y,p.z}); return {result.x,result.y,result.z};
}
JointTransform root_transform(JointTransform joint,const CanvasTransform &t) {
  joint.translation=point(t,joint.translation);
  const auto &q=t.orientation;
  joint.rotation=(Quat{q.w,q.x,q.y,q.z}*joint.rotation).unit();
  joint.scale=joint.scale*t.scale;
  return joint;
}
}
void AnatomicalSkinOptions::validate() const {
  if(!maximum_work||maximum_work>500'000'000||maximum_workspace<65536||
     maximum_workspace>256u*1024u*1024u||maximum_total<maximum_workspace||
     maximum_total>512u*1024u*1024u)
    throw std::invalid_argument("Invalid anatomical work, workspace or owning-request bound");
}
void SkinAuthoringOptions::validate() const {
  if(mode!=SkinAuthoringMode::Automatic && mode!=SkinAuthoringMode::Transfer && mode!=SkinAuthoringMode::Anatomical && mode!=SkinAuthoringMode::SurfaceHeat)
    throw std::invalid_argument("Unknown skin authoring operation");
  if(!reference || !std::isfinite(seed_distance) || seed_distance<0 || seed_distance>10000 ||
     !std::isfinite(seed_margin) || seed_margin<0 || seed_margin>10000 ||
     !std::isfinite(transfer_distance) || transfer_distance<0 || transfer_distance>10000 ||
     !std::isfinite(falloff) || falloff<1 || falloff>8 ||
     !maximum_work || maximum_work>500'000'000 ||
     !limits.max_influences || limits.max_influences>32 ||
     !std::isfinite(limits.prune) || limits.prune<0 || limits.prune>=1 || locks.size()>256 ||
     std::any_of(locks.begin(),locks.end(),[](uint8_t v){return v>1;}))
    throw std::invalid_argument("Invalid skin distance, falloff, influence, lock or work bounds");
  if(mode==SkinAuthoringMode::Anatomical||mode==SkinAuthoringMode::SurfaceHeat)anatomical.validate();
  if(((mode==SkinAuthoringMode::Automatic||mode==SkinAuthoringMode::SurfaceHeat) && seed_distance<=0) ||
     (mode==SkinAuthoringMode::Automatic && seed_margin>seed_distance) ||
     (mode==SkinAuthoringMode::Transfer && transfer_distance<=0))
    throw std::invalid_argument("Automatic seeds need a positive radius and contained margin; transfer needs a positive radius");
}
float skin_distance_metres(float t) {
  if(!std::isfinite(t) || t<0 || t>1) throw std::invalid_argument("Invalid skin distance slider");
  if(t==1)return 10000;
  return float(std::expm1(double(t)*std::log1p(1e9))*1e-5);
}
float skin_distance_slider(float metres) {
  if(!std::isfinite(metres) || metres<0 || metres>10000) throw std::invalid_argument("Invalid world skin distance");
  return float(std::log1p(double(metres)*1e5)/std::log1p(1e9));
}
bool author_skin(Scene &scene,uint64_t target_id,const SkinAuthoringOptions &options,
                 const std::function<bool()> &cancelled) {
  stop(cancelled);
  options.validate();
  if(options.mode==SkinAuthoringMode::SurfaceHeat)return author_surface_heat_skin(scene,std::span<const uint64_t>(&target_id,1),options,cancelled);
  if(options.mode==SkinAuthoringMode::Anatomical)return author_anatomical_skin(scene,std::span<const uint64_t>(&target_id,1),options,cancelled);
  const auto &target=scene.object(target_id), &reference=scene.object(options.reference);
  if(!target.visible || target.locked || !target.mesh_active || !target.painted)
    throw std::invalid_argument("Select a visible, unlocked mesh to bind");
  if(!reference.mesh_active || !reference.painted || !reference.deformation ||
     !reference.deformation->skeleton ||
     (options.mode==SkinAuthoringMode::Transfer && !reference.deformation->skin))
    throw std::invalid_argument("Choose a fitted reference skeleton; transfer also requires source skin weights");
  if(options.mode==SkinAuthoringMode::Transfer && reference.id==target.id)
    throw std::invalid_argument("Choose another mesh as the weight-transfer source");
  if(options.mode!=SkinAuthoringMode::Automatic && options.mode!=SkinAuthoringMode::Transfer)
    throw std::invalid_argument("Unknown skin authoring operation");
  const auto &source=*reference.deformation;
  source.validate(reference.painted->mesh());
  if(target.id!=reference.id && target.deformation) target.deformation->validate(target.painted->mesh());
  stop(cancelled);
  const bool exact_metric=scene.has_affine_placement(reference.id)||scene.has_affine_placement(target.id)||
    source.skeleton->space_matrix||source.skeleton->inverse_bind_override||
    std::any_of(source.pose.begin(),source.pose.end(),[](const JointTransform &p){return bool(p.full_local_matrix);})||
    std::any_of(source.skeleton->bones.begin(),source.skeleton->bones.end(),[](const Bone &b){return bool(b.rest_matrix);});
  auto reference_world=exact_metric?CanvasTransform{}:scene.world_transform(reference.id);
  auto target_world=exact_metric?CanvasTransform{}:scene.world_transform(target.id);
  auto source_to_target=ob::compose(ob::inverse(target_world),reference_world);
  auto target_to_source=ob::compose(ob::inverse(reference_world),target_world);
  auto reference_matrix=exact_metric?scene.world_matrix(reference.id):AffineTransform{};
  auto target_matrix=exact_metric?scene.world_matrix(target.id):AffineTransform{};
  // Translation does not belong to a distance metric. Use one common world
  // origin so distant valid placements neither lose float precision nor hit
  // the solver's local coordinate bound merely because of a shared offset.
  auto origin=AffineTransform{}.matrix();
  for(size_t i=0;i<3;++i)origin[12+i]=-reference_matrix.matrix()[12+i];
  const auto shift=AffineTransform(origin);
  const auto reference_metric=shift*reference_matrix,target_metric=shift*target_matrix;
  auto change=target_metric.inverse()*reference_metric;
  detail::SkinGeometryWork placement_work(options.maximum_work,cancelled);
  auto skeleton=*source.skeleton;
  auto pose=source.pose;
  for(size_t i=0;!exact_metric && i<skeleton.bones.size();++i) if(skeleton.bones[i].parent<0) {
    skeleton.bones[i].rest=root_transform(skeleton.bones[i].rest,source_to_target);
    if(!pose.empty()) pose[i]=root_transform(pose[i],source_to_target);
  }
  skeleton.validate();
  bool existing=target.deformation && target.deformation->skeleton;
  // Identity placement keeps the original exact encoding, avoiding quaternion
  // renormalization noise during an ordinary rebind to the selected mesh.
  auto equal_placement=[](const CanvasTransform &a,const CanvasTransform &b) {
    bool rotation=(a.orientation.x==b.orientation.x && a.orientation.y==b.orientation.y &&
                   a.orientation.z==b.orientation.z && a.orientation.w==b.orientation.w) ||
                  (a.orientation.x==-b.orientation.x && a.orientation.y==-b.orientation.y &&
                   a.orientation.z==-b.orientation.z && a.orientation.w==-b.orientation.w);
    return a.position.x==b.position.x && a.position.y==b.position.y && a.position.z==b.position.z &&
      rotation && a.scale==b.scale;
  };
  bool same_placement=exact_metric?reference_matrix.matrix()==target_matrix.matrix():equal_placement(reference_world,target_world);
  if(exact_metric&&!same_placement)skeleton=detail::skin_reframe(*source.skeleton,change,placement_work);
  if(same_placement) { skeleton=*source.skeleton; pose=source.pose; }
  if(existing && target.deformation->skeleton->encode()!=skeleton.encode())
    throw std::invalid_argument("Target has a different rest rig; use an explicit joint-mapping workflow");
  if((!options.locks.empty() && (!existing || !target.deformation->skin ||
       options.locks.size()!=skeleton.bones.size())) ||
     std::any_of(options.locks.begin(),options.locks.end(),[](uint8_t v){return v>1;}))
    throw std::invalid_argument("Skin locks require the target's exact existing joint identities");
  if(existing && target.deformation->skin && !options.locks.empty()) {
    bool every_joint_locked=std::all_of(options.locks.begin(),options.locks.end(),[](uint8_t value){return value==1;});
    bool closed=true;
    size_t vertex=0;
    for(const auto &row:target.deformation->skin->vertices) {
      if(!(vertex++ &1023))stop(cancelled);
      double fixed=0;size_t count=0;
      for(auto influence:row) if(options.locks[influence.joint]) {fixed+=influence.weight;++count;}
      if(count>options.limits.max_influences)
        throw std::invalid_argument("Locked influences exceed the chosen influence cap");
      if(count!=row.size() || (!every_joint_locked && fixed<1-1e-6))closed=false;
    }
    if(closed){stop(cancelled);return false;}
  }
  std::optional<HumanLandmarks> affine_landmarks;
  if(!existing&&source.landmarks&&exact_metric&&!same_placement)
    affine_landmarks=detail::skin_reframe_landmarks(*source.landmarks,change,placement_work);
  auto rest=target.painted->mesh();
  for(size_t i=0;!exact_metric && !same_placement && i<rest.positions.size();++i) {
    if(!(i%1024)) stop(cancelled);
    rest.positions[i]=point(target_to_source,rest.positions[i]);
    rest.normals[i]=direction(target_to_source,rest.normals[i]);
  }
  if(exact_metric)rest=detail::skin_world_mesh(rest,target_metric,placement_work);
  SkinWeights weights;
  if(options.mode==SkinAuthoringMode::Automatic) {
    BindOptions bind; bind.limits=options.limits; bind.maximum_work=options.maximum_work;
    bind.maximum_seed_distance=options.seed_distance/reference_world.scale;
    bind.seed_margin=options.seed_margin/reference_world.scale; bind.falloff=options.falloff;
    auto solve_automatic = [&](const Mesh &mesh, const Skeleton &rig) {
      if (source.humanoid)
        return detail::automatic_bind_humanoid(mesh, rig, *source.humanoid,
                                               bind, cancelled);
      return automatic_bind(mesh, rig, bind, cancelled);
    };
    if(exact_metric){
      auto world_rig=detail::skin_reframe(*source.skeleton,reference_metric,placement_work);
      bind.maximum_seed_distance=options.seed_distance;bind.seed_margin=options.seed_margin;bind.maximum_work=placement_work.remaining();
      weights=solve_automatic(rest,world_rig);
    }else weights=solve_automatic(rest,*source.skeleton);
  } else {
    if(exact_metric){
      auto source_mesh=detail::skin_world_mesh(reference.painted->mesh(),reference_metric,placement_work);
      weights=transfer_weights(source_mesh,*source.skin,rest,skeleton.bones.size(),options.transfer_distance,options.limits,cancelled,placement_work.remaining());
    }else weights=transfer_weights(reference.painted->mesh(),*source.skin,rest,skeleton.bones.size(),
                             options.transfer_distance/reference_world.scale,options.limits,cancelled,options.maximum_work);
  }
  if(!options.locks.empty()) for(size_t vertex=0;vertex<weights.vertices.size();++vertex) {
    if(!(vertex%1024)) stop(cancelled);
    auto &candidate=weights.vertices[vertex];
    std::erase_if(candidate,[&](const Influence &i){return options.locks.at(i.joint);});
    for(auto influence:target.deformation->skin->vertices.at(vertex))
      if(options.locks.at(influence.joint)) candidate.push_back(influence);
    candidate=normalize_weights(std::move(candidate),skeleton.bones.size(),options.locks,options.limits);
  }
  if(existing && target.deformation->skin) {
    bool same=true;
    for(size_t vertex=0;vertex<weights.vertices.size();++vertex) {
      if(!(vertex%1024)) stop(cancelled);
      auto &row=weights.vertices[vertex];const auto &old=target.deformation->skin->vertices[vertex];
      bool equal=row.size()==old.size();
      for(const auto &i:row) equal &= std::any_of(old.begin(),old.end(),[&](const auto &o){return i==o;});
      if(equal)row=old;else same=false;
    }
    if(same){stop(cancelled);return false;}
  }
  auto next=target.deformation ? *target.deformation : DeformationState(target.painted->mesh());
  next.skeleton=std::move(skeleton); next.skin=std::move(weights);
  if(!existing) {
    next.pose=std::move(pose); next.humanoid=source.humanoid;
    if(source.landmarks) {
      next.landmarks=*source.landmarks;
      if(affine_landmarks)next.landmarks=std::move(affine_landmarks);
      else if(!same_placement) {
        for(auto &[name,p]:next.landmarks->points) p=point(source_to_target,p);
        next.landmarks->left=direction(source_to_target,next.landmarks->left);
        next.landmarks->up=direction(source_to_target,next.landmarks->up);
        next.landmarks->front=direction(source_to_target,next.landmarks->front);
      }
    }
  }
  next.validate(target.painted->mesh());
  // Skin changes keep the authored REST/corner and morph POSITION authority.
  // Check that association on this worker; current paint/normal owners are
  // preserved verbatim, never replaced by the reference object's material.
  if(target.material_bindings && target.material_bindings->normal_frames)
    detail::normal_frame_current_authority(*target.material_bindings,
        target.painted->mesh(),&next,cancelled);
  stop(cancelled);
  // Native bind/rebind needs the same complete first-source Restore contract
  // as native rig fitting. Original imported-node rigs keep their existing
  // source-graph Restore, and genuine no-ops returned above create no capsule.
  auto original=target.rig_source;
  if(!original && !detail::source_rest_identity(scene,target))
    original=capture_polygon_origin(scene,target.id);
  stop(cancelled);
  Scene result=scene;
  result.object(target.id).deformation=std::make_shared<const DeformationState>(std::move(next));
  result.object(target.id).rig_source=std::move(original);
  result.validate(false); stop(cancelled); scene=std::move(result);return true;
}
} // namespace dome
