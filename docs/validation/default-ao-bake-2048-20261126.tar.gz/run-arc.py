from pathlib import Path
import json
import subprocess
import sys
import time
root=Path(__file__).resolve().parent
unit='ds-default-ao-2048-asan-20261126.service'
while subprocess.run(['systemctl','--user','is-active','--quiet',unit]).returncode==0:
    time.sleep(2)
state=json.loads((root/'asan/status.json').read_text())
assert state['terminal'] and state['exit']==0,state
subprocess.run([sys.executable,root/'public-focus.py','arc'],check=True,timeout=360)
