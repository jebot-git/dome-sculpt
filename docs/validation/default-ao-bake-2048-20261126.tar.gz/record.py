from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
destination=repo/'docs/validation'
name='default-ao-bake-2048-20261126'

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
def keep(path):
    files[str(path.relative_to(root))]=path
    return sha(path)

files={}
product=subprocess.check_output(['git','-C',repo,'rev-parse','14fc52b4'],text=True).strip()
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',product])==(root/'source.patch').read_bytes()
report={'product':product,'patch_sha256':keep(root/'source.patch'),'native':{},'frontend':{},'byte_parity':{},
        'scope':'Default sixteen AO samples at 2048 in the normal-offset and matching-triangle native Bake routes, including live nested Wayland and synthetic OpenXR. Both AO and geometry projection are CPU work.',
        'target_texels':4194304,'ordinary_rays':71303168,'matching_rays':67108864}
for path in ('run.py','public-focus.py','wayland.py','xr-focus.py','ao-parity.cpp','ao-parity-first.cpp',
             'focused.py','secondary-normal.cpp','run-arc.py','record.py'):
    keep(root/path)
for p in ('release','asan'):
    out=root/p
    state=read(out/'status.json')
    assert state['terminal'] and state['exit']==0 and len(state['tests'])==12
    log=out/'ctest.log'
    message=log.read_text()
    assert 'DENSE_DEFAULT_AO ray=71303168 matching=67108864' in message
    assert 'PASS 16 full-resolution retained Bake checks' in message
    paths=['status.json','ctest.log','bake-authoring.cpp.log','bake.cpp.log','build/regressions.xml',
           'ao-parity-baseline-run.log','ao-parity-first-baseline-run.log','ao-parity-candidate-run.log',
           'ao-parity-exact.json','secondary-normal-candidate-run.log']
    record={n:keep(out/n) for n in paths}
    assert 'PASS seven exact AO pattern endpoints' in (out/'ao-parity-candidate-run.log').read_text()
    assert 'primary AO rays=23104 projected=1444' in (out/'secondary-normal-candidate-run.log').read_text()
    report['native'][p]={'checks':16,'app_sha256':state['app_sha256'],'core_sha256':state['core'],
        'ctests':state['tests'],'log_sha256':record,
        'ao_parity':read(out/'ao-parity-exact.json'),
        'secondary_pass_primary_ao_rays':23104}
assert report['native']['release']['ao_parity']==report['native']['asan']['ao_parity']
for name_part in ('retained-2048.dsculpt','baked-2048.dsculpt','matched-2048.dsculpt'):
    def file(p):return root/p/'build/native-writable-default-ao-2048'/name_part
    assert sha(file('release'))==sha(file('asan')),name_part
    report['byte_parity'][name_part]=sha(file('release'))
for mode,checks in (('wayland',9),('software',10),('arc',10)):
    out=root/(mode+'-focus-recipient')
    state=read(out/'status.json')
    assert state['terminal'] and state['exit']==0 and state['checks']==checks
    assert state['native_sha256']==report['byte_parity']['matched-2048.dsculpt']
    report['frontend'][mode]={**state,'status_sha256':keep(out/'status.json'),'log_sha256':keep(out/'run.log')}
    for path in (('workflow/report.json','workflow/client.log','workflow/compositor.log') if mode=='wayland'
                else ('workflow/report.json','workflow/accept.json','workflow/cancel.json','workflow/accept.log','workflow/cancel.log')):
        keep(out/path)
archive=destination/(name+'.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for n,p in sorted(files.items()):
        payload=p.read_bytes()
        member=tarfile.TarInfo(n)
        member.size=len(payload)
        tar.addfile(member,io.BytesIO(payload))
report['archive']={'file':archive.name,'sha256':sha(archive),'members':len(files)}
(destination/(name+'.json')).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(product,report['archive'])
