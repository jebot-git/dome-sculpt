#include "dome/bake.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace dome;

int main(int argc,char **argv) try {
  if(argc!=2)return 2;
  const std::filesystem::path out=argv[1];
  std::filesystem::create_directories(out);
  Mesh low;
  low.positions={{-.5f,-.5f,0},{.5f,-.5f,0},{.5f,.5f,0},{-.5f,.5f,0}};
  low.normals.assign(4,{0,0,1});
  low.uv={{{0,0}},{{1,0}},{{1,1}},{{0,1}}};
  low.indices={0,1,2,0,2,3};
  BakeSource donor;
  donor.mesh=low;
  for(auto &p:donor.mesh.positions)p.z=.02f;
  donor.mesh.normals={{.20f,.11f,1},{-.34f,.12f,1},{-.13f,.28f,1},{.15f,.05f,1}};
  for(auto &n:donor.mesh.normals)n=normalized(n);
  donor.mesh.positions.insert(donor.mesh.positions.end(),{{0,-.26f,.02f},{0,.23f,.02f},{0,.23f,.24f},{0,-.26f,.24f}});
  donor.mesh.normals.insert(donor.mesh.normals.end(),4,Vec3{1,0,0});
  donor.mesh.uv.insert(donor.mesh.uv.end(),{{{0,0}},{{1,0}},{{1,1}},{{0,1}}});
  donor.mesh.indices.insert(donor.mesh.indices.end(),{4,5,6,4,6,7});
  for(const auto count:{0u,1u,2u,7u,16u,64u,256u}){
    BakeOptions settings;
    settings.resolution=64;
    settings.ao_samples=count;
    const auto result=bake_mesh(low,donor,settings);
    if(result.projected!=4096||result.rays!=4096*(count+1))throw std::runtime_error("Wrong projection or AO sample count");
    bool visible=false;
    for(size_t p=0;p<result.ambient_occlusion.rgba.size();p+=4)visible|=result.ambient_occlusion.rgba[p]<255;
    if(count && !visible)throw std::runtime_error("Occluder did not register");
    std::ofstream f(out/(std::to_string(count)+".rgba"),std::ios::binary);
    for(const auto *image:{&result.maps.metal_rough,&result.ambient_occlusion,&result.normal})
      f.write(reinterpret_cast<const char*>(image->rgba.data()),image->rgba.size());
    if(!f)throw std::runtime_error("Could not write computed map");
  }
  std::cout<<"PASS seven exact AO pattern endpoints (0, 1, 2, 7, 16, 64 and 256)\n";
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
