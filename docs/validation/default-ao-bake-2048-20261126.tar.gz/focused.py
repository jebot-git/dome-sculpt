from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parent
art=root.parent
profile=sys.argv[1]
which=sys.argv[2]
out=root/profile
build=out/'build'
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
candidate=out/'libdome-sculpt-core.a'
baseline=art/'native-writable-raster-2048-v3-20261126'/profile/'libdome-sculpt-core.a'
sdk=art/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit')
target='dome-sculpt-'+('bake' if which=='ao-parity' else 'source-canonical-normal-bake')+'-test'
db=json.loads((build/'compile_commands.json').read_text())
entry=next(e for e in db if target+'.dir/' in e['command'])
obj=out/(which+'.o')
def command(args,log):
    with (out/log).open('w') as f:
        print(shlex.join(map(str,args)),file=f,flush=True)
        subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=360,check=True)
argv=shlex.split(entry['command'])
argv[argv.index('-o')+1]=str(obj)
argv[argv.index('-c')+1]=str(root/(which+'.cpp'))
argv.extend(['-I'+str(root/'source/tests'),'-MMD','-MF',str(obj)+'.d'])
command(argv,which+'-compile.log')
link=subprocess.check_output(['ninja','-t','commands',target],cwd=build,text=True).splitlines()[-1]
argv=[s for s in shlex.split(link)[2:-2] if not s.startswith('-Wl,--dependency-file')]
bwrap=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
       '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2',
     'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if profile=='asan':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for k,v in env.items():bwrap.extend(['--setenv',k,v])
variants=(('baseline',baseline),('candidate',candidate)) if which=='ao-parity' else (('candidate',candidate),)
for label,core in variants:
    args=[]
    for a in argv:
        if a.endswith('.o'):a=str(obj)
        elif a=='libdome-sculpt-core.a':a=str(core)
        elif a.endswith('.a') and not a.startswith('/'):a=str(support/a)
        args.append(a)
    exe=out/(which+'-'+label)
    directory=out/('ao-parity-'+label+'-maps')
    args[args.index('-o')+1]=str(exe)
    command(args,which+'-'+label+'-link.log')
    command([*bwrap,exe,*([directory] if which=='ao-parity' else [])],which+'-'+label+'-run.log')
if which=='ao-parity':
    baseline_maps=out/'ao-parity-baseline-maps'
    candidate_maps=out/'ao-parity-candidate-maps'
    hashes={}
    for sample in (0,1,2,7,16,64,256):
        name=f'{sample}.rgba'
        raw=(candidate_maps/name).read_bytes()
        assert raw==(baseline_maps/name).read_bytes()
        hashes[str(sample)]=hashlib.sha256(raw).hexdigest()
    (out/'ao-parity-exact.json').write_text(json.dumps(hashes,indent=2)+'\n')
    print('Exact baseline and candidate AO/ORM/normal bytes for all seven sample counts')
