#define main source_canonical_normal_reference
#include "source-canonical-normal-bake.cpp"
#undef main

int main() try {
  auto scene=canonical_source::converted(false);
  canonical_source::uv(scene);
  auto without=scene;
  auto with=scene;
  auto settings=canonical_source::settings();
  const auto old=bake_object(without,3,settings);
  settings.ao_samples=16;
  const auto result=bake_object(with,3,settings);
  const auto a=without.active().painted->baked()->normal_field;
  const auto b=with.active().painted->baked()->normal_field;
  if(!old.projected||old.projected!=result.projected||old.rays<=old.projected||
     result.rays-old.rays!=16*result.projected||a->pbr()->rgba!=b->pbr()->rgba||
     a->mtoon()->rgba!=b->mtoon()->rgba||a->normal_coverage()!=b->normal_coverage())
    throw std::runtime_error("Wrong independent normal pass or AO count");
  std::cout<<"PASS independent normal pass keeps both planes, primary AO rays="
           <<result.rays-old.rays<<" projected="<<result.projected<<'\n';
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
