from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys

out=Path(__file__).resolve().parent/sys.argv[1]
out.mkdir(exist_ok=True)
art=out.parent.parent
profile=out.name
prior=art/'affine-artist-bake-validation-v2-20261126'/profile
build=prior/'build'
old=art/'affine-artist-bake-source-20261126'
source=art/'affine-artist-bake-fixture-20261126'
db=json.loads((build/'compile_commands.json').read_text())
status={'candidate':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),'profile':profile}
assert not subprocess.check_output(['git','-C',source,'diff','--name-only','71f60afa','HEAD','--','src','include','CMakeLists.txt'],text=True)
sdk=art/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit')
prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
settings={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
          'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if profile=='asan':settings.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                                    UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for k,v in settings.items():prefix.extend(['--setenv',k,v])
def run(cmd,log,cwd=out,check=True):
    with (out/log).open('w') as f:
        print(shlex.join(map(str,cmd)),file=f,flush=True)
        return subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=check,timeout=360)

def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
fixture=prior.parent/'release/build/vrm1-background-fixture/baseline.dsculpt'
for basename,target,args in [('source-artist-normal-bake.cpp','dome-sculpt-source-artist-normal-bake-test',[out/'artist']),
                            ('source-skin-world.cpp','dome-sculpt-source-skin-world-test',[fixture,out/'world.dsculpt'])]:
    name=Path(basename).stem
    cmd=shlex.split(next(e['command'] for e in db if Path(e['file']).name==basename and f'{target}.dir' in e['command']))
    cmd=[w.replace(str(old),str(source)) for w in cmd]
    obj=out/(basename+'.o')
    cmd[cmd.index('-o')+1]=str(obj)
    run(cmd,name+'-compile.log',cwd=build)
    cmd=shlex.split((prior/'tests'/target/'link.log').read_text().splitlines()[0])
    cmd=[str(obj) if w.endswith('/'+obj.name) else w for w in cmd]
    binary=out/target
    cmd[cmd.index('-o')+1]=str(binary)
    run(cmd,name+'-link.log',cwd=build)
    log=name+'.log'
    done=run([*prefix,binary,*args],log,check=False)
    status[name]={'exit':done.returncode,'binary_sha256':sha(binary),'log_sha256':sha(out/log),
                  'last_line':(out/log).read_text().strip().splitlines()[-1]}
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
    assert done.returncode==0
