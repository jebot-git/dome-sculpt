from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from xml.etree import ElementTree
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

home = Path(__file__).resolve().parent
artifacts = home.parent
source = artifacts/'affine-artist-bake-source-20261126'
profile = sys.argv[1]
asan = profile == 'asan'
out = home/profile
out.mkdir(exist_ok=True)
build = out/'build'
sdk = artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
donor = artifacts/'affine-native-bake-centered-validation-20261126'/profile
matching = artifacts/'matching-bake-validation-20261126'/profile
targets = {
    'source-artist-normal-bake': 'dome-sculpt-source-artist-normal-bake-test',
    'source-prepared-normal-bake': 'dome-sculpt-source-prepared-normal-bake-test',
    'source-artist-normal-cc0-cpu': 'dome-sculpt-source-artist-normal-render-test',
    'vrm1-background-fixture': 'dome-sculpt-vrm1-background-fixture-test',
    'source-skin-world': 'dome-sculpt-source-skin-world-test',
    'retopology-affine': 'dome-sculpt-retopo-affine-test',
    'retopology-authoring': 'dome-sculpt-retopo-authoring-test',
    'retopology-save-handoff': 'dome-sculpt-retopo-save-handoff-test',
    'retopology-affine-ui-fixture': 'dome-sculpt-retopo-affine-ui-fixture',
    'texture-set-retained-bake-source': 'dome-sculpt-texture-set-source-export-test',
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
    'bake-custom-cage': 'dome-sculpt-bake-cage-test',
    'bake-projection-policy': 'dome-sculpt-bake-projection-policy-test',
}
extra_targets = {'dome-sculpt-native-authoring-inspect'}
start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def sha(file):
    with Path(file).open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

status = {'candidate':git('rev-parse','HEAD'), 'profile':profile, 'terminal':False,
          'fltk':str(sdk),'invocation':os.getenv('INVOCATION_ID')}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic()-start,2))
    temp=out/'status.tmp'
    temp.write_text(json.dumps(status,indent=2)+'\n')
    temp.replace(out/'status.json')

def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check)

try:
    assert status['candidate']==os.environ['DOME_AFFINE_BAKE_CANDIDATE'] and not git('status','--porcelain')
    baseline=json.loads((donor/'status.json').read_text())
    assert baseline['terminal'] and baseline['exit']==0
    changed=set(git('diff','--name-only',baseline['candidate'],'HEAD','--','src','include','assets','third_party','CMakeLists.txt').splitlines())
    assert changed=={'src/bake-authoring.cpp','src/source-skin-world.hpp','src/source-bake-normal.hpp','src/texture-set-surface.cpp','src/emission-bake-source.cpp'},changed
    opts=[]
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    record(phase='configure canonical toolkit',baseline=baseline['candidate'])
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,out)
    database=json.loads((build/'compile_commands.json').read_text())
    archives={}
    for role in ('core','render','xr'):
        lib=(donor if role=='core' else matching)/f'libdome-sculpt-{role}.a'
        assert sha(lib)==baseline[role+'_sha256']
        archives[lib.name]=str(lib)
    def compile(entry,directory):
        cmd=shlex.split(entry['command'])
        target=cmd.index('-o')+1
        original=cmd[target]
        obj=directory/(Path(entry['file']).name+'.o')
        cmd[target]=str(obj)
        cmd.extend(['-MMD','-MF',str(obj)+'.d'])
        invoke(cmd,obj.relative_to(out).with_suffix('.log'),660)
        return original,obj

    record(phase='compile all changed or header-dependent core owners')
    changed_headers={path for path in changed if path.endswith('.hpp')}
    core_sources={path for path in changed if path.endswith('.cpp')}
    for header in changed_headers:
        core_sources.update(str(src.relative_to(source)) for src in (source/'src').glob('*.cpp')
                            if f'#include "{Path(header).name}"' in src.read_text())
    owners=[e for e in database if Path(e['file']) in {source/path for path in core_sources}
            and 'dome-sculpt-core.dir/' in e['command']]
    assert len(owners)==len(core_sources)==6
    with ThreadPoolExecutor(max_workers=2) as pool:
        objects=dict(pool.map(lambda e:compile(e,out),owners))
    previous=Path(archives['libdome-sculpt-core.a'])
    core=out/previous.name
    shutil.copyfile(previous,core)
    invoke(['ar','rs',core,*objects.values()],'archive-link.log')
    assert subprocess.check_output(['ar','t',core])==subprocess.check_output(['ar','t',previous])
    for obj in objects.values():
        assert hashlib.sha256(subprocess.check_output(['ar','p',core,obj.name])).hexdigest()==sha(obj)
        assert any(str(source/header) in Path(str(obj)+'.d').read_text() for header in changed_headers)
    archives[core.name]=str(core)

    def make_target(target):
        directory=out/'tests'/target
        directory.mkdir(parents=True,exist_ok=True)
        entries=[entry for entry in database if f'CMakeFiles/{target}.dir/' in entry['command']]
        assert entries
        objects=dict(compile(entry,directory) for entry in entries)
        last=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
        words=[word for word in shlex.split(last)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
        assert all(x in words for x in objects)
        words=[str(objects[word]) if word in objects else word for word in words]
        words=[archives.get(word,str(support/word)) if word.startswith('lib') and word.endswith('.a') else word for word in words]
        invoke(words,directory.relative_to(out)/'link.log',500)
        return target,sha(build/target)

    record(phase='build native fixtures and relink application',core_sha256=sha(core),
           rebuilt={obj.name:sha(obj) for obj in objects.values()},render_sha256=baseline['render_sha256'],xr_sha256=baseline['xr_sha256'])
    with ThreadPoolExecutor(max_workers=2) as pool:
        binaries=dict(pool.map(make_target,sorted(set(targets.values())|extra_targets)))
    app=build/'dome-sculpt'
    stable_link=matching/'app-link.log'
    link=shlex.split(stable_link.read_text().splitlines()[0])
    link=[str(core) if (Path(word).name==core.name) else word for word in link]
    link[link.index('-o')+1]=str(app)
    invoke(link,'app-link.log',500,support)
    runtime=matching/'build/libdome-sculpt-test-runtime.so'
    assert runtime.is_file()
    (build/runtime.name).symlink_to(runtime)
    record(phase='execute registered native regressions',binaries=binaries,app_sha256=sha(app),runtime_sha256=sha(runtime))

    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        environment.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    else:
        targets['retopology-affine-openxr']='dome-sculpt'
    for key,value in environment.items():
        isolated.extend(['--setenv',key,value])
    report=build/'regressions.xml'
    run=invoke([*isolated,'ctest','--test-dir',build,'-R','^('+'|'.join(targets)+')$',
                '--output-on-failure','-V','-j2','--output-junit',report],'ctest.log',850,check=False)
    cases={case.attrib['name']:case for case in ElementTree.parse(report).getroot().findall('.//testcase')}
    assert set(cases)==set(targets),cases.keys()
    failure=sorted(name for name,case in cases.items() if case.find('failure') is not None or case.find('skipped') is not None)
    assert not git('status','--porcelain')
    record(phase='complete',terminal=True,exit=run.returncode,failures=failure,tests=len(cases),
           ctest_sha256=sha(out/'ctest.log'),junit_sha256=sha(report))
    assert run.returncode==0 and not failure, failure
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
