#include "dome/document.hpp"
#include "dome/bake-authoring.hpp"
#include <iostream>
#include <nlohmann/json.hpp>
int main(int argc,char **argv){
  if(argc<2)return 2;
  if(argc==3&&std::string_view(argv[1])=="--sources"){
    auto scene=dome::Scene::load(argv[2]);
    scene.erase(scene.active().id);
    std::cout<<scene.encode().dump()<<std::endl;
    return 0;
  }
  auto original=dome::Scene::load(argv[1]);
  if(argc==3){
    auto &target=original.active();
    auto mesh=target.painted->mesh();
    dome::Vec3 center;
    for(auto p:mesh.positions)center+=p;
    center=center/float(mesh.positions.size());
    for(auto &p:mesh.positions)p=center+(p-center)*.85f;
    target.painted=std::make_shared<dome::PaintedMesh>(std::move(mesh),target.painted->resolution());
    original.save(argv[2]);
  }
  for(auto normals:{false,true})for(auto matching:{false,true}){
    auto scene=original.snapshot();
    dome::ObjectBakeSettings settings;
    settings.prepare_normals=normals;settings.corresponding_topology=matching;
    try{
      auto r=dome::bake_object(scene,2,settings);std::cout<<normals<<" "<<matching<<" projected "<<r.projected<<" missed "<<r.missed<<std::endl;
    }catch(const std::exception&e){std::cout<<normals<<" "<<matching<<" "<<e.what()<<std::endl;}
  }
}
