from pathlib import Path
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time

out=Path(__file__).resolve().parent
repo=out.parents[1]
older=repo/'artifacts/native-grid-combined-release-20261126/build'
frozen=repo/'artifacts/native-grid-combined-source-20261126'
original_path=next((older/'canonical-paint37-key-replace-faults').glob('run-*/plan.json'))
original=json.loads(original_path.read_text())
original_part=original_path.with_name('part-0086.json')
original_report=json.loads(original_part.read_text())
assert original_report['exit_code']==0 and original_report['maps_verified'] is False
assert original_report['native']['completed']==345 and '/usr/bin/python3.14' in original_report['unprotected_elf']
shutil.copyfile(original_part,out/'original-0086.json')
module_path=repo/'tests/native_process_maps.py'
spec=importlib.util.spec_from_file_location('native_process_maps',module_path)
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
# Hold a real child before exec and sample the same PID after a controlled exec.
sleep_elf=Path(shutil.which('sleep')).resolve()
with subprocess.Popen([sys.executable,'-c',
        'import os,sys; print("before",flush=True); sys.stdin.readline(); os.execv(sys.argv[1],[sys.argv[1],"30"])',
        str(sleep_elf)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True) as child:
    try:
        assert child.stdout.readline()=='before\n'
        assert str(Path(sys.executable).resolve()) in (Path('/proc')/str(child.pid)/'maps').read_text()
        assert not helper.elf_mappings(child.pid,sleep_elf)
        child.stdin.write('\n');child.stdin.flush()
        deadline=time.monotonic()+5
        maps=set()
        while not maps and time.monotonic()<deadline:
            maps=helper.elf_mappings(child.pid,sleep_elf)
            if not maps:time.sleep(.01)
        assert str(sleep_elf) in maps and str(Path(sys.executable).resolve()) not in maps
    finally:
        child.terminate()
        child.wait()
(out/'exec-transition.json').write_text(json.dumps({'pid':child.pid,'startup_is_python':True,'ignored_startup':True,
    'native_elf':sorted(maps)},indent=2)+'\n')
settings={'HOME':'/tmp','PYTHONDONTWRITEBYTECODE':'1',**original['environment']}
isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
for key,value in settings.items():isolated.extend(['--setenv',key,value])
python=['/usr/bin/python3',repo/'tests/key-oom-partitions.py']
with (out/'replay.log').open('w') as log:
    def run(*args):
        subprocess.run([*isolated,*args],check=True,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    run(*python,'controls')
    run('/usr/bin/python3',repo/'tests/physical-oom-partitions.py','controls')
    run(*python,'prepare',out/'replace','--binary',original['binary'],'--fixture',original['fixture'],
        '--source',frozen,'--operation','Replace','--expect-baseline',str(original['measurement']['baseline']),
        '--partitions',str(len(original['parts'])))
    run(*python,'part',out/'replace','86')
fixed_path=next((out/'replace').glob('run-*/part-0086.json'))
fixed=json.loads(fixed_path.read_text())
shutil.copyfile(fixed_path,out/'fixed-0086.json')
assert fixed['maps_verified'] and not fixed['unprotected_elf']
assert fixed['native']==original_report['native']
new_plan=json.loads(fixed_path.with_name('plan.json').read_text())
assert str(module_path) in new_plan['inputs']
assert not (original['inputs'][original['binary']]!=new_plan['inputs'][original['binary']] or
            original['inputs'][original['fixture']]!=new_plan['inputs'][original['fixture']])
(out/'status.json').write_text(json.dumps({'terminal':True,'study':'Native image observer across actual exec',
    'same_binary_and_fixture':True,'same_allocation_report':True,
    'original_problem':original_report['unprotected_elf'],'verified_maps':len(fixed['mapped_elf']),
    'prefixes':fixed['native']['completed'],'case':86,'input_sha256':new_plan['inputs_digest']},indent=2)+'\n')
