from pathlib import Path
import re

path = Path(__file__).parent
source = Path('tests/independent-seam-key-mirror.cpp').read_text()
assert source.count('mesh.normals.assign(5,{0,0,1})') == 1
assert source.count('pbr->normals.assign(12,{0,0,1})') == 1
assert source.count('pbr->tangents.assign(12,{1,0,0,1})') == 1
source = source.replace('mesh.normals.assign(5,{0,0,1})', 'mesh.normals.assign(5,normalized(Vec3{.2f,.25f,1}))')
source = source.replace('pbr->normals.assign(12,{0,0,1})', 'pbr->normals.assign(12,mesh.normals.front())')
source = source.replace('pbr->tangents.assign(12,{1,0,0,1})', 'pbr->tangents.assign(12,{.9805807f,0,-.1961161f,1})')
source = source[:source.rindex('int main(')]
path.joinpath('archive-proof.cpp').write_text(source + Path(path / 'archive-main.cpp').read_text())
