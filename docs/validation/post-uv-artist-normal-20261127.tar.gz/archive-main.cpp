namespace {
void edit_corner(Scene &scene, const std::string &name) {
  ShapeKeyEdit edit;
  edit.name = name;
  const auto id = scene.active().id;
  edit.target = scene.active().deformation->morphs->targets.size();
  author_shapekey(scene, id, edit);
  edit.action = ShapeKeyAction::Replace;
  edit.positions = scene.active().painted->mesh().positions;
  edit.positions[0].z += .085f;
  edit.positions[3].z -= .034f;
  author_shapekey(scene, id, edit);
  check(bool(scene.active().material_bindings->key_derivation), "The edit uses a replay-certified independent POSITION domain");
}
void check_offset(const Scene &scene, size_t slot, bool expected) {
  const auto &object = scene.active();
  const auto &mesh = object.painted->mesh();
  const auto &frames = *object.material_bindings->normal_frames;
  const auto &key = target(*frames.pbr, frames.current_targets.at(slot));
  const auto &delta = object.deformation->morphs->targets.at(slot).delta;
  bool retained = true;
  for (size_t c = 0; c < mesh.indices.size(); c += 3) {
    const auto a = mesh.indices[c], b = mesh.indices[c + 1], d = mesh.indices[c + 2];
    const auto p = [&](uint32_t v) { return mesh.positions[v] + delta[v]; };
    const auto rest = normalized(cross(mesh.positions[b] - mesh.positions[a],
                                      mesh.positions[d] - mesh.positions[a]));
    const auto bent = normalized(cross(p(b) - p(a), p(d) - p(a)));
    for (size_t corner = c; corner < c + 3; ++corner) {
      const auto normal = frames.pbr->normals.at(corner);
      const auto endpoint = normal + key.normals.at(corner);
      retained &= std::abs(dot(normal, rest) - dot(endpoint, bent)) < 1e-5f;
    }
  }
  check(retained == expected, expected ? "New key retains the artist offset on independent triangle corners" :
        "The historical executable writes the affected geometric endpoint");
}
}
int main(int argc, char **argv) try {
  if (argc < 3) return 2;
  const std::filesystem::path project = argv[2];
  if (std::string_view(argv[1]) == "seed") {
    auto scene = fixture(false);
    edit_corner(scene, "Historical endpoint");
    check_offset(scene, 1, false);
    scene.save(project);
    return 0;
  }
  if (argc != 4) return 2;
  auto scene = Scene::load(project);
  const auto file = std::filesystem::path(argv[3]);
  const auto before = scene.encode();
  scene.save(file.string() + "-resave.dsculpt");
  check(Scene::load(file.string() + "-resave.dsculpt").encode() == before,
        "Current codec reopens and re-saves exact historical authoring data");
  check_offset(scene, 1, false);
  const auto old = scene.active().material_bindings->normal_frames;
  const auto restore = scene.active().shape_source;
  edit_corner(scene, "New geometric reference");
  const auto now = scene.active().material_bindings->normal_frames;
  const auto &historical = target(*old->pbr, old->current_targets[1]);
  const auto &retained = target(*now->pbr, now->current_targets[1]);
  check(std::ranges::equal(historical.normals, retained.normals, same) &&
            std::ranges::equal(historical.tangents, retained.tangents, same),
        "New authoring retains an unrelated historical target exactly");
  check(scene.active().shape_source == restore, "New authoring keeps the first Restore capsule");
  check_offset(scene, 2, true);
  scene.save(file.string() + "-edit.dsculpt");
  check(Scene::load(file.string() + "-edit.dsculpt").encode() == scene.encode(),
        "Cold Open authenticates both historical and corrected frame records");
} catch (const std::exception &error) {
  std::cerr << "FAIL " << error.what() << '\n';
  return 1;
}
