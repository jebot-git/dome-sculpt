const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
(async () => {
  const results = [];
  for (const placement of ['plain','affine']) {
    for (const variant of ['retopo','portable']) {
      const file = path.join(__dirname,'release','retopology-mtoon-'+placement,'mtoon-'+variant+'.glb');
      const bytes = fs.readFileSync(file);
      const jsonLength = bytes.readUInt32LE(12);
      const j = JSON.parse(bytes.toString('utf8',20,20+jsonLength));
      const used = j.meshes[0].primitives.map(p => j.materials[p.material]);
      const typed = used.filter(m => m.extensions?.VRMC_materials_mtoon);
      const roleWidths = typed.map(m => {
        const role = m.extensions.VRMC_materials_mtoon.shadeMultiplyTexture;
        const texture = j.textures[role.index];
        const image = j.images[texture.source];
        const view = j.bufferViews[image.bufferView];
        assert.equal(image.mimeType,'image/png');
        assert.equal(role.extensions?.KHR_texture_transform,undefined);
        return bytes.readUInt32BE(28+jsonLength+(view.byteOffset || 0)+16);
      }).sort((a,b)=>a-b);
      assert.equal(used.length,2);
      assert.deepEqual(roleWidths,variant==='portable'?[128,512]:[512]);
      assert(typed.some(m => m.normalTexture?.scale > .6 && m.normalTexture.scale < .7));
      if (variant==='portable') {
        assert(typed.some(m => m.extensions.VRMC_materials_mtoon.outlineWidthMultiplyTexture));
        assert(typed.every(m => m.alphaMode==='MASK' && m.alphaCutoff>.32 && m.alphaCutoff<.34));
      }
      const report = await validator.validateBytes(bytes,{uri:placement+'-'+variant+'.glb',maxIssues:10000});
      results.push({placement,variant,roleWidths,report});
      console.log(placement,variant,roleWidths,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings');
    }
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results},null,2)+'\n');
  if (results.some(({report}) => report.issues.numErrors)) process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1});
