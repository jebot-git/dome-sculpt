from pathlib import Path
import subprocess
import sys

work=Path(__file__).resolve().parent
public=work.parent/'creator-public-build-20261126'
fixture=work/sys.argv[1]
run=work/'wayland-resize'
probe=work.parent/'combined-atlas-hdr-preview-full-20261126/build/libdome-sculpt-test-widgets.so'
env={'PATH':str(public/'private-bin-v3')+':/usr/bin','HOME':'/tmp',
     'PYTHONPATH':str(public/'private-python'),'PYTHONDONTWRITEBYTECODE':'1',
     'DOME_COMPOSITOR':str(public/'wayland-reference/dome-compositor'),
     'DOME_CREATOR_PROJECT':str(fixture/'visible-paint.dsculpt'),'DOME_GRID_EXPECTED':str(fixture/'resized-256.dsculpt'),
     'DOME_CAGE_APP':str(work/'release/dome-sculpt'),'DOME_CAGE_PROBE':str(probe),'DOME_CAGE_WL_OUT':str(run),
     'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:'+str(public/'private-x11/usr/lib64')+':/usr/lib64'}
args=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',work,work,
      '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
for key,value in env.items():args.extend(['--setenv',key,value])
with (work/'bind-wayland.log').open('w') as log:
    subprocess.run([*args,'/usr/bin/python3.14',work/'wayland-resize.py'],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
