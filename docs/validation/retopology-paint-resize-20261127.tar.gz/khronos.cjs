const fs = require('node:fs');
const path = require('node:path');
const validator = require('../hdr-khronos-validation-20261126/module/package');

async function main() {
  const files=['visible-standard.glb','visible-editable.glb','resized-standard.glb','resized-editable.glb',
               'selected-mtoon.glb','selected-core.glb'].map(file=>`v2-resize/${file}`);
  const results = [];
  for (const file of files) {
    const bytes = fs.readFileSync(path.join(__dirname, file));
    const report = await validator.validateBytes(new Uint8Array(bytes), {uri:file});
    results.push({file,issues:report.issues});
    console.log(file,report.issues.numErrors,report.issues.numWarnings);
    if (report.issues.numErrors) throw new Error(JSON.stringify(report.issues));
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({validator:validator.version(),results},null,2)+'\n');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
