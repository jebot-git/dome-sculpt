from hashlib import file_digest, sha256
import gzip
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile

work=Path(__file__).resolve().parent
repo=work.parent.parent
base=work.parent/'retopology-portable-mixed-20261127'
validation=repo/'docs/validation'
previous='4e512dd6d67195614df49fa2603dcd159cbf0402'

def digest(path):
    with path.open('rb') as file:return file_digest(file,'sha256').hexdigest()

def git(directory,*args):
    return subprocess.check_output(['git','-C',directory,*args]).decode().strip()

def data(name):
    return json.loads((work/name).read_text())

def parse(path):
    raw=path.read_bytes()
    assert raw[:4]==b'glTF'
    end=20+struct.unpack_from('<I',raw,12)[0]
    return json.loads(raw[20:end]),raw[end+8:]

def core_images(path):
    scene,binary=parse(path)
    primitive=scene['meshes'][0]['primitives'][0]
    material=scene['materials'][primitive['material']]
    pbr=material['pbrMetallicRoughness']
    roles=dict(base=pbr['baseColorTexture'],orm=pbr['metallicRoughnessTexture'],normal=material['normalTexture'],
               emission=material['emissiveTexture'],ao=material['occlusionTexture'])
    result={}
    for role,info in roles.items():
        texture=scene['textures'][info['index']]
        image=scene['images'][texture['source']]
        view=scene['bufferViews'][image['bufferView']]
        offset=view.get('byteOffset',0)
        result[role]=sha256(binary[offset:offset+view['byteLength']]).hexdigest()
    return result

product=git(repo,'rev-parse','HEAD')
assert git(repo,'rev-parse','HEAD^')==previous
patch=subprocess.check_output(['git','-C',repo,'diff','--binary',previous,product])
assert sha256(patch).hexdigest()==digest(work/'source-v2.patch')
canonical=git(repo.parent/'DomeD','rev-parse','HEAD')
assert canonical==git(repo.parent/'DomeD','ls-remote','origin','refs/heads/main').split()[0]
assert 'FAIL A painted patch with independent projected images enables the native resolution control' in (work/'baseline-native.log').read_text()
old=work/'baseline-resized-512.glb'
assert 'KHR_materials_variants' not in parse(old)[0].get('extensionsUsed',[])
fixture=work/'v2-resize'
assert core_images(old)==core_images(fixture/'resized-standard.glb')

members=['record.py','check-v2.sh','check-v2-asan.py','release-v2-build.log','release-v2-tests.log',
         'asan-v2-tests.log','baseline-native.log','run-wayland.py','wayland-resize.py','bind-wayland.log',
         'wayland-resize/report.json','khronos.cjs','khronos.log','khronos.json','mtoon-schemas.log','mtoon-schemas.json',
         'select-variant.py','render-portable.cpp','render-portable.py','run-render.py','xr-portable.py',
         'run-field-xr.py','field-xr.py','run-field-xr-paced.py','field-xr-paced.py','field-xr-software.log']
for name in ('texture-set-resample.cpp','texture-set-export.cpp','export.cpp','texture-set-source-export.cpp'):
    members.append(f'exact-v2-asan/{name}.build.log')
case='retopology-imported-mtoon-resize'
profiles={}
measurements={}
for directory,log,count in [('release','release-v2-tests.log',23),('exact-v2-asan','asan-v2-tests.log',17)]:
    output=(work/log).read_text()
    passed=re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',output)
    assert f'0 tests failed out of {count}' in output and len(passed)==count and case in passed
    control=(work/directory/'Testing/Temporary/LastTest.log').read_text()
    tests=re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.',control,re.M|re.S)[1]
    assert 'PASS 467 imported MToon retopology checks' in tests
    samples=re.findall(r'MIXED_MTOON painted=(\d+) base_error=([.\d]+) shade_error=([.\d]+) emission_error=([.\d]+) base_size=(\d+) emission_size=(\d+) strength=([.\d]+)',tests)
    assert len(samples)==4 and samples[0]==samples[1] and samples[2]==samples[3]
    measurements[directory]=[dict(painted=int(painted),color=float(color),shade=float(shade),emission=float(emission),
                                  base_size=int(width),emission_size=int(height),strength=float(strength))
                             for painted,color,shade,emission,width,height,strength in samples[::2]]
    assert measurements[directory][1]['base_size']==measurements[directory][1]['emission_size']==512
    assert measurements[directory][1]['painted']==3988
    name=f'{directory}-resize-controls.log'
    (work/name).write_text(tests)
    members.append(name)
    profiles[directory]=passed
assert measurements['release']==measurements['exact-v2-asan']

hashes={}
for name in ('raw-guide.dsculpt','raw-patch.dsculpt','visible-paint.dsculpt','resized-256.dsculpt','resized-512.dsculpt',
             'visible-standard.glb','visible-editable.glb','resized-standard.glb','resized-editable.glb'):
    checksum=digest(fixture/name)
    assert checksum==digest(work/'release'/case/name)==digest(work/'exact-v2-asan'/case/name)
    hashes[name]=checksum
assert hashes['visible-paint.dsculpt']==digest(work/'v1-resize/visible-paint.dsculpt')
assert hashes['resized-256.dsculpt']==digest(work/'v1-resize/resized-256.dsculpt')==digest(work/'wayland-resize/painted256.dsculpt')
bounds={}
for name in ('resized-standard.glb','resized-editable.glb'):
    document,_=parse(fixture/name)
    primitive=document['meshes'][0]['primitives'][0]
    assert 'TANGENT' in primitive['attributes']
    alternate=primitive['extensions']['KHR_materials_variants']['mappings'][0]['material']
    assert alternate!=primitive['material']
    metric=document['materials'][alternate]['extras']['domeSculptMToonPaint']
    assert metric['errorDomain']=='mesh-uv-triangles' and metric['emissiveStrength']==6
    assert metric['maximumLinearColorError']<=.008 and metric['maximumLinearShadeError']<=.008
    assert metric['maximumLinearEmissionError']<=.048
    bounds[name]=metric

unchanged={}
for variant in ('painted','tinted','unprepared','mixed-hdr','mixed-ldr'):
    for name in ('raw-standard.glb','raw-editable.glb','visible-standard.glb','visible-editable.glb'):
        relative=Path('retopology-imported-mtoon-'+variant)/name
        checksum=digest(work/'release'/relative)
        assert checksum==digest(base/'release'/relative)==digest(work/'exact-v2-asan'/relative)
        unchanged[str(relative)]=checksum
wayland=data('wayland-resize/report.json')
assert wayland['complete'] and len(wayland['checks'])==12 and all(check['passed'] for check in wayland['checks'])

rendering={}
field_workflow={}
for mode,renderer in [('arc','Arc(tm) A770'),('software','llvmpipe')]:
    render=f'v2-resize/render-portable-{mode}.log'
    log=(work/render).read_text()
    assert renderer in log and 'PASS package-free MToon variant and Core PBR replay' in log
    match=re.search(r'PORTABLE_RENDER pixels=(\d+) mtoon_max=(\d+) mtoon_rms=([.\d]+) core_pixels=(\d+) core_max=(\d+) core_rms=([.\d]+)',log)
    pixels,mtoon,typed_rms,core_pixels,core,core_rms=map(float,match.groups())
    assert pixels==core_pixels==5754 and mtoon<=2 and core<=1
    replay=f'xr-{mode}-v2-resize/compare.json'
    replay_data=data(replay)
    assert replay_data['runtime']=='synthetic OpenXR' and replay_data['exact_ordered_close']
    assert all(row['maximum_channel_difference']<=2 for row in replay_data['differing_rgb_components_per_eye'])
    rendering[mode]=dict(renderer=renderer,pixels=int(pixels),maximum_mtoon_error=int(mtoon),maximum_core_error=int(core),
                          mtoon_rms=typed_rms,core_rms=core_rms,stereo_differences=replay_data['differing_rgb_components_per_eye'])
    field_name='field-xr-'+('paced-' if mode=='software' else '')+mode
    field=data(f'{field_name}/report.json')
    assert field['complete'] and len(field['checks'])==12 and renderer in field['renderer']
    assert digest(work/field_name/'final.dsculpt')==hashes['resized-256.dsculpt']
    field_workflow[mode]=field
    members += [render,replay,f'v2-resize/verified-stereo-{mode}.log',f'{field_name}/report.json',f'{field_name}.log',f'{field_name}/runtime.json']

khronos=data('khronos.json')
assert len(khronos['results'])==6
for result in khronos['results']:
    assert result['issues']['numErrors']==result['issues']['numWarnings']==0
    result['sha256']=digest(work/result['file'])
schemas=data('mtoon-schemas.json')
assert len(schemas['files'])==5 and len(schemas['resolver_controls'])==3
assert all(len(file['checks'])==1 and not file['checks'][0]['errors'] for file in schemas['files'])
assert not schemas['schema_drift'] and not schemas['schema_bytes_rewritten']

archive=validation/(work.name+'.tar.gz')
archive_members={}
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0) as packed:
    with tarfile.open(fileobj=packed,mode='w') as tar:
        for name in members:
            item_data=(work/name).read_bytes()
            archive_members[name]=sha256(item_data).hexdigest()
            item=tarfile.TarInfo(name)
            item.size=len(item_data)
            tar.addfile(item,io.BytesIO(item_data))

receipt=dict(product=product,previous_main=previous,canonical_domed=canonical,
    release_application_sha256=digest(work/'release/dome-sculpt'),source_patch_sha256=digest(work/'source-v2.patch'),
    asan_test_sha256=digest(work/'exact-v2-asan/dome-sculpt-texture-set-source-export-test'),
    asan_build='Exact baseline with changed source units and fixture rebuilt and relinked with ASan/UBSan',
    baseline=dict(app_sha256=digest(base/'release/dome-sculpt'),glb_sha256=digest(old),
                  resize_enabled=False,mtoon_variant=False,unchanged_core_png_sha256=core_images(old)),
    tests=profiles,matching_native_and_glb_sha256=hashes,unchanged_previous_glb_sha256=unchanged,
    sampled_material=measurements['release'],error_bounds=bounds,wayland=wayland,graphics=rendering,
    synthetic_field_workflow=field_workflow,physical_headset=False,khronos=khronos,
    mtoon_schema_valid_materials=len(schemas['files']),
    software_field_retry='The first software run did not register the immediate Undo after durable Save. The paced synthetic flow waits 750 ms after each observed native Save.',
    archive_sha256=digest(archive),archive_members_sha256=archive_members)
(validation/(work.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
