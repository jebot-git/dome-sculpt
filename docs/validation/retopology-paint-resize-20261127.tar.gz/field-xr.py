from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
app=work/'release/dome-sculpt'
runtime=work.parent/'current-integrated-full-release-20261127/build/libdome-sculpt-texture-resolution-runtime.so'
fixture=work/sys.argv[2]
mode=sys.argv[1]
out=work/f'field-xr-{mode}'
out.mkdir(exist_ok=True)
gates=out/'gates'; gates.mkdir(exist_ok=True)
project=out/'input.dsculpt'; target=out/'final.dsculpt'; metadata=out/'runtime.json'
manifest=out/'loader.json'
manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(runtime)}}))
original=(fixture/'visible-paint.dsculpt').read_bytes()
expected=(fixture/'resized-256.dsculpt').read_bytes()
assert expected!=original
project.write_bytes(original)
for name in ('accepted','undone','redone'):
    assert not (gates/name).exists()
home=out/'home'; home.mkdir(mode=0o700,exist_ok=True)
env=dict(os.environ,HOME=str(home),XR_RUNTIME_JSON=str(manifest),DOME_XR_FIXTURE_REPORT=str(metadata),
         DOME_XR_TEXTURE_RESOLUTION='apply-primary',DOME_XR_TEXTURE_TARGET='256',DOME_XR_TEXTURE_GATES=str(gates))
for part in ('config','state','data','cache','runtime'):
    folder=home/part; folder.mkdir(mode=0o700,exist_ok=True)
    env['XDG_'+part.upper()+('_DIR' if part=='runtime' else '_HOME')]=str(folder)

def state():
    try: return json.loads(metadata.read_text())
    except (OSError,ValueError): return {}

checks=[]
def check(passed,label):
    assert passed,label
    checks.append(label)
    print('PASS',label,flush=True)

with (out/'app.log').open('w') as log:
    app_process=subprocess.Popen([app,'--xr','--open',project,'--save',target],env=env,stdout=log,stderr=subprocess.STDOUT)
    try:
        deadline=time.monotonic()+230
        stamp=project.stat().st_mtime_ns
        for phase,minimum,root,closed,wanted in [('accepted',45,39,43,expected),('undone',59,55,57,original),('redone',73,69,71,expected)]:
            while time.monotonic()<deadline:
                status=state()
                assert app_process.poll() is None
                if status.get('field_step',0)>=minimum and project.stat().st_mtime_ns!=stamp and project.read_bytes()==wanted:
                    root_state=status['field_root_visible'][str(root)]
                    closed_state=status['field_menu_closed'][str(closed)]
                    check(root_state['save_selected'] and root_state['redo_enabled']==(phase=='undone') and
                          not closed_state['panel_present'],f'{phase} rendered palette shows the expected history and closes after Save')
                    check(True,f'{phase} controller Save matches the complete native project byte for byte')
                    (gates/phase).write_text('Compared exact durable result\n')
                    stamp=project.stat().st_mtime_ns
                    break
                time.sleep(.06)
            else:
                raise TimeoutError((phase,state().get('field_step'),app_process.poll()))
        check(app_process.wait(timeout=35)==0 and target.read_bytes()==expected,'OpenXR app drains and final close persists the exact resized patch')
        status=state()
        check(status['frames_waited']==status['frames_begun']==status['frames_ended'] and
              status['acquires']==status['image_waits']==status['releases'] and status['swapchains_destroyed']==2,
              'Real OpenXR loader balances frame, images and both swapchains')
        check(status['left_eye_nonblank']>0 and status['right_eye_nonblank']>0 and
              '27-0' in status['field_captures'] and '27-1' in status['field_captures'],
              'Both eyes render the patch and its actual resolution panel')
        check({8,14,20,26}.issubset({v['step'] for v in status['field_buttons']}) and
              any(v['step']==30 for v in status['field_pressures']), 'Loader delivers actual panel navigation and slider rays')
        check(('Arc(tm) A770' if mode=='arc' else 'llvmpipe') in status['gl_renderer'],'Requested OpenGL renderer drives the workflow')
        actual_maps=Path(str(metadata)+'.maps').read_text()
        check(str(app) in actual_maps and str(runtime) in actual_maps,'Process maps witness the ordinary application and synthetic runtime module')
        (out/'report.json').write_text(json.dumps(dict(complete=True,checks=checks,renderer=status['gl_renderer'],
              runtime=str(runtime),balanced_frames=status['frames_ended']),indent=2)+'\n')
    finally:
        if app_process.poll() is None:
            app_process.terminate()
            try: app_process.wait(timeout=8)
            except subprocess.TimeoutExpired: app_process.kill(); app_process.wait()
