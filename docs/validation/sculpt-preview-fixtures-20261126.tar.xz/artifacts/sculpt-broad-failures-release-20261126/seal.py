from pathlib import Path
import json,tarfile,hashlib,io,subprocess
B=Path(__file__).resolve().parent;ROOT=B.parents[1];S=B.parent/'sculpt-broad-failures-source-20261126';Q=B.parent/'sculpt-sharing-range-search-release-20261126';V=S/'docs/validation';V.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
state=json.loads((B/'cpu-v1/status.json').read_text());assert state['terminal'] and state['exit']==0 and len(state['cases'])==5
original=json.loads((B/'original-failures.json').read_text());assert hashlib.sha256(Path(original['original_log']).read_bytes()[:original['captured_bytes']]).hexdigest()==original['captured_sha256']
files={}
def add(p):p=Path(p).resolve();assert p.is_file();files[str(p.relative_to(ROOT))]=p
for p in B.iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.d','.log','.txt']:add(p)
for p in (B/'cpu-v1').iterdir():
 if p.is_file():add(p)
for n in ['CMakeLists.txt','tests/scene.cpp','tests/native-strokes.cpp','tests/sculpt-document.cpp','tests/sculpt-controller.cpp']:add(S/n)
for n in ['build-plan.json','build-status.json']:add(Q/n)
q={'fixture_commit':'b060ef56','base_core':'f9c20398','core_sha256':json.loads((B/'build-status.json').read_text())['core_sha256'],'scope':'Four stale preview fixtures corrected to actual owningchunkgeometry/scalar/capture seam;5focused ReleaseCPU casespass; noproductionpatch/no graphics/devicelease/no sanitizer or wholeumbrella claim.','original_failure_capture':original,'build':json.loads((B/'build-status.json').read_text()),'runtime':state,'authorities':[]}
for name,p in sorted(files.items()):q['authorities'].append({'name':name,'actual_path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
payload=(json.dumps(q,indent=2)+'\n').encode();dest=V/'sculpt-preview-fixtures-20261126.tar.xz';assert not dest.exists()
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('index.json');info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
with tarfile.open(dest,'r:xz') as tar:
 for a in q['authorities']:assert hashlib.sha256(tar.extractfile(a['name']).read()).hexdigest()==a['sha256'];assert sha(a['actual_path'])==a['sha256']
q['archive']={'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(files)+1};(V/'sculpt-preview-fixtures-20261126.json').write_text(json.dumps(q,indent=2)+'\n');print(q['archive'])
