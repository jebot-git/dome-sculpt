"""Read-only expected ELF certification, including Btrfs map/stat device IDs.

The kernel's map device for a Btrfs file may differ from st_dev. Certify it
against an actual independent read-only mapping of the exact expected file.
No product data, GL context, input action or error state is changed.
"""
import hashlib,mmap,os,re
from pathlib import Path

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def certificate(path):
    path=Path(path).resolve()
    with path.open('rb') as stream:
        before=os.fstat(stream.fileno())
        assert before.st_size>=4 and stream.read(4)==b'\x7fELF'
        with mmap.mmap(stream.fileno(),min(before.st_size,4096),access=mmap.ACCESS_READ):
            matches=[]
            for line in Path('/proc/self/maps').read_text().splitlines():
                fields=line.split(None,5)
                if len(fields)==6 and fields[5]==str(path) and int(fields[4])==before.st_ino:
                    matches.append(fields)
            assert matches,('Independent expected-file mapping missing',str(path))
            devices={fields[3] for fields in matches}
            assert len(devices)==1,('Ambiguous independent expected-file mapping',str(path),devices)
            after=os.fstat(stream.fileno())
            assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
            return {'path':str(path),'stat_device':before.st_dev,'inode':before.st_ino,'map_device':next(iter(devices)),'sha256':sha(path),'certificate':'Actual independent read-only kernel mapping of exact expected provider'}

class Witness:
    def __init__(self,expected,app,xvfb):
        self.expected=expected;self.app=Path(app);self.xvfb=Path(xvfb)
        self.app_stat=self.app.stat();self.xvfb_stat=self.xvfb.stat()
        self.certificates={};self.mapped={};self.apps={};self.xvfbs={};self.drm={};self.shared_data={}

    def observe(self,row,monitor):
        for record in row.get('known_processes',[]):
            if not monitor.alive(record):continue
            pid=record['pid']
            try:
                exe=Path('/proc',str(pid),'exe');actual=exe.stat()
                kind='app' if (actual.st_dev,actual.st_ino)==(self.app_stat.st_dev,self.app_stat.st_ino) else 'xvfb' if (actual.st_dev,actual.st_ino)==(self.xvfb_stat.st_dev,self.xvfb_stat.st_ino) else None
                if kind is None:continue
                if kind=='xvfb':
                    self.xvfbs[str(pid)]={'identity':record,'actual_executable_sha256':sha(exe),'expected_executable_sha256':self.expected[str(self.xvfb)]}
                    assert self.xvfbs[str(pid)]['actual_executable_sha256']==self.expected[str(self.xvfb)]
                    continue
                assert os.readlink('/proc/'+str(pid)+'/ns/mnt')==os.readlink('/proc/self/ns/mnt'),'App changed mount namespace'
                self.apps[str(pid)]=record
                maps=Path('/proc',str(pid),'maps').read_text()
                for line in maps.splitlines():
                    fields=line.split(None,5)
                    if len(fields)!=6 or not fields[5].startswith('/'):continue
                    if fields[5].endswith(' (deleted)'):
                        # Kernel SystemV shared image buffers are mutable data,
                        # not path-backed selected ELF providers. Keep their
                        # raw identity; no executable/deleted ELF is excused.
                        if fields[1]in ['rw-s','r--s']and int(fields[2],16)==0 and fields[3]=='00:01'and re.fullmatch(r'/SYSV[0-9a-fA-F]{8} \(deleted\)',fields[5]):
                            self.shared_data[str(pid)+':'+fields[0]]={'pid':pid,'start':record['start'],'raw_map':line,'classification':'Non-executable kernel SystemV shared image data; not an ELF certificate'}
                            continue
                        raise RuntimeError(('Deleted product mapping',line))
                    path=Path(fields[5]);key=str(pid)+':'+str(path)
                    if key in self.mapped:continue
                    with path.open('rb')as stream:
                        if stream.read(4)!=b'\x7fELF':continue
                    resolved=str(path.resolve());wanted=self.expected.get(str(path),self.expected.get(resolved))
                    assert wanted,('Unpinned actual selected ELF',str(path))
                    if resolved not in self.certificates:self.certificates[resolved]=certificate(path)
                    proof=self.certificates[resolved]
                    assert wanted==proof['sha256'] and fields[3]==proof['map_device'] and int(fields[4])==proof['inode'],('Actual mapping differs from certified expected ELF',str(path),fields,proof)
                    self.mapped[key]={'pid':pid,'start':record['start'],'path':str(path),'sha256':wanted,'map_device':fields[3],'inode':int(fields[4]),'expected_certificate':proof}
                fds=[]
                for entry in Path('/proc',str(pid),'fd').iterdir():
                    try:
                        target=os.readlink(entry)
                        if target.startswith('/dev/dri/'):
                            st=entry.stat();fds.append({'fd':int(entry.name),'target':target,'device':st.st_rdev})
                    except(FileNotFoundError,ProcessLookupError):pass
                if fds:self.drm[str(pid)]={'identity':record,'fds':fds}
            except(FileNotFoundError,ProcessLookupError):continue

    def result(self):
        return {'actual_apps':self.apps,'actual_private_Xvfb':self.xvfbs,'actual_mapped_ELFs':self.mapped,'actual_DRM_FDs':self.drm,'observed_nonexecutable_SystemV_data':self.shared_data}
