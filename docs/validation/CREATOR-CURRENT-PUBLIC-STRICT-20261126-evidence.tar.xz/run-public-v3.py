from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,re,sys,time,traceback
sys.dont_write_bytecode=True
out=Path(__file__).resolve().parent
src=out.parent/'vroid-creator-public-resume-20261126'
build=out/'release'
mode=sys.argv[1]
assert mode in ['fixture','accept','cancel','focus','desktop']
case=out/('public-'+mode+'-v3');case.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
monitor=load('creator_owned_monitor',out/'owned-monitor.py')
witness_module=load('creator_provider_witness',out/'provider-witness-v2.py')
app=build/'dome-sculpt';inspector=build/'dome-sculpt-creator-workspace-test'
runtime=build/'libdome-sculpt-creator-workspace-runtime.so'
xvfb=out/'private-x11/usr/bin/Xvfb'
env={k:v for k,v in os.environ.items()if not k.startswith(('LD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_','DYLD_'))}
for key in ['DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','XR_RUNTIME_JSON','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(key,None)
env.update(PATH=str(out/'private-bin-v2')+':/usr/local/bin:/usr/bin',LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:'+str(out/'private-x11/usr/lib64')+':/usr/lib64',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(out/'private-python'),LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',XR_RUNTIME_JSON=str(case/'no-physical-runtime.json'))
if mode=='desktop':env.update(LIBGL_ALWAYS_SOFTWARE='1')
elif mode!='fixture':env.update(DRI_PRIME='pci-0000_03_00_0',MESA_LOADER_DRIVER_OVERRIDE='iris',EGL_PLATFORM='surfaceless',__EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json',DOME_BAKED_EMISSION_APP_PRELOAD=str(out/'device-auth.so'),DOME_MARKER_DEVICE_REPORT=str(case/'actual-device'))
pins={}
def pin(path):
    path=Path(path)
    if path.is_file():pins[str(path.resolve())]=sha(path)
for path in [app,inspector,runtime,out/'device-auth.so',out/'owned-monitor.py',out/'provider-witness-v2.py',Path(__file__),src/'tests/creator-workspace-xr.py',src/'tests/creator-workspace-menu.py',out/'private-bin-v2/Xvfb',xvfb,out/'private-x11/usr/bin/xkbcomp','/usr/bin/python3.14','/usr/bin/bwrap','/usr/bin/dbus-run-session','/usr/bin/dbus-daemon','/usr/share/glvnd/egl_vendor.d/50_mesa.json']:
    pin(path)
for root in [Path('/usr/lib64'),Path('/usr/lib64/dri'),Path('/opt/fltk-vr/toolkit/lib'),Path('/opt/fltk-vr/bdf-runtime/lib'),out/'private-x11/usr/lib64']:
    for path in root.glob('*'):
        if path.is_file():
            try:
                with path.open('rb')as f:
                    if f.read(4)==b'\x7fELF':pin(path)
            except PermissionError:pass
for root in [out/'private-python',Path('/usr/lib/python3.14/site-packages/Xlib'),Path('/usr/lib64/python3.14/site-packages/PIL')]:
    for path in root.rglob('*'):
        if path.is_file()and path.suffix in ['.py','.so']:pin(path)
for original,wanted in json.loads((out/'build-before.json').read_text()).items():
    if Path(original).is_relative_to(src):
        assert sha(original)==wanted; pins[original]=wanted
seed=out/'public-fixture-v1/fixture/creator-input.dsculpt'
if mode!='fixture':pin(seed);assert seed.is_file()
command=[str(inspector),'--fixture',str(case/'fixture')]if mode=='fixture'else ['/usr/bin/python3.14',str(src/'tests/creator-workspace-menu.py'),str(app),str(inspector),str(seed),str(case/'workflow')]if mode=='desktop'else ['/usr/bin/python3.14',str(src/'tests/creator-workspace-xr.py'),str(app),str(runtime),str(inspector),str(seed),mode,str(case/'workflow')]
rss=6*1024**3 if mode=='desktop'else 4*1024**3
recorded_environment={k:v for k,v in env.items()if k in ['PATH','LD_LIBRARY_PATH','PYTHONDONTWRITEBYTECODE','PYTHONPATH','LP_NUM_THREADS','OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','XR_RUNTIME_JSON','LIBGL_ALWAYS_SOFTWARE','DRI_PRIME','MESA_LOADER_DRIVER_OVERRIDE','EGL_PLATFORM','__EGL_VENDOR_LIBRARY_FILENAMES','DOME_BAKED_EMISSION_APP_PRELOAD','DOME_MARKER_DEVICE_REPORT']}
plan={'source':'5509958f','production':'05f5d1cc','mode':mode,'command':command,'cwd':str(case),'RSS_limit':rss,'timeout_seconds':240,'virtual_AS_cap':None,'environment':recorded_environment,'input_pins':pins,'scope':'Current05 public application workflow; synthetic XR input, no physical HMD or native Wayland desktop claim'}
(case/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s={'terminal':False,'state':'preparing','mode':mode,'steps':[],'plan_sha256':sha(case/'plan.json')}
def save():(case/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
witness=witness_module.Witness(pins,app,xvfb)
def live(row):
    witness.observe(row,monitor);s['live']=row;s['observed']=witness.result();save()
lease=None
try:
    assert json.loads((out/'build-review.json').read_text())['exit']==0
    assert not drift()
    lease=open('/tmp/dome-sculpt-arc-device.lock','a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(lease.fileno());s['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino,'before_any_ldd_or_product':True};save()
    for path in [app,inspector,runtime,out/'device-auth.so']:
        row=monitor.run(['/usr/bin/ldd',str(path)],cwd=case,env=env,log=case/(path.name+'.ldd'),timeout=30,max_rss=rss);s['steps'].append({'name':'loader '+path.name,**row});assert row['exit']==0 and not row.get('error')
        text=(case/(path.name+'.ldd')).read_text();assert 'not found'not in text
        for name in re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text):
            resolved=str(Path(name).resolve());assert resolved in pins and sha(name)==pins[resolved],('Loader provider outside prospective pins',name)
    row=monitor.run(command,cwd=case,env=env,log=case/'process.log',timeout=240,max_rss=rss,progress=live)
    s['steps'].append({'name':'public '+mode,**row});s.pop('live',None);s['observed']=witness.result();save();assert row['exit']==0 and not row.get('error')and not row['signals'],row
    if mode=='fixture':
        assert (case/'fixture/creator-input.dsculpt').is_file();s['fixture_sha256']=sha(case/'fixture/creator-input.dsculpt')
    else:
        report=json.loads((case/'workflow/report.json').read_text());assert report['complete']and not report['error']and not report['drift']and all(x['passed']for x in report['checks']);s['actual_checks']=report['count'];assert len(witness.apps)==(1 if mode=='desktop'else 2)
        assert all(any(v['pid']==int(pid)and v['path']==str(app)for v in witness.mapped.values())for pid in witness.apps),'Missing actual expected App ELF map'
        if mode=='desktop':assert witness.xvfbs,'Missing actual private Xvfb identity'
        else:
            devices=list((case/'actual-device').glob('*/device.txt'));assert len(devices)==2
            for path in devices:
                d=dict(line.split('=',1)for line in path.read_text().splitlines()if '='in line and not line.startswith('fd='))
                assert 'Arc'in d['renderer']and'A770'in d['renderer']and d['vendor']=='Intel'and d['render_node']=='/dev/dri/renderD129'and d['pci'].endswith('/0000:03:00.0')and d['vendor_id']=='0x8086'and d['device_id']=='0x56a0'
                assert int(d['egl_context'],16)and int(d['egl_display'],16)and re.search(r'^fd=\d+$',path.read_text(),re.M)
                assert(path.parent/'context-maps.txt').is_file()
            assert Path('/sys/dev/char/226:129/device/driver').resolve().name=='i915'
            s['actual_device_reports']={str(p):sha(p)for p in devices}
    assert not drift();s.update(state='complete',exit=0)
except BaseException as error:s.update(state='failed',exit=1,error=repr(error),traceback=traceback.format_exc())
finally:
    s['input_drift']=drift();s['owned_remaining']=[]
    for row in s['steps']:
        for record in row.get('known_processes',[]):
            if monitor.alive(record):s['owned_remaining'].append(record)
    if s['input_drift']or s['owned_remaining']:s.update(state='failed',exit=1)
    s['terminal']=True
    if lease:
        if 'lease'in s:s['lease']['released']=time.time()
        save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
    save()
raise SystemExit(s['exit'])
