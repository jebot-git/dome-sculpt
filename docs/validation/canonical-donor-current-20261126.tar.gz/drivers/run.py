from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

out=Path(__file__).resolve().parent
art=out.parent
mode,method=sys.argv[1:]
assert method in ('field','clear')
arc=mode=='arc'
profile='asan' if arc else 'release'
prior=art/'canonical-donor-current-validation-v3-20261126'/profile
sdk=art/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
evidence={'mode':mode,'invocation':os.getenv('INVOCATION_ID')}
stage=out/(mode+'-'+method)
stage.mkdir(exist_ok=True)
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(**fields):
    evidence.update(fields)
    (stage/'status.json').write_text(json.dumps(evidence,indent=2)+'\n')
def await_test(folder):
    path=folder/'status.json'
    while True:
        data=json.loads(path.read_text()) if path.exists() else {}
        if data.get('terminal'):break
        subprocess.run(['systemctl','--user','is-active','--quiet',f'ds-canonical-donor-current-{folder.name}-v3-20261126.service'],check=True)
        time.sleep(1)
    assert data['exit']==0 and data['candidate']==os.environ['DOME_UV_NORMAL_CANDIDATE'],data
    return data
try:
    write(phase='wait for matched build and native tests',terminal=False)
    receipt=await_test(prior)
    build=prior/'build'
    release=prior.parent/'release'
    await_test(release)
    fixture=release/'build/source-canonical-normal-bake'/(method+'-affine-before.dsculpt')
    app=build/'dome-sculpt'
    runtime=build/'libdome-sculpt-test-runtime.so'
    inspector=build/'dome-sculpt-native-authoring-inspect'
    assert sha(app)==receipt['app_sha256'] and sha(runtime)==receipt['runtime_sha256']
    assert sha(inspector)==receipt['binaries'][inspector.name]
    verifier=build/'dome-sculpt-source-canonical-normal-bake-test'
    assert sha(verifier)==receipt['binaries'][verifier.name]
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
         'LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1',
         'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
         'DOME_CANONICAL_CLEARED':'1' if method=='clear' else '0',
         'DOME_AFFINE_VERIFY_SOURCES':str(build/'dome-sculpt-source-canonical-normal-bake-test')}
    if arc:
        node='/dev/dri/renderD129'
        prefix.extend(['--dev-bind',node,node])
        env.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
                   ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                   UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    if mode=='wayland':
        public=art/'creator-public-build-20261126'
        comp=public/'wayland-reference/dome-compositor'
        comp_proof=json.loads((comp.parent/'compositor-build-status.json').read_text())
        assert comp_proof['exit']==0 and comp_proof['source']=='acc2b70ae61dedec2a23727f67c60c0303d0f76f' and sha(comp)==comp_proof['output_sha256']
        probe=art/'combined-atlas-hdr-preview-full-20261126/build/libdome-sculpt-test-widgets.so'
        env.update(PATH=str(public/'private-bin-v3')+':/usr/bin',PYTHONPATH=str(public/'private-python'),
                   PYTHONDONTWRITEBYTECODE='1',DOME_COMPOSITOR=str(comp),DOME_AFFINE_INSPECTOR=str(inspector),
                   DOME_AFFINE_PATCH=str(fixture),DOME_CAGE_APP=str(app),DOME_CAGE_PROBE=str(probe),
                   DOME_CAGE_WL_OUT=str(stage/'workflow'),
                   LD_LIBRARY_PATH=f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:{public}/private-x11/usr/lib64:/usr/lib64')
        command=['/usr/bin/python3.14',out/'wayland.py']
        write(compositor_sha256=sha(comp),compositor_source=comp_proof['source'],probe_sha256=sha(probe))
    else:
        env['DOME_XR_REQUIRE_RENDERER']='Arc(tm) A770' if arc else 'llvmpipe'
        command=['/usr/bin/python3',out/'xr.py',app,runtime,inspector,fixture,stage/'workflow']
    for k,v in env.items():prefix.extend(['--setenv',k,v])
    write(phase='run through desktop or OpenXR frontend',app_sha256=sha(app),
          input_sha256=sha(fixture),inspector_sha256=sha(inspector),verifier_sha256=sha(verifier),run_script_sha256=sha(command[1]))
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock,(stage/'run.log').open('w') as log:
        if arc or mode=='wayland':fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,[*prefix,*command])),file=log,flush=True)
        subprocess.run([*prefix,*command],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
    report=stage/'workflow/report.json'
    checks=json.loads(report.read_text())['checks']
    assert len(checks)==10 and all(row['passed'] for row in checks),checks
    native=stage/('workflow/patch.dsculpt' if mode=='wayland' else 'workflow/accept.dsculpt')
    write(phase='complete',terminal=True,exit=0,checks=len(checks),report_sha256=sha(report),native_sha256=sha(native))
except BaseException as error:
    write(terminal=True,exit=1,error=repr(error))
    raise
