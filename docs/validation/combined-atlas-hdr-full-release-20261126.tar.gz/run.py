from hashlib import file_digest
import json
import os
from pathlib import Path
import shlex
import subprocess
import time
import xml.etree.ElementTree as ET

out = Path(__file__).resolve().parent
artifacts = out.parent
build = out/'build'
source = artifacts/'combined-atlas-hdr-preview-source-20261126'
previous = artifacts/'vrm-consumer-combined-20261126'/'full-private-ctest'
focused = artifacts/'combined-atlas-hdr-preview-validation-20261126'
expected = '5c977be9be8d90f0a6ada3ef34df9d4d27769209'
sdk = Path('/opt/fltk-vr/toolkit')
bitmap = Path('/opt/fltk-vr/bdf-runtime')
started = time.monotonic()
state = {'candidate': expected, 'terminal': False, 'invocation': os.getenv('INVOCATION_ID'),
         'fltk': str(sdk), 'bitmap': str(bitmap)}


def save(**fields):
    state.update(fields, elapsed_seconds=round(time.monotonic()-started,3))
    tmp = out/'status.tmp'
    tmp.write_text(json.dumps(state, indent=2)+'\n')
    tmp.replace(out/'status.json')


def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()


def sha(path):
    with path.open('rb') as stream:
        return file_digest(stream,'sha256').hexdigest()


def invoke(command, log, env=None):
    with (out/log).open('w') as stream:
        print(shlex.join(map(str,command)),file=stream,flush=True)
        return subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=env).returncode


def cases(path):
    values = {}
    for case in ET.parse(path).getroot().iter('testcase'):
        name = case.attrib['name']
        assert name not in values
        values[name] = 'failed' if case.find('failure') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
    return values


try:
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    save(phase='Configure clean optimized Release')
    os.environ['PKG_CONFIG_PATH']=f'{bitmap}/lib/pkgconfig:/usr/lib64/pkgconfig'
    os.environ['LD_LIBRARY_PATH']=f'{sdk}/lib:{bitmap}/lib:/usr/lib64'
    cmd=['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_COMPUTE_BACKEND=CPU',
         '-DDOME_KEY_OOM_PARTITIONS=128','-DDOME_PHYSICAL_OOM_PARTITIONS=128',
         f'-DFLTK_DIR={sdk}/share/fltk']
    assert invoke(cmd,'configure.log')==0
    assert (build/'CMakeCache.txt').is_file() and (build/'build.ninja').is_file()
    before=sha(build/'CMakeCache.txt')
    save(phase='Wait for focused Arc replay before full compile', cache_sha256=before)
    wait = time.monotonic()+900
    while True:
        arc=focused/'arc-asan/status.json'
        if arc.is_file():
            entry=json.loads(arc.read_text())
            if entry['terminal']:
                assert entry['candidate']==expected
                save(focused_arc={'exit':entry['exit'],'checks':entry['checks']})
                break
        assert time.monotonic()<wait
        time.sleep(5)
    save(phase='Build all optimized Release targets')
    built=invoke(['cmake','--build',build,'--parallel','7'],'build.log')
    save(build_exit=built)
    assert built==0 and git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    assert before==sha(build/'CMakeCache.txt')
    application=sha(build/'dome-sculpt')
    registration=subprocess.check_output(['ctest','--test-dir',build,'--show-only=json-v1'],text=True)
    (out/'registered.json').write_text(registration)
    tests=json.loads(registration)['tests']
    assert len(tests)==1360 and all(t.get('command') for t in tests)
    private=out/'private'
    for name in ('home','cache','config','data','runtime','state'):
        (private/name).mkdir(mode=0o700,parents=True)
    variables={'PATH':'/usr/bin:/bin','HOME':str(private/'home'),'XDG_CACHE_HOME':str(private/'cache'),
               'XDG_CONFIG_HOME':str(private/'config'),'XDG_DATA_HOME':str(private/'data'),
               'XDG_RUNTIME_DIR':str(private/'runtime'),'XDG_STATE_HOME':str(private/'state'),
               'LD_LIBRARY_PATH':os.environ['LD_LIBRARY_PATH'],'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2',
               'OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2'}
    command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    for key,value in variables.items():
        command.extend(['--setenv',key,value])
    junit=out/'full.xml'
    command.extend(['ctest','--test-dir',build,'-j4','--output-on-failure','--output-junit',junit])
    save(phase='Run all registered CTests in private software profile', registered=len(tests),
         app_sha256=application, command=list(map(str,command)))
    tested=invoke(command,'ctest.log')
    baseline=cases(previous/'full.xml')
    current=cases(junit)
    assert set(baseline)==set(current) and len(current)==len(tests)
    difference={
        'fixed':sorted(k for k in current if baseline[k]!='passed' and current[k]=='passed'),
        'regressed':sorted(k for k in current if baseline[k]=='passed' and current[k]!='passed'),
        'failed': sorted(k for k,v in current.items() if v=='failed'),
        'skipped': sorted(k for k,v in current.items() if v=='skipped'),
    }
    (out/'comparison.json').write_text(json.dumps(difference,indent=2)+'\n')
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    assert sha(build/'dome-sculpt')==application and before==sha(build/'CMakeCache.txt')
    save(phase='Full private Release CTest finished', terminal=True, exit=tested,
         totals={k:list(current.values()).count(k) for k in ('passed','failed','skipped')})
except Exception as error:
    save(phase='Qualification runner stopped', terminal=True, exit=1, error=repr(error))
raise SystemExit(state['exit'])
