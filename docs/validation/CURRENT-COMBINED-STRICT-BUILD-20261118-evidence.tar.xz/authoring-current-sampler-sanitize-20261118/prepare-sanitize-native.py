from pathlib import Path
import hashlib
import json

base = Path('/home/blux/de-xr/dome-sculpt')
build = Path(__file__).parent
release = base / 'artifacts/authoring-current-sampler-release-20261118/native-selected-v2'
out = build / 'native-selected-v1'
out.mkdir(exist_ok=False)
plan = json.loads((release / 'plan.json').read_text())
owner_plan = json.loads((build / 'plan.json').read_text())
status = json.loads((build / 'status.json').read_text())
strict = json.loads((base / 'artifacts/source-owning-hdr-source8-export-gates-20261118/sanitize/plan.json').read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert status['exit'] == 0 and not status['input_drift']
for step in plan['steps']:
    argv = step['argv']
    argv[0] = str(build / Path(argv[0]).name)
    argv[:] = [str(out / Path(value).relative_to(release))
               if index and value.startswith(str(release) + '/') else value
               for index, value in enumerate(argv)]
    step['ELF_sha256'] = status['products'][Path(argv[0]).name]
    step['AS_bytes'] = None
plan.update(source=owner_plan['source'],
            scope='Strict ASan/UBSan/leak selected15 coherent05 native/GL cases. No AS cap, same RSS/case limits; not all-target or full-goal acceptance.',
            pins=dict(owner_plan['pins']), profile='strict-ASAN-UBSAN-leaks',
            environment=dict(strict['environment'], MALLOC_ARENA_MAX='2', MALLOC_MMAP_THRESHOLD_='131072'),
            whole_unit_seconds=3600, whole_unit_memory='6G')
for step in plan['steps']:
    plan['pins'][step['argv'][0]] = step['ELF_sha256']
plan['pins'][plan['monitor']['path']] = plan['monitor']['sha256']
for name in ['status.json', 'actual-new-MD-owners.json', 'actual-link-dependencies.json']:
    plan['pins'][str(build / name)] = sha(build / name)
(out / 'plan.json').write_text(json.dumps(plan, indent=2))
source = (release / 'run.py').read_text()
source = source.replace("assert 'not found' not in text and not re.search(r'lib(?:asan|ubsan)\\.so', text)",
                        "assert 'not found' not in text\n        assert re.search(r'libasan\\.so', text) and re.search(r'libubsan\\.so', text)")
source = source.replace("if now - last_observation[0] < 1:",
                        "if now - last_observation[0] < (1 if observed.get('live_sanitizers') else .02):")
source = source.replace("                    (out / (name + '.maps')).write_text((proc / 'maps').read_text())", """                    maps = (proc / 'maps').read_text()
                    (out / (name + '.maps')).write_text(maps)
                    if 'libasan.so' in maps and 'libubsan.so' in maps:
                        observed['live_sanitizers'] = True
                        observed['live_witness_time'] = time.time()""")
source = source.replace("        text = (out / (name + '.log')).read_text()\n        matches =", """        assert observed.get('live_sanitizers'), (name, 'Missing actual ASan/UBSan mapped witness')
        text = (out / (name + '.log')).read_text()
        assert not re.search(r'ERROR: AddressSanitizer|runtime error:|ERROR: LeakSanitizer|SUMMARY: (?:AddressSanitizer|UndefinedBehaviorSanitizer)', text)
        matches =""")
compile(source, str(out / 'run.py'), 'exec')
(out / 'run.py').write_text(source)
assert "assert re.search(r'libasan\\.so', text)" in source
assert all(step['AS_bytes'] is None for step in plan['steps'])
print('Prepared strict15:', len(plan['pins']), 'pins; no AS caps; RSS retained')
