from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import time

out = Path(__file__).parent
plan = json.loads((out / 'plan.json').read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
state = {'terminal': False, 'source': plan['source'], 'scope': plan['scope'], 'steps': []}
started = time.monotonic()


def save():
    (out / 'status.json').write_text(json.dumps(state, indent=2) + '\n')


def run(name, argv):
    start = time.monotonic()
    with (out / (name.replace('/', '_') + '.log')).open('wb') as log:
        proc = subprocess.run(['/usr/bin/timeout', '--signal=TERM', '--kill-after=5s', '900s', *argv],
                              cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT)
    return {'name': name, 'argv': argv, 'cwd': str(out), 'exit': proc.returncode,
            'seconds': time.monotonic() - start}


def verify():
    bad = [path for path, expected in plan['pins'].items()
           if not Path(path).is_file() or sha(path) != expected]
    if bad:
        raise RuntimeError('Immutable input drift: ' + repr(bad[:8]))


def first_rule(path):
    rule = ''
    for line in path.read_text().splitlines():
        continued = line.endswith('\\')
        rule += line[:-1] + ' ' if continued else line
        if not continued:
            break
    return shlex.split(rule.split(':', 1)[1])


env = dict(plan['environment'])
try:
    verify()
    assert len({item['object'] for item in plan['compiles']}) == len(plan['compiles'])
    original = json.loads(Path(plan['old_core_members']).read_text())
    old_members = subprocess.check_output(['/usr/bin/ar', 't', plan['old_core']], text=True).splitlines()
    assert old_members == [item['member'] for item in original]
    for item in original:
        payload = subprocess.check_output(['/usr/bin/ar', 'p', plan['old_core'], item['member']])
        assert hashlib.sha256(payload).hexdigest() == item['sha256']
    state['verified_old_core_members'] = len(original)
    save()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for result in pool.map(lambda item: run(item['name'], item['argv']), plan['compiles']):
            state['steps'].append(result)
            save()
    assert all(item['exit'] == 0 for item in state['steps']), 'Complete TU compilation failed'
    current_core = out / 'libdome-sculpt-core.a'
    shutil.copyfile(plan['old_core'], current_core)
    replacement = plan['compiles'][0]['object']
    assert Path(replacement).name == 'source-maps.cpp.o'
    for name, argv in [('archive', ['/usr/bin/ar', 'r', str(current_core), replacement]),
                       ('ranlib', ['/usr/bin/ranlib', str(current_core)])]:
        result = run(name, argv)
        state['steps'].append(result)
        save()
        assert result['exit'] == 0, name
    assert subprocess.check_output(['/usr/bin/ar', 't', str(current_core)], text=True).splitlines() == old_members
    for item in original:
        expected = sha(replacement) if item['member'] == 'source-maps.cpp.o' else item['sha256']
        payload = subprocess.check_output(['/usr/bin/ar', 'p', str(current_core), item['member']])
        assert hashlib.sha256(payload).hexdigest() == expected
    for item in plan['links']:
        result = run(item['name'], item['argv'])
        state['steps'].append(result)
        save()
        assert result['exit'] == 0, item['name']
    owners = []
    unknown = []
    for item in plan['compiles']:
        dependencies = {str(Path(path).resolve()): sha(path) for path in first_rule(Path(item['MD']))}
        unknown.extend(path for path in dependencies if path not in plan['pins'])
        assert all(plan['pins'].get(path) == digest for path, digest in dependencies.items()), unknown
        owners.append(dict(item, object_sha256=sha(item['object']), MD_sha256=sha(item['MD']), dependencies=dependencies))
    (out / 'actual-new-MD-owners.json').write_text(json.dumps(owners, indent=2))
    verify()
    state.update(exit=0, unknown_dependencies=unknown, input_drift=[],
                 core_sha256=sha(current_core),
                 products={item['name']: sha(out / item['name']) for item in plan['links']})
except BaseException as error:
    state.update(exit=1, error=repr(error))
state.update(terminal=True, seconds=time.monotonic() - started)
save()
raise SystemExit(state['exit'])
