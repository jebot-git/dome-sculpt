from pathlib import Path
import hashlib
import json
import shlex
import subprocess

base = Path('/home/blux/de-xr/dome-sculpt')
out = Path(__file__).parent
old = base / 'artifacts/authoring-current-combined-sanitize-20261118'
oldsrc = base / 'artifacts/authoring-current-integration-20261118'
src = base / 'artifacts/authoring-current-sampler-integration-20261118'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
prior = json.loads((old / 'build-plan.json').read_text())
owners = json.loads((old / 'actual-MD-owners.json').read_text())
changed = set(subprocess.check_output(['git', 'diff', '--name-only', 'f5998a18', 'HEAD'], cwd=src, text=True).splitlines())
commands = (old / 'actual-target-commands.txt').read_text().splitlines()
commands += subprocess.check_output(['/usr/bin/ninja', '-C', str(old), '-t', 'commands', 'dome-sculpt-source-maps-test'], text=True).splitlines()
compile_by_output = {}
link_by_output = {}
for line in commands:
    segments = [[]]
    for token in shlex.split(line):
        if token == '&&':
            segments.append([])
        else:
            segments[-1].append(token)
    for segment in segments:
        if '/usr/bin/c++' not in segment and '/usr/bin/cc' not in segment:
            continue
        expanded = []
        for token in segment:
            expanded.extend(shlex.split((old / token[1:]).read_text()) if token.startswith('@') else [token])
        if '-o' not in expanded:
            continue
        destination = expanded[expanded.index('-o') + 1]
        if '-c' in expanded:
            compile_by_output[destination] = expanded
        else:
            link_by_output[destination] = expanded

pins = dict(prior['source_input_pins'])
for relative in subprocess.check_output(['git', 'ls-files', '-z'], cwd=src).decode().split('\0'):
    path = src / relative
    if relative and path.is_file():
        pins[str(path)] = sha(path)
affected = []
unchanged = []
for owner in owners:
    object_path = old / owner['object']
    depfile = old / owner['actual_compiler_MD']
    assert sha(object_path) == owner['sha256'] and sha(depfile) == owner['MD_sha256']
    rule = ''
    for line in depfile.read_text().splitlines():
        continued = line.endswith('\\')
        rule += line[:-1] + ' ' if continued else line
        if not continued:
            break
    dependencies = shlex.split(rule.split(':', 1)[1])
    touched = []
    for dependency in dependencies:
        path = Path(dependency).resolve()
        pins[str(path)] = sha(path)
        if path.is_relative_to(oldsrc):
            relative = str(path.relative_to(oldsrc))
            if relative in changed:
                touched.append(relative)
            else:
                assert sha(path) == sha(src / relative), relative
    record = dict(owner, changed_dependencies=sorted(set(touched)))
    (affected if touched else unchanged).append(record)
    pins[str(object_path)] = owner['sha256']
    pins[str(depfile)] = owner['MD_sha256']
assert len(affected) == 2 and len(unchanged) == 257

object_map = {}
compiles = []
for relative in [owner['object'] for owner in affected] + ['CMakeFiles/dome-sculpt-source-maps-test.dir/tests/source-maps.cpp.o']:
    argv = [value.replace(str(oldsrc), str(src)) for value in compile_by_output[relative]]
    destination = out / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    for flag, value in [('-o', destination), ('-MF', str(destination) + '.d'), ('-MT', destination)]:
        assert flag in argv
        argv[argv.index(flag) + 1] = str(value)
    object_map[relative] = str(destination)
    compiles.append({'name': Path(relative).name, 'argv': argv, 'cwd': str(out), 'object': str(destination), 'MD': str(destination) + '.d'})

links = []
for target in prior['targets'] + ['dome-sculpt-source-maps-test']:
    argv = []
    for token in link_by_output[target]:
        if token in object_map:
            token = object_map[token]
        elif token == 'libdome-sculpt-core.a':
            token = str(out / token)
        elif token.endswith(('.o', '.a')) and not Path(token).is_absolute():
            token = str(old / token)
        elif token.startswith('-Wl,--dependency-file='):
            token = '-Wl,--dependency-file=' + str(out / (target + '.link.d'))
        argv.append(token)
    argv[argv.index('-o') + 1] = str(out / target)
    links.append({'name': target, 'argv': argv, 'cwd': str(out)})
    for token in argv:
        if token.startswith('/') and Path(token).is_file():
            pins[token] = sha(token)

core = old / 'libdome-sculpt-core.a'
pins[str(core)] = sha(core)
plan = {
    'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=src, text=True).strip(),
    'source_path': str(src), 'scope': 'Three fresh complete TUs: two actual MD-affected owners plus new sampler regression; 257 explicitly qualified old owners retained. Updated197-member core and15 fresh consumer links. No header/layout change.',
    'compiles': compiles, 'links': links, 'affected_owners': affected,
    'unchanged_owners': unchanged, 'old_core': str(core),
    'old_core_members': str(old / 'actual-core-members.json'),
    'pins': pins, 'environment': prior['environment'],
}
(out / 'plan.json').write_text(json.dumps(plan, indent=2))
print('Prepared', len(compiles), 'fresh complete TUs,', len(links), 'fresh links;', len(pins), 'pins')
