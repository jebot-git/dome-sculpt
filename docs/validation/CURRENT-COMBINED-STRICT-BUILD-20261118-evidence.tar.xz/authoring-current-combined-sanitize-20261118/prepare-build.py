from pathlib import Path
import json,hashlib,subprocess,shlex,os
out=Path(__file__).resolve().parent;root=Path('/home/blux/de-xr/dome-sculpt');release=root/'artifacts/authoring-current-combined-release-20261118';rp=json.loads((release/'build-plan.json').read_text());cp=json.loads((out/'configure-plan.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();src=Path(cp['argv'][cp['argv'].index('-S')+1])
assert cp['source']=='f5998a1824a86f259ffbb31174bcd32244f3d8c1'and subprocess.check_output(['git','status','--porcelain'],cwd=src)==b''
raw=subprocess.check_output(['/usr/bin/ninja','-t','commands',*rp['targets']],cwd=out,text=True);(out/'planned-target-commands.txt').write_text(raw)
cc=json.loads((out/'compile_commands.json').read_text());byoutput={str(Path(x['output']).resolve()):x for x in cc};owners=[]
for command in raw.splitlines():
 argv=shlex.split(command)
 if '-c'not in argv or'-o'not in argv:continue
 obj=argv[argv.index('-o')+1];path=(out/obj).resolve();actual=byoutput[str(path)];flags=shlex.split(actual['command'])
 opts=[x for x in flags if x.startswith('-O')];assert opts and opts[-1]=='-O1',(obj,opts)
 for flag in ['-g1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-DNDEBUG']:assert flag in flags,(obj,flag)
 assert '-fno-sanitize=all'not in flags and'-fno-sanitize=address'not in flags and'-fno-sanitize=undefined'not in flags
 assert '--kill-after=5s'in argv and'900s'in argv,(obj,'missing actual compiler launcher')
 owners.append({'object':obj,'source':argv[argv.index('-c')+1],'actual_Ninja_command':command,'compile_commands_record':actual,'effective_optimization':opts[-1]})
assert len(owners)==259,len(owners);assert len({x['object']for x in owners})==259
assert sum(x['object'].startswith('CMakeFiles/dome-sculpt-core.dir/')for x in owners)==197
assert not list(out.rglob('*.o'))and not list(out.rglob('*.a')),'Not a fresh output tree'
pins=dict(cp['source_pins']);external=0
# The prior fresh combined Release audit supplies the actual selected external
# closure. No Release objects or generated payloads enter this strict build.
for filename in ['actual-input-manifest.json','actual-link-inputs.json']:
 data=json.loads((release/filename).read_text());items=data.items()if isinstance(data,dict)else((x['path'],x['sha256'])for x in data)
 for name,want in items:
  p=Path(name).resolve()
  if p.is_relative_to(src)or p.is_relative_to(release):continue
  assert p.is_file()and sha(p)==want,('prior external input drift',str(p));pins[str(p)]=want;external+=1
# Pin the actual strict SDK, compiler instrumentation runtimes, and tools before
# compiling or linking; a same-version Release provider is not a substitute.
sdk=root/'artifacts/sdk-20261111/toolkit-sanitize'
for p in sdk.rglob('*'):
 if p.is_file():pins[str(p)]=sha(p)
for command in ['/usr/bin/c++','/usr/bin/cc','/usr/bin/cmake','/usr/bin/ninja','/usr/bin/ar','/usr/bin/ranlib','/usr/bin/ld','/usr/bin/timeout']:
 p=Path(command).resolve();pins[str(p)]=sha(p)
for name in ['cc1plus','cc1','libasan_preinit.o','libasan.so','libubsan.so','libstdc++.so','libgcc_s.so']:
 key='-print-prog-name='if name.startswith('cc1')else'-print-file-name=';p=Path(subprocess.check_output(['/usr/bin/c++',key+name]).decode().strip()).resolve()
 assert p.is_file(),str(p);pins[str(p)]=sha(p)
for p in out.rglob('*'):
 if p.is_file()and p.name not in ['configure.log','configure-status.json','planned-target-commands.txt','prepare-build.py']and p.suffix not in ['.log']and'.ninja_deps'not in str(p)and'.ninja_log'not in str(p):pins[str(p)]=sha(p)
plan={'source':cp['source'],'scope':'Fresh coherent strict O1/g1 ASan+UBSan App+13fixtures from f599; all259 selected compiler owners including197core/support instrumented; no Release or prior-layout object reuse, no runtime admission','targets':rp['targets'],'argv':['/usr/bin/ninja','-d','keepdepfile','-d','keeprsp','-j2','-v',*rp['targets']],'environment':cp['environment'],'source_input_pins':pins,'prior_pinned_external_dependencies':external,'planned_owners':owners,'profile':{'optimization':'O1','debug':'g1','ASan_UBSan_all_selected_owners':True,'frame_pointers':True,'compiler_timeout_seconds':900,'whole_unit_seconds':3600,'unit_memory_bytes':8*1024**3,'no_runtime_started':True}}
(out/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print({'source':plan['source'],'owners':len(owners),'core':197,'source_pins':len(cp['source_pins']),'total_pins':len(pins),'prior_external_dependencies':external,'plan_sha256':sha(out/'build-plan.json')})
