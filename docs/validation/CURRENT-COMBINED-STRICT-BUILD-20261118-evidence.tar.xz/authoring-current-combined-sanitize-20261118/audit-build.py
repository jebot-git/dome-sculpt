from pathlib import Path
import json,hashlib,subprocess,shlex,re
out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((out/'build-plan.json').read_text());s=json.loads((out/'build-status.json').read_text());assert s['state']=='terminal'and s['exit']==0
errors=[];pins=p['source_input_pins'];canonical={str(Path(k).resolve()):v for k,v in pins.items()}
gen_observation=json.loads((out/'generation-input-pins.json').read_text());extra=gen_observation['input_pins']
assert not[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
assert not[p for p,h in extra.items()if not Path(p).is_file()or sha(p)!=h]
raw=subprocess.check_output(['/usr/bin/ninja','-t','commands',*p['targets']],cwd=out,text=True);(out/'actual-target-commands.txt').write_text(raw);log=(out/'build.log').read_text();cc=json.loads((out/'compile_commands.json').read_text());byoutput={str(Path(x['output']).resolve()):x for x in cc};owners=[];dependencies={};aliases={};generated={};incidences=0
allowed_generated={'armorpaint-blur-generated/blur_weights.hpp','appmenu-client.h','appmenu-protocol.c'}
def first_rule(path):
 text=''
 for line in path.read_text().splitlines():
  continued=line.endswith('\\');text+=line[:-1]+' 'if continued else line
  if not continued:break
 lhs,rhs=text.split(':',1);return shlex.split(lhs),shlex.split(rhs)
def file(name):return(Path(name)if Path(name).is_absolute()else out/name)
def checked_input(name):
 original=file(name);actual=original.resolve();assert actual.is_file(),str(actual);value=sha(actual);key=str(actual)
 if key in canonical:assert canonical[key]==value,('actual input drift',key)
 elif actual.is_relative_to(out)and str(actual.relative_to(out))in allowed_generated:generated[key]=value
 else:raise RuntimeError('Unpinned actual compiler dependency '+str(original))
 if str(original)!=key:aliases[str(original)]=key
 dependencies.setdefault(key,value);return key
commands=[]
for command in raw.splitlines():
 argv=shlex.split(command)
 if'-c'in argv and'-o'in argv:commands.append((argv[argv.index('-o')+1],argv[argv.index('-c')+1],command,argv))
assert len(commands)==259 and len({x[0]for x in commands})==259
for rel,source,command,argv in commands:
 obj=out/rel;md=out/(rel+'.d');assert obj.is_file()and md.is_file();lhs,rhs=first_rule(md);assert rel in lhs and rhs
 assert file(rhs[0]).resolve()==file(source).resolve();assert command in log,('actual compiler command not in execution log',rel)
 actualcc=byoutput[str(obj.resolve())];assert Path(actualcc['directory']).resolve()==out and Path(actualcc['file']).resolve()==file(source).resolve()
 args=shlex.split(actualcc['command']);opt=[v for v in args if v.startswith('-O')];assert opt[-1]=='-O1'and'-g1'in args and'-DNDEBUG'in args
 for flag in ['-fsanitize=address,undefined','-fno-omit-frame-pointer']:assert flag in args and flag in argv,(rel,flag)
 assert'900s'in argv and'--kill-after=5s'in argv
 deps=[checked_input(v)for v in rhs];incidences+=len(deps)
 owners.append({'object':rel,'sha256':sha(obj),'actual_compiler_MD':str(md.relative_to(out)),'MD_sha256':sha(md),'dependencies':len(deps),'actual_dependencies':deps,'source':source,'actual_command':command,'cwd':str(out),'effective_optimization':opt[-1],'instrumentation':['address','undefined'],'debug':'g1','frame_pointers':True})
assert {str(x.relative_to(out))[:-2]for x in out.rglob('*.o.d')}=={x['object']for x in owners}
owner_by_path={str((out/x['object']).resolve()):x for x in owners};archives=[];payloads=0
for command in raw.splitlines():
 argv=shlex.split(command)
 if'/usr/bin/ar'not in argv:continue
 assert command in log;at=argv.index('/usr/bin/ar');archive=file(argv[at+2]);args=argv[at+3:];args=args[:args.index('&&')]if'&&'in args else args;objects=[]
 for value in args:
  if value.startswith('@'):objects.extend(shlex.split(file(value[1:]).read_text()))
  else:objects.append(value)
 expected={Path(v).name:owner_by_path[str(file(v).resolve())]for v in objects};assert len(expected)==len(objects)
 names=subprocess.check_output(['/usr/bin/ar','t',str(archive)]).decode().splitlines();assert len(names)==len(expected)and set(names)==set(expected)
 members=[]
 for name in names:
  digest=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(archive),name])).hexdigest();assert digest==expected[name]['sha256'];members.append({'member':name,'sha256':digest,'object':expected[name]['object']})
 payloads+=len(members);archives.append({'archive':str(archive),'sha256':sha(archive),'members':members,'actual_writer_command':command})
assert len(archives)==14 and payloads==219,(len(archives),payloads)
core=next(x for x in archives if Path(x['archive']).name=='libdome-sculpt-core.a');assert len(core['members'])==197
links={}
for target in p['targets']:
 md=out/'CMakeFiles'/(target+'.dir')/'link.d';lhs,rhs=first_rule(md);assert target in lhs;records=[]
 for v in rhs:
  f=file(v).resolve();assert f.is_file();records.append({'path':str(f),'sha256':sha(f)})
 # No Release SDK library or object is permitted in this strict profile.
 assert not any('/toolkit-release/'in x['path']for x in records),target
 links[target]={'depfile':str(md),'depfile_sha256':sha(md),'actual_inputs':records,'elf_sha256':sha(out/target)}
readelf=subprocess.check_output(['/usr/bin/readelf','-d',str(out/'dome-sculpt')],text=True);(out/'app-readelf-dynamic.txt').write_text(readelf);assert'libasan.so'in readelf and'libubsan.so'in readelf
assert sha(out/'dome-sculpt')==s['application_sha256']
for name in allowed_generated:
 f=out/name;assert f.is_file();generated[str(f)]=sha(f)
 # A genuine logged generator command names the output and is retained intact.
 writers=[line for line in raw.splitlines()if str(f)in line and ('/usr/bin/wayland-scanner'in line or' -P 'in line)]
 assert len(writers)==1 and writers[0]in log,(name,writers)
response_files={str(f.relative_to(out)):{'sha256':sha(f),'bytes':f.stat().st_size}for f in out.rglob('*.rsp')}
for name,data in [('actual-MD-owners.json',owners),('actual-input-manifest.json',dependencies),('actual-all-archives.json',archives),('actual-link-inputs.json',links),('actual-generated-inputs.json',{'generated':generated,'raw_aliases':aliases,'generation_observation':gen_observation}),('actual-response-files.json',response_files)]:
 (out/name).write_text(json.dumps(data,indent=2)+'\n')
summary={'state':'actual_selected_App_and_fixture_strict_build_audit_passed','source':p['source'],'scope':p['scope'],'owner_count':len(owners),'core_member_count':197,'archive_count':14,'archive_payloads':payloads,'dependency_incidences':incidences,'actual_dependency_paths':len(dependencies),'actual_App_link_inputs':len(links['dome-sculpt']['actual_inputs']),'response_file_count':len(response_files),'application_sha256':sha(out/'dome-sculpt'),'core_archive_sha256':sha(out/'libdome-sculpt-core.a'),'plan_sha256':sha(out/'build-plan.json'),'build_status_sha256':sha(out/'build-status.json'),'audit_driver_sha256':sha(__file__),'input_drift':[],'artifacts':{name:sha(out/name)for name in ['actual-target-commands.txt','actual-MD-owners.json','actual-input-manifest.json','actual-all-archives.json','actual-link-inputs.json','actual-generated-inputs.json','actual-response-files.json','app-readelf-dynamic.txt']}}
(out/'build-audit-status.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
