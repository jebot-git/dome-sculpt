from pathlib import Path
import json,hashlib,tarfile,io
root=Path('/home/blux/de-xr/dome-sculpt/artifacts');dest=root/'current-combined-strict-build-proof-20261118/docs/validation';dest.mkdir(exist_ok=True);sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();files={}
for name in ['authoring-current-combined-sanitize-20261118','authoring-current-sampler-sanitize-20261118']:
 directory=root/name
 for path in directory.iterdir():
  if path.is_file()and(path.suffix in ['.py','.json','.txt','.log']or path.name.endswith('.link.d')):files[str(path.relative_to(root))]=path
 for path in directory.rglob('*.o.d'):files[str(path.relative_to(root))]=path
 for path in directory.rglob('link.d'):files[str(path.relative_to(root))]=path
parent=json.loads((root/'authoring-current-combined-sanitize-20261118/build-audit-status.json').read_text());child=json.loads((root/'authoring-current-sampler-sanitize-20261118/status.json').read_text());assert parent['owner_count']==259 and child['exit']==0
archive=dest/'CURRENT-COMBINED-STRICT-BUILD-20261118-evidence.tar.xz'
with tarfile.open(archive,'w:xz',preset=6)as tar:
 for name,path in sorted(files.items()):
  data=path.read_bytes();item=tarfile.TarInfo(name);item.mode=0o644;item.size=len(data);item.mtime=0;tar.addfile(item,io.BytesIO(data))
receipt={'scope':'Fresh f599 strict App+13fixtures owning compilation and coherent05 sampler child, not runtime/application admission','full_goal_complete':False,'parent_source':parent['source'],'child_source':child['source'],'parent_owner_count':259,'parent_core_members':197,'parent_archives':14,'parent_archive_payloads':219,'parent_application_sha256':parent['application_sha256'],'parent_core_sha256':parent['core_archive_sha256'],'child_fresh_whole_TUs':3,'child_qualified_unchanged_owners':257,'child_fresh_links':15,'child_core_sha256':child['core_sha256'],'child_products':child['products'],'runtime':'not executed by this build/audit task; separate root-owned gate','archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(files)},'archived_authorities':{name:{'actual_path':str(path),'sha256':sha(path),'bytes':path.stat().st_size}for name,path in sorted(files.items())}}
(dest/'CURRENT-COMBINED-STRICT-BUILD-20261118.json').write_text(json.dumps(receipt,indent=2)+'\n');print({'members':len(files),'bytes':archive.stat().st_size,'sha256':sha(archive)})
