"""Fresh complete TUs only. No application, fixture, ldd or runtime execution."""
import hashlib,importlib.util,json,os,resource,shlex,signal,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;J=json.loads((P/'compile-plan.json').read_text());S=Path(J['source']);pins={};state={'state':'preparing','scope':J['scope'],'source':J['commit'],'cwd':J['cwd'],'compiler_environment':J['compiler_environment'],'steps':[],'dependency_owners':[],'exit':1}
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,want=None):
 value=sha(p);key=str(p);assert want is None or value==want,('Input drift',key);assert key not in pins or pins[key]==value,('Conflicting prior input pin',key);pins[key]=value;return value
def save():(P/'compile-status.json').write_text(json.dumps(state,indent=2)+'\n')
def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
def identity(pid):
 try:
  fields=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split();return(int(fields[19]),int(fields[2]))
 except(FileNotFoundError,ProcessLookupError):return None
MONITOR=Path('/home/blux/de-xr/dome-sculpt/artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py')
assert sha(MONITOR)=='b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269'
_spec=importlib.util.spec_from_file_location('qualified_owned_compile_monitor',MONITOR);monitor=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(monitor)
def run(name,cmd):
 row={'name':name,'command':cmd,'cwd':str(P),'compiler_environment':J['compiler_environment'],'started':time.time()};state['steps'].append(row);save()
 with(P/(name+'.log')).open('w')as log:
  child=subprocess.Popen(cmd,cwd=P,env=J['compiler_environment'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);ident=identity(child.pid);row.update(pid=child.pid,identity=ident);save()
  owned=monitor.Owned(child);deadline=time.monotonic()+900
  try:
   while child.poll()is None:
    rss=owned.refresh();row.update(owned.result());save()
    if rss>3*1024**3:raise monitor.BudgetExceeded('Owned compiler aggregate RSS exceeds3GiB')
    if time.monotonic()>deadline:raise monitor.BudgetExceeded('Compiler command exceeds900s')
    time.sleep(.02)
   code=child.wait();owned.refresh();row.update(owned.result())
   assert not[v for v in owned.known.values()if monitor.alive(v)],'Compiler descendants survived actual exit'
  except BaseException as error:
   owned.terminate(str(error));row.update(owned.result());save();raise
 row.update(exit=code,seconds=time.time()-row['started'],log_sha256=sha(P/(name+'.log')));save();print(name,code,flush=True);assert code==0

def dependencies(path):
 text=path.read_text();target,tail=text.replace('\\\n',' ').split(':',1);rows=[]
 for literal in shlex.split(tail):
  f=Path(literal);f=f if f.is_absolute()else P/f;resolved=f.resolve();digest=pin(f);pin(resolved,digest);rows.append({'literal':literal,'absolute_literal':str(f),'resolved':str(resolved),'sha256':digest})
 assert rows;pin(path);return {'target':target.strip(),'path':str(path),'sha256':sha(path),'dependencies':rows}
try:
 assert S.is_dir()and P==Path(J['cwd'])and subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==J['commit']and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 (P/'tmp').mkdir(exist_ok=False);pin(P/'compile-plan.json');pin(Path(__file__).resolve());pin(MONITOR,'b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269');pin(J['closed_current_tool_context']['path'],J['closed_current_tool_context']['sha256'])
 for path,want in J['canonical_command_sources'].items():pin(path,want)
 assert len(J['closed_current_compiler_tools'])==14;state['actual_tools']={}
 for literal,row in J['closed_current_compiler_tools'].items():
  resolved=str(Path(literal).resolve());assert resolved==row['resolved'];pin(literal,row['sha256']);pin(resolved,row['sha256']);state['actual_tools'][literal]={'resolved':resolved,'sha256':row['sha256'],'roles':row['roles']}
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=S,text=True).split('\0'):
  if name and(S/name).is_file():pin(S/name)
 before=[]
 for i,row in enumerate(J['commands']):
  cmd=row['command'];assert '-MD'in cmd and '-MMD'not in cmd and cmd[cmd.index('-MT')+1]==cmd[cmd.index('-o')+1]
  pre=cmd.copy()
  for flag in ['-o','-MF','-MT']:
   at=pre.index(flag);del pre[at:at+2]
  pre.remove('-c');pre.remove('-MD');path=P/(str(i)+'.precheck-all.d');pre+=['-M','-MF',str(path),'-MT','owner.o'];run('preprocess-'+str(i),pre);before.append(dependencies(path))
 for i,row in enumerate(J['commands']):
  run('compile-'+str(i),row['command']);actual=dependencies(Path(row['command'][row['command'].index('-MF')+1]));assert actual['target']==row['command'][row['command'].index('-o')+1]
  pre_rows={x['absolute_literal']:x['sha256']for x in before[i]['dependencies']};actual_rows={x['absolute_literal']:x['sha256']for x in actual['dependencies']};assert pre_rows==actual_rows,('Precheck/actual full dependency roster differs',i)
  state['dependency_owners'].append({'file':row['file'],'precheck':before[i],'actual_compiler':actual,'same_roster':True,'object':row['command'][row['command'].index('-o')+1],'object_sha256':sha(row['command'][row['command'].index('-o')+1])});save()
 state['exit']=0
except BaseException as e:state['error']=repr(e)
finally:
 state['input_drift']=[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h];state['exit']=state['exit']or int(bool(state['input_drift']));state['state']='terminal';(P/'compile-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');save();print(json.dumps({k:state.get(k)for k in ['state','exit','input_drift','error']}),flush=True)
raise SystemExit(state['exit'])
