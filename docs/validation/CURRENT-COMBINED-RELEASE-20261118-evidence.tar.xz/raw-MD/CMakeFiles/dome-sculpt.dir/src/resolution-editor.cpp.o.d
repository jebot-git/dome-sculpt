CMakeFiles/dome-sculpt.dir/src/resolution-editor.cpp.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/src/resolution-editor.cpp \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/src/resolution-editor.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/sculpt-resolution.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/scene.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/affine.hpp \
 /usr/include/c++/16/array /usr/include/c++/16/compare \
 /usr/include/c++/16/bits/version.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++config.h \
 /usr/include/bits/wordsize.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/cpu_defines.h \
 /usr/include/c++/16/pstl/pstl_config.h /usr/include/c++/16/concepts \
 /usr/include/c++/16/type_traits /usr/include/c++/16/initializer_list \
 /usr/include/c++/16/bits/stdexcept_throw.h \
 /usr/include/c++/16/bits/exception_defines.h \
 /usr/include/c++/16/bits/stdexcept_throwfwd.h \
 /usr/include/c++/16/bits/stl_algobase.h \
 /usr/include/c++/16/bits/cpp_type_traits.h \
 /usr/include/c++/16/ext/type_traits.h \
 /usr/include/c++/16/ext/numeric_traits.h \
 /usr/include/c++/16/bits/stl_pair.h /usr/include/c++/16/bits/move.h \
 /usr/include/c++/16/bits/utility.h \
 /usr/include/c++/16/bits/stl_iterator_base_types.h \
 /usr/include/c++/16/bits/iterator_concepts.h \
 /usr/include/c++/16/bits/ptr_traits.h \
 /usr/include/c++/16/bits/ranges_cmp.h \
 /usr/include/c++/16/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/16/bits/concept_check.h \
 /usr/include/c++/16/debug/assertions.h \
 /usr/include/c++/16/bits/stl_iterator.h /usr/include/c++/16/new \
 /usr/include/c++/16/bits/exception.h \
 /usr/include/c++/16/bits/new_except.h \
 /usr/include/c++/16/bits/stl_construct.h \
 /usr/include/c++/16/debug/debug.h \
 /usr/include/c++/16/bits/predefined_ops.h \
 /usr/include/c++/16/bits/stl_function.h \
 /usr/include/c++/16/backward/binders.h /usr/include/c++/16/bit \
 /usr/include/c++/16/bits/range_access.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/deformation.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/avatar.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/rig.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/mesh.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/volume.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/brush.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/math.hpp \
 /usr/include/c++/16/algorithm /usr/include/c++/16/bits/stl_algo.h \
 /usr/include/c++/16/bits/algorithmfwd.h \
 /usr/include/c++/16/bits/stl_heap.h \
 /usr/include/c++/16/bits/uniform_int_dist.h \
 /usr/include/c++/16/bits/stl_tempbuf.h /usr/include/c++/16/cstdlib \
 /usr/include/stdlib.h /usr/include/bits/libc-header-start.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stddef.h \
 /usr/include/bits/waitflags.h /usr/include/bits/waitstatus.h \
 /usr/include/bits/floatn.h /usr/include/bits/floatn-common.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/sys/types.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/time_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-bsearch.h /usr/include/bits/stdlib-float.h \
 /usr/include/c++/16/bits/std_abs.h \
 /usr/include/c++/16/bits/ranges_algo.h \
 /usr/include/c++/16/bits/ranges_algobase.h \
 /usr/include/c++/16/bits/ranges_base.h \
 /usr/include/c++/16/bits/max_size_type.h /usr/include/c++/16/numbers \
 /usr/include/c++/16/limits /usr/include/c++/16/bits/invoke.h \
 /usr/include/c++/16/bits/ranges_util.h \
 /usr/include/c++/16/pstl/glue_algorithm_defs.h \
 /usr/include/c++/16/pstl/execution_defs.h /usr/include/c++/16/cmath \
 /usr/include/c++/16/bits/requires_hosted.h /usr/include/math.h \
 /usr/include/bits/math-vector.h /usr/include/bits/libm-simd-decl-stubs.h \
 /usr/include/bits/flt-eval-method.h /usr/include/bits/fp-logb.h \
 /usr/include/bits/fp-fast.h /usr/include/bits/mathcalls-macros.h \
 /usr/include/bits/mathcalls-helper-functions.h \
 /usr/include/bits/mathcalls.h /usr/include/bits/mathcalls-narrow.h \
 /usr/include/bits/iscanonical.h /usr/include/c++/16/bits/specfun.h \
 /usr/include/c++/16/tr1/gamma.tcc \
 /usr/include/c++/16/tr1/special_function_util.h \
 /usr/include/c++/16/tr1/bessel_function.tcc \
 /usr/include/c++/16/tr1/beta_function.tcc \
 /usr/include/c++/16/tr1/ell_integral.tcc \
 /usr/include/c++/16/tr1/exp_integral.tcc \
 /usr/include/c++/16/tr1/hypergeometric.tcc \
 /usr/include/c++/16/tr1/legendre_function.tcc \
 /usr/include/c++/16/tr1/modified_bessel_func.tcc \
 /usr/include/c++/16/tr1/poly_hermite.tcc \
 /usr/include/c++/16/tr1/poly_laguerre.tcc \
 /usr/include/c++/16/tr1/riemann_zeta.tcc /usr/include/c++/16/cstdint \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-uintn.h /usr/include/bits/stdint-least.h \
 /usr/include/c++/16/stdexcept /usr/include/c++/16/exception \
 /usr/include/c++/16/bits/exception_ptr.h \
 /usr/include/c++/16/bits/cxxabi_init_exception.h \
 /usr/include/c++/16/typeinfo /usr/include/c++/16/bits/hash_bytes.h \
 /usr/include/c++/16/bits/nested_exception.h /usr/include/c++/16/string \
 /usr/include/c++/16/bits/stringfwd.h \
 /usr/include/c++/16/bits/memoryfwd.h \
 /usr/include/c++/16/bits/char_traits.h \
 /usr/include/c++/16/bits/postypes.h /usr/include/c++/16/cwchar \
 /usr/include/wchar.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdarg.h \
 /usr/include/bits/types/wint_t.h /usr/include/bits/types/mbstate_t.h \
 /usr/include/bits/types/__mbstate_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/c++/16/bits/allocator.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++allocator.h \
 /usr/include/c++/16/bits/new_allocator.h \
 /usr/include/c++/16/bits/new_throw.h \
 /usr/include/c++/16/bits/localefwd.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++locale.h \
 /usr/include/c++/16/clocale /usr/include/locale.h \
 /usr/include/bits/locale.h /usr/include/c++/16/iosfwd \
 /usr/include/c++/16/cctype /usr/include/ctype.h \
 /usr/include/c++/16/bits/ostream_insert.h \
 /usr/include/c++/16/bits/cxxabi_forced.h \
 /usr/include/c++/16/bits/erase_if.h \
 /usr/include/c++/16/bits/basic_string.h \
 /usr/include/c++/16/ext/alloc_traits.h \
 /usr/include/c++/16/bits/alloc_traits.h /usr/include/c++/16/string_view \
 /usr/include/c++/16/bits/functional_hash.h \
 /usr/include/c++/16/bits/string_view.tcc \
 /usr/include/c++/16/ext/string_conversions.h /usr/include/c++/16/cstdio \
 /usr/include/stdio.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__fpos64_t.h \
 /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/stdio.h \
 /usr/include/c++/16/cerrno /usr/include/errno.h \
 /usr/include/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h /usr/include/bits/types/error_t.h \
 /usr/include/c++/16/bits/charconv.h \
 /usr/include/c++/16/bits/basic_string.tcc \
 /usr/include/c++/16/bits/memory_resource.h /usr/include/c++/16/cstddef \
 /usr/include/c++/16/bits/uses_allocator.h \
 /usr/include/c++/16/bits/uses_allocator_args.h /usr/include/c++/16/tuple \
 /usr/include/c++/16/bits/stdexcept_except.h /usr/include/c++/16/span \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/cow-map.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/sculpt-storage.hpp \
 /usr/include/c++/16/memory /usr/include/c++/16/bits/stl_uninitialized.h \
 /usr/include/c++/16/bits/stl_raw_storage_iter.h \
 /usr/include/c++/16/bits/align.h /usr/include/c++/16/bits/unique_ptr.h \
 /usr/include/c++/16/bits/ostream.h /usr/include/c++/16/ios \
 /usr/include/c++/16/bits/ios_base.h /usr/include/c++/16/ext/atomicity.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/gthr.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/gthr-default.h \
 /usr/include/pthread.h /usr/include/sched.h /usr/include/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/include/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/include/asm/posix_types.h \
 /usr/include/asm/posix_types_64.h /usr/include/asm-generic/posix_types.h \
 /usr/include/bits/types/struct_sched_param.h /usr/include/bits/cpu-set.h \
 /usr/include/time.h /usr/include/bits/time.h /usr/include/bits/timex.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_itimerspec.h /usr/include/bits/setjmp.h \
 /usr/include/bits/types/struct___jmp_buf_tag.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/atomic_word.h \
 /usr/include/sys/single_threaded.h \
 /usr/include/c++/16/bits/locale_classes.h \
 /usr/include/c++/16/bits/functexcept.h \
 /usr/include/c++/16/bits/locale_classes.tcc \
 /usr/include/c++/16/system_error \
 /usr/include/c++/16/x86_64-redhat-linux/bits/error_constants.h \
 /usr/include/c++/16/streambuf /usr/include/c++/16/bits/streambuf.tcc \
 /usr/include/c++/16/bits/basic_ios.h \
 /usr/include/c++/16/bits/locale_facets.h /usr/include/c++/16/cwctype \
 /usr/include/wctype.h /usr/include/bits/wctype-wchar.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/ctype_base.h \
 /usr/include/c++/16/bits/streambuf_iterator.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/ctype_inline.h \
 /usr/include/c++/16/bits/locale_facets.tcc \
 /usr/include/c++/16/bits/basic_ios.tcc \
 /usr/include/c++/16/bits/shared_ptr.h \
 /usr/include/c++/16/bits/shared_ptr_base.h \
 /usr/include/c++/16/bits/allocated_ptr.h \
 /usr/include/c++/16/bits/refwrap.h \
 /usr/include/c++/16/ext/aligned_buffer.h \
 /usr/include/c++/16/ext/concurrence.h \
 /usr/include/c++/16/bits/shared_ptr_atomic.h \
 /usr/include/c++/16/bits/atomic_base.h \
 /usr/include/c++/16/bits/atomic_lockfree_defines.h \
 /usr/include/c++/16/bits/atomic_wait.h \
 /usr/include/c++/16/backward/auto_ptr.h \
 /usr/include/c++/16/bits/ranges_uninitialized.h \
 /usr/include/c++/16/pstl/glue_memory_defs.h /usr/include/c++/16/iterator \
 /usr/include/c++/16/bits/stream_iterator.h /usr/include/c++/16/map \
 /usr/include/c++/16/bits/stl_tree.h \
 /usr/include/c++/16/bits/node_handle.h \
 /usr/include/c++/16/bits/stl_map.h \
 /usr/include/c++/16/bits/stl_multimap.h /usr/include/c++/16/optional \
 /usr/include/c++/16/bits/enable_special_members.h \
 /usr/include/c++/16/unordered_map \
 /usr/include/c++/16/bits/unordered_map.h \
 /usr/include/c++/16/bits/hashtable.h \
 /usr/include/c++/16/bits/hashtable_policy.h /usr/include/c++/16/vector \
 /usr/include/c++/16/bits/stl_vector.h \
 /usr/include/c++/16/bits/stl_bvector.h \
 /usr/include/c++/16/bits/vector.tcc /usr/include/c++/16/deque \
 /usr/include/c++/16/bits/stl_deque.h /usr/include/c++/16/bits/deque.tcc \
 /usr/include/c++/16/filesystem /usr/include/c++/16/bits/fs_fwd.h \
 /usr/include/c++/16/bits/chrono.h /usr/include/c++/16/ratio \
 /usr/include/c++/16/ctime /usr/include/c++/16/bits/parse_numbers.h \
 /usr/include/c++/16/bits/fs_path.h /usr/include/c++/16/locale \
 /usr/include/c++/16/bits/locale_facets_nonio.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/time_members.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/messages_members.h \
 /usr/include/libintl.h /usr/include/c++/16/bits/codecvt.h \
 /usr/include/c++/16/bits/locale_facets_nonio.tcc \
 /usr/include/c++/16/bits/locale_conv.h /usr/include/c++/16/iomanip \
 /usr/include/c++/16/bits/quoted_string.h /usr/include/c++/16/sstream \
 /usr/include/c++/16/istream /usr/include/c++/16/ostream \
 /usr/include/c++/16/bits/ostream_print.h \
 /usr/include/c++/16/bits/ostream.tcc \
 /usr/include/c++/16/bits/istream.tcc \
 /usr/include/c++/16/bits/sstream.tcc /usr/include/c++/16/codecvt \
 /usr/include/c++/16/bits/fs_dir.h /usr/include/c++/16/bits/fs_ops.h \
 /usr/include/c++/16/functional /usr/include/c++/16/bits/std_function.h \
 /usr/include/c++/16/bits/binders.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/third_party/nlohmann/nlohmann/json_fwd.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/groups.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/navigation.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/third_party/openbrush/navigation.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/third_party/openbrush/brush-math.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/paint.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/emission.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/baked-emission.hpp \
 /usr/include/c++/16/utility /usr/include/c++/16/bits/stl_relops.h \
 /usr/include/c++/16/bits/intcmp.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/paint-blur.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/include/dome/mesh-processing.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/src/resolution-ui-values.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/third_party/desktop/appearance.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Text_Display.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_config.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Export.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/platform_types.h \
 /usr/include/dirent.h /usr/include/bits/dirent.h \
 /usr/include/bits/posix1_lim.h /usr/include/bits/local_lim.h \
 /usr/include/linux/limits.h /usr/include/bits/dirent_ext.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_casts.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Cairo.H \
 /usr/include/cairo/cairo.h /usr/include/cairo/cairo-version.h \
 /usr/include/cairo/cairo-features.h \
 /usr/include/cairo/cairo-deprecated.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_utf8.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Export.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_types.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_attr.h \
 /usr/include/sys/stat.h /usr/include/bits/stat.h \
 /usr/include/bits/struct_stat.h /usr/include/bits/statx.h \
 /usr/include/linux/stat.h /usr/include/bits/statx-generic.h \
 /usr/include/bits/types/struct_statx_timestamp.h \
 /usr/include/bits/types/struct_statx.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Enumerations.H \
 /usr/include/string.h /usr/include/strings.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_draw.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Enumerations.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Graphics_Driver.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Device.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Plugin.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Preferences.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Image.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Widget.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Bitmap.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Image.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Pixmap.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_RGB_Image.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Rect.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Widget.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Group.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Scrollbar.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Slider.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Valuator.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Text_Buffer.H \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/third_party/desktop/bdf_font.hpp \
 /usr/include/fontconfig/fontconfig.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/limits.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/posix2_lim.h \
 /usr/include/bits/xopen_lim.h /usr/include/bits/uio_lim.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/ft2build.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/ftheader.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/freetype.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/ftconfig.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/ftoption.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/ftstdlib.h \
 /usr/include/c++/16/stdlib.h /usr/include/setjmp.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/integer-types.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/public-macros.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/config/mac-support.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/fttypes.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/ftsystem.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/ftimage.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/fterrors.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/ftmoderr.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/fterrdef.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/ftfntfmt.h \
 /opt/fltk-vr/bdf-runtime/include/freetype2/freetype/ftbdf.h \
 /usr/include/zlib.h /usr/include/zconf.h \
 /usr/include/zlib_name_mangling.h /usr/include/unistd.h \
 /usr/include/bits/posix_opt.h /usr/include/bits/environments.h \
 /usr/include/bits/confname.h /usr/include/bits/getopt_posix.h \
 /usr/include/bits/getopt_core.h /usr/include/bits/unistd_ext.h \
 /usr/include/linux/close_range.h /usr/include/c++/16/chrono \
 /usr/include/c++/16/bits/chrono_io.h /usr/include/c++/16/format \
 /usr/include/c++/16/charconv /usr/include/c++/16/bits/monostate.h \
 /usr/include/c++/16/bits/formatfwd.h /usr/include/c++/16/bits/unicode.h \
 /usr/include/c++/16/bits/unicode-data.h /usr/include/c++/16/cstring \
 /usr/include/c++/16/fstream \
 /usr/include/c++/16/x86_64-redhat-linux/bits/basic_file.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++io.h \
 /usr/include/c++/16/bits/fstream.tcc /usr/include/c++/16/set \
 /usr/include/c++/16/bits/stl_set.h \
 /usr/include/c++/16/bits/stl_multiset.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Browser_.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Choice.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Menu_.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Menu_Item.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Multi_Label.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Group.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Image_Surface.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Widget_Surface.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Window.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Shared_Image.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Input_.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Menu_.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Tooltip.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Value_Input.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Input.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Input_.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_ask.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_attr.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_draw.H \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/third_party/nlohmann/nlohmann/json.hpp \
 /usr/include/c++/16/forward_list /usr/include/c++/16/bits/forward_list.h \
 /usr/include/c++/16/bits/forward_list.tcc /usr/include/c++/16/valarray \
 /usr/include/c++/16/bits/valarray_array.h \
 /usr/include/c++/16/bits/valarray_array.tcc \
 /usr/include/c++/16/bits/valarray_before.h \
 /usr/include/c++/16/bits/slice_array.h \
 /usr/include/c++/16/bits/valarray_after.h \
 /usr/include/c++/16/bits/gslice.h \
 /usr/include/c++/16/bits/gslice_array.h \
 /usr/include/c++/16/bits/mask_array.h \
 /usr/include/c++/16/bits/indirect_array.h /usr/include/c++/16/version \
 /usr/include/c++/16/cassert /usr/include/assert.h \
 /usr/include/c++/16/ranges /usr/include/c++/16/numeric \
 /usr/include/c++/16/bits/stl_numeric.h \
 /usr/include/c++/16/pstl/glue_numeric_defs.h /usr/include/c++/16/any \
 /usr/include/spawn.h /usr/include/bits/spawn_ext.h \
 /usr/include/sys/wait.h /usr/include/signal.h \
 /usr/include/bits/signum-generic.h /usr/include/bits/signum-arch.h \
 /usr/include/bits/types/sig_atomic_t.h \
 /usr/include/bits/types/siginfo_t.h /usr/include/bits/types/__sigval_t.h \
 /usr/include/bits/siginfo-arch.h /usr/include/bits/siginfo-consts.h \
 /usr/include/bits/siginfo-consts-arch.h \
 /usr/include/bits/types/sigval_t.h /usr/include/bits/types/sigevent_t.h \
 /usr/include/bits/sigevent-consts.h /usr/include/bits/sigaction.h \
 /usr/include/bits/sigcontext.h /usr/include/bits/types/stack_t.h \
 /usr/include/sys/ucontext.h /usr/include/bits/sigstack.h \
 /usr/include/bits/sigstksz.h /usr/include/bits/ss_flags.h \
 /usr/include/bits/types/struct_sigstack.h /usr/include/bits/sigthread.h \
 /usr/include/bits/signal_ext.h /usr/include/bits/types/idtype_t.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/src/ui-conventions.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Button.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Double_Window.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Window.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Box.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Check_Button.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Light_Button.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Button.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Scroll.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Slider.H
