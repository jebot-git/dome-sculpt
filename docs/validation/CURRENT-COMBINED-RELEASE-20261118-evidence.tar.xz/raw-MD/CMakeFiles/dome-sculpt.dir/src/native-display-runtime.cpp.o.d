CMakeFiles/dome-sculpt.dir/src/native-display-runtime.cpp.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/src/native-display-runtime.cpp \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-current-integration-20261118/src/native-display-runtime.hpp \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/platform.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Export.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/platform_types.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_config.h \
 /usr/include/time.h /usr/include/features.h \
 /usr/include/features-time64.h /usr/include/bits/wordsize.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stddef.h \
 /usr/include/bits/time.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/timex.h /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/dirent.h /usr/include/bits/dirent.h \
 /usr/include/bits/posix1_lim.h /usr/include/bits/local_lim.h \
 /usr/include/linux/limits.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/dirent_ext.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_types.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_attr.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/wayland.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/x11.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Enumerations.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/Fl_Export.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/include/FL/fl_types.h \
 /usr/include/X11/Xlib.h /usr/include/sys/types.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/X11/X.h \
 /usr/include/X11/Xfuncproto.h /usr/include/X11/Xosdefs.h \
 /usr/include/X11/Xutil.h /usr/include/X11/keysym.h \
 /usr/include/X11/keysymdef.h /usr/include/X11/Xatom.h
