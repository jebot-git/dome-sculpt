#define main existing_mtoon_test
#include "mtoon-render.cpp"
#undef main
#include "dome/document.hpp"
#include "dome/vrm-expression.hpp"
#include "independent-unlit-consumer.hpp"
#include <fstream>
using J=nlohmann::json;

namespace {
struct LiveWeights {float happy, alternate;};
struct Applied {
  std::map<size_t,std::vector<float>> node_morphs;
  std::vector<std::tuple<cgltf_node*,float*,size_t>> original;
  ~Applied(){
    for(auto &[node,weights,count]:original){node->weights=weights;node->weights_count=count;}
  }
};

void apply(color_consumer::Model &model, Applied &applied, LiveWeights weights, bool fixed_uv, bool source_alpha, bool ignore_cutoff, bool flip_basis) {
  const auto &defs=model.json.at("extensions").at("VRMC_vrm").at("expressions");
  const auto &happy=defs.at("preset").at("happy");
  const auto &alternate=defs.at("custom").at("alternate");
  const std::array<std::pair<const J*,float>,2> live{{{&happy,weights.happy},{&alternate,weights.alternate}}};
  const auto node_id=happy.at("morphTargetBinds")[0].at("node").get<size_t>();
  for(size_t i=0;i<model.data->nodes_count;++i)
    if(i!=node_id)model.data->nodes[i].mesh=nullptr;
  if(flip_basis){
    auto &role=model.data->nodes[node_id].mesh->primitives[0].material->pbr_metallic_roughness.base_color_texture;
    role.transform.rotation+=3.14159265358979323846f;
    for(auto &scale:role.transform.scale)scale=-scale;
  }
  const auto baseline=std::vector<cgltf_material>(model.data->materials,model.data->materials+model.data->materials_count);
  for(const auto &[entry,weight]:live)
    for(const auto &m:entry->value("morphTargetBinds",J::array())){
      const size_t node=m.at("node"), index=m.at("index");
      auto &target=model.data->nodes[node];
      auto [found,inserted]=applied.node_morphs.try_emplace(node);
      if(inserted){
        applied.original.emplace_back(&target,target.weights,target.weights_count);
        if(target.weights_count)found->second.assign(target.weights,target.weights+target.weights_count);
        else found->second.assign(target.mesh->weights,target.mesh->weights+target.mesh->weights_count);
        target.weights=found->second.data();
        target.weights_count=found->second.size();
      }
      found->second.at(index)=0;
    }
  for(const auto &[entry,weight]:live){
    for(const auto &b:entry->value("materialColorBinds",J::array())){
      if(b.at("type")!="color")continue;
      const size_t material=b.at("material");
      const auto &start=baseline.at(material).pbr_metallic_roughness;
      auto &next=model.data->materials[material].pbr_metallic_roughness;
      for(size_t k=0;k<4;++k)
        next.base_color_factor[k]+=weight*(b.at("targetValue")[k].get<float>()-start.base_color_factor[k]);
    }
    if(!fixed_uv)for(const auto &b:entry->value("textureTransformBinds",J::array())){
      const size_t material=b.at("material");
      const auto &start=baseline.at(material).pbr_metallic_roughness.base_color_texture;
      auto &next=model.data->materials[material].pbr_metallic_roughness.base_color_texture;
      if(!next.has_transform)throw std::runtime_error("Independent source fixture lacks authored transform");
      const auto offset=b.value("offset",std::array<float,2>{}),scale=b.value("scale",std::array<float,2>{1,1});
      for(size_t k=0;k<2;++k){
        next.transform.offset[k]+=weight*(offset[k]-start.transform.offset[k]);
        next.transform.scale[k]+=weight*(scale[k]-start.transform.scale[k]);
      }
    }
    for(const auto &b:entry->value("morphTargetBinds",J::array())){
      const size_t node=b.at("node"),index=b.at("index");
      applied.node_morphs.at(node).at(index)+=weight*b.at("weight").get<float>();
    }
  }
  auto &m=*model.data->nodes[node_id].mesh;
  if(ignore_cutoff)m.primitives[0].material->alpha_mode=cgltf_alpha_mode_opaque;
  if(source_alpha){
    auto a=cgltf_find_accessor(&m.primitives[0],cgltf_attribute_type_color,0);
    for(size_t i=0;i<m.primitives[1].attributes_count;++i){
      auto &v=m.primitives[1].attributes[i];
      if(v.type==cgltf_attribute_type_color&&v.index==0)v.data=const_cast<cgltf_accessor*>(a);
    }
  }
}
}
int main(int argc,char **argv)try{
  if(argc!=2)return 2;
  const std::filesystem::path data=argv[1];
  NativeGraphics graphics;
  std::cout<<"GPU "<<reinterpret_cast<const char*>(glGetString(GL_RENDERER))<<'\n';
  Fbo framebuffer;
  SurfaceRenderer native;
  color_consumer::Renderer independent;
  auto baseline=Scene::load(data/"unlit-mask-preserved.dsculpt");
  const auto selected=baseline.active().id;
  for(const auto &o:baseline.objects())if(o.id!=selected)baseline.object(o.id).visible=false;
  for(auto weights:{LiveWeights{0,0},LiveWeights{.35f,0},LiveWeights{1,0},LiveWeights{0,1},LiveWeights{.28f,.62f}}){
    Vrm1ExpressionWeights request;
    request.preset["happy"]=weights.happy;
    request.custom["alternate"]=weights.alternate;
    auto posed=bake_vrm1_expression_pose(baseline,selected,request);
    Document doc;doc.replace(std::move(posed));
    check(doc.wait_mesh()&&doc.frame().state->error.empty(),"Native expression mesh publishes");
    framebuffer.bind();
    const auto want=draw(native,doc.frame().surface);
    auto compare=[&](bool fixed_uv,bool source_alpha,bool ignore_cutoff=false,bool flip_basis=false){
      color_consumer::Model model(data/"unlit-mask-output.vrm");
      Applied active;
      apply(model,active,weights,fixed_uv,source_alpha,ignore_cutoff,flip_basis);
      framebuffer.bind();
      independent.render(model.data);
      return read();
    };
    const auto actual=compare(false,false);
    size_t covered=0,rgb_error=0,alpha_error=0;
    for(size_t i=0;i<actual.size();i+=4){
      covered+=want[i+3]>0;
      for(size_t k=0;k<3;++k)rgb_error=std::max(rgb_error,size_t(std::abs(int(want[i+k])-int(actual[i+k]))));
      alpha_error=std::max(alpha_error,size_t(std::abs(int(want[i+3])-int(actual[i+3]))));
    }
    std::cout<<"unlit happy="<<weights.happy<<" alternate="<<weights.alternate<<" covered="<<covered<<" rgb="<<rgb_error<<" alpha="<<alpha_error<<'\n';
    check(covered>=50&&rgb_error<=4&&alpha_error<=1,"Independent portable unlit matches native active expression pixels");
    const auto without_cutoff=compare(false,false,true);
    size_t removed=0;
    for(size_t i=3;i<actual.size();i+=4)removed+=(!actual[i]&&without_cutoff[i]);
    std::cout<<"actual cutout pixels="<<removed<<'\n';
    check(removed>=4,"Rendering detects the real source cutout outside the fixed paint footprint");
    if(weights.alternate==1){
      const auto wrong_uv=delta(actual,compare(true,false));
      const auto wrong_alpha=delta(actual,compare(false,true));
      std::cout<<"sensitivity wrong_uv="<<wrong_uv<<" wrong_alpha="<<wrong_alpha<<'\n';
      check(wrong_uv>=8&&wrong_alpha>=8,"Actual pixels detect frozen source UV and wrongly attenuated paint");
      const auto wrong_basis=delta(actual,compare(false,false,false,true));
      std::cout<<"sensitivity flipped signed-scale basis="<<wrong_basis<<'\n';
      check(wrong_basis>=8,"A matrix-equivalent rest decomposition yields visibly wrong live UV sampling");
    }
  }
  return 0;
}catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
