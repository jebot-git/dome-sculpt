import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

folder = Path(__file__).resolve().parent
profile = sys.argv[1]
hardware = profile == "arc"
if hardware:
    lock = open("/tmp/dome-sculpt-arc-device.lock", "rb")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
status = {}
for case in ["unlit-render"]:
    suffix = "-asan" if profile == "asan" else ""
    output = folder / (case + "-" + profile + "-final")
    output.mkdir(mode=0o700, exist_ok=False)
    binary = folder / (case + suffix)
    args = ["bwrap", "--die-with-parent", "--unshare-all", "--ro-bind", "/", "/", "--bind", output, output,
            "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp", "--tmpfs", "/run/user", "--clearenv"]
    variables = {"PATH": "/usr/bin:/bin", "HOME": "/tmp", "XDG_CACHE_HOME": "/tmp/mesa",
                 "LP_NUM_THREADS": "2", "LC_ALL": "C", "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=1",
                 "ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1"}
    if hardware:
        args.extend(["--dev-bind", "/dev/dri/renderD129", "/dev/dri/renderD129"])
        variables["DRI_PRIME"] = "pci-0000_03_00_0"
        variables["MESA_SHADER_CACHE_DISABLE"] = "1"
    else:
        variables["LIBGL_ALWAYS_SOFTWARE"] = "1"
    for key, value in variables.items():
        args.extend(["--setenv", key, value])
    args.extend([binary, folder / "release-final/output"])
    def process_tree(pid):
        yield pid
        try:
            children = Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
        except (FileNotFoundError, ProcessLookupError):
            return
        for child in children:
            yield from process_tree(int(child))
    witnesses = set()
    start = time.monotonic()
    with (output / "run.log").open("wb") as log:
        proc = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, cwd=output)
        while proc.poll() is None:
            if hardware:
                for pid in process_tree(proc.pid):
                    try:
                        if Path(f"/proc/{pid}/exe").resolve().name != binary.name:
                            continue
                        for fd in Path(f"/proc/{pid}/fd").iterdir():
                            try:
                                if os.readlink(fd) == "/dev/dri/renderD129":
                                    witnesses.add((pid, int(fd.name)))
                            except FileNotFoundError:
                                pass
                    except (FileNotFoundError, ProcessLookupError):
                        pass
            if time.monotonic() - start > 300:
                proc.terminate()
                proc.wait(timeout=10)
                break
            time.sleep(.2)
    lines = (output / "run.log").read_text().splitlines()
    status[case] = {"exit": proc.returncode, "seconds": round(time.monotonic() - start, 3),
                    "checks": sum(line.startswith("PASS ") for line in lines),
                    "gpu": next((line for line in lines if line.startswith("GPU ")), ""),
                    "device_witnesses": sorted(witnesses)}
    print(profile, case, status[case], flush=True)
    if proc.returncode or (hardware and not witnesses):
        break
(folder / (profile + "-graphics-status.json")).write_text(json.dumps(status, indent=2) + "\n")
sys.exit(len(status) != 1 or any(s["exit"] or (hardware and not s["device_witnesses"]) for s in status.values()))
