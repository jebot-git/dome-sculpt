import json
from pathlib import Path
import shlex
import subprocess
out=Path(__file__).resolve().parent
artifacts=out.parent
source=artifacts/"vrm1-unlit-mask-paint-source-20261126"
build=artifacts/"vrm-consumer-combined-20261126"
entry=next(x for x in json.loads((build/"compile_commands.json").read_text())
           if x["file"].endswith("/tests/source-color-vrm-consumer.cpp"))
old=Path(entry["file"]).parents[1]
cmd=[x.replace(str(old),str(source)) for x in shlex.split(entry["command"])]
obj=out/"unlit-render-proof.o"
cmd[cmd.index("-o")+1]=str(obj)
cmd[cmd.index("-c")+1]=str(out/"unlit-render-proof.cpp")
cmd.extend(["-I"+str(source/"tests"),"-I"+str(out)])
subprocess.run(cmd,cwd=build,check=True)
target="dome-sculpt-source-color-vrm-test"
raw=subprocess.check_output(["ninja","-t","commands",target],text=True,cwd=build).splitlines()[-1]
cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith("-Wl,--dependency-file=")]
cmd[cmd.index("-o")+1]=str(out/"unlit-render")
cmd[next(i for i,x in enumerate(cmd) if x.endswith("/source-color-vrm-consumer.cpp.o"))]=str(obj)
cmd[cmd.index("libdome-sculpt-core.a")]=str(out/"release-final/libdome-sculpt-core.a")
subprocess.run(cmd,cwd=build,check=True)
