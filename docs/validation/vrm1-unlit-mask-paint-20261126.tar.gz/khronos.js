const fs = require('fs');
const path = require('path');
const validator = require('../hdr-khronos-validation-20261126/module/package');

async function main() {
  const profile = path.join(__dirname, 'release-final');
  for (const name of ['unlit-mask-input.vrm', 'unlit-mask-output.vrm']) {
    const bytes = fs.readFileSync(path.join(profile, 'output', name));
    const report = await validator.validateBytes(new Uint8Array(bytes), {uri: name, maxIssues: 0});
    fs.writeFileSync(path.join(profile, name + '.khronos.json'), JSON.stringify(report, null, 2) + '\n');
    const {numErrors, numWarnings} = report.issues;
    console.log(name, report.validatorVersion, numErrors, numWarnings);
    if (numErrors) process.exitCode = 1;
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
