from pathlib import Path
import json
import os
import subprocess
import time

base=Path(__file__).resolve().parent
source=base.parent/"vrm1-unlit-mask-paint-source-20261126"
build=base/"combined-release"
build.mkdir(mode=0o700,exist_ok=False)
candidate="e09f2f4bcb9c35198cbb9a6168ae3403a95263ff"
status={"candidate":candidate,"invocation":os.getenv("INVOCATION_ID"),"terminal":False}
start=time.monotonic()

def report(**fields):
    status.update(fields, seconds=round(time.monotonic()-start,2))
    temporary=build/"status.tmp"
    temporary.write_text(json.dumps(status,indent=2)+"\n")
    temporary.replace(build/"status.json")

def frozen():
    def git(*args):
        return subprocess.check_output(["git","-C",source,*args],text=True).strip()
    return git("rev-parse","HEAD")==candidate and not git("status","--porcelain")

def run(name, command):
    report(phase=name)
    with (build/(name+".log")).open("w") as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    report(**{name+"_exit":result.returncode})
    if result.returncode or not frozen():
        code=result.returncode or 125
        report(terminal=True,exit=code)
        raise SystemExit(code)

report(phase="preflight")
assert frozen()
os.environ["PKG_CONFIG_PATH"]="/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig"
os.environ["LD_LIBRARY_PATH"]="/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
run("configure",["cmake","-G","Ninja","-S",source,"-B",build,"-DCMAKE_BUILD_TYPE=Release",
                 "-DDOME_COMPUTE_BACKEND=CPU","-DFLTK_DIR=/opt/fltk-vr/toolkit/share/fltk",
                 "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON"])
targets=["dome-sculpt","dome-sculpt-vrm1-expressions-test",
         "dome-sculpt-vrm1-expression-layer-authoring-test","dome-sculpt-vrm1-mask-support-faults-test",
         "dome-sculpt-xr-fixture-clock-test","dome-sculpt-test-runtime"]
known={row.split(":")[0] for row in subprocess.check_output(["ninja","-C",build,"-t","targets","all"],text=True).splitlines()}
missing=set(targets)-known
if missing:
    report(terminal=True,exit=1,missing=sorted(missing))
    raise SystemExit(1)
run("build",["cmake","--build",build,"--parallel","4","--target",*targets])
run("version",[build/"dome-sculpt","--version"])
report(phase="application ready for native/XR tests",terminal=True,exit=0)
