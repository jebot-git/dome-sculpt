from pathlib import Path
import os
import subprocess
import sys

folder = Path(__file__).resolve().parent
profile = sys.argv[1]
run = folder / profile
fixture = folder.parent / "production-full-regression-release-20261126/vrm1-background-fixture/source.vrm"
assert (run / "vrm1-expressions").exists()

def execute(executable, output, log, *arguments):
    output.mkdir(mode=0o700, exist_ok=True)
    command = ["bwrap", "--die-with-parent", "--unshare-all", "--ro-bind", "/", "/",
               "--bind", output, output, "--proc", "/proc", "--dev", "/dev",
               "--tmpfs", "/tmp", "--tmpfs", "/run/user", "--clearenv",
               "--setenv", "PATH", "/usr/bin:/bin", "--setenv", "HOME", "/tmp",
               "--setenv", "ASAN_OPTIONS", "detect_leaks=1:halt_on_error=1",
               "--setenv", "UBSAN_OPTIONS", "halt_on_error=1:print_stacktrace=1",
               run / executable, *arguments]
    with (run / log).open("w") as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    print(profile, executable, result.returncode, flush=True)
    return result.returncode

output = run / "output"
mtoon = run / "mtoon-mask"
mode = sys.argv[2] if len(sys.argv)>2 else "native"
if mode == "faults":
    sys.exit(execute("vrm1-mask-support-faults", mtoon, "mtoon-faults.log",
                     mtoon / "nonuniform-source.dsculpt"))
if mode == "controls":
    sys.exit(execute("vrm1-mask-support-faults", mtoon, "mtoon-control.log",
                     mtoon / "nonuniform-source.dsculpt", "--controls-only"))
if mode == "fixtures":
    sys.exit(execute("vrm1-expression-layer-authoring", mtoon, "mtoon-mask.log",
                     fixture, mtoon, "--positive", "--mask-local-cutouts"))
sys.exit(execute("vrm1-expressions", output, "run.log", output))
