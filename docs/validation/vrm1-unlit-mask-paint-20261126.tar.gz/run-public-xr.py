from pathlib import Path
import json
import os
import subprocess
import time

base=Path(__file__).resolve().parent
source=base.parent/"vrm1-unlit-mask-paint-source-20261126"
build=base/"combined-release"
out=base/"public-xr"
out.mkdir(mode=0o700)
invocation=os.getenv("INVOCATION_ID")
compiled=json.loads((build/"status.json").read_text())
status={"candidate":compiled["candidate"],"invocation":invocation,"terminal":False}
start=time.monotonic()

def update(**fields):
    status.update(fields,seconds=round(time.monotonic()-start,2))
    temporary=out/"status.tmp"
    temporary.write_text(json.dumps(status,indent=2)+"\n")
    temporary.replace(out/"status.json")

def run(phase,command):
    update(phase=phase)
    with (out/(phase+".log")).open("w") as log:
        result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    update(**{phase+"_exit":result.returncode})
    if result.returncode:
        update(terminal=True,exit=result.returncode)
        raise SystemExit(result.returncode)

update(phase="waiting for matching optimized build")
parent="ds-vrm1-mask-combined-release-20261126.service"
deadline=time.monotonic()+1800
while not compiled["terminal"]:
    active=subprocess.run(["systemctl","--user","is-active","--quiet",parent]).returncode
    if active or time.monotonic()>=deadline:
        update(phase="matching build did not complete",terminal=True,exit=1)
        raise SystemExit(1)
    time.sleep(3)
    compiled=json.loads((build/"status.json").read_text())
if compiled.get("exit")!=0:
    update(phase="matching optimized build prerequisite",terminal=True,exit=1)
    raise SystemExit(1)
for label in ("dome-sculpt","libdome-sculpt-test-runtime.so"):
    assert (build/label).exists()
toolkit="/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
os.environ["LD_LIBRARY_PATH"]=toolkit
run("support-build",["cmake","--build",build,"--parallel","2","--target",
    "dome-sculpt-vrm1-editable-ui-test","dome-sculpt-export-cancel-gate"])
helper=build/"dome-sculpt-vrm1-editable-ui-test"
run("fixture",[helper,"--fixture",base/"release-final/output/unlit-mask-output.vrm",
               out/"mask-avatar.dsculpt"])
run("loader",["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/",
    "--bind",out,out,"--proc","/proc","--dev","/dev","--tmpfs","/tmp","--tmpfs","/run/user","--clearenv",
    "--setenv","PATH","/usr/bin:/bin","--setenv","HOME","/tmp","--setenv","LD_LIBRARY_PATH",toolkit,
    "--setenv","XDG_CACHE_HOME",out/"cache",
    "/usr/bin/python3",source/"tests/vrm1-editable-xr.py",
    build/"dome-sculpt",build/"libdome-sculpt-test-runtime.so",
    helper,out/"mask-avatar.dsculpt", build/"libdome-sculpt-export-cancel-gate.so",
    out/"workflow"])
update(phase="complete",terminal=True,exit=0)
