import pathlib,json,hashlib,os,fcntl,time,subprocess,re
out=pathlib.Path(__file__).resolve().parent
prior=out.parent/'authoring-canonical-public-release-20261118/loader-version-status.json'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
old=json.loads(prior.read_text());audit=json.loads((out/'build-audit-status.json').read_text())
assert audit['state']=='actual_whole_App_build_audit_passed'
assert sha(out/'dome-sculpt')==audit['application_sha256']
for p in old['providers']:
 assert str(pathlib.Path(p['literal']).resolve())==p['resolved'] and sha(p['resolved'])==p['sha256'],p
lease=pathlib.Path('/tmp/dome-sculpt-arc-device.lock');fd=os.open(lease,os.O_RDWR|os.O_NOFOLLOW)
st=os.fstat(fd);assert (st.st_ino,st.st_dev)==(old['lease_inode'],old['lease_dev'])
try:fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
except BlockingIOError:
 os.close(fd);raise SystemExit('Device lease busy: no product executed and no lease reserved')
state={'state':'running','source':audit['source'],'application_sha256':audit['application_sha256'],'prior_provider_status_sha256':sha(prior),'steps':[],'lease_acquired':time.time(),'lease_inode':st.st_ino,'lease_dev':st.st_dev,'driver_sha256':sha(__file__)}
def save():(out/'loader-version-status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 env=os.environ.copy()
 for k in ['LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','LD_AUDIT']:env.pop(k,None)
 env['LD_LIBRARY_PATH']=str(out.parent/'sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'
 providers=[]
 for name,args in [('ldd',['/usr/bin/ldd',str(out/'dome-sculpt')]),('version',[str(out/'dome-sculpt'),'--version'])]:
  started=time.monotonic();p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
  log=out/('loader-'+name+'.log');log.write_bytes(p.stdout)
  state['steps'].append({'name':name,'argv':args,'exit':p.returncode,'seconds':time.monotonic()-started,'log_sha256':sha(log)});save()
  assert p.returncode==0,(name,p.returncode)
  if name=='ldd':
   assert b'not found' not in p.stdout
   for line in p.stdout.decode().splitlines():
    m=re.search(r'=>\s+(/\S+)',line) or re.match(r'\s*(/\S+)\s+\(',line)
    if m:
     literal=m.group(1);resolved=str(pathlib.Path(literal).resolve());providers.append({'literal':literal,'resolved':resolved,'sha256':sha(resolved)})
   assert {x['resolved']:x['sha256'] for x in providers}=={x['resolved']:x['sha256'] for x in old['providers']},'Actual loader providers differ from original72; investigate'
   assert len(providers)==len(old['providers'])==72
   state['providers']=providers
  else:
   state['version_stdout']=p.stdout.decode();assert state['version_stdout']==old['version_stdout']+'\n' # Prior metadata stored a stripped line; preserve and compare the actual terminal LF.
 state['exit']=0
except BaseException as error:state.update(exit=1,error=repr(error))
finally:
 fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd);state['lease_released']=time.time();state['state']='terminal'
 check=os.open(lease,os.O_RDWR|os.O_NOFOLLOW)
 try:
  fcntl.flock(check,fcntl.LOCK_EX|fcntl.LOCK_NB);state['independent_NB_free']={'time':time.time(),'inode':os.fstat(check).st_ino,'dev':os.fstat(check).st_dev};fcntl.flock(check,fcntl.LOCK_UN)
 except BlockingIOError:state['independent_NB_free']=False
 finally:os.close(check)
 save()
print(json.dumps({k:v for k,v in state.items() if k not in ('providers',)},indent=2));raise SystemExit(state['exit'])
