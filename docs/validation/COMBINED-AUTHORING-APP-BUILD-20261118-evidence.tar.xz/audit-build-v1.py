import pathlib,hashlib,json,subprocess,shlex,re,collections
out=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
state=json.loads((out/'build-status.json').read_text())
if state.get('state')!='terminal' or state.get('exit')!=0:
 raise SystemExit('Actual whole-App build is not successfully terminal; no audit acceptance')
plan=json.loads((out/'build-plan.json').read_text())
assert not state['input_drift']
drift=[p for p,h in plan['source_input_pins'].items() if not pathlib.Path(p).is_file() or sha(p)!=h]
assert not drift,drift
raw=subprocess.check_output(['/usr/bin/ninja','-C',str(out),'-t','commands','dome-sculpt'],text=True)
(out/'actual-target-commands.txt').write_text(raw)
commands=[]
for line in raw.splitlines():
 argv=shlex.split(line)
 if '-c' in argv and '-o' in argv:
  commands.append({'object':argv[argv.index('-o')+1],'source':argv[argv.index('-c')+1],'command':line})
expected={x['object']:x for x in commands};assert len(expected)==len(commands)
cc=json.loads((out/'compile_commands.json').read_text());cc_by_output={x['output']:x for x in cc}
log=(out/'build.log').read_text();owners=[];dependencies={};incidences=0

def first_rule(path):
 # GNU compiler/linker depfiles can include later empty phony rules. Only the
 # first logical rule names the actual dependency closure; retain raw bytes.
 result=''
 for line in path.read_text().splitlines():
  continued=line.endswith('\\')
  result+=line[:-1]+' ' if continued else line
  if not continued:break
 left,right=result.split(':',1)
 return shlex.split(left),shlex.split(right)

for rel,entry in expected.items():
 obj=out/rel;md=out/(rel+'.d');assert obj.is_file() and md.is_file(),rel
 targets,inputs=first_rule(md);assert rel in targets,(rel,targets)
 assert inputs and pathlib.Path(inputs[0]).resolve()==pathlib.Path(entry['source']).resolve(),rel
 actualcc=cc_by_output[rel];assert pathlib.Path(actualcc['directory']).resolve()==out
 assert pathlib.Path(actualcc['file']).resolve()==pathlib.Path(entry['source']).resolve()
 assert entry['command'] in log,('missing actual complete-TU command',rel)
 assert '-O3' in shlex.split(entry['command']) and '-DNDEBUG' in shlex.split(entry['command']),rel
 for dep in inputs:
  p=pathlib.Path(dep);p=p if p.is_absolute() else out/p
  assert p.is_file(),str(p)
  dependencies.setdefault(str(p),sha(p));incidences+=1
 owners.append({'object':rel,'sha256':sha(obj),'actual_compiler_MD':str(md.relative_to(out)),'MD_sha256':sha(md),'dependencies':len(inputs),'source':entry['source']})
actual_md={str(p.relative_to(out))[:-2] for p in out.rglob('*.o.d')}
assert actual_md==set(expected),(actual_md-set(expected),set(expected)-actual_md)
core=[x for x in owners if x['object'].startswith('CMakeFiles/dome-sculpt-core.dir/')]
core_by_name={pathlib.Path(x['object']).name:x for x in core};assert len(core_by_name)==len(core)
archive=out/'libdome-sculpt-core.a';members=subprocess.check_output(['/usr/bin/ar','t',str(archive)],text=True).splitlines()
assert len(members)==len(core) and set(members)==set(core_by_name)
archive_records=[]
for member in members:
 payload=subprocess.check_output(['/usr/bin/ar','p',str(archive),member]);digest=hashlib.sha256(payload).hexdigest();assert digest==core_by_name[member]['sha256'],member
 archive_records.append({'member':member,'sha256':digest,'object':core_by_name[member]['object']})
link=out/'CMakeFiles/dome-sculpt.dir/link.d';targets,linkdeps=first_rule(link);assert 'dome-sculpt' in targets
link_records=[]
for dep in linkdeps:
 p=pathlib.Path(dep);p=p if p.is_absolute() else out/p;assert p.is_file(),str(p)
 link_records.append({'path':str(p),'sha256':sha(p)})
readelf=subprocess.check_output(['/usr/bin/readelf','-d',str(out/'dome-sculpt')],text=True);(out/'app-readelf-dynamic.txt').write_text(readelf)
assert sha(out/'dome-sculpt')==state['application_sha256']
for name,data in [('actual-MD-owners.json',owners),('actual-input-manifest.json',dependencies),('actual-core-members.json',archive_records),('actual-link-inputs.json',link_records)]:
 (out/name).write_text(json.dumps(data,indent=2)+'\n')
summary={'state':'actual_whole_App_build_audit_passed','source':state['source'],'scope':'Fresh optimized CPU whole application target only; no product/GL execution and no native/all-target/sanitizer acceptance','owner_count':len(owners),'core_member_count':len(core),'dependency_incidences':incidences,'actual_dependency_paths':len(dependencies),'actual_link_incidences':len(linkdeps),'application_sha256':sha(out/'dome-sculpt'),'core_archive_sha256':sha(archive),'plan_sha256':sha(out/'build-plan.json'),'build_status_sha256':sha(out/'build-status.json'),'audit_driver_sha256':sha(__file__),'input_drift':drift,'artifacts':{name:sha(out/name) for name in ['actual-target-commands.txt','actual-MD-owners.json','actual-input-manifest.json','actual-core-members.json','actual-link-inputs.json','app-readelf-dynamic.txt']}}
(out/'build-audit-status.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
