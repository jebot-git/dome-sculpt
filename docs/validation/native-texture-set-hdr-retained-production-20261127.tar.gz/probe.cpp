#include "dome/document.hpp"
#include "dome/emission-native.hpp"
#include "dome/native-authoring.hpp"
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc,char **argv) try {
  using namespace dome;
  if(argc!=3)return 2;
  const auto input=std::filesystem::absolute(argv[1]);
  const std::filesystem::path output=argv[2];
  std::filesystem::create_directories(output);
  const auto baseline=Scene::load(input).encode();
  Document doc;
  doc.open_async(input).get();
  if(!doc.wait_mesh()||!doc.frame().state->error.empty())throw std::runtime_error("Legacy project did not render");
  doc.save_async(output/"source.dsculpt").get();
  for(auto [name,format]:std::array{std::pair{"standard",AssetExportFormat::Glb},
      std::pair{"editable",AssetExportFormat::EditableGlb512}}){
    const auto path=output/(std::string(name)+".glb");
    doc.export_asset(path,format).get();
    std::ifstream stream(path,std::ios::binary);
    const std::vector<uint8_t> bytes{std::istreambuf_iterator<char>(stream),{}};
    const auto restored=format==AssetExportFormat::Glb?extract_native_emission(bytes):extract_native_authoring(bytes);
    if(!restored||restored->encode()!=baseline)throw std::runtime_error("Legacy native round trip differs");
    std::cout<<name<<" legacy "<<bytes.size()<<" bytes; exact native restore"<<std::endl;
  }
  return 0;
} catch (const std::exception &e) {std::cerr<<e.what()<<std::endl;return 1;}
