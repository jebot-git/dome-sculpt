#!/usr/bin/env bash
set -euo pipefail
root_path=$(dirname "$(readlink -f "$0")")
binary="$root_path/release-admit/dome-sculpt-texture-set-source-export-test"
link_log="$root_path/release-admit/prior-standard.log"
for iteration in {1..90}; do
    if [[ -x "$binary" && -f "$link_log" ]]; then break; fi
    sleep 2
done
test -x "$binary"
test -f "$link_log"
ln -s "$binary" "$root_path/registration/dome-sculpt-texture-set-source-export-test"
export LD_LIBRARY_PATH=/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64
export LIBGL_ALWAYS_SOFTWARE=1 EGL_PLATFORM=surfaceless LP_NUM_THREADS=2
ctest --test-dir "$root_path/registration" -R '^texture-set-retained-hdr-production-' --output-on-failure -j2 --output-junit "$root_path/registered-production.xml" > "$root_path/registered-production.log" 2>&1
