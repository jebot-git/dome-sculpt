from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as XML

root=Path(__file__).resolve().parent
source=root/"source"
out=source/"docs/validation"
name="native-texture-set-hdr-retained-production-20261127"
archive=out/(name+".tar.gz")
files=set()

def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def keep(path):
    path=Path(path)
    files.add(path)
    return sha(root/path)

def git(*args):
    return subprocess.check_output(["git","-C",source,*args],text=True).strip()

product=git("rev-parse","HEAD")
assert product.startswith("e64e9a51")
receipt={
    "baseline":git("rev-parse","HEAD^"),
    "product":product,
    "scope":"Prepared retained PBR source with two independent 1024-square members and their actual original filtering raster. Native cold Open, desktop paint, exact Undo/Redo, original color/ORM and normal byte oracles, both GLB formats, exact EXR coefficients and exact native reopen.",
    "limits":{"maximum_bytes":256*1024*1024,"maximum_work":64_000_000,"tight_work_refusal":2_000_000},
    "source_patch_sha256":keep("source.patch"),
    "controls":{},
    "profiles":{},"packages":{},"frontends":{},"khronos":{},
    "open":"Larger retained grids, retained rebaking at production size, fully typed MToon, alternate source emission coordinates, HDR VRM, full integrated regression and physical headset acceptance."
}
for path in ("validate.py","validate-final.py","verify.py","admit.py","probe.cpp","run-registered.sh","record.py",
             "public-focus-admit.py","xr-public-admit.py","xr-focus.py","wayland.py","khronos.log",
             "registry-configure.log","registered-production.json","registered-production.log","registered-production.xml",
             "release-namespace-refusal.log","asan-namespace-refusal.log","first-key-regression-terminal.json"):
    keep(path)
baseline=(root/"original-refusal.log").read_text()
assert "Texture-set field preview exceeds its charged work bound" in baseline
assert baseline.count("Texture-set export exceeds its working budget")==2
receipt["controls"]["original_refusals_sha256"]=keep("original-refusal.log")
alternate=(root/"release-retained/probe-1024.log").read_text()
assert "Texture-set export exceeds its working budget" in alternate
receipt["controls"]["preview_only_refusal_sha256"]=keep("release-retained/probe-1024.log")
assert sha(root/"release-retained/probe-1024/source.dsculpt")==sha(root/"release-admit/probe-1024/source.dsculpt")
older=json.loads((root/"first-key-regression-terminal.json").read_text())
assert older["terminal"] and older["exit"]==8 and older["totals"]=={"pass":1335,"fail":2,"skip":13}
receipt["older_full_regression"]={key:older[key] for key in ("candidate","terminal","registered","totals","failed","skipped","junit_sha256")}

tests={
    "dome-sculpt-texture-set-source-export-test":6074,
    "dome-sculpt-texture-set-export-test":149,
    "dome-sculpt-current-paint-preview-native-test":8425,
    "dome-sculpt-texture-set-surfaces-test":72,
    "dome-sculpt-texture-set-native-test":45,
    "prior-standard":50,
    "prior-editable":44,
    "production-standard":745,
    "production-editable":736
}
for profile in ("release","asan"):
    directory=Path(profile+"-admit")
    artifact=root/directory
    current={"application_sha256":sha(artifact/"dome-sculpt"),
             "core_sha256":sha(artifact/"libdome-sculpt-core.a"),"checks":tests,"normal_max_radians":{}}
    for test,count in tests.items():
        log=directory/(test+".log")
        content=(root/log).read_text()
        assert re.search(rf"^PASS {count} ",content,re.M), (profile,test)
        if test.startswith("production-"):
            current["normal_max_radians"][test]=float(re.search(r"PORTABLE normal peak radians ([.e+\d-]+)",content)[1])
        keep(log)
    for filename in ("archive.log","probe-512.log","probe-1024.log"):
        keep(directory/filename)
    assert (artifact/"probe-1024.log").read_text().count("exact native restore")==2
    for stage in (profile+"-retained",profile+"-final",profile+"-admit"):
        for log in sorted((root/stage).glob("*compile.log")):
            keep(log.relative_to(root))
    for log in sorted(artifact.glob("*-link.log")):
        keep(log.relative_to(root))
    receipt["profiles"][profile]=current

for path in [*(f"probe-{size}/{part}" for size in (512,1024) for part in ("source.dsculpt","standard.glb","editable.glb")),
             *((f"production-{fmt}/{part}") for fmt in ("standard","editable") for part in ("source.dsculpt",fmt+"-retained-hdr.glb"))]:
    release,asan=(root/(p+"-admit")/path for p in ("release","asan"))
    digest=sha(release)
    assert sha(asan)==digest,path
    record={"bytes":release.stat().st_size,"sha256":digest}
    if path.startswith("probe-512/"):
        prior=root.parent/"texture-set-baked-production-20261127/release-baked/probe-retained-512"/release.name
        assert sha(prior)==digest
        record["identical_to_original"]=True
    receipt["packages"][path]=record
assert sha(root.parent/"texture-set-baked-production-20261127/release-baked/probe-retained-1024/source.dsculpt")==receipt["packages"]["probe-1024/source.dsculpt"]["sha256"]
reference=receipt["packages"]["probe-1024/standard.glb"]["sha256"]

for mode in ("wayland","software","arc"):
    directory=Path(mode+"-focus-retained-hdr-admitted")
    status=json.loads((root/directory/"status.json").read_text())
    report=json.loads((root/directory/"workflow/report.json").read_text())
    assert status["terminal"] and status["exit"]==0 and status["native_sha256"]==reference
    profile="asan" if mode=="arc" else "release"
    assert status["app_sha256"]==receipt["profiles"][profile]["application_sha256"]
    assert status["input_sha256"]==receipt["packages"]["probe-1024/source.dsculpt"]["sha256"]
    assert status["checks"] in (7,10) and status["checks"]==len(report["checks"]) and all(row["passed"] for row in report["checks"])
    for path in (root/directory).rglob("*"):
        if path.is_file() and path.suffix in (".log",".json",".txt") and "home" not in path.parts:
            keep(path.relative_to(root))
    receipt["frontends"][mode]=status

suite=XML.parse(root/"registered-production.xml").getroot()
assert suite.attrib["tests"]=="2" and suite.attrib["failures"]=="0"
assert "100% tests passed" in (root/"registered-production.log").read_text()
receipt["registered_release_ctest"]={case.attrib["name"]:float(case.attrib["time"]) for case in suite.findall("testcase")}
for line in (root/"khronos.log").read_text().splitlines():
    row=json.loads(line)
    assert row["errors"]==row["warnings"]==0
    row["report_sha256"]=keep(row["filename"]+".khronos.json")
    receipt["khronos"][row["filename"]]=row

with archive.open("wb") as stream:
    with gzip.GzipFile(filename="",fileobj=stream,mode="wb",mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode="w") as bundle:
            for file in sorted(files):
                path=root/file
                info=bundle.gettarinfo(path,str(file))
                info.mtime=0
                info.uid=info.gid=0
                info.uname=info.gname=""
                with path.open("rb") as data:
                    bundle.addfile(info,data)
with tarfile.open(archive) as bundle:
    assert set(m.name for m in bundle.getmembers())==set(map(str,files))
    for file in files:
        assert hashlib.file_digest(bundle.extractfile(str(file)),"sha256").hexdigest()==sha(root/file)
receipt["archive"]={"file":archive.name,"members":len(files),"sha256":sha(archive)}
(out/(name+".json")).write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
