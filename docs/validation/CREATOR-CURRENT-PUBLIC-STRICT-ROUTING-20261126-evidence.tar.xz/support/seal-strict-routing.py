from pathlib import Path
import hashlib,json,tarfile,io
out=Path(__file__).resolve().parent;src=out.parent/'vroid-creator-public-resume-20261126'
stage=out/'strict-routing-milestone';stage.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
members={};external={};cases={}
def add(name,p):
    p=Path(p);assert p.is_file();members[name]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
for mode,expected in [('cancel',19),('focus',20)]:
    case=out/('strict-public-'+mode+'-v1');s=json.loads((case/'status.json').read_text());r=json.loads((case/'workflow/report.json').read_text());plan=json.loads((case/'plan.json').read_text())
    assert s['terminal']and s['exit']==0 and s['actual_checks']==expected and not s['input_drift']and not s['owned_remaining']
    assert r['complete']and not r['error']and not r['drift']and r['count']==expected and all(c['passed']for c in r['checks'])
    row=next(x for x in s['steps']if x['name']=='public '+mode);assert row['exit']==0 and row['seconds']<240 and row['peak_owned_RSS_bytes']<4*1024**3 and not row['signals']
    assert len(s['explicit_App_roots'])==2
    cases[mode]={'actual_checks':expected,'whole_wrapper_exit':s['exit'],'actual_seconds':row['seconds'],'peak_owned_RSS_bytes':row['peak_owned_RSS_bytes'],'explicit_App_roots':s['explicit_App_roots'],'same_executable_descendants':s['same_executable_descendants'],'ELF_certificates':len(s['observed']['actual_mapped_ELFs']),'lease':s['lease'],'input_drift':s['input_drift'],'owned_remaining':s['owned_remaining']}
    for p in case.rglob('*'):
        if not p.is_file():continue
        relative=p.relative_to(case)
        if '/home/'in '/'+str(relative)+'/' or p.suffix=='.dsculpt':
            if p.suffix=='.dsculpt':external[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
            continue
        add(mode+'/'+str(relative),p)
for p in [Path(__file__),out/'run-public-sanitize-v2.py',out/'provider-witness-v3.py',out/'owned-monitor.py',out/'private-bin-v3/Xvfb',out/'sanitize-review.json',out/'device-auth-sanitize-build.json']:
    if p.is_file():add('support/'+p.name,p)
for p in [src/'tests/creator-workspace-xr.py',src/'tests/creator-workspace.cpp',src/'tests/creator-workspace-runtime.cpp']:
    if p.is_file():add('fixture/'+p.name,p)
arc=stage/'scoped-proof.tar.xz'
with tarfile.open(arc,'w:xz',preset=6)as t:
    for name,row in sorted(members.items()):
        data=Path(row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(arc)as t:
    for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
receipt={'scope':'Current05 matched ASan/UBSan/leak public XR cancel and focus routing, native fidelity and ordinary reopen. Synthetic-input Arc execution; no physical HMD or newer combined-source acceptance.','production':'05f5d1ccfa4bb5b97d25e4a425a2fd9497b0d8c9','fixture_source':'5509958f','strict_App_sha256':'1c2560673f4f388eb9c56efeccf1c2bffb59e17633ef4f9ac57a7de0ede151ba','static_build_proof':'9dd08f32','prior_strict_accept_desktop_proof':'46b1b3eb','strict_options':{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','cohort_seconds':240,'RSS_bytes':4*1024**3,'virtual_AS_cap':None},'actual_cases':cases,'archive':{'bytes':arc.stat().st_size,'sha256':sha(arc),'members':members},'external_native_projects':external}
(stage/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'members':len(members),'bytes':arc.stat().st_size,'sha256':sha(arc),'cases':cases},indent=2))
for name,p in [('CREATOR-CURRENT-PUBLIC-STRICT-ROUTING-20261126.json',stage/'receipt.json'),('CREATOR-CURRENT-PUBLIC-STRICT-ROUTING-20261126-evidence.tar.xz',arc)]:
    (src/'docs/validation'/name).write_bytes(p.read_bytes())
