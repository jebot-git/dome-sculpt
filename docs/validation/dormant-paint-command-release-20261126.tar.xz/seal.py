from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

here=Path(__file__).resolve().parent
artifacts=here.parent
docs=artifacts.parent/'docs/validation'
source=artifacts/'dormant-paint-command-source-20261126'
plan=json.loads((here/'build-plan.json').read_text())
built=json.loads((here/'build-status.json').read_text())
native=json.loads((here/'native/status.json').read_text())
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args])
commit=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain')
assert hashlib.sha256(git('diff','--binary','f9c20398','HEAD')).hexdigest()==plan['source_diff_sha256']
assert built['terminal'] and built['exit']==0 and built['linked_archive']['replacements']==['document.cpp.o']
assert built['linked_archive']['members']==197 and len(built['compile'])==4 and len(built['links'])==4
assert native['terminal'] and native['exit']==0 and len(native['cases'])==3
assert all(row['exit']==0 and row['check_passed'] for row in native['cases'].values())
broad=artifacts/'production-full-regression-release-20261126/full-private-ctest/ctest.log'
original=broad.read_text()
failures=here/'broad-original-dormant-tests.log'
matches=[]
for name in ('transaction-sculpt-undo','source-uv-adopt'):
    m=re.search(r'^.*Test +#\d+: '+name+r' +[.]+\*\*\*Failed[^\n]*\n(?:(?!^ +Start ).*\n)*',original,re.M)
    assert m and 'Texture sets require an active painting mesh' in m[0]
    matches.append(m[0])
failures.write_text('\n'.join(matches))
paths=[here/p for p in ('prepare.py','build.py','run-native.py','owned_monitor.py','build-plan.json','build-status.json','native/status.json','seal.py')]
paths+=sorted(here.glob('*.d'))+sorted(here.glob('*.log'))+sorted((here/'native').glob('*.log'))
archive=docs/'dormant-paint-command-release-20261126.tar.xz'
manifest={}
with tarfile.open(archive,'w:xz',preset=6) as f:
    for path in paths:
        key=str(path.relative_to(here))
        assert key not in manifest
        data=path.read_bytes()
        member=tarfile.TarInfo(key)
        member.size=len(data)
        manifest[key]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        f.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:xz') as f:
    assert set(f.getnames())==set(manifest)
    for file in f:
        assert file.size==manifest[file.name]['bytes']
        assert hashlib.file_digest(f.extractfile(file),'sha256').hexdigest()==manifest[file.name]['sha256']
receipt={'source':commit,'baseline':'f9c20398','build_invocation':'0038c2b203534917946c7c88ce66105c',
         'native_invocation':'95e962616b11496dbd89010f9e966068',
         'scope':'Actual private Release reload/source-mode and sculpt-undo allocation fault regression. Software color blur verifies the selected current-layer workflow and backend refusal; graphics/hardware support is separate.',
         'build':built,'native':native,'authorities':manifest,
         'archive':{'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}}
archive.with_name(archive.name.replace('.tar.xz','.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(commit,len(paths),receipt['archive'])
