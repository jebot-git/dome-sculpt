from pathlib import Path
import fcntl,hashlib,json,os,shlex,subprocess,sys,time

base=Path(__file__).resolve().parent
profile=sys.argv[1]
arc=profile=='asan'
artifacts=base.parent
out=base/profile
out.mkdir(exist_ok=True)
native=artifacts/'steady-gpu-retirement-validation-v2-20261126'/profile
build=native/'build'
source=artifacts/'steady-gpu-retirement-source-20261126'
runtime=artifacts/'retained-texture-set-public-validation-20261126'/profile
sdk=artifacts/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
expected=os.environ['DOME_RETIREMENT_CANDIDATE']

def sha(file):
    with Path(file).open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

state={'candidate':expected,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def record(**values):
    state.update(values)
    temp=out/'status.tmp'
    temp.write_text(json.dumps(state,indent=2)+'\n')
    temp.replace(out/'status.json')

def invoke(cmd,label,timeout):
    with (out/label).open('w') as trace:
        print(shlex.join(map(str,cmd)),file=trace,flush=True)
        subprocess.run(cmd,cwd=out,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=timeout)

try:
    assert subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()==expected
    assert subprocess.check_output(['git','-C',source,'diff','--name-only','33bd2460','HEAD','--','tests/xr_runtime.cpp','tests/cut-color-xr.py'],text=True)==''
    record(phase='wait for the exact successful product and tests')
    status=native/'status.json'
    while True:
        if status.is_file():
            sealed=json.loads(status.read_text())
            if sealed['terminal']:break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        f'ds-steady-gpu-retirement-{profile}-v2-20261126.service'],check=True)
        time.sleep(2)
    assert sealed['candidate']==expected and sealed['exit']==0 and sealed['tests']==12
    app=build/'dome-sculpt'
    assert sha(app)==sealed['app_sha256']
    suites = {
        'render-store-ledger': ['--hardware'],
        'renderer-recovery': ['--hardware'],
        'source-gpu': [source/'assets/humanoid/vroid/base-female.vrm',
                       source/'assets/humanoid/vroid/base-male.vrm'],
        'mtoon-emission': ['--hardware'],
        'native-mtoon-physical': [out/'native-mtoon', '--hardware'],
        'native-retained-physical': [out/'native-retained', '--hardware'],
        'polygon-color-render': ['--hardware'],
        'paint-overlay-gpu': ['--hardware'],
        'current-paint-preview-gpu': ['--hardware'],
        'sculpt-chunk-render': [out/'sculpt-chunks'],
        'sculpt-mask-render': ['--hardware'],
    }
    def target_name(name):
        return 'dome-sculpt-mask-render-test' if name=='sculpt-mask-render' else f'dome-sculpt-{name}-test'
    for target in ('dome-sculpt-cut-color-render-test', *(target_name(name) for name in suites)):
        assert sha(build/target)==sealed['binaries'][target]
    synthetic=runtime/'libdome-sculpt-test-runtime.so'
    assert sha(synthetic)==json.loads((runtime/'status.json').read_text())['runtime_sha256']
    sandbox=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    settings={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
              'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    runner=source/'tests/cut-color-xr.py'
    if arc:
        sandbox.extend(['--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129'])
        settings.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
                        LIBGL_ALWAYS_SOFTWARE='0',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                        UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        text=runner.read_text()
        assert text.count('"LIBGL_ALWAYS_SOFTWARE":"1"')==1
        runner=out/'runner.py'
        runner.write_text(text.replace('"LIBGL_ALWAYS_SOFTWARE":"1"','"LIBGL_ALWAYS_SOFTWARE":"0"'))
    for k,v in settings.items():
        sandbox.extend(['--setenv',k,v])
    record(phase='load both eyes through the actual OpenXR entry point',app_sha256=sha(app),runtime_sha256=sha(synthetic),
           runner_sha256=sha(runner),core_sha256=sealed['core_sha256'])
    command=[*sandbox,'/usr/bin/python3',runner,app,synthetic,out/'xr']
    if arc:
        with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            invoke([*sandbox,build/'dome-sculpt-cut-color-render-test',out/'render'],'render.log',180)
            hardware={}
            failures=[]
            for name,args in suites.items():
                log=out/f'{name}.log'
                binary=build/target_name(name)
                try:
                    invoke([*sandbox,binary,*args],log.name,300)
                    code=0
                except subprocess.CalledProcessError as error:
                    code=error.returncode
                    failures.append(name)
                hardware[name]={'exit':code,'log_sha256':sha(log),
                                'checks':sum(line.startswith('PASS ') for line in log.read_text().splitlines())}
            record(hardware=hardware,hardware_failures=failures)
            assert not failures, failures
            invoke(command,'xr.log',220)
        renderer=next(line[4:] for line in (out/'render.log').read_text().splitlines() if line.startswith('GPU '))
        assert 'Arc(tm) A770' in renderer
        for name in ('render-store-ledger','renderer-recovery','current-paint-preview-gpu'):
            assert 'Arc(tm) A770' in (out/f'{name}.log').read_text()
            assert 'renderD129' in (out/f'{name}.log').read_text()
        record(renderer=renderer,render_log_sha256=sha(out/'render.log'))
    else:
        invoke(command,'xr.log',220)
    result=json.loads((out/'xr/report.json').read_text())
    assert result['synthetic_tracking'] and result['failed']==0 and len(result['checks'])==21
    record(phase='complete',terminal=True,exit=0,checks=len(result['checks']),report_sha256=sha(out/'xr/report.json'))
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
