from pathlib import Path
import hashlib
import json
import shlex
import subprocess

out = Path(__file__).resolve().parent
artifacts = out.parents[1]
build = out.parent/'release/build'
old = artifacts/'cut-owning-material-source-20261126/src'
fixture = 'dome-sculpt-render-store-ledger-test'
database = json.loads((build/'compile_commands.json').read_text())
entry = next(row for row in database if f'{fixture}.dir/' in row['command'])
words = shlex.split(entry['command'])
old_input = words[words.index('-o')+1]
obj = out/'render-store-ledger.cpp.o'
words[words.index('-o')+1] = str(obj)
words.insert(1, f'-I{old}')
last = subprocess.check_output(['ninja','-C',build,'-t','commands',fixture], text=True).splitlines()[-1]
link = [word for word in shlex.split(last)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
link[link.index(old_input)] = str(obj)
app = out/'baseline-ledger'
link[link.index('-o')+1] = str(app)
with (out/'build.log').open('w') as log:
    for command in [words, link]:
        print(shlex.join(command), file=log, flush=True)
        subprocess.run(command, cwd=build, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=120)
command = ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--proc','/proc','--dev','/dev',
           '--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','HOME','/tmp',
           '--setenv','EGL_PLATFORM','surfaceless','--setenv','LIBGL_ALWAYS_SOFTWARE','1',
           '--setenv','LP_NUM_THREADS','2', app]
with (out/'control.log').open('w') as log:
    run = subprocess.run(command, cwd=out, stdout=log, stderr=subprocess.STDOUT, timeout=120)
observed=(out/'control.log').read_text()
diagnostic='New pending submissions preserve a completed older fence and reclaim its actual store'
assert run.returncode==1 and diagnostic in observed and 'llvmpipe' in observed, observed
(old_header,)=(old/'render-store-ledger.hpp',)
(out/'status.json').write_text(json.dumps({'expected_failure':diagnostic,'exit':run.returncode,
    'parent':subprocess.check_output(['git','-C',old,'rev-parse','HEAD'],text=True).strip(),
    'header_sha256':hashlib.sha256(old_header.read_bytes()).hexdigest(),
    'fixture_sha256':hashlib.sha256(Path(entry['file']).read_bytes()).hexdigest()},indent=2)+'\n')
