from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile
from xml.etree import ElementTree

native=Path(__file__).resolve().parent
art=native.parent
root=art.parent
public=art/'steady-gpu-retirement-public-v2-20261126'
wayland=art/'steady-gpu-retirement-wayland-v3-20261126'
baseline=art/'steady-gpu-retirement-validation-20261126/baseline'
out=root/'docs/validation'
expected='a4ef26ffad36da8814ae1bf863feaa7b02693cd9'
files={}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def add(prefix,directory,*names):
    for name in names:
        path=directory/name
        assert path.is_file(), path
        files[prefix+'/'+name]=path

def read(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

gpu_files=git('diff','--name-only','4ecf1998',expected).splitlines()
assert len(gpu_files)==7 and not git('diff','--name-only',expected,'HEAD','--',*gpu_files)
subprocess.run(['git','-C',root,'merge-base','--is-ancestor',expected,'HEAD'],check=True)
results={}
for profile in ('release','asan'):
    ref=native/profile
    online=(art/'steady-gpu-retirement-public-v3-20261126' if profile=='release' else public)/profile
    suite=read(ref/'status.json')
    replay=read(online/'status.json')
    assert suite['candidate']==replay['candidate']==expected
    assert suite['terminal'] and suite['exit']==0 and suite['tests']==12 and suite['failures']==[]
    assert replay['terminal'] and replay['exit']==0 and replay['checks']==21
    assert replay['app_sha256']==suite['app_sha256']==sha(ref/'build/dome-sculpt')
    xml=ref/'build/renderer-tests.xml'
    cases=ElementTree.parse(xml).getroot().findall('.//testcase')
    assert len(cases)==12 and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
    if profile=='asan':
        assert 'Arc(tm) A770' in replay['renderer'] and replay['hardware_failures']==[]
        assert len(replay['hardware'])==11 and all(row['exit']==0 for row in replay['hardware'].values())
        add(profile+'/arc',online,'render.log','runner.py',
            *[name+'.log' for name in replay['hardware']])
    results[profile]={'native':suite,'synthetic_openxr':replay}
    add(profile+'/native',ref,'status.json','configure.log','render.cpp.log','render-index.log','dome-sculpt-link.log',
        'ctest.log','build/renderer-tests.xml','cut-fixtures.json')
    add(profile+'/synthetic-openxr',online,'status.json','xr.log','xr/report.json')
public_wl=read(wayland/'status.json')
assert public_wl['candidate']==expected and public_wl['exit']==0 and public_wl['checks']==17
assert public_wl['app_sha256']==results['release']['native']['app_sha256']
add('wayland',wayland,'run.py','replay.py','status.json','wayland.log','workflow/report.json')
control=read(baseline/'status.json')
assert control['exit']==1 and control['expected_failure'] in (baseline/'control.log').read_text()
assert control['parent']==results['release']['native']['donor']
add('baseline',baseline,'run.py','status.json','build.log','control.log')
add('failed-runner-v1-release',art/'steady-gpu-retirement-validation-20261126/release','status.json')
add('failed-runner-v1-asan',art/'steady-gpu-retirement-validation-20261126/asan','status.json')
add('failed-wayland-wait-v2',art/'steady-gpu-retirement-wayland-v2-20261126','status.json')
add('runner',native,'run.py','record.py')
add('replay-runner',public,'run.py')
add('replay-runner-v3',art/'steady-gpu-retirement-public-v3-20261126','run.py')
add('failed-software-replay-v2',public/'release','status.json','xr.log')
archive=out/'steady-gpu-retirement-20261126.tar.gz'
with archive.open('wb') as packed,gzip.GzipFile(filename='',fileobj=packed,mode='wb',mtime=0) as data:
    with tarfile.open(fileobj=data,mode='w') as target:
        for name,path in sorted(files.items()):
            info=target.gettarinfo(str(path),arcname=name)
            info.uid=info.gid=info.mtime=0
            info.mode=0o644
            info.uname=info.gname=''
            with path.open('rb') as stream:
                target.addfile(info,stream)
members={name:sha(path) for name,path in sorted(files.items())}
with tarfile.open(archive,'r:gz') as check:
    assert {entry.name for entry in check.getmembers()}==set(members)
    for name,digest in members.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==digest
receipt={'candidate':expected,'main_merge':git('rev-parse','HEAD'),
         'source_commits':git('log','-2','--format=%H',expected).splitlines(),
         'baseline':control,'matrix':results,'wayland':public_wl,
         'archive':{'name':archive.name,'sha256':sha(archive),'members':members}}
(out/'steady-gpu-retirement-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(members),'archived evidence members',sha(archive))
