from pathlib import Path
from xml.etree import ElementTree
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

native=Path(__file__).resolve().parent
art=native.parent
root=art.parent
output=root/'docs/validation'
arc=art/'current-creator-vrm0-arc-v2-20261126'
wayland=art/'current-creator-vrm0-wayland-v2-20261126'
interop=art/'current-creator-vrm0-interoperability-release-20261126'
xr=art/'current-creator-vrm0-xr-reopen-v3-20261126'
expected='90c10c285038fdfdf5e415ca8efbc7c494debb34'
files={}

def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def add(prefix,folder,*members):
    for name in members:
        item=folder/name
        assert item.is_file(),item
        files[prefix+'/'+name]=item

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

subprocess.run(['git','-C',root,'merge-base','--is-ancestor',expected,'HEAD'],check=True)
assert git('diff','--name-only',expected,'HEAD','--','src','include','assets','third_party','CMakeLists.txt')==''
test_changes=set(git('diff','--name-only',expected,'HEAD','--','tests').splitlines())
assert test_changes=={'tests/object-selection.cpp','tests/object-isolation.cpp','tests/modal-selection-controls.cpp'}
before=read(native/'baseline/status.json')
assert before['diagnostic']=='FAIL VRM0: every source part needs coordinate basis provenance'
add('baseline',native/'baseline','run.py','control.log','link.log','status.json')

release=native/'release'
state=read(release/'status.json')
assert state['candidate']==expected and state['terminal'] and state['exit']==0 and state['tests']==11 and not state['failures']
assert sha(release/'build/dome-sculpt')==state['app_sha256'] and sha(release/'ctest.log')==state['ctest_sha256']
xml=release/'build/creator-vrm-tests.xml'
assert sha(xml)==state['junit_sha256']
cases=ElementTree.parse(xml).getroot().findall('.//testcase')
names={case.attrib['name'] for case in cases}
assert len(names)==11 and all(case.find('failure') is None and case.find('skipped') is None for case in cases)
assert 'CREATOR VRM CHECKS 460' in (release/'ctest.log').read_text()
add('release/native',release,'status.json','configure.log','dome-sculpt-link.log','ctest.log','build/creator-vrm-tests.xml')

asan=native/'asan'
snapshot=native/'asan-checkpoint'
snapshot.mkdir(exist_ok=True)
for name in ('status.json','ctest.log'):
    (snapshot/name).write_bytes((asan/name).read_bytes())
strict=read(snapshot/'status.json')
assert strict['candidate']==expected and sha(asan/'build/dome-sculpt')==strict['app_sha256']
log=(snapshot/'ctest.log').read_text()
passed=set(re.findall(r'^\s*\d+/11 Test\s+#\d+: ([\w-]+) \.+\s+Passed',log,re.M))
failed=set(re.findall(r'^\s*\d+/11 Test\s+#\d+: ([\w-]+) \.+\s+\*\*\*',log,re.M))
assert passed<=names and not failed and len(passed)>=9
strict['checkpoint']={'passed':sorted(passed),'pending':sorted(names-passed),'failed':sorted(failed),
                      'full_run_terminal':strict['terminal']}
add('asan/checkpoint',snapshot,'status.json','ctest.log')
for profile in ('release','asan'):
    for number in (1,2):
        qualifier='' if number==1 else '-v2'
        earlier=art/f'current-creator-vrm0-validation{qualifier}-20261126'/profile
        compiler=earlier/'tests/dome-sculpt-creator-vrm-test/creator-vrm.cpp.log'
        assert 'error:' in compiler.read_text()
        add(f'{profile}/initial-fixture-{number}',earlier,'status.json',
            'tests/dome-sculpt-creator-vrm-test/creator-vrm.cpp.log')
    donor=art/'current-creator-vrm0-validation-v2-20261126'/profile
    add(profile+'/product-build',donor,'creation.cpp.log','creator-vrm.cpp.log','material-bindings.cpp.log',
         'vrm.cpp.log','vroid-creator.cpp.log','core-index.log')
gpu=read(arc/'status.json')
wl=read(wayland/'status.json')
intop=read(interop/'status.json')
assert gpu['candidate']==wl['candidate']==intop['candidate']==expected
assert gpu['exit']==wl['exit']==intop['exit']==0
assert gpu['binary_sha256']==state['binaries']['dome-sculpt-normal-frame-vrm-consumer-test']
assert gpu['checks']==27 and wl['checks']==10 and intop['schemas']==15 and intop['validated_files']==32
assert intop['errors']==0 and len(intop['binary_equal_release_and_asan'])==13 and len(intop['binary_equal_arc'])==7
assert wl['app_sha256']==state['app_sha256'] and sha(wayland/'workflow/Avatar.vrm')==wl['output_sha256']
assert sha(arc/'arc.log')==gpu['trace_sha256']
assert sha(interop/'official-vrm0.json')==intop['official_sha256'] and sha(interop/'khronos.json')==intop['khronos_sha256']
add('runner',native,'run.py','record-release.py','record.py')
add('arc',arc,'run.py','arc.log','status.json')
for label,folder in {'combined':'current-creator-vrm0-arc-20261126',
                     'canonical':'current-creator-vrm0-arc-canonical-20261126'}.items():
    observed=art/folder
    probe=read(observed/'status.json')
    assert probe['exit']==1 and 'FAIL Actual avatar worker accepts explicitly authored flat frames' in (observed/'arc.log').read_text()
    add('asan-arc-'+label,observed,'run.py','arc.log','status.json')
add('wayland',wayland,'run.py','replay.py','status.json','wayland.log','workflow/report.json')
add('wayland-wrapper-count-v1',art/'current-creator-vrm0-wayland-20261126','status.json','workflow/report.json')
add('interoperability',interop,'run.py','status.json','official-vrm0.json','khronos.json','khronos.log')
xr_status={}
for profile in ('software','arc'):
    observed=xr/profile
    runtime=read(observed/'status.json')
    assert runtime['candidate']==expected and runtime['exit']==0 and runtime['releases']>=10
    assert runtime['app_sha256']==state['app_sha256'] and sha(observed/'runtime.json')==runtime['report_sha256']
    xr_status[profile]=runtime
    add(profile+'/xr',observed,'status.json','runtime.json','xr.log')
    add(profile+'/first-xr-fixture',art/'current-creator-vrm0-xr-reopen-20261126'/profile,'status.json','runtime.json','xr.log')
add('xr-runner',xr,'run.py')
spec=art/'creator-vrm-placement-spec-20261126'
add('schema-pins',spec,'khronos.cjs','schema-blobs.txt')
add('validator-pin',art/'hdr-khronos-validation-20261126','npm-pack.json')
archive=output/'creator-vrm0-current-20261126.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as stream:
    with tarfile.open(fileobj=stream,mode='w') as tar:
        for name,path in sorted(files.items()):
            entry=tar.gettarinfo(str(path),arcname=name)
            entry.uid=entry.gid=entry.mtime=0
            entry.mode=0o644
            entry.uname=entry.gname=''
            with path.open('rb') as data:
                tar.addfile(entry,data)
digests={name:sha(path) for name,path in sorted(files.items())}
with tarfile.open(archive,'r:gz') as tar:
    assert {entry.name for entry in tar.getmembers()}==set(digests)
    for name,digest in digests.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
receipt={'candidate':expected,'main_merge':git('rev-parse','HEAD'),'prior_control':before,
         'release':state,'sanitizer':strict,'arc':gpu,'wayland':wl,'synthetic_openxr':xr_status,
         'interoperability':intop,'concurrent_selection_fixtures':sorted(test_changes),
         'raw':{'archive':archive.name,'sha256':sha(archive),'members':digests}}
(output/'creator-vrm0-current-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(files),'evidence files',sha(archive),len(passed),'sanitizer cases passed')
