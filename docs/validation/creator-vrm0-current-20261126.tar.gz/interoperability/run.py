from pathlib import Path
import base64
import hashlib
import importlib.metadata
import json
import os
import struct
import subprocess
import tarfile
import time

from jsonschema import Draft4Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT4

out=Path(__file__).resolve().parent
art=out.parent
source=art/'current-creator-vrm0-source-v3-20261126'
matrix=art/'current-creator-vrm0-validation-v3-20261126'
wayland=art/'current-creator-vrm0-wayland-v2-20261126'
arc=art/'current-creator-vrm0-arc-v2-20261126'
spec=art/'creator-vrm-placement-spec-20261126'
schema=spec/'specification/0.0/schema'
validator=art/'hdr-khronos-validation-20261126'
candidate='90c10c285038fdfdf5e415ca8efbc7c494debb34'
state={'candidate':candidate,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def state_file(**fields):
    state.update(fields)
    temp=out/'status.tmp'
    temp.write_text(json.dumps(state,indent=2)+'\n')
    temp.replace(out/'status.json')

def wait(parent,unit,total):
    while True:
        status=parent/'status.json'
        if status.is_file():
            sealed=json.loads(status.read_text())
            if sealed['terminal']:break
        subprocess.run(['systemctl','--user','is-active','--quiet',unit],check=True)
        time.sleep(2)
    assert sealed['candidate']==candidate and sealed['exit']==0 and sealed.get('tests',sealed.get('checks'))==total
    return sealed

def parse(path):
    with path.open('rb') as handle:
        magic,version,length,size,kind=struct.unpack('<5I',handle.read(20))
        assert (magic,version,length,kind)==(0x46546c67,2,path.stat().st_size,0x4e4f534a)
        assert 0<size<=length-20
        return json.loads(handle.read(size))

try:
    state_file(phase='wait for exact native, Arc and native Wayland export receipts')
    wait(matrix/'release','ds-current-creator-vrm0-release-v3-20261126.service',11)
    strict_log=(matrix/'asan/ctest.log').read_text()
    import re
    assert re.search(r'bone-length-creator-basis\s+\.+\s+Passed',strict_log)
    assert re.search(r'normal-frame-vrm-consumer\s+\.+\s+Passed',strict_log)
    assert re.search(r'Test\s+#340: document-export\s+\.+\s+Passed',strict_log)
    wl=wait(wayland,'ds-current-creator-vrm0-wayland-v2-20261126.service',10)
    wait(arc,'ds-current-creator-vrm0-arc-v2-20261126.service',27)
    assets=wayland/'workflow/Avatar.vrm'
    assert sha(assets)==wl['output_sha256']

    state_file(phase='check binary equality and validate emitted GLB and VRM schemas')
    release=matrix/'release/build'
    strict=matrix/'asan/build'
    relatives=[p.relative_to(release) for folder in ('creator-shaped-vrm','bone-length-creator-basis','source-native-hints')
               for p in sorted((release/folder).glob('*.vrm'))]
    relatives.extend(Path(f'frame-vrm-consumer-{shape}-{weight}.vrm')
                     for shape in range(2) for weight in (0,35,100))
    relatives.append(Path('frame-vrm-consumer-canonical.vrm'))
    assert len(relatives)==31
    comparisons={}
    asan_comparisons={}
    for file in relatives:
        digest=sha(release/file)
        if file.parts[0]=='bone-length-creator-basis' or str(file).startswith('frame-vrm-consumer'):
            assert digest==sha(strict/file),file
            asan_comparisons[str(file)]=digest
        comparisons[str(file)]=digest
    arc_outputs=[]
    for file in relatives[-7:]:
        assert sha(arc/file)==comparisons[str(file)],file
        arc_outputs.append(str(file))

    blob_records=(spec/'schema-blobs.txt').read_text().splitlines()
    assert len(blob_records)==15
    resources={}
    schema_base='https://vrm.invalid/0.0/schema/'
    for entry in blob_records:
        prefix,relative=entry.split('\t')
        identifier=prefix.split()[-1]
        file=spec/relative
        data=file.read_bytes()
        computed=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
        assert computed==identifier,relative
        resources[schema_base+file.name]=Resource.from_contents(json.loads(data),default_specification=DRAFT4)
    assert {path.name for path in schema.glob('*.json')}=={Path(key).name for key in resources}
    registry=Registry().with_resources(resources.items())
    vrm=Draft4Validator({'$ref':schema_base+'vrm.schema.json'},registry=registry)

    package=json.loads((validator/'npm-pack.json').read_text())[0]
    tar=validator/package['filename']
    assert 'sha512-'+base64.b64encode(hashlib.sha512(tar.read_bytes()).digest()).decode()==package['integrity']
    module=validator/'module'
    with tarfile.open(tar,'r:gz') as tarball:
        for entry in tarball.getmembers():
            if entry.isfile():
                assert tarball.extractfile(entry).read()==(module/entry.name).read_bytes(),entry.name
    files=[release/file for file in relatives]+[assets]
    checked=[]
    for model in files:
        glb=parse(model)
        issues=[f'{issue.json_path}: {issue.message}' for issue in vrm.iter_errors(glb['extensions']['VRM'])]
        checked.append({'file':str(model),'sha256':sha(model),'errors':issues})
    (out/'official-vrm0.json').write_text(json.dumps({'files':checked},indent=2)+'\n')
    assert all(not item['errors'] for item in checked)
    transcript=out/'khronos.log'
    with transcript.open('w') as log:
        subprocess.run(['node',spec/'khronos.cjs',module/'package',out/'khronos.json',*files],
                       cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)
    gltf=json.loads((out/'khronos.json').read_text())
    assert gltf['version']==package['version'] and len(gltf['results'])==len(checked)
    warnings=sum(item['report']['issues']['numWarnings'] for item in gltf['results'])
    assert all(item['report']['issues']['numErrors']==0 and not item['report']['issues']['truncated'] for item in gltf['results'])
    state_file(phase='complete',terminal=True,exit=0,schemas=15,validated_files=len(checked),
               binary_equal_release_and_asan=asan_comparisons,binary_equal_arc=arc_outputs,
               warnings=warnings,errors=0,khronos_version=gltf['version'],
               jsonschema_version=importlib.metadata.version('jsonschema'),official_sha256=sha(out/'official-vrm0.json'),
               khronos_sha256=sha(out/'khronos.json'))
except Exception as error:
    state_file(terminal=True,exit=1,error=repr(error))
    raise
