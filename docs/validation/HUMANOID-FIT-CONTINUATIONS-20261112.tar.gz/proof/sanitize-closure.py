import pathlib,subprocess,json,hashlib,shlex,shutil,time,os,sys
ROOT=pathlib.Path('/home/blux/de-xr/dome-sculpt');BASE=ROOT/'artifacts/humanoid-fitting-quality-proof-20261111';SRC=ROOT/'artifacts/humanoid-fitting-quality-20261111';OLD=ROOT/'artifacts/radiance-bake-fallback-v2-20261111';CURRENT=ROOT/'artifacts/authoring-hdr-union-20261111';PROVIDER=ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/sanitize';OUT=BASE/'sanitize-9cebf6';PLAN=OUT/'plan';SDK=ROOT/'artifacts/sdk-20261111/toolkit-sanitize';MODE=sys.argv[1]
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
head=lambda p:subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip()
env={k:v for k,v in os.environ.items()if k not in ['LD_PRELOAD','LSAN_OPTIONS','ASAN_OPTIONS','UBSAN_OPTIONS']};env.update(PKG_CONFIG_PATH='/usr/lib64/pkgconfig',LD_LIBRARY_PATH=str(SDK/'lib')+':/usr/lib64',FLTK_DIR=str(SDK/'share/fltk'),LIBGL_ALWAYS_SOFTWARE='1',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
TESTS=['rig-fit-anatomical','avatar','rig-fit-authoring','rig-fit-metric','rig-fit-faults','skin-affine','skin-affine-controller','skin-authoring','rig-fit-import','skin-affine-export','rig-fit-controller']
FRESH={'avatar.cpp.o','rig-fit.cpp.o','material-visibility.cpp.o','mesh-processing.cpp.o'}
def run(cmd,name,status,cwd=OUT,timeout=180):
 t=time.monotonic()
 with open(OUT/(name+'.log'),'w')as f:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env=env)
 status['steps'].append({'name':name,'command':list(map(str,cmd)),'native_exit':r.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(OUT/(name+'.log'))});(OUT/'progress.json').write_text(json.dumps(status,indent=2));assert r.returncode==0,name
if MODE=='audit':
 OUT.mkdir();s={'source':head(SRC),'provider_source':head(OLD),'source_base':head(CURRENT),'pins':{},'steps':[],'kind':'Incremental matched native SAN closure:4fresh owning core TUs,189unchanged authenticated members,11fresh consumer TUs;notwholeapplicationbuild.'}
 def pin(p):p=pathlib.Path(p).resolve();s['pins'][str(p)]=sha(p)
 try:
  pin(__file__);assert s['source'].startswith('9cebf6ab') and s['provider_source']=='5bb34971651f6200bea7caf5af21a515cef8492f' and s['source_base']=='4977fb320afcc9b4d0ed486d4152c62b8018c324'
  assert not subprocess.check_output(['git','-C',str(SRC),'status','--porcelain','--untracked-files=no'],text=True).strip()
  manifest=PROVIDER/'source-before.json';pin(manifest);historical=json.loads(manifest.read_text())
  for name,h in historical.items():
   p=OLD/name
   if p.is_file():assert sha(p)==h,('provider historical source drift',name);pin(p)
  differences=set()
  for folder in ['include','src','assets','third_party']:
   for p in (OLD/folder).rglob('*'):
    if not p.is_file():continue
    relative=p.relative_to(OLD);pin(p)
    if not (SRC/relative).is_file()or sha(p)!=sha(SRC/relative):differences.add(str(relative))
   for p in (SRC/folder).rglob('*'):
    if not p.is_file():continue
    relative=p.relative_to(SRC);pin(p)
    if not (OLD/relative).is_file():differences.add(str(relative))
  expected={'src/avatar.cpp','src/rig-fit.cpp','src/material-visibility.cpp','src/mesh-processing.cpp','src/packed-material-query.hpp','src/render.cpp','src/render-store-ledger.hpp','src/humanoid-fit-continuation.hpp'};assert differences==expected,differences;s['actual_source_differences']=sorted(differences)
  s['public_header_count']=len(list((SRC/'include').rglob('*.hpp')))
  # The new plan is configure-only and compiles no provider or product object.
  config=['cmake','-S',str(SRC),'-B',str(PLAN),'-G','Ninja','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_COMPUTE_BACKEND=CPU','-DDOME_BUILD_UI=OFF','-DDOME_BUILD_XR=OFF','-DBUILD_TESTING=ON','-DFLTK_DIR='+str(SDK/'share/fltk'),'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer','-DCMAKE_CXX_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'];run(config,'configure-only',s)
  ready=PROVIDER.parent/'core-ready.json';pin(ready);r=json.loads(ready.read_text());core=PROVIDER/'libdome-sculpt-core.a';assert sha(core)==r['sha256'];pin(core)
  members=subprocess.check_output(['ar','t',str(core)],text=True).splitlines();assert len(members)==193 and FRESH<=set(members);s['provider_member_hashes']={m:hashlib.sha256(subprocess.check_output(['ar','p',str(core),m])).hexdigest()for m in members}
  old=json.loads((PROVIDER/'compile_commands.json').read_text());new=json.loads((PLAN/'compile_commands.json').read_text());pin(PROVIDER/'compile_commands.json');pin(PLAN/'compile_commands.json')
  core_old={pathlib.Path(x['file']).relative_to(OLD).as_posix():x for x in old if '/dome-sculpt-core.dir/'in x.get('output','')};core_new={pathlib.Path(x['file']).relative_to(SRC).as_posix():x for x in new if '/dome-sculpt-core.dir/'in x.get('output','')};assert len(core_old)==193 and core_old.keys()==core_new.keys()
  old_literal='-DDOME_SCULPT_SOURCE_ASSETS="'+str(OLD/'assets/humanoid')+'"';new_literal='-DDOME_SCULPT_SOURCE_ASSETS="'+str(SRC/'assets/humanoid')+'"';s['preserved_literal_asset_macro']={'actual_all193_old_and4fresh':old_literal,'new_plan_default_only':new_literal,'basis':'Tracked assets compared byte-for-byte across old/current/private source;bothroots pinned. No other -D normalization.'}
  routes=[]
  for file,a in core_old.items():
   args=shlex.split(a['command']);want=shlex.split(core_new[file]['command']);rebased=[x.replace('-I'+str(OLD),'-I'+str(SRC))for x in args];rebased[rebased.index('-o')+1]=want[want.index('-o')+1];rebased[-1]=str(SRC/file);rebased=[new_literal if x==old_literal else x for x in rebased];assert rebased==want,('flags',file)
   obj=pathlib.Path(a['output']);assert obj.is_file(),obj;pin(obj)
   deps=subprocess.check_output(['ninja','-C',str(PROVIDER),'-t','deps',str(obj.relative_to(PROVIDER))],text=True);changed=[]
   for line in deps.splitlines():
    if not line.startswith('    /'):continue
    p=pathlib.Path(line.strip()).resolve()
    if p.is_file():pin(p)
    if p.is_relative_to(OLD):
     rel=p.relative_to(OLD)
     if str(rel)in differences:changed.append(str(rel))
   assert not changed or obj.name in FRESH,('unrebuilt private dependency',file,changed)
   assert hashlib.sha256(obj.read_bytes()).hexdigest()==s['provider_member_hashes'][obj.name],('actual object/archive member mismatch',obj)
   routes.append({'source':file,'actual_provider_object':str(obj),'fresh':obj.name in FRESH,'changed_private_dependencies':changed})
  s['193_owning_routes']=routes
  s['tests']=[]
  listing=json.loads(subprocess.check_output(['ctest','--test-dir',str(PLAN),'--show-only=json-v1'],text=True,env=env))
  for name in TESTS:
   template='rig-fit-import'if name=='rig-fit-anatomical'else name
   entry=next(x for x in new if x['file']==str(SRC/('tests/'+name+'.cpp')));oldentry=next(x for x in old if x['file']==str(OLD/('tests/'+template+'.cpp')))
   # The new native target has exactly the existing cgltf consumer context.
   args=shlex.split(oldentry['command']);want=shlex.split(entry['command']);rebased=[x.replace('-I'+str(OLD),'-I'+str(SRC))for x in args];rebased[rebased.index('-o')+1]=want[want.index('-o')+1];rebased[-1]=str(SRC/('tests/'+name+'.cpp'));assert rebased==want,('consumer flags',name)
   target='dome-sculpt-'+name+'-test';raw=subprocess.check_output(['ninja','-C',str(PLAN),'-t','commands',target],text=True).splitlines()[-1];link=shlex.split(raw)[2:-2]
   for x in link:
    if x.endswith('.a')and not x.startswith('-'):
     p=PROVIDER/x;assert p.is_file();pin(p)
   test=next(x for x in listing['tests']if x['name']==name);s['tests'].append({'name':name,'compile':want,'link':link,'runtime':test['command'],'timeout':next((x['value']for x in test['properties']if x['name']=='TIMEOUT'),120)})
  for root in [SRC/'tests',SDK]:
   for p in root.rglob('*'):
    if p.is_file():pin(p)
  for name in ['libasan.so','libubsan.so','libstdc++.so','libgcc_s.so']:
   pin(subprocess.check_output(['c++','-print-file-name='+name],text=True).strip())
  for tool in ['c++','cc','ar','ld','cmake','ninja']:pin(shutil.which(tool))
  s['exit_code']=0
 except Exception as e:s['exit_code']=1;s['error']=repr(e)
 s['pin_drift']=[p for p,h in s['pins'].items()if not pathlib.Path(p).is_file()or sha(p)!=h]
 if s['pin_drift']:s['exit_code']=1
 (OUT/'audit.json').write_text(json.dumps(s,indent=2));print(json.dumps({'audit_exit':s['exit_code'],'error':s.get('error'),'pins':len(s['pins']),'routes':len(s.get('193_owning_routes',[])),'tests':len(s.get('tests',[])),'drift':s['pin_drift']}));sys.exit(s['exit_code'])
assert MODE=='execute';audit=json.loads((OUT/'audit.json').read_text());s={'source':head(SRC),'pins':dict(audit['pins']),'steps':[],'scope':audit['kind']};s['pins'][str(OUT/'audit.json')]=sha(OUT/'audit.json');assert audit['exit_code']==0
try:
 assert all(sha(p)==h for p,h in s['pins'].items())
 compile_commands=json.loads((PLAN/'compile_commands.json').read_text())
 for member in sorted(FRESH):
  file='src/'+member[:-2];entry=next(x for x in compile_commands if x['file']==str(SRC/file));args=shlex.split(entry['command']);args=[audit['preserved_literal_asset_macro']['actual_all193_old_and4fresh']if x==audit['preserved_literal_asset_macro']['new_plan_default_only']else x for x in args];args[args.index('-o')+1]=str(OUT/member);run(args,'compile-'+member,s);s['pins'][str(OUT/member)]=sha(OUT/member)
 core=OUT/'libdome-sculpt-core.a';shutil.copyfile(PROVIDER/'libdome-sculpt-core.a',core);run(['ar','r',str(core),*[str(OUT/m)for m in sorted(FRESH)]],'replace-four-owning-members',s)
 members=subprocess.check_output(['ar','t',str(core)],text=True).splitlines();assert set(members)==set(audit['provider_member_hashes']);s['current_member_hashes']={m:hashlib.sha256(subprocess.check_output(['ar','p',str(core),m])).hexdigest()for m in members};assert {m for m,h in s['current_member_hashes'].items()if h!=audit['provider_member_hashes'][m]}==FRESH;s['unchanged_members']=189;s['pins'][str(core)]=sha(core)
 for test in audit['tests']:
  name=test['name'];args=list(test['compile']);obj=OUT/(name+'.o');args[args.index('-o')+1]=str(obj);run(args,'compile-'+name,s);s['pins'][str(obj)]=sha(obj)
  link=list(test['link']);link=[str(core)if x=='libdome-sculpt-core.a'else str((PROVIDER/x).resolve())if x.endswith('.a')and not x.startswith(('-','/'))else x for x in link];link=[str(obj)if x.endswith('/tests/'+name+'.cpp.o')else x for x in link];elf=OUT/('dome-sculpt-'+name+'-test');link[link.index('-o')+1]=str(elf)
  for x in link:
   if x.startswith('/')and pathlib.Path(x).is_file():s['pins'][str(pathlib.Path(x).resolve())]=sha(x)
  run(link,'link-'+name,s);s['pins'][str(elf)]=sha(elf);args=[str(elf),*test['runtime'][1:]];run(args,'run-'+name,s,timeout=float(test['timeout']))
 s['exit_code']=0
except Exception as e:s['exit_code']=1;s['error']=repr(e)
finally:
 s['pin_drift']=[p for p,h in s['pins'].items()if not pathlib.Path(p).is_file()or sha(p)!=h]
 if s['pin_drift']:s['exit_code']=1
 (OUT/'status.json').write_text(json.dumps(s,indent=2));print(json.dumps({'exit_code':s['exit_code'],'error':s.get('error'),'steps':len(s['steps']),'drift':s['pin_drift']}))
sys.exit(s['exit_code'])
