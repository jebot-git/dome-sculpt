import pathlib,json,hashlib,subprocess,tarfile,io
ROOT=pathlib.Path('/home/blux/de-xr/dome-sculpt');BASE=ROOT/'artifacts/humanoid-fitting-quality-proof-20261111';SOURCE=ROOT/'artifacts/humanoid-fitting-quality-20261111';META=ROOT/'artifacts/humanoid-fitting-quality-seal-20261112';VALIDATION=META/'docs/validation';VALIDATION.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
source_head=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip();assert source_head.startswith('9cebf6ab')
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain','--untracked-files=no'],text=True).strip()
SAN=BASE/'sanitize-9cebf6-v4';san=json.loads((SAN/'status.json').read_text());assert san['exit_code']==0 and not san['pin_drift'] and san['unchanged_members']==189
release_routes={'rig-fit-anatomical':('release-9cebf6','run-rig-fit-anatomical'),'avatar':('release-a3684a','run-avatar'),'rig-fit-authoring':('release-a3684a','run-rig-fit-authoring'),'rig-fit-metric':('release-a3684a','run-rig-fit-metric'),'rig-fit-faults':('release-a3684a','run-rig-fit-faults'),'skin-affine':('release-a3684a','run-skin-affine'),'skin-affine-controller':('release-15fab7','run-skin-affine-controller'),'skin-authoring':('release-15fab7','run-skin-authoring'),'rig-fit-import':('release-15fab7','run-rig-fit-import'),'skin-affine-export':('release-final-two','skin-affine-export'),'rig-fit-controller':('release-final-two','rig-fit-controller')}
release={}
for name,(directory,step)in release_routes.items():
 p=BASE/directory/'status.json';d=json.loads(p.read_text());r=next(x for x in d['steps']if x['name']==step);assert r['native_exit']==0 and not d['pin_drift'];log=p.parent/(step+'.log');release[name]={'receipt':str(p),'receipt_sha256':sha(p),'individual_case':r,'log_sha256':sha(log),'log_last_line':log.read_text().strip().splitlines()[-1],'raw_cohort_exit_preserved':d['exit_code']}
assert sum(x['name'].startswith('run-') and x['native_exit']==0 for x in san['steps'])==11
counter=json.loads((BASE/'old4977-final725-counterfactual.json').read_text());assert counter['expected_counterfactual_satisfied'] and counter['actual_native_exit']==1
files=['src/avatar.cpp','src/rig-fit.cpp','src/humanoid-fit-continuation.hpp','tests/rig-fit-anatomical.cpp','tests/skin-affine-controller.cpp','CMakeLists.txt'];product_hashes={p:sha(SOURCE/p)for p in files};public={str(p.relative_to(SOURCE)):sha(p)for p in (SOURCE/'include').rglob('*')if p.is_file()};assert len(public)==103
report={'schema':1,'source_base':'4977fb320afcc9b4d0ed486d4152c62b8018c324','source':source_head,'private_only':True,'product_component':'Reviewed anatomical hand/finger continuation and full-affine explicit terminal world length; existing solver/default/UI commands preserved.','source_hashes':product_hashes,'public_header_count':len(public),'public_header_manifest_sha256':hashlib.sha256(json.dumps(public,sort_keys=True).encode()).hexdigest(),'public_API_layout_or_scene_schema_changed':False,'release':{'scope':'Union of11 individual positive native cases over authenticated current4977 core with2complete owning TUs replaced/191memberbytesunchanged;freshconsumer TUs. Not a whole app build, and original raw failing cohorts remain failing.','cases':release},'sanitize':{'scope':'Audited incremental current-native closure:completed5bb193core,4complete current owning/query TUs replaced,189memberpayloadsunchanged,11freshcompleteconsumerTUs/ELFs. Public103/assets/thirdparty/private dependencies and actual literal compiler flags authenticated. Not a whole4977SAN/applicationbuild.','audit':str(SAN/'audit.json'),'audit_sha256':sha(SAN/'audit.json'),'receipt':str(SAN/'status.json'),'receipt_sha256':sha(SAN/'status.json'),'native_cases':11,'all38_steps_native_exit':0,'core_sha256':sha(SAN/'libdome-sculpt-core.a'),'strict_runtime':{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','suppressions':False},'source_provider_drift':san['pin_drift'],'actual_cases':[x for x in san['steps']if x['name'].startswith('run-')]},'final_counterfactual':{'receipt':str(BASE/'old4977-final725-counterfactual.json'),'receipt_sha256':sha(BASE/'old4977-final725-counterfactual.json'),'same_final725_object':True,'old4977_actual_native_exit':1,'intended_error':counter['log'].strip(),'fixed_actual_native_exit':0},'original_models':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in (SOURCE/'assets/humanoid/vroid').glob('*.vrm')},'limits_preserved':{'fit_default_maximum_work':20000000,'bind_default_maximum_work':50000000,'default_maximum_influences':4,'coordinate_bone_and_mesh_caps':'unchanged','new_native_deadline_seconds':180,'existing_ctest_deadlines':'actual generated CTest commands/properties used by final SAN cases'},'preserved_failures':['release-fb3766: missing NativeAffineEdit definition in test include','release-b35586: overlapping synthetic UV islands','release-a3684a: legacy controller assumes old two-method slider; exact same object fails on original4977','release-15fab7: export runner missing required directory argument; same ELF passes proper command','sanitize audit v1: CTest JSON omitted command for unbuilt configure-only executable','sanitize v2: namespace preflight FileExistsError before any audit/provider mutation','sanitize audit v3: actual CTest aliases differ from executable basename'],'peer_source_review':'merge_contracts read-only review found no blocking hunk; no runtime claim transferred from peer.','remaining_required':['Automatic geometry-only landmark recognition','General original-source/existing-rig mapping and full-domain rest transport','Absent-Toes foot inference, arbitrary bent-hand terminal accuracy and broader source quality','Volume-aware production weighting and broader independent deformation coverage','Physical controller/HMD acceptance and remaining full REQUIREMENTS'],'GPU_GUI_HMD_install_session_or_production_performance_claim':False,'no_live_lane_jobs_or_GPU_lease':True}
# Self-contained metadata-only evidence: decoded member hashes, source versions,
# commands and raw receipts/logs. No ELF/object/archive/model binary payloads.
entries={}
for p in BASE.rglob('*'):
 if not p.is_file()or p.suffix not in {'.json','.log','.py','.cpp','.hpp'}:continue
 rel=p.relative_to(BASE)
 if '/CMakeFiles/'in '/'+str(rel):continue
 entries['proof/'+str(rel)]=p.read_bytes()
for name in files+['LICENSE','THIRD-PARTY.md','assets/humanoid/vroid/SOURCES.json']:
 entries['current-source/'+name]=(SOURCE/name).read_bytes()
for commit in ['4977fb32','fb3766f4','b35586d6','a3684ae5','15fab7c2','9cebf6ab']:
 for name in ['src/avatar.cpp','src/rig-fit.cpp','src/humanoid-fit-continuation.hpp','tests/rig-fit-anatomical.cpp','tests/skin-affine-controller.cpp']:
  r=subprocess.run(['git','-C',str(SOURCE),'show',commit+':'+name],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if r.returncode==0:entries['historical-source/'+commit+'/'+name]=r.stdout
providers={
 'current-release/core-ready.json':ROOT/'artifacts/authoring-hdr-owning-build-20261111/core-ready.json',
 'current-release/compile_commands.json':ROOT/'artifacts/authoring-hdr-owning-build-20261111/release/compile_commands.json',
 'baseline-sanitize/core-ready.json':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/core-ready.json',
 'baseline-sanitize/current4977-core-delta.json':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/current4977-core-delta.json',
 'baseline-sanitize/current4977-ninja-deps.txt':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/current4977-ninja-deps.txt',
 'baseline-sanitize/source-before.json':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/sanitize/source-before.json',
 'baseline-sanitize/compile_commands.json':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/sanitize/compile_commands.json',
 'baseline-sanitize/build-status.json':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/sanitize/status.json',
 'baseline-sanitize/native-status.json':ROOT/'artifacts/radiance-bake-sanitize-proof-20261111/native-sanitize-v1/status.json'}
for name,p in providers.items():entries['provider/'+name]=p.read_bytes()
entries['qualified-index.json']=json.dumps(report,indent=2).encode()
manifest={'members':{name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}for name,data in sorted(entries.items())}};manifest_bytes=json.dumps(manifest,indent=2).encode();entries['MANIFEST.json']=manifest_bytes
archive=VALIDATION/'HUMANOID-FIT-CONTINUATIONS-20261112.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9)as tar:
 for name,data in sorted(entries.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive)as tar:
 actual={m.name:tar.extractfile(m).read()for m in tar if m.isfile()};assert len(actual)==len(entries)and actual==entries
 for name,row in manifest['members'].items():assert len(actual[name])==row['bytes']and hashlib.sha256(actual[name]).hexdigest()==row['sha256']
report['evidence_archive']={'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'decoded_members':len(entries),'decoded_payload_bytes':sum(map(len,entries.values())),'decoded_manifest_sha256':hashlib.sha256(manifest_bytes).hexdigest(),'full_decoded_reverification':0,'binary_ELFs_objects_libraries_and_VRM_payloads_included':False}
receipt=VALIDATION/'HUMANOID-FIT-CONTINUATIONS-20261112.json';receipt.write_text(json.dumps(report,indent=2)+'\n')
doc=(BASE/'assessment-draft.md').read_text();doc+='\nBoth profiles pass all eleven selected native suites; the final new test passes725\nchecks in each. Existing worker tests pass2001 allocation-denial boundaries and51\ncancellation boundaries in each. Release is explicitly a union of qualified\nindividual runs; the original failed cohort statuses remain intact. Strict SAN\npasses all38 build/archive/link/runtime steps in one current closure. Read\n[the validation receipt](validation/HUMANOID-FIT-CONTINUATIONS-20261112.json)\nfor exact scope, source/provider hashes and the fully decoded evidence archive.\n'
(META/'docs/HUMANOID-FIT-CONTINUATIONS-20261112.md').write_text(doc)
assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain','--untracked-files=no'],text=True).strip()
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'decoded_members':len(entries),'decoded_bytes':sum(map(len,entries.values())),'receipt':str(receipt),'receipt_sha256':sha(receipt)}))
