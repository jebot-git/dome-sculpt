#include "dome/avatar.hpp"
#include <nlohmann/json.hpp>
#define CGLTF_IMPLEMENTATION
#include "cgltf.h"
#include <fstream>
#include <iostream>
using namespace dome;
int main(int argc,char**argv)try{
 if(argc!=2)return 2;cgltf_options options{};cgltf_data*data=nullptr;
 if(cgltf_parse_file(&options,argv[1],&data)!=cgltf_result_success)throw std::runtime_error("parse");
 std::unique_ptr<cgltf_data,decltype(&cgltf_free)>guard(data,cgltf_free);
 if(cgltf_load_buffers(&options,data,argv[1])!=cgltf_result_success)throw std::runtime_error("buffers");
 std::ifstream f(argv[1],std::ios::binary);std::vector<char>bytes((std::istreambuf_iterator<char>(f)),{});uint32_t len=0;memcpy(&len,bytes.data()+12,4);auto j=nlohmann::json::parse(bytes.data()+20,bytes.data()+20+len);
 HumanLandmarks l;std::map<std::string,size_t>nodes;
 for(auto&h:j["extensions"]["VRM"]["humanoid"]["humanBones"]){std::string role=h["bone"];if(role.ends_with("ThumbProximal"))role.replace(role.size()-8,8,"Metacarpal");else if(role.ends_with("ThumbIntermediate"))role.replace(role.size()-12,12,"Proximal");size_t n=h["node"];float m[16];cgltf_node_transform_world(data->nodes+n,m);l.points[role]={m[12],m[13],m[14]};nodes[role]=n;}
 l.up=normalized(l.points.at("head")-l.points.at("hips"));auto left=l.points.at("leftUpperArm")-l.points.at("rightUpperArm");l.left=normalized(left-l.up*dot(left,l.up));l.front=cross(l.left,l.up);
 Mesh mesh;
 for(size_t n=0;n<data->nodes_count;++n)if(auto*m=data->nodes[n].mesh){float world[16];cgltf_node_transform_world(data->nodes+n,world);for(size_t p=0;p<m->primitives_count;++p){const auto&prim=m->primitives[p];const cgltf_accessor*a=nullptr;for(size_t k=0;k<prim.attributes_count;++k)if(prim.attributes[k].type==cgltf_attribute_type_position)a=prim.attributes[k].data;if(!a||prim.type!=cgltf_primitive_type_triangles||!prim.indices)throw std::runtime_error("domain");uint32_t start=mesh.positions.size();for(size_t v=0;v<a->count;++v){float q[3];cgltf_accessor_read_float(a,v,q,3);mesh.positions.push_back({world[0]*q[0]+world[4]*q[1]+world[8]*q[2]+world[12],world[1]*q[0]+world[5]*q[1]+world[9]*q[2]+world[13],world[2]*q[0]+world[6]*q[1]+world[10]*q[2]+world[14]});}for(size_t k=0;k<prim.indices->count;++k)mesh.indices.push_back(start+cgltf_accessor_read_index(prim.indices,k));}}
 mesh.normals.assign(mesh.positions.size(),{0,1,0});mesh.validate();HumanFitOptions o;o.maximum_surface_distance=.3f;auto fit=fit_humanoid(mesh,l,o);auto seg=fit.skeleton.segments();std::cout<<"geometry vertices="<<mesh.positions.size()<<" triangles="<<mesh.indices.size()/3<<" roles="<<l.points.size()<<'\n';
 for(std::string role:{"leftHand","rightHand","leftIndexDistal","rightIndexDistal","leftMiddleDistal","rightMiddleDistal"}){auto node=data->nodes+nodes.at(role);Vec3 reference;if(role.ends_with("Hand")){reference=l.points.at(role.substr(0,role.size()-4)+"MiddleProximal")-l.points.at(role);}else{if(node->children_count!=1)throw std::runtime_error("reference end");float m[16];cgltf_node_transform_world(node->children[0],m);reference=Vec3{m[12],m[13],m[14]}-l.points.at(role);}auto b=fit.mapping.joints.at(role);auto axis=seg[b][1]-seg[b][0];std::cout<<role<<" cosine_to_original="<<dot(normalized(reference),normalized(axis))<<" segment_length="<<length(axis)<<'\n';}
 
 auto oracle=fit.skeleton;std::vector<Quat> rotations;for(const auto&[role,b]:fit.mapping.joints){(void)role;(void)b;}
 // Independent reconstruction from declared heads: preserve every global head;
 // only hands with a middle landmark and terminal finger axes differ.
 std::vector<std::string> names(oracle.bones.size());for(auto&[role,b]:fit.mapping.joints)names[b]=role;
 for(size_t b=0;b<oracle.bones.size();++b){auto&bone=oracle.bones[b];const auto&name=names[b];Vec3 axis=seg[b][1]-seg[b][0];
  if(name.ends_with("Hand")){auto middle=name.substr(0,name.size()-4)+"MiddleProximal";if(l.points.contains(middle)){axis=l.points.at(middle)-l.points.at(name);bone.length=length(axis);}}
  bool finger=false;for(auto token:{"Thumb","Index","Middle","Ring","Little"})finger|=name.find(token)!=std::string::npos;
  bool child=false;for(const auto&other:oracle.bones)child|=other.parent==int(b);
  if(finger&&!child&&bone.parent>=0)axis=l.points.at(name)-l.points.at(names[bone.parent]);
  auto q=arcball({0,1,0},normalized(axis));bone.rest.rotation=bone.parent<0?q:rotations[bone.parent].inverse()*q;
  bone.rest.translation=bone.parent<0?l.points.at(name):rotations[bone.parent].inverse().rotate(l.points.at(name)-l.points.at(names[bone.parent]));rotations.push_back(q);
 }
 BindOptions bind;bind.maximum_work=500'000'000;auto oldweights=automatic_bind(mesh,fit.skeleton,bind),newweights=automatic_bind(mesh,oracle,bind);
 auto weight=[](const VertexWeights&row,size_t joint){for(auto i:row)if(i.joint==joint)return i.weight;return 0.f;};
 for(std::string role:{"leftIndexDistal","rightIndexDistal","leftMiddleDistal","rightMiddleDistal"}){const auto b=fit.mapping.joints.at(role);auto node=data->nodes+nodes.at(role);float m[16];cgltf_node_transform_world(node->children[0],m);Vec3 tip{m[12],m[13],m[14]};double oldsum=0,newsum=0;size_t count=0;std::vector<bool>used(mesh.positions.size());for(auto v:mesh.indices)if(!used[v]){used[v]=true;if(length(mesh.positions[v]-tip)<.009f){oldsum+=weight(oldweights.vertices[v],b);newsum+=weight(newweights.vertices[v],b);++count;}}std::cout<<"TIP "<<role<<" visible_vertices="<<count<<" old_weight="<<(count?oldsum/count:0)<<" anatomical_weight="<<(count?newsum/count:0)<<'\n';}
 return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
