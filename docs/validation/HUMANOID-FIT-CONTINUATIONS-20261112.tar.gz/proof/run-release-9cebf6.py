import pathlib,subprocess,hashlib,json,shlex,shutil,time,os
BASE=pathlib.Path('/home/blux/de-xr/dome-sculpt');SRC=BASE/'artifacts/humanoid-fitting-quality-20261111';OLD=BASE/'artifacts/authoring-hdr-union-20261111';PROVIDER=BASE/'artifacts/authoring-hdr-owning-build-20261111/release';OUT=BASE/'artifacts/humanoid-fitting-quality-proof-20261111/release-9cebf6';OUT.mkdir()
STATUS={'source':subprocess.check_output(['git','-C',str(SRC),'rev-parse','HEAD'],text=True).strip(),'commands':[],'pins':{},'steps':[],'scope':'Two authenticated existing owning product TUs and one strengthened fresh full native consumer TU over authenticated current4977 193-member core/support closure;191 unchanged core members. No zero-object whole-build claim.'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def pin(p):p=pathlib.Path(p).resolve();STATUS['pins'][str(p)]=sha(p)
def call(cmd,name,cwd=OUT,timeout=180):
 STATUS['commands'].append({'name':name,'argv':list(map(str,cmd)),'cwd':str(cwd)})
 start=time.monotonic()
 with open(OUT/(name+'.log'),'w')as f:r=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,env={**os.environ,'LIBGL_ALWAYS_SOFTWARE':'1','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'})
 STATUS['steps'].append({'name':name,'native_exit':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(OUT/(name+'.log'))})
 (OUT/'progress.json').write_text(json.dumps(STATUS,indent=2))
 if r.returncode:raise RuntimeError(name+' native exit '+str(r.returncode))
 return r
try:
 pin(__file__)
 assert subprocess.check_output(['git','-C',str(OLD),'rev-parse','HEAD'],text=True).strip()=='4977fb320afcc9b4d0ed486d4152c62b8018c324'
 ready=json.loads((PROVIDER.parent/'core-ready.json').read_text());assert sha(PROVIDER/'libdome-sculpt-core.a')==ready['sha256'];pin(PROVIDER.parent/'core-ready.json')
 changes=set(subprocess.check_output(['git','-C',str(SRC),'diff','--name-only','4977fb32','HEAD'],text=True).splitlines());assert changes=={'src/avatar.cpp','src/rig-fit.cpp','src/humanoid-fit-continuation.hpp','tests/rig-fit-anatomical.cpp','tests/skin-affine-controller.cpp','CMakeLists.txt'}
 for line in subprocess.check_output(['git','-C',str(OLD),'ls-files'],text=True).splitlines():
  p=OLD/line
  if p.is_file():
   pin(p)
   if line not in changes:assert sha(p)==sha(SRC/line),line
 for line in subprocess.check_output(['git','-C',str(SRC),'ls-files'],text=True).splitlines():
  p=SRC/line
  if p.is_file():pin(p)
 commands=json.loads((PROVIDER/'compile_commands.json').read_text());pin(PROVIDER/'compile_commands.json')
 def compile(file,name,template=None):
  entry=next(x for x in commands if x['file']==str(OLD/(template or file)))
  args=shlex.split(entry['command']);assert args[-2]=='-c'
  args=[arg.replace('-I'+str(OLD),'-I'+str(SRC))for arg in args]
  args[args.index('-o')+1]=str(OUT/name);args[-1]=str(SRC/file)
  # Asset string literals intentionally remain the actual4977 provider path;
  # complete tracked assets were compared and pinned above.
  call(args,'compile-'+name)
  pin(OUT/name)
 previous=BASE/'artifacts/humanoid-fitting-quality-proof-20261111/release-a3684a';receipt=json.loads((previous/'status.json').read_text());pin(previous/'status.json')
 for file in ['src/avatar.cpp','src/rig-fit.cpp','src/humanoid-fit-continuation.hpp']:
  assert sha(SRC/file)==receipt['pins'][str(SRC/file)]
 for file in ['avatar.cpp.o','rig-fit.cpp.o']:
  assert sha(previous/file)==receipt['pins'][str(previous/file)];pin(previous/file);shutil.copyfile(previous/file,OUT/file)
 STATUS['reused_qualified_compile_steps']=receipt['steps'][:2]

 core=OUT/'libdome-sculpt-core.a';oldcore=PROVIDER/'libdome-sculpt-core.a';pin(oldcore);shutil.copyfile(oldcore,core)
 call(['ar','r',str(core),str(OUT/'avatar.cpp.o'),str(OUT/'rig-fit.cpp.o')],'replace-two-core-members')
 members=subprocess.check_output(['ar','t',str(oldcore)],text=True).splitlines();assert len(members)==193 and members==subprocess.check_output(['ar','t',str(core)],text=True).splitlines()
 STATUS['core_members']={}
 for member in members:
  oldhash=hashlib.sha256(subprocess.check_output(['ar','p',str(oldcore),member])).hexdigest();newhash=hashlib.sha256(subprocess.check_output(['ar','p',str(core),member])).hexdigest();STATUS['core_members'][member]={'old':oldhash,'current':newhash};assert (oldhash==newhash)==(member not in ['avatar.cpp.o','rig-fit.cpp.o']),member
 pin(core)
 tests=['rig-fit-anatomical']
 for name in tests:
  new=name=='rig-fit-anatomical';template='rig-fit-import' if new else name
  compile('tests/'+name+'.cpp',name+'.o','tests/'+template+'.cpp')
  target='dome-sculpt-'+template+'-test';raw=subprocess.check_output(['ninja','-C',str(PROVIDER),'-t','commands',target],text=True).splitlines()[-1];args=shlex.split(raw);assert args[:2]==[':','&&'] and args[-2:]==['&&',':'];args=args[2:-2]
  args=[str((PROVIDER/arg).resolve()) if (arg.endswith(('.a','.so'))and not arg.startswith(('-','/'))) else arg for arg in args]
  args=[str(core)if arg==str(oldcore)else arg for arg in args]
  args=[str(OUT/(name+'.o'))if arg.endswith('/tests/'+template+'.cpp.o') else arg for arg in args]
  args=[arg if not arg.startswith('-Wl,--dependency-file=')else '-Wl,--dependency-file='+str(OUT/(name+'.link.d')) for arg in args]
  args[args.index('-o')+1]=str(OUT/('dome-sculpt-'+name+'-test'))
  for arg in args:
   if arg.startswith('/')and pathlib.Path(arg).is_file():pin(arg)
  call(args,'link-'+name)
  pin(OUT/('dome-sculpt-'+name+'-test'))
  run=[str(OUT/('dome-sculpt-'+name+'-test'))]+([str(SRC/'assets/humanoid')]if new else [])
  call(run,'run-'+name,timeout=180)
 STATUS['exit_code']=0
except Exception as e:STATUS['exit_code']=1;STATUS['error']=str(e)
finally:
 STATUS['pin_drift']=[p for p,h in STATUS['pins'].items()if not pathlib.Path(p).is_file()or sha(p)!=h]
 if STATUS['pin_drift']:STATUS['exit_code']=1
 (OUT/'status.json').write_text(json.dumps(STATUS,indent=2));print(json.dumps({'exit_code':STATUS['exit_code'],'error':STATUS.get('error'),'steps':STATUS['steps'],'pin_drift':STATUS['pin_drift']}))
raise SystemExit(STATUS['exit_code'])
