import pathlib,json,subprocess,hashlib,shlex,time,os
ROOT=pathlib.Path('/home/blux/de-xr/dome-sculpt');BASE=ROOT/'artifacts/humanoid-fitting-quality-proof-20261111';SRC=ROOT/'artifacts/humanoid-fitting-quality-20261111';OLD=ROOT/'artifacts/authoring-hdr-union-20261111';PROVIDER=ROOT/'artifacts/authoring-hdr-owning-build-20261111/release';PREV=BASE/'release-15fab7';OUT=BASE/'release-final-two';OUT.mkdir()
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();previous=json.loads((PREV/'status.json').read_text());pins=dict(previous['pins']);pins[str(PREV/'status.json')]=sha(PREV/'status.json');pins[str(pathlib.Path(__file__).resolve())]=sha(__file__);status={'source':previous['source'],'pins':pins,'steps':[]}
def run(cmd,name):
 t=time.monotonic()
 with open(OUT/(name+'.log'),'w')as f:r=subprocess.run(cmd,cwd=OUT,stdout=f,stderr=subprocess.STDOUT,timeout=180,env={**os.environ,'LIBGL_ALWAYS_SOFTWARE':'1'})
 status['steps'].append({'name':name,'argv':cmd,'native_exit':r.returncode,'seconds':time.monotonic()-t,'log_sha256':sha(OUT/(name+'.log'))});assert r.returncode==0,name
try:
 assert all(sha(p)==h for p,h in pins.items())
 # This target's actual CTest supplies an output-directory argument. Preserve
 # the previous runner's native2/no-argument result; no source/ELF changed.
 run([str(PREV/'dome-sculpt-skin-affine-export-test'),str(OUT/'skin-affine-exports')],'skin-affine-export')
 target='dome-sculpt-rig-fit-controller-test';commands=json.loads((PROVIDER/'compile_commands.json').read_text());entry=next(x for x in commands if x['file']==str(OLD/'tests/rig-fit-controller.cpp'));cmd=shlex.split(entry['command']);cmd=[x.replace('-I'+str(OLD),'-I'+str(SRC))for x in cmd];cmd[cmd.index('-o')+1]=str(OUT/'rig-fit-controller.o');cmd[-1]=str(SRC/'tests/rig-fit-controller.cpp');run(cmd,'compile-rig-fit-controller')
 raw=subprocess.check_output(['ninja','-C',str(PROVIDER),'-t','commands',target],text=True).splitlines()[-1];cmd=shlex.split(raw)[2:-2];cmd=[str((PROVIDER/x).resolve())if x.endswith(('.a','.so'))and not x.startswith(('-','/'))else x for x in cmd];cmd=[str(PREV/'libdome-sculpt-core.a')if x==str(PROVIDER/'libdome-sculpt-core.a')else x for x in cmd];cmd=[str(OUT/'rig-fit-controller.o')if x.endswith('/tests/rig-fit-controller.cpp.o')else x for x in cmd];cmd=[x if not x.startswith('-Wl,--dependency-file=')else '-Wl,--dependency-file='+str(OUT/'rig-fit-controller.link.d')for x in cmd];cmd[cmd.index('-o')+1]=str(OUT/target)
 for x in cmd:
  if x.startswith('/')and pathlib.Path(x).is_file():pins[x]=sha(x)
 run(cmd,'link-rig-fit-controller');pins[str(OUT/target)]=sha(OUT/target);run([str(OUT/target)],'rig-fit-controller');status['exit_code']=0
except Exception as e:status['exit_code']=1;status['error']=str(e)
finally:
 status['pin_drift']=[p for p,h in pins.items()if not pathlib.Path(p).is_file()or sha(p)!=h]
 if status['pin_drift']:status['exit_code']=1
 (OUT/'status.json').write_text(json.dumps(status,indent=2));print(json.dumps({k:v for k,v in status.items()if k!='pins'}))
raise SystemExit(status['exit_code'])
