from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import time

out=Path(__file__).resolve().parent
artifacts=out.parent
source=artifacts/'cut-owning-material-source-20261126'
donor=artifacts/'cut-owning-material-validation-20261126/release'
public=artifacts/'creator-public-build-20261126'
comp=public/'wayland-reference/dome-compositor'
probe=artifacts/'combined-atlas-hdr-preview-full-20261126/build/libdome-sculpt-test-widgets.so'
def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):
    return json.loads(path.read_text())
state={'candidate':git('rev-parse','HEAD'),'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def record(**values):
    state.update(values)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')
def run(cmd,log,timeout):
    with (out/log).open('w') as dest:
        print(shlex.join(map(str,cmd)),file=dest,flush=True)
        subprocess.run(cmd,cwd=out,stdout=dest,stderr=subprocess.STDOUT,check=True,timeout=timeout)
try:
    assert state['candidate'] == os.environ['DOME_CUT_CANDIDATE'] and not git('status','--porcelain')
    record(phase='wait for exact native product')
    unit='ds-cut-owning-material-release-20261126.service'
    while True:
        prior=read(donor/'status.json')
        if prior['terminal']:break
        assert subprocess.check_output(['systemctl','--user','is-active',unit],text=True).strip()=='active'
        time.sleep(2)
    assert prior['exit']==0 and prior['candidate']==state['candidate']
    app=donor/'build'/'dome-sculpt'
    helper=artifacts/'retained-smooth-atlas-public-20261126'/'release'/'fixture'
    while not (helper.parent/'fixture.sha256').is_file():
        subprocess.run(['systemctl','--user','is-active','--quiet','ds-retained-smooth-atlas-public-release-20261126.service'],check=True)
        time.sleep(1)
    assert prior['app_sha256']==sha(app) and (helper.parent/'fixture.sha256').read_text().strip()==sha(helper)
    comp_status=read(comp.parent/'compositor-build-status.json')
    assert comp_status['exit']==0 and comp_status['source']=='acc2b70ae61dedec2a23727f67c60c0303d0f76f' and comp_status['output_sha256']==sha(comp)
    record(core_sha256=prior['core_sha256'],fixture_sha256=sha(helper),
           compositor_sha256=sha(comp),compositor_source=comp_status['source'],probe_sha256=sha(probe))
    workflow=out/'workflow'
    workflow.mkdir(exist_ok=True)
    settings={
        'PATH':str(public/'private-bin-v3')+':/usr/bin', 'HOME':'/tmp',
        'PYTHONPATH':str(public/'private-python'), 'PYTHONDONTWRITEBYTECODE':'1',
        'DOME_COMPOSITOR':str(comp),'DOME_CAGE_HELPER':str(helper),'DOME_CAGE_APP':str(app),
        'DOME_CAGE_PROBE':str(probe),'DOME_CAGE_WL_OUT':str(workflow),'DOME_CAGE_TEXTURE_SET':'1',
        'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:'+str(public/'private-x11/usr/lib64')+':/usr/lib64',
    }
    bwrap=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
           '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    for key,value in settings.items():bwrap.extend(['--setenv',key,value])
    record(phase='exercise the Wayland universal menu and FLTK editor',app_sha256=sha(app))
    run([*bwrap,'/usr/bin/python3.14',out/'replay.py'],'wayland.log',360)
    checks=read(workflow/'report.json')['checks']
    assert all(row['passed'] for row in checks) and len(checks)==17
    record(phase='complete',terminal=True,exit=0,checks=len(checks),report_sha256=sha(workflow/'report.json'))
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
