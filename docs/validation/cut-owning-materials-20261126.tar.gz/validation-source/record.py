from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
from xml.etree import ElementTree

root=Path(__file__).resolve().parents[2]
artifacts=root/'artifacts'
base=artifacts/'cut-owning-material-validation-20261126'
public=artifacts/'cut-owning-material-public-20261126'
wayland=artifacts/'cut-owning-material-wayland-20261126'
source='fadacc0076aef8f7b2ed8ec5a9a9cfbbbaa8ca17'
validation=root/'docs/validation'
files={}

def load(path):
    return json.loads(path.read_text())

def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def add(parent,prefix,*names):
    for name in names:
        path=parent/name
        assert path.is_file(),path
        files[prefix+'/'+name]=path

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

def verified(path):
    status=load(path/'status.json')
    assert status['candidate']==source and status['exit']==0,status
    return status

native={}
openxr={}
for profile in ('release','asan'):
    path=base/profile
    state=verified(path)
    assert state['terminal'] and state['tests']==12 and not state['failures']
    assert digest(path/'ctest.log')==state['ctest_sha256']
    assert digest(path/'build/cut-tests.xml')==state['junit_sha256']
    tree=ElementTree.parse(path/'build/cut-tests.xml')
    passed={x.attrib['name'] for x in tree.findall('.//testcase') if
            x.find('failure') is None and x.find('skipped') is None}
    assert {'cut-authoring','cut-cancellation-boundaries','colored-cut-render',
            'colored-cut-document','colored-cut-held-publication'}<=passed and len(passed)==12
    text=(path/'ctest.log').read_text()
    assert '92 checks passed' in text
    assert text.count('Spatial samples keep the FLOAT brush at its actual location')==2
    assert text.count('GLB retains the exact FLOAT cut and its hidden editable source')==2
    native[profile]=state|{'passed':sorted(passed)}
    add(path,'native/'+profile,'status.json','ctest.log','build/cut-tests.xml','dome-sculpt-link.log',
        'configure.log','document-cut.cpp.log','cut-authoring.cpp.log','scene.cpp.log','emission-export.cpp.log')
    xp=public/profile
    x=verified(xp)
    assert x['checks']==21 and x['app_sha256']==state['app_sha256']
    assert digest(xp/'xr/report.json')==x['report_sha256']
    openxr[profile]=x
    add(xp,'openxr/'+profile,'status.json','xr.log','xr/report.json',
        *[f'xr/{case}.{suffix}' for case in ('accept','held','unconfirmed') for suffix in ('log','json')])
    if profile=='asan':
        assert 'Arc(tm) A770' in x['renderer'] and digest(xp/'render.log')==x['render_log_sha256']
        add(xp,'openxr/'+profile,'runner.py','render.log')
add(base,'validation-source','run.py','record.py')
add(public,'validation-source/openxr','run.py')

desktop=verified(wayland)
assert desktop['checks']==17 and desktop['app_sha256']==native['release']['app_sha256']
add(wayland,'nested-wayland','run.py','replay.py','status.json','wayland.log','workflow/report.json')
assert git('diff','--name-only',source,'HEAD','--','src','include','tests','CMakeLists.txt')==''
archive=validation/'cut-owning-materials-20261126.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as stream:
        for label,path in sorted(files.items()):
            info=stream.gettarinfo(str(path),arcname=label)
            info.uid=info.gid=info.mtime=0
            info.mode=0o644
            info.uname=info.gname=''
            with path.open('rb') as item:
                stream.addfile(info,item)
with tarfile.open(archive,'r:gz') as check:
    assert len(check.getmembers())==len(files)
    for name,path in files.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==digest(path)
receipt={'product':source,'main_merge':git('rev-parse','HEAD'),'physical_headset':False,
         'scope':'Plane cuts from actual current editable material fields. Ordered cancellation and retry, exact field assignment, FLOAT emission, axis-aligned and reflected/sheared inputs, independent cap, native history and GLB payload, corner-color and compositor regression coverage.',
         'native':native,'synthetic_openxr':openxr,'nested_wayland_bake_smoke':desktop,
         'raw':{'archive':archive.name,'sha256':digest(archive),'members':{name:digest(path) for name,path in sorted(files.items())}}}
(validation/'cut-owning-materials-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(files),'members',receipt['raw']['sha256'])
