from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

home = Path(__file__).resolve().parent
artifacts = home.parent
source = artifacts/'cut-owning-material-source-20261126'
profile = sys.argv[1]
asan = profile == 'asan'
out = home/profile
out.mkdir(exist_ok=True)
build = out/'build'
prior = artifacts/'sculpt-cold-chunk-validation-20261126'/profile
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk = artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
test_targets = {
    'cut-authoring': 'dome-sculpt-cut-authoring-test',
    'cut-cancellation-boundaries': 'dome-sculpt-cut-boundaries-test',
    'colored-plane-cut': 'dome-sculpt-cut-color-test',
    'colored-cut-boundaries': 'dome-sculpt-cut-color-boundaries-test',
    'colored-cut-admission': 'dome-sculpt-cut-color-admission-test',
    'colored-cut-document': 'dome-sculpt-cut-color-document-test',
    'colored-cut-held-publication': 'dome-sculpt-cut-color-publication-test',
    'colored-cut-publication-0': 'dome-sculpt-cut-color-publication-test',
    'colored-cut-render': 'dome-sculpt-cut-color-render-test',
    'sculpt-chunk-pipeline': 'dome-sculpt-sculpt-chunk-pipeline-test',
    'dome-sculpt-texture-set-native': 'dome-sculpt-texture-set-native-test',
    'texture-painting': 'dome-sculpt-paint-test',
}
start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def sha(file):
    with Path(file).open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

status = {'candidate':git('rev-parse','HEAD'), 'profile':profile, 'terminal':False,
          'fltk':str(sdk),'invocation':os.getenv('INVOCATION_ID')}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic()-start,2))
    temp=out/'status.tmp'
    temp.write_text(json.dumps(status,indent=2)+'\n')
    temp.replace(out/'status.json')

def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check)

try:
    expected=os.environ['DOME_CUT_CANDIDATE']
    assert expected==status['candidate'] and not git('status','--porcelain')
    opts = []
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    record(phase='configure canonical toolkit')
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,out)
    baseline=json.loads((prior/'status.json').read_text())
    parent=baseline['candidate']
    assert parent=='a2b46ea72c9188c3ec48dcfa216873f078bd6c14' and baseline['terminal'] and baseline['exit']==0
    changed=git('diff','--name-only',parent,'HEAD','--','src','include','third_party','assets').splitlines()
    assert all(path in ('src/document-cut.cpp','src/cut-authoring.cpp','src/cut-color.cpp','src/scene.cpp','src/emission-export.cpp') for path in changed) and changed
    database=json.loads((build/'compile_commands.json').read_text())

    def compile(entry,directory):
        cmd=shlex.split(entry['command'])
        target = cmd.index('-o')+1
        original = cmd[target]
        obj=directory/(Path(entry['file']).name+'.o')
        cmd[target]=str(obj)
        invoke(cmd,obj.relative_to(out).with_suffix('.log'),500)
        return original,obj

    record(phase='build product changes against verified complete core',donor=parent,rebuilt=changed)
    parent_core=prior/'libdome-sculpt-core.a'
    assert sha(parent_core)==baseline['core_sha256']
    owners=[next(entry for entry in database if entry['file']==str(source/path) and
              'CMakeFiles/dome-sculpt-core.dir/' in entry['command']) for path in changed]
    objects=[compile(entry,out)[1] for entry in owners]
    core=out/parent_core.name
    shutil.copyfile(parent_core,core)
    invoke(['ar','rs',core,*objects],'core-index.log')
    assert all(hashlib.sha256(subprocess.check_output(['ar','p',core,obj.name])).hexdigest()==sha(obj) for obj in objects)
    render=artifacts/'retained-smooth-atlas-validation-20261126'/profile/'libdome-sculpt-render.a'
    xr=artifacts/'retained-smooth-atlas-validation-20261126'/profile/'libdome-sculpt-xr.a'
    assert sha(render)==baseline['render_sha256'] and sha(xr)==baseline['xr_sha256']
    archives={a.name:str(a) for a in (core,render,xr)}

    def make_target(target):
        directory=out/'tests'/target
        directory.mkdir(parents=True,exist_ok=True)
        entries=[entry for entry in database if f'CMakeFiles/{target}.dir/' in entry['command']]
        assert entries
        objects=dict(compile(entry,directory) for entry in entries)
        last=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
        words=[word for word in shlex.split(last)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
        assert all(x in words for x in objects)
        words=[str(objects[word]) if word in objects else word for word in words]
        words=[archives.get(word,str(support/word)) if word.startswith('lib') and word.endswith('.a') else word for word in words]
        invoke(words,directory.relative_to(out)/'link.log',500)
        return target,sha(build/target)

    record(phase='build registered native and render tests',core_sha256=sha(core),
           parent_core_sha256=sha(parent_core),owned_objects={o.name:sha(o) for o in objects})
    with ThreadPoolExecutor(max_workers=4 if not asan else 3) as pool:
        binaries=dict(pool.map(make_target,sorted(set(test_targets.values()))))
    app=build/'dome-sculpt'
    assert sha(prior/'build/dome-sculpt')==baseline['app_sha256']
    link=shlex.split((prior/'dome-sculpt-link.log').read_text().splitlines()[0])
    link=[archives.get(Path(word).name,word) for word in link]
    link[link.index('-o')+1]=str(app)
    invoke(link,'dome-sculpt-link.log',500,support)
    record(phase='run registered test fixtures',binaries=binaries,app_sha256=sha(app),
           render_sha256=sha(render),xr_sha256=sha(xr))

    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        environment.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in environment.items():
        isolated.extend(['--setenv',key,value])
    # Emit JUnit before enforcing success so a failed case can be diagnosed
    # against its exact executable while preserving all other results.
    report=build/'cut-tests.xml'
    run=invoke([*isolated,'ctest','--test-dir',build,'-R','^('+'|'.join(test_targets)+')$',
                '--output-on-failure','-V','-j3','--output-junit',report],
               'ctest.log',900,check=False)
    from xml.etree import ElementTree
    cases={case.attrib['name']:case for case in ElementTree.parse(report).getroot().findall('.//testcase')}
    assert set(cases)==set(test_targets)
    failure=sorted(name for name,case in cases.items() if case.find('failure') is not None or case.find('skipped') is not None)
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    record(phase='complete',terminal=True,exit=run.returncode,failures=failure,tests=len(cases),
           ctest_sha256=sha(out/'ctest.log'),junit_sha256=sha(report))
    assert run.returncode==0 and not failure
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
