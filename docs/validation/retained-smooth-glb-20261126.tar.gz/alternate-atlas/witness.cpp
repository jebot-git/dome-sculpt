// SPDX-License-Identifier: GPL-3.0-or-later
// Force portable alternate coordinates on a real retained native Bake owner.
#define portable_texture_set_field probe_portable_texture_set_field
#include "texture-set-portable-field.cpp"
#undef portable_texture_set_field
#include "dome/scene.hpp"
#include <iostream>

int main(int argc, char **argv) try {
 using namespace dome;
 using namespace dome::detail;
 if(argc!=2)return 2;
 const auto scene=Scene::load(argv[1]);
 const auto field=active_texture_set(scene.active());
 const auto world=scene.world_matrix(scene.active().id);
 const auto &preview=*field.source->source_preview();
 const auto source_size=preview.native_bake()->width;
 const auto domain=field.domain->triangles();
 const TextureSetLimits limits;
 size_t work=0;
 auto portable=probe_portable_texture_set_field(field,world,work,limits);
 const auto original=portable.corners;
 const auto size=portable_normal_export_max_resolution(source_size);
 auto mapped=reproject_normal(preview,domain,portable.corners,world,source_size,size,true,work,limits);
 if(!mapped || mapped->width!=size)throw std::runtime_error("Alternate bake atlas did not qualify");
 PaintSourceTexture image;
 image.image=std::make_shared<const Image>(std::move(*mapped));
 image.wrap_s=image.wrap_t=33071;
 image.min_filter=image.mag_filter=9729;
 size_t checked=0;
 double maximum=0;
 bool changed=false;
 for(size_t i=0;i<domain.size();++i) {
  std::array<std::array<float,2>,3> uv;
  std::array<Vec3,3> n,t,b;
  for(size_t k=0;k<3;++k){
   const auto &c=portable.corners[i*3+k],&old=original[i*3+k];
   if(c.paint!=old.paint||length(c.normal-old.normal)>0||c.tangent!=old.tangent)
    throw std::runtime_error("Alternate coordinates mutated a non-role stream");
   changed|=c.role!=old.role;
   uv[k]=c.role;
   n[k]=affine_unit(world.normal({c.normal.x,c.normal.y,c.normal.z}));
   t[k]=affine_unit(world.direction({c.tangent[0],c.tangent[1],c.tangent[2]}));
   const float hand=world.orientation()==AffineOrientation::Reversing?-1.f:1.f;
   b[k]=normalized(cross(n[k],t[k]))*(c.tangent[3]*hand);
  }
  constexpr int grid=100;
  for(int x=0;x<=grid;++x)for(int y=0;y<=grid-x;++y){
   const std::array<double,3> w{double(x)/grid,double(y)/grid,double(grid-x-y)/grid};
   Vec3 N{},T{},B{};
   std::array<double,2> coord{};
   for(size_t k=0;k<3;++k){
    N+=n[k]*float(w[k]);T+=t[k]*float(w[k]);B+=b[k]*float(w[k]);
    for(size_t r=0;r<2;++r)coord[r]+=uv[k][r]*w[k];
   }
   const auto cell=sample_source_texture(image,float(coord[0]),float(coord[1]),false);
   const auto actual=normalized(normalized(T)*(2*cell[0]-1)+normalized(B)*(2*cell[1]-1)+
                                normalized(N)*(2*cell[2]-1));
   const auto expected=field.source->normal(domain[i],w,world,true);
   const double error=std::atan2(length(cross(actual,expected)),dot(actual,expected));
   maximum=std::max(maximum,error);
   if(error>.02)throw std::runtime_error("Alternate coordinates lost filtered direction");
   ++checked;
  }
 }
 if(!changed)throw std::runtime_error("Fixture did not exercise alternate coordinates");
 std::cout<<"PASS four-way texel and dense barycentric agreement for "<<checked
          <<" samples, peak radians "<<maximum<<", atlas "<<source_size<<" to "<<size<<'\n';
 return 0;
}catch(const std::exception &e){
 std::cerr<<"FAIL "<<e.what()<<'\n';
 return 1;
}
