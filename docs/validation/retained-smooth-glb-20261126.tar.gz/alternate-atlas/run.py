from pathlib import Path
import json
import shlex
import subprocess

out = Path(__file__).resolve().parent
qualified = out.parent/'retained-smooth-atlas-validation-20261126/release'
build = qualified/'build'
row = next(item for item in json.loads((build/'compile_commands.json').read_text())
           if item['file'].endswith('/tests/texture-set-source-export.cpp'))
words = shlex.split(row['command'])
original_object = out/'witness.o'
words[words.index('-o')+1]=str(original_object)
words[-1] = str(out/'witness.cpp')
with (out/'build.log').open('w') as log:
    subprocess.run(words,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    link=shlex.split((qualified/'dome-sculpt-texture-set-source-export-link.log').read_text().splitlines()[0])
    link[link.index(str(qualified/'texture-set-source-export.cpp.o'))]=str(original_object)
    executable=out/'witness'
    link[link.index('-o')+1]=str(executable)
    subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    child=subprocess.run([executable,build/'texture-set-retained-native-target/native-target-smooth-portable.dsculpt'],
                         stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
    (out/'run.log').write_text(child.stdout)
    print(child.stdout,end='')
    raise SystemExit(child.returncode)
