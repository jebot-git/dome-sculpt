from concurrent.futures import ThreadPoolExecutor
import re
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base.parent / 'retained-smooth-atlas-source-20261126'
profile = sys.argv[1]
sanitize = profile == 'asan'
out = base / profile
out.mkdir(mode=0o700, exist_ok=True)
build = out / 'build'
sdk = base.parent / 'sdk-20261126/toolkit-sanitize' if sanitize else Path('/opt/fltk-vr/toolkit')
targets = {
    'dome-sculpt-texture-set-native': 'dome-sculpt-texture-set-native-test',
    'dome-sculpt-texture-set-source-export': 'dome-sculpt-texture-set-source-export-test',
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
    'bake-recipes': 'dome-sculpt-bake-recipes-test',
    'bake-custom-cage': 'dome-sculpt-bake-cage-test',
    'bake-workflow': 'dome-sculpt-bake-workflow-test',
    'bake-controls': 'dome-sculpt-bake-controls-test',
}

start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git', '-C', source, *args], text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

status = {'candidate': git('rev-parse', 'HEAD'), 'profile': profile, 'terminal': False,
          'invocation': os.getenv('INVOCATION_ID'), 'fltk': str(sdk)}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic() - start, 2))
    tmp = out / 'status.tmp'
    tmp.write_text(json.dumps(status, indent=2) + '\n')
    tmp.replace(out / 'status.json')

def run(argv, logname, cwd=None, timeout=1800):
    with (out / logname).open('w') as log:
        print(shlex.join(map(str, argv)), file=log, flush=True)
        subprocess.run(argv, cwd=cwd, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)

try:
    assert status['candidate'] == os.environ['DOME_BAKE_CANDIDATE'] and not git('status','--porcelain')
    record(phase='configure')
    options = []
    if sanitize:
        options.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C', 'CXX'))
        options.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C', 'CXX'))
    run(['cmake', '-S', source, '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DDOME_COMPUTE_BACKEND=CPU', f'-DFLTK_DIR={sdk}/share/fltk',
         *options], 'configure.log', timeout=120)
    donor = '55a5bc69be9db6641c5df2227b5f87108869564b'
    prior = base.parent / 'texture-set-recipe-and-hdr-validation-20261126' / profile
    support = prior / 'build'
    qualified = base.parent / 'retained-smooth-final-validation-20261126' / profile
    while True:
        upstream = json.loads((qualified/'status.json').read_text())
        if upstream['terminal']:
            break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        f'ds-retained-smooth-final-{profile}-20261126.service'], check=True)
        time.sleep(1)
    active_status = json.loads((qualified/'status.json').read_text())
    assert active_status['candidate']==donor and active_status['terminal'] and active_status['exit']==0
    parent_core = qualified/'libdome-sculpt-core.a'
    assert sha(parent_core)==active_status['core_sha256']
    assert sha(qualified/'build'/'dome-sculpt')==active_status['app_sha256']
    for kind in ('render','xr'):
        assert sha(qualified/f'libdome-sculpt-{kind}.a')==active_status[kind+'_sha256']
    active = qualified
    differences = git('diff','--name-only',donor,'HEAD','--','src','include','third_party','assets').splitlines()
    assert all(p.startswith(('src/','include/')) for p in differences)
    changes = set(differences)
    frontend = {'src/app.cpp','src/texture-set-editor.cpp'} & changes
    owners = {p for p in differences if p.endswith('.cpp') and p not in frontend and p!='src/render.cpp'}
    headers = {p for p in differences if p.endswith('.hpp')}
    render_owners = set()
    xr_owners = set()
    listing = subprocess.check_output(['ninja','-C',support,'-t','deps'],text=True)
    member = ''
    for line in listing.splitlines():
        if not line.startswith(' '):
            member = line.split(': #deps',1)[0]
        elif any(line.endswith('/'+p) for p in headers):
            if member.startswith('CMakeFiles/dome-sculpt-core.dir/src/'):
                owners.add(member.split('.dir/',1)[1][:-2])
            elif member.startswith('CMakeFiles/dome-sculpt-render.dir/src/'):
                render_owners.add(member.split('.dir/',1)[1][:-2])
            elif member.startswith('CMakeFiles/dome-sculpt-xr.dir/src/'):
                xr_owners.add(member.split('.dir/',1)[1][:-2])
            elif member.startswith('CMakeFiles/dome-sculpt.dir/src/'):
                frontend.add(member.split('.dir/',1)[1][:-2])
            else:
                assert '.dir/tests/' in member, member
    database = json.loads((build/'compile_commands.json').read_text())
    def compile_path(owner, target):
        match = next(row for row in database if row['file'] == str(source / owner)
                     and f'CMakeFiles/{target}.dir/' in row['command'])
        words = shlex.split(match['command'])
        obj = out / (Path(owner).name + '.o')
        position = words.index('-o') + 1
        original = words[position]
        words[position] = str(obj)
        run(words, obj.name + '.log', build, 900)
        return original, obj
    record(phase='build all affected core owners', donor=donor, rebuilt=sorted(owners),frontend=sorted(frontend),render_owners=sorted(render_owners))
    with ThreadPoolExecutor(max_workers=6 if not sanitize else 5) as pool:
        changed = list(pool.map(lambda owner: compile_path(owner, 'dome-sculpt-core'), sorted(owners)))
    core = out / parent_core.name
    run(['cp', '--reflink=auto', parent_core, core], 'core-copy.log')
    run(['ar', 'r', core, *[obj for _, obj in changed]], 'core-update.log')
    run(['ranlib', core], 'core-index.log')
    digest_objects = {obj.name: sha(obj) for _, obj in changed}
    assert all(hashlib.sha256(subprocess.check_output(['ar','p',core,name])).hexdigest()==digest
               for name,digest in digest_objects.items())
    def refreshed_archive(target, owners, parent):
        archive=out/f'lib{target}.a'
        run(['cp','--reflink=auto',parent/archive.name,archive],target+'-copy.log')
        if owners:
            with ThreadPoolExecutor(max_workers=2) as pool:
                objects = list(pool.map(lambda owner: compile_path(owner,target),sorted(owners)))
            run(['ar','r',archive,*[obj for _,obj in objects]],target+'-update.log')
            run(['ranlib',archive],target+'-index.log')
            assert all(hashlib.sha256(subprocess.check_output(['ar','p',archive,obj.name])).hexdigest()==sha(obj)
                       for _,obj in objects)
        return archive
    render=refreshed_archive('dome-sculpt-render',render_owners,active)
    xr=refreshed_archive('dome-sculpt-xr',xr_owners,active)
    atlas = support / 'libxatlas.a' 
    assert git('diff','--name-only',donor,'HEAD','--','third_party/xatlas') == ''
    record(phase='build exact registered tests against matching core', core_sha256=sha(core),
           parent_core_sha256=sha(parent_core), objects=digest_objects, atlas_sha256=sha(atlas))
    record(render_sha256=sha(render), render_rebuilt=sorted(render_owners),xr_sha256=sha(xr),xr_rebuilt=sorted(xr_owners))
    for name, target in targets.items():
        link = subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
        link = [word for word in shlex.split(link)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
        entry = next(row for row in database if f'CMakeFiles/{target}.dir/' in row['command'])
        old_obj, obj = compile_path(str(Path(entry['file']).relative_to(source)), target)
        link[link.index(old_obj)] = str(obj)
        link[link.index('libdome-sculpt-core.a')] = str(core)
        link[link.index('libxatlas.a')] = str(atlas)
        for index, value in enumerate(link):
            if value.startswith('lib') and value.endswith('.a'):
                if value == render.name:
                    link[index] = str(render)
                    continue
                if value == xr.name:
                    link[index] = str(xr)
                    continue
                assert (support/value).is_file(), value
                link[index] = str(support/value)
        run(link, name+'-link.log', build)
    record(phase='link the full FLTK and OpenXR application to the exact updated core')
    link = shlex.split((qualified/'dome-sculpt-link.log').read_text().splitlines()[0])
    for path in (core,render,xr):
        index=next(i for i,w in enumerate(link) if Path(w).name==path.name)
        link[index]=str(path)
    for owner in sorted(frontend):
        old, obj = compile_path(owner, 'dome-sculpt')
        index=next(i for i,w in enumerate(link) if w.endswith('/'+Path(old).name))
        link[index]=str(obj)
    link[link.index('-o')+1]=str(build/'dome-sculpt')
    run(link,'dome-sculpt-link.log',support)
    record(app_sha256=sha(build/'dome-sculpt'))
    record(phase='private native CTest', binaries={name:sha(build/target) for name,target in targets.items()})
    native = ['bwrap', '--die-with-parent', '--unshare-all', '--ro-bind', '/', '/',
              '--bind', build, build, '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp',
              '--tmpfs', '/run/user', '--clearenv', '--setenv', 'PATH', '/usr/bin:/bin',
              '--setenv', 'HOME', '/tmp', '--setenv', 'LD_LIBRARY_PATH',
              f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
    if sanitize:
        native.extend(['--setenv', 'ASAN_OPTIONS', 'detect_leaks=1:halt_on_error=1',
                       '--setenv', 'UBSAN_OPTIONS', 'halt_on_error=1:print_stacktrace=1'])
    run([*native,'ctest','--test-dir',build,'-R','^('+'|'.join([*targets,'texture-set-active-bake','texture-set-retained-bake-source','texture-set-prepared-recipe-references','texture-set-retained-bake-target','texture-set-retained-native-target'])+')$','--output-on-failure','-V','-j3'],
        'ctest.log', timeout=1400)
    log = (out/'ctest.log').read_text()
    expected = 12
    assert f'100% tests passed, 0 tests failed out of {expected}' in log and re.search(r'PASS \d+ native-normal retained target checks', log)
    assert git('rev-parse', 'HEAD') == status['candidate'] and not git('status', '--porcelain')
    public_dir = build/'portable-retained-smooth'
    public_dir.mkdir(exist_ok=True)
    fixture = build/'texture-set-retained-native-target/native-target-smooth-portable.dsculpt'
    assert fixture.is_file()
    report = [float(value) for value in re.findall(r'PORTABLE normal peak radians ([\d.e+-]+)',log)]
    assert len(report)==10 and .001 < max(report) <= .02
    for item in ('native-normal-smooth-bake.glb','native-normal-smooth-editable.glb'):
        product = fixture.parent/item
        assert product.is_file() and product.stat().st_size>100
    for n in range(2):
        run([*native,build/'dome-sculpt','--export-project',fixture,public_dir/f'public-{n}.glb'],
            f'public-{n}.log',timeout=180)
    assert sha(public_dir/'public-0.glb') == sha(public_dir/'public-1.glb') == sha(fixture.parent/'native-normal-smooth-bake.glb')
    record(phase='complete',terminal=True,exit=0,tests=expected,ctest_sha256=sha(out/'ctest.log'),
           directional_samples=10*2*325,maximum_angle=max(report),portable_glb_sha256=sha(public_dir/'public-0.glb'),
           editable_glb_sha256=sha(fixture.parent/'native-normal-smooth-editable.glb'))
except Exception as error:
    record(terminal=True, exit=1, error=repr(error))
    raise
