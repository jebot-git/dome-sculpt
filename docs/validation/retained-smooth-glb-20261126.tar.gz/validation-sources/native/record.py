from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parents[2]
artifacts = root/'artifacts'
product = '33bd24609e8fc701283b23aa5057955e908df583'
validation = root/'docs/validation'
native = artifacts/'retained-smooth-atlas-validation-20261126'
graphics = artifacts/'retained-smooth-atlas-graphics-20261126'
validator = artifacts/'retained-smooth-atlas-validator-20261126'
atlas = artifacts/'retained-smooth-final-atlas-20261126'
xr = artifacts/'retained-smooth-atlas-public-20261126'
wayland = artifacts/'retained-smooth-atlas-wayland-20261126'
whole = artifacts/'retained-texture-set-full-release-20261126'
triage = artifacts/'current-whole-regression-triage-20261126'

def read(file):
    return json.loads(file.read_text())

def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

def success(path):
    data = read(path/'status.json')
    assert data['candidate']==product and data['terminal'] and data['exit']==0, path
    return data

def add(items, prefix, parent, *files):
    for name in files:
        path = parent/name
        assert path.is_file(), path
        items[prefix+'/'+name] = path

def archive(out, items):
    with out.open('wb') as file, gzip.GzipFile(filename='', mode='wb', fileobj=file, mtime=0) as packed:
        with tarfile.open(fileobj=packed, mode='w') as bundle:
            for filename, path in sorted(items.items()):
                record = bundle.gettarinfo(str(path), arcname=filename)
                record.uid = record.gid = record.mtime = 0
                record.mode = 0o644
                record.uname = record.gname = ''
                with path.open('rb') as body:
                    bundle.addfile(record, body)
    with tarfile.open(out,'r:gz') as bundle:
        assert len(bundle.getmembers())==len(items)
        for filename,path in items.items():
            assert hashlib.sha256(bundle.extractfile(filename).read()).hexdigest()==digest(path)
    return {'archive':out.name, 'sha256':digest(out),
            'members':{name:digest(path) for name,path in sorted(items.items())}}

def git(*argv):
    return subprocess.check_output(['git','-C',root,*argv],text=True).strip()

items = {}
results = {}
for profile in ('release','asan'):
    group = native/profile
    renderer = graphics/profile
    state = success(group)
    assert state['tests']==12 and state['directional_samples']==6500 and state['maximum_angle']<.006
    actual = success(renderer)
    assert state['core_sha256']==actual['core_sha256'] and state['render_sha256']==actual['render_sha256']
    assert all(row['max']<=1 and not row['unequal_silhouette'] for row in actual['report'])
    add(items,'native/'+profile,group,'status.json','ctest.log','public-0.log',
        'public-1.log','dome-sculpt-link.log')
    add(items,'graphics/'+profile,renderer,'status.json','startup-attempt.json','render.log','output/oracle.json')
    add(items,'graphics/'+profile,renderer,*[str(file.relative_to(renderer)) for file in (renderer/'output').glob('*.png')])
    results[profile]={'native':state,'graphics':actual}
assert len({r['native']['portable_glb_sha256'] for r in results.values()})==1
assert len({r['native']['editable_glb_sha256'] for r in results.values()})==1
sample = native/'release/build/texture-set-retained-native-target'
add(items,'fixture',sample,'native-target-smooth-portable.dsculpt',
    'native-normal-smooth-bake.glb','native-normal-smooth-editable.glb')
add(items,'validation-sources/native',native,'run.py','record.py')
add(items,'validation-sources/graphics',graphics,'run.py','witness.cpp')
add(items,'alternate-atlas',atlas,'run.py','witness.cpp','run.log')
assert (atlas/'run.log').read_text().startswith('PASS') and '5151' in (atlas/'run.log').read_text()
format_report=read(validator/'summary.json')
assert len(format_report['reports'])==4 and all(not row['errors'] and not row['warnings'] for row in format_report['reports'])
add(items,'validator',validator,'validate.cjs','summary.json',
    *[file.name for file in validator.glob('*.glb.json')])
xr_status=success(xr/'release')
wl_status=success(wayland)
assert xr_status['checks']==19 and wl_status['checks']==17
assert all(data['app_sha256']==results['release']['native']['app_sha256'] for data in (xr_status,wl_status))
add(items,'openxr',xr/'release','status.json','xr.log','workflow/report.json')
add(items,'wayland',wayland,'status.json','wayland.log','workflow/report.json')
add(items,'validation-sources/openxr',xr,'run.py','fixture.cpp')
add(items,'validation-sources/wayland',wayland,'run.py','replay.py')
full=read(whole/'status.json')
assert full['candidate'].startswith('5ff0da2b') and full['terminal'] and full['totals']=={'pass':1307,'fail':27,'skip':0}
assert digest(whole/'full.xml')==full['junit_sha256']
followup=read(triage/'status.json')
assert followup['candidate'].startswith('55a5bc69') and len(followup['results'])==5 and all(report['exit']==1 for report in followup['results'])
add(items,'earlier-release',whole,'status.json','full.xml','ctest.log','run.py')
add(items,'reproduced-regressions',triage,'status.json','run.py')
for repro in followup['results']:
    add(items,'reproduced-regressions',triage,repro['test']+'/run.log')
assert git('diff','--name-only',product,'HEAD','--','src','include','tests','CMakeLists.txt')==''
archive_info=archive(validation/'retained-smooth-glb-20261126.tar.gz',items)
report={'product':product,'main_merge':git('rev-parse','HEAD'),
        'scope':'Static LDR retained normal texture sets. Standard and Editable GLB, per-corner frame transport, bounded reprojection and alternate atlas sampling.',
        'physical_headset':False,'profiles':results,'khronos':format_report,
        'synthetic_openxr':xr_status,'nested_wayland':wl_status,
        'earlier_full_release':full,'reproduced_on_previous_export_candidate':followup,
        'raw':archive_info}
(validation/'retained-smooth-glb-20261126.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'archive':archive_info['archive'],'members':len(items),'sha256':archive_info['sha256']}))
