from pathlib import Path
import fcntl,hashlib,json,os,shlex,subprocess,sys,time
profile=sys.argv[1]
arc=profile=='asan'
base=Path(__file__).resolve().parent
artifacts=base.parent
source=artifacts/'retained-smooth-atlas-source-20261126'
validation=artifacts/'retained-smooth-atlas-validation-20261126'/profile
build=validation/'build'
support=artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=artifacts/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
out=base/profile
out.mkdir(exist_ok=True)
candidate=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
info={'candidate':candidate,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}
def record(**items):
 info.update(items)
 temp=out/'status.tmp';temp.write_text(json.dumps(info,indent=2)+'\n');temp.replace(out/'status.json')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,label,timeout=360):
 with (out/label).open('w') as f:
  print(shlex.join(map(str,cmd)),file=f,flush=True)
  subprocess.run(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
try:
 assert candidate==os.environ['DOME_BAKE_CANDIDATE']
 record(phase='wait for sealed native and renderer archives')
 unit=f'ds-retained-smooth-atlas-{profile}-20261126.service'
 profile_state=validation/'status.json'
 while True:
  if profile_state.is_file():
   witness=json.loads(profile_state.read_text())
   if witness['terminal']:break
  subprocess.run(['systemctl','--user','is-active','--quiet',unit],check=True)
  time.sleep(1)
 assert witness['candidate']==candidate and witness['exit']==0
 archives=[validation/f'libdome-sculpt-{kind}.a' for kind in ('core','render')]
 assert all(sha(file)==witness[f'{kind}_sha256'] for file,kind in zip(archives,('core','render')))
 binary=out/'witness'
 target='dome-sculpt-texture-set-source-render-test'
 compile=json.loads((build/'compile_commands.json').read_text())
 row=next(r for r in compile if r['file'].endswith('/tests/texture-set-source-render.cpp'))
 c=shlex.split(row['command']);at=c.index('-o')+1;name=c[at];obj=out/'witness.o'
 c[at]=str(obj);c[-1]=str(base/'witness.cpp')
 c.insert(1,'-I'+str(source/'tests'))
 run(c,'build.log')
 line=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
 link=[w for w in shlex.split(line)[2:-2] if not w.startswith('-Wl,--dependency-file=')]
 link[link.index(name)]=str(obj)
 link[link.index('-o')+1]=str(binary)
 linked={p.name:str(p) for p in archives}
 link=[linked.get(w,str(support/w)) if w.startswith('lib') and w.endswith('.a') else w for w in link]
 run(link,'link.log')
 cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
      '--dev','/dev','--proc','/proc','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
 env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
      'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
      'LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1','MESA_SHADER_CACHE_DISABLE':'1'}
 if arc:
  node='/dev/dri/renderD129'
  cmd+=['--dev-bind',node,node]
  env.update(DRI_PRIME='pci-0000_03_00_0',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
             UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 for k,v in env.items():
  cmd+=['--setenv',k,v]
 record(phase='independent RGBA oracle on actual GPU renderer',core_sha256=sha(archives[0]),
        render_sha256=sha(archives[1]),fixture=sha(binary))
 fixture=build/'texture-set-retained-native-target'
 arguments=[binary,fixture/'native-target-smooth-portable.dsculpt',
            fixture/'native-normal-smooth-bake.glb',out/'output']
 if arc:
  with open('/tmp/dome-sculpt-arc-device.lock','rb') as fd:
   fcntl.flock(fd,fcntl.LOCK_EX)
   run([*cmd,*arguments],'render.log')
 else:run([*cmd,*arguments],'render.log')
 text=(out/'render.log').read_text()
 renderer=next(l for l in text.splitlines() if l.startswith('GL_RENDERER '))
 assert ('arc' if arc else 'llvmpipe') in renderer.lower()
 report=json.loads((out/'output'/'oracle.json').read_text())
 assert len(report)==2
 record(phase='complete',terminal=True,exit=0,renderer=renderer,report=report)
except Exception as error:
 record(terminal=True,exit=1,error=repr(error))
 raise
