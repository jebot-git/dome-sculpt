// SPDX-License-Identifier: GPL-3.0-or-later
#define main existing_sourceful_matrix
#include "texture-set-source-render.cpp"
#undef main
#include "dome/import-authoring.hpp"
#include <numeric>

int main(int argc,char **argv)try {
 if(argc!=4)return 2;
 const std::filesystem::path out=argv[3];
 std::filesystem::create_directories(out);
 NativeGraphics graphics;
 std::cout<<"GL_RENDERER "<<glGetString(GL_RENDERER)<<'\n';
 Document original,portable;
 auto native=Scene::load(argv[1]);
 const auto exact=native.encode();
 original.replace(native);
 ready(original);
 Scene empty;
 empty.active().visible=false;
 ImportAuthoringOptions options;
 options.prepare_texture_atlas=false;
 auto imported=prepare_authoring_import(empty,argv[2],options);
 check(imported.objects.size()==2,"Roundtrip importer opens both standard material primitives");
 portable.replace(imported.scene);
 ready(portable);
 const auto base=original.frame().surface;
 const auto roundtrip=portable.frame().surface;
 Fbo fbo;
 SurfaceRenderer renderer;
 renderer.set_output_encoding(SurfaceOutputEncoding::Linear);
 nlohmann::json report=nlohmann::json::array();
 for(float shift : {.0f,.008f}){
  CanvasTransform canvas;
  canvas.position={shift,0,0};
  const auto left=render(renderer,base,fbo,policy(original,false),canvas);
  const auto right=render(renderer,roundtrip,fbo,policy(portable,false),canvas);
  const auto label=std::to_string(shift);
  png(out/(label+"-native.png"),left);
  png(out/(label+"-portable.png"),right);
  size_t same=0,unequal_silhouette=0;
  std::vector<unsigned> error;
  for(size_t i=0;i<left.size();i+=4){
   if(bool(left[i+3])!=bool(right[i+3]))++unequal_silhouette;
   if(!left[i+3]||!right[i+3])continue;
   ++same;
   for(size_t c=0;c<3;++c)
    error.push_back(unsigned(std::abs(int(left[i+c])-int(right[i+c]))));
  }
  check(!error.empty(),"Both draws have overlapping visible geometry");
  std::ranges::sort(error);
  const double mean=std::accumulate(error.begin(),error.end(),0.)/error.size();
  const auto peak=error.back(),p99=error[99*error.size()/100];
  nlohmann::json result{{"eye",shift},{"overlap",same},{"unequal_silhouette",unequal_silhouette},
                        {"max",peak},{"p99",p99},{"mean",mean}};
  std::cout<<result.dump()<<'\n';
  report.push_back(result);
  check(same>1000&&unequal_silhouette<=12,"Standard GLB roundtrip preserves the visible mesh");
  check(p99<=3&&peak<=12&&mean<=1.,"GPU roundtrip preserves the smooth baked material within RGB8 limits");
 }
 check(original.copy_scene().encode()==exact,"Graphical roundtrip preserves original native project");
 std::ofstream(out/"oracle.json")<<report.dump(2)<<'\n';
 return 0;
}catch(const std::exception &error){
 std::cerr<<"FAIL "<<error.what()<<'\n';
 return 1;
}
