from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import shlex
import subprocess

out = Path(__file__).resolve().parent
artifacts = out.parent
qualified = artifacts/'retained-smooth-final-validation-20261126/release'
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126/release/build'
build = qualified/'build'
state = json.loads((qualified/'status.json').read_text())
assert state['candidate'] == '55a5bc69be9db6641c5df2227b5f87108869564b' and state['terminal'] and state['exit'] == 0
database = json.loads((build/'compile_commands.json').read_text())
suite = {
  'native-paged-ray-cancellation': ('dome-sculpt-native-paged-ray-test', []),
  'scene-authoring': ('dome-sculpt-scene-test', []),
  'sculpt-mask-document': ('dome-sculpt-mask-document-test', []),
  'sculpt-mask-controller': ('dome-sculpt-mask-controller-test', []),
  'native-live-preview': ('dome-sculpt-native-strokes-test', ['--preview-test']),
}
isolated = ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
            '--bind',out,out,'--proc','/proc','--dev','/dev','--tmpfs','/tmp',
            '--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
            '--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH',
            '/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']

def process(case):
    name, (target, args) = case
    current = out/name
    current.mkdir(exist_ok=True)
    entry = next(row for row in database if f'CMakeFiles/{target}.dir/' in row['command'])
    compile = shlex.split(entry['command'])
    index = compile.index('-o')+1
    original, obj = compile[index], current/(Path(entry['file']).name+'.o')
    compile[index] = str(obj)
    binary = current/target
    with (current/'build.log').open('w') as log:
        subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
        commands = subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True)
        link = [w for w in shlex.split(commands.splitlines()[-1])[2:-2] if not w.startswith('-Wl,--dependency-file=')]
        link[link.index(original)] = str(obj)
        link[link.index('-o')+1] = str(binary)
        link = [str(qualified/w if (qualified/w).is_file() else support/w)
                if w.startswith('lib') and w.endswith('.a') else w for w in link]
        subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    with (current/'run.log').open('w') as log:
        child = subprocess.run([*isolated,binary,*args],cwd=current,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    return {'test':name, 'exit':child.returncode, 'last_lines':(current/'run.log').read_text().splitlines()[-4:]}

with ThreadPoolExecutor(max_workers=3) as pool:
    reports = list(pool.map(process,suite.items()))
(out/'status.json').write_text(json.dumps({'candidate':state['candidate'],'results':reports},indent=2)+'\n')
