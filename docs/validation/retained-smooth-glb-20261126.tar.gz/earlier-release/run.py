from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as ET
out=Path(__file__).resolve().parent
source=out.parent/'retained-texture-set-bake-coexistence-source-20261126'
build=out/'build'
expected='5ff0da2bf169ebb6a999139bcdd1103d1ea3c91d'
toolkit=Path('/opt/fltk-vr/toolkit')
bitmap=Path('/opt/fltk-vr/bdf-runtime')
env={**os.environ,'PKG_CONFIG_PATH':f'{bitmap}/lib/pkgconfig:/usr/lib64/pkgconfig','LD_LIBRARY_PATH':f'{toolkit}/lib:{bitmap}/lib:/usr/lib64'}
t=time.monotonic()
def git(*args):return subprocess.check_output(['git','-C',source,*args],text=True).strip()
def digest(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
s={'candidate':git('rev-parse','HEAD'),'terminal':False,'invocation':os.getenv('INVOCATION_ID'),'toolkit':str(toolkit)}
def write(**fields):
    s.update(fields,elapsed_seconds=round(time.monotonic()-t,3))
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(s,indent=2)+'\n')
    tmp.replace(out/'status.json')
def invoke(argv,log,timeout):
    with (out/log).open('w') as file:
        return subprocess.run(argv,cwd=out,stdout=file,stderr=subprocess.STDOUT,env=env,timeout=timeout).returncode
try:
    assert s['candidate']==expected and not git('status','--porcelain')
    opts=['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
          '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={toolkit}/share/fltk']
    write(phase='configure all Release targets',configure=list(map(str,opts)))
    assert invoke(opts,'configure.log',180)==0
    config=digest(build/'CMakeCache.txt')
    write(phase='build all Release targets',cache_sha256=config)
    assert invoke(['cmake','--build',build,'--parallel','7'],'build.log',4000)==0
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain') and digest(build/'CMakeCache.txt')==config
    registration=subprocess.check_output(['ctest','--test-dir',build,'--show-only=json-v1'],text=True)
    (out/'registered.json').write_text(registration)
    enrolled=json.loads(registration)['tests']
    names={case['name'] for case in enrolled}
    assert len(names)==len(enrolled) and all(c.get('command') for c in enrolled)
    assert {'texture-set-retained-bake-source','texture-set-retained-source-openxr',
            'texture-set-active-bake-openxr','native-key-uv-openxr'}<=names
    app_sha=digest(build/'dome-sculpt')
    command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    settings={'PATH':'/usr/bin:/bin','LD_LIBRARY_PATH':env['LD_LIBRARY_PATH'],
              'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2'}
    private=out/'private'
    for key,name in [('HOME','home'),('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),
                    ('XDG_DATA_HOME','data'),('XDG_RUNTIME_DIR','runtime'),('XDG_STATE_HOME','state')]:
        path=private/name
        path.mkdir(parents=True,mode=0o700,exist_ok=True)
        settings[key]=str(path)
    for key,value in settings.items():command.extend(['--setenv',key,value])
    junit=out/'full.xml'
    command.extend(['ctest','--test-dir',build,'-j4','--output-on-failure','--output-junit',junit])
    write(phase='run all registered private software CTests',app_sha256=app_sha,registered=len(names))
    code=invoke(command,'ctest.log',10800)
    cases=ET.parse(junit).getroot().findall('.//testcase')
    assert {case.attrib['name'] for case in cases}==names and len(cases)==len(names)
    fail=sorted(case.attrib['name'] for case in cases if case.find('failure') is not None)
    skip=sorted(case.attrib['name'] for case in cases if case.find('skipped') is not None)
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain') and digest(build/'dome-sculpt')==app_sha
    write(phase='complete',terminal=True,exit=code,totals={'pass':len(cases)-len(fail)-len(skip),'fail':len(fail),'skip':len(skip)},
          failed=fail,skipped=skip,junit_sha256=digest(junit))
except Exception as err:
    write(terminal=True,exit=1,error=repr(err))
raise SystemExit(s['exit'])
