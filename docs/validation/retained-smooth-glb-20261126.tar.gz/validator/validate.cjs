const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

const here = __dirname;
const validator = require(path.join(here, '..', 'hdr-khronos-validation-20261126', 'module/package'));
const parent = path.join(here, '..', 'retained-smooth-atlas-validation-20261126');
const artifactNames = ['native-normal-smooth-bake.glb', 'native-normal-smooth-editable.glb'];
const profiles = ['release', 'asan'];

(async () => {
  const reports = [];
  for (const profile of profiles) {
    for (const file of artifactNames) {
      const input = fs.readFileSync(path.join(parent, profile, 'build/texture-set-retained-native-target', file));
      const report = await validator.validateBytes(input, {uri: file, maxIssues: 100});
      const output = path.join(here, profile + '-' + file + '.json');
      fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
      reports.push({profile, file, sha256: crypto.createHash('sha256').update(input).digest('hex'),
                    errors: report.issues.numErrors, warnings: report.issues.numWarnings,
                    infos: report.issues.numInfos});
    }
  }
  const result = {validator: validator.version(), reports};
  fs.writeFileSync(path.join(here, 'summary.json'), JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify(result));
  if (reports.some(({errors, warnings}) => errors || warnings)) process.exitCode = 1;
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
