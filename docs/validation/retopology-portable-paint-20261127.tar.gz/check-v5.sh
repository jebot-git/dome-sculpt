#!/usr/bin/bash
set -euo pipefail
profile="$1"
out="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$out/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/$profile"
sdk=/opt/fltk-vr/toolkit
if [[ "$profile" == asan ]]; then sdk="$repo/artifacts/sdk-20261126/toolkit-sanitize"; fi
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$out/source-v5/src" "$repo/src" --ro-bind "$out/source-v5/include" "$repo/include" --ro-bind "$out/source-v5/tests" "$repo/tests" --ro-bind "$out/source-v5/CMakeLists.txt" "$repo/CMakeLists.txt" --bind "$out/$profile" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH "$sdk/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64" --setenv ASAN_OPTIONS detect_leaks=1:halt_on_error=1 --setenv UBSAN_OPTIONS halt_on_error=1:print_stacktrace=1 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
targets=(dome-sculpt-retopo-surface-heat-test dome-sculpt-texture-set-source-export-test)
pattern='^(retopology-(mtoon-.*|first-material-.*|imported-(pbr|prior-bake|mtoon-.*))|native-mikk-export)$'
if [[ "$profile" == release ]]; then
  targets+=(dome-sculpt dome-sculpt-mtoon-render-test dome-sculpt-native-mtoon-preview-contracts-test)
  pattern='^(retopology-(mtoon-.*|first-material-.*|imported-(pbr|prior-bake|mtoon-.*))|native-mikk-export|mtoon-(texture-sets|painted-texture-sets|baked-texture-sets)|native-mtoon-preview-contracts.*)$'
fi
"${sandbox[@]}" cmake --build "$seed" --parallel 6 --target "${targets[@]}" > "$out/$profile-v5-build.log" 2>&1
"${sandbox[@]}" ctest --test-dir "$seed" --parallel 3 -R "$pattern" --output-on-failure > "$out/$profile-v5-tests.log" 2>&1
