from hashlib import file_digest, sha256
import gzip
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'
base = work.parent / 'retopology-portable-mtoon-20261127'
previous = '2010f4dc36e4ac80723e89aba9de321f38e66a97'


def digest(path):
    with path.open('rb') as file:
        return file_digest(file, 'sha256').hexdigest()


def git(directory, *args):
    return subprocess.check_output(['git', '-C', directory, *args]).decode().strip()


def parse(path):
    data = path.read_bytes()
    assert data[:4] == b'glTF'
    end = 20 + struct.unpack_from('<I',data,12)[0]
    return json.loads(data[20:end]),data[end+8:]


def primary(data):
    return data['meshes'][0]['primitives'][0]


def core_images(path):
    data, binary = parse(path)
    core = data['materials'][primary(data)['material']]
    pbr = core['pbrMetallicRoughness']
    infos = dict(color=pbr['baseColorTexture'],orm=pbr['metallicRoughnessTexture'],
                 normal=core['normalTexture'],occlusion=core['occlusionTexture'],emission=core['emissiveTexture'])
    images = {}
    for role,info in infos.items():
        texture = data['textures'][info['index']]
        view = data['bufferViews'][data['images'][texture['source']]['bufferView']]
        begin = view.get('byteOffset',0)
        images[role] = sha256(binary[begin:begin+view['byteLength']]).hexdigest()
    return images


product = git(repo,'rev-parse','HEAD')
assert git(repo,'rev-parse','HEAD^') == previous
patch = subprocess.check_output(['git','-C',repo,'diff','--binary',previous,product])
assert sha256(patch).hexdigest() == digest(work/'source-v5.patch')
canonical = git(repo.parent/'DomeD','rev-parse','HEAD')
assert canonical == git(repo.parent/'DomeD','ls-remote','origin','refs/heads/main').split()[0]
old = work/'baseline-visible.glb'
assert 'KHR_materials_variants' not in parse(old)[0]['extensionsUsed']
assert 'TANGENT' not in primary(parse(old)[0])['attributes']
old_core = core_images(old)
assert old_core == core_images(work/'v5-painted/visible-standard.glb')

members = ['record.py','check-v5.sh','check-v5-asan.py','release-v4-build.log','release-v5-build.log',
    'release-v5-tests.log','asan-v5-tests.log','render-portable.cpp','render-portable.py',
    'select-variant.py','run-render.py','xr-portable.py','run-wayland-painted.py','wayland-painted.py',
    'bind-wayland.log','wayland-painted/report.json','khronos.cjs','khronos.json','khronos.log',
    'mtoon-schemas.log','mtoon-schemas.json']
for name in ('texture-set-export.cpp','export.cpp','texture-set-source-export.cpp'):
    members.append(f'exact-v5-asan/{name}.build.log')
variants = ('painted','tinted','unprepared')
passed = {}
counts = {}
for directory,case_log,total in [('release','release-v5-tests.log',18),('exact-v5-asan','asan-v5-tests.log',14)]:
    log = (work/case_log).read_text()
    cases = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',log)
    assert f'0 tests failed out of {total}' in log and len(cases)==len(set(cases))==total
    passed[directory] = cases
    last = (work/directory/'Testing/Temporary/LastTest.log').read_text()
    counts[directory] = {}
    for variant in variants:
        case = 'retopology-imported-mtoon-'+variant
        assert case in cases
        log = re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.',last,re.M|re.S)[1]
        counts[directory][variant] = int(re.search(r'PASS (\d+) imported MToon retopology checks',log)[1])
        name = f'{directory}-{variant}-native-controls.log'
        (work/name).write_text(log)
        members.append(name)
assert counts['release']==counts['exact-v5-asan']==dict(painted=180,tinted=150,unprepared=153)

hashes = {}
bounds = {}
renderers = {}
for variant in variants:
    case = 'retopology-imported-mtoon-'+variant
    directory = work/f'v5-{variant}'
    for name in ('original-import.glb','raw-guide.dsculpt','raw-patch.dsculpt','raw-standard.glb','raw-editable.glb',
                 'visible-paint.dsculpt','visible-standard.glb','visible-editable.glb'):
        relative = Path(case)/name
        checksum = digest(work/'release'/relative)
        assert checksum == digest(work/'exact-v5-asan'/relative) == digest(directory/name)
        if name.startswith('raw-') or name=='original-import.glb':
            assert checksum == digest(base/'release'/relative)
        hashes[str(relative)] = checksum
    for name in ('visible-standard.glb','visible-editable.glb'):
        data,_=parse(directory/name)
        primitive=primary(data)
        assert 'TANGENT' in primitive['attributes']
        mapping=primitive['extensions']['KHR_materials_variants']['mappings'][0]
        typed=data['materials'][mapping['material']]
        assert primitive['material']!=mapping['material'] and mapping['variants']==[0]
        proof=typed['extras']['domeSculptMToonPaint']
        assert 0 < proof['maximumLinearColorError'] <= .008
        assert 0 < proof['maximumLinearEmissionError'] <= .008*proof['emissiveStrength']
        assert ('maximumLinearShadeError' in proof) == (variant!='unprepared')
        assert proof.get('maximumLinearShadeError',0) <= .008
        assert .9 <= proof['emissiveStrength'] < 2 if variant=='unprepared' else proof['emissiveStrength']==6
        assert bounds.setdefault(variant,proof)==proof
    cases={}
    for mode,renderer in [('software','llvmpipe'),('arc','Arc(tm) A770')]:
        name=f'v5-{variant}/render-portable-{mode}.log'
        log=(work/name).read_text()
        assert renderer in log and 'PASS package-free MToon variant and Core PBR replay' in log
        row=re.search(r'PORTABLE_RENDER pixels=(\d+) mtoon_max=(\d+) mtoon_rms=([.\d]+) core_pixels=(\d+) core_max=(\d+) core_rms=([.\d]+)',log)
        pixels,mtoon,typed_rms,core_pixels,core,core_rms=map(float,row.groups())
        assert pixels==core_pixels==5754 and mtoon<=2 and core<=1
        cases[mode]=dict(renderer=renderer,pixels=int(pixels),max_mtoon_8_bit_error=int(mtoon),
                         max_core_8_bit_error=int(core),mtoon_rms=typed_rms,core_rms=core_rms)
        members.append(name)
    renderers[variant]=cases

stereo={}
for mode,renderer in [('software','llvmpipe'),('arc','Arc(tm) A770')]:
    member=f'xr-{mode}-v5-painted/compare.json'
    report=json.loads((work/member).read_text())
    assert report['runtime']=='synthetic OpenXR' and report['exact_ordered_close']
    for profile in report['profiles']:
        assert renderer in profile['gl_renderer'] and profile['stereo_submissions']==6
        assert profile['acquires']==profile['image_waits']==profile['releases']==12
    assert len(report['profiles'])==2 and len(report['differing_rgb_components_per_eye'])==2
    assert all(row['maximum_channel_difference']<=3 for row in report['differing_rgb_components_per_eye'])
    stereo[mode]=report['differing_rgb_components_per_eye']
    members.extend([member,f'v5-painted/verified-stereo-{mode}.log'])

wayland=json.loads((work/'wayland-painted/report.json').read_text())
assert wayland['complete'] and len(wayland['checks'])==7 and all(row['passed'] for row in wayland['checks'])
khronos=json.loads((work/'khronos.json').read_text())
assert len(khronos['results'])==19
for result in khronos['results']:
    assert result['issues']['numErrors']==result['issues']['numWarnings']==0
    result['sha256']=digest(work/result['file'])
schema=json.loads((work/'mtoon-schemas.json').read_text())
assert len(schema['files'])==10 and len(schema['resolver_controls'])==3
assert all(len(file['checks'])==1 and not file['checks'][0]['errors'] for file in schema['files'])
assert not schema['schema_drift'] and not schema['schema_bytes_rewritten']

archive=validation/(work.name+'.tar.gz')
archive_members={}
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0) as packed:
    with tarfile.open(fileobj=packed,mode='w') as tar:
        for name in members:
            data=(work/name).read_bytes()
            archive_members[name]=sha256(data).hexdigest()
            item=tarfile.TarInfo(name)
            item.size=len(data)
            tar.addfile(item,io.BytesIO(data))

receipt=dict(product=product,previous_main=previous,canonical_domed=canonical,
    release_application_sha256=digest(work/'release/dome-sculpt'),
    asan_test_sha256=digest(work/'exact-v5-asan/dome-sculpt-texture-set-source-export-test'),
    asan_build='Same native sanitizer toolchain and baseline core, with both changed compiler objects and the fixture rebuilt from the frozen final source',
    source_patch_sha256=digest(work/'source-v5.patch'),
    baseline=dict(app_sha256=digest(base/'release/dome-sculpt'),file_sha256=digest(old),
                  material_variants=False,unchanged_core_view_png_sha256=old_core),
    tests=passed,native_checks=counts['release'],identical_release_and_asan_sha256=hashes,
    portable_paint_bounds=bounds,package_free_graphics=renderers,synthetic_openxr_differences=stereo,
    physical_headset=False,wayland=wayland,khronos=khronos,mtoon_schema_valid_materials=len(schema['files']),
    archive_sha256=digest(archive),archive_members_sha256=archive_members)
(validation/(work.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
