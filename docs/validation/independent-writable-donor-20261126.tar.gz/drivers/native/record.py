from pathlib import Path
import cbor2
import hashlib
import json
import re
import subprocess
import tarfile

out=Path(__file__).resolve().parent
art=out.parent
repo=art.parent
docs=repo/'docs/validation'
name='independent-writable-donor-20261126'
archive=docs/(name+'.tar.gz')
native={}
frontends={}
members={}

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def include(prefix,*paths):
    for path in paths:
        assert path.is_file(),path
        members[prefix+'/'+path.name]=path

for profile in ('release','asan'):
    folder=out/profile
    state=json.loads((folder/'status.json').read_text())
    if not state.get('terminal') or state.get('exit'):
        continue
    baseline=art/'writable-donor-current-validation-v2-20261126'/profile
    initial=json.loads((baseline/'status.json').read_text())
    assert not state['failures'] and state['app_sha256']==initial['app_sha256']
    data=(folder/'ctest.log').read_text()
    for suite,tag in [('writable','WRITABLE_SOURCE'),('joint','JOINT_SOURCE')]:
        lines=[line.split(tag+' ',1)[1] for line in data.splitlines() if tag+' ' in line]
        entries=[dict(item.split('=',1) for item in line.split()[1:]) for line in lines]
        assert len(entries)==(64 if suite=='writable' else 8)
        state[suite+'_cases']=len(entries)
        state[suite+'_assertions']=int(re.search(r'PASS (\d+) '+suite+r' source checks',data).group(1))
        state[suite+'_max_normal_error']=max(float(row['normal']) for row in entries)
        state[suite+'_max_material_error']=max(float(row['material']) for row in entries)
        state[suite+'_max_emission_value']=max(float(row['peak']) for row in entries)
    assert state['joint_assertions']==346313
    native[profile]=state
    include(profile,folder/'status.json',folder/'ctest.log',folder/'configure.log',folder/'build/regressions.xml')
    include(profile+'/product',baseline/'status.json',baseline/'app-link.log',baseline/'ctest.log',
            baseline/'core-archive-link.log',baseline/'render-archive-link.log')
    for target in ('source-writable-normal-bake','source-joint-writable-normal-bake'):
        parent=(folder if 'joint' in target else baseline)/'tests'/f'dome-sculpt-{target}-test'
        include(profile+'/'+target,*sorted(parent.glob('*.log')))
assert 'release' in native

matches={}
for variant in ('native','canonical','joint'):
    root=art/('writable-donor-joint-public-20261126' if variant=='joint' else 'writable-donor-current-public-20261126')
    shas=set()
    for mode in ('software','arc','arc-release','wayland'):
        key=mode+'-'+variant
        folder=root/key
        state=json.loads((folder/'status.json').read_text())
        if not state.get('terminal') or state.get('exit'):
            continue
        profile='asan' if mode=='arc' else 'release'
        assert state['app_sha256']==native[profile]['app_sha256'] and state['checks']==10
        frontends[key]=state
        shas.add(state['native_sha256'])
        include(key,folder/'status.json',folder/'run.log',folder/'workflow/report.json')
        if mode=='wayland':
            include(key,folder/'workflow/client.log',folder/'workflow/compositor.log',folder/'workflow/runtime-maps.txt')
        else:
            include(key,*(folder/'workflow'/f'{phase}.{ext}' for phase in ('accept','cancel') for ext in ('json','log')))
    if shas:
        assert len(shas)==1,(variant,shas)
        matches[variant]=shas.pop()
    include('drivers/'+variant,root/'run.py',root/'run-release-arc.py',root/'xr.py',root/'wayland.py')

same={}
matched_payloads={}
if 'asan' in native:
    for case in ('source-writable-normal-bake','source-joint-writable-normal-bake'):
        a=out/'release'/'build'/case
        b=out/'asan'/'build'/case
        for file in sorted(a.glob('*.dsculpt')):
            other=b/file.name
            key=case+'/'+file.name
            if digest(file)==digest(other):
                same[key]=digest(file)
                continue
            assert case=='source-joint-writable-normal-bake',file
            decoded=[cbor2.loads(path.read_bytes()) for path in (file,other)]
            names=[d.get('payload',d)['groups'][0].pop('name') for d in decoded]
            assert all(re.fullmatch(r'dome-cut-color-source-[0-9]+',name) for name in names)
            assert decoded[0]==decoded[1],file
            matched_payloads[key]={'release_sha256':digest(file),'asan_sha256':digest(other),'import_group_names':names}

include('drivers/native',out/'run.py',art/'writable-donor-current-validation-v2-20261126'/'run.py')
members['drivers/native/joint-fixture.py']=out/'run.py'
members['drivers/native/record.py']=out/'record.py'
with tarfile.open(archive,'w:gz',compresslevel=9) as pack:
    for key,path in sorted(members.items()):
        pack.add(path,arcname=key)
receipt={
    'scope':'Native and canonical writable-UV donors, and combined prepared polygon color and normal donors with FLOAT emission. Current rebuilt core and render owners and the relinked application. Includes the isolated frontend routes listed here.',
    'dome_d':subprocess.check_output(['git','-C',repo.parent/'DomeD','rev-parse','HEAD'],text=True).strip(),
    'native':native,
    'frontends':frontends,
    'matching_public_projects':matches,
    'matching_native_projects':same,
    'matching_joint_payloads_excluding_import_group_name':matched_payloads,
    'archive':{'file':archive.name,'sha256':digest(archive),'members':{key:digest(path) for key,path in sorted(members.items())}},
}
(docs/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print({profile:(data['tests'],data['writable_assertions'],data['joint_assertions']) for profile,data in native.items()})
print(list(frontends),len(same),len(matched_payloads))
