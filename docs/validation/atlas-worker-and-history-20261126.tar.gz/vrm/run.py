from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
support=artifacts/('vrm-consumer-combined-asan-20261126' if profile=='asan' else 'vrm-consumer-combined-20261126')
old=artifacts/'vrm-consumer-source-20261126'
source=artifacts/'vrm1-normal-negative-oracle-source-20261126'
out=base/profile
out.mkdir(mode=0o700)

def git(path,*args):
    return subprocess.check_output(['git','-C',path,*args],text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

status={'profile':profile,'candidate':git(source,'rev-parse','HEAD'),
        'parent':git(old,'rev-parse','HEAD'),'invocation':os.getenv('INVOCATION_ID'),'terminal':False,'linked':{}}

def record(**fields):
    status.update(fields)
    pending=out/'status.tmp'
    pending.write_text(json.dumps(status,indent=2)+'\n')
    pending.replace(out/'status.json')

def command(cmd,logfile):
    with (out/logfile).open('a') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)

compile_entries=json.loads((support/'compile_commands.json').read_text())

def build_object(target,filename,replace_source=None):
    entry=next(item for item in compile_entries if item['file'].endswith('/'+filename)
               and f'CMakeFiles/{target}.dir/' in item['command'])
    cmd=shlex.split(entry['command'])
    relative_object=cmd[cmd.index('-o')+1]
    if replace_source:
        cmd=[val.replace(str(old),str(replace_source)) for val in cmd]
    obj=out/(target+'.o')
    cmd[cmd.index('-o')+1]=str(obj)
    command(cmd,'compile.log')
    return relative_object,obj

try:
    assert not git(source,'status','--porcelain') and not git(old,'status','--porcelain')
    assert git(source,'rev-parse','HEAD^')==status['parent']
    release=artifacts/'vrm-consumer-combined-20261126'
    outcomes={}
    for name in ('normal','shift'):
        target=f'dome-sculpt-vrm1-{name}-faults-test'
        filename=f'tests/vrm1-{name}-faults.cpp'
        record(phase='compile '+target)
        relative,obj=build_object(target,filename,source)
        raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
        cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
        cmd[cmd.index('-o')+1]=str(out/target)
        cmd[cmd.index(relative)]=str(obj)
        command(cmd,'link.log')
        app=out/target
        status['linked'][target]=sha(app)
        project=release/f'vrm1-{name}-authoring/nonuniform-source.dsculpt'
        input_hash=sha(project)
        native=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
                '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
                '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
                '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
                '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',app,project]
        for case,options in (('controls',['--controls-only']),('full',[])):
            label=f'{name}-{case}'
            record(phase=label,outcomes=outcomes)
            log=out/(label+'.log')
            with log.open('w') as stream:
                result=subprocess.run([*native,*options],cwd=support,stdout=stream,stderr=subprocess.STDOUT,timeout=1800)
            lines=log.read_text().splitlines()
            outcomes[label]={'exit':result.returncode,'project_sha256':input_hash,'report':lines[-1]}
            assert sha(project)==input_hash
            assert result.returncode==0 and lines[-1].startswith('PASS '),outcomes[label]
            record(outcomes=outcomes)
    record(terminal=True,exit=0,phase='complete',outcomes=outcomes)
except Exception as problem:
    record(terminal=True,exit=1,error=repr(problem))
    raise
