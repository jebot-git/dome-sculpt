from pathlib import Path
import subprocess
import sys

base=Path(__file__).resolve().parent
for step in ('build.py','test-native.py'):
    subprocess.run([sys.executable,base/step,'release'],check=True)
