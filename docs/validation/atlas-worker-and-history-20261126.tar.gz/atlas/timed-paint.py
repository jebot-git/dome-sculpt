from pathlib import Path
import fcntl
import json
import os
import hashlib
import sys
import signal
import subprocess
import time

work=Path(__file__).resolve().parent
artifacts=work.parent
implementation=sys.argv[1]
profile=sys.argv[2]
base=work/"comparisons"/sys.argv[3]
base.mkdir(mode=0o700,parents=True)
out=base/"workflow"
out.mkdir(mode=0o700,exist_ok=False)
app=(work/profile/"dome-sculpt" if implementation=="candidate" else
     artifacts/("vrm-consumer-combined-asan-20261126" if profile=="asan" else
                "vrm-consumer-combined-20261126")/"dome-sculpt")
runtime=artifacts/"xr-material-ray-ready-validation-20261126/arc-asan/libdome-sculpt-test-runtime.so"
manifest=out/"runtime.json"
manifest.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{"library_path":str(runtime)}}))
node="/dev/dri/renderD129"
ld=(str(artifacts/"sdk-20261126/toolkit-sanitize/lib") if profile=="asan" else
    "/opt/fltk-vr/toolkit/lib")+":/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
env={"PATH":"/usr/bin:/bin","HOME":str(out),"LD_LIBRARY_PATH":ld,
     "DRI_PRIME":"pci-0000_03_00_0","MESA_SHADER_CACHE_DISABLE":"1","LP_NUM_THREADS":"2",
     "ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1","UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1",
     "XR_RUNTIME_JSON":str(manifest),"DOME_XR_FIXTURE_REPORT":str(out/"paint-baseline.json")}
cmd=["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/","--bind",out,out,
     "--proc","/proc","--dev","/dev","--dev-bind",node,node,"--tmpfs","/tmp","--tmpfs","/run/user","--clearenv"]
for k,v in env.items():
    cmd.extend(["--setenv",k,v])
cmd.extend([app,"--xr","--frames","1","--save",out/"paint-baseline.dsculpt","--paint"])
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
status={"terminal":False,"invocation":os.getenv("INVOCATION_ID"),"timeout_seconds":40,
        "implementation":implementation,"profile":profile,"application_sha256":sha(app)}
first=None
last_before_graphics=None
def report(**fields):
    status.update(fields)
    tmp=base/"status.tmp"
    tmp.write_text(json.dumps(status,indent=2)+"\n")
    tmp.replace(base/"status.json")
def descendants(pid):
    yield pid
    try:
        children=Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
    except (FileNotFoundError,ProcessLookupError):
        return
    for child in children:
        yield from descendants(int(child))
def observe(pid):
    for child in descendants(pid):
        proc=Path(f"/proc/{child}")
        try:
            if (proc/"exe").resolve()!=app.resolve():
                continue
            info=(proc/"stat").read_text().split(")",1)[1].split()
            descriptors=[]
            for fd in (proc/"fd").iterdir():
                try:descriptors.append(os.readlink(fd))
                except (FileNotFoundError,ProcessLookupError):continue
            return {"pid":child,"cpu_jiffies":int(info[11])+int(info[12]),"state":info[0],
                    "wait_channel":(proc/"wchan").read_text().strip(),"arc_open":node in descriptors}
        except (FileNotFoundError,ProcessLookupError):
            continue
    return {}
log=out/"application.log"
samples=[]
with open("/tmp/dome-sculpt-arc-device.lock","rb") as lease, log.open("w") as stream:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    report(phase="Timed paint startup using real loader and Intel Arc")
    begin=time.monotonic()
    process=subprocess.Popen(cmd,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    while process.poll() is None:
        age=time.monotonic()-begin
        data=observe(process.pid)
        if data:samples.append({"seconds":round(age,2),**data})
        if first is None:
            if "windowless EGL" in log.read_text():
                first=round(age,2)
            elif data:
                last_before_graphics=data["cpu_jiffies"]
        if age>40:
            os.killpg(process.pid,signal.SIGTERM)
            process.wait(timeout=10)
            break
        time.sleep(.25)
(base/"trace.json").write_text(json.dumps(samples,indent=2)+"\n")
saved=out/"paint-baseline.dsculpt"
report(terminal=True,exit=process.returncode,elapsed=round(time.monotonic()-begin,2),
       cpu_ticks_before_graphics=last_before_graphics, ticks_per_second=os.sysconf("SC_CLK_TCK"),
       save_sha256=sha(saved) if saved.is_file() else None,
       first_graphics_log_seconds=first,created_save=(out/"paint-baseline.dsculpt").is_file(),
       arc_witnesses=sum(s["arc_open"] for s in samples))
raise SystemExit(bool(process.returncode))
