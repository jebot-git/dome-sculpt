from pathlib import Path
import json
import subprocess
import sys

base=Path(__file__).resolve().parent
for implementation in ('parent','candidate'):
    label=f'release-{implementation}-correct-loader'
    subprocess.run([sys.executable,base/'timed-paint-release.py',implementation,'release',label],timeout=65,check=False)
release=[json.loads((base/'comparisons'/f'release-{implementation}-correct-loader/status.json').read_text())
         for implementation in ('parent','candidate')]
matching=all(row['exit']==0 and row['arc_witnesses']>0 for row in release) and release[0]['save_sha256']==release[1]['save_sha256']
(base/'comparisons/release-correct-loader-result.json').write_text(json.dumps({'matching':matching,'runs':release},indent=2)+'\n')
# The broad suite independently exercises real graphics and all helper projects.
code=subprocess.run([sys.executable,base/'run-suite-with-helpers.py','arc-asan'],timeout=640).returncode
raise SystemExit(code or (not matching))
