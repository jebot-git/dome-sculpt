from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
support=artifacts/('vrm-consumer-combined-asan-20261126' if profile=='asan' else 'vrm-consumer-combined-20261126')
old=artifacts/'vrm-consumer-source-20261126'
source=artifacts/'xatlas-idle-group-wait-source-20261126'
out=base/profile
assert out.is_dir()

def git(path,*args):
    return subprocess.check_output(['git','-C',path,*args],text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

status={'profile':profile,'candidate':git(source,'rev-parse','HEAD'),
        'candidate_atlas_source_sha256':sha(source/'third_party/xatlas/xatlas.cpp'),
        'parent':git(old,'rev-parse','HEAD'),'invocation':os.getenv('INVOCATION_ID'),'terminal':False,'linked':{}}

def record(**fields):
    status.update(fields)
    pending=out/'helpers-status.tmp'
    pending.write_text(json.dumps(status,indent=2)+'\n')
    pending.replace(out/'helpers-status.json')

def command(cmd,logfile):
    with (out/logfile).open('a') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)

compile_entries=json.loads((support/'compile_commands.json').read_text())

def build_object(target,filename,replace_source=None):
    entry=next(item for item in compile_entries if item['file'].endswith('/'+filename)
               and f'CMakeFiles/{target}.dir/' in item['command'])
    cmd=shlex.split(entry['command'])
    relative_object=cmd[cmd.index('-o')+1]
    if replace_source:
        cmd=[val.replace(str(old),str(replace_source)) for val in cmd]
    obj=out/(target+'.o')
    cmd[cmd.index('-o')+1]=str(obj)
    command(cmd,'helpers-compile.log')
    return relative_object,obj

try:
    assert not git(source,'status','--porcelain') and not git(old,'status','--porcelain')
    atlas=out/'libxatlas.a'
    build=json.loads((out/'status.json').read_text())
    assert build['candidate']==status['candidate'] and sha(atlas)==build['atlas_sha256']
    for target in ('dome-sculpt-bake-controls-test','dome-sculpt-corner-color-uv23-gui-fixture',
                   'dome-sculpt-skin-authoring-test','dome-sculpt-retopo-authoring-test',
                   'dome-sculpt-cut-authoring-test','dome-sculpt-mask-document-test'):
        record(phase='link '+target)
        raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
        cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
        cmd[cmd.index('-o')+1]=str(out/target)
        if 'libxatlas.a' in cmd:
            cmd[cmd.index('libxatlas.a')]=str(atlas)
        index=next(i for i,x in enumerate(cmd) if x.startswith(f'CMakeFiles/{target}.dir/') and x.endswith('.o'))
        if not (support/cmd[index]).is_file():
            filename=cmd[index].split('/'+target+'.dir/',1)[1][:-2]
            actual,new=build_object(target,filename)
            assert actual==cmd[index]
            cmd[index]=str(new)
        command(cmd,'helpers-link.log')
        status['linked'][target]=sha(out/target)
        record()
    record(terminal=True,exit=0,phase='complete')
except Exception as problem:
    record(terminal=True,exit=1,error=repr(problem))
    raise
