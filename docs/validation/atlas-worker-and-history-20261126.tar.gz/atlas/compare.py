from pathlib import Path
import json
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
out=base/'comparisons'
out.mkdir(mode=0o700)
results={}

def save(**fields):
    path=out/'status.tmp'
    path.write_text(json.dumps({'invocation':os.getenv('INVOCATION_ID'),'results':results,**fields},indent=2)+'\n')
    path.replace(out/'status.json')

try:
    for implementation,profile,repeat in (('parent','asan',1),('candidate','asan',1),
                                            ('candidate','asan',2),('parent','asan',2),
                                            ('parent','release',1),('candidate','release',1)):
        label=f'{profile}-{implementation}-{repeat}'
        save(terminal=False,phase=label)
        result=subprocess.run([sys.executable,base/'timed-paint.py',implementation,profile,label],timeout=60)
        results[label]=json.loads((out/label/'status.json').read_text())
        assert results[label]['terminal'],result.returncode
    successes=[r for r in results.values() if r['exit']==0]
    assert len({r['save_sha256'] for r in successes})==1
    assert all(r['arc_witnesses']>0 and r['first_graphics_log_seconds'] is not None for r in successes)
    assert all(r['exit']==0 for r in results.values() if r['implementation']=='candidate')
    save(terminal=True,exit=0,phase='complete')
except Exception as problem:
    save(terminal=True,exit=1,error=repr(problem))
    raise
