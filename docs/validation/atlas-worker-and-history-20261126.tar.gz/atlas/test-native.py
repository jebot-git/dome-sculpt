from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
profile=sys.argv[1]
products=base/profile
out=base/('native-'+profile)
out.mkdir(mode=0o700)
build=json.loads((products/'status.json').read_text())
assert build['terminal'] and build['exit']==0
status={'terminal':False,'profile':profile,'candidate':build['candidate'],'invocation':os.getenv('INVOCATION_ID'),'results':[]}

def record(**fields):
    status.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

try:
    for target,limit in [('xatlas-allocation',30),('xatlas-shutdown',30),('atlas-robustness',120),
                         ('atlas-cancellation',120),('atlas-authoring-cancellation',120),('voxel-authoring',120)]:
        record(phase=target)
        identifier='dome-sculpt-'+target+'-test'
        executable=products/identifier
        assert sha(executable)==build['linked'][identifier]
        log=out/(target+'.log')
        cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
             '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
             '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
             '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',executable]
        started=time.monotonic()
        with log.open('wb') as stream:
            result=subprocess.run(cmd,cwd=out,stdout=stream,stderr=subprocess.STDOUT,timeout=limit)
        status['results'].append({'target':target,'exit':result.returncode,'seconds':round(time.monotonic()-started,3),
                                  'log_sha256':sha(log),'last_line':log.read_text().splitlines()[-1]})
        assert result.returncode==0,status['results'][-1]
    record(terminal=True,exit=0,phase='complete')
except Exception as problem:
    record(terminal=True,exit=1,error=repr(problem))
    raise
