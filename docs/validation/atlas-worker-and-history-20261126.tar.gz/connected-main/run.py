from pathlib import Path
import json
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
profile=sys.argv[1]
for step in ('build.py','test-native.py'):
    subprocess.run([sys.executable,base/step,profile],check=True)
if profile=='release':
    out=base/profile
    log=out/'baseline.log'
    app=out/'baseline-atlas-cancellation-test'
    started=time.monotonic()
    with log.open('w') as stream:
        result=subprocess.run([app],stdout=stream,stderr=subprocess.STDOUT,cwd=out,timeout=120)
    text=log.read_text()
    assert result.returncode==1 and 'FAIL Connected sculpt chart growth observes cancellation' in text
    (out/'baseline-status.json').write_text(json.dumps({'exit':result.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'last_line':text.splitlines()[-1]},indent=2)+'\n')
