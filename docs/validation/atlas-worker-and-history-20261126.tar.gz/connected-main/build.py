from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
support=artifacts/'dormant-main-release-20261126'
old=artifacts/'dormant-main-source-20261126'
source=artifacts/'xatlas-connected-cancellation-source-20261126'
out=base/profile
out.mkdir(mode=0o700)

def git(path,*args):
    return subprocess.check_output(['git','-C',path,*args],text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

status={'profile':profile,'candidate':git(source,'rev-parse','HEAD'),
        'candidate_atlas_source_sha256':sha(source/'third_party/xatlas/xatlas.cpp'),
        'parent':git(old,'rev-parse','HEAD'),'invocation':os.getenv('INVOCATION_ID'),'terminal':False,'linked':{}}

def record(**fields):
    status.update(fields)
    pending=out/'status.tmp'
    pending.write_text(json.dumps(status,indent=2)+'\n')
    pending.replace(out/'status.json')

def command(cmd,logfile):
    with (out/logfile).open('a') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)

compile_entries=json.loads((support/'compile_commands.json').read_text())

def build_object(target,filename,replace_source=None):
    entry=next(item for item in compile_entries if item['file'].endswith('/'+filename)
               and f'CMakeFiles/{target}.dir/' in item['command'])
    cmd=shlex.split(entry['command'])
    relative_object=cmd[cmd.index('-o')+1]
    if replace_source:
        cmd=[val.replace(str(old),str(replace_source)) for val in cmd]
    obj=out/(target+'.o')
    cmd[cmd.index('-o')+1]=str(obj)
    command(cmd,'compile.log')
    return relative_object,obj

try:
    assert not git(source,'status','--porcelain') and not git(old,'status','--porcelain')
    assert git(source,'rev-parse','HEAD^').startswith('d2430f6b')
    assert not git(source,'diff','--name-only','HEAD',status['parent'],'--','src','include','CMakeLists.txt')
    status['qualified_parent']=git(source,'rev-parse','HEAD^')
    record(phase='compile complete xatlas dependency')
    _,obj=build_object('xatlas','third_party/xatlas/xatlas.cpp',source)
    library=out/'libxatlas.a'
    command(['/usr/bin/ar','qc',library,obj],'link.log')
    command(['/usr/bin/ranlib',library],'link.log')
    targets={
        'dome-sculpt':None,
        'dome-sculpt-xatlas-allocation-test':'tests/xatlas-allocation.cpp',
        'dome-sculpt-xatlas-shutdown-test':'tests/xatlas-shutdown.cpp',
        'dome-sculpt-atlas-robustness-test':'tests/atlas-robustness.cpp',
        'dome-sculpt-atlas-cancellation-test':'tests/atlas-cancellation.cpp',
        'dome-sculpt-atlas-authoring-cancellation-test':'tests/atlas-authoring-cancellation.cpp',
        'dome-sculpt-voxel-authoring-test':'tests/voxel-authoring.cpp',
    }
    for target,filename in targets.items():
        record(phase='link '+target)
        raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
        cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
        cmd[cmd.index('-o')+1]=str(out/target)
        cmd[cmd.index('libxatlas.a')]=str(library)
        if filename:
            needed=next(x for x in cmd if x.startswith(f'CMakeFiles/{target}.dir/') and x.endswith('.o'))
            if target=='dome-sculpt-atlas-cancellation-test' or not (support/needed).is_file():
                actual,new=build_object(target,filename,source if target=='dome-sculpt-atlas-cancellation-test' else None)
                assert needed==actual
                cmd[cmd.index(needed)]=str(new)
        command(cmd,'link.log')
        status['linked'][target]=sha(out/target)
        if profile=='release' and target=='dome-sculpt-atlas-cancellation-test':
            baseline=out/'baseline-atlas-cancellation-test'
            baseline_archive=artifacts/'xatlas-idle-group-wait-validation-20261126/release/libxatlas.a'
            baseline_link=[str(baseline_archive) if x==str(library) else str(baseline) if x==str(out/target) else x for x in cmd]
            command(baseline_link,'baseline-link.log')
            status['baseline_test_sha256']=sha(baseline)
        record()
    assert not git(source,'status','--porcelain') and not git(old,'status','--porcelain')
    record(terminal=True,exit=0,phase='complete',atlas_sha256=sha(library))
except Exception as problem:
    record(terminal=True,exit=1,error=repr(problem))
    raise
