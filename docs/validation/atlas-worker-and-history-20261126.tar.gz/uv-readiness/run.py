from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess

base=Path(__file__).resolve().parent
artifacts=base.parent
support=artifacts/'vrm-consumer-combined-asan-20261126'
target='libdome-sculpt-test-runtime.so'
entry=next(row for row in json.loads((support/'compile_commands.json').read_text()) if row['file'].endswith('/tests/xr_runtime.cpp'))
cmd=shlex.split(entry['command'])
cmd[cmd.index('-o')+1]=str(base/'runtime.o')
cmd[cmd.index(entry['file'])]=str(artifacts/'xr-uv-ready-source-20261126/tests/xr_runtime.cpp')
with (base/'compile.log').open('w') as log:
    subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)
raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
cmd[cmd.index('-o')+1]=str(base/target)
cmd[next(i for i,x in enumerate(cmd) if x.endswith('/xr_runtime.cpp.o'))]=str(base/'runtime.o')
with (base/'link.log').open('w') as log:
    subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)
patched=artifacts/'xatlas-idle-group-wait-validation-20261126/asan/dome-sculpt'
original=support/'dome-sculpt'
fixture=artifacts/'xatlas-idle-group-wait-validation-20261126/suite-arc-asan-with-helpers/workflow/paint-baseline.dsculpt'
node='/dev/dri/renderD129'
libpath=str(artifacts/'sdk-20261126/toolkit-sanitize/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'
status={'terminal':False,'invocation':os.getenv('INVOCATION_ID'),'cases':[]}

def record(**fields):
    status.update(fields)
    (base/'status.json').write_text(json.dumps(status,indent=2)+'\n')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

record(phase='tracing same prepared input on both Arc applications',source_sha256=sha(fixture))
with open('/tmp/dome-sculpt-arc-device.lock','rb') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for implementation,app in [('candidate',patched)]:
        for repeat in range(1,2):
            out=base/f'{implementation}-{repeat}'
            out.mkdir(mode=0o700)
            manifest=out/'runtime.json'
            manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(base/target)}}))
            saved=out/'uv.dsculpt'
            native=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
                    '--proc','/proc','--dev','/dev','--dev-bind',node,node,'--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
            environment={'PATH':'/usr/bin:/bin','HOME':str(out),'LD_LIBRARY_PATH':libpath,'DRI_PRIME':'pci-0000_03_00_0',
                         'MESA_SHADER_CACHE_DISABLE':'1','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
                         'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','XR_RUNTIME_JSON':str(manifest),
                         'DOME_XR_FIXTURE_UV':'1','DOME_XR_FIXTURE_REPORT':str(out/'xr.json')}
            for k,v in environment.items():native.extend(['--setenv',k,v])
            with (out/'application.log').open('w') as log:
                result=subprocess.run([*native,app,'--xr','--open',fixture,'--frames','900','--save',saved],
                                      stdout=log,stderr=subprocess.STDOUT,timeout=40)
            report=json.loads((out/'xr.json').read_text())
            local_env=dict(os.environ,LD_LIBRARY_PATH=libpath)
            old=json.loads(subprocess.check_output([app,'--project-info',fixture],env=local_env))
            new=json.loads(subprocess.check_output([app,'--project-info',saved],env=local_env))
            evidence={'ready':report.get('uv_atlas_ready'),'waits':report.get('uv_atlas_wait_frames'),
                      'edge_pixels':report.get('uv_atlas_visible_pixels'),'apply_accent':report.get('uv_atlas_apply_accent'),
                      'uv_change':old['uv_hash']!=new['uv_hash'],'paint_exact':old['paint_hash']==new['paint_hash'],
                      'field_exact':old['field_hash']==new['field_hash']}
            (out/'comparison.json').write_text(json.dumps(evidence,indent=2)+'\n')
            status['cases'].append({'label':out.name,'exit':result.returncode,'app_sha256':sha(app),
                                    'save_sha256':sha(saved) if saved.is_file() else None,
                                    'evidence':evidence})
            record(phase='tracing same prepared input on both Arc applications')
success=all(case['exit']==0 and all(case['evidence'].get(key) for key in ('ready','uv_change','paint_exact','field_exact')) for case in status['cases'])
record(phase='complete',terminal=True,exit=int(not success))
raise SystemExit(not success)
