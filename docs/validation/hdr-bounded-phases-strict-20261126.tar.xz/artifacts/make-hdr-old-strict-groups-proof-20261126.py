from pathlib import Path
import json,hashlib,lzma,tarfile,time
R=Path('/home/blux/de-xr/dome-sculpt');A=R/'artifacts';O=A/'hdr-strict-groups-build-v3-20261126';N=O/'native-sanitize-groups-v1';D=A/'hdr-release-proof-20261126/docs/validation';files=set()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def add(p):
 if Path(p).is_file():files.add(Path(p))
for base in [O,N]:
 for f in base.iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.log','.maps','.txt']:add(f)
for f in (O/'compiler-records').glob('*'):add(f)
for f in (O/'compiler-records').glob('*.json'):add(json.loads(f.read_text())['depfile'])
add(A/'make-hdr-old-strict-groups-proof-20261126.py');s=json.loads((N/'status.json').read_text());c=json.loads((N/'terminal-closure.json').read_text());assert s['terminal'] and s['exit']==1 and not s['owned'] and not s['drift'];assert c['exact_samples_per_role']==73530600 and c['positive_completed_phase_controls']==59716
inventory=[{'path':str(f.relative_to(R)),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(files)];archive=D/'hdr-bounded-phases-strict-20261126.tar.xz'
with lzma.open(archive,'wb',preset=6) as out:
 with tarfile.open(fileobj=out,mode='w|') as t:
  for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
r={'scope':'Actual old725 native and all original dense normal/HDR positions pass strict independent bounded phases; original combinedendpoint900deadline failure retained. Complete grouped strict is not passed, and no newApp0813 or channeloptimized core acceptance is implied.','product_source':'725ea10032981e28c7edb0c1ffdd5689e4a3ad32','fixture_source':'9ee166d43999f8006514247f3e227c99c8ffda31','invocation':'5bd7f71d1f2f49baa0d6f4b36d3f269f','status':s,'independent_postfailure_coverage_and_terminal':c,'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'authorities':inventory},'observed':time.time()};(D/'hdr-bounded-phases-strict-20261126.json').write_text(json.dumps(r,indent=2)+'\n');print('oldstrictproof59716/failure',len(files),archive.stat().st_size)
