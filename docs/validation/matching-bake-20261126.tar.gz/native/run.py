from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

home = Path(__file__).resolve().parent
artifacts = home.parent
source = artifacts/'current-bake-topology-fixture-20261126'
profile = sys.argv[1]
asan = profile == 'asan'
out = home/profile
out.mkdir(exist_ok=True)
build = out/'build'
prior = artifacts/'native-authored-grid-validation-v3-20261126'/profile
prior_product = artifacts/'native-authored-grid-validation-20261126'/profile
gpu = artifacts/'steady-gpu-retirement-validation-v2-20261126'/profile
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk = artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
test_targets = {
    'bake-projection-policy': 'dome-sculpt-bake-projection-policy-test',
    'bake': 'dome-sculpt-bake-test',
    'baked-textures': 'dome-sculpt-baked-textures-test',
    'bake-workflow': 'dome-sculpt-bake-workflow-test',
    'bake-controls': 'dome-sculpt-bake-controls-test',
    'bake-recipes': 'dome-sculpt-bake-recipes-test',
    'texture-set-active-bake': 'dome-sculpt-bake-recipes-test',
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
}
start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def sha(file):
    with Path(file).open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

status = {'candidate':git('rev-parse','HEAD'), 'profile':profile, 'terminal':False,
          'fltk':str(sdk),'invocation':os.getenv('INVOCATION_ID')}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic()-start,2))
    temp=out/'status.tmp'
    temp.write_text(json.dumps(status,indent=2)+'\n')
    temp.replace(out/'status.json')

def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check)

try:
    expected=os.environ['DOME_PAINT_GRID_CANDIDATE']
    assert expected==status['candidate'] and not git('status','--porcelain')
    opts = []
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    record(phase='configure canonical toolkit')
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,out)
    previous=artifacts/'matching-bake-validation-20261126'/profile
    record(phase='wait for immutable scoped product build')
    while True:
        path=previous/'status.json'
        if path.is_file():
            prior=json.loads(path.read_text())
            if prior['terminal']:break
        assert subprocess.check_output(['systemctl','--user','is-active',
            f'ds-matching-bake-{profile}-v2-20261126.service'],text=True).strip()=='active'
        time.sleep(2)
    product=prior['candidate']
    assert product=='fc4abd9a'+git('rev-parse','fc4abd9a')[8:]
    assert git('diff','--name-only',product,'HEAD').splitlines()==['tests/bake-projection-policy.cpp']
    base=previous/'build'
    record(phase='authenticate unchanged scoped product',exact_product=product,
           rebuilt=prior['rebuilt'],dependency_receipt=prior['dependency_receipt'],
           owned_objects=prior['owned_objects'])
    verified={}
    for role in ('core','render','xr'):
        library=previous/f'libdome-sculpt-{role}.a'
        assert sha(library)==prior[role+'_sha256']
        target=out/library.name
        target.symlink_to(library)
        verified[role+'_sha256']=sha(target)
    for name,key in {'dome-sculpt':'app_sha256','libdome-sculpt-test-runtime.so':'runtime_sha256'}.items():
        file=base/name
        assert sha(file)==prior[key]
        (build/name).symlink_to(file)
        verified[key]=sha(file)

    fixture='dome-sculpt-bake-projection-policy-test'
    test_paths={}
    for name in sorted(set(test_targets.values())-{fixture}):
        path=base/name
        assert sha(path)==prior['binaries'][name]
        (build/name).symlink_to(path)
        test_paths[name]=sha(path)
    entry=next(e for e in json.loads((build/'compile_commands.json').read_text())
               if e['file'].endswith('/tests/bake-projection-policy.cpp'))
    obj=out/'bake-projection-policy.cpp.o'
    args=shlex.split(entry['command'])
    args[args.index('-o')+1]=str(obj)
    invoke(args,'fixture-compile.log',500)
    fixture_dir=out/'tests'/fixture
    fixture_dir.mkdir(exist_ok=True,parents=True)
    link=shlex.split((previous/'tests'/fixture/'link.log').read_text().splitlines()[0])
    link=[str(obj) if p.endswith('/bake-projection-policy.cpp.o') else p for p in link]
    invoke(link,fixture_dir.relative_to(out)/'link.log',500)
    test_paths[fixture]=sha(build/fixture)
    record(phase='run matched native bake suites',binaries=test_paths,**verified)

    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        environment.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in environment.items():
        isolated.extend(['--setenv',key,value])
    # Emit JUnit before enforcing success so a failed case can be diagnosed
    # against its exact executable while preserving all other results.
    report=build/'bake-topology-tests.xml'
    run=invoke([*isolated,'ctest','--test-dir',build,'-R','^('+'|'.join(test_targets)+')$',
                '--output-on-failure','-V','-j2','--output-junit',report],
               'ctest.log',850,check=False)
    from xml.etree import ElementTree
    cases={case.attrib['name']:case for case in ElementTree.parse(report).getroot().findall('.//testcase')}
    assert set(cases)==set(test_targets)
    failure=sorted(name for name,case in cases.items() if case.find('failure') is not None or case.find('skipped') is not None)
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    record(phase='complete',terminal=True,exit=run.returncode,failures=failure,tests=len(cases),
           ctest_sha256=sha(out/'ctest.log'),junit_sha256=sha(report))
    assert run.returncode==0 and not failure, failure
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
