from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

home = Path(__file__).resolve().parent
artifacts = home.parent
source = artifacts/'current-bake-topology-source-20261126'
profile = sys.argv[1]
asan = profile == 'asan'
out = home/profile
out.mkdir(exist_ok=True)
build = out/'build'
prior = artifacts/'native-authored-grid-validation-v3-20261126'/profile
prior_product = artifacts/'native-authored-grid-validation-20261126'/profile
gpu = artifacts/'steady-gpu-retirement-validation-v2-20261126'/profile
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk = artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
test_targets = {
    'bake-projection-policy': 'dome-sculpt-bake-projection-policy-test',
    'bake': 'dome-sculpt-bake-test',
    'baked-textures': 'dome-sculpt-baked-textures-test',
    'bake-workflow': 'dome-sculpt-bake-workflow-test',
    'bake-controls': 'dome-sculpt-bake-controls-test',
    'bake-recipes': 'dome-sculpt-bake-recipes-test',
    'texture-set-active-bake': 'dome-sculpt-bake-recipes-test',
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
}
start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def sha(file):
    with Path(file).open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

status = {'candidate':git('rev-parse','HEAD'), 'profile':profile, 'terminal':False,
          'fltk':str(sdk),'invocation':os.getenv('INVOCATION_ID')}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic()-start,2))
    temp=out/'status.tmp'
    temp.write_text(json.dumps(status,indent=2)+'\n')
    temp.replace(out/'status.json')

def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check)

try:
    expected=os.environ['DOME_PAINT_GRID_CANDIDATE']
    assert expected==status['candidate'] and not git('status','--porcelain')
    opts = []
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    record(phase='configure canonical toolkit')
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,out)
    baseline=json.loads((prior/'status.json').read_text())
    parent=baseline['candidate']
    assert parent=='d9ea0716855609a2f8121fc4ffa9e652446b771e' and baseline['terminal'] and baseline['exit']==0
    production=set(git('diff','--name-only',parent,'HEAD','--','src','include','third_party','assets').splitlines())
    source_changes={p for p in production if p.endswith('.cpp')}
    headers={p for p in production if p.endswith('.hpp')}
    assert headers=={'src/source-bake-normal.hpp','include/dome/bake-settings.hpp'}
    database=json.loads((build/'compile_commands.json').read_text())

    def compile(entry,directory):
        cmd=shlex.split(entry['command'])
        target = cmd.index('-o')+1
        original = cmd[target]
        obj=directory/(Path(entry['file']).name+'.o')
        cmd[target]=str(obj)
        invoke(cmd,obj.relative_to(out).with_suffix('.log'),500)
        return original,obj

    targets={'dome-sculpt-core','dome-sculpt-render','dome-sculpt-xr','dome-sculpt'}
    def target(obj):return obj.split('/')[1].removesuffix('.dir')
    reference_build=artifacts/'current-full-release-20261126/build'
    dependencies={}
    with subprocess.Popen(['ninja','-C',reference_build,'-t','deps'],
                          stdout=subprocess.PIPE,text=True) as listing:
        for line in listing.stdout:
            if '.o: #' in line and line.startswith('CMakeFiles/'):
                owner=line.split(':',1)[0]
            elif line.startswith('    ') and any(line.rstrip().endswith('/'+header) for header in headers):
                dependencies.setdefault(owner,[]).append(line.strip())
        assert listing.wait()==0
    product_entries=[]
    for entry in database:
        args=shlex.split(entry['command'])
        obj=args[args.index('-o')+1]
        if not obj.startswith('CMakeFiles/') or target(obj) not in targets:continue
        file=Path(entry['file'])
        path=str(file.relative_to(source)) if file.is_relative_to(source) else ''
        if obj in dependencies or path in source_changes:
            product_entries.append((obj,entry))
    expected_deps={obj for obj in dependencies if target(obj) in targets}
    assert expected_deps<={obj for obj,_ in product_entries}
    assert source_changes<={str(Path(e['file']).relative_to(source)) for _,e in product_entries}
    record(phase='rebuild each changed or dependent product object',rebuilt=len(product_entries),
           dependency_receipt={obj:dependencies.get(obj,[]) for obj,_ in product_entries})
    def owned(job):
        obj,entry=job
        directory=out/'product'/target(obj)
        directory.mkdir(exist_ok=True,parents=True)
        return compile(entry,directory)
    with ThreadPoolExecutor(max_workers=3 if asan else 4) as pool:
        objects=dict(pool.map(owned,product_entries))
    donors={
        'dome-sculpt-core':prior_product/'libdome-sculpt-core.a',
        'dome-sculpt-render':gpu/'libdome-sculpt-render.a',
        'dome-sculpt-xr':artifacts/'retained-smooth-atlas-validation-20261126'/profile/'libdome-sculpt-xr.a',
    }
    archives={}
    for owner,donor in donors.items():
        short_name=owner.removeprefix('dome-sculpt-')
        assert sha(donor)==baseline[short_name+'_sha256']
        archive=out/donor.name
        shutil.copyfile(donor,archive)
        parts=[p for k,p in objects.items() if target(k)==owner]
        assert len(parts)==len({p.name for p in parts})
        assert parts
        invoke(['ar','rs',archive,*parts],short_name+'-index.log')
        assert subprocess.check_output(['ar','t',archive])==subprocess.check_output(['ar','t',donor])
        assert all(hashlib.sha256(subprocess.check_output(['ar','p',archive,p.name])).hexdigest()==sha(p) for p in parts)
        archives[archive.name]=str(archive)
    core=Path(archives['libdome-sculpt-core.a'])
    render=Path(archives['libdome-sculpt-render.a'])
    xr=Path(archives['libdome-sculpt-xr.a'])

    def make_target(target):
        directory=out/'tests'/target
        directory.mkdir(parents=True,exist_ok=True)
        entries=[entry for entry in database if f'CMakeFiles/{target}.dir/' in entry['command']]
        assert entries
        objects=dict(compile(entry,directory) for entry in entries)
        last=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
        words=[word for word in shlex.split(last)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
        assert all(x in words for x in objects)
        words=[str(objects[word]) if word in objects else word for word in words]
        words=[archives.get(word,str(support/word)) if word.startswith('lib') and word.endswith('.a') else word for word in words]
        invoke(words,directory.relative_to(out)/'link.log',500)
        return target,sha(build/target)

    record(phase='build focused CTests and ordinary frontend',
           core_sha256=sha(core),render_sha256=sha(render),xr_sha256=sha(xr),
           owned_objects={k:sha(p) for k,p in objects.items()})
    with ThreadPoolExecutor(max_workers=3) as pool:
        binaries=dict(pool.map(make_target,sorted(set(test_targets.values()))))
    app=build/'dome-sculpt'
    assert sha(prior_product/'build/dome-sculpt')==baseline['app_sha256']
    words=shlex.split((prior_product/'dome-sculpt-link.log').read_text().splitlines()[0])
    app_objects={value.name:str(value) for key,value in objects.items() if target(key)=='dome-sculpt'}
    assert sum(Path(word).name in app_objects for word in words)==len(app_objects)
    words=[app_objects.get(Path(word).name,archives.get(Path(word).name,word)) for word in words]
    words[words.index('-o')+1]=str(app)
    invoke(words,'app-link.log',500,support)
    runtime_target='dome-sculpt-test-runtime'
    runtime_obj=next(e for e in database if f'CMakeFiles/{runtime_target}.dir/' in e['command'])
    runtime_dir=out/'runtime'
    runtime_dir.mkdir(exist_ok=True)
    original,obj=compile(runtime_obj,runtime_dir)
    raw=subprocess.check_output(['ninja','-C',build,'-t','commands',runtime_target],text=True).splitlines()[-1]
    link=[word for word in shlex.split(raw)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
    assert original in link
    link[link.index(original)]=str(obj)
    invoke(link,'runtime-link.log',300)
    record(phase='run native tests',binaries=binaries,app_sha256=sha(app),
           runtime_sha256=sha(build/'libdome-sculpt-test-runtime.so'))

    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        environment.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in environment.items():
        isolated.extend(['--setenv',key,value])
    # Emit JUnit before enforcing success so a failed case can be diagnosed
    # against its exact executable while preserving all other results.
    report=build/'bake-topology-tests.xml'
    run=invoke([*isolated,'ctest','--test-dir',build,'-R','^('+'|'.join(test_targets)+')$',
                '--output-on-failure','-V','-j2','--output-junit',report],
               'ctest.log',850,check=False)
    from xml.etree import ElementTree
    cases={case.attrib['name']:case for case in ElementTree.parse(report).getroot().findall('.//testcase')}
    assert set(cases)==set(test_targets)
    failure=sorted(name for name,case in cases.items() if case.find('failure') is not None or case.find('skipped') is not None)
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    record(phase='complete',terminal=True,exit=run.returncode,failures=failure,tests=len(cases),
           ctest_sha256=sha(out/'ctest.log'),junit_sha256=sha(report))
    assert run.returncode==0 and not failure, failure
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
