// SPDX-License-Identifier: GPL-3.0-or-later
#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/creation.hpp"
#include "dome/document.hpp"
#include "dome/humanoid-creator.hpp"
#include "dome/normal-preparation.hpp"
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <iostream>
#include <nlohmann/json.hpp>

using namespace dome;

void check(bool passed, const char *message) {
  if(!passed)
    throw std::runtime_error(message);
  std::cout << "PASS " << message << std::endl;
}

int main(int argc,char **argv) try {
  if(argc!=2)throw std::invalid_argument("Expected output directory");
  const std::filesystem::path out=argv[1];
  std::filesystem::create_directories(out);
  for(const char *baseline:{"vroid-beta-female","vroid-beta-male"}){
    Scene scene;
    const auto group=append_humanoid(scene,humanoid_baseline_defaults(baseline),
                                     "CC0 shape detail",{},256);
    scene.group(group).transform.scale=.8f;
    scene.group(group).transform.position.y=-.7f;
    const auto face=std::ranges::find_if(scene.objects(),[&](const auto &part){
      return part.group==group&&part.name.find("Face_00_SKIN")!=std::string::npos;
    });
    check(face!=scene.objects().end(),"CC0 avatar contains the original FaceSkin");
    const auto id=face->id;
    scene.select(id);
    {
      auto &target=scene.active();
      auto prepared=prepare_source_normals({target.painted,target.appearance,
          target.material_bindings,target.deformation,target.material});
      target.painted=prepared.paint;
      target.material_bindings=prepared.material_bindings;
    }
    auto high=scene.active().painted->mesh();
    const auto artist=high.normals;
    for(size_t v=0;v<high.positions.size();++v){
      const auto point=high.positions[v];
      high.positions[v]+=artist[v]*(.003f+.0015f*std::sin(point.x*300.f)*std::sin(point.y*230.f));
    }
    high.normals.assign(high.positions.size(),{});
    for(size_t c=0;c<high.indices.size();c+=3){
      const auto a=high.indices[c],b=high.indices[c+1],c2=high.indices[c+2];
      const auto normal=cross(high.positions[b]-high.positions[a],high.positions[c2]-high.positions[a]);
      high.normals[a]+=normal;
      high.normals[b]+=normal;
      high.normals[c2]+=normal;
    }
    for(size_t v=0;v<high.normals.size();++v)
      high.normals[v]=length(high.normals[v])>1e-12f?normalized(high.normals[v]):artist[v];
    const auto source_id=scene.add("Displaced detailed FaceSkin",Volume{});
    {
      auto &source=scene.object(source_id);
      source.mesh_active=true;
      source.visible=false;
      source.locked=true;
      source.group=group;
      source.transform=scene.object(id).transform;
      source.painted=std::make_shared<PaintedMesh>(std::move(high),256);
    }
    scene.select(id);
    const auto before=scene.encode();
    const auto original=scene.active().painted;
    const auto appearance=scene.active().appearance;
    const auto deformation=scene.active().deformation;
    ObjectBakeSettings options;
    options.front_mm=options.back_mm=30;
    options.ao_samples=0;
    options.allow_partial=true;
    options.padding=4;
    options.corresponding_topology=true;
    auto baked=scene;
    const auto report=bake_object(baked,source_id,options);
    auto &result=baked.active();
    check(report.projected>2000&&!report.rays&&result.appearance==appearance&&
          result.deformation==deformation&&result.painted->mesh_owner()==original->mesh_owner(),
          "Matching detail reaches the real avatar surface without projection rays or owner changes");
    const auto &image=result.painted->baked()->maps.normal;
    bool varying=false;
    std::array<uint8_t,3> first{};
    bool seen=false;
    for(size_t i=0;i<image.rgba.size();i+=4){
      if(!image.rgba[i+3])continue;
      const std::array<uint8_t,3> rgb{image.rgba[i],image.rgba[i+1],image.rgba[i+2]};
      if(seen)varying|=rgb!=first;else first=rgb;
      seen=true;
    }
    check(seen&&varying,"The matching normal field contains measured nonconstant detail");
    const auto file=out/(std::string(baseline)+".dsculpt");
    const auto expected=baked.encode();
    Document doc;
    doc.replace(scene);
    doc.bake_from_object(source_id,options);
    doc.save_async(file).get();
    check(doc.wait_asset()&&doc.frame().state->error.empty()&&
          Scene::load(file).encode()==expected&&doc.undo()&&doc.copy_scene().encode()==before,
          "Ordinary document Bake, ordered Save and Undo preserve the real avatar exactly");
    std::cout<<"MATCHING_AVATAR "<<baseline<<" projected="<<report.projected<<" missed="<<report.missed<<std::endl;
  }
  return 0;
} catch(const std::exception &error) {
  std::cerr << "FAIL " << error.what() << '\n';
  return 1;
}
