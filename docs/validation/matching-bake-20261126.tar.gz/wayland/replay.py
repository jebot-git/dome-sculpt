#!/usr/bin/env python3
"""Exercise matching bake topology through an isolated native DomeD Wayland session."""
import asyncio,json,math,os,platform,re,signal,socket,struct,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
from dbus_next.aio import MessageBus
from dbus_next import Variant
from Xlib import X,XK,display
from Xlib.ext import xtest
from PIL import Image,ImageChops
signal.pthread_sigmask(signal.SIG_SETMASK,[])
if os.environ.get('DOME_PROJECTION_WL_BUS')!='1':os.execvpe('dbus-run-session',['dbus-run-session','--',sys.executable,*sys.argv],{**os.environ,'DOME_PROJECTION_WL_BUS':'1'})
root=Path(__file__).resolve().parents[1];build=Path(os.environ.get('DOME_SCULPT_TEST_BUILD',root/'build'));compositor=Path(os.environ['DOME_COMPOSITOR']);out=Path(os.environ['DOME_CAGE_WL_OUT']);out.mkdir(parents=True,exist_ok=True);checks=[];processes=[]
texture_set=os.environ.get('DOME_CAGE_TEXTURE_SET')=='1'
def check(ok,label):
 checks.append({'passed':bool(ok),'check':label});(out/'report.json').write_text(json.dumps({'checks':checks,'complete':False},indent=2)+'\n');print(('PASS ' if ok else 'FAIL ')+label,flush=True);assert ok,label
async def wait(fn,seconds=60):
 end=time.monotonic()+seconds
 while time.monotonic()<end:
  try:
   value=fn()
   if value:return value
  except (OSError,ValueError,KeyError,StopIteration):pass
  await asyncio.sleep(.08)
 raise TimeoutError('Private DomeD projection condition timed out')
def start(args,name,env,**kw):
 log=(out/(name+'.log')).open('w');p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,**kw);processes.append(p);return p
async def main():
 with tempfile.TemporaryDirectory(prefix='dome-cage-wl-',ignore_cleanup_errors=True) as home:
  rd,wr=os.pipe();start(['Xvfb','-displayfd',str(wr),'-screen','0','1600x1000x24','-nolisten','tcp','-noreset'],'xvfb',os.environ.copy(),pass_fds=(wr,));os.close(wr)
  with os.fdopen(rd) as pipe:screen=':'+pipe.readline().strip()
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  icd=next(p for p in (Path('/usr/share/vulkan/icd.d/lvp_icd.json'),Path('/usr/share/vulkan/icd.d/lvp_icd.'+platform.machine()+'.json')) if p.is_file())
  config=Path(home,'config/dome');config.mkdir(parents=True);(config/'keyboard.json').write_text(json.dumps({'ime':False,'layout':'us'}))
  env={**os.environ,'HOME':home,'DISPLAY':screen,'XDG_CONFIG_HOME':home+'/config','XDG_DATA_HOME':home+'/data','XDG_CACHE_HOME':home+'/cache','XDG_RUNTIME_DIR':home,'XDG_CURRENT_DESKTOP':'Dome','XDG_SESSION_TYPE':'wayland','VK_DRIVER_FILES':str(icd),'LIBGL_ALWAYS_SOFTWARE':'1','GIO_USE_VFS':'local','LIBGL_KOPPER_DISABLE':'true','LP_NUM_THREADS':'2','DOME_RENDER_CAPTURE':str(out/'render.ppm'),'DOME_LOGIN_SESSION':'0','DOME_PREVIEW_PORT':str(port),'DOME_RENDERER':'vulkan','DOME_START_XR':'0','DOME_START_TRAY':'0','DOME_START_IME':'0','DOME_SESSION_RESTORE':'0','DBUS_SYSTEM_BUS_ADDRESS':'unix:path=/nonexistent/viewport-test-bus','XR_RUNTIME_JSON':'/nonexistent/viewport-no-headset.json','RUST_LOG':'warn','SPNAV_SOCKET':home+'/spnav.sock'}
  for k in ('WAYLAND_DISPLAY','WAYLAND_SOCKET','FLTK_BACKEND','QT_QPA_PLATFORM'):env.pop(k,None)
  host_process=start([str(compositor),'--backend','nested'],'compositor',env);base=f'http://127.0.0.1:{port}'
  def scene():return json.load(urllib.request.urlopen(base+'/api/state',timeout=2))['scene']
  def action(data):urllib.request.urlopen(urllib.request.Request(base+'/api/action',data=json.dumps(data).encode(),headers={'Content-Type':'application/json'}),timeout=2).close()
  await wait(lambda:scene()['source']=='wayland');wayland=re.search(r'Dome Wayland socket: (\S+)',(out/'compositor.log').read_text())[1]
  project=Path(home,'topology.dsculpt')
  helper=os.environ['DOME_MATCHING_BAKE_HELPER']
  subprocess.run([helper,'--ui-topology-fixture',project],check=True,env=env)
  original_bytes=project.read_bytes()
  report=Path(home,'widgets.json')
  client=start([os.environ['DOME_CAGE_APP'],str(project)],'client',{**env,'WAYLAND_DISPLAY':wayland,'FLTK_BACKEND':'wayland','LD_PRELOAD':os.environ['DOME_CAGE_PROBE'],'LD_LIBRARY_PATH':os.environ.get('DOME_CAGE_CLIENT_LD_LIBRARY_PATH',env.get('LD_LIBRARY_PATH','')),'DOME_CAGE_WIDGET_REPORT':str(report)},cwd=home)
  def named(title):return next((w for w in scene()['windows'] if title in w['title']),None)
  window=await wait(lambda:named('topology.dsculpt'));(out/'runtime-maps.txt').write_text(Path('/proc/'+str(client.pid)+'/maps').read_text());check(window['app_id']=='org.domed.Sculpt','Native Wayland Bake client publishes the Dome Sculpt identity')
  d=display.Display(screen);host=await wait(lambda:next((w for w in d.screen().root.query_tree().children if 'Dome' in str(w.get_wm_name() or '')),None));host.set_input_focus(X.RevertToParent,X.CurrentTime);d.sync();action({'op':'focus','id':window['id']});await asyncio.sleep(.4)
  async def key(name,down=None):
   code=d.keysym_to_keycode(XK.string_to_keysym(name))
   for kind in ([X.KeyPress,X.KeyRelease] if down is None else [X.KeyPress if down else X.KeyRelease]):xtest.fake_input(d,kind,code);d.sync();await asyncio.sleep(.06)
  async def chord(*names):
   for n in names:await key(n,True)
   for n in reversed(names):await key(n,False)
  bus=await MessageBus().connect();db=bus.get_proxy_object('org.freedesktop.DBus','/org/freedesktop/DBus',await bus.introspect('org.freedesktop.DBus','/org/freedesktop/DBus')).get_interface('org.freedesktop.DBus');menu=None
  end=time.monotonic()+60
  while menu is None and time.monotonic()<end:
   for service in await db.call_list_names():
    if not service.startswith(':'):continue
    try:
     endpoint='/org/de_xr/FLTK/Menu1';candidate=bus.get_proxy_object(service,endpoint,await asyncio.wait_for(bus.introspect(service,endpoint),1)).get_interface('com.canonical.dbusmenu');result=await candidate.call_get_layout(0,-1,[])
     if 'Bake surface...' in str(result):menu=candidate;break
    except Exception:pass
   if menu is None:await asyncio.sleep(.1)
  check(menu is not None,'Native Wayland client exports the universal Bake surface command')
  async def layout():
   result=await menu.call_get_layout(0,-1,[])
   nodes={}
   def walk(node):
    ident,properties,children=node
    nodes[properties.get('label',Variant('s','')).value.replace('_','')]=(ident,properties)
    for child in children:walk(child.value)
   walk(result[1])
   return nodes
  async def command(label):
   nodes=await layout()
   ident,properties=nodes[label]
   assert properties.get('enabled',Variant('b',True)).value,label
   await menu.call_event(ident,'clicked',Variant('i',0),0)
   await asyncio.sleep(.15)
  def widget(label,window_label="Bake surface"):
   try:windows=json.loads(report.read_text())
   except (OSError,ValueError):return None
   def walk(item):
    if item['label']==label:return item
    for c in item.get('children',[]):
     found=walk(c)
     if found:return found
   for w in windows:
    if w['label']==window_label:
     found=walk(w)
     if found:return found
  label='Bake surface...'
  title='Bake surface'
  option='Match source triangles'
  async def open_dialog():
   await command(label)
   dialog=await wait(lambda:named(title))
   host.set_input_focus(X.RevertToParent,X.CurrentTime)
   d.sync()
   action({'op':'focus','id':dialog['id']})
   await wait(lambda:scene()['focused']==dialog['id'])
   return dialog
  async def focus_widget(label,caption=title):
   await wait(lambda:widget(label,caption))
   for _ in range(36):
    if widget(label,caption)['focused']:return True
    await key('Tab')
   return False
  async def choose_source():
   assert await focus_widget('Source')
   if 'Half blue' not in widget('Source',title)['selected']:
    await key('space')
    await key('Up')
    await key('Return')
   await wait(lambda:'Half blue' in widget('Source',title)['selected'])
  async def toggle():
   assert await focus_widget(option)
   await key('space')
   return await wait(lambda:widget('Cage mesh',title) if not widget('Cage mesh',title)['active'] else None)
  async def save_project():
   old=project.stat().st_mtime_ns
   await command('Save')
   await wait(lambda:project.stat().st_mtime_ns!=old,90)
   return project.read_bytes()
  def inspect():
   return json.loads(subprocess.check_output([helper,'--inspect',project],env=env))
  original=inspect()
  dialog=await open_dialog()
  check(dialog['app_id']==window['app_id'] and (await wait(lambda:widget('Cage mesh',title)))['active'],
        'Bake opens with the native app identity and editable ray cage')
  await choose_source()
  check(await toggle(),'The native matching switch disables cage projection')
  await chord('Control_L','w')
  await wait(lambda:named(title) is None)
  check(project.read_bytes()==original_bytes,'Ctrl+W cancels a staged matching bake')
  await open_dialog()
  await choose_source()
  await toggle()
  check(await focus_widget('Bake'),'DomeD keyboard routing reaches the actual Bake action')
  await key('space')
  await wait(lambda:named('Bake surface - complete'),90)
  await chord('Control_L','w')
  await wait(lambda:named(title) is None)
  saved=await save_project()
  after=inspect()
  baked=after['objects'][0]['painted']
  recipe=after['objects'][0]['bake_recipe']
  check(recipe['version']==2 and recipe['settings']['corresponding_topology'] and
        recipe['source']['object']==after['objects'][1]['id'] and recipe['cage'] is None,
        'Native Wayland Save records the matching recipe and live source')
  color=baked['baked']['color']['bytes']
  check(all(color[i:i+4]==[0,0,255,255] for i in range(0,len(color),4)) and
        baked['layers']==original['objects'][0]['painted']['layers'] and after['objects'][1:]==original['objects'][1:],
        'The applied bake transfers the entire displaced source while retaining source and target layers')
  (out/'topology.dsculpt').write_bytes(saved)
  await open_dialog()
  assert await focus_widget(option)
  await key('space')
  await wait(lambda:widget('Cage mesh',title)['active'])
  assert await focus_widget('Use last bake')
  await key('space')
  await wait(lambda:not widget('Cage mesh',title)['active'])
  check(True,'Native Recall restores matching mode after switching the local draft to rays')
  await chord('Control_L','w')
  await wait(lambda:named(title) is None)
  await command('Undo')
  check(await save_project()==original_bytes,'Universal Undo restores exact original project bytes')
  await command('Redo')
  check(await save_project()==saved,'Universal Redo restores exact matching Bake project bytes')
  await command('Close Window')
  await wait(lambda:client.poll() is not None)
  check(client.returncode==0,'Native Wayland Bake client closes normally')
  (out/'final-scene.json').write_text(json.dumps(scene(),indent=2))
  (out/'report.json').write_text(json.dumps({'checks':checks,'complete':True},indent=2)+'\n')
  d.close()
  bus.disconnect()
try:asyncio.run(main())
finally:
 for p in reversed(processes):
  if p.poll() is None:
   p.terminate()
   try:p.wait(timeout=8)
   except subprocess.TimeoutExpired:p.kill();p.wait()
