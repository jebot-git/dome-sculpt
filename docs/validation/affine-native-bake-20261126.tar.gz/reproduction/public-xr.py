from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import signal
signal.pthread_sigmask(signal.SIG_SETMASK, [])
app,runtime,inspector,fixture,out=map(Path,sys.argv[1:])
out.mkdir(exist_ok=True)
manifest=out/'runtime.json'
manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(runtime)}}))
home=out/'home'
home.mkdir(exist_ok=True)
before_hash=hashlib.sha256(fixture.read_bytes()).hexdigest()
def scene(path):
    data=json.loads(subprocess.check_output([inspector,path],text=True))
    return data.get('payload',data)
before=scene(fixture)
checks=[]
def check(ok,label):
    checks.append({'passed':bool(ok),'check':label})
    (out/'report.json').write_text(json.dumps({'checks':checks},indent=2)+'\n')
    assert ok,label
for mode in ('accept','cancel'):
    native=out/(mode+'.dsculpt')
    report=out/(mode+'.json')
    env={**os.environ,'XR_RUNTIME_JSON':str(manifest),'DOME_XR_FIXTURE_BAKE':mode,
         'DOME_XR_FIXTURE_REPORT':str(report),'HOME':str(home),'XDG_RUNTIME_DIR':str(home),
         'XDG_CONFIG_HOME':str(home/'config'),'XDG_STATE_HOME':str(home/'state')}
    with (out/(mode+'.log')).open('w') as log:
        run=subprocess.run([app,'--xr','--open',fixture,'--frames','75','--save',native],
                           env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    check(run.returncode==0 and native.is_file(),mode+' submits a native project and exits normally')
    result=json.loads(report.read_text())
    check(os.environ['DOME_XR_REQUIRE_RENDERER'] in result.get('gl_renderer',''),
          mode+' uses the requested renderer')
    check(result['left_eye_nonblank']>0 and result['right_eye_nonblank']>0 and
          result['acquires']==result['image_waits']==result['releases'] and
          result['frames_waited']==result['frames_begun']==result['frames_ended'],
          mode+' renders both stereo eyes with balanced image and frame ownership')
    after=scene(native)
    if mode=='accept':
        donor,patch=after['objects']
        paint=patch['painted'].get('payload',patch['painted'])
        check(not donor['visible'] and patch['visible'] and
              patch['bake_recipe']['source']['object']==donor['id'] and bool(paint.get('baked')),
              'Actual joystick Bake uses the hidden posed affine donor')
        comparison=before['objects'][0]
        check(donor['painted']==comparison['painted'] and donor['deformation']==comparison['deformation']
              and after['affine_state']==before['affine_state'],
              'Ordered Save keeps the entire original paint, skin, morphs and affine placement')
    else:
        check(native.read_bytes()==fixture.read_bytes(),'Cancel preserves native project bytes exactly')
check(hashlib.sha256(fixture.read_bytes()).hexdigest()==before_hash,'Immutable input bytes are unchanged')
print(len(checks),'actual-loader XR checks passed')
