#include "dome/volume.hpp"
#include "dome/mesh.hpp"
#include "dome/affine.hpp"
#include <iostream>
int main(){
 for(float radius:{.2f,.201f,.197f})for(float t:{0.f,.4f,1.f}){
  dome::Volume volume(.01f);dome::Brush brush;brush.radius=radius;volume.begin_stroke();volume.stamp(brush);volume.end_stroke();
  const std::array<double,16> m{-1.3,0,0,0,.25,.8,0,0,0,0,1.2,0,2*t,t,.4*t,1};
  const dome::AffineTransform transform(m);
  auto mesh=dome::surface_mesh(volume);
  std::cout<<radius<<' '<<t<<" local "<<mesh.indices.size()/3<<" triangles ";
  try{mesh.validate();std::cout<<"valid";}catch(const std::exception&e){std::cout<<e.what();}
  for(auto&p:mesh.positions){const auto q=transform.point({p.x,p.y,p.z});p={float(q[0]),float(q[1]),float(q[2])};}
  std::cout<<" placed ";
  try{mesh.validate();std::cout<<"valid";}catch(const std::exception&e){std::cout<<e.what();}
  std::cout<<'\n';
 }
}
