"""Additive component targets; original App/DSO expectations remain immutable."""
import importlib.util,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
OLD=R/'artifacts/app1bc-source8-gui-regression-20261115'
paths=list(sys.path);sys.path.insert(0,str(OLD))
try:
 spec=importlib.util.spec_from_file_location('qualified_app1bc_component_cohort',OLD/'cohort.py');_old=importlib.util.module_from_spec(spec);spec.loader.exec_module(_old)
finally:sys.path[:]=paths
S,B,HEAD,TARGETS,G,sha,write,verify=(_old.__dict__[key]for key in ['S','B','HEAD','TARGETS','G','sha','write','verify'])
from runtime_contract import merge_pins
SOURCE='6c8f042cb1730fa017595e9a710b8c8c6015a9ea'
def add(pins,path,want=None):
 path=str(path);actual=sha(path);assert want is None or actual==want,('Input changed',path);merge_pins(pins,{path:actual})
def admit(profile,native_status,native_sha):
 old=_old.admit(profile);pins=dict(old['pins'])
 add(pins,native_status,native_sha);native=json.loads(native_status.read_text())
 assert native['state']=='terminal'and native['exit']==0 and not native['input_drift']and native['source']==SOURCE and native['product']=='1bc13125'
 assert native['lease']['before_any_built_product']and native['lease']['released_epoch']>=native['lease']['acquired_epoch']
 for row in native['steps']:assert 'error'not in row and not row['signals']
 prior=native_status.parent;inputs=prior/'inputs-final.json';add(pins,inputs);merge_pins(pins,json.loads(inputs.read_text()))
 for path,want in native['outputs'].items():add(pins,path,want)
 summary=prior/'verified-summary.json';add(pins,summary);j=json.loads(summary.read_text())
 assert j['source']==SOURCE and j['native91']==91 and j['positive_verifier_calls']==32 and j['wrong_original_rejections']==8 and j['finite_first_prepared_to_second_normal_bound']==.035 and j['original_font4_exact']and j['additive_labels']==22 and not j['UI_execution']
 link=prior.parent/'status.json';add(pins,link);linked=json.loads(link.read_text());assert linked['state']=='terminal'and linked['exit']==0 and not linked['input_drift']and linked['source']==SOURCE
 target_rows={key:dict(row)for key,row in old['targets'].items()};original={key:dict(target_rows[key])for key in ['workflow','font','runtime']}
 for role,key in [('workflow','prepared'),('font','font'),('runtime','runtime')]:
  row=linked['products'][key];assert row['path']not in [x['path']for x in original.values()];add(pins,row['path'],row['sha256']);target_rows[role]={**row,'source_role':'complete fresh test component from6c8; product1bc context'}
 titles=prior/'titles-public.json';add(pins,titles);font=json.loads(titles.read_text());assert font['font_pixels']==16 and len(font['masks'])==26;add(pins,font['font_file'])
 suite=prior/'capsules/manifest.json';add(pins,suite);j=json.loads(suite.read_text());assert j['kind']=='ordinary-prepared-normal-public-suite'and set(j['cases'])=={'mt0-rest','mt0-posed','mt1-rest','mt1-posed'}
 provenance=P/'scenario-provenance.json';add(pins,provenance);v=json.loads(provenance.read_text());assert v['source_commit']==SOURCE
 for row in v['scenarios'].values():add(pins,row['source'],row['source_sha256']);add(pins,row['copy'],row['copy_sha256']);assert row['source_sha256']==row['copy_sha256']
 for path,want in v['unchanged_monitor_inputs'].items():add(pins,path,want)
 add(pins,P/'cohort.py');assert not verify(pins)
 return {**old,'scope':'Qualified App1bc component plus fresh6c8 test components and verified native prepared capsules/fonts. Not whole combined90/physical device qualification. All original baseline/component expectations retained.','pins':pins,'targets':target_rows,'original_test_targets_preserved':original,'prepared_source':SOURCE,'native_admission':{'path':str(native_status),'sha256':native_sha},'fixture_root':str(suite.parent),'font_reference':str(titles),'GUI_runtime_DSO_used':False}
