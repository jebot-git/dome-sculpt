"""Independently evaluate emitted GLB vertices from public joint and morph streams."""
import json
from pathlib import Path
import struct
import cbor2
import numpy as np

root = Path(__file__).resolve().parent
profile = root / "release"

def matrix(v):
    return np.array(v, dtype=float).reshape((4, 4), order="F")

def trs(t, q, s):
    x, y, z, w = np.array(q) / np.linalg.norm(q)
    result = np.eye(4)
    result[:3, :3] = np.array([
        [1-2*y*y-2*z*z, 2*x*y-2*z*w, 2*x*z+2*y*w],
        [2*x*y+2*z*w, 1-2*x*x-2*z*z, 2*y*z-2*x*w],
        [2*x*z-2*y*w, 2*y*z+2*x*w, 1-2*x*x-2*y*y],
    ]) @ np.diag(s)
    result[:3, 3] = t
    return result

def unit(q):
    return [*q[1:], q[0]]

def expected(project):
    scene = cbor2.loads(project.read_bytes())
    scene = scene.get("payload", scene)
    obj = next(o for o in scene["objects"] if o["id"] == scene["active"])
    assert obj["group"] == 0
    placement = trs(obj["translation"], obj["rotation"], [obj["scale"]] * 3)
    assert obj.get("affine_edit") is None
    vertices = obj["painted"].get("payload", obj["painted"])["mesh"]["positions"]
    points = np.frombuffer(vertices,dtype="<f4").reshape((-1,3))
    state = obj["deformation"]
    skeleton = state["skeleton"]
    space = matrix(skeleton["space_matrix"])
    rest, pose = [], []
    for definition, current in zip(skeleton["bones"], state["pose"], strict=True):
        base = trs(definition["translation"], unit(definition["rotation"]), definition["scale"])
        bind = matrix(definition["rest_matrix"]) if definition["rest_matrix"] else base
        now = trs(current["translation"], unit(current["rotation"]), current["scale"])
        if "full_local_matrix" in current:
            now = matrix(current["full_local_matrix"])
        elif definition["rest_matrix"]:
            now = now @ np.linalg.inv(base) @ bind
        parent = definition["parent"]
        rest.append((rest[parent] if parent >= 0 else space) @ bind)
        pose.append((pose[parent] if parent >= 0 else space) @ now)
    inverse_binds = [matrix(v) for v in skeleton["inverse_bind_override"]] if "inverse_bind_override" in skeleton else [np.linalg.inv(r) for r in rest]
    skinning = [placement @ current @ bind for current, bind in zip(pose, inverse_binds, strict=True)]
    scaled = np.array(points, dtype=float)
    for weight, target in zip(state["morph_weights"], state["morphs"]["targets"], strict=True):
        scaled += weight * np.asarray(target["delta"],dtype=float)
    rows = np.zeros((len(points), len(skinning)))
    for v, influences in enumerate(state["skin"]["vertices"]):
        for j, weight in influences:
            rows[v, j] = weight
    result = np.array([sum(weight * transform @ np.append(p, 1)
                           for weight, transform in zip(row, skinning, strict=True))
                       for row, p in zip(rows, scaled, strict=True)])
    return points, result, rows

def consumer(file, proof):
    path = profile / file
    data = path.read_bytes()
    assert data[:12] == struct.pack("<4sII", b"glTF", 2, len(data))
    count, name = struct.unpack_from("<I4s", data, 12)
    assert name == b"JSON"
    gltf = json.loads(data[20:20+count])
    size, name = struct.unpack_from("<I4s", data, 20+count)
    assert name == bytes((66, 73, 78, 0))
    binary = memoryview(data)[28+count:28+count+size]
    buffers = {5121:np.dtype("<u1"),5123:np.dtype("<u2"),5125:np.dtype("<u4"),5126:np.dtype("<f4")}
    def accessor(i):
        a = gltf["accessors"][i]
        b = gltf["bufferViews"][a["bufferView"]]
        dtype = buffers[a["componentType"]]
        components = {"SCALAR":1,"VEC3":3,"VEC4":4,"MAT4":16}[a["type"]]
        start = b.get("byteOffset", 0) + a.get("byteOffset", 0)
        step = b.get("byteStride", components*dtype.itemsize)
        x = np.ndarray((a["count"], components), dtype=dtype, buffer=binary, offset=start,
                       strides=(step,dtype.itemsize))
        return x / np.iinfo(dtype).max if a.get("normalized") else x
    nodes = gltf["nodes"]
    parents = {child:parent for parent,n in enumerate(nodes) for child in n.get("children", [])}
    def world(i):
        v = nodes[i]
        local = matrix(v["matrix"]) if "matrix" in v else trs(
            v.get("translation", [0,0,0]), v.get("rotation", [0,0,0,1]), v.get("scale", [1,1,1]))
        return world(parents[i]) @ local if i in parents else local
    node, = (n for n in nodes if "mesh" in n)
    skin = gltf["skins"][node["skin"]]
    joint_matrices = [world(joint) @ matrix(ibm) for joint, ibm in
                      zip(skin["joints"], accessor(skin["inverseBindMatrices"]), strict=True)]
    mesh = gltf["meshes"][node["mesh"]]
    expected_positions, expected_world, expected_rows = proof
    worst = 0
    weight_error = 0
    surface_corners = 0
    for primitive in mesh["primitives"]:
        attrs = primitive["attributes"]
        rest = accessor(attrs["POSITION"])
        poses = rest.astype(float, copy=True)
        for value, target in zip(node.get("weights", mesh.get("weights", [])), primitive.get("targets", []), strict=True):
            poses += value * accessor(target["POSITION"])
        for index in accessor(primitive["indices"]).flat:
            v = int(index)
            weights = np.zeros(len(joint_matrices))
            for key in range(16):
                if "JOINTS_" + str(key) not in attrs:
                    break
                joints = accessor(attrs["JOINTS_" + str(key)])[v]
                values = accessor(attrs["WEIGHTS_" + str(key)])[v]
                for joint, value in zip(joints, values, strict=True):
                    weights[int(joint)] += value
            actual = sum(weight * transform @ np.append(poses[v],1)
                         for weight, transform in zip(weights, joint_matrices, strict=True))
            offsets = np.linalg.norm(expected_positions - rest[v], axis=1)
            matches = np.where(offsets < 5e-7)[0]
            assert len(matches), (path, tuple(rest[v]))
            same_position = min(matches, key=lambda k: np.linalg.norm(expected_world[k] - actual))
            error = float(np.linalg.norm(expected_world[same_position] - actual))
            worst = max(worst,error)
            weight_error = max(weight_error, float(np.max(np.abs(weights - expected_rows[same_position]))))
            surface_corners += 1
    assert surface_corners == 6 and worst < 3e-6 and weight_error < 3e-6, (path, worst, weight_error)
    return {"file": file, "corners":surface_corners, "maximum_position_error_m":worst,
            "maximum_weight_error":weight_error}

reports = []
for placement in ("plain","affine"):
    folder = "retopology-reapply-" + placement
    proof = expected(profile / folder / "reapplied.dsculpt")
    reports.append(consumer(f"{folder}/reapplied.glb",proof))
(root / "consumer.json").write_text(json.dumps(reports,indent=2)+"\n")
print(json.dumps(reports,indent=2))
