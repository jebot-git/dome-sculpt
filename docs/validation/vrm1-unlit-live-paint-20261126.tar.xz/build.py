from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys

base = Path(__file__).resolve().parent
artifacts = base.parent
source = artifacts/"vrm1-unlit-live-paint-source-20261126"
profile, revision = sys.argv[1:]
out = base/(profile+"-"+revision)
out.mkdir(mode=0o700, exist_ok=True)
build = artifacts/{"release":"vrm-consumer-combined-20261126",
                  "asan":"core-gltf-normal-export-asan-20261126"}[profile]
parent = build/"libdome-sculpt-core.a"
if profile=="asan":
    parent=artifacts/"authoring-regression-integration-current-asan-20261126"/parent.name
targets = {"vrm1-expressions":"tests/vrm1-expressions.cpp",
           "vrm1-expression-layer-authoring":"tests/vrm1-expression-layer-authoring.cpp"}
units = [*(f"src/{name}.cpp" for name in
           ["vrm1-export","vrm1-authoring","vrm1-expression-layer","export"]),
         *targets.values()]
commands = json.loads((build/"compile_commands.json").read_text())
def compile(name):
    record = next(row for row in commands if row["file"].endswith("/"+name))
    old = str(Path(record["file"]).parents[1])
    cmd = [x.replace(old,str(source)) for x in shlex.split(record["command"])]
    obj = out/(Path(name).name+".o")
    if obj.exists():
        return name,obj
    cmd[cmd.index("-o")+1]=str(obj)
    with (out/(Path(name).name+".build.log")).open("w") as log:
        print(shlex.join(cmd),file=log,flush=True)
        subprocess.run(cmd,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    return name,obj
with ThreadPoolExecutor(max_workers=3) as workers:
    compiled = dict(workers.map(compile,units))
archive = out/parent.name
shutil.copyfile(parent,archive)
changed = {compiled[name].name:compiled[name] for name in units if name.startswith("src/")}
def output(*args):
    return subprocess.check_output(args,cwd=build)
output("ar","r",str(archive),*map(str,changed.values()))
output("ranlib",str(archive))
members = output("ar","t",str(archive)).decode().splitlines()
assert members == output("ar","t",str(parent)).decode().splitlines()
assert set(changed)<=set(members)
for member in members:
    expected = changed[member].read_bytes() if member in changed else output("ar","p",str(parent),member)
    assert sha256(output("ar","p",str(archive),member)).digest()==sha256(expected).digest()
print(len(members),"verified archive members;",len(changed),"fresh owning TUs",flush=True)
for case, unit in targets.items():
    selector = next(row for row in commands if row["file"].endswith("/"+unit))
    path = next(Path(x) for x in shlex.split(selector["command"]) if x.startswith("CMakeFiles/"))
    target = path.parts[1].removesuffix(".dir")
    raw = output("ninja","-t","commands",target).decode().splitlines()[-1]
    cmd = [x for x in shlex.split(raw)[2:-2] if not x.startswith("-Wl,--dependency-file=")]
    cmd[cmd.index("-o")+1]=str(out/case)
    cmd[cmd.index(parent.name)]=str(archive)
    cmd[next(i for i,x in enumerate(cmd) if x.endswith("/"+Path(unit).name+".o"))]=str(compiled[unit])
    subprocess.run(cmd,cwd=build,check=True)
print("Focused targets linked",flush=True)
