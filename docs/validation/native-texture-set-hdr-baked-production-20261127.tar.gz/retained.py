from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
artifacts = root.parent
source = root / "source"
profile = sys.argv[1]
out = root / (profile+"-baked")
out.mkdir(exist_ok=True)
previous = artifacts / "texture-set-hdr-production-20261127" / (profile+"-export")
shared = artifacts / "native-shared-bake-20261127" / profile
older = artifacts / "native-hdr-compact-20261126" / profile / "build"
codec = artifacts / "hdr-portable-streaming-20261127" / profile / "libdome-sculpt-emission-codec.a"
toolkit = artifacts / "sdk-20261126/toolkit-sanitize" if profile == "asan" else Path("/opt/fltk-vr/toolkit")
env = dict(os.environ, LD_LIBRARY_PATH=f"{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
           LIBGL_ALWAYS_SOFTWARE="1", EGL_PLATFORM="surfaceless", LP_NUM_THREADS="2",
           ASAN_OPTIONS="detect_leaks=1:halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
core = out / "libdome-sculpt-core.a"
entries = json.loads((shared/"build/compile_commands.json").read_text())
parent = shared.parent / "source"

def run(args, name, check=True):
    with (out/(name+".log")).open("w") as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        return subprocess.run(args, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT,
                              timeout=720, check=check).returncode

def compile_object(filename, target="dome-sculpt-core", override=None):
    row = next(c for c in entries if f"/{target}.dir/" in c["output"] and Path(c["file"]).name==filename)
    args = shlex.split(row["command"].replace(str(parent),str(source)))
    if override is not None:
        args[-1]=str(override)
    obj = out / ((override.name if override is not None else filename)+".o")
    args[args.index("-o")+1] = str(obj)
    run(args,obj.stem+"-compile")
    return obj

def link(target, obj=None, name=None):
    line = subprocess.check_output(["ninja","-t","commands",target],cwd=older,text=True).splitlines()[-1]
    args = []
    for word in shlex.split(line)[2:-2]:
        if word.startswith("-Wl,--dependency-file"):continue
        if word==core.name:word=str(core)
        elif word==codec.name:word=str(codec)
        elif obj is not None and f"{target}.dir/" in word and word.endswith(".o"):word=str(obj)
        elif not word.startswith("/") and word.endswith((".a",".o")):word=str(older/word)
        args.append(word)
    path=out/(name or target)
    args[args.index("-o")+1]=str(path)
    run(args,path.name+"-link")
    return path



core=previous/core.name
target="dome-sculpt-texture-set-source-export-test"
executable=link(target,compile_object("texture-set-source-export.cpp",target,override=root/"probe-retained.cpp"),"probe-retained")
for resolution in [512,1024]:
    name=f"probe-retained-{resolution}"
    print(profile,name,run([executable,out/name,str(resolution)],name,check=False),flush=True)
