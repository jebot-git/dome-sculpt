from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

root=Path(__file__).resolve().parent
source=root/"source"
out=source/"docs/validation"
name="native-texture-set-hdr-baked-production-20261127"
archive=out/(name+".tar.gz")
members=set()

def sha(p):
    with Path(p).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def keep(p):
    relative=Path(p)
    members.add(relative)
    return sha(root/relative)

def git(*args):
    return subprocess.check_output(["git","-C",source,*args],text=True).strip()

product=git("rev-parse","HEAD")
assert product.startswith("9dcf0355")
report={
    "baseline":git("rev-parse","HEAD^"),
    "product":product,
    "scope":"Actual Document Bake and rebake, native preview, Save/Open, and Standard and Editable GLB of two separate native HDR PBR material members. Dense predecessor compatibility and independent exact material/EXR reference comparisons.",
    "source_patch_sha256":keep("source.patch"),
    "limits":{"texture_set_work":64_000_000,"texture_set_bytes":256*1024*1024,
              "baked_paint_storage":128*1024*1024},
    "baked_fixture_paint_storage_bytes_per_member":{"dense":43278336,"compact":26632224},
    "controls":{},"profiles":{},"packages":{},"frontends":{},"khronos":{},
    "open":"Larger and prepared retained-source multisets, typed MToon, alternate emission coordinates, HDR VRM, full integrated regression and physical headset verification."
}
for filename in ("baseline.py","retained.py","candidate.py","compact.py","final.py","verify.py",
                 "codec.py","probe.cpp","probe-retained.cpp","legacy.cpp","record.py","khronos.log","khronos-rebake.log",
                 "public-focus-final.py","xr-public-final.py","xr-focus.py","wayland.py"):
    keep(filename)
for key,path,expected in (
        ("dense_preview","release-baked/probe-1024-1024.log","Timed out waiting for actual Document"),
        ("dense_save","release-candidate/probe-1024-1024.log","Texture-set archive exceeds its owning byte budget"),
        ("retained_512","release-baked/probe-retained-512.log","editable exported"),
        ("retained_1024","release-baked/probe-retained-1024.log","Texture-set field preview exceeds its charged work bound")):
    assert expected in (root/path).read_text()
    report["controls"][key]={"observation":expected,"log_sha256":keep(path)}
assert (root/"release-baked/probe-retained-1024.log").read_text().count("refused: Texture-set export exceeds its working budget")==2

tests={
  "dome-sculpt-texture-set-export-test":("PASS",149),
  "dome-sculpt-texture-set-source-export-test":("PASS",6074),
  "dome-sculpt-current-paint-preview-native-test":("PASS",8425),
  "dome-sculpt-texture-set-surfaces-test":("PASS",72),
  "dome-sculpt-texture-set-native-test":("PASS",45),
  "retained-editable":("PASS",44),"retained-standard":("PASS",50),
  "baked-emission-test":("Baked emission",1720),
}
for profile in ("release","asan"):
    directory=Path(profile+"-final")
    log_root=root/directory
    audit={"application_sha256":sha(log_root/"dome-sculpt"),"core_sha256":sha(log_root/"libdome-sculpt-core.a"),
           "baked_emission_sha256":sha(log_root/"libdome-sculpt-baked-emission.a"),"checks":{}}
    for test,(label,count) in tests.items():
        log=directory/(test+".log")
        assert re.search(rf"^{label} {count} ",(root/log).read_text(),re.M),test
        audit["checks"][test]=count
        keep(log)
    bake_count=sum(line.startswith("PASS ") for line in (log_root/"dome-sculpt-bake-test.log").read_text().splitlines())
    assert bake_count==45
    audit["checks"]["dome-sculpt-bake-test"]=bake_count
    for filename in ("dome-sculpt-bake-test.log","probe-512-512.log","probe-1024-1024.log",
                     "legacy.log","legacy-roundtrip.log","archive.log","float-archive.log"):
        keep(directory/filename)
    assert "filesystem error" in (log_root/"legacy.log").read_text()
    assert (log_root/"legacy-roundtrip.log").read_text().count("exact native restore")==2
    assert sha(log_root/"legacy")==sha(log_root/"legacy-replay")
    audit["legacy_replay_executable_sha256"]=sha(log_root/"legacy-replay")
    assert (log_root/"probe-1024-1024.log").read_text().count("exact native restore")==2
    for p in sorted(log_root.glob("*compile.log"))+sorted(log_root.glob("*-link.log")):
        keep(p.relative_to(root))
    for partial in (profile+"-compact",):
        for p in (root/partial).glob("*cpp-compile.log"):
            keep(p.relative_to(root))
    report["profiles"][profile]=audit

for path in [*(f"probe-{sizes}/{part}" for sizes in ("512-512","1024-1024")
               for part in ("source.dsculpt","standard.glb","editable.glb")),
             "production-baked.dsculpt","production-baked-standard.glb","production-baked-editable.glb",
             *(f"legacy-project/{part}" for part in ("source.dsculpt","standard.glb","editable.glb"))]:
    a,b=(root/(profile+"-final")/path for profile in ("release","asan"))
    digest=sha(a)
    assert sha(b)==digest,path
    report["packages"][path]={"bytes":a.stat().st_size,"sha256":digest}
    if path.startswith("legacy-project/"):
        assert sha(root/"release-baked/probe-512-512"/Path(path).name)==digest
        report["packages"][path]["identical_to_original_dense_project"]=True

expected=report["packages"]["probe-1024-1024/standard.glb"]["sha256"]
for mode in ("wayland","software","arc"):
    folder=Path(mode+"-focus-baked-texture-set-hdr")
    status=json.loads((root/folder/"status.json").read_text())
    assert status["terminal"] and status["exit"]==0 and status["native_sha256"]==expected
    profile="asan" if mode=="arc" else "release"
    assert status["app_sha256"]==report["profiles"][profile]["application_sha256"]
    assert status["input_sha256"]==report["packages"]["probe-1024-1024/source.dsculpt"]["sha256"]
    result=json.loads((root/folder/"workflow/report.json").read_text())
    assert status["checks"]==len(result["checks"]) and all(x["passed"] for x in result["checks"])
    for file in (root/folder).rglob("*"):
        if file.is_file() and file.suffix in (".log",".json",".txt") and "home" not in file.parts:
            keep(file.relative_to(root))
    report["frontends"][mode]=status
for line in ((root/"khronos.log").read_text()+(root/"khronos-rebake.log").read_text()).splitlines():
    row=json.loads(line)
    assert row["errors"]==row["warnings"]==0
    row["report_sha256"]=keep(row["filename"]+".khronos.json")
    report["khronos"][row["filename"]]=row

with archive.open("wb") as output:
    with gzip.GzipFile(filename="",fileobj=output,mode="wb",mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode="w") as bundle:
            for member in sorted(members):
                path=root/member
                info=bundle.gettarinfo(path,str(member))
                info.mtime=0
                info.uid=info.gid=0
                info.uname=info.gname=""
                with path.open("rb") as data:
                    bundle.addfile(info,data)
with tarfile.open(archive) as bundle:
    assert set(m.name for m in bundle.getmembers())==set(map(str,members))
    for member in members:
        assert hashlib.file_digest(bundle.extractfile(str(member)),"sha256").hexdigest()==sha(root/member)
report["archive"]={"file":archive.name,"members":len(members),"sha256":sha(archive)}
(out/(name+".json")).write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
