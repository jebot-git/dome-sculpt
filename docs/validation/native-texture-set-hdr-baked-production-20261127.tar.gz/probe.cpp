#include "dome/document.hpp"
#include "dome/emission-native.hpp"
#include "dome/native-authoring.hpp"
#include "dome/texture-sets.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc,char **argv) try {
  using namespace dome;
  if(argc!=4)return 2;
  const std::filesystem::path out=argv[1];
  std::filesystem::create_directories(out);
  const auto size=uint32_t(std::stoul(argv[2]));
  const auto second_size=uint32_t(std::stoul(argv[3]));
  Mesh mesh;
  mesh.positions={{-.8f,-.6f,0},{.8f,-.6f,0},{0,.85f,0},{-.8f,-.6f,.5f},{.8f,-.6f,.5f},{0,.85f,.5f}};
  mesh.normals.assign(6,{0,0,1});
  mesh.uv={{{.1f,.1f}},{{.9f,.1f}},{{.5f,.9f}},{{.1f,.1f}},{{.9f,.1f}},{{.5f,.9f}}};
  mesh.indices={0,1,2,3,4,5};
  Scene scene;
  const auto id=scene.active().id;
  std::array<TextureSetInitialField,2> fields;
  fields[0].resolution=size;
  fields[1].resolution=second_size;
  fields[1].material.name="Second material";
  fields[0].material.double_sided=fields[1].material.double_sided=true;
  TextureSetLimits creation;
  if(std::max(size,second_size)==2048)creation.maximum_work=160'000'000;
  initialize_texture_sets(scene,id,mesh,fields,std::array<TextureSetId,2>{0,1},creation);
  for(TextureSetId set:{0u,1u}){
    const auto authored=edit_texture_set(scene,id,set,[&](PaintedMesh &paint,Material &material){
      material.emissive=set?std::array<float,3>{.2f,.1f,.03f}:std::array<float,3>{.03f,.2f,.1f};
      Brush brush;
      brush.from=brush.to={0,0,set?.5f:0.f};brush.normal={0,0,1};brush.radius=.045f;brush.strength=.81f;
      PaintSettings settings;
      settings.front_only=false;settings.channel=PaintChannel::Emission;settings.emission_units=PaintEmissionUnits::Physical;
      settings.emission=set?std::array<float,3>{.2f,9.f,.8f}:std::array<float,3>{5.f,.12f,.35f};
      paint.begin_stroke();paint.stamp(brush,settings);const bool emission=paint.end_stroke();
      brush.from=brush.to={.2f,-.05f,set?.5f:0.f};brush.radius=.055f;
      settings.channel=PaintChannel::Color;settings.color={.2f,.5f,.1f,.83f};
      paint.begin_stroke();paint.stamp(brush,settings);const bool color=paint.end_stroke();
      return emission&&color;
    });
    if(!authored)throw std::runtime_error("Could not paint actual independent production fields");
  }
  const auto source=scene.add("Hidden physical bake donor",Volume{});
  auto &donor=scene.object(source);
  donor.mesh_active=true;
  donor.visible=false;
  donor.locked=true;
  donor.material.emissive={4,.8f,.25f};
  donor.material.color={.4f,.7f,.22f,1.f};
  for(auto &position:mesh.positions)position.z+=.01f;
  for(size_t vertex=0;vertex<mesh.uv.size();++vertex)mesh.uv[vertex][0]=mesh.uv[vertex][0]*.45f+(vertex>=3?.5f:0.f);
  donor.painted=std::make_shared<PaintedMesh>(mesh,64);
  ObjectBakeSettings settings;
  settings.ao_samples=0;
  settings.allow_backfaces=true;
  settings.corresponding_topology=true;
  Document doc;
  const auto ready=[&]{
    if(!doc.wait_asset(std::chrono::seconds(100))||!doc.wait_mesh(std::chrono::seconds(100)))
     throw std::runtime_error("Timed out waiting for actual Document");
    return doc.frame().state->error;
  };
  for(TextureSetId set:{0,1}){
    scene.select(id);
    select_texture_set(scene,id,set);
    doc.replace(scene);
    std::cout<<"Before Bake "<<set<<" "<<ready()<<std::endl;
    doc.bake_from_object(source,settings);
    if(!doc.wait_asset(std::chrono::seconds(100)))throw std::runtime_error("Bake worker timed out");
    scene=doc.copy_scene();
    const auto field=texture_set_view(scene.object(id),set);
    const auto &bake=field.painted->baked();
    std::cout<<"Baked "<<set<<" "<<field.painted->resolution()<<" paint storage "<<field.painted->storage_bytes()
             <<" FLOAT "<<(bake&&bake->emission_field)<<" frame "<<ready()<<std::endl;
    if(!bake||!bake->emission_field)throw std::runtime_error("The native Bake did not publish");
  }
  doc.save_async(out/"source.dsculpt").get();
  const auto exact=scene.encode();
  doc.open_async(out/"source.dsculpt").get();
  std::cout<<"Cold Open "<<ready()<<std::endl;
  bool okay=true;
  for(auto [name,format]:std::array{std::pair{"standard",AssetExportFormat::Glb},
      std::pair{"editable",AssetExportFormat::EditableGlb512}}){
    const auto path=out/(std::string(name)+".glb");
    try {
      doc.export_asset(path,format).get();
      std::ifstream stream(path,std::ios::binary);
      const std::vector<uint8_t> bytes{std::istreambuf_iterator<char>(stream),{}};
      auto restored=format==AssetExportFormat::Glb?extract_native_emission(bytes):extract_native_authoring(bytes);
      if(!restored||restored->encode()!=exact)throw std::runtime_error("Did not restore the exact native material document");
      std::cout<<name<<" "<<size<<"+"<<second_size<<" "<<bytes.size()<<" bytes; exact native restore"<<std::endl;
    }catch(const std::exception &e){
      std::cout<<name<<" refusal: "<<e.what()<<std::endl;
      okay=false;
    }
  }
  return okay?0:1;
} catch(const std::exception &e) {std::cerr<<e.what()<<std::endl;return 1;}
