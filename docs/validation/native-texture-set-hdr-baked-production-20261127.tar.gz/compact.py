from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
artifacts = root.parent
source = root / "source"
profile = sys.argv[1]
out = root / (profile+"-compact")
out.mkdir(exist_ok=True)
previous = artifacts / "texture-set-hdr-production-20261127" / (profile+"-export")
shared = artifacts / "native-shared-bake-20261127" / profile
older = artifacts / "native-hdr-compact-20261126" / profile / "build"
codec = artifacts / "hdr-portable-streaming-20261127" / profile / "libdome-sculpt-emission-codec.a"
toolkit = artifacts / "sdk-20261126/toolkit-sanitize" if profile == "asan" else Path("/opt/fltk-vr/toolkit")
env = dict(os.environ, LD_LIBRARY_PATH=f"{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
           LIBGL_ALWAYS_SOFTWARE="1", EGL_PLATFORM="surfaceless", LP_NUM_THREADS="2",
           ASAN_OPTIONS="detect_leaks=1:halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
core = out / "libdome-sculpt-core.a"
entries = json.loads((shared/"build/compile_commands.json").read_text())
parent = shared.parent / "source"

def run(args, name, check=True):
    with (out/(name+".log")).open("w") as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        return subprocess.run(args, cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT,
                              timeout=720, check=check).returncode

def compile_object(filename, target="dome-sculpt-core", override=None):
    row = next(c for c in entries if f"/{target}.dir/" in c["output"] and Path(c["file"]).name==filename)
    args = shlex.split(row["command"].replace(str(parent),str(source)))
    if override is not None:
        args[-1]=str(override)
    obj = out / ((override.name if override is not None else filename)+".o")
    args[args.index("-o")+1] = str(obj)
    run(args,obj.stem+"-compile")
    return obj

def link(target, obj=None, name=None):
    line = subprocess.check_output(["ninja","-t","commands",target],cwd=older,text=True).splitlines()[-1]
    args = []
    for word in shlex.split(line)[2:-2]:
        if word.startswith("-Wl,--dependency-file"):continue
        if word==core.name:word=str(core)
        elif word==codec.name:word=str(codec)
        elif word=="libdome-sculpt-baked-emission.a":word=str(out/word)
        elif obj is not None and f"{target}.dir/" in word and word.endswith(".o"):word=str(obj)
        elif not word.startswith("/") and word.endswith((".a",".o")):word=str(older/word)
        args.append(word)
    path=out/(name or target)
    args[args.index("-o")+1]=str(path)
    run(args,path.name+"-link")
    return path



changed=[compile_object(n) for n in ("paint.cpp","texture-set-export.cpp","texture-set-worker.cpp","bake.cpp")]
shutil.copyfile(previous/core.name,core)
run(["ar","rs",core,*changed],"archive")
assert subprocess.check_output(["ar","t",core])==subprocess.check_output(["ar","t",previous/core.name])
for obj in changed:
    assert subprocess.check_output(["ar","p",core,obj.name])==obj.read_bytes()
field=compile_object("baked-emission.cpp","dome-sculpt-baked-emission")
baked=out/"libdome-sculpt-baked-emission.a"
run(["ar","rcs",baked,field],"float-archive")
assert subprocess.check_output(["ar","p",baked,field.name])==field.read_bytes()
link("dome-sculpt")
probe=link("dome-sculpt-emission-export-test",
           compile_object("native-authoring-compiler.cpp",override=root/"probe.cpp"),"probe")
for sizes in [(512,512),(1024,1024)]:
    name=f"probe-{sizes[0]}-{sizes[1]}"
    print(profile,name,run([probe,out/name,*map(str,sizes)],name,check=False),flush=True)

tests={
 "dome-sculpt-texture-set-export-test":"texture-set-export.cpp",
 "dome-sculpt-texture-set-source-export-test":"texture-set-source-export.cpp",
 "dome-sculpt-current-paint-preview-native-test":"current-paint-preview-native.cpp",
 "dome-sculpt-texture-set-surfaces-test":"texture-set-surfaces.cpp",
 "dome-sculpt-texture-set-native-test":"texture-set-native.cpp",
 "dome-sculpt-bake-test":"bake.cpp",
}
for target,file in tests.items():
    executable=link(target,compile_object(file,target))
    run([executable],target)
    if target=="dome-sculpt-texture-set-source-export-test":
        for fmt in ("standard","editable"):
            run([executable,"--retained-hdr-"+fmt,out/("retained-"+fmt)],"retained-"+fmt)
