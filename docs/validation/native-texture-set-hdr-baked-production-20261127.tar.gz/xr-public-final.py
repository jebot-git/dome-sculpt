from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

out=Path(__file__).resolve().parent
art=out.parent
mode=sys.argv[1]
method='baked-texture-set-hdr'
arc=mode=='arc'
profile='asan' if arc else 'release'
prior=out/(profile+'-final')
sdk=art/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
evidence={'mode':mode,'invocation':os.getenv('INVOCATION_ID')}
stage=out/(mode+'-focus-'+method)
stage.mkdir(exist_ok=True)
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(**fields):
    evidence.update(fields)
    (stage/'status.json').write_text(json.dumps(evidence,indent=2)+'\n')
try:
    fixture=out/'release-final/probe-1024-1024/source.dsculpt'
    deadline=time.monotonic()+300
    while True:
        probe=prior/'probe-1024-1024.log'
        if probe.is_file() and 'editable 1024+1024' in probe.read_text():
            break
        if time.monotonic()>deadline:
            raise TimeoutError('Timed out waiting for the exact production build and native packages')
        time.sleep(1)
    app=prior/'dome-sculpt'
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
         'LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1',
         'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
         'DOME_RECIPIENT_EXPECTED':str(out/'release-final/probe-1024-1024/standard.glb'),
}
    if arc:
        node='/dev/dri/renderD129'
        prefix.extend(['--dev-bind',node,node])
        env.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
                   ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                   UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    env['DOME_XR_REQUIRE_RENDERER']='Arc(tm) A770' if arc else 'llvmpipe'
    runtime=art/'hdr-portable-streaming-20261127'/profile/'libdome-sculpt-portable-test-runtime.so'
    command=['/usr/bin/python3',out/'xr-focus.py',app,runtime,fixture,stage/'workflow']
    write(runtime_sha256=sha(runtime))
    for k,v in env.items():prefix.extend(['--setenv',k,v])
    write(phase='run through desktop or OpenXR frontend',app_sha256=sha(app),
          input_sha256=sha(fixture),run_script_sha256=sha(command[1]))
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock,(stage/'run.log').open('w') as log:
        if arc or mode=='wayland':fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,[*prefix,*command])),file=log,flush=True)
        subprocess.run([*prefix,*command],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=540)
    report=stage/'workflow/report.json'
    checks=json.loads(report.read_text())['checks']
    assert len(checks)==10 and all(row['passed'] for row in checks),checks
    native=stage/'workflow/accept/converted.glb'
    write(phase='complete',terminal=True,exit=0,checks=len(checks),report_sha256=sha(report),native_sha256=sha(native))
except BaseException as error:
    write(terminal=True,exit=1,error=repr(error))
    raise
