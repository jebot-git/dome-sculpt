// Independent invocation of the native worker and Editable GLB importer.
#include "dome/document.hpp"
#include "dome/native-authoring.hpp"
#include <chrono>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

int main(int argc, char **argv) try {
  if(argc!=4) throw std::invalid_argument("Usage: auto-key|editable input output");
  dome::Document document;
  document.open(argv[2]);
  if(!document.wait_asset()||!document.wait_mesh(std::chrono::seconds(45))||
      !document.frame().state->error.empty())
    throw std::runtime_error(document.frame().state->error);
  const std::string_view mode=argv[1];
  if(mode=="auto-key") {
    document.author_shape({});
    document.save_async(argv[3]).get();
    if(!document.wait_asset()||!document.frame().state->can_select_shape)
      throw std::runtime_error(document.frame().state->error);
  } else if(mode=="editable") {
    document.export_asset(argv[3],dome::AssetExportFormat::EditableGlb256).get();
    std::ifstream input(argv[3],std::ios::binary|std::ios::ate);
    if(!input) throw std::runtime_error("Cannot open the emitted Editable GLB");
    std::vector<uint8_t> bytes(static_cast<size_t>(input.tellg()));
    input.seekg(0);
    if(!input.read(reinterpret_cast<char*>(bytes.data()),bytes.size()))
      throw std::runtime_error("Cannot read the emitted Editable GLB");
    auto recovered=dome::extract_native_authoring(bytes);
    if(!recovered) throw std::runtime_error("The emitted Editable GLB has no native Scene");
    auto restored=std::filesystem::path(argv[3]);
    restored.replace_extension(".dsculpt");
    recovered->save(restored);
  } else throw std::invalid_argument("Unknown verification mode");
  return 0;
} catch(const std::exception &error) {
  std::cerr<<error.what()<<'\n';
  return 1;
}
