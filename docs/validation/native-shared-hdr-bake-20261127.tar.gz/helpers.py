from pathlib import Path
import json
import os
import shlex
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor

root=Path(__file__).resolve().parent
out=root/'release'
build=out/'build'
baseline=root.parent/'native-hdr-compact-20261126/release/build'
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if Path(e['file']).name=='source-writable-normal-bake.cpp')
raw=subprocess.check_output(['ninja','-t','commands','dome-sculpt-source-writable-normal-bake-test'],cwd=baseline,text=True).splitlines()[-1]
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
case=build/'native-writable-first-key-2048'
def invoke(args,path):
    with (out/path).open('w') as trace:
        print(shlex.join(map(str,args)),file=trace,flush=True)
        subprocess.run(args,cwd=build,env=env,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=180)
def build_target(name):
    obj=out/(name+'.o')
    app=build/name
    args=shlex.split(entry['command'])
    args[args.index('-c')+1]=str(root/(name+'.cpp'))
    args[args.index('-o')+1]=str(obj)
    invoke(args,name+'-compile.log')
    args=[]
    for a in shlex.split(raw)[2:-2]:
        if a.startswith('-Wl,--dependency-file'):continue
        if a.endswith('/source-writable-normal-bake.cpp.o'):a=str(obj)
        elif a=='libdome-sculpt-core.a':a=str(out/a)
        elif not a.startswith('/') and a.endswith(('.a','.o')):a=str(baseline/a)
        args.append(a)
    args[args.index('-o')+1]=str(app)
    invoke(args,name+'-link.log')
    return app
with ThreadPoolExecutor(max_workers=2) as pool:
    automatic,edit=pool.map(build_target,('first-key-extra','varied-key-edit'))
keyed=case/'keyed-2048-varied-hdr.dsculpt'
until=time.monotonic()+100
while not keyed.is_file():
    if time.monotonic()>until: raise TimeoutError('The full-resolution HDR fixture did not save a key')
    state=json.loads((out/'status.json').read_text())
    if state['terminal'] and state['exit']!=0:raise RuntimeError('The native Release fixture failed')
    time.sleep(1)
invoke([automatic,'auto-key',case/'baked-2048-varied-hdr.dsculpt',case/'keyed-auto-2048-varied-hdr.dsculpt'],'first-key-extra.log')
invoke([edit,keyed,out/'edited'],'varied-key-edit.log')
