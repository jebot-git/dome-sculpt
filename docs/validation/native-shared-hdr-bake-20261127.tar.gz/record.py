from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile


root = Path(__file__).resolve().parent
repo = root.parents[1]
destination = repo / "docs/validation"
name = "native-shared-hdr-bake-20261127"
product = subprocess.check_output(
    ["git", "-C", repo, "rev-parse", sys.argv[1]], text=True
).strip()
files = {}


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def keep(path, member=None):
    files[member or str(path.relative_to(root))] = path
    return sha(path)


def read(path):
    return json.loads(path.read_text())


assert subprocess.check_output(["git", "-C", repo, "show", "--format=", "--binary", product]) == (
    root / "source.patch"
).read_bytes()
report = {
    "product": product,
    "source_patch_sha256": keep(root / "source.patch"),
    "scope": "Share one immutable packed FLOAT Bake across native paint leaves on the same authenticated sampling domain. Covers authored varying and constant 2048-square emission, first shapekey, exact archive history and domain refusal.",
    "profiles": {},
    "frontends": {},
}
for filename in (
    "run.py", "record.py", "helpers.py", "first-key-extra.cpp", "varied-key-edit.cpp",
    "public-focus.py", "wayland.py", "xr-focus.py",
):
    keep(root / filename)

def native_case(profile):
    return root / profile / "build/native-writable-first-key-2048"

for profile in ("release", "asan"):
    folder = root / profile
    state = read(folder / "status.json")
    assert state["terminal"] and state["exit"] == 0
    log = (folder / "ctest.log").read_text()
    for line in (
        "100% tests passed, 0 tests failed out of 14",
        "DENSE_HDR_FIRST_KEY varied=0 54940517 archive bytes; Restore exact",
        "DENSE_HDR_FIRST_KEY varied=1 105444452 archive bytes; Restore exact",
        "PASS 27 full-resolution physical Bake and shapekey checks",
    ):
        assert line in log, (profile, line)
    proof = {}
    for filename in (
        "status.json", "configure.log", "archive.log", "ctest.log", "build/regressions.xml",
        "dome-sculpt-link.log",
        *(source + ".log" for source in state["sources"]),
    ):
        proof[filename] = keep(folder / filename)
    report["profiles"][profile] = {
        "app_sha256": sha(folder / "build/dome-sculpt"),
        "ctests": 14,
        "invocation": state["invocation"],
        "logs_sha256": proof,
    }

for kind, keyed_bytes in (("hdr", 54940517), ("varied-hdr", 105444452)):
    data = {step: native_case("release") / f"{step}-2048-{kind}.dsculpt"
            for step in ("baked", "keyed", "restored")}
    digest = {}
    for step, path in data.items():
        digest[step] = {"bytes": path.stat().st_size, "sha256": sha(path)}
        assert digest[step]["sha256"] == sha(native_case("asan") / path.name)
    assert digest["baked"] == digest["restored"]
    assert digest["keyed"]["bytes"] == keyed_bytes
    report[kind] = digest

for frontend in ("wayland", "software", "arc"):
    folder = root / f"{frontend}-focus-varied-hdr-first-key"
    result = read(folder / "status.json")
    assert result["terminal"] and result["exit"] == 0 and result["checks"] == 10
    expected = "keyed-2048-varied-hdr.dsculpt" if frontend == "wayland" else "keyed-auto-2048-varied-hdr.dsculpt"
    assert result["native_sha256"] == sha(native_case("release") / expected)
    for filename in ("status.json", "run.log", "workflow/report.json"):
        keep(folder / filename)
    filenames = ("client.log", "compositor.log", "runtime-maps.txt") if frontend == "wayland" else (
        "accept.json", "accept.log", "cancel.json", "cancel.log",
    )
    for filename in filenames:
        keep(folder / "workflow" / filename)
    report["frontends"][frontend] = result

edit_log = root / "release/varied-key-edit.log"
assert "VARIED_HDR_KEY_EDIT 210302405 archive bytes; exact HDR field retained" in edit_log.read_text()
report["edit_after_reopen"] = {"bytes": 210302405, "log_sha256": keep(edit_log)}
old = root.parent / "native-hdr-compact-20261126/release/extras"
for file, error in (
    ("hdr-varied-first-key.log", "Scene paint storage budget exceeded"),
    ("hdr-standard-export.log", "Aggregate HDR export fields exceed128MiB"),
):
    assert error in (old / file).read_text()
    keep(old / file, "baseline/" + file)
report["open"] = "Portable HDR export and physical headset verification remain open. The measured Standard HDR export refusal is a distinct staging limit."

archive = destination / (name + ".tar.gz")
with archive.open("wb") as raw, gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as stream, tarfile.open(fileobj=stream, mode="w") as tar:
    for filename, path in sorted(files.items()):
        data = path.read_bytes()
        item = tarfile.TarInfo(filename)
        item.size = len(data)
        tar.addfile(item, io.BytesIO(data))
report["archive"] = {"file": archive.name, "sha256": sha(archive), "members": len(files)}
(destination / (name + ".json")).write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(product, report["archive"])
