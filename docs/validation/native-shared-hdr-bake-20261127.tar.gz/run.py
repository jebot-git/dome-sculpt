from pathlib import Path
import json
import re
import shlex
import shutil
from concurrent.futures import ThreadPoolExecutor
import os
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
source=root/'source'
profile=sys.argv[1]
asan=profile=='asan'
out=root/profile
out.mkdir(exist_ok=True)
build=out/'build'
sdk=root.parent/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
bdf=Path('/opt/fltk-vr/bdf-runtime')
env={**os.environ,'PKG_CONFIG_PATH':f'{bdf}/lib/pkgconfig:/usr/lib64/pkgconfig'}
start=time.monotonic()
state={'candidate':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),
       'profile':profile,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}
def status(**kwargs):
    state.update(kwargs,elapsed=round(time.monotonic()-start,2))
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
def invoke(args,name,limit,check=True):
    with (out/name).open('w') as log:
        return subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=limit,check=check).returncode
try:
    assert subprocess.check_output(['git','-C',source,'diff','--binary','HEAD'])==(root/'source.patch').read_bytes()
    options=[]
    if asan:
        options.extend(f'-DCMAKE_{k}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for k in ('C','CXX'))
        options.extend(f'-DCMAKE_{k}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for k in ('C','CXX'))
    status(phase='configure')
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*options],'configure.log',180)
    targets=('dome-sculpt','dome-sculpt-baked-emission-test','dome-sculpt-baked-emission-gpu-test',
       'dome-sculpt-baked-emission-native-test','dome-sculpt-baked-emission-workflow-test',
       'dome-sculpt-source-writable-normal-bake-test','dome-sculpt-bake-test','dome-sculpt-test-runtime')
    before=root.parent/'native-hdr-compact-20261126'/profile
    old=before/'build'
    assert json.loads((before/'status.json').read_text())['exit']==0
    baseline=old/'libdome-sculpt-core.a'
    next_core=out/baseline.name
    changed=subprocess.check_output(['git','-C',source,'diff','--name-only','HEAD'],text=True).splitlines()
    headers={Path(name).name for name in changed if name.endswith('.hpp')}
    affected={Path(name).name for name in changed if name.startswith('src/') and name.endswith('.cpp')}
    headers_pattern=re.compile(r'^#\s*include\s+"([^"]+)"',re.M)
    deps={p.name:{Path(x).name for x in headers_pattern.findall(p.read_text(errors='replace'))}
          for p in (source/'src').glob('*.[ch]pp')}
    while True:
        users={p for p,includes in deps.items() if includes&headers}
        affected.update(p for p in users if p.endswith('.cpp'))
        added={p for p in users if p.endswith('.hpp')}-headers
        if not added:break
        headers.update(added)
    entries=json.loads((build/'compile_commands.json').read_text())
    core=[e for e in entries if 'CMakeFiles/dome-sculpt-core.dir/' in e['command']
          and Path(e['file']).name in affected]
    assert {Path(e['file']).name for e in core}==affected
    suite='dome-sculpt-source-writable-normal-bake-test'
    test=next(e for e in entries if suite+'.dir/' in e['command'])
    def compile(entry):
        cmd=shlex.split(entry['command'])
        obj=out/(Path(entry['file']).name+'.o')
        cmd[cmd.index('-o')+1]=str(obj)
        cmd.extend(['-MMD','-MF',str(obj)+'.d'])
        invoke(cmd,obj.stem+'.log',600)
        return obj
    status(phase='compile actual changed owners',sources=sorted(affected),targets=targets)
    with ThreadPoolExecutor(max_workers=3) as pool:
        objects=list(pool.map(compile,[*core,test]))
    shutil.copyfile(baseline,next_core)
    invoke(['ar','rs',next_core,*objects[:-1]],'archive.log',180)
    before_names=subprocess.check_output(['ar','t',baseline]).splitlines()
    after_names=subprocess.check_output(['ar','t',next_core]).splitlines()
    assert set(after_names)-set(before_names)=={b'scene-bake-archive.cpp.o'}
    for obj in objects[:-1]:
        assert subprocess.check_output(['ar','p',next_core,obj.name])==obj.read_bytes()
    status(phase='relink app and native fixtures')
    def relink(target):
        command=subprocess.check_output(['ninja','-t','commands',target],cwd=old,text=True).strip().splitlines()[-1]
        raw=shlex.split(command)[2:-2]
        if 'libdome-sculpt-core.a' not in raw:
            (build/target).symlink_to((old/target).resolve())
            return
        args=[]
        for word in raw:
            if word.startswith('-Wl,--dependency-file'):continue
            if word=='libdome-sculpt-core.a':word=str(next_core)
            elif word.endswith('/source-writable-normal-bake.cpp.o'):word=str(objects[-1])
            elif not word.startswith('/') and word.endswith(('.a','.o')):word=str(old/word)
            args.append(word)
        args[args.index('-o')+1]=str(build/target)
        invoke(args,target+'-link.log',480)
    with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(relink,targets))
    (build/'libdome-sculpt-test-runtime.so').symlink_to((old/'libdome-sculpt-test-runtime.so').resolve())
    command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    settings={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
        'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:{bdf}/lib:/usr/lib64'}
    if asan:settings.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in settings.items():command.extend(['--setenv',key,value])
    pattern='^(baked-emission(|-gpu|-native|-workflow|-source|-uv1-worker)|native-writable-(hdr-first-key|varied-hdr-first-key|first-key|editable-export)-2048|legacy-native-key-bake-conversion|native-key-writable-bake-recipient|native-writable-bake-recipient|bake)$'
    status(phase='test exact app and native fixtures')
    rc=invoke([*command,'ctest','--test-dir',build,'-V','-j1','-R',pattern,'--output-on-failure',
           '--output-junit',build/'regressions.xml'],'ctest.log',2600,False)
    status(phase='complete',terminal=True,exit=rc)
    raise SystemExit(rc)
except Exception as error:
    status(terminal=True,exit=1,error=repr(error))
    raise
