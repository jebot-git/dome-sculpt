#include "dome/document.hpp"
#include "dome/polygon-scene.hpp"
#include <chrono>
#include <filesystem>
#include <iostream>

int main(int argc,char **argv) try {
  if(argc!=3)throw std::invalid_argument("Usage: key-edit keyed-project output-directory");
  using namespace dome;
  const auto directory=std::filesystem::path(argv[2]);
  std::filesystem::create_directories(directory);
  const auto converted=directory/"converted-varied-key.dsculpt";
  Document doc;
  const auto wait=[&]{
    if(!doc.wait_asset()||!doc.wait_mesh(std::chrono::seconds(90))||!doc.frame().state->error.empty())
      throw std::runtime_error(doc.frame().state->error);
  };
  doc.open(argv[1]);
  wait();
  const auto former=doc.copy_scene();
  const auto original=former.active().painted->baked()->emission_field;
  ShapeKeyEdit edit;
  edit.action=ShapeKeyAction::Replace;
  edit.positions=former.active().painted->mesh().positions;
  edit.positions.front().z+=.028f;
  doc.author_shape(edit);
  wait();
  if(doc.copy_scene().active().deformation->morphs->targets.front().delta.front().z!=.028f)
    throw std::runtime_error("The actual HDR shapekey did not accept the requested displacement");
  doc.convert_baked_normals();
  doc.save_async(converted).get();
  wait();
  const auto accepted=doc.copy_scene();
  const auto bake=accepted.active().painted->baked();
  if(!bake||bake->emission_field!=original||bake->normal_interpretation!=BakedNormalInterpretation::NativeAttributes)
    throw std::runtime_error("Portable normal conversion changed HDR emission authority");
  const auto cold=Scene::load(converted);
  const auto &reopened=cold.active();
  if(reopened.painted->baked()->emission_field->encode()!=original->encode()||
     reopened.painted->baked()->normal_interpretation!=BakedNormalInterpretation::NativeAttributes)
    throw std::runtime_error("Cold normal conversion read changed baked HDR values");
  std::cout<<"VARIED_HDR_KEY_EDIT "<<std::filesystem::file_size(converted)
           <<" archive bytes; exact HDR field retained\n";
} catch(const std::exception &error){
  std::cerr<<error.what()<<'\n';
  return 1;
}
