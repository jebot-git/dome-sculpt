from pathlib import Path
import subprocess,os,json,time
O=Path(__file__).resolve().parent
subprocess.run(['/usr/bin/python3',str(O/'prepare-inputs.py')],check=True)
cmd=['ninja','-C',str(O),'-d','keepdepfile','-d','keeprsp','-j2','-v']+['dome-sculpt-source-advanced-normal-bake-test', 'dome-sculpt-source-canonical-normal-bake-test', 'dome-sculpt-source-writable-normal-bake-test', 'dome-sculpt-source-joint-writable-normal-bake-test', 'dome-sculpt-source-owning-hdr-domain-test', 'dome-sculpt-source-owning-hdr-export-test', 'dome-sculpt-source-prepared-normal-bake-test', 'dome-sculpt-source-artist-normal-bake-test', 'dome-sculpt-source-owning-hdr-render-test', 'dome-sculpt-creator-workspace-test', 'dome-sculpt-creator-vrm-test', 'dome-sculpt-baked-emission-gpu-test', 'dome-sculpt-mtoon-render-test']
s={'source':'05f5d1ccfa4bb5b97d25e4a425a2fd9497b0d8c9','terminal':False,'start':time.time(),'command':cmd,'scope':'Fresh headless strict core/support/render and13 fixtures; no App, FLTK or XR'}
(O/'build-status.json').write_text(json.dumps(s,indent=2)+'\n')
with (O/'build.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
s.update(terminal=True,exit=r.returncode,seconds=time.time()-s['start']);(O/'build-status.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s),flush=True)
raise SystemExit(r.returncode)
