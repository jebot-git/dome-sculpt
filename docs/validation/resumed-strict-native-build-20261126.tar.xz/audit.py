from pathlib import Path
import hashlib,json,shlex,subprocess,collections,time

B=Path(__file__).resolve().parent
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
status=json.loads((B/'build-status.json').read_text())
assert status['terminal'] and status['exit']==0
pins=json.loads((B/'before-inputs.json').read_text())
expected={str(Path(p).resolve()):v['sha256'] for p,v in pins.items()}
errors=[];owners=[];deps=set();objects=collections.defaultdict(list)
for f in sorted((B/'compiler-records').glob('*.json')):
 r=json.loads(f.read_text());cmd=r['command']
 if r['exit'] or '-fsanitize=address,undefined' not in cmd or '-O1' not in cmd:
  errors.append({'compiler_record':str(f),'reason':'failed or incorrectly instrumented'})
 obj=Path(r['object']);md=Path(r['depfile']);assert sha(obj)==r['object_sha256'] and sha(md)==r['depfile_sha256']
 raw=md.read_text().replace('\\\n',' ')
 paths=[]
 for x in shlex.split(raw.split(':',1)[1]):
  p=Path(x);p=(p if p.is_absolute() else Path(r['cwd'])/p).resolve()
  paths.append(str(p));deps.add(str(p))
 owners.append({'record':str(f),'object':str(obj),'object_sha256':sha(obj),'depfile':str(md),'depfile_sha256':sha(md),'dependencies':paths})
 objects[obj.name].append(sha(obj))
generated=B/'armorpaint-blur-generated/blur_weights.hpp'
writer=subprocess.check_output(['ninja','-C',str(B),'-t','commands',str(generated.relative_to(B))],text=True)
(B/'generated-blur-writer.txt').write_text(writer)
derived={str(generated.resolve()):sha(generated)}
for p in sorted(deps):
 h=sha(p)
 if p in expected:
  if h!=expected[p]:errors.append({'dependency':p,'reason':'input drift'})
 elif p not in derived:errors.append({'dependency':p,'reason':'not prospectively pinned or declared derived'})
archives=[]
for a in sorted(B.glob('*.a')):
 members=subprocess.check_output(['ar','t',str(a)],text=True).splitlines();assert len(members)==len(set(members))
 for m in members:
  h=hashlib.sha256(subprocess.check_output(['ar','p',str(a),m])).hexdigest()
  if h not in objects[m]:errors.append({'archive':str(a),'member':m,'reason':'payload has no actual matching compiled object'})
 archives.append({'path':str(a),'sha256':sha(a),'members':members})
targets=status['command'][status['command'].index('-v')+1:];links=[]
for target in targets:
 p=B/target
 raw=subprocess.check_output(['ninja','-C',str(B),'-t','commands',target],text=True)
 (B/(target+'.commands.txt')).write_text(raw)
 dynamic=subprocess.check_output(['readelf','-d',str(p)],text=True)
 if 'libasan.so' not in dynamic or 'libubsan.so' not in dynamic:errors.append({'ELF':str(p),'reason':'missing sanitizer dependency'})
 links.append({'target':target,'sha256':sha(p),'commands_sha256':sha(B/(target+'.commands.txt'))})
out={'source':status['source'],'scope':status['scope'],'actual_compiler_owners':len(owners),'actual_core_owners':sum('/dome-sculpt-core.dir/' in r['object'] for r in owners),'dependency_paths':len(deps),'owners':owners,'archives':archives,'links':links,'derived_inputs':derived,'errors':errors,'supplemental_tool_observation':'cc1/cc1plus/collect2 observations during build are not claimed before already completed compiles','completed_epoch':time.time()}
(B/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['actual_compiler_owners','actual_core_owners','dependency_paths','errors']}),flush=True)
raise SystemExit(bool(errors))
