from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
artifacts=root.parent
profile=sys.argv[1]
prior=artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile
build=prior/'build'
source=artifacts/'texture-set-recipe-and-hdr-qualification-source-20261126'
candidate='6b5d338ec348767c8494a8fa6387c40af11ce284'
base='b89b1f8c2a3d3346f6b0127c830395df193ecbf3'
sdk=Path('/opt/fltk-vr/toolkit') if profile=='release' else artifacts/'sdk-20261126/toolkit-sanitize'
out=root/profile
out.mkdir(mode=0o700)
status={'profile':profile,'candidate':candidate,'product_source':base,'terminal':False,
        'invocation':os.getenv('INVOCATION_ID')}
def record(**fields):
    status.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')
def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
def run(cmd,name,timeout):
    with (out/(name+'.log')).open('w') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        subprocess.run(cmd,cwd=build,check=True,timeout=timeout,stdout=log,stderr=subprocess.STDOUT)
try:
    assert git('rev-parse','HEAD')==candidate and not git('status','--porcelain')
    file='tests/polygon-surface-paint.cpp'
    assert git('diff','--name-only',base,'HEAD')==file
    record(phase='wait for matching fresh build and retained original test')
    report=prior/'status.json'
    unit='ds-recipe-hdr-build-'+profile+'-20261126.service'
    while True:
        if report.is_file():
            earlier=json.loads(report.read_text())
            if earlier['terminal']:
                break
        active=subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()
        if active not in ('active','activating') and not (report.is_file() and json.loads(report.read_text())['terminal']):
            raise RuntimeError('Fresh application build ended before writing a terminal receipt')
        time.sleep(5)
    assert earlier['candidate']==base and earlier['phase']=='private native runtime'
    assert earlier['app_sha256']==sha(build/'dome-sculpt')
    log=(prior/'ctest.log').read_text()
    assert '90% tests passed, 1 tests failed out of 10' in log and 'FAIL Float data cannot borrow an absent physical-plane witness' in log
    assert log.count('(Failed)')==1 and 'polygon-surface-paint-private-codec (Failed)' in log
    record(phase='rebuild only the corrected fixture',app_sha256=earlier['app_sha256'],
           core_sha256=earlier['core_sha256'],original_ctest_sha256=sha(prior/'ctest.log'))
    target='dome-sculpt-polygon-surface-paint-test'
    database=json.loads((build/'compile_commands.json').read_text())
    row=next(row for row in database if row['file'].endswith('/'+file) and target+'.dir/' in row['command'])
    cmd=shlex.split(row['command'])
    old_object=cmd[cmd.index('-o')+1]
    replacement=out/'fixture.o'
    cmd[cmd.index('-o')+1]=str(replacement)
    cmd[cmd.index('-c')+1]=str(source/file)
    run(cmd,'compile',240)
    raw=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
    words=[w for w in shlex.split(raw)[2:-2] if not w.startswith('-Wl,--dependency-file=')]
    binary=out/target
    words[words.index('-o')+1]=str(binary)
    words[words.index(old_object)]=str(replacement)
    run(words,'link',240)
    original=build/target
    original_hash=sha(original)
    cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
         '--ro-bind',binary,original,'--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user',
         '--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
         '--setenv','LD_LIBRARY_PATH',f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
    if profile=='asan':
        cmd.extend(['--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
                    '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1'])
    names='^('+'|'.join(earlier['tests'])+')$'
    record(phase='replay the full native set with the exact corrected observer',fixture_sha256=sha(binary))
    run([*cmd,'ctest','--test-dir',build,'-R',names,'--output-on-failure','-V'],'ctest',1600)
    log=(out/'ctest.log').read_text()
    assert '100% tests passed, 0 tests failed out of 10' in log and 'PASS 16407 private Paint6' in log
    assert 'PASS 75 prepared texture recipe controls' in log
    assert sha(original)==original_hash and sha(build/'dome-sculpt')==earlier['app_sha256']
    record(phase='complete',terminal=True,exit=0,ctest_sha256=sha(out/'ctest.log'))
except Exception as e:
    record(terminal=True,exit=1,error=repr(e))
    raise
