from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import signal
import subprocess
import sys
import time

folder=Path(__file__).resolve().parent
artifacts=folder.parent
source=artifacts/"texture-set-recipe-and-hdr-qualification-source-20261126"
profile=sys.argv[1]
hardware=profile=="arc-asan"
lane="asan" if hardware else "release"
product=folder/lane
build=artifacts/"texture-set-recipe-and-hdr-validation-20261126"/lane/"build"
target="libdome-sculpt-test-runtime.so"
companions=[
    "dome-sculpt-bake-controls-test","dome-sculpt-corner-color-uv23-gui-fixture",
    "dome-sculpt-skin-authoring-test","dome-sculpt-retopo-authoring-test",
    "dome-sculpt-cut-authoring-test","dome-sculpt-mask-document-test",
]
out=folder/profile
out.mkdir(mode=0o700,exist_ok=False)
run=out/"workflow"
run.mkdir(mode=0o700)
def git(work,*args):
    return subprocess.check_output(["git","-C",work,*args],text=True).strip()
def sha(p):
    with p.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
status={"candidate":git(source,"rev-parse","HEAD"),"app_source":git(source,"rev-parse","HEAD"),
        "invocation":os.getenv("INVOCATION_ID"),"profile":profile,"terminal":False}
start=time.monotonic()
def write(**fields):
    status.update(fields,elapsed_seconds=round(time.monotonic()-start,2))
    temporary=out/"status.tmp"
    temporary.write_text(json.dumps(status,indent=2)+"\n")
    temporary.replace(out/"status.json")
def logged(name,argv,cwd):
    with (out/(name+".log")).open("w") as log:
        print(shlex.join(map(str,argv)),file=log,flush=True)
        subprocess.run(argv,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True)

try:
    assert not git(source,"status","--porcelain")
    unit="ds-recipe-hdr-qualified-"+lane+"-20261126.service"
    product_status=product/"status.json"
    write(phase="wait for matching native validation")
    while True:
        if product_status.is_file():
            pinned_product=json.loads(product_status.read_text())
            if pinned_product["terminal"]:
                break
        service=subprocess.check_output(["systemctl","--user","show",unit,"-p","ActiveState","--value"],text=True).strip()
        if service not in ("active","activating"):
            if product_status.is_file() and json.loads(product_status.read_text())["terminal"]:
                continue
            raise RuntimeError("Build ended without a terminal receipt")
        time.sleep(5)
    app=build/"dome-sculpt"
    assert pinned_product["exit"]==0 and pinned_product["candidate"]==status["app_source"]
    assert sha(app)==pinned_product["app_sha256"]
    write(phase="build exact app companion tools and private OpenXR runtime")
    logged("build-companions",["cmake","--build",build,"--parallel","3","--target",
                              "dome-sculpt-test-runtime",*companions],build)
    assert sha(app)==pinned_product["app_sha256"]
    write(companion_hashes={name:sha(build/name) for name in companions})
    runner=out/"native-xr.py"
    original=(source/"tests/xr_runtime.py").read_text()
    forced='"LIBGL_ALWAYS_SOFTWARE": "1"'
    assert original.count(forced)==1
    runner.write_text(original.replace(forced,'"LIBGL_ALWAYS_SOFTWARE": "0"') if hardware else original)
    lib=(str(artifacts/"sdk-20261126/toolkit-sanitize/lib") if hardware else "/opt/fltk-vr/toolkit/lib")
    environment={"PATH":"/usr/bin:/bin","HOME":"/tmp","LD_LIBRARY_PATH":lib+":/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
                 "LP_NUM_THREADS":"2","ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1",
                 "UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1"}
    node="/dev/dri/renderD129"
    cmd=["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/","--bind",run,run,
         "--proc","/proc","--dev","/dev","--tmpfs","/tmp","--tmpfs","/run/user","--clearenv"]
    if hardware:
        environment.update(DRI_PRIME="pci-0000_03_00_0",MESA_SHADER_CACHE_DISABLE="1")
        cmd.extend(["--dev-bind",node,node])
        lease=open("/tmp/dome-sculpt-arc-device.lock","rb")
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for key,value in environment.items():
        cmd.extend(["--setenv",key,value])
    cmd.extend(["/usr/bin/python3.14",runner,app,build/target,run])
    write(phase="run full native OpenXR workflow",app_sha256=sha(app),runtime_sha256=sha(build/target),runner_sha256=sha(runner))
    def descendants(pid):
        yield pid
        try:
            children=Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
        except (FileNotFoundError,ProcessLookupError):
            return
        for child in children:
            yield from descendants(int(child))
    witnesses={}
    def measure(pid):
        for child in descendants(pid):
            proc=Path(f"/proc/{child}")
            try:
                if (proc/"exe").resolve()!=app.resolve():
                    continue
                maps=(proc/"maps").read_text()
                fds=set()
                for fd in (proc/"fd").iterdir():
                    try:fds.add(os.readlink(fd))
                    except (FileNotFoundError,ProcessLookupError):continue
                if node not in fds or "/libasan.so" not in maps or "/libubsan.so" not in maps:
                    continue
                args=[s.decode(errors="replace") for s in (proc/"cmdline").read_bytes().split(b"\0") if s]
                paths=[row.rsplit(None,1)[-1] for row in maps.splitlines() if "/libgallium" in row or "/iris_dri.so" in row]
                if paths and "--save" in args:
                    label=Path(args[args.index("--save")+1]).stem
                    witnesses[label]={"pid":child,"node":node,"maps":sorted(set(paths))}
            except (FileNotFoundError,ProcessLookupError):
                continue
    begin=time.monotonic()
    with (out/"run.log").open("w") as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while process.poll() is None:
            if hardware:measure(process.pid)
            if time.monotonic()-begin>600:
                os.killpg(process.pid,signal.SIGTERM)
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid,signal.SIGKILL)
                    process.wait()
                break
            time.sleep(.15)
    report=json.loads((run/"report.json").read_text())
    pass_count=sum(x["passed"] for x in report["checks"])
    undo=run/"voxel-undo.dsculpt"
    base=run/"baseline.dsculpt"
    undo_report=run/"voxel-undo.json"
    exact=undo.is_file() and base.is_file() and sha(undo)==sha(base)
    outcome={"exact_native_bytes":exact}
    if undo_report.is_file():
        observation=json.loads(undo_report.read_text())
        outcome.update({k:v for k,v in observation.items() if k.startswith("voxel_")})
    clean=git(source,"rev-parse","HEAD")==status["candidate"] and not git(source,"status","--porcelain")
    uv_case=run/"uv.json"
    uv_observation=json.loads(uv_case.read_text()) if uv_case.is_file() else {}
    uv={key:value for key,value in uv_observation.items() if key.startswith("uv_atlas_")}
    code=int(not (process.returncode==0 and report["complete"] and exact and pass_count==153 and
                  (not hardware or "files" in witnesses) and clean))
    write(phase="complete",terminal=True,exit=code,loader_exit=process.returncode,
          checks=pass_count,report_complete=report["complete"],error=report.get("error"),
          arc_witnesses=witnesses,voxel=outcome,uv=uv)
except Exception as failure:
    write(terminal=True,exit=1,error=repr(failure))
    raise
raise SystemExit(code)
