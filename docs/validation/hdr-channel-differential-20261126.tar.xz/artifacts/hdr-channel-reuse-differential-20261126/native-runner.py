import os,sys,pathlib,json,time,subprocess,signal,hashlib,fcntl,re
OUT=pathlib.Path(sys.argv[1]).absolute();PLAN=json.loads((OUT/'plan.json').read_text());OUT.mkdir(exist_ok=True)
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def ident(pid):
 try:
  values=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
  return {'pid':pid,'start':int(values[19]),'pgrp':int(values[2]),'state':values[0]}
 except FileNotFoundError:return None
def save(): (OUT/'status.json').write_text(json.dumps(S,indent=2)+'\n')
S={'terminal':False,'exit':None,'started':time.time(),'steps':[],'drift':[],'owned':[],'generated':{},'scope':PLAN['scope']};save()
lease=None if PLAN.get('cpu_only_no_graphics_lease') else os.open('/tmp/dome-sculpt-arc-device.lock',os.O_RDWR);passed=False;active=[]
try:
 if lease is not None:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(lease);S['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino}
 else:S['lease']={'not_acquired':True,'mode':'CPU-only correctness per root authorization; any DRM fd/Mesa driver mapping is refused'}
 for path,digest in PLAN['pins'].items():
  if sha(path)!=digest:S['drift'].append(path)
 assert not S['drift'],'Prospective product/runtime input drift'
 env=dict(os.environ,**PLAN.get('environment',{}))
 for case in PLAN['cases']:
  for path in case.get('consumes_generated',[]):
   assert path in S['generated'] and sha(path)==S['generated'][path]['sha256'],'Generated producer/input mismatch '+path
  name=case['name'];cmd=case['command'];step={'name':name,'command':cmd,'started':time.time(),'timeout_seconds':case.get('timeout',900),'RSS_limit_bytes':case.get('RSS_limit_bytes',4*1024**3),'virtual_AS_cap':None,'signals':[],'peak_owned_RSS_bytes':0,'known_processes':[]};S['steps'].append(step);save()
  fd=None;known={};maps=None;elf_path=None;timed=False;rss_failed=False
  with (OUT/(name+'.log')).open('w') as log:
   p=subprocess.Popen(cmd,env=env,cwd=PLAN['cwd'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   step['pid']=p.pid;root=ident(p.pid);step['root']=root
   if root:known[p.pid]=root
   active.append((p,known,step))
   while p.poll() is None:
    total=0
    for pid,old in list(known.items()):
     cur=ident(pid)
     if not cur or cur['start']!=old['start']:continue
     try:
      if PLAN.get('cpu_only_no_graphics_lease'):
       for handle in pathlib.Path(f'/proc/{pid}/fd').iterdir():
        try:target=os.readlink(handle)
        except FileNotFoundError:continue
        assert not target.startswith('/dev/dri/'),'CPU-only case opened graphics device '+target
       cpu_maps=pathlib.Path(f'/proc/{pid}/maps').read_text()
       assert not any(x in cpu_maps for x in ['_dri.so','libEGL_mesa','libGLX_mesa','libvulkan_lvp']),'CPU-only case mapped a Mesa graphics driver'
       step['cpu_no_graphics_samples']=step.get('cpu_no_graphics_samples',0)+1
      for task in pathlib.Path(f'/proc/{pid}/task').iterdir():
       try:
        for child in (task/'children').read_text().split():
         value=ident(int(child))
         if value and value['pgrp']==p.pid:known[value['pid']]=value
       except FileNotFoundError:pass
      data=pathlib.Path(f'/proc/{pid}/status').read_text();m=re.search(r'^VmRSS:\s+(\d+) kB',data,re.M);total+=int(m[1])*1024 if m else 0
     except FileNotFoundError:pass
    step['peak_owned_RSS_bytes']=max(step['peak_owned_RSS_bytes'],total)
    if fd is None:
     try:
      observed=os.readlink(f'/proc/{p.pid}/exe')
      if observed==str(pathlib.Path(cmd[0]).resolve()):
       fd=os.open(f'/proc/{p.pid}/exe',os.O_RDONLY);elf_path=observed
     except FileNotFoundError:pass
    if fd is not None and maps is None:
     try:
      candidate=pathlib.Path(f'/proc/{p.pid}/maps').read_text()
      if candidate and 'libstdc++.so' in candidate and (not PLAN.get('strict') or ('libasan.so' in candidate and 'libubsan.so' in candidate)):
       maps=candidate;(OUT/(name+'.maps')).write_text(maps)
     except FileNotFoundError:pass
    elapsed=time.time()-step['started']
    if elapsed>step['timeout_seconds'] or total>step['RSS_limit_bytes']:
     timed=elapsed>step['timeout_seconds'];rss_failed=not timed
     reason='deadline' if timed else 'RSS';witness=ident(p.pid)
     if witness and witness['start']==root['start'] and witness['pgrp']==p.pid:
      os.killpg(p.pid,signal.SIGTERM);step['signals'].append({'signal':'SIGTERM','reason':reason,'witness':witness})
     try:p.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
     break
    time.sleep(.01)
   code=p.wait()
  if fd is not None:
   with os.fdopen(fd,'rb') as f:
    h=hashlib.sha256()
    for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
   step['actual_ELF']={'path':elf_path,'sha256':h.hexdigest(),'live_maps':maps is not None,'live_sanitizers':bool(maps and 'libasan.so' in maps and 'libubsan.so' in maps)}
  step.update(exit=code,seconds=time.time()-step['started'],known_processes=list(known.values()))
  step['survivors']=[cur for pid,old in known.items() if (cur:=ident(pid)) and cur['start']==old['start'] and cur['state']!='Z'];S['owned']+=step['survivors'];save()
  assert not step['survivors'],'Owned survivors'
  assert code==case.get('expected_exit',0) and not timed and not rss_failed,name+' result'
  logtext=(OUT/(name+'.log')).read_text()
  if case.get('expected_text'):assert case['expected_text'] in logtext,name+' expected marker'
  if not case.get('loader'):
   assert step.get('actual_ELF',{}).get('sha256')==PLAN['pins'][str(pathlib.Path(cmd[0]))],name+' actual product identity'
   assert maps,name+' actual mapped providers'
   providers={}
   for line in maps.splitlines():
    fields=line.split(maxsplit=5)
    if len(fields)==6 and fields[5].startswith('/'):
     path=fields[5];assert not path.endswith(' (deleted)'),name+' deleted mapped file'
     resolved=str(pathlib.Path(path).resolve());expected=PLAN['pins'].get(resolved,PLAN['pins'].get(path))
     assert expected is not None,name+' unpinned mapped provider '+path
     actual=sha(path);assert actual==expected,name+' changed mapped provider '+path;providers[path]=actual
   step['actual_mapped_providers']=providers
  if PLAN.get('strict') and not case.get('loader'):
   assert step.get('actual_ELF',{}).get('live_sanitizers'),name+' live sanitizer witness'
   assert not any(x in logtext for x in ['ERROR: AddressSanitizer','ERROR: LeakSanitizer','runtime error:']),name+' sanitizer output'
  if case.get('checks'):
   assert re.search(r'PASS\s+'+str(case['checks'])+r'\b',logtext),name+' original check count'
   step['actual_checks']=case['checks'];save()
  for path in case.get('produces',[]):
   assert pathlib.Path(path).is_file(),name+' required actual output '+path
   S['generated'][path]={'producer':name,'sha256':sha(path),'bytes':pathlib.Path(path).stat().st_size}
  save()
 for path,digest in PLAN['pins'].items():
  if sha(path)!=digest:S['drift'].append(path)
 assert not S['drift'],'Post-product drift';passed=True
except BaseException as error:S['error']=repr(error)
finally:
 for proc,known,step in active:
  survivors=[cur for pid,old in known.items() if (cur:=ident(pid)) and cur['start']==old['start'] and cur['state']!='Z']
  if survivors:
   witness=next((cur for cur in survivors if cur['pgrp']==proc.pid),None)
   if witness:
    try:os.killpg(proc.pid,signal.SIGTERM);step['signals'].append({'signal':'SIGTERM','reason':'exception cleanup','witness':witness})
    except ProcessLookupError:pass
   try:proc.wait(timeout=5)
   except subprocess.TimeoutExpired:
    if witness:
     try:os.killpg(proc.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    proc.wait()
 S['owned']=[cur for proc,known,step in active for pid,old in known.items() if (cur:=ident(pid)) and cur['start']==old['start'] and cur['state']!='Z']
 S.update(terminal=True,exit=0 if passed else 1,seconds=time.time()-S['started'])
 if 'lease' in S:S['lease']['released']=time.time()
 if lease is not None:os.close(lease)
 save();print(json.dumps({k:v for k,v in S.items() if k!='steps'}),flush=True)
raise SystemExit(S['exit'])
