from pathlib import Path
import hashlib,json,lzma,tarfile,time,subprocess
R=Path('/home/blux/de-xr/dome-sculpt');A=R/'artifacts';O=A/'hdr-channel-reuse-differential-20261126';W=A/'hdr-release-proof-20261126';D=W/'docs/validation';files=set()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():files.add(p)
def meta(p):
 for f in p.iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.log','.txt','.maps']:add(f)
meta(O)
for f in (O/'compiler-records').glob('*'):add(f)
for f in (O/'compiler-records').glob('*.json'):add(json.loads(f.read_text())['depfile'])
profiles={}
for label in ['release','sanitize']:
 p=O/('native-'+label+'-v1');meta(p);s=json.loads((p/'status.json').read_text());assert s['terminal'] and s['exit']==0 and not s['owned'] and not s['drift'];assert 'PASS 576 channel reuse differential controls' in (p/'differential.log').read_text();profiles[label]={'status':s,'terminal_closure':json.loads((p/'terminal-closure.json').read_text())}
first=A/'source-hdr-channel-reuse-20261126';clean=A/'source-hdr-channel-reuse-standalone-20261126';identity=[]
for name in ['src/color-projection-quality.hpp','tests/color-projection-channel-reuse.cpp','tests/color-projection-reference-725.hpp']:
 a,b=first/name,clean/name;assert sha(a)==sha(b);identity.append({'path':name,'tested_source_sha256':sha(a),'clean_commit_source_sha256':sha(b)});add(a)
add(A/'make-hdr-channel-differential-proof-20261126.py');inventory=[{'path':str(f.relative_to(R)),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(files)];archive=D/'hdr-channel-differential-20261126.tar.xz'
with lzma.open(archive,'wb',preset=6) as out:
 with tarfile.open(fileobj=out,mode='w|') as t:
  for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
r={'scope':'Algorithm-only paired whole-TU Release/strict differential on actual full2048 numerical input and original receipt; unchanged725 support archives. Owning new product core/App qualification is a separate stage, not implied by these checks.','tested_algorithm_fixture_source':'1b954003a516313b44888d211256f9664fe18de8','clean_standalone_commit':'eccddcd4','source_identity':identity,'support_archive_source':'725ea10032981e28c7edb0c1ffdd5689e4a3ad32','actual_controls_each':576,'profiles':profiles,'reference_identity':json.loads((O/'reference-identity.json').read_text()),'actual_native_input':{'path':str(A/'hdr-projection-sharing-sanitize-20261126/native-sanitize-current-v1/current2048/observed-second-bake.dsculpt'),'bytes':122856849,'sha256':'4721e99dc724cfdb71cc26106c646a532bebf53d12a060ec8bc65184fd54a1e4'},'invariants':['all5934012 tested cells and2975612 intersecting cells unchanged','all5808 cancellation callback positions unchanged','all4 channel maxima bit-identical to frozen original725','all original native receipt CBOR bytes unchanged','neighboring G-only field takes general path and invalidates original tight claim','finite random/pair fields, in-cell callback mutation/cancel, exact and one-cell-tight budgets, ill-conditioned/degenerate/outside/nonfinite cases'], 'timing_scope':'Elapsed same-process paired orders in these bounded runs; not isolated hardware benchmark. No newcore performance claim until owning runtime.','archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'authorities':inventory},'observed':time.time()};(D/'hdr-channel-differential-20261126.json').write_text(json.dumps(r,indent=2)+'\n');print('diffproof',len(files),'authorities','bytes',archive.stat().st_size)
