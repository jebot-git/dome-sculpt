cairo/CMakeFiles/fltk_cairo.dir/cairo_dummy.c.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/cairo/cairo_dummy.c \
 /usr/include/stdc-predef.h
