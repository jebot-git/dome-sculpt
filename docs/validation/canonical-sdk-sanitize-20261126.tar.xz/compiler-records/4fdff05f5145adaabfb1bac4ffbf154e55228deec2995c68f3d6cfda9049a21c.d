src/CMakeFiles/fltk-shared.dir/xutf8/keysym2Ucs.c.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/keysym2Ucs.c \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/../Xutf8.h \
 /usr/include/X11/X.h /usr/include/X11/Xlib.h /usr/include/sys/types.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/types/clock_t.h \
 /usr/include/bits/types/clockid_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stddef.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/X11/Xfuncproto.h \
 /usr/include/X11/Xosdefs.h /usr/include/X11/Xlocale.h \
 /usr/include/locale.h /usr/include/bits/locale.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/X11/Xutil.h /usr/include/X11/keysym.h \
 /usr/include/X11/keysymdef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/../FL/Fl_Export.H \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/imKStoUCS.c \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/Xlibint.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/Ximint.h
