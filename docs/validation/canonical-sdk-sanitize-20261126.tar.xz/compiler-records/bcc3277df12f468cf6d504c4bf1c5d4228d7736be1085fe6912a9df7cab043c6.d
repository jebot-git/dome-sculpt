src/CMakeFiles/fltk-shared.dir/xutf8/is_spacing.c.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/is_spacing.c \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/../utf8_internal.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/src/xutf8/headers/spacing.h
