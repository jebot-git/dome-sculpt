src/CMakeFiles/fltk.dir/__/libdecor/src/desktop-settings.c.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/libdecor/src/desktop-settings.c \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/fltk-1.4.5/libdecor/src/desktop-settings.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdbool.h \
 /usr/include/stdlib.h /usr/include/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stddef.h \
 /usr/include/bits/waitflags.h /usr/include/bits/waitstatus.h \
 /usr/include/bits/floatn.h /usr/include/bits/floatn-common.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/sys/types.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/time_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-bsearch.h /usr/include/bits/types/once_flag.h \
 /usr/include/bits/stdlib-float.h /usr/include/string.h \
 /usr/include/strings.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-uintn.h /usr/include/bits/stdint-least.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/build/src/../config.h \
 /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261126/sanitize-deps/build/src/../FL/fl_config.h
