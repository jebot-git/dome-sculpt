from pathlib import Path
import subprocess,time,json,os
O=Path(__file__).resolve().parent
cmd=['/usr/bin/python3','/home/blux/de-xr/DomeD/scripts/prepare-fltk-experiment.py','--deps',str(O/'sanitize-deps'),'--prefix',str(O/'toolkit-sanitize'),'--sanitize','--jobs','2']
s={'terminal':False,'started':time.time(),'command':cmd,'canonical_source':'acc2b70ae61dedec2a23727f67c60c0303d0f76f','scope':'Fresh canonical whole-owned ASan/UBSan FLTK SDK; no product run or system install'}
(O/'sanitize-status.json').write_text(json.dumps(s,indent=2)+'\n')
with (O/'sanitize-build.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
s.update(terminal=True,exit=r.returncode,seconds=time.time()-s['started']);(O/'sanitize-status.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps(s),flush=True)
raise SystemExit(r.returncode)
