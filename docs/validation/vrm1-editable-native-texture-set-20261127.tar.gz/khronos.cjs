const fs = require('fs');
const path = require('path');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
(async () => {
  const reports = [];
  const files = ['accessory-source.vrm','accessory-avatar-baseline.vrm',
                 'native-accessory-editable.vrm','native-accessory-editable-second.vrm'];
  for (const name of files) {
    const input = fs.readFileSync(path.join(__dirname,'release','accessory',name));
    const report = await validator.validateBytes(input,{uri:name,maxIssues:10000});
    reports.push({name,report});
    console.log(name,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings');
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),reports},null,2)+'\n');
  if (reports.some(item=>item.report.issues.numErrors || item.report.issues.numWarnings)) process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1});
