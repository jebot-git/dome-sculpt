import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
destination = repo / "docs" / "validation"
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert revision.startswith("51219fa9")
blobs = {}

def digest(payload):
    return hashlib.sha256(payload).hexdigest()

def file_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def capture(path):
    relative = path.relative_to(work)
    raw = path.read_bytes()
    blobs[str(relative)] = raw
    return raw

def document(path):
    raw = path.read_bytes()
    magic, version, size, text, kind = struct.unpack_from("<5I", raw)
    assert (magic, version, size, kind) == (0x46546C67, 2, len(raw), 0x4E4F534A)
    return json.loads(raw[20:20 + text])

profiles = {}
witnesses = [
    "VRM1 native texture set: 31 checks",
    "The selected accessory enables the shared Editable VRM control",
    "Independent portable images, samplers, FLOAT factors and texture-set membership match Standard VRM",
    "Editable VRM restores the exact FLOAT bake, source graph and excluded-donor state",
    "Reopening and re-exporting Editable VRM reproduces every byte",
    "Editable VRM also refuses a foreign accessory before replacing the destination"
]
for profile in ("release", "asan"):
    directory = work / profile
    native = capture(directory / "accessory.log").decode()
    assert all(witness in native for witness in witnesses)
    command = capture(directory / "compile_commands.json").decode()
    release_flags = "-O3 -DNDEBUG"
    strict_flags = "-fsanitize=address,undefined"
    assert (release_flags if profile == "release" else strict_flags) in command
    profiles[profile] = {
        "native_checks": 31,
        "native_test": file_digest(directory / "dome-sculpt-emission-vrm-test"),
        "core": file_digest(directory / "libdome-sculpt-core.a")
    }
    if profile == "release":
        profiles[profile]["application"] = file_digest(directory / "dome-sculpt")
        profiles[profile]["synthetic_openxr_runtime"] = file_digest(directory / "libdome-sculpt-test-runtime.so")
    for log in ("build.log", "configure.log", "registered.log", "registered.xml"):
        capture(directory / log)
    assert "100% tests passed" in (directory / "registered.log").read_text()
    cases = ET.parse(directory / "registered.xml").getroot().findall(".//testcase")
    assert cases and all(case.find("failure") is None and case.find("skipped") is None for case in cases)
    profiles[profile]["registered_cases"] = [case.attrib["name"] for case in cases]

names = ("native-accessory.dsculpt", "native-accessory.vrm", "native-accessory-editable.vrm",
         "native-accessory-editable-second.vrm")
outputs = {}
for name in names:
    outputs[name] = file_digest(work / "release" / "accessory" / name)
    assert outputs[name] == file_digest(work / "asan" / "accessory" / name)
assert outputs[names[2]] == outputs[names[3]]
expected_vrm = outputs[names[2]]
expected_scene = outputs[names[0]]
current = document(work / "release" / "accessory" / names[2])
assert current["extensions"]["VRMC_vrm"]["specVersion"] == "1.0"
assert current["extras"]["domeSculptAuthoring"]["scope"] == "exportedObjects"

wayland = work / "release-wayland"
result = json.loads(capture(wayland / "report.json"))
assert result["complete"] and len(result["checks"]) == 8 and all(x["passed"] for x in result["checks"])
assert file_digest(wayland / "Avatar.vrm") == expected_vrm
ui = {"wayland-keyboard": {"checks": 8, "output_sha256": expected_vrm}}
pointer = work / "release-wayland-pointer"
result = json.loads(capture(pointer / "report.json"))
assert result["complete"] and len(result["checks"]) == 8 and all(x["passed"] for x in result["checks"])
assert file_digest(pointer / "Avatar.vrm") == expected_vrm
target = json.loads(capture(pointer / "target.json"))
assert target["left"] < target["x"] < target["left"] + target["width"] and target["top"] < target["y"]
ui["wayland-pointer"] = {"checks": 8, "output_sha256": expected_vrm}
for mode, renderer in [("software", "llvmpipe"), ("arc", "Arc(tm) A770"),
                       ("software-cancel", "llvmpipe")]:
    folder = work / ("xr-" + mode)
    render = json.loads(capture(folder / "runtime.json"))
    assert renderer in render["gl_renderer"] and render["acquires"] == render["releases"] == render["image_waits"] > 0
    assert all(render["editable_avatar_images"]["13"][eye] > 1000 for eye in ("0", "1"))
    assert file_digest(folder / "final.dsculpt") == expected_scene
    written = file_digest(folder / "screen-export.vrm")
    assert written == (digest(b"Previous Editable Avatar VRM") if mode.endswith("cancel") else expected_vrm)
    log = capture(work / ("xr-" + mode + ".log"))
    assert b"PASS five native OpenXR accessory export checks" in log
    ui["openxr-" + mode] = {
        "checks": 5, "renderer": render["gl_renderer"], "physical_headset": False,
        "swapchain_releases": render["releases"], "output_sha256": written
    }

khronos = json.loads(capture(work / "khronos.json"))
assert len(khronos["reports"]) == 4 and all(
    item["report"]["issues"]["numErrors"] == item["report"]["issues"]["numWarnings"] == 0
    for item in khronos["reports"]
)
schemas = json.loads(capture(work / "schemas.json"))
checks = [entry for file in schemas["files"] for entry in file["checks"]]
assert len(checks) == 14 and not any(entry["errors"] for entry in checks) and not schemas["schema_drift"]
cold = file_digest(work / "cold-accessory.glb")
assert cold == file_digest(work.parent / "vrm1-native-texture-set-20261127" / "cold-accessory.glb")
for log in ("khronos.cjs", "khronos.log", "schemas.log", "headless.log", "xr-build.log", "ui.py",
            "release-wayland.log", "wayland-accessory.py", "xr-accessory.py",
            "release-wayland-pointer.log", "wayland-pointer.py", "release-wayland-pointer-timeout.log",
            "wayland-pointer-first.py", "release-wayland-pointer-fixed-point-timeout.log",
            "wayland-pointer-fixed-point.py"):
    capture(work / log)
combined = work.parent / "portable-mtoon-bake-20261127" / "combined-release"
combined_status = json.loads((combined / "status.json").read_text())
history = (combined / "ctest.log").read_text()
combined_status["observed_passes"] = len(re.findall(r"\. +Passed +\d", history))
combined_status["observed_reported_failures"] = len(re.findall(r"\*\*\*(?:Failed|Timeout|Exception)", history))
blobs["previous-combined-release-status.json"] = json.dumps(combined_status, indent=2).encode()
capture(Path(__file__).resolve())
archive = destination / f"{work.name}.tar.gz"
with archive.open("wb") as stream, gzip.GzipFile(fileobj=stream, filename="", mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as tar:
        for name, payload in sorted(blobs.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(payload), 0o644
            tar.addfile(member, io.BytesIO(payload))
hashes = {name: digest(payload) for name, payload in blobs.items()}
with tarfile.open(archive) as tar:
    assert {member.name: digest(tar.extractfile(member).read()) for member in tar.getmembers()} == hashes
receipt = {
    "product_revision": revision, "canonical_domed_revision": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repo.parent / "DomeD", text=True).strip(),
    "profiles": profiles, "byte_identical_outputs": outputs, "runtime_paths": ui,
    "interop": {"khronos_files": 4, "khronos_version": khronos["version"], "khronos_errors": 0,
                "khronos_warnings": 0, "pinned_schema_checks": len(checks),
                "cold_glb_sha256": cold, "cold_glb_identical_from_standard_and_editable_vrm": True},
    "earlier_combined_release": combined_status,
    "scope": "VRM 1.0, nested native rigid texture-set accessories with certified native portable materials",
    "archive": {"filename": archive.name, "sha256": file_digest(archive), "members": hashes}
}
(destination / f"{work.name}.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
print("Verified", len(blobs), "evidence files and", len(outputs), "matching fixture outputs")
