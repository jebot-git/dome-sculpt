import json,hashlib,subprocess,os,time,fcntl,shlex,signal,types
from pathlib import Path
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent;S=R/'artifacts/artist-prepared-finite-20261115';HEAD='1740fb9d';MON=R/'artifacts/artist-prepared-strict-monitor-20261115';OLD=R/'artifacts/artist-prepared-sanitize-component-v1-20261115';REL=R/'artifacts/artist-prepared-release-component-v3-20261115';cache={};pins={};lease=None
state={'state':'preparing','pid':os.getpid(),'source':HEAD,'product_source':'1bc13125','scope':'Strict native component only, finite consumer fixture;8GiB aggregate actualownedRSS/900s perstep/no virtualAS cap. Independent sealed current provider archives and fresh currentcompiled/linked owners. Prior143 and resource/harness failures remain. No owningapp/graphics/HMD/install acceptance.','steps':[],'exit':1,'external_signals':[]}
def sha(p):
 p=Path(p);s=p.stat();k=(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 if k not in cache:
  with p.open('rb')as f:cache[k]=hashlib.file_digest(f,'sha256').hexdigest()
 return cache[k]
def save():(P/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def drift():return[f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h]
def external(signum,frame):state['external_signals'].append({'signal':signum,'epoch':time.time(),'sender':'unknown'});save();raise RuntimeError('External driver signal '+str(signum))
signal.signal(signal.SIGTERM,external);signal.signal(signal.SIGINT,external)
module=types.ModuleType('artist_owned_monitor_v2');payload=(MON/'owned_monitor_v2.py').read_bytes();exec(compile(payload,str(MON/'owned_monitor_v2.py'),'exec'),module.__dict__)
controls=json.loads((MON/'controls-v2.json').read_text());assert controls['state']=='terminal'and controls['exit']==0
for f,h in controls['pins'].items():assert sha(f)==h;pins[f]=h
pins[str(MON/'controls-v2.json')]=sha(MON/'controls-v2.json')
env={k:v for k,v in os.environ.items()if not k.startswith(('DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
for k in ['LD_PRELOAD','LSAN_OPTIONS','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET']:env.pop(k,None)
env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',LD_LIBRARY_PATH=str(R/'artifacts/sdk-20261111/toolkit-sanitize/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',LP_NUM_THREADS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',LIBGL_ALWAYS_SOFTWARE='1',EGL_PLATFORM='surfaceless',XR_RUNTIME_JSON=str(P/'no-physical-runtime.json'))
for k,n in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime')]:env[k]=str(P/n);Path(env[k]).mkdir(mode=0o700)
def run(name,cmd,expected=0):
 state['phase']=name;row={'name':name,'command':cmd,'started':time.time()};state['steps'].append(row);save()
 def progress(data):row.update(data);save()
 result=module.run(cmd,cwd=P,env=env,log=P/(name+'.log'),timeout=900,max_rss=8*1024**3,progress=progress);row.update(result);row['log_sha256']=sha(P/(name+'.log'));save();print(name,row.get('exit'),row.get('peak_owned_RSS_bytes'),flush=True);assert row.get('exit')==expected and'error'not in row,(name,row.get('error'),row.get('exit'));return(P/(name+'.log')).read_text()
def fixture(profile):
 d=R/'artifacts'/('artist-prepared-finite-'+profile+'-compile-20261115');j=json.loads((d/'compile-status.json').read_text());assert j['exit']==0 and not j['input_drift'];row=j['steps'][-1];assert row['exit']==0;inputs=json.loads((d/'compile-inputs.json').read_text());deps=shlex.split((d/'0.preprocess.d').read_text().replace('\\\n',' ').split(':',1)[1]);
 for f in deps:
  path=str(Path(f).resolve());assert sha(path)==inputs[path];pins[path]=inputs[path]
 obj=Path(row['command'][row['command'].index('-o')+1]);pins[str(obj)]=sha(obj);return obj
try:
 assert subprocess.check_output(['git','rev-parse','--short=8','HEAD'],cwd=S,text=True).strip()==HEAD and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 for file in ['src/emission-bake-source.cpp','src/bake.cpp','src/bake-authoring.cpp','src/source-bake-normal.hpp']:assert sha(S/file)==sha(R/'artifacts/artist-prepared-source-v3-20261115'/file)
 old=json.loads((OLD/'status.json').read_text());assert old['source']=='1bc13125'and old['phase']=='native-cc0856';oldpins=json.loads((OLD/'inputs-before-runtime.json').read_text());pins.update(oldpins);pins[str(OLD/'status.json')]=sha(OLD/'status.json');pins[str(Path(__file__).resolve())]=sha(__file__);assert not drift()
 root=json.loads((REL/'status.json').read_text());assert root['archives']['fixed']['count']==old['archives']['fixed']['count']==193
 for tag,base,j in [('release',REL,root),('sanitize',OLD,old)]:
  core=j['archives']['fixed'];assert sha(core['path'])==core['sha256'];pins[core['path']]=core['sha256'];obj=fixture(tag);template=next(row['command']for row in j['steps']if row['name']=='link-prepared');cmd=template.copy();oldobj=next(x for x in cmd if x.endswith('.o'));cmd[cmd.index(oldobj)]=str(obj);cmd[cmd.index('-o')+1]=str(P/(tag+'-prepared-test'));cmd=[('-Wl,--dependency-file='+str(P/(tag+'-link.d')))if x.startswith('-Wl,--dependency-file=')else x for x in cmd];run('link-'+tag,cmd);pins[str(P/(tag+'-prepared-test'))]=sha(P/(tag+'-prepared-test'))
 # Linkers/tools only above. Lease precedes every built product, including loader tracing.
 lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);state['graphics_lease']={'path':lease.name,'owner_pid':os.getpid(),'acquired_epoch':time.time(),'before_any_built_product':True};save();(P/'inputs-before-runtime.json').write_text(json.dumps(pins,indent=2)+'\n')
 for tag in ['release','sanitize']:
  text=run('finite-'+tag,[str(P/(tag+'-prepared-test')),str(P/(tag+'-prepared-output'))]);assert'PASS 91 prepared source controls'in text
 for name,args,count in [('missing62',[str(P/'missing-output')],'PASS 62 '),('domain19',[str(P/'domain-native.dsculpt')],'PASS 19 '),('artist139',[str(P/'artist-output')],'PASS 139 '),('role9',['--role-domain-cpu'],'PASS 9 '),('cc0856',['--cpu-only'],'PASS 856 '),('cc0bake32',['--cc0-bake-cpu',str(P/'cc0-bake-output')],'PASS 32 ')]:
  exe=OLD/(('renderCPU'if name in ['role9','cc0856','cc0bake32']else name)+'-test');text=run('strict-'+name,[str(exe),*args]);assert count in text,(name,'wrong native count')
 state['exit']=0
except BaseException as e:state['error']=repr(e)
finally:
 if lease:state['graphics_lease']['released_epoch']=time.time();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 state['input_drift']=drift();state['exit']=state['exit']or int(bool(state['input_drift']));state['state']='terminal';save();print(json.dumps({k:state.get(k)for k in ['state','exit','phase','error','input_drift','external_signals']}),flush=True)
raise SystemExit(state['exit'])
