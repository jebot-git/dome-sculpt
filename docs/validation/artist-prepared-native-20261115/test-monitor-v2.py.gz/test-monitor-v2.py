import sys,json,os,time,hashlib,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P));import owned_monitor_v2 as m
before=m.identity(os.getpid());control=subprocess.Popen(['/usr/bin/sleep','10'],start_new_session=True);control_id=m.identity(control.pid)
try:
 tiny=m.run(['/usr/bin/sleep','10'],cwd=P,env=os.environ.copy(),log=P/'tiny.log',timeout=2,max_rss=1)
 assert tiny['error'].startswith("BudgetExceeded('Owned aggregate RSS")and tiny['exit']in[-15,-9]and tiny['peak_owned_RSS_bytes']>1 and tiny['peak_observed_virtual_bytes']>0 and tiny['signals'];assert m.same(control_id,m.identity(control.pid))and m.same(before,m.identity(os.getpid()))
 normal=m.run(['/usr/bin/sleep','.05'],cwd=P,env=os.environ.copy(),log=P/'normal.log',timeout=2,max_rss=8*1024**3);assert normal['exit']==0 and'error'not in normal and not normal['signals']and normal['peak_observed_virtual_bytes']>0
 deadline=m.run(['/usr/bin/sleep','10'],cwd=P,env=os.environ.copy(),log=P/'deadline.log',timeout=.03,max_rss=8*1024**3);assert deadline['exit']in[-15,-9]and'declared deadline'in deadline['error'];assert m.same(control_id,m.identity(control.pid))and m.same(before,m.identity(os.getpid()))
 result={'state':'terminal','exit':0,'scope':'Actual small owned new-session processes: intentional tinyRSS limit, ordinary completion and timeout; independent control and driver retain exact identity. Only verified own PGIDs signaled. No project-built/native/graphics product.','cases':{'tinyRSS':tiny,'normal':normal,'deadline':deadline},'control_identity':control_id,'driver_identity':before,'pins':{str(P/'owned_monitor_v2.py'):hashlib.sha256((P/'owned_monitor_v2.py').read_bytes()).hexdigest(),str(Path(__file__).resolve()):hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'/usr/bin/sleep':hashlib.sha256(Path('/usr/bin/sleep').read_bytes()).hexdigest()}}
finally:
 if m.same(control_id,m.identity(control.pid)):os.killpg(control.pid,15)
 control.wait(timeout=2)
(P/'controls-v2.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS actual owned RSS/normal/deadline controls; separate driver/control preserved')
