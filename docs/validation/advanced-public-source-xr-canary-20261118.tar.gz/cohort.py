"""Current advanced component and native capsule admission; no whole-build claim."""
import hashlib,json,sys
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
G=R/'artifacts/guard87-validation-admitted-v3-20261115'
prior_paths=list(sys.path);sys.path.insert(0,str(G))
try:
 from runtime_contract import read_runtime,merge_pins
 from build_contract import HEAD
finally:sys.path[:]=prior_paths
S=R/'artifacts/advanced-public-normal-archive-fix-20261117'
B=R/'artifacts/native90-release-planning-20261115/release-090f00-20261117-owning'
SOURCE=FIXTURE_SOURCE='27ff940b55bb43dc545db5e680bd49edd0630a12'
SCENARIO_SOURCE='8bb4072dc1ad60bb7b11b8a325c930f8b2c0c176'
APPLICATION_SOURCE='90fad800bc5aac3dc2421595532f4d2ef8429797'
SOURCE_TUPLE={'product':APPLICATION_SOURCE,'native_fixture':FIXTURE_SOURCE,'runtime_scenarios':SCENARIO_SOURCE,'unchanged_UI_support_context':'090f009ede2c0623ca616fe892223b4f68f1c2c4','font':'6c8f042cb1730fa017595e9a710b8c8c6015a9ea'}
SOURCE_TUPLE={'product':APPLICATION_SOURCE,'native_fixture':SOURCE,'runtime_scenarios':SCENARIO_SOURCE,'unchanged_UI_support_context':'090f009ede2c0623ca616fe892223b4f68f1c2c4','font':'6c8f042cb1730fa017595e9a710b8c8c6015a9ea'}
LINK=R/'artifacts/advanced-public-normal-archive-fix-links-20261117'
LINK_SHA='7c4baa6fce0b2b0266a867028d9ba7a7e91cd8118c848b70c2888984a1252c35'
NATIVE=R/'artifacts/advanced-public-normal-native-20261117/native-v3-20261117/status.json'
NATIVE_SHA='838778ae84e2d6065a3ea5133583f8ecc6fd71ac1f3b3791e00a1f3774909191'
TARGETS={
 'app':{'path':str(R/'artifacts/advanced-public-normal-links-v2-20261117/dome-sculpt'),'sha256':'41a7cf4e63535e64a682b822a602e3058a5d4591297c5d8629e0d6f715ca7d37'},
 'workflow':{'path':str(LINK/'advanced-public-native'),'sha256':'91b475554b5cce7b23a998c9a546ccd71ebf5a976221eec6042479c89c1effd2'},
 'runtime':{'path':str(R/'artifacts/advanced-public-normal-links-v2-20261117/libdome-sculpt-source8-public-runtime.so'),'sha256':'e6c9ea934416eddb2e0e1a595c2d2c7352549404f7b2937a51532c11cba02370'},
 'font':{'path':str(R/'artifacts/artist-prepared-public-link-v3-20261115/font-reference'),'sha256':'1afa272f9288267126fcc3670fb1add2a7830d7e119337582fcedaaca4d4ad21'}}
CASES=[method+'-'+mt+'-'+pose for method in ['raster','retained']for mt in ['mt0','mt1']for pose in ['rest','posed']]
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def verify(pins):return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def add(pins,p,h=None):
 p=str(p);actual=sha(p);assert h is None or actual==h,('Input changed',p);merge_pins(pins,{p:actual})
def admit(profile,native_status,native_sha,workflow,case):
 assert profile=='release'and workflow in ['source-use','uv-create']and case in CASES
 assert native_status==NATIVE and native_sha==NATIVE_SHA
 native=json.loads(native_status.read_text());assert native['state']=='terminal'and native['exit']==0 and not native['input_drift']and not native['remaining_owned']and native['source']==SOURCE and native['scope_tuple']==SOURCE_TUPLE
 assert native['lease']['before_any_ldd_or_built_product']and native['lease']['released_epoch']>=native['lease']['acquired_epoch']
 summary=native['summary'];assert summary=={'native17':17,'source_use_positive':64,'source_use_wrong_Original':16,'uv_creation_positive':64,'uv_creation_wrong_method':16,'source_use_cases':8,'UV_creation_cases':8,'normal_bound_unchanged':.035,'source_use_negative_normal_bound_unchanged':.05,'font_default4_exact':True,'font_families':2,'font_labels_each':22,'App_provider_count':72,'public_actions_executed':False}
 assert len(native['steps'])==171 and len(native['native17_ordered_pairs'])==17
 for row in native['steps']:assert 'error'not in row and not row['signals']and row['exit']==(1 if row['name'].endswith(('-wrong-original','-wrong-method'))else 0)
 pins=dict(read_runtime()['pins']);inputs=native_status.parent/'inputs-final.json';add(pins,native_status,native_sha);add(pins,inputs);merge_pins(pins,json.loads(inputs.read_text()))
 for path,h in native['outputs'].items():add(pins,path,h)
 add(pins,LINK/'status.json',LINK_SHA);linked=json.loads((LINK/'status.json').read_text());assert linked['state']=='terminal'and linked['exit']==0 and not linked['input_drift']and not linked['remaining_owned']and linked['source_tuple']==SOURCE_TUPLE
 for role,key in [('app','app'),('workflow','native'),('runtime','runtime'),('font','font')]:assert linked['products'][key]==TARGETS[role];add(pins,TARGETS[role]['path'],TARGETS[role]['sha256'])
 family=case.split('-',1)[0];root=native_status.parent/('source-use/'+family if workflow=='source-use'else'uv-creation');suite=root/'manifest.json';j=json.loads(suite.read_text());assert case in j['cases']and len(j['cases'])==(4 if workflow=='source-use'else 8)
 assert j['kind']==('advanced-prepared-normal-public-family'if workflow=='source-use'else'advanced-normal-uv-authoring-suite')
 titles=native_status.parent/('titles-'+family+'.json');font=json.loads(titles.read_text());assert font['font_pixels']==16 and len(font['masks'])==26;add(pins,titles);add(pins,font['font_file'])
 provenance=P/'scenario-provenance.json';add(pins,provenance);v=json.loads(provenance.read_text());assert v['source_tuple']==SOURCE_TUPLE and v['scenario_source']==SCENARIO_SOURCE and v['fixture_source']==SOURCE
 for row in v['scenarios'].values():add(pins,row['source'],row['source_sha256']);add(pins,row['copy'],row['copy_sha256']);assert row['source_sha256']==row['copy_sha256']
 auth=v['qualified_monitor_authority'];add(pins,auth['path'],auth['sha256']);prior=json.loads(Path(auth['path']).read_text());assert prior['state']=='terminal'and prior['exit']==0 and not prior['input_drift']
 for path,h in v['unchanged_monitor_inputs'].items():assert prior['pins'][v['monitor_copy_sources'][path]]==h;add(pins,path,h)
 for path,h in v['unchanged_external_monitor_inputs'].items():assert prior['pins'][path]==h;add(pins,path,h)
 add(pins,P/'cohort.py');assert not verify(pins)
 return {'pins':pins,'targets':TARGETS,'scope':'Advanced product90fad component with fixture27ff, runtime/scenarios8bb, unchanged090f UI/support context and font6c8. Native expected capsules are qualified; public actions remain the actual scenario under test.','prepared_source':SOURCE,'source_tuple':SOURCE_TUPLE,'native_admission':{'path':str(native_status),'sha256':native_sha},'component_loader_admission':{'path':str(native_status),'sha256':native_sha,'App_provider_count':72,'version_exit':0},'fixture_root':str(root),'font_reference':str(titles),'GUI_runtime_DSO_used':False}
