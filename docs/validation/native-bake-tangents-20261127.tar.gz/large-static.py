from pathlib import Path
import shlex
import subprocess

work=Path(__file__).resolve().parent
build=work/'release'
commands=subprocess.check_output(['ninja','-C',build,'-t','commands','dome-sculpt-texture-set-source-export-test'],text=True).splitlines()
includes=[flag for flag in shlex.split(next(line for line in commands if line.endswith('/tests/texture-set-source-export.cpp'))) if flag.startswith('-I')]
link=shlex.split(commands[-1])[2:-2]
libs=['-lgcc_s' if flag=='-lgcc_s_asneeded' else str(build/flag) if flag.endswith('.a') else flag for flag in link[link.index('libdome-sculpt-core.a'):]]
with (work/'large-static.log').open('w') as out:
    subprocess.run(['/usr/bin/c++','-std=c++20','-O2',*includes,work/'large-static.cpp','-o',work/'large-static',*libs],stdout=out,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['/usr/bin/time','-f','wall_seconds=%e peak_rss_kib=%M',work/'large-static'],stdout=out,stderr=subprocess.STDOUT,check=True)
