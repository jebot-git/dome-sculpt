#include "dome/gltf-export.hpp"
#include "dome/paint.hpp"
#include "dome/scene.hpp"
#include "dome/source-maps.hpp"
#include "gltf-document.hpp"
#include <iostream>

int main() try {
  constexpr uint32_t divisions = 450;
  constexpr uint32_t side = divisions + 1;
  dome::Mesh mesh;
  mesh.positions.reserve(side * side);
  mesh.normals.assign(side * side, {0,0,1});
  mesh.uv.reserve(side * side);
  mesh.indices.reserve(6 * divisions * divisions);
  for (uint32_t y=0; y<side; ++y) for (uint32_t x=0; x<side; ++x) {
    mesh.positions.push_back({float(x)/divisions,float(y)/divisions,0});
    mesh.uv.push_back({.04f+float(x)*.92f/divisions,.04f+float(y)*.92f/divisions});
    if (x && y) {
      const uint32_t a=(y-1)*side+x-1;
      const uint32_t c=y*side+x;
      for (uint32_t v : {a,a+1,c,a,c,c-1}) mesh.indices.push_back(v);
    }
  }
  dome::Scene scene;
  auto &object = scene.active();
  object.mesh_active = true;
  object.painted = std::make_shared<dome::PaintedMesh>(std::move(mesh),64);
  const auto image=[](uint8_t r,uint8_t g,uint8_t b) {
    dome::Image out{64,64,std::vector<uint8_t>(64*64*4)};
    for (size_t i=0; i<64*64; ++i) {
      out.rgba[i*4]=r; out.rgba[i*4+1]=g; out.rgba[i*4+2]=b; out.rgba[i*4+3]=255;
    }
    return out;
  };
  dome::BakedTextures baked;
  baked.maps.normal=image(109,175,240);
  baked.maps.color=image(56,88,91);
  baked.maps.metal_rough=image(198,122,5);
  baked.maps.emission=image(0,0,0);
  baked.coverage.assign(64*64,255);
  object.painted->install_bake(std::move(baked));
  const auto glb=dome::detail::make_gltf(scene.export_surfaces());
  const auto &primitive=glb.json.at("meshes").at(0).at("primitives").at(0);
  const auto &accessors=glb.json.at("accessors");
  const auto count=accessors.at(primitive.at("attributes").at("TANGENT").get<int>()).at("count");
  if (count!=side*side || accessors.at(primitive.at("indices").get<int>()).at("count")!=6*divisions*divisions)
    throw std::runtime_error("Export changed the large chart's vertex or corner count");
  std::cout << "PASS " << 2*divisions*divisions << " baked triangles and " << count << " explicit tangents\n";
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
