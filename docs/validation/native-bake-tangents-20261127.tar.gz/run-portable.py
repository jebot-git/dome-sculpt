from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
build = work / "release"
mode = sys.argv[1]
args = ["bwrap", "--die-with-parent", "--unshare-all", "--ro-bind", "/", "/",
        "--bind", work, work, "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
        "--tmpfs", "/run/user", "--clearenv"]
env = {
    "PATH": "/usr/bin:/bin", "HOME": "/tmp", "LP_NUM_THREADS": "2",
    "LD_LIBRARY_PATH": "/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
    "EGL_PLATFORM": "surfaceless", "MESA_SHADER_CACHE_DISABLE": "1",
}
if mode == "arc":
    args = ["flock", "--timeout", "180", "/tmp/dome-sculpt-arc-device.lock", *args,
            "--dev-bind", "/dev/dri/renderD129", "/dev/dri/renderD129"]
    env["DRI_PRIME"] = "pci-0000_03_00_0"
else:
    env["LIBGL_ALWAYS_SOFTWARE"] = "1"
for key, value in env.items():
    args.extend(["--setenv", key, value])
placement = sys.argv[2]
command = ["/usr/bin/python3.14", work / "xr-portable-compare.py", mode, placement]
with (work / ("portable-verified-" + placement + "-" + mode + ".log")).open("w") as log:
    subprocess.run([*args, *command], stdout=log, stderr=subprocess.STDOUT, check=True, timeout=240)
