from pathlib import Path
import json
import shlex
import struct
import subprocess

work = Path(__file__).resolve().parent
repo = work.parent.parent
build = work / 'release'
commands = subprocess.check_output(['ninja','-C',build,'-t','commands','dome-sculpt-texture-set-source-export-test'],text=True).splitlines()
compile_line = next(line for line in commands if line.endswith('/tests/texture-set-source-export.cpp'))
includes = [flag for flag in shlex.split(compile_line) if flag.startswith('-I')]
run = shlex.split(commands[-1])[2:-2]
libs = ['-lgcc_s' if flag=='-lgcc_s_asneeded' else str(build/flag) if flag.endswith('.a') else flag
        for flag in run[run.index('libdome-sculpt-core.a'):]]
original = (build/'retopology-imported-pbr/raw-standard.glb').read_bytes()
size = struct.unpack_from('<I',original,12)[0]
root = json.loads(original[20:20+size])
# Exercise the standard material and geometric streams as a generic reader.
# Dome Sculpt ordinarily recognizes this optional native emission payload.
assert root['extras'].pop('domeSculptEmission')
encoded = json.dumps(root,separators=(',',':')).encode()
encoded += b' ' * ((-len(encoded)) % 4)
binary_chunk = original[20+size:]
portable = work/'standard-portable-view.glb'
portable.write_bytes(struct.pack('<5I',0x46546c67,2,20+len(encoded)+len(binary_chunk),len(encoded),0x4e4f534a)
                     +encoded+binary_chunk)
with (work/'reopen-standard.log').open('w') as out:
    subprocess.run(['/usr/bin/c++','-std=c++20','-O2',*includes,work/'reopen-standard.cpp','-o',work/'reopen-standard',*libs],
                   stdout=out,stderr=subprocess.STDOUT,check=True)
    subprocess.run([work/'reopen-standard',portable,work/'raw-portable.dsculpt'],
                   stdout=out,stderr=subprocess.STDOUT,check=True)
