#include "dome/import-authoring.hpp"
#include "dome/material-bindings.hpp"
#include <iostream>

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  const std::filesystem::path glb = argv[1];
  dome::ImportAuthoringOptions options;
  options.paint_resolution = 64;
  auto imported = dome::prepare_authoring_import(dome::Scene{}, glb, options);
  if (imported.objects.size() != 1) throw std::runtime_error("Expected exactly one imported primitive");
  const auto selected=imported.objects.front();
  for (const auto &object : imported.scene.objects())
    if (object.id != selected) imported.scene.object(object.id).visible=false;
  imported.scene.select(selected);
  const auto &mesh=imported.scene.active();
  if (!mesh.material_bindings || !mesh.material_bindings->normal_frames ||
      mesh.material_bindings->normal_frames->pbr->generated_tangents ||
      mesh.material_bindings->normal_frames->pbr->tangents.size()!=mesh.painted->mesh().indices.size())
    throw std::runtime_error("Missing per-corner imported explicit tangent data");
  imported.scene.save(argv[2]);
  std::cout << "PASS Standard GLB import binds explicit tangents and writes a native project\n";
} catch (const std::exception &failure) {
  std::cerr << failure.what() << '\n';
  return 1;
}
