from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile
from xml.etree import ElementTree

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def revision(path):
    return subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()

def read(parent, name):
    return json.loads((parent / name).read_text())

members = ['record.py', 'check-profile.sh', 'check-extended.sh', 'khronos.cjs', 'khronos.json',
           'run-wayland.py', 'wayland-first-material.py', 'bind-wayland.log', 'wayland-first-material/report.json',
           'wayland-first-material/corners.json', 'wayland-first-material/source-viewport.png',
           'run-render.py', 'xr-first-material.py', 'exact-pbr-images.json',
           'large-static.cpp', 'large-static.py', 'large-static.log', 'reopen-standard.cpp',
           'reopen-standard.py', 'reopen-standard.log', 'run-portable.py', 'xr-portable-compare.py']
combined = work.parent / 'retopology-prepared-color-20261127/combined-release'
frozen = read(combined, 'status.json')
assert frozen['terminal'] and frozen['exit'] == 0 and frozen['totals'] == {'pass': 1399, 'fail': 0, 'skip': 0}
assert digest(combined / 'full.xml') == frozen['junit_sha256']
suites = ElementTree.parse(combined / 'full.xml')
assert len(suites.findall('.//testcase')) == 1399 and not suites.findall('.//failure') and not suites.findall('.//skipped')
(work / 'earlier-frozen-status.json').write_text(json.dumps(frozen,indent=2)+'\n')
members.append('earlier-frozen-status.json')

all_tests = {}
geometry_controls = {}
for profile in ('release','asan'):
    filename = f'{profile}-final.log'
    log = (work / filename).read_text()
    names = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', log)
    assert len(names) == len(set(names)) == {'release':58,'asan':11}[profile]
    assert f'0 tests failed out of {len(names)}' in log
    assert {'retopology-imported-pbr','native-mikk-export'} <= set(names)
    all_tests[profile] = names
    members += [filename, f'{profile}-final-build.log']
    native_log = (work / profile / 'Testing/Temporary/LastTest.log').read_text()
    geometry_controls[profile] = {}
    for case, phrase in [('retopology-imported-pbr','imported material retopology'),('native-mikk-export','native Mikk export')]:
        result = re.search(r'^\d+/\d+ Testing: ' + case + r'\n(.*?)^Test Passed\.', native_log, re.M | re.S)
        assert result, case
        assert ('MIKK_EXPORT native_vertices=5 portable_vertices=6 endpoints=2' if case=='native-mikk-export'
                else 'IMPORTED_PBR interior=86') in result[1]
        geometry_controls[profile][case] = int(re.search(r'^PASS (\d+) '+phrase+r' checks$',result[1],re.M)[1])
        log_name = f'{profile}-{case}-controls.log'
        (work / log_name).write_text(result[1]);members.append(log_name)
assert geometry_controls['release'] == geometry_controls['asan']

exact = {}
for directory in ('retopology-imported-pbr','native-mikk-export'):
    for path in sorted((work/'release'/directory).iterdir()):
        if path.suffix not in ('.glb','.dsculpt'): continue
        value = digest(path)
        assert value == digest(work/'asan'/directory/path.name)
        exact[str(path.relative_to(work/'release'))] = value
assert len(exact) == 8

assert (work/'baseline-fixture.log').read_text().find('explicit tangent for every emitted vertex') >= 0
members.append('baseline-fixture.log')
wayland = read(work,'wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks'])==7 and all(row['passed'] for row in wayland['checks'])
validator = read(work,'khronos.json')
assert len(validator['results']) == 7
for row in validator['results']:
    assert row['issues']['numErrors'] == 0
    assert all(item['code']!='MESH_PRIMITIVE_GENERATED_TANGENT_SPACE' for item in row['issues']['messages'])
    row['sha256'] = digest(work/row['file'])
assert 'PASS 405000 baked triangles and 203401 explicit tangents' in (work/'large-static.log').read_text()
assert 'PASS Standard GLB import binds explicit tangents' in (work/'reopen-standard.log').read_text()
records = {}
portable_stereo = {}
for gpu in ('arc','software'):
    name=f'xr-{gpu}-affine/compare.json'
    info=read(work,name)
    assert info['exact_ordered_close'] and len(info['profiles'])==2
    for profile in info['profiles']:
        assert profile['stereo_submissions']==6 and profile['action_syncs']==7
        assert profile['acquires']==profile['image_waits']==profile['releases']==12
    records[gpu] = {'renderer':info['profiles'][0]['gl_renderer'], 'exact_ordered_close':True,
                    'differing_rgb_components_per_eye':info['differing_rgb_components_per_eye']}
    members += [name,f'verified-affine-{gpu}.log']
    portable_name=f'xr-{gpu}-portable/compare.json'
    portable=read(work,portable_name)
    assert portable['exact_ordered_close'] and len(portable['profiles'])==2
    differences=portable['differing_rgb_components_per_eye']
    assert len(differences)==2 and all(row['maximum']<=2 and row['over_three']==0 for row in differences)
    portable_stereo[gpu]=differences
    members += [portable_name,f'portable-verified-portable-{gpu}.log']
archive = validation/(work.name+'.tar.gz')
archived = {}
with tarfile.open(archive,'w:gz',compresslevel=9) as stream:
    for member in members:
        data=(work/member).read_bytes()
        leaf=tarfile.TarInfo(member);leaf.size=len(data)
        stream.addfile(leaf,io.BytesIO(data));archived[member]=sha256(data).hexdigest()

receipt={'product':revision(repo),'canonical_domed':revision(repo.parent/'DomeD'),
         'canonical_compositor_sha256':digest(work.parent/'creator-public-build-20261126/wayland-reference/dome-compositor'),
         'release_binary_sha256':digest(work/'release/dome-sculpt'),
         'sanitizer_fixture_sha256':digest(work/'asan/dome-sculpt-texture-set-source-export-test'),
         'release_tests':all_tests['release'],'strict_asan_ubsan':all_tests['asan'],'geometry_controls':geometry_controls,
         'earlier_frozen_release':frozen,'unchanged_imported_patch_image_sha256':read(work,'exact-pbr-images.json'),'identical_release_and_sanitizer_artifacts_sha256':exact,
         'wayland':wayland,'synthetic_stereo':records,'portable_standard_reimport_stereo':portable_stereo,
         'large_static_chart':{'triangles':405000,'tangents':203401},'physical_headset':False,'khronos':validator,
         'archive_sha256':digest(archive),'archive_members_sha256':archived}
(validation/(work.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
