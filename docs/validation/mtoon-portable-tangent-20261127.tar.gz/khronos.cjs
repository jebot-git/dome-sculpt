const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
const build = path.join(__dirname,'release');
const typed = name => path.join(build,'texture-set-derivative-tangent',name+'.glb');
const retopo = (mode,variant) => path.join(build,'retopology-mtoon-'+mode,'mtoon-'+variant+'.glb');
const names = [];
for (const mode of ['plain','affine','flat','slight','mixed'])
  for (const kind of ['standard','editable']) names.push({file:typed(mode+'-'+kind),explicit:true});
for (const mode of ['reflected','incompatible','rotated','dynamic'])
  names.push({file:typed(mode+'-standard'),explicit:false});
for (const mode of ['plain','affine'])
  for (const kind of ['portable','retopo']) names.push({file:retopo(mode,kind),explicit:true});
(async () => {
  const results = [];
  for (const {file,explicit} of names) {
    const uri = path.relative(build,file);
    const bytes = fs.readFileSync(file);
    const doc = JSON.parse(bytes.toString('utf8',20,20+bytes.readUInt32LE(12)));
    const toon = doc.meshes[0].primitives.filter(p=>doc.materials[p.material].extensions?.VRMC_materials_mtoon);
    const mapped = toon.filter(p=>doc.materials[p.material].normalTexture);
    assert.equal(mapped.length,1,uri);
    assert.equal(mapped[0].attributes.TANGENT !== undefined,explicit,uri);
    const report = await validator.validateBytes(bytes,{uri,maxIssues:10000});
    const warnings = report.issues.messages.filter(m=>m.severity===1).map(m=>m.code);
    assert.equal(report.issues.numErrors,0,uri+' errors '+report.issues.messages.filter(m=>m.severity===0).map(m=>m.code));
    assert.equal(warnings.includes('MESH_PRIMITIVE_GENERATED_TANGENT_SPACE'),!explicit,uri);
    console.log(uri,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings',warnings.join(','));
    results.push({uri,explicit,report});
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results},null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
