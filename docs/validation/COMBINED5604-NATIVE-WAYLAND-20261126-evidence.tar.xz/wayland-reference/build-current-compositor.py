from pathlib import Path
import subprocess,json,hashlib,time,os
P=Path(__file__).resolve().parent;S=Path('/home/blux/de-xr/DomeD');HEAD='acc2b70ae61dedec2a23727f67c60c0303d0f76f'
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 return {n:sha(S/n)for n in subprocess.check_output(['git','ls-files','-z'],cwd=S,text=True).split('\0')if n and(S/n).is_file()}
before=source();(P/'compositor-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
env=dict(os.environ);env.update(DOME_FLTK_PREFIX='/opt/fltk-vr/toolkit',PKG_CONFIG_PATH='/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig',LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',CARGO_TARGET_DIR=str(S/'target'),CARGO_BUILD_JOBS='2')
for k in ['LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']:env.pop(k,None)
cmd=['/usr/bin/nice','-n','10','/usr/bin/cargo','build','--offline','--locked','--release','--features','nested,xr,standalone','--bin','dome-compositor','--jobs','2','--message-format=json-render-diagnostics']
started=time.time()
with(P/'compositor-build.log').open('w')as log:run=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
after=source();out=S/'target/release/dome-compositor';status={'source':HEAD,'command':cmd,'cwd':str(S),'exit':run.returncode,'seconds':time.time()-started,'source_input_count':len(before),'source_drift':[n for n in set(before)|set(after)if before.get(n)!=after.get(n)],'output':str(out),'output_sha256':sha(out)if out.is_file()else None,'scope':'Regular-user optimized canonical compositor build using real Cargo fingerprints/currentsource/private bitmap SDK. Cached dependency artifacts may be reused by Cargo; not a fresh-all-crates claim. No compositor/app/runtime launch or session change.'};(P/'compositor-build-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True);raise SystemExit(run.returncode or int(bool(status['source_drift'])))
