from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import shlex
import subprocess
import sys

work = Path(__file__).resolve().parent
artifacts = work.parent
profile = sys.argv[1]
root = work / profile
root.mkdir(exist_ok=True)
source = work / "source"
shared = artifacts / "native-shared-bake-20261127"
compiled = shared / profile / "build"
entries = json.loads((compiled / "compile_commands.json").read_text())
current = artifacts / "varying-role-mtoon-20261127" / (profile + "-admit")
current_link = shlex.split((current / "app-link.log").read_text().splitlines()[0])
archives = {}
for path in (Path(word) for word in current_link if word.endswith(".a")):
    archives.setdefault(path.name, path)
toolkit = Path("/opt/fltk-vr/toolkit") if profile == "release" else artifacts / "sdk-20261126/toolkit-sanitize"
env = dict(os.environ, LD_LIBRARY_PATH=f"{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
           ASAN_OPTIONS="detect_leaks=1:halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
cpu = sorted(os.sched_getaffinity(0))[2]
targets = ["dome-sculpt-retopo-save-handoff-test", "dome-sculpt-retopo-held-admission-test",
           "dome-sculpt-retopo-worker-faults-test", "dome-sculpt-retopo-affine-test"]

def run(args, log, timeout=240, check=True):
    with (root / (log + ".log")).open("w") as output:
        print(shlex.join(map(str, args)), file=output, flush=True)
        p = subprocess.run(args, stdout=output, stderr=subprocess.STDOUT, cwd=root,
                           env=env, timeout=timeout, check=check)
    return p.returncode

def build(target):
    entry = next(row for row in entries if f"/{target}.dir/" in row["output"])
    obj = root / Path(entry["output"]).name
    args = shlex.split(entry["command"].replace(str(shared / "source"), str(source)))
    args[args.index("-o") + 1] = str(obj)
    run(args, target + "-compile")
    command = subprocess.check_output(["ninja", "-t", "commands", target], cwd=compiled, text=True)
    args = []
    for word in shlex.split(command.splitlines()[-1])[2:-2]:
        if word.startswith("-Wl,--dependency-file="):
            continue
        if word.endswith(".a") and not word.startswith("/"):
            word = str(archives[word])
        elif f"{target}.dir/" in word and word.endswith(".o"):
            word = str(obj)
        args.append(word)
    if target in targets[:2]:
        args.insert(1, "-Wl,--wrap=fsync")
    args[args.index("-o") + 1] = str(root / target)
    run(args, target + "-link")

workers = 2 if profile == "release" else 1
with ThreadPoolExecutor(max_workers=workers) as pool:
    list(pool.map(build, targets))

def handoff(n):
    code = run(["taskset", "-c", str(cpu), root / targets[0], root / f"handoff-{n}"],
               f"handoff-{n}", check=False)
    return n, code, (root / f"handoff-{n}.log").read_text().splitlines()[-1]

with ThreadPoolExecutor(max_workers=4 if profile == "release" else 2) as pool:
    outcomes = list(pool.map(handoff, range(16 if profile == "release" else 4)))
    for item in outcomes:
        print(*item, flush=True)

run([root / targets[1], root / "held"], "held")
run([root / targets[2]], "worker-faults")
run([root / targets[2], "--persistent"], "worker-reporter")
run([root / targets[2], "--acceptance", root / "accepted-publication"], "accepted-publication")
run([root / targets[3], root / "affine"], "affine")
print(Counter(item[1] for item in outcomes), flush=True)
assert all(item[1] == 0 for item in outcomes)
