const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
const build = path.join(__dirname,'release');
const cases = [];
for (const name of ['plain','affine','flat','slight','mixed','rotated','mirror','dual','override'])
  for (const kind of ['standard','editable']) cases.push({name,path:'texture-set-derivative-tangent/'+name+'-'+kind+'.glb',explicit:true});
for (const name of ['reflected','incompatible','rotated-incompatible','dynamic','precision','animated'])
  cases.push({name,path:'texture-set-derivative-tangent/'+name+'-standard.glb',explicit:false});
for (const mode of ['plain','affine'])
  for (const kind of ['portable','retopo']) cases.push({name:'retopo',path:'retopology-mtoon-'+mode+'/mtoon-'+kind+'.glb',explicit:true});
(async () => {
  const results=[];
  for (const {name,path:uri,explicit} of cases) {
    const bytes=fs.readFileSync(path.join(build,uri));
    const doc=JSON.parse(bytes.toString('utf8',20,20+bytes.readUInt32LE(12)));
    const mapped=doc.meshes[0].primitives.filter(p=>{
      const m=doc.materials[p.material];
      return m.extensions?.VRMC_materials_mtoon && m.normalTexture;
    });
    assert.equal(mapped.length,name==='dual'?2:1,uri);
    const postTransform=['rotated','mirror','dual'].includes(name);
    for (const p of mapped) {
      const material=doc.materials[p.material];
      const normal=material.normalTexture;
      assert.equal(p.attributes.TANGENT!==undefined,explicit,uri);
      if(explicit) assert.equal(normal.extensions?.KHR_texture_transform,undefined,uri);
      if(postTransform) {
        assert.equal(normal.texCoord,1,uri);
        assert(p.attributes.TEXCOORD_1!==undefined && p.attributes.TEXCOORD_1!==p.attributes.TEXCOORD_0,uri);
        const shade=material.extensions.VRMC_materials_mtoon.shadeMultiplyTexture;
        assert.equal(shade.texCoord??0,0,uri);
        if(name==='rotated'||name==='dual') assert(shade.extensions.KHR_texture_transform.offset.length===2,uri);
      }
      if(name==='override') assert.equal(normal.texCoord??0,0,uri);
      if(['rotated-incompatible','precision','animated'].includes(name))
        assert(normal.extensions.KHR_texture_transform,uri);
    }
    if(['mirror','override'].includes(name)) assert(!doc.extensionsUsed.includes('KHR_texture_transform'),uri);
    const report=await validator.validateBytes(bytes,{uri,maxIssues:10000});
    const warnings=report.issues.messages.filter(m=>m.severity===1).map(m=>m.code);
    assert.equal(report.issues.numErrors,0,uri+' '+report.issues.messages.filter(m=>m.severity===0).map(m=>m.code));
    assert.equal(warnings.length,explicit?0:1,uri+' '+warnings);
    if(!explicit) assert.deepEqual(warnings,['MESH_PRIMITIVE_GENERATED_TANGENT_SPACE'],uri);
    console.log(uri,'explicit',explicit,'transferred coordinates',postTransform,report.issues.numErrors,'errors',warnings);
    results.push({uri,explicit,postTransform,report});
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results},null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
