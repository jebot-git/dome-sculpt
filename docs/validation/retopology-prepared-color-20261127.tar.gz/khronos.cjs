const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
const names = ['plain','affine'].flatMap(f => ['standard','editable'].map(mode =>
  `retopology-prepared-color-${f}/color-${mode}.glb`));
(async () => {
  const results = [];
  for (const file of names) {
    const report=await validator.validateBytes(fs.readFileSync(path.join(__dirname,'release',file)), {uri:file,maxIssues:10000});
    const issues=report.issues;
    assert.equal(issues.numErrors,0,file);
    results.push({file,report});
    console.log(file,issues.numErrors,'errors',issues.numWarnings,'warnings',issues.messages.filter(e=>e.severity===1).map(e=>e.code));
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results},null,2)+'\n');
})().catch(error=>{console.error(error);process.exitCode=1;});
