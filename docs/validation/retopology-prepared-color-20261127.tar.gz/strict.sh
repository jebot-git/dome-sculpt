#!/usr/bin/bash
set -eu
profile="$1"
run="$2"
out="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$out/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/$profile"
sdk=/opt/fltk-vr/toolkit
if [[ "$profile" == asan ]]; then sdk="$repo/artifacts/sdk-20261126/toolkit-sanitize"; fi
prefix=(bwrap --die-with-parent --unshare-all --ro-bind / / --bind "$out/$profile" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH "$sdk/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64" --setenv ASAN_OPTIONS detect_leaks=1:halt_on_error=1 --setenv UBSAN_OPTIONS halt_on_error=1:print_stacktrace=1 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${prefix[@]}" /usr/bin/python3.14 "$out/relink-sanitizer.py" "$seed" src/paint.cpp src/retopo-authoring.cpp src/texture-set-resample.cpp tests/retopo-surface-heat.cpp > "$out/asan-build.log" 2>&1
for mode in prepared-color-plain prepared-color-affine prepared-affine mtoon-detached reapply-affine; do
  "${prefix[@]}" "$seed/dome-sculpt-retopo-surface-heat-test" "$seed/retopology-$mode" "$mode" > "$out/asan-$mode.log" 2>&1
done
