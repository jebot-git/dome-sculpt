from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parents[1]
destination = repo / 'docs' / 'validation'
stem = work.name

def read(name):
    return (work/name).read_text()

def report(name):
    return json.loads(read(name))

def sha(path):
    with (work/path).open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()

def passed_cases(log, count):
    text = read(log)
    assert f'100% tests passed, 0 tests failed out of {count}' in text
    cases = re.findall(r'Test\s+#\d+: (\S+)\s+\.+\s+Passed', text)
    assert len(cases) == count
    return sorted(cases)

cases = ('native-first','native-rebind','prepared-mirror','retained-mirror')
native = {}
exact = {}
for profile in ('release', 'asan'):
    registered = passed_cases(profile+'-first.log', 9)
    details = report(profile+'-native-evidence.json')
    assert details['checks'] == 56
    native[profile] = {
        'registered_cases': registered,
        'authored_bind_assertions': details['checks'],
        'native_test_sha256': sha(profile+'/dome-sculpt-native-paint-key-frames-test'),
    }
for case in cases:
    for stage in ('before','bound'):
        leaf = f'surface-heat-authored-frames/{case}/{stage}.dsculpt'
        release, asan = (sha(f'{profile}/{leaf}') for profile in ('release','asan'))
        assert release == asan, leaf
        exact[leaf] = release

wayland = report('wayland-bind/report.json')
assert wayland['complete'] and len(wayland['checks']) == 9
assert all(check['passed'] for check in wayland['checks'])
xr = {}
render = {}
files = set()
expected = exact['surface-heat-authored-frames/native-first/bound.dsculpt']
assert sha('wayland-bind/heat-bound.dsculpt') == expected
for mode in ('software', 'arc'):
    x = report(f'xr-bind-{mode}/compare.json')
    assert sha(f'xr-bind-{mode}/bound.dsculpt') == expected and x['same_native_reference']
    assert x['stereo_submissions'] == 77 and x['releases'] == 154
    assert ('llvmpipe' if mode == 'software' else 'Arc(tm) A770') in x['gl_renderer']
    xr[mode] = {
        'renderer':x['gl_renderer'], 'submissions':x['stereo_submissions'],
        'releases':x['releases'], 'project_sha256':expected,
    }
    render[mode] = {}
    for stage, count, marker, line in (
        ('render',151,'actual native36 key export graphical controls','NATIVE36_KEY_EXPORT'),
        ('prepared-mirror',36,'prepared Mirror graphical checks','DERIVED_PBR'),
        ('retained-mirror',36,'retained Mirror graphical checks','DERIVED_PBR'),
    ):
        text = read(f'verified-{stage}-{mode}.log')
        assert f'PASS {count} {marker}' in text
        differences = re.findall(fr'^{line} .*?\bmax=(\d+)',text,re.M)
        assert len(differences) == (12 if stage == 'render' else 9)
        assert max(map(int,differences)) <= 4
        render[mode][stage] = {
            'assertions':count, 'pixel_comparisons':len(differences),
            'max_rgba_byte_error':max(map(int,differences)),
        }
        for f in (work/f'verified-{stage}-{mode}').rglob('*.glb'):
            if f.name != 'cancel.glb':
                files.add((stage,str(f.relative_to(work/f'verified-{stage}-{mode}'))))

driver_reproducible = {}
for stage, filename in sorted(files):
    sw, arc = (sha(f'verified-{stage}-{mode}/{filename}') for mode in ('software','arc'))
    assert sw == arc, filename
    driver_reproducible[f'{stage}/{filename}'] = sw
k = report('khronos.json')
assert len(k['reports']) == len(driver_reproducible) == 32
warnings = Counter()
for row in k['reports']:
    data = row['report']['issues']
    assert data['numErrors'] == 0
    warnings.update(item['code'] for item in data['messages'] if item['severity'] == 1)

logs = [
    'receipt.py', 'measure-native.py', 'check-profile.sh', 'check-mirror.sh', 'run-render.py', 'run-bind.py',
    'wayland-heat.py','xr-bind.py','khronos.cjs','khronos.json','khronos.log',
    'release-first.log','asan-first.log','release-mirror.log',
    'release-native-evidence.json','asan-native-evidence.json',
    'bind-wayland.log','wayland-bind/report.json',
]
for mode in ('software','arc'):
    logs.extend(f'verified-{stage}-{mode}.log' for stage in ('render','prepared-mirror','retained-mirror','bind'))
    logs.extend([f'xr-bind-{mode}/report.json',f'xr-bind-{mode}/compare.json'])
archive = destination/(stem+'.tar.gz')
with archive.open('wb') as output, gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode='w') as bundle:
        for name in sorted(logs):
            info = bundle.gettarinfo(str(work/name),arcname=name)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            info.mode = 0o644
            with (work/name).open('rb') as payload:
                bundle.addfile(info, payload)

summary = {
    'revision':subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip(),
    'canonical_domed_revision':'acc2b70ae61dedec2a23727f67c60c0303d0f76f',
    'release_fltk':'/opt/fltk-vr/toolkit',
    'asan_fltk':'artifacts/sdk-20261126/toolkit-sanitize',
    'release_application_sha256':sha('release/dome-sculpt'),
    'native':native,
    'qualification':{
        'native-first':'Native writable-grid paint with independent frames and a weighted seam shape before first bind',
        'native-rebind':'Cold native paint frame and independently derived key with an existing skin',
        'prepared-mirror':'Prepared intrinsic and baked normal plus the original Mirror source and active pose',
        'retained-mirror':'Independent writable, corner color, retained normal, POSITION, and Mirror sources',
    },
    'sanitizer_environment':{'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
                             'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'},
    'cold_release_and_asan_project_sha256':exact,
    'wayland_bound_project_sha256':expected,
    'nested_domed_wayland_assertions':9,
    'synthetic_openxr':xr,
    'source_mirror_baseline_software_cases':passed_cases('release-mirror.log', 4),
    'surface_and_independent_glb_rendering':render,
    'identical_software_and_arc_exports_sha256':driver_reproducible,
    'khronos':{'version':k['version'],'files':len(k['reports']),'errors':0,'warnings':dict(warnings)},
    'physical_headset_tested':False,
    'archive':{'path':archive.name,
               'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
               'members_sha256':{name:sha(name) for name in sorted(logs)}},
}
(destination/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
