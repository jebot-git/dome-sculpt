const fs = require('fs');
const path = require('path');
const validator = require(path.join(__dirname, '../hdr-khronos-validation-20261126/module/package'));
function collect(dir) {
    return fs.readdirSync(dir, {withFileTypes:true}).flatMap(entry => {
        const name = path.join(dir, entry.name);
        return entry.isDirectory() ? collect(name) : (name.endsWith('.glb') ? [name] : []);
    });
}
(async () => {
    const reports = [];
    for (const fixture of ['render', 'prepared-mirror', 'retained-mirror']) {
        const dir = path.join(__dirname, 'verified-' + fixture + '-software');
        for (const file of collect(dir).sort()) {
            const uri = fixture + '/' + path.relative(dir,file);
            const bytes = fs.readFileSync(file);
            if (path.basename(file) === 'cancel.glb') {
                if (bytes.toString() !== 'existing-output-before-derived-key-export') throw Error('Cancelled export changed its sentinel: ' + uri);
                continue;
            }
            const report = await validator.validateBytes(bytes, {uri});
            reports.push({uri,report});
            console.log(uri, report.issues.numErrors, 'errors', report.issues.numWarnings, 'warnings');
        }
    }
    fs.writeFileSync(path.join(__dirname,'khronos.json'), JSON.stringify({version:validator.version(),reports},null,2)+'\n');
    if (reports.some(item => item.report.issues.numErrors)) process.exitCode = 1;
})().catch(error => {console.error(error);process.exitCode = 1});
