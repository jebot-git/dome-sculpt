from pathlib import Path
import json
import re
import sys

work=Path(__file__).resolve().parent
for profile in sys.argv[1:]:
    complete=(work/profile/'Testing/Temporary/LastTest.log').read_text()
    text=complete.split('Test: surface-heat-authored-frames\n',1)[1].split('Test time =',1)[0]
    controls=re.findall(r'^PASS (.*)$',text,re.M)
    final=controls.pop()
    count=int(final.removeprefix('authored Surface Heat checks='))
    assert count==len(controls)==56
    (work/f'{profile}-native-evidence.json').write_text(json.dumps({
        'checks':count, 'passing_assertions':controls,
        'observed_refusals':re.findall(r'^expected refusal (.*)$',text,re.M)
    },indent=2)+'\n')
