from concurrent.futures import ThreadPoolExecutor
import re
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base.parent / 'retained-target-bake-final-source-20261126'
profile = sys.argv[1]
sanitize = profile == 'asan'
out = base / profile
out.mkdir(mode=0o700, exist_ok=True)
build = out / 'build'
sdk = base.parent / 'sdk-20261126/toolkit-sanitize' if sanitize else Path('/opt/fltk-vr/toolkit')
targets = {
    'dome-sculpt-texture-set-native': 'dome-sculpt-texture-set-native-test',
    'dome-sculpt-texture-set-source-export': 'dome-sculpt-texture-set-source-export-test',
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
    'bake-recipes': 'dome-sculpt-bake-recipes-test',
    'bake-custom-cage': 'dome-sculpt-bake-cage-test',
    'bake-workflow': 'dome-sculpt-bake-workflow-test',
    'bake-controls': 'dome-sculpt-bake-controls-test',
}

start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git', '-C', source, *args], text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

status = {'candidate': git('rev-parse', 'HEAD'), 'profile': profile, 'terminal': False,
          'invocation': os.getenv('INVOCATION_ID'), 'fltk': str(sdk)}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic() - start, 2))
    tmp = out / 'status.tmp'
    tmp.write_text(json.dumps(status, indent=2) + '\n')
    tmp.replace(out / 'status.json')

def run(argv, logname, cwd=None, timeout=1800):
    with (out / logname).open('w') as log:
        print(shlex.join(map(str, argv)), file=log, flush=True)
        subprocess.run(argv, cwd=cwd, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)

try:
    assert status['candidate']==os.environ['DOME_BAKE_CANDIDATE'] and not git('status','--porcelain')
    prior_source='2aaa9b70af2aba8cf3fce2556ff06b3794755b15'
    assert git('diff','--name-only',prior_source,'HEAD')=='src/app.cpp'
    prior=base.parent/'retained-target-bake-qualified-20261126'/profile
    support=base.parent/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
    record(phase='wait for exact dependency closure',prior_source=prior_source)
    while True:
        prior_status=json.loads((prior/'status.json').read_text())
        if prior_status['terminal']:break
        subprocess.run(['systemctl','--user','is-active','--quiet',f'ds-retained-target-qualified-{profile}-v3-20261126.service'],check=True)
        time.sleep(1)
    assert prior_status['candidate']==prior_source
    core=prior/'libdome-sculpt-core.a'
    renderer=prior/'libdome-sculpt-render.a'
    xr=prior/'libdome-sculpt-xr.a'
    for path,label in [(core,'core'),(renderer,'render'),(xr,'xr')]:
        assert sha(path)==prior_status[label+'_sha256']
    assert prior_status['phase']=='link the full FLTK and OpenXR application to the exact updated core'
    assert 'app.cpp' in (prior/'app.cpp.o.log').read_text()
    record(phase='configure and run registered native tests',core_sha256=sha(core),render_sha256=sha(renderer),xr_sha256=sha(xr))
    options=[]
    if sanitize:
        options.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        options.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    run(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',
         *options],'configure.log',timeout=120)
    for target in targets.values():
        assert (prior/'build'/target).is_file()
        (build/target).symlink_to(prior/'build'/target)
    for name in ('texture-set-source-export.cpp.o.log','dome-sculpt-texture-set-source-export-link.log'):
        (out/name).symlink_to(prior/name)
    record(binaries={name:sha(build/target) for name,target in targets.items()})
    native = ['bwrap', '--die-with-parent', '--unshare-all', '--ro-bind', '/', '/',
              '--bind', build, build, '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp',
              '--tmpfs', '/run/user', '--clearenv', '--setenv', 'PATH', '/usr/bin:/bin',
              '--setenv', 'HOME', '/tmp', '--setenv', 'LD_LIBRARY_PATH',
              f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
    if sanitize:
        native.extend(['--setenv', 'ASAN_OPTIONS', 'detect_leaks=1:halt_on_error=1',
                       '--setenv', 'UBSAN_OPTIONS', 'halt_on_error=1:print_stacktrace=1'])
    run([*native,'ctest','--test-dir',build,'-R','^('+'|'.join([*targets,'texture-set-active-bake','texture-set-retained-bake-source','texture-set-prepared-recipe-references','texture-set-retained-bake-target'])+')$','--output-on-failure','-V'],
        'ctest.log', timeout=1400)
    log = (out/'ctest.log').read_text()
    expected = 11
    assert f'100% tests passed, 0 tests failed out of {expected}' in log and re.search(r'PASS \d+ retained target Bake controls', log)
    assert git('rev-parse', 'HEAD') == status['candidate'] and not git('status', '--porcelain')
    record(phase='rebuild desktop and application translation units against the sealed core',ctest_sha256=sha(out/'ctest.log'))
    database=json.loads((build/'compile_commands.json').read_text())
    def frontend_owner(owner):
        row=next(r for r in database if r['file']==str(source/owner)
                 and 'CMakeFiles/dome-sculpt.dir/' in r['command'])
        command=shlex.split(row['command'])
        obj=out/(Path(owner).name+'.o')
        i=command.index('-o')+1
        old=command[i]
        command[i]=obj
        run(command,obj.name+'.log',build,timeout=900)
        return old,obj
    with ThreadPoolExecutor(max_workers=5 if not sanitize else 4) as pool:
        objects=dict(pool.map(frontend_owner,prior_status['frontend']))
    app=build/'dome-sculpt'
    link=shlex.split(subprocess.check_output(['ninja','-C',support,'-t','commands','dome-sculpt'],text=True).splitlines()[-1])[2:-2]
    link=[objects.get(word,word) for word in link if not word.startswith('-Wl,--dependency-file=')]
    for path in (core,renderer,xr):
        link[link.index(path.name)]=path
    link[link.index('-o')+1]=app
    run(link,'dome-sculpt-link.log',support)
    record(app_sha256=sha(app),frontend_sha256={p.name:sha(p) for p in objects.values()})
    record(phase='complete', terminal=True, exit=0, ctest_sha256=sha(out/'ctest.log'))
except Exception as error:
    record(terminal=True, exit=1, error=repr(error))
    raise
