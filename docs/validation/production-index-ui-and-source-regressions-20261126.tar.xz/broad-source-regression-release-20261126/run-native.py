from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

here=Path(__file__).resolve().parent
build=json.loads((here/'build-status.json').read_text())
plan=json.loads((here/'build-plan.json').read_text())
assert build['terminal'] and build['exit']==0
assert not Path('/dev/dri').exists()
assert not os.environ.get('XR_RUNTIME_JSON') and not os.environ.get('WAYLAND_DISPLAY')
outputs=here/'runtime'
outputs.mkdir()
baseline=here.parent/'serialize-sculpt-objects-release-20261126'
input=baseline/'source-joint-writable-normal-bake-checked/000.dsculpt'
assert input.exists()
def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()
state={'diff_sha256':plan['diff_sha256'],'terminal':False,'archive_sha256':build['linked_archive']['sha256'],
       'fixture_sha256':digest(input),'cases':{}}
def save():
    p=outputs/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(outputs/'status.json')
tests=[
    ('corner-color-uv23-domain','corner-color-uv23-domain-test',[]),
    ('baked-emission-uv1-worker','baked-emission-workflow-test',['--source-worker-controls',str(outputs/'uv1')]),
    ('baked-emission-raw-worker','baked-emission-workflow-test',['--raw-source-worker-controls',str(outputs/'raw')]),
    ('baked-emission-workflow','baked-emission-workflow-test',[str(outputs/'workflow')]),
    ('scene-file','scene-file-test',[str(outputs/'scene-file')]),
    ('source-owning-hdr-domain','source-owning-hdr-domain-test',[str(input),str(outputs/'hdr-domain')]),
]
save()
try:
    for name,target,args in tests:
        elf=here/f'dome-sculpt-{target}'
        cmd=[str(elf),*args]
        start=time.monotonic()
        with (outputs/(name+'.log')).open('w') as f:
            result=subprocess.run(cmd,cwd=outputs,env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT,timeout=900)
        state['cases'][name]={'exit':result.returncode,'seconds':time.monotonic()-start,
            'executable_sha256':digest(elf),'command':cmd}
        save()
        print(name,result.returncode,flush=True)
    state['exit']=int(any(x['exit']!=0 for x in state['cases'].values()))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
