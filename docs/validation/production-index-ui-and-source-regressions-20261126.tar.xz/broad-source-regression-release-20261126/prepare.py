from pathlib import Path
import hashlib
import json
import shlex
import subprocess

here=Path(__file__).resolve().parent
source=here.parent/'broad-source-regression-source-20261126'
parent=here.parent/'serialize-sculpt-objects-source-20261126'
original=here.parent/'serialize-sculpt-objects-release-20261126'
integrated=here.parent/'production-sculpt-index-integration-release-20261126'
archive=integrated/'libdome-sculpt-core.a'
assert json.loads((integrated/'build-plan.json').read_text())['source'].startswith('ec578e56')
integrated_build=json.loads((integrated/'build-status.json').read_text())
assert integrated_build['terminal'] and integrated_build['exit']==0
targets={
    'dome-sculpt-corner-color-uv23-domain-test':'tests/corner-color-uv23-domain.cpp',
    'dome-sculpt-baked-emission-workflow-test':'tests/baked-emission-workflow.cpp',
    'dome-sculpt-scene-file-test':'tests/scene-file.cpp',
    'dome-sculpt-source-owning-hdr-domain-test':'tests/source-owning-hdr-domain.cpp',
}
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
assert git('rev-parse','--short','HEAD')=='ec578e56'
assert set(git('diff','--name-only','HEAD').splitlines())=={'src/paint.cpp','tests/baked-emission-workflow.cpp'}
commands={x['file']:x for x in json.loads((original/'compile_commands.json').read_text())}
owners={}
compiles=[]
for rel in ['src/paint.cpp',*targets.values()]:
    argv=shlex.split(commands[str(parent/rel)]['command'].replace(str(parent),str(source)))
    obj=here/rel.split('/')[0]/(Path(rel).name+'.o')
    obj.parent.mkdir(exist_ok=True)
    argv[argv.index('-o')+1]=str(obj)
    argv[1:1]=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
    owners[rel]=str(obj)
    compiles.append({'name':rel.replace('/','-'),'argv':argv})
links=[]
for target,rel in targets.items():
    _,line,_=subprocess.check_output(['ninja','-t','commands',target],cwd=original,text=True).splitlines()[-1].split(' && ')
    argv=[]
    for value in shlex.split(line):
        if value.startswith('-Wl,--dependency-file='):
            value=f'-Wl,--dependency-file={here}/{target}.link.d'
        elif value==target:
            value=str(here/target)
        elif value=='libdome-sculpt-core.a':
            value=str(here/value)
        elif value.endswith('/'+rel+'.o'):
            value=owners[rel]
        argv.append(value)
    assert owners[rel] in argv
    links.append({'name':target,'argv':argv})
plan={'base':'ec578e56','dirty_paths':git('diff','--name-only','HEAD').splitlines(),
      'diff_sha256':hashlib.sha256(git('diff','--binary','HEAD').encode()).hexdigest(),
      'baseline_archive':str(archive),'baseline_archive_sha256':integrated_build['linked_archive']['sha256'],
      'cwd':str(original),'compiler':compiles,'links':links,'replacement_objects':[owners['src/paint.cpp']]}
(here/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(plan['diff_sha256'],len(compiles),len(links))
