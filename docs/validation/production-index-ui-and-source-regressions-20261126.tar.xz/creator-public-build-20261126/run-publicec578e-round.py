from pathlib import Path
import json
import subprocess

here=Path(__file__).resolve().parent
out=here/'publicec578e-round-v1'
out.mkdir()
runs={}
def write(terminal):
    p=out/'status.tmp'
    p.write_text(json.dumps({'terminal':terminal,'cases':runs},indent=2)+'\n')
    p.replace(out/'status.json')
write(False)
for mode,count in [('accept',19),('cancel',19),('focus',20)]:
    with (out/(mode+'.log')).open('w') as log:
        r=subprocess.run(['/usr/bin/python3.14',str(here/'run-publicec578e-v1.py'),mode],
                         stdout=log,stderr=subprocess.STDOUT)
    review=here/f'publicec578e-{mode}-v1/status.json'
    d=json.loads(review.read_text()) if review.exists() else {}
    passed=(r.returncode==0 and d.get('terminal') and d.get('actual_checks')==count and
            not d.get('input_drift') and not d.get('owned_remaining') and
            d.get('lease',{}).get('released') is not None)
    runs[mode]={'wrapper_exit':r.returncode,'expected':count,'passed':bool(passed),
                'status':str(review),'actual_checks':d.get('actual_checks'),'error':d.get('error')}
    write(False)
    print(mode,passed,flush=True)
write(True)
raise SystemExit(int(not all(row['passed'] for row in runs.values())))
