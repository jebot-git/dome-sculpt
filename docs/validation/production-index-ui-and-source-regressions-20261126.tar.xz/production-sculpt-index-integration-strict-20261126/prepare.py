from pathlib import Path
import hashlib
import json
import re
import shlex
import subprocess

here=Path(__file__).resolve().parent
original=here.parent/'serialize-sculpt-objects-strict-20261126'
parent=here.parent/'serialize-sculpt-objects-source-20261126'
source=here.parent/'production-sculpt-index-integration-source-20261126'
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
assert git('rev-parse','HEAD')=='ec578e561c99ec681e9db57f657c0823526b0151'
assert not git('status','--porcelain')
expected_core={'src/sculpt-chunk-masks.cpp','src/sculpt-placed-chunks.cpp','src/sculpt-surface-chunks.cpp'}
by_dep=set()
for depfile in (original/'CMakeFiles').glob('**/*.o.d'):
    if '/sculpt-chunk-index.hpp' in depfile.read_text():
        assert 'dome-sculpt-core.dir' in depfile.parts
        by_dep.add('src/'+depfile.name.removesuffix('.o.d'))
assert by_dep==expected_core
archive=original/'libdome-sculpt-core.a'
with archive.open('rb') as f:
    archive_sha=hashlib.file_digest(f,'sha256').hexdigest()
baseline=json.loads((original/'status.json').read_text())
assert baseline['source']=='07025cd3995626bd32a9d0a848a2564965583ada'
assert baseline['build']['exit']==baseline['native']['exit']==0
assert baseline['terminal'] and baseline['sculpt_default']['error'].startswith('BudgetExceeded')
assert not subprocess.check_output(['git','-C',str(parent),'status','--porcelain'],text=True).strip()
assert subprocess.check_output(['git','-C',str(parent),'rev-parse','HEAD'],text=True).strip()==baseline['source']
commands=json.loads((original/'compile_commands.json').read_text())
items={x['file']:x for x in commands}
targets={
    'dome-sculpt-scene-file-test':'tests/scene-file.cpp',
    'dome-sculpt-document-recovery-test':'tests/document-recovery.cpp',
    'dome-sculpt-atomic-write-allocation-test':'tests/atomic-write-allocation.cpp',
    'dome-sculpt-sculpt-surface-chunks-test':'tests/sculpt-surface-chunks.cpp',
    'dome-sculpt-sculpt-chunk-pipeline-test':'tests/sculpt-chunk-pipeline.cpp',
    'dome-sculpt-sculpt-independent-workflow':'tests/sculpt-independent-workflow.cpp',
}
compiles=[]
objs={}
for rel in sorted(expected_core) + [r for r in targets.values() if r]:
    spec=items[str(parent/rel)]
    argv=shlex.split(spec['command'].replace(str(parent),str(source)))
    obj=here/rel.split('/')[0]/(Path(rel).name+'.o')
    obj.parent.mkdir(exist_ok=True)
    argv[argv.index('-o')+1]=str(obj)
    argv[1:1]=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
    assert '-O1' in argv and '-g1' in argv and '-fsanitize=address,undefined' in argv
    compiles.append({'name':rel.replace('/','-'),'argv':argv})
    objs[rel]=str(obj)
links=[]
for target, rel in targets.items():
    lines=subprocess.check_output(['ninja','-t','commands',target],cwd=original,text=True).splitlines()
    _,link,_=lines[-1].split(' && ')
    argv=[]
    for item in shlex.split(link):
        if item.startswith('-Wl,--dependency-file='):
            item=f'-Wl,--dependency-file={here}/{target}.link.d'
        elif item==target:
            item=str(here/target)
        elif item=='libdome-sculpt-core.a':
            item=str(here/item)
        elif rel and item.endswith('/'+rel+'.o'):
            item=objs[rel]
        argv.append(item)
    if rel:
        assert objs[rel] in argv
    links.append({'name':target,'argv':argv})
plan={'source':git('rev-parse','HEAD'),'core_baseline_sha256':archive_sha,'core_baseline_source':'07025cd3',
      'cwd':str(original),'compiler':compiles,'links':links,'receipt_md_inputs':sorted(by_dep),
      'replacement_objects':[objs[x] for x in sorted(expected_core)]}
(here/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(plan['source'],len(compiles),len(links),archive_sha)
