from pathlib import Path
import cbor2
import hashlib
import json
import re
import subprocess
import tarfile

root=Path(__file__).resolve().parent
art=root.parent
repo=art.parent
name='native-writable-recipient-20261126'
dest=repo/'docs/validation'
archive=dest/(name+'.tar.gz')
candidate=subprocess.check_output(['git','-C',repo,'rev-parse','c6b80cce'],text=True).strip()
def sha(p):
    with Path(p).open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
patch=root/'source.patch'
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',candidate])==patch.read_bytes()
members={}
def include(prefix,*files):
    for path in files:
        assert path.is_file(),path
        key=prefix+'/'+path.name
        assert key not in members,key
        members[key]=path
def state(p):
    return json.loads((p/'status.json').read_text())

old_cases={}
for version,log,diagnostic in (
        ('', 'bake-editor.cpp.log','invalid use of incomplete type'),
        ('-v2','ctest.log','Retained paint with raw normal data requires independent prepared-normal authority'),
        ('-v3','ctest.log','Native paint metadata changed its immutable basis/attachment interpretation')):
    suffix=version or '-v1'
    folder=art/('native-writable-recipient'+version+'-20261126')/'release'
    data=state(folder)
    assert data['terminal'] and data['exit'] and diagnostic in (folder/log).read_text()
    old_cases[suffix]=data
    include('earlier/'+suffix,folder/'status.json',folder/log)
for mode in ('software','arc'):
    folder=root/(mode+'-recipient')
    assert state(folder)['exit']==1
    include('earlier/xr-'+mode,folder/'status.json',folder/'run.log',folder/'workflow/report.json')
    assert sha(folder/'workflow/accept.dsculpt')==sha(root/'expected.dsculpt')
    rejected=folder/'workflow/cancel.dsculpt'
    assert sha(rejected)!=sha(root/'before.dsculpt')
    graph=cbor2.loads(rejected.read_bytes())
    graph=graph.get('payload',graph)
    target=next(o for o in graph['objects'] if o['id']==graph['active'])
    assert 'baked' in target['painted'].get('payload',target['painted'])
    assert not target['bake_recipe']['settings'].get('corresponding_topology',False)

native={}
for profile in ('release','asan'):
    folder=root/profile
    data=state(folder)
    assert data['terminal'] and data['exit']==0 and data['patch_sha256']==sha(patch)
    assert 'PASS 60 native writable recipient checks' in (folder/'ctest.log').read_text()
    assert sha(folder/'build/dome-sculpt')==data['app_sha256']
    full=root/(profile+'-regression')
    data['regressions']=state(full)
    assert data['regressions']['exit']==0 and not data['regressions']['failed'] and len(data['regressions']['tests'])==11
    assert data['regressions']['patch_sha256']==sha(patch)
    data['recipient_assertions']=60
    native[profile]=data
    include(profile,folder/'status.json',folder/'configure.log',folder/'archive.log',folder/'app-link.log',
            folder/'ctest.log',folder/'build/regressions.xml')
    for path in folder.glob('*.cpp*.log'):include(profile+'/compilation',path)
    include(profile+'/regressions',full/'status.json',full/'configure.log',full/'ctest.log',full/'build/regressions.xml',*sorted(full.glob('*-link.log')))
projects={}
baseline=root/'release/build/native-writable-bake-recipient'
asan=root/'asan/build/native-writable-bake-recipient'
for path in sorted(baseline.iterdir()):
    projects[path.name]=sha(path)
    assert projects[path.name]==sha(asan/path.name)
assert len(projects)==12
graphics={}
for mode in ('llvmpipe','arc'):
    folder=root/('graphics-'+mode)
    text=(folder/'run.log').read_text()
    assert ('GPU llvmpipe' if mode=='llvmpipe' else 'Arc(tm) A770') in text
    assert 'PASS 13 native writable Bake graphical checks' in text
    native_delta=[int(n) for n in re.findall(r'NATIVE_BAKE_IMAGE .*? delta=(\d+)',text)]
    glb_delta=[int(n) for n in re.findall(r'GLB_IMAGE .*? delta=(\d+)',text)]
    wrong=re.search(r'WRONG_TANGENT delta=(\d+)',text)
    assert native_delta==[0,0] and glb_delta==[1,1] and wrong and int(wrong[1])>5
    graphics[mode]={'native_max_rgb_delta':max(native_delta),'glb_max_rgb_delta':max(glb_delta),
                    'wrong_tangent_max_rgb_delta':int(wrong[1]),'checks':13,'fixture_sha256':sha(folder/'graphics')}
    include('graphics/'+mode,folder/'compile.log',folder/'link.log',folder/'run.log',*sorted((folder/'images').glob('*.png')))
outputs={}
for mode,profile,checks in (('software-focus','release',11),('arc-focus','asan',11),('wayland','release',10)):
    folder=root/(mode+'-recipient')
    data=state(folder)
    assert data['terminal'] and data['exit']==0 and data['checks']==checks
    assert data['app_sha256']==native[profile]['app_sha256'] and data['input_sha256']==sha(root/'before.dsculpt')
    assert data['native_sha256']==sha(root/'expected.dsculpt')
    outputs[mode]=data
    include('frontend/'+mode,folder/'status.json',folder/'run.log',folder/'workflow/report.json')
    if mode=='wayland':
        include('frontend/'+mode,*(folder/'workflow'/n for n in ('client.log','compositor.log','runtime-maps.txt')))
    else:
        include('frontend/'+mode,*(folder/'workflow'/f'{op}.{ext}' for op in ('accept','cancel') for ext in ('log','json')))
khronos=json.loads((root/'khronos.json').read_text())
warnings={}
for file,report in khronos.items():
    assert file in projects and report['issues']['numErrors']==0
    warning=[entry['code'] for entry in report['issues']['messages'] if entry['severity']==1]
    assert warning==['NODE_SKINNED_MESH_NON_ROOT']
    warnings[file]=warning
include('format',root/'khronos.json',root/'validate.cjs')
include('fixtures',root/'before.dsculpt',root/'expected.dsculpt')
include('drivers',patch,*(root/n for n in ('run.py','regressions.py','public.py','public-focus.py','xr.py',
        'xr-focus.py','wayland.py','prepare-public.py','public-fixture.cpp','graphics.cpp','graphics.py','record.py')))
with tarfile.open(archive,'w:gz',compresslevel=9) as pack:
    for key,path in sorted(members.items()):
        pack.add(path,arcname=key)
report={
    'candidate':candidate,
    'scope':'Plain native writable-UV Bake target, editable UV continuation, Bake source, viewport tangent publication and standard and editable GLB. Product delta matches the archived patch.',
    'source_patch_sha256':sha(patch),
    'earlier_failures':old_cases,
    'native':native,
    'matching_native_and_glb_projects':projects,
    'graphics':graphics,
    'public_frontends':outputs,
    'format_warnings':warnings,
    'format_errors':0,
    'archive':{'file':archive.name,'sha256':sha(archive),'members':{key:sha(path) for key,path in sorted(members.items())}},
}
(dest/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(archive) as pack:
    assert {m.name:hashlib.sha256(pack.extractfile(m).read()).hexdigest() for m in pack.getmembers()}==report['archive']['members']
print(candidate,len(projects),list(graphics),list(outputs),len(members))
