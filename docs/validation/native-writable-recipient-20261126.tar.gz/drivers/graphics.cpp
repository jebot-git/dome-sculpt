#define DOME_NATIVE_KEY_EXPORT_NO_MAIN
#include "native-paint-key-export-render.cpp"
#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/tangents.hpp"

int main(int argc,char **argv) try {
  if(argc!=4)return 2;
  const auto input=std::filesystem::path(argv[1]);
  const auto output=std::filesystem::path(argv[2]);
  std::filesystem::create_directories(output);
  auto scene=Scene::load(input/"ldr-accepted.dsculpt");
  auto control=Scene::load(input/"ldr-before.dsculpt");
  auto &root=control.active();
  root.painted=root.material_bindings->native_paint_sampling->before_paint()->snapshot();
  root.material_bindings.reset();
  const auto recipe=scene.active().bake_recipe;
  bake_object(control,recipe->source.object,recipe->settings);
  const auto original_normals=tangent_corners(control.active().painted->mesh());
  const auto display_normals=tangent_corners(scene.active().painted->mesh());
  check(original_normals!=display_normals,"Wrong display tangent direction is distinct from the retained paint frame");

  NativeGraphics graphics;
  const std::string renderer_name=reinterpret_cast<const char *>(glGetString(GL_RENDERER));
  std::cout<<"GPU "<<renderer_name<<std::endl;
  check(renderer_name.find(argv[3])!=std::string::npos,"Requested actual renderer is active");
  Fbo fbo;
  SurfaceRenderer native;
  prepared_normal_consumer::Renderer consumer;
  for(bool posed:{false,true}){
    auto before=control,after=scene;
    if(posed){
      auto deformation=*before.active().deformation;
      deformation.pose.resize(2);
      deformation.pose[0].scale={1.1f,.84f,1.3f};
      deformation.pose[1].scale={.83f,1.14f,1.22f};
      before.set_deformation(1,deformation);
      after.set_deformation(1,deformation);
    }
    Document b,a;
    b.replace(before);a.replace(after);
    b.shading(false);a.shading(false);
    finish(b);finish(a);
    fbo.bind();
    const auto want=draw(native,b.frame().surface);
    const auto got=draw(native,a.frame().surface);
    std::set<std::array<uint8_t,4>> colors;
    size_t visible=0;
    for(size_t p=0;p<got.size();p+=4)if(got[p+3]){
      ++visible;colors.insert({got[p],got[p+1],got[p+2],got[p+3]});
    }
    check(visible>500&&colors.size()>8,"Lit Bake has substantial visible nonuniform pixels");
    const auto error=delta(want,got);
    std::cout<<"NATIVE_BAKE_IMAGE posed="<<posed<<" visible="<<visible<<" delta="<<error<<std::endl;
    capture(output/(posed?"pose.png":"rest.png"),got);
    check(error<=2,"UV edits retain the same native baked color and normal appearance");
    if(!posed){
      auto wrong=std::make_shared<MeshSnapshot>(*a.frame().surface);
      wrong->geometry_identity.reset();
      for(size_t c=0;c<wrong->mesh.indices.size();++c)
        wrong->tangents[wrong->mesh.indices[c]]=display_normals[c];
      const auto incorrect=draw(native,wrong);
      std::cout<<"WRONG_TANGENT delta="<<delta(got,incorrect)<<std::endl;
      check(delta(got,incorrect)>5,"The framebuffer distinguishes the wrong display tangent basis");
      for(const auto *name:{"ldr.glb","ldr-editable.glb"}){
        prepared_normal_consumer::Model model(input/name);
        fbo.bind();consumer.render(model.data,nullptr);
        const auto emitted=read();
        std::cout<<"GLB_IMAGE "<<name<<" delta="<<delta(got,emitted)<<std::endl;
        capture(output/(std::string(name)+".png"),emitted);
        check(delta(got,emitted)<=4,"Independent GLB consumer reproduces the retained paint normal and color");
      }
    }
  }
  std::cout<<"PASS "<<checks<<" native writable Bake graphical checks\n";
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
