from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

home=Path(__file__).resolve().parent
art=home.parent
src=home/'source'
profile=sys.argv[1]
asan=profile=='asan'
out=home/profile
out.mkdir(exist_ok=True)
build=out/'build'
old=art/'canonical-writable-recipient-20261126'/(profile+'-current')
prior=art/'writable-donor-current-validation-v2-20261126'/profile
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=art/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
env={**os.environ,'PKG_CONFIG_PATH':'/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig'}
start=time.monotonic()
candidate=subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
state={'candidate':candidate,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def status(**updates):
    state.update(updates,elapsed=round(time.monotonic()-start,2))
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')
def sha(file):
    with Path(file).open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              env=env,timeout=timeout,check=check).returncode
def first(path):
    return shlex.split(path.read_text().splitlines()[0])
try:
    assert subprocess.check_output(['git','-C',src,'diff','--binary','HEAD'])==(home/'source.patch').read_bytes()
    past=json.loads((old/'status.json').read_text())
    old_core=old/'libdome-sculpt-core.a'
    assert past['exit']==0 and sha(old_core)==past['core_sha256'] and sha(old/'build/dome-sculpt')==past['app_sha256']
    delta={'bake-authoring.cpp','bake.cpp','document-baking.cpp','document.cpp','emission-bake-source.cpp','emission-package.cpp','export.cpp',
           'native-authoring-compiler.cpp','paint.cpp','native-paint-metadata.cpp','native-paint-sampling.cpp','normal-preparation.cpp','texture-set-surface.cpp','vrm1-export.cpp'}
    opts=[]
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    status(phase='configure canonical toolkit',patch_sha256=sha(home/'source.patch'),prior_core=sha(old_core))
    invoke(['cmake','-S',src,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,home)
    db=json.loads((build/'compile_commands.json').read_text())
    earlier=art/'native-writable-recipient-20261126'/profile
    corrected=art/'native-writable-recipient-v2-20261126'/profile
    grid=art/'native-writable-recipient-v3-20261126'/profile
    while True:
        result=subprocess.run(['systemctl','--user','is-active','--quiet',
                               f'ds-native-writable-recipient-v3-{profile}-20261126.service'])
        if result.returncode: break
        time.sleep(2)
    reused={}
    def compile(entry):
        cmd=shlex.split(entry['command'])
        filename=Path(entry['file']).name
        obj=out/(filename+'.o')
        cmd[cmd.index('-o')+1]=str(obj)
        cmd.extend(['-MMD','-MF',str(obj)+'.d'])
        previous=next((p for p in (grid,corrected,earlier) if (p/(obj.name+'.d')).is_file()),earlier)
        old_root=previous.parent
        former=previous/obj.name
        dep=previous/(obj.name+'.d')
        if former.is_file() and dep.is_file():
            def mapped(arg):return arg.replace(str(old_root),str(home))
            old_command=[mapped(w) for w in first(previous/(filename+'.log'))]
            assert cmd==old_command,(cmd,old_command)
            paths=shlex.split(dep.read_text().replace(chr(92)+chr(10),' ').split(':',1)[1])
            for path in paths:
                if path.startswith(str(old_root)):
                    assert sha(Path(path))==sha(Path(mapped(path))),path
            shutil.copyfile(former,obj)
            shutil.copyfile(previous/(filename+'.log'),out/(filename+'.reused.log'))
            reused[filename]=sha(obj)
            return obj
        invoke(cmd,filename+'.log',900)
        return obj
    suite='dome-sculpt-source-writable-normal-bake-test'
    core_entries=[entry for entry in db if 'CMakeFiles/dome-sculpt-core.dir/' in entry['command'] and Path(entry['file']).name in delta]
    app_entries=[entry for entry in db if 'CMakeFiles/dome-sculpt.dir/' in entry['command'] and Path(entry['file']).name=='bake-editor.cpp']
    suite_entries=[entry for entry in db if f'CMakeFiles/{suite}.dir/' in entry['command']]
    assert {Path(e['file']).name for e in core_entries}==delta and len(core_entries)==len(delta)
    assert len(app_entries)==len(suite_entries)==1
    status(phase='compile owning core, app and fixture sources',core_entries=sorted(delta))
    with ThreadPoolExecutor(max_workers=2 if asan else 3) as pool:
        objects=list(pool.map(compile,[*core_entries,*app_entries,*suite_entries]))
    core=out/old_core.name
    shutil.copyfile(old_core,core)
    owned=objects[:len(delta)]
    invoke(['ar','rs',core,*owned],'archive.log',300)
    assert subprocess.check_output(['ar','t',old_core])==subprocess.check_output(['ar','t',core])
    for obj in owned:
        assert hashlib.sha256(subprocess.check_output(['ar','p',core,obj.name])).hexdigest()==sha(obj)
    status(phase='relink actual app and regression fixtures',core=sha(core),objects={p.name:sha(p) for p in objects},reused=reused)
    app=build/'dome-sculpt'
    # Original app command has the current canonical toolkit configured. Both
    # archived core occurrences and the freshly compiled FLTK editor change.
    cmd=first(old/'app-link.log')
    cmd=[str(core) if word==str(old_core) else str(objects[-2]) if word.endswith('/bake-editor.cpp.o') else word for word in cmd]
    cmd[cmd.index('-o')+1]=str(app)
    invoke(cmd,'app-link.log',500,support)
    runtime=old/'build/libdome-sculpt-test-runtime.so'
    assert sha(runtime)==past['runtime_sha256']
    (build/runtime.name).symlink_to(runtime.resolve())
    def link_fixture(target):
        cmd=first(prior/'tests'/target/'link.log')
        cmd=[str(core) if word==str(prior/core.name) else str(objects[-1])
             if target==suite and word.endswith('/source-writable-normal-bake.cpp.o') else word for word in cmd]
        cmd[cmd.index('-o')+1]=str(build/target)
        invoke(cmd,target+'-link.log',600,prior/'build')
        return target,sha(build/target)
    target='dome-sculpt-native-authoring-inspect'
    bins=dict(link_fixture(t) for t in (suite,target))
    status(phase='native retained target and canonical control',app_sha256=sha(app),runtime_sha256=sha(runtime),binaries=bins)
    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    runenv={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        runenv.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,val in runenv.items():isolated.extend(['--setenv',key,val])
    report=build/'regressions.xml'
    exit_code=invoke([*isolated,'ctest','--test-dir',build,'-V','-j2','-R','^(canonical|native)-writable-bake-recipient$',
        '--output-on-failure','--output-junit',report],'ctest.log',650,check=False)
    status(phase='complete',terminal=True,exit=exit_code,ctest_sha256=sha(out/'ctest.log'),report_sha256=sha(report))
    raise SystemExit(exit_code)
except Exception as error:
    status(terminal=True,exit=1,error=repr(error))
    raise
