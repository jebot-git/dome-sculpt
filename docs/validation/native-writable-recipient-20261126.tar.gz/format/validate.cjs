const fs = require('fs');
const path = require('path');
const validator = require('../hdr-khronos-validation-20261126/module/package');
const root = path.join(__dirname, 'release/build/native-writable-bake-recipient');
(async () => {
  const reports = {};
  for (const name of ['ldr.glb', 'ldr-editable.glb', 'hdr.glb', 'hdr-editable.glb']) {
    const data = fs.readFileSync(path.join(root, name));
    const report = await validator.validateBytes(new Uint8Array(data), {uri: name, maxIssues: 10000});
    reports[name] = report;
    console.log(name, report.issues.numErrors, report.issues.numWarnings);
  }
  fs.writeFileSync(path.join(__dirname, 'khronos.json'), JSON.stringify(reports, null, 2) + '\n');
  process.exitCode = Object.values(reports).some(r => r.issues.numErrors || r.issues.numWarnings) ? 1 : 0;
})().catch(error => {console.error(error); process.exitCode = 1;});
