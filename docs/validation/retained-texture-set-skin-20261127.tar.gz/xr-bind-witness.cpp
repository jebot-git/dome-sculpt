#include "dome/scene.hpp"
#include "dome/skin-authoring.hpp"
#include <nlohmann/json.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <iomanip>
#include <iostream>

using namespace dome;

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  const auto original = Scene::load(argv[1]);
  const auto xr = Scene::load(argv[2]);
  const auto &target = *xr.active().deformation->skin;
  double minimum = 1;
  float nearest = 0;
  const auto sweep = [&](SkinAuthoringMode method, float metres) {
    auto scene = original;
    SkinAuthoringOptions options;
    options.mode = method;
    options.seed_distance = metres;
    options.reference = 2;
    try {
      if (!author_skin(scene, scene.active().id, options)) return;
    } catch (const std::exception &) {
      return;
    }
    const auto &current = *scene.active().deformation->skin;
    double error = 0;
    for (size_t i = 0; i < target.vertices.size(); ++i) {
      std::array<float, 2> expected{}, observed{};
      for (const auto &item : target.vertices[i]) expected.at(item.joint) = item.weight;
      for (const auto &item : current.vertices[i]) observed.at(item.joint) = item.weight;
      for (size_t j = 0; j < expected.size(); ++j)
        error = std::max(error, double(std::abs(expected[j] - observed[j])));
    }
    if (error < minimum) {
      minimum = error;
      nearest = metres;
    }
    if (current.vertices == target.vertices) {
      if (scene.encode() != xr.encode()) throw std::runtime_error("Exact weights differ in retained data");
      std::cout << "Exact native request equals saved controller project at method "
                << static_cast<int>(method) << " and " << std::setprecision(12) << metres << " m\n";
    }
  };
  for (const auto method : {SkinAuthoringMode::SurfaceHeat, SkinAuthoringMode::Automatic}) {
    minimum = 1;
    for (float seed : {.1f,.2f,.3f,.4f,.5f,.6f,.7f,.8f,.9f,1.f,1.1f,2.f,10000.f})
      sweep(method, seed);
    std::cout << "Method " << static_cast<int>(method) << " nearest weight error "
              << minimum << " at " << nearest << " m\n";
  }
} catch (const std::exception &e) {
  std::cerr << e.what() << '\n';
  return 1;
}
