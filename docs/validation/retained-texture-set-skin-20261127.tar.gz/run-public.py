from pathlib import Path
import subprocess
import sys

work = Path(__file__).resolve().parent
public = work.parent / "creator-public-build-20261126"
build = work / "release"
mode = sys.argv[1]
out = work / mode
fixtures = build / "texture-set-retained-skin" / "bake"
assert all((fixtures/name).is_file() for name in ("recall.dsculpt", "baked.dsculpt"))
env = {
    "PATH": str(public / "private-bin-v3") + ":/usr/bin:/bin",
    "HOME": "/tmp",
    "PYTHONPATH": str(public / "private-python"),
    "PYTHONDONTWRITEBYTECODE": "1",
    "LD_LIBRARY_PATH": ("/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:"
                        + str(public / "private-x11/usr/lib64") + ":/usr/lib64"),
    "LP_NUM_THREADS": "2",
    "DOME_POSED_BAKE_FIXTURE": str(fixtures),
}
args = ["bwrap", "--die-with-parent", "--unshare-all", "--ro-bind", "/", "/",
        "--bind", work, work, "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
        "--tmpfs", "/run/user", "--clearenv"]
app = build / "dome-sculpt"
helper = build / "dome-sculpt-texture-set-source-export-test"
if mode == "wayland":
    env.update(DOME_CAGE_WL_OUT=str(out), DOME_CAGE_APP=str(app),
               DOME_COMPOSITOR=str(public / "wayland-reference/dome-compositor"),
               DOME_CAGE_HELPER=str(helper),DOME_CAGE_TEXTURE_SET="1",
               DOME_CAGE_PROBE=str(work.parent/"vrm1-xr-attachment-20261127"/"combined-release"/
                                   "build"/"libdome-sculpt-test-widgets.so"))
    run = ["/usr/bin/python3.14", work / "wayland-bake.py"]
else:
    if mode == "arc":
        args = ["flock", "--timeout", "180", "/tmp/dome-sculpt-arc-device.lock", *args,
                "--dev-bind", "/dev/dri/renderD129", "/dev/dri/renderD129"]
        env.update(DOME_TEST_ARC="1", DRI_PRIME="pci-0000_03_00_0",
                   MESA_SHADER_CACHE_DISABLE="1", EGL_PLATFORM="surfaceless")
    run = ["/usr/bin/python3.14",work/"xr-bake.py",app,build/"libdome-sculpt-test-runtime.so",
           helper,out,"--texture-set"]
for key, value in env.items():
    args.extend(["--setenv", key, value])
with (work / (mode + ".log")).open("w") as log:
    subprocess.run([*args, *run], stdout=log, stderr=subprocess.STDOUT, check=True, timeout=480)
