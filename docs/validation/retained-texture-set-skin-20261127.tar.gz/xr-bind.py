from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile
import cbor2

work = Path(__file__).resolve().parent
build = work / "release"
mode = sys.argv[1]
slot = work / ("xr-bind-" + mode)
slot.mkdir(exist_ok=True)
project = build / "texture-set-retained-skin" / "skin" / "before-bind.dsculpt"
before = project.read_bytes()
with tempfile.TemporaryDirectory(dir="/tmp", prefix="dome-retained-bind-") as temp:
    private = Path(temp)
    runtime = private / "runtime.json"
    runtime.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{
        "library_path":str(build / "libdome-sculpt-test-runtime.so")}}))
    metadata = slot / "report.json"
    saved = slot / "bound.dsculpt"
    env = dict(os.environ, HOME=temp, XR_RUNTIME_JSON=str(runtime),
               DOME_XR_FIXTURE_SKIN="texture-set-heat", DOME_XR_FIXTURE_REPORT=str(metadata))
    for part in ("config", "state", "data", "cache", "runtime"):
        local = private / part
        local.mkdir(mode=0o700)
        env["XDG_" + part.upper() + ("_DIR" if part=="runtime" else "_HOME")] = str(local)
    with (slot / "app.log").open("w") as log:
        subprocess.run([build/"dome-sculpt","--xr","--open",project,"--frames","90","--save",saved],
                       env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=75)
info = json.loads(metadata.read_text())
assert info["acquires"] == info["image_waits"] == info["releases"] > 0
assert ("Arc(tm) A770" if mode=="arc" else "llvmpipe") in info["gl_renderer"]
assert project.read_bytes() == before
original, edited = cbor2.loads(before), cbor2.loads(saved.read_bytes())
old_object, new_object = (next(o for o in source["objects"] if o["id"]==source["active"])
                          for source in (original, edited))
assert new_object["deformation"]["skin"] and new_object["deformation"]["skeleton"]
assert old_object["deformation"]["morphs"] == new_object["deformation"]["morphs"]
assert old_object["deformation"]["morph_weights"] == new_object["deformation"]["morph_weights"]
assert original["texture_set_geometry"] == edited["texture_set_geometry"]
reference = project.with_name("bound.dsculpt").read_bytes()
result = {"same_native_reference":saved.read_bytes()==reference,
          "stereo_submissions":info["stereo_submissions"],"releases":info["releases"],
          "gl_renderer":info["gl_renderer"]}
(slot / "compare.json").write_text(json.dumps(result, indent=2)+"\n")
print("PASS OpenXR Surface Heat preserves native skin, shapekey and texture fields", result)
