from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parents[1]
destination = repo / "docs" / "validation"
stem = work.name

def read(name):
    return (work / name).read_text()

def report(name):
    return json.loads(read(name))

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

profiles = {}
for profile in ("release", "asan"):
    log = read(f"{profile}-final.log")
    assert "100% tests passed, 0 tests failed out of 16" in log
    cases = re.findall(r"Test\s+#\d+: (\S+)\s+\.+\s+Passed", log)
    controls = re.search(r"^PASS (\d+) retained skin, material and Bake controls$",
                         read(f"{profile}/Testing/Temporary/LastTest.log"), re.M)
    assert len(cases) == 16 and controls and int(controls[1]) == 117
    profiles[profile] = {
        "registered_cases": sorted(cases),
        "retained_skin_assertions": int(controls[1]),
        "test_binary_sha256": {
            label: sha(work / profile / label) for label in (
                "dome-sculpt-texture-set-source-export-test",
                "dome-sculpt-vrm1-source-export-test",
            )
        },
    }

wayland = {}
for action, count, folder in (("bind", 9, "wayland-bind"), ("default_bind", 9, "wayland-bind-default"), ("bake", 15, "wayland")):
    result = report(f"{folder}/report.json")
    assert len(result["checks"]) == count and all(it["passed"] for it in result["checks"])
    wayland[action] = count

controller_match = sha(work / "wayland-bind-default/heat-bound.dsculpt")
assert "Exact native request equals saved controller project at method 5 and 0.300000011921 m" in read("xr-bind-witness.log")
xr = {}
render = {}
for mode in ("software", "arc"):
    result = report(f"{mode}/report.json")
    checks = result["checks"]
    assert len(checks) == 19 and all(it["passed"] for it in checks)
    assert "19 actual-loader custom cage checks passed" in read(f"{mode}.log")
    attempts = {}
    for name in ("accept", "cancel", "focus"):
        record = report(f"{mode}/{name}.json")
        assert record["acquires"] == record["image_waits"] == record["releases"] > 0
        if name == "focus":
            assert record["focus_losses"] == record["focus_regains"] == 1
        attempts[name] = {k: record[k] for k in ("gl_renderer", "stereo_submissions", "releases")}
    pose = report(f"xr-{mode}/compare.json")
    assert pose["exact_ordered_close"] and len(pose["profiles"]) == 2
    assert all(diff > 100 for diff in pose["differing_rgb_components_per_eye"])
    assert all(it["stereo_submissions"] == 6 and it["releases"] == 12 for it in pose["profiles"])
    bind = report(f"xr-bind-{mode}/compare.json")
    assert bind["stereo_submissions"] == 77 and bind["releases"] == 154
    assert sha(work / f"xr-bind-{mode}/bound.dsculpt") == controller_match
    xr[mode] = {
        "surface_heat": {
            "seed_radius_m": .3, "matched_native_worker_and_wayland": True,
            "project_sha256": controller_match, "stereo_submissions": bind["stereo_submissions"],
            "releases": bind["releases"], "gl_renderer": bind["gl_renderer"],
        },
        "bake_assertions": len(checks), "bake_runs": attempts,
        "cold_pose": {
            "matched_input_project_bytes": pose["exact_ordered_close"],
            "different_rgb_components_per_eye": pose["differing_rgb_components_per_eye"],
            "stereo_submissions_per_run": 6, "image_releases_per_run": 12,
        },
    }
    oracle = report(f"verified-render-{mode}/oracle.json")
    output = read(f"verified-render-{mode}.log")
    m = re.search(r"^GL_RENDERER (.+)$", output, re.M)
    assert m and ("Arc(tm) A770" if mode=="arc" else "llvmpipe") in m[1]
    assert len(oracle["cases"]) == 8 and all("skinned" in it for it in oracle["cases"])
    assert "PASS 1122 actual sourceful same-object field appearance controls" in output
    render[mode] = {"renderer": m[1], "cases": 8, "assertions": 1122}

consumer = report("consumer.json")
assert len(consumer) == 4 and all(it["corners"] == 6 and it["maximum_position_error_m"] < 3e-6
                                  and it["maximum_weight_error"] < 3e-6 for it in consumer)
validation = report("khronos.json")
assert len(validation["reports"]) == 6
warnings = {}
for item in validation["reports"]:
    issues = item["report"]["issues"]
    assert issues["numErrors"] == 0
    warnings[item["uri"]] = dict(Counter(it["code"] for it in issues["messages"] if it["severity"] == 1))
schemas = report("schemas.json")
assert len(schemas["files"]) == 2 and len(schemas["resolver_controls"]) == 2
assert all(len(item["checks"]) == 8 and all(not it["errors"] for it in item["checks"])
           for item in schemas["files"])

exact = {}
for f in (
    "texture-set-retained-skin/skin/before-bind.dsculpt",
    "texture-set-retained-skin/skin/bound.dsculpt",
    "texture-set-retained-skin/skin/rigid-pose.dsculpt",
    "texture-set-retained-skin/skin/skinned-standard.glb",
    "texture-set-retained-skin/skin/skinned-editable.glb",
    "texture-set-retained-skin/bake/baked.dsculpt",
    "texture-set-retained-skin/bake/recall.dsculpt",
    "texture-set-retained-skin/bake/posed-standard.glb",
    "texture-set-retained-skin/bake/posed-editable.glb",
    "vrm1-retained-skinned-accessory/retained-standard.vrm",
    "vrm1-retained-skinned-accessory/retained-editable.vrm",
):
    release, asan = (sha(work / profile / f) for profile in ("release", "asan"))
    assert release == asan, f
    exact[f] = release
assert sha(work/"wayland-bind/heat-bound.dsculpt") == exact["texture-set-retained-skin/skin/bound.dsculpt"]

logs = [
    "receipt.py", "check-final.sh", "run-bind.py", "wayland-heat.py", "run-public.py",
    "wayland-bake.py", "xr-bake.py", "xr-pose.py", "run-render.py", "khronos.cjs",
    "consumer.py", "consumer.json", "consumer.log",
    "xr-bind.py", "xr-bind-witness.cpp", "xr-bind-witness.log", "build-witness.py",
    "release-final.log", "asan-final.log", "release/Testing/Temporary/LastTest.log",
    "asan/Testing/Temporary/LastTest.log", "khronos.json", "schemas.json", "schemas.log",
    "bind-wayland.log", "wayland.log", "wayland-bind/report.json", "wayland/report.json",
    "bind-wayland-default.log", "wayland-bind-default/report.json",
]
for mode in xr:
    logs += [f"{mode}.log", f"{mode}/report.json", f"xr-{mode}/compare.json",
             f"verified-render-{mode}/oracle.json", f"verified-render-{mode}.log",
             f"verified-pose-{mode}.log", f"verified-bind-{mode}.log",
             f"xr-bind-{mode}/compare.json", f"xr-bind-{mode}/report.json"]
    logs += [f"{mode}/{case}.json" for case in ("accept", "cancel", "focus")]
archive = destination / (stem + ".tar.gz")
with archive.open("wb") as output, gzip.GzipFile(filename="", fileobj=output, mode="wb", mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode="w") as bundle:
        for name in sorted(logs):
            info = bundle.gettarinfo(str(work / name), arcname=name)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ""
            info.mode = 0o644
            with (work / name).open("rb") as payload:
                bundle.addfile(info, payload)

data = {
    "revision": subprocess.check_output(["git","-C",repo,"rev-parse","HEAD"], text=True).strip(),
    "canonical_domed_revision": "acc2b70ae61dedec2a23727f67c60c0303d0f76f",
    "release_fltk": "/opt/fltk-vr/toolkit",
    "asan_fltk": "artifacts/sdk-20261126/toolkit-sanitize",
    "release_application_sha256": sha(work / "release/dome-sculpt"),
    "native": profiles,
    "qualification": {
        "binding": "Cold prepared PBR with independent paint and normal grids, two materials and two native joints, exercised through native worker, Wayland and controller-driven synthetic OpenXR",
        "deformation": "Combined shape and differential joints, material-aware picking, and transactional weight painting",
        "bake": "Reflected prepared PBR donor and recipient with active shape and single-joint deformation, reflected affine placement, custom cage, AO and FLOAT emission",
        "standard_export": "Certified rigid posing of a mesh with two joints, plus explicit refusal of a differential pose beyond the portable angular limit",
        "vrm1": "Transfer to an original VRM 1.0 rig with both retained accessory materials sharing original joints, Standard and Editable",
    },
    "sanitizer_environment": {"ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1",
                              "UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1"},
    "nested_domed_wayland_assertions": wayland,
    "synthetic_openxr": xr,
    "opengl_render": render,
    "independent_glb_skin_consumer": consumer,
    "khronos": {"version": validation["version"],"files":len(warnings),
                "errors":0, "warnings_by_file":warnings},
    "vrm_official_schemas": {"files":2,"checks_per_file":8,"errors":0,"resolver_controls":2},
    "identical_release_asan_files_sha256": exact,
    "physical_headset_tested": False,
    "archive": {"path": archive.name, "sha256": sha(archive),
                "members_sha256": {name: sha(work / name) for name in sorted(logs)}},
}
(destination / (stem + ".json")).write_text(json.dumps(data, indent=2)+"\n")
