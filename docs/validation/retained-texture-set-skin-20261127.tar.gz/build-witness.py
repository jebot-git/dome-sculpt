from pathlib import Path
import subprocess
import shlex
work=Path(__file__).resolve().parent
build=work/'release'
lines=subprocess.check_output(['ninja','-C',str(build),'-t','commands','dome-sculpt-texture-set-source-export-test'],text=True).splitlines()
compile_command=next(line for line in lines if line.endswith('/tests/texture-set-source-export.cpp'))
command=shlex.split(compile_command)
command=command[:command.index('-MD')]+['-c',str(work/'xr-bind-witness.cpp'),'-o',str(work/'xr-bind-witness.o')]
subprocess.run(command,cwd=build,check=True)
linker=shlex.split(lines[-1])[2:-2]
linker=[str(work/'xr-bind-witness.o') if a.endswith('/texture-set-source-export.cpp.o') else
        str(work/'xr-bind-witness') if a=='dome-sculpt-texture-set-source-export-test' else a
        for a in linker if not a.startswith('-Wl,--dependency-file=')]
subprocess.run(linker,cwd=build,check=True)
