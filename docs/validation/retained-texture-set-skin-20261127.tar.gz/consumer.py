"""Independently evaluate emitted GLB vertices from public joint and morph streams."""
import json
from pathlib import Path
import struct
import cbor2
import numpy as np

root = Path(__file__).resolve().parent
profile = root / "release" / "texture-set-retained-skin"

def matrix(v):
    return np.array(v, dtype=float).reshape((4, 4), order="F")

def trs(t, q, s):
    x, y, z, w = np.array(q) / np.linalg.norm(q)
    result = np.eye(4)
    result[:3, :3] = np.array([
        [1-2*y*y-2*z*z, 2*x*y-2*z*w, 2*x*z+2*y*w],
        [2*x*y+2*z*w, 1-2*x*x-2*z*z, 2*y*z-2*x*w],
        [2*x*z-2*y*w, 2*y*z+2*x*w, 1-2*x*x-2*y*y],
    ]) @ np.diag(s)
    result[:3, 3] = t
    return result

def unit(q):
    return [*q[1:], q[0]]

def expected(project):
    scene = cbor2.loads(project.read_bytes())
    obj = next(o for o in scene["objects"] if o["id"] == scene["active"])
    assert obj["group"] == 0
    placement = trs(obj["translation"], obj["rotation"], [obj["scale"]] * 3)
    if scene.get("affine_state"):
        edit = scene["affine_state"]["edits"][0]
        assert len(scene["affine_state"]["edits"]) == 2
        placement = placement @ matrix(edit)
    arena = scene["texture_set_geometry"]
    collection = arena["collections"][obj["texture_sets"]["collection"]]
    mesh = arena["meshes"][arena["topologies"][collection["topology"]]["mesh"]]
    points = np.frombuffer(mesh["positions"], dtype="<f4").reshape((-1, 3))
    state = obj["deformation"]
    rest, pose = [], []
    for definition, current in zip(state["skeleton"]["bones"], state["pose"], strict=True):
        bind = trs(definition["translation"], unit(definition["rotation"]), definition["scale"])
        at = trs(current["translation"], unit(current["rotation"]), current["scale"])
        parent = definition["parent"]
        rest.append((rest[parent] if parent >= 0 else np.eye(4)) @ bind)
        pose.append((pose[parent] if parent >= 0 else np.eye(4)) @ at)
    skinning = [placement @ current @ np.linalg.inv(bind) for current, bind in zip(pose, rest, strict=True)]
    scaled = np.array(points, dtype=float)
    for weight, target in zip(state["morph_weights"], state["morphs"]["targets"], strict=True):
        scaled += weight * np.asarray(target["delta"])
    rows = np.zeros((len(points), len(skinning)))
    for v, influences in enumerate(state["skin"]["vertices"]):
        for j, weight in influences:
            rows[v, j] = weight
    result = np.array([sum(weight * transform @ np.append(p, 1)
                           for weight, transform in zip(row, skinning, strict=True))
                       for row, p in zip(rows, scaled, strict=True)])
    return points, result, rows

def consumer(file, proof):
    path = profile / file
    data = path.read_bytes()
    assert data[:12] == struct.pack("<4sII", b"glTF", 2, len(data))
    count, name = struct.unpack_from("<I4s", data, 12)
    assert name == b"JSON"
    gltf = json.loads(data[20:20+count])
    size, name = struct.unpack_from("<I4s", data, 20+count)
    assert name == bytes((66, 73, 78, 0))
    binary = memoryview(data)[28+count:28+count+size]
    buffers = {5121:np.dtype("<u1"),5123:np.dtype("<u2"),5125:np.dtype("<u4"),5126:np.dtype("<f4")}
    def accessor(i):
        a = gltf["accessors"][i]
        b = gltf["bufferViews"][a["bufferView"]]
        dtype = buffers[a["componentType"]]
        components = {"SCALAR":1,"VEC3":3,"VEC4":4,"MAT4":16}[a["type"]]
        start = b.get("byteOffset", 0) + a.get("byteOffset", 0)
        step = b.get("byteStride", components*dtype.itemsize)
        x = np.ndarray((a["count"], components), dtype=dtype, buffer=binary, offset=start,
                       strides=(step,dtype.itemsize))
        return x / np.iinfo(dtype).max if a.get("normalized") else x
    nodes = gltf["nodes"]
    parents = {child:parent for parent,n in enumerate(nodes) for child in n.get("children", [])}
    def world(i):
        v = nodes[i]
        local = matrix(v["matrix"]) if "matrix" in v else trs(
            v.get("translation", [0,0,0]), v.get("rotation", [0,0,0,1]), v.get("scale", [1,1,1]))
        return world(parents[i]) @ local if i in parents else local
    node, = (n for n in nodes if "mesh" in n)
    skin = gltf["skins"][node["skin"]]
    joint_matrices = [world(joint) @ matrix(ibm) for joint, ibm in
                      zip(skin["joints"], accessor(skin["inverseBindMatrices"]), strict=True)]
    mesh = gltf["meshes"][node["mesh"]]
    expected_positions, expected_world, expected_rows = proof
    worst = 0
    weight_error = 0
    surface_corners = 0
    for primitive in mesh["primitives"]:
        attrs = primitive["attributes"]
        rest = accessor(attrs["POSITION"])
        poses = rest.astype(float, copy=True)
        for value, target in zip(mesh["weights"], primitive["targets"], strict=True):
            poses += value * accessor(target["POSITION"])
        for index in accessor(primitive["indices"]).flat:
            v = int(index)
            weights = np.zeros(len(joint_matrices))
            for key in range(16):
                if "JOINTS_" + str(key) not in attrs:
                    break
                joints = accessor(attrs["JOINTS_" + str(key)])[v]
                values = accessor(attrs["WEIGHTS_" + str(key)])[v]
                for joint, value in zip(joints, values, strict=True):
                    weights[int(joint)] += value
            actual = sum(weight * transform @ np.append(poses[v],1)
                         for weight, transform in zip(weights, joint_matrices, strict=True))
            offsets = np.linalg.norm(expected_positions - rest[v], axis=1)
            matches = np.where(offsets < 5e-7)[0]
            assert len(matches), (path, tuple(rest[v]))
            same_position = min(matches, key=lambda k: np.linalg.norm(expected_world[k] - actual))
            error = float(np.linalg.norm(expected_world[same_position] - actual))
            worst = max(worst,error)
            weight_error = max(weight_error, float(np.max(np.abs(weights - expected_rows[same_position]))))
            surface_corners += 1
    assert surface_corners == 6 and worst < 3e-6 and weight_error < 3e-6, (path, worst, weight_error)
    return {"file": file, "corners":surface_corners, "maximum_position_error_m":worst,
            "maximum_weight_error":weight_error}

reports = []
for name, project in (("skin", "skin/rigid-pose.dsculpt"), ("bake", "bake/before.dsculpt")):
    proof = expected(profile / project)
    stem = "skinned" if name == "skin" else "posed"
    reports.extend(consumer(f"{name}/{stem}-{mode}.glb", proof)
                   for mode in ("standard", "editable"))
(root / "consumer.json").write_text(json.dumps(reports, indent=2)+"\n")
print(json.dumps(reports, indent=2))
