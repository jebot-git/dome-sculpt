from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

work = Path(__file__).resolve().parent
build = work / "release"
mode = sys.argv[1]
placement = sys.argv[2]
slot = work / ("xr-" + mode + "-" + placement)
slot.mkdir(exist_ok=True)
data = []
material_pixels = {}
for name in ("first-material-source", "first-material-patch"):
    output = slot / name
    output.mkdir(exist_ok=True)
    project = build / "view-fixtures" / ("retopology-first-material-posed-" + placement) / f"{name}.dsculpt"
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="dome-retained-xr-") as temp:
        private = Path(temp)
        runtime = private / "runtime.json"
        runtime.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{
            "library_path":str(build / "libdome-sculpt-test-runtime.so")}}))
        metadata = output / "report.json"
        saved = output / "closed.dsculpt"
        env = dict(os.environ, HOME=temp, XR_RUNTIME_JSON=str(runtime),
                   DOME_XR_FIXTURE_PBR_VIEW="1", DOME_XR_FIXTURE_REPORT=str(metadata))
        for part in ("config", "state", "data", "cache", "runtime"):
            local = private / part
            local.mkdir(mode=0o700)
            env["XDG_" + part.upper() + ("_DIR" if part=="runtime" else "_HOME")] = str(local)
        with (output / "app.log").open("w") as log:
            subprocess.run([build/"dome-sculpt","--xr","--open",project,"--frames","7","--save",saved],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=45)
        info = json.loads(metadata.read_text())
        assert info["action_syncs"] == 7 and info["stereo_submissions"] == 6
        assert info["acquires"] == info["image_waits"] == info["releases"] == 12
        assert ("Arc(tm) A770" if mode == "arc" else "llvmpipe") in info["gl_renderer"], info["gl_renderer"]
        assert all(info["pbr_preview_images"]["6"][str(eye)]["opaque"] > 0 for eye in (0,1))
        assert project.read_bytes() == saved.read_bytes()
        material_pixels[name] = {}
        for eye in (0,1):
            rgb = (output / f"report.json.pbr-6-{eye}.ppm").read_bytes().split(b"\n",3)[3]
            pixels = list(zip(*([iter(rgb)] * 3)))
            left=sum(r>g+18 and r>b+18 for r,g,b in pixels)
            if placement == "affine":
                right=sum(g>=245 and r<100 and g>r+70 and g>b+25 for r,g,b in pixels)
            else:
                right=sum(b>r+35 and b>g+35 for r,g,b in pixels)
            assert min(left,right)>1000,(name,eye,left,right)
            material_pixels[name][eye]=[left,right]
        data.append(info)
def rgb(path):
    return path.read_bytes().split(b"\n", 3)[3]
different = []
for eye in (0, 1):
    before, after = [rgb(slot/name/f"report.json.pbr-6-{eye}.ppm") for name in ("first-material-source", "first-material-patch")]
    assert len(before) == len(after)
    count = sum(a!=b for a,b in zip(before, after))
    assert count > 100, (eye, count)
    different.append(count)
report = {"runtime":"synthetic OpenXR", "profiles":data,
          "differing_rgb_components_per_eye":different,
          "exact_ordered_close":True,"material_pixels_per_eye":material_pixels}
(slot / "compare.json").write_text(json.dumps(report, indent=2)+"\n")
print(f"PASS {mode} stereo before/after first material transfer, balanced submissions and exact close", different)
