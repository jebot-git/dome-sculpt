from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
art=base.parent
profile=sys.argv[1]
arc=profile=='arc'
out=base/profile
out.mkdir(exist_ok=True)
native=art/'native-authored-grid-validation-v3-20261126/release'
runtime=art/'current-full-release-20261126/build'
source=art/'current-authored-paint-resolution-source-20261126'
candidate='d9ea0716855609a2f8121fc4ffa9e652446b771e'
status={'candidate':candidate,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def save(**fields):
    status.update(fields)
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()
try:
    save(phase='wait for validated Release')
    while True:
        status_file=native/'status.json'
        if status_file.is_file():
            sealed=json.loads(status_file.read_text())
            if sealed['terminal']:break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        'ds-authored-native-grid-release-v3-20261126.service'],check=True)
        time.sleep(2)
    assert sealed['candidate']==candidate and sealed['exit']==0 and sealed['tests']==3
    app=native/'build/dome-sculpt'
    assert sha(app)==sealed['app_sha256']
    assert not subprocess.check_output(['git','-C',source,'diff','--name-only',
        'fadacc00','HEAD','--','tests/texture-set-resolution-runtime.cpp'],text=True)
    fixtures=native/'build/native-authored-paint-resolution'
    fixture=fixtures/'vroid-beta-female-painted128.dsculpt'
    expected=fixtures/'vroid-beta-female-painted256.dsculpt'
    synthetic=runtime/'libdome-sculpt-texture-resolution-runtime.so'
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    report=out/'runtime.json'
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','XDG_RUNTIME_DIR':'/tmp',
                 'DOME_FIELD_XR_REQUIRE_RENDERER':'Arc(tm) A770' if arc else 'llvmpipe',
                 'EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2','LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1',
                 'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if arc:
        node='/dev/dri/renderD129'
        prefix.extend(['--dev-bind',node,node])
        environment.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1')
    for k,v in environment.items():prefix.extend(['--setenv',k,v])
    command=[*prefix,'/usr/bin/python3',base/'replay.py',app,synthetic,fixture,expected,out/'workflow']
    save(phase='controller resize, undo, redo and save through the actual OpenXR loader',
         app_sha256=sha(app),immutable_project_sha256=sha(fixture),runtime_sha256=sha(synthetic))
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock,(out/'xr.log').open('w') as trace:
        if arc:fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,command)),file=trace,flush=True)
        subprocess.run(command,cwd=out,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=570)
    observed=json.loads((out/'workflow/report.json').read_text())
    record=observed['cases'][0]
    assert observed['complete'] and observed["count"]==18 and not observed['drift'] and record['native_sha256']==sha(expected)
    save(phase='complete',terminal=True,exit=0,renderer=record['renderer'],
         checks=observed['count'],report_sha256=sha(out/'workflow/report.json'),native_sha256=record['native_sha256'])
except Exception as error:
    save(terminal=True,exit=1,error=repr(error))
    raise
