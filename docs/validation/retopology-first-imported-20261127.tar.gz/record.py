from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def git(path):
    return subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()

def read(name):
    return json.loads((work / name).read_text())

archive_files = ['record.py', 'check-profile.sh', 'baseline-fixture.log', 'bind-wayland.log',
                 'run-wayland.py', 'wayland-first-material.py', 'wayland-first-material/report.json',
                 'wayland-first-material/corners.json', 'wayland-first-material/source-viewport.png',
                 'run-render.py', 'xr-first-material.py', 'khronos.cjs', 'khronos.json']
assert 'FAIL Apply produces a native Bake' in (work / 'baseline-fixture.log').read_text()
runs = {}
measurements = {}
for profile, label, count in [('release', 'final', 45), ('asan', 'qualified', 12)]:
    name = f'{profile}-{label}.log'
    log = (work / name).read_text()
    tests = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', log)
    assert len(tests) == len(set(tests)) == count and f'0 tests failed out of {count}' in log
    runs[profile] = tests
    all_controls = (work / profile / 'Testing/Temporary/LastTest.log').read_text()
    matched = re.search(r'^\d+/\d+ Testing: retopology-imported-pbr\n(.*?)^Test Passed\.', all_controls, re.M | re.S)
    assert matched
    controls = matched[1]
    samples, peak, normal_dot = re.search(r'^IMPORTED_PBR interior=(\d+) peak=([\d.]+) min_normal_dot=([\d.]+)$', controls, re.M).groups()
    assertions = re.search(r'^PASS (\d+) imported material retopology checks$', controls, re.M)[1]
    measurements[profile] = {'checks': int(assertions), 'interior_samples': int(samples),
                             'minimum_normal_dot_rounded': float(normal_dot), 'peak_red_radiance_rounded': float(peak)}
    controls_name = f'{profile}-native-controls.log'
    (work / controls_name).write_text(controls)
    archive_files += [name, f'{profile}-{label}-build.log', controls_name]
assert measurements['release'] == measurements['asan']
outputs = {}
for file in ('original-import.glb', 'raw-guide.dsculpt', 'raw-patch.dsculpt', 'raw-standard.glb', 'raw-editable.glb'):
    path = Path('retopology-imported-pbr') / file
    outputs[file] = digest(work / 'release' / path)
    assert outputs[file] == digest(work / 'asan' / path)

wayland = read('wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks']) == 7 and all(row['passed'] for row in wayland['checks'])
validator = read('khronos.json')
assert len(validator['results']) == 4
for row in validator['results']:
    assert row['issues']['numErrors'] == 0
    warnings = [item for item in row['issues']['messages'] if item['severity'] == 1]
    if row['file'].endswith('original-import.glb'):
        assert not warnings
    else:
        assert [item['code'] for item in warnings] == ['MESH_PRIMITIVE_GENERATED_TANGENT_SPACE']
    row['sha256'] = digest(work / row['file'])

stereo = {}
for gpu in ('arc', 'software'):
    path = f'xr-{gpu}-affine/compare.json'
    evidence = read(path)
    assert evidence['exact_ordered_close'] and len(evidence['profiles']) == 2
    for profile in evidence['profiles']:
        assert profile['stereo_submissions'] == 6 and profile['action_syncs'] == 7
        assert profile['acquires'] == profile['image_waits'] == profile['releases'] == 12
    assert min(evidence['differing_rgb_components_per_eye']) > 100
    stereo[gpu] = {'renderer': evidence['profiles'][0]['gl_renderer'], 'stereo_submissions_per_project': 6,
                   'differing_rgb_components_per_eye': evidence['differing_rgb_components_per_eye'],
                   'authoring_pixels_per_eye': evidence['material_pixels_per_eye'], 'exact_ordered_close': True}
    archive_files += [path, f'verified-affine-{gpu}.log']

archive = validation / (work.name + '.tar.gz')
members = {}
with tarfile.open(archive, 'w:gz', compresslevel=9) as out:
    for file in archive_files:
        data = (work / file).read_bytes()
        members[file] = sha256(data).hexdigest()
        entry = tarfile.TarInfo(file)
        entry.size = len(data)
        out.addfile(entry, io.BytesIO(data))

receipt = {'product': git(repo), 'previous_product': '8d7356ea', 'canonical_domed': git(repo.parent / 'DomeD'),
           'canonical_compositor_sha256': digest(work.parent / 'creator-public-build-20261126/wayland-reference/dome-compositor'),
           'release_app_sha256': digest(work / 'release/dome-sculpt'),
           'strict_asan_ubsan_test_sha256': digest(work / 'asan/dome-sculpt-texture-set-source-export-test'),
           'test_results': runs, 'native_measurements': measurements, 'identical_native_and_glb_outputs_sha256': outputs,
           'wayland': wayland, 'synthetic_stereo': stereo, 'physical_headset': False, 'khronos': validator,
           'archive_sha256': digest(archive), 'archive_members_sha256': members}
(validation / (work.name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
