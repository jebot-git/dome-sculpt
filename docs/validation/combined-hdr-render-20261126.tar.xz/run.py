from pathlib import Path
import fcntl
import hashlib
import json
import os
import re
import time
from owned_monitor import run

HERE = Path(__file__).resolve().parent
EXE = HERE / 'hdr-render-test'
OBSERVER = HERE / 'context-observer.so'
DEVICE = Path('/sys/class/drm/renderD129/device').resolve()
BUILT = json.loads((HERE / 'build-status.json').read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


status = {'terminal': False, 'source': 'c1aea4cb', 'executable': sha(EXE),
          'observer': sha(OBSERVER), 'cases': []}
assert BUILT['exit'] == 0 and BUILT['ELF'] == status['executable']
assert DEVICE.name == '0000:03:00.0'
assert (DEVICE / 'vendor').read_text().strip() == '0x8086'
assert (DEVICE / 'device').read_text().strip() == '0x56a0'
assert (DEVICE / 'driver').resolve().name == 'i915'


def save():
    (HERE / 'runtime-status.json').write_text(json.dumps(status, indent=2) + '\n')


save()
try:
    with open('/tmp/dome-sculpt-arc-device.lock', 'rb') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        status['acquired'] = time.time()
        try:
            for label in ('software', 'arc'):
                env = dict(os.environ, LD_PRELOAD=str(OBSERVER),
                           LD_LIBRARY_PATH='/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
                           EGL_PLATFORM='surfaceless', LP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2',
                           __EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json')
                for key in ('DRI_PRIME', 'MESA_LOADER_DRIVER_OVERRIDE', 'LIBGL_ALWAYS_SOFTWARE'):
                    env.pop(key, None)
                if label == 'software':
                    env['LIBGL_ALWAYS_SOFTWARE'] = '1'
                else:
                    env.update(DRI_PRIME='pci-0000_03_00_0', MESA_LOADER_DRIVER_OVERRIDE='iris')
                fds = set()

                def observe(row):
                    proc = Path('/proc') / str(row['pid'])
                    try:
                        if not (proc / 'exe').samefile(EXE):
                            return
                        for fd in (proc / 'fd').iterdir():
                            try:
                                name = os.readlink(fd)
                            except FileNotFoundError:
                                continue
                            if name.startswith('/dev/dri/'):
                                fds.add(name)
                        if label == 'arc' and '/dev/dri/renderD129' in fds and not (HERE / 'arc-live-maps.txt').exists():
                            (HERE / 'arc-live-maps.txt').write_text((proc / 'maps').read_text())
                    except (FileNotFoundError, ProcessLookupError):
                        return

                argv = [str(EXE)] + (['--hardware'] if label == 'arc' else [])
                log = HERE / f'{label}.log'
                row = run(argv, cwd=HERE, env=env, log=log, timeout=120,
                          max_rss=3 * 1024**3, progress=observe)
                content = log.read_text()
                render = 'llvmpipe' if label == 'software' else 'Intel(R) Arc(TM) A770'
                contexts = re.findall(r'^HDR_ARC_CONTEXT read=(\d+) context=(0x\w+) display=(0x\w+) .* renderer=(.*)$', content, re.M)
                numerical = re.search(r'^HDR_GPU coefficient_error=0 maximum_RGB_error=(\d+) checks=4422$', content, re.M)
                samples = re.findall(r'^HDR_MATERIAL edited=(\d) mtoon=(\d) rgb_error=(\d+)$', content, re.M)
                device_witness = (not fds if label == 'software' else fds == {'/dev/dri/renderD129'})
                accepted = (row['exit'] == 0 and 'error' not in row and numerical is not None and
                            int(numerical[1]) <= 2 and len(samples) == 4 and device_witness and
                            [int(i) for i, _, _, _ in contexts] == list(range(1, 106)) and
                            len({(context, display) for _, context, display, _ in contexts}) == 1 and
                            all(render in renderer for _, _, _, renderer in contexts))
                row.update(label=label, accepted=accepted, context_reads=len(contexts), drm_fds=sorted(fds),
                           coefficients_exact=numerical is not None, material_phases=samples)
                status['cases'].append(row)
                save()
                assert sha(EXE) == status['executable'] and sha(OBSERVER) == status['observer']
        finally:
            status['released'] = time.time()
    status['exit'] = int(not all(row['accepted'] for row in status['cases']))
except BaseException as error:
    status.update(exit=1, error=repr(error))
finally:
    status['terminal'] = True
    save()
raise SystemExit(status['exit'])
