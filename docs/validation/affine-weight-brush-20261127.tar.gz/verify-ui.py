from pathlib import Path
import os
import subprocess
import sys

work = Path(__file__).resolve().parent
artifacts = work.parent
public = artifacts / "creator-public-build-20261126"
build = work / "release"
wayland = work / "wayland"
mode = sys.argv[1]
env = {
    "PATH": str(public / "private-bin-v3") + ":/usr/bin:/bin",
    "HOME": "/tmp",
    "PYTHONPATH": str(public / "private-python"),
    "PYTHONDONTWRITEBYTECODE": "1",
    "LD_LIBRARY_PATH": ("/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:"
                        + str(public / "private-x11/usr/lib64") + ":/usr/lib64"),
    "LP_NUM_THREADS": "2",
}
args = ["bwrap", "--die-with-parent", "--unshare-all", "--ro-bind", "/", "/",
        "--bind", work, work, "--proc", "/proc", "--dev", "/dev", "--tmpfs", "/tmp",
        "--tmpfs", "/run/user", "--clearenv"]
if mode == "wayland":
    env.update(
        DOME_CAGE_WL_OUT=str(wayland),
        DOME_CAGE_APP=str(build / "dome-sculpt"),
        DOME_COMPOSITOR=str(public / "wayland-reference/dome-compositor"),
        DOME_ACCESSORY_PROJECT=str(build / "xr-fixture/before.dsculpt"),
        DOME_ACCESSORY_REFERENCE=str(build / "xr-fixture/after.dsculpt"),
    )
    run = ["/usr/bin/python3.14", work / "wayland-weight.py"]
else:
    if mode.startswith("arc"):
        args = ["flock", "--timeout", "240", "/tmp/dome-sculpt-arc-device.lock", *args,
                "--dev-bind", "/dev/dri/renderD129", "/dev/dri/renderD129"]
    if mode == 'arc':
        env.update(DRI_PRIME='pci-0000_03_00_0', EGL_PLATFORM='surfaceless', MESA_SHADER_CACHE_DISABLE='1')
    else:
        env['LIBGL_ALWAYS_SOFTWARE'] = '1'
    run = ['/usr/bin/python3.14', artifacts.parent / 'tests/affine-weight-xr.py', build / 'dome-sculpt',
           build / 'libdome-sculpt-test-runtime.so', build / 'dome-sculpt-weight-authoring-test',
           work / mode, '--renderer', 'A770' if mode == 'arc' else 'llvmpipe']


for key, value in env.items():
    args.extend(["--setenv", key, value])
with (work / (mode + ".log")).open("w") as log:
    subprocess.run([*args, *run], stdout=log, stderr=subprocess.STDOUT, check=True, timeout=510)
