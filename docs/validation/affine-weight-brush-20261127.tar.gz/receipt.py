from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
docs = repo / 'docs' / 'validation'
name = 'affine-weight-brush-20261127'
members = {}


def git(directory, *args):
    return subprocess.check_output(['git', *args], cwd=directory, text=True).strip()


def sha(payload):
    return hashlib.sha256(payload).hexdigest()


def hash_file(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def capture(path):
    data = (work / path).read_bytes()
    members[path] = data
    return data


def load(path):
    return json.loads(capture(path))


def checks(path, count):
    lines = capture(path).decode().splitlines()
    assert not any(line.startswith('FAIL ') for line in lines), path
    result = [line for line in lines if line.startswith('PASS ')]
    assert len(result) == count, (path, len(result))
    return result


def registered(path, count):
    items = ET.fromstring(capture(path)).findall('.//testcase')
    names = {item.attrib['name'] for item in items}
    assert len(items) == len(names) == count
    assert all(item.find(tag) is None for item in items for tag in ('failure', 'error', 'skipped'))
    return sorted(names)


revision = git(repo, 'rev-parse', sys.argv[1])
assert not git(repo, 'diff', '--name-only', revision, '--', 'src', 'include', 'tests', 'CMakeLists.txt')
dome = repo.parent / 'DomeD'
canonical = git(dome, 'rev-parse', 'HEAD')
assert canonical == 'acc2b70ae61dedec2a23727f67c60c0303d0f76f'
assert git(dome, 'ls-remote', '--exit-code', 'origin', 'refs/heads/main').split()[0] == canonical

profiles = {}
for profile, n in (('release', 7), ('asan', 5)):
    kernel = checks(f'{profile}/kernel.log', 43)
    document = checks(f'{profile}/document.log', 80)
    native = checks(f'{profile}/qualified.log', 218)
    for witness, log in (('differing skin slot tables', kernel),
                         ('circular world-distance falloff', document),
                         ('keeps unheld siblings unchanged', document),
                         ('another instance', native),
                         ('painted weights and baked FLOAT emission together', native)):
        assert any(witness in line for line in log), witness
    suite = registered(f'{profile}/registered.xml', n)
    assert registered(f'{profile}/final-vrm1.xml', 1) == ['vrm1-source-export']
    for path in (f'{profile}/registered.log', f'{profile}/final-vrm1.log', f'{profile}/xr-fixture.log'):
        capture(path)
    profiles[profile] = {'kernel_assertions': len(kernel), 'document_assertions': len(document),
                         'native_vrm1_assertions': len(native)-1, 'registered_cases': suite,
                         'native_fixture_sha256': hash_file(work / profile / 'dome-sculpt-vrm1-source-export-test')}

matches = {}
for file in ('xr-fixture/before.dsculpt', 'xr-fixture/after.dsculpt', 'qualified/skin-weight-painted.dsculpt',
             'qualified/skin-weight-painted-editable.vrm', 'qualified/heat-weight-painted-editable.vrm'):
    matches[file] = sha(capture('release/' + file))
    assert hash_file(work / 'asan' / file) == matches[file], file

desktop = load('wayland/report.json')
assert desktop['complete'] and len(desktop['checks']) == 10 and all(x['passed'] for x in desktop['checks'])
assert sha(capture('wayland/pointer-weights.dsculpt')) != matches['xr-fixture/before.dsculpt']
xr = {}
for profile, directory, renderer in (('software', 'release/affine-weight-openxr', 'llvmpipe'),
                                      ('arc', 'arc', 'A770')):
    report = load(f'{directory}/report.json')
    assert not report['physical_headset'] and len(report['checks']) == 7
    cases = {}
    for mode, fixture in (('accept', 'after'), ('focus', 'before')):
        r = load(f'{directory}/{mode}.json')
        assert r['reference_changes'] == 1 and renderer in r['gl_renderer']
        assert r['acquires'] == r['image_waits'] == r['releases'] > 0 and r['stereo_submissions'] > 0
        assert sha(capture(f'{directory}/{mode}.dsculpt')) == matches[f'xr-fixture/{fixture}.dsculpt']
        capture(f'{directory}/{mode}.log')
        if mode == 'focus':
            assert r['focus_losses'] == r['focus_regains'] == 1
        cases[mode] = {'renderer': r['gl_renderer'], 'stereo_frames': r['stereo_submissions'],
                       'swapchain_releases': r['releases'], 'reference_changes': r['reference_changes']}
    xr[profile] = {'checks': len(report['checks']), 'cases': cases}

initial = load('initial-arc-reference.json')
assert initial['reference_changes'] == 1
assert sha(capture('initial-arc-reference.dsculpt')) == matches['xr-fixture/before.dsculpt']
validator = load('khronos.json')
warning_tally = {}
assert len(validator['reports']) == 2
for item in validator['reports']:
    issue = item['report']['issues']
    assert issue['numErrors'] == 0 and issue['numWarnings'] == 8
    warning_tally[item['name']] = dict(Counter(x['code'] for x in issue['messages'] if x['severity'] == 1))
schemas = load('schemas.json')['files']
assert len(schemas) == 2 and all(len(entry['checks']) == 4 and
    not any(check['errors'] for check in entry['checks']) for entry in schemas)

for path in ('receipt.py', 'verify-ui.py', 'wayland-weight.py', 'arc.log', 'wayland.log',
             'wayland/compositor.log', 'wayland/client.log', 'initial-arc-reference.log',
             'release/initial-registered.log', 'release/initial-registered.xml', 'khronos.cjs', 'khronos.log',
             'schemas.log', 'release-configure.log', 'release-exact-build.log', 'release-regeneration.log',
             'release-xr-refresh.log', 'release-baked-fixture-build.log',
             'asan-configure.log', 'asan-final-build.log', 'asan-baked-fixture-build.log'):
    capture(path)

archive = docs / (name + '.tar.gz')
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed, \
        tarfile.open(fileobj=compressed, mode='w|') as tar:
    for path, payload in sorted(members.items()):
        item = tarfile.TarInfo(path)
        item.size = len(payload)
        item.mode = 0o644
        tar.addfile(item, io.BytesIO(payload))
receipt = {
    'revision': revision, 'canonical_domed_revision': canonical,
    'release_fltk': '/opt/fltk-vr/toolkit', 'asan_fltk': 'artifacts/sdk-20261126/toolkit-sanitize',
    'bitmap_runtime': '/opt/fltk-vr/bdf-runtime', 'profiles': profiles,
    'release_application_sha256': hash_file(work / 'release' / 'dome-sculpt'),
    'wayland_assertions': len(desktop['checks']), 'synthetic_openxr': xr, 'physical_headset_tested': False,
    'identical_release_sanitizer_files_sha256': matches,
    'portability': {'khronos': validator['version'], 'khronos_errors_per_file': 0,
                    'khronos_warnings_per_file': warning_tally, 'pinned_schema_checks': 8},
    'archive': {'path': archive.name, 'sha256': hash_file(archive),
                'members_sha256': {key: sha(payload) for key, payload in sorted(members.items())}},
}
(docs / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(archive, archive.stat().st_size)
