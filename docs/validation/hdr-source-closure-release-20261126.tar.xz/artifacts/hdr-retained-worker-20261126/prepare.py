import pathlib,json,hashlib,subprocess,shlex,os,time
ROOT=pathlib.Path('/home/blux/de-xr/dome-sculpt');OLD=ROOT/'artifacts/hdr-provenance-resume-20261126';OSRC=ROOT/'artifacts/source-hdr-provenance-resume-20261126';SRC=ROOT/'artifacts/source-hdr-retained-worker-20261126';OUT=pathlib.Path(__file__).resolve().parent;B=OUT/'release'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
audit=json.loads((OLD/'build-audit.json').read_text());assert audit['exit']==0
pins=json.loads((OLD/'before-inputs.json').read_text())
for k,v in pins.items():assert sha(k)==v['sha256'],'Changed base input '+k
for p in SRC.rglob('*'):
 if p.is_file() and '.git' not in p.parts:pins[str(p)]={'sha256':sha(p),'resolved':str(p.resolve())}
for p,v in json.loads((OLD/'auxiliary-tool-observation.json').read_text())['tools'].items():pins[p]=v
for p in OUT.glob('*.py'):pins[str(p)]={'sha256':sha(p),'resolved':str(p.resolve())}
(OUT/'before-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
cmd=['cmake','-S',str(SRC),'-B',str(B),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DCMAKE_CXX_SCAN_FOR_MODULES=OFF','-DDOME_COMPUTE_BACKEND=CPU','-DDOME_BUILD_UI=OFF','-DDOME_BUILD_XR=OFF','-DBUILD_TESTING=ON']
env=dict(os.environ,PKG_CONFIG_PATH='/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig',LD_LIBRARY_PATH='/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
with (OUT/'configure.log').open('w') as f:subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
objects={};fresh=[];retained=[]
for owner in audit['actual_owners']:
 record=json.loads(pathlib.Path(owner['record']).read_text());obj=owner['object'];reasons=[]
 assert sha(obj)==record['object_sha256'] and sha(owner['actual_md'])==record['depfile_sha256']
 for dep in owner['dependencies']:
  p=pathlib.Path(dep).resolve()
  if p.is_relative_to(OSRC):
   q=SRC/p.relative_to(OSRC)
   if not q.is_file() or sha(p)!=sha(q):reasons.append(str(p))
 if obj.endswith('/src/vroid-creator.cpp.o'):reasons.append('Actual consumer of changed DOME_SCULPT_SOURCE_ASSETS path')
 if reasons:
  command=[x.replace(str(OSRC),str(SRC)).replace(str(OLD/'release'),str(B)) for x in record['command']]
  output=pathlib.Path(command[command.index('-o')+1]);output=output if output.is_absolute() else B/output
  objects[obj]=str(output);fresh.append({'base_object':obj,'base_record':owner['record'],'command':command,'object':str(output),'changed_actual_dependencies':reasons})
 else:objects[obj]=obj;retained.append(owner)
new='dome-sculpt-source-retained-emission-worker-test'
cc=json.loads((B/'compile_commands.json').read_text());c=next(x for x in cc if x['file']==str(SRC/'tests/source-retained-emission-worker.cpp'))
command=shlex.split(c['command']);output=pathlib.Path(command[command.index('-o')+1]);output=output if output.is_absolute() else B/output
fresh.append({'base_object':None,'command':command,'object':str(output),'changed_actual_dependencies':['New whole retained-worker regression TU']})
archives=[];libmap={}
for archive in audit['archives']:
 old=archive['path'];assert sha(old)==archive['sha256'];inputs=[objects[x] for x in archive['whole_object_inputs']]
 if inputs!=archive['whole_object_inputs']:
  path=str(B/pathlib.Path(old).name);archives.append({'path':path,'inputs':inputs,'base_archive':old,'base_sha256':archive['sha256']});libmap[old]=path
 else:libmap[old]=old
links=[]
for link in audit['links']+[{'path':str(B/new),'command':subprocess.check_output(['ninja','-C',str(B),'-t','commands',new],text=True).splitlines()[-1]}]:
 tokens=shlex.split(link['command']);begin=tokens.index('/usr/bin/c++');end=tokens.index('&&',begin) if '&&' in tokens[begin:] else len(tokens);command=tokens[begin:end];target=pathlib.Path(link['path']).name
 for i,x in enumerate(command):
  if i and command[i-1]=='-o':command[i]=str(B/target);continue
  if x.endswith(('.a','.o')):
   old=str((OLD/'release'/x).absolute()) if not pathlib.Path(x).is_absolute() else x
   command[i]=objects.get(old,libmap.get(old,str(B/x) if not pathlib.Path(old).exists() else old))
 links.append({'target':target,'command':command})
plan={'source':subprocess.check_output(['git','-C',str(SRC),'rev-parse','HEAD'],text=True).strip(),'base_source':audit['source'],'base_audit':str(OLD/'build-audit.json'),'base_audit_sha256':sha(OLD/'build-audit.json'),'source_dir':str(SRC),'build_dir':str(B),'fresh':fresh,'retained':retained,'object_map':objects,'archives':archives,'library_map':libmap,'links':links,'prepared':time.time(),'scope':'Whole affected Release TUs plus new worker regression; qualified unchanged native owners retain actual original paths and commands. No App/UI/XR.'}
(OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('fresh',len(fresh),'retained',len(retained),'archives',len(archives),'links',len(links),'source',plan['source'])
