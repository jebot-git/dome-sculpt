import pathlib,json,sys,subprocess,re,hashlib,time,os
O=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/texture-set-recipe-release-20261126');B=O/'release';phase1=sys.argv[1]=='--current';N=O/('native-recipe-v1' if phase1 else 'native-release-legacy-v1')
legacy=None if phase1 else pathlib.Path(sys.argv[1]).absolute();N.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
audit=json.loads((O/'audit-v2.json').read_text());assert audit['exit']==0
pins={k:v['sha256'] for k,v in json.loads((O/'before-inputs-v2.json').read_text()).items()}
for name in ['native-runner.py','prepare-native.py','audit.py','audit-v2.json']:pins[str(O/name)]=sha(O/name)
targets=['dome-sculpt-source-hdr-provenance-closure-test','dome-sculpt-source-joint-writable-normal-bake-test','dome-sculpt-source-owning-hdr-domain-test','dome-sculpt-source-owning-hdr-export-test','dome-sculpt-source-retained-emission-worker-test','dome-sculpt-texture-set-bake-recipe-test'];pending=[B/x for x in targets]+([] if phase1 else [legacy]);scanned=set();resolution=[]
cache={}
for line in subprocess.check_output(['/sbin/ldconfig','-p'],text=True).splitlines():
 m=re.match(r'\s*(\S+)\s+\(.*x86-64.*\)\s+=>\s+(\S+)',line)
 if m:cache.setdefault(m[1],m[2])
while pending:
 p=pending.pop();real=p.resolve()
 if str(real) in scanned:continue
 scanned.add(str(real));pins[str(p)]=pins[str(real)]=sha(real)
 raw=subprocess.check_output(['readelf','-d',str(real)],text=True)
 needed=re.findall(r'\(NEEDED\).*\[(.*?)\]',raw);rpaths=[]
 for r in re.findall(r'\((?:RUNPATH|RPATH)\).*\[(.*?)\]',raw):rpaths+=r.replace('$ORIGIN',str(real.parent)).split(':')
 for name in needed:
  chosen=None
  for parent in ['/opt/fltk-vr/bdf-runtime/lib',*rpaths,'/usr/lib64','/lib64']:
   q=pathlib.Path(parent)/name
   if q.is_file():chosen=q;break
  if chosen is None and name in cache:chosen=pathlib.Path(cache[name])
  assert chosen is not None,'Unresolved DT_NEEDED '+name
  resolution.append({'from':str(real),'needed':name,'literal':str(chosen),'resolved':str(chosen.resolve()),'sha256':sha(chosen)});pending.append(chosen)
 loader=re.search(r'Requesting program interpreter: (.*?)\]',subprocess.check_output(['readelf','-l',str(real)],text=True))
 if loader:pending.append(pathlib.Path(loader[1]))
for tool in ['/usr/bin/ldd','/usr/bin/bash','/usr/bin/readelf']:pins[tool]=pins[str(pathlib.Path(tool).resolve())]=sha(tool)
old512=N/'legacy512';old2048=N/'legacy2048';new2048=N/'current2048';new512=N/'current512';closure=N/'closure';owner=N/'owner';export=N/'export'
def case(name,cmd,checks=None,produces=(),consumes=(),**extra):
 return {'name':name,'command':[str(x) for x in cmd],'checks':checks,'produces':[str(x) for x in produces],'consumes_generated':[str(x) for x in consumes],'timeout':900,'RSS_limit_bytes':4*1024**3,**extra}
joint=B/'dome-sculpt-source-joint-writable-normal-bake-test'
worker_input=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/hdr-provenance-resume-20261126/native-release-legacy-v1/legacy2048/selected-target-resolution.dsculpt')
pins[str(worker_input)]=sha(worker_input)
legacy_seed=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/hdr-provenance-resume-20261126/native-release-legacy-v1/legacy512/000.dsculpt')
pins[str(legacy_seed)]=sha(legacy_seed)
current_cases=[case('recipe20',[B/'dome-sculpt-texture-set-bake-recipe-test',N/'recipe'],20),case('closure22',[B/'dome-sculpt-source-hdr-provenance-closure-test',worker_input,legacy_seed,N/'closure'],22)]
legacy_cases=[] if phase1 else [case('legacy512',[legacy,'--checked-case','000','512',old512],47409,[old512/'000.dsculpt']),case('legacy2048-refusal',[legacy,'--checked-case','000','2048',old2048],None,[old2048/'selected-target-resolution.dsculpt'],expected_exit=1,expected_text='Retained emission before-raster exceeds prospective budget'),case('closure22',[B/'dome-sculpt-source-hdr-provenance-closure-test',old2048/'selected-target-resolution.dsculpt',old512/'000.dsculpt',closure],22,[],[old2048/'selected-target-resolution.dsculpt',old512/'000.dsculpt'])]
cases=current_cases if phase1 else legacy_cases
ldd=[]
for p in ([] if phase1 else [legacy])+[B/x for x in targets]:ldd.append(case('loader-'+p.name+('-old' if p==legacy else ''),['/usr/bin/ldd',p],None,loader=True,timeout=60))
plan={'scope':('Actual plain per-field Scene40 recipes, real oldScene43 replay and nested HDR source dependency closure; native-only R scope, no App/public acceptance' if phase1 else 'Actual05 old512 producer and2048 refusal, then514 dependency closure and byte-exact oldScene43 replay; native-only R scope'),'source':'1815e5fcd2418ad0cca20e6d517d08c4c3f891cf','legacy_binary':str(legacy),'pins':pins,'dynamic_resolution':resolution,'cwd':str(O),'environment':{'PATH':'/usr/bin:/bin','LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'},'cases':ldd+cases,'strict':False,'prepared':time.time()}
(N/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('ready',N,'pins',len(pins),'cases',len(cases),'providers',len(scanned))
