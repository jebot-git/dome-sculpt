import pathlib,json,subprocess,hashlib,shlex,time
O=pathlib.Path(__file__).resolve().parent;P=json.loads((O/'plan-v2.json').read_text());B=pathlib.Path(P['build_dir']);base=json.loads(pathlib.Path(P['base_audit']).read_text());pins=json.loads((O/'before-inputs-v2.json').read_text());errors=[];fresh=[];objects={};all_deps=set()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
for old in P['retained']:
 r=json.loads(pathlib.Path(old['record']).read_text());path=old['object'];assert sha(path)==r['object_sha256'] and sha(old['actual_md'])==r['depfile_sha256'];objects[path]=r
for path in sorted((O/'compiler-records-v2').glob('*.json')):
 r=json.loads(path.read_text());obj=pathlib.Path(r['object']);md=pathlib.Path(r['depfile']);assert r['exit']==0 and sha(obj)==r['object_sha256'] and sha(md)==r['depfile_sha256'];deps=[]
 for word in shlex.split(md.read_text().replace('\\\n',' ').split(':',1)[1]):
  if word.endswith(':'):continue
  p=pathlib.Path(word);p=p if p.is_absolute() else B/p;p=p.absolute();key=str(p) if str(p) in pins else str(p.resolve());all_deps.add(str(p));deps.append(str(p))
  if key not in pins:errors.append('Unknown actual dependency '+str(p))
  elif sha(p)!=pins[key]['sha256']:errors.append('Changed actual dependency '+str(p))
 objects[str(obj)]=r;fresh.append({'record':str(path),'object':str(obj),'actual_MD':str(md),'dependencies':deps})
assert len(fresh)==len(P['fresh'])
archives=[]
for archive in base['archives']:
 actual=P['library_map'][archive['path']];inputs=next((x['inputs'] for x in P['archives'] if x['path']==actual),archive['whole_object_inputs']);members=subprocess.check_output(['ar','t',actual],text=True).splitlines()
 if members!=[pathlib.Path(x).name for x in inputs]:errors.append('Actual writer/member mismatch '+actual)
 for member,obj in zip(members,inputs):
  h=hashlib.sha256(subprocess.check_output(['ar','p',actual,member])).hexdigest()
  if obj not in objects or h!=objects[obj]['object_sha256']:errors.append('Actual archive/compiler mismatch '+actual+':'+member)
 archives.append({'path':actual,'sha256':sha(actual),'members':members,'inputs':inputs,'reused_original_archive':actual==archive['path']})
links=[]
for link in P['links']:
 path=B/link['target'];inputs=[]
 for arg in link['command']:
  if arg.endswith(('.o','.a','.so')) or '.so.' in arg:
   p=pathlib.Path(arg);p=p if p.is_absolute() else B/p
   if p.is_file():inputs.append({'path':str(p),'sha256':sha(p)})
 links.append({'target':link['target'],'path':str(path),'sha256':sha(path),'actual_command':link['command'],'inputs':inputs,'DT_NEEDED':subprocess.check_output(['readelf','-d',str(path)],text=True)})
result={'exit':int(bool(errors)),'errors':errors,'source':P['source'],'base_source':P['base_source'],'scope':P['scope'],'fresh_TUs':len(fresh),'qualified_unchanged_TUs':len(P['retained']),'unique_current_TUs':len(fresh)+len(P['retained']),'actual_fresh_dependencies':len(all_deps),'fresh_owners':fresh,'archives':archives,'links':links,'observed':time.time()};(O/'audit-v2.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['fresh_owners','archives','links']},indent=2));raise SystemExit(result['exit'])
