import pathlib,json,subprocess,concurrent.futures,time,os
O=pathlib.Path(__file__).resolve().parent;P=json.loads((O/'plan.json').read_text());B=pathlib.Path(P['build_dir']);start=time.time();S={'terminal':False,'source':P['source'],'start':start,'steps':[]};(O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def save():(O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def compile_one(item):
 command=item['command'];obj=pathlib.Path(item['object']);obj.parent.mkdir(parents=True,exist_ok=True)
 if '-MF' not in command:command=command+['-MD','-MF',str(obj)+'.d']
 t=time.time();r=subprocess.run(['/usr/bin/python3',str(O/'compiler.py'),*command],cwd=B)
 return {'kind':'whole-TU','object':str(obj),'exit':r.returncode,'seconds':time.time()-t}
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for result in pool.map(compile_one,P['fresh']):S['steps'].append(result);save();assert result['exit']==0
 for archive in P['archives']:
  path=pathlib.Path(archive['path']);assert not path.exists(),'Do not overwrite previously staged archive'
  command=['/usr/bin/ar','qc',str(path),*archive['inputs']];t=time.time();subprocess.run(command,check=True);subprocess.run(['/usr/bin/ranlib',str(path)],check=True)
  S['steps'].append({'kind':'archive','command':command,'exit':0,'seconds':time.time()-t});save()
 for link in P['links']:
  t=time.time();command=link['command'];log=O/(link['target']+'.link.log')
  for x in command:
   if x.startswith('-Wl,--dependency-file='):(B/pathlib.Path(x.split('=',1)[1])).parent.mkdir(parents=True,exist_ok=True)
  with log.open('w') as f:r=subprocess.run(command,cwd=B,stdout=f,stderr=subprocess.STDOUT)
  S['steps'].append({'kind':'link','target':link['target'],'command':command,'exit':r.returncode,'seconds':time.time()-t});save();assert r.returncode==0
 S['exit']=0
except BaseException as e:S.update(exit=1,error=repr(e))
S.update(terminal=True,seconds=time.time()-start);save();print(json.dumps(S),flush=True);raise SystemExit(S['exit'])
