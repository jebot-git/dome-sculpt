import pathlib,json,sys,subprocess,re,hashlib,time,os
O=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/hdr-provenance-resume-20261126');B=O/'release';phase1=sys.argv[1]=='--current';N=O/('native-release-current-v1' if phase1 else 'native-release-legacy-v1')
legacy=None if phase1 else pathlib.Path(sys.argv[1]).absolute();N.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
audit=json.loads((O/'build-audit.json').read_text());assert audit['exit']==0
pins={k:v['sha256'] for k,v in json.loads((O/'before-inputs.json').read_text()).items()}
for name in ['native-runner.py','prepare-native.py','audit.py','build-audit.json']:pins[str(O/name)]=sha(O/name)
targets=['dome-sculpt-source-hdr-provenance-closure-test','dome-sculpt-source-joint-writable-normal-bake-test','dome-sculpt-source-owning-hdr-domain-test','dome-sculpt-source-owning-hdr-export-test'];pending=[B/x for x in targets]+([] if phase1 else [legacy]);scanned=set();resolution=[]
cache={}
for line in subprocess.check_output(['/sbin/ldconfig','-p'],text=True).splitlines():
 m=re.match(r'\s*(\S+)\s+\(.*x86-64.*\)\s+=>\s+(\S+)',line)
 if m:cache.setdefault(m[1],m[2])
while pending:
 p=pending.pop();real=p.resolve()
 if str(real) in scanned:continue
 scanned.add(str(real));pins[str(p)]=pins[str(real)]=sha(real)
 raw=subprocess.check_output(['readelf','-d',str(real)],text=True)
 needed=re.findall(r'\(NEEDED\).*\[(.*?)\]',raw);rpaths=[]
 for r in re.findall(r'\((?:RUNPATH|RPATH)\).*\[(.*?)\]',raw):rpaths+=r.replace('$ORIGIN',str(real.parent)).split(':')
 for name in needed:
  chosen=None
  for parent in ['/opt/fltk-vr/bdf-runtime/lib',*rpaths,'/usr/lib64','/lib64']:
   q=pathlib.Path(parent)/name
   if q.is_file():chosen=q;break
  if chosen is None and name in cache:chosen=pathlib.Path(cache[name])
  assert chosen is not None,'Unresolved DT_NEEDED '+name
  resolution.append({'from':str(real),'needed':name,'literal':str(chosen),'resolved':str(chosen.resolve()),'sha256':sha(chosen)});pending.append(chosen)
 loader=re.search(r'Requesting program interpreter: (.*?)\]',subprocess.check_output(['readelf','-l',str(real)],text=True))
 if loader:pending.append(pathlib.Path(loader[1]))
for tool in ['/usr/bin/ldd','/usr/bin/bash','/usr/bin/readelf']:pins[tool]=pins[str(pathlib.Path(tool).resolve())]=sha(tool)
old512=N/'legacy512';old2048=N/'legacy2048';new2048=N/'current2048';new512=N/'current512';closure=N/'closure';owner=N/'owner';export=N/'export'
def case(name,cmd,checks=None,produces=(),consumes=(),**extra):
 return {'name':name,'command':[str(x) for x in cmd],'checks':checks,'produces':[str(x) for x in produces],'consumes_generated':[str(x) for x in consumes],'timeout':900,'RSS_limit_bytes':4*1024**3,**extra}
joint=B/'dome-sculpt-source-joint-writable-normal-bake-test'
current_cases=[case('current2048',[joint,'--checked-case','000','2048',new2048],47409,[new2048/'000.dsculpt',new2048/'selected-target-resolution.dsculpt']),case('current512',[joint,'--checked-case','000','512',new512],47409,[new512/'000.dsculpt']),case('owner24',[B/'dome-sculpt-source-owning-hdr-domain-test',new512/'000.dsculpt',owner],24,[],[new512/'000.dsculpt']),case('export16400',[B/'dome-sculpt-source-owning-hdr-export-test',new512/'000.dsculpt',export],16400,[],[new512/'000.dsculpt'])]
legacy_cases=[] if phase1 else [case('legacy512',[legacy,'--checked-case','000','512',old512],47409,[old512/'000.dsculpt']),case('legacy2048-refusal',[legacy,'--checked-case','000','2048',old2048],None,[old2048/'selected-target-resolution.dsculpt'],expected_exit=1,expected_text='Retained emission before-raster exceeds prospective budget'),case('closure22',[B/'dome-sculpt-source-hdr-provenance-closure-test',old2048/'selected-target-resolution.dsculpt',old512/'000.dsculpt',closure],22,[],[old2048/'selected-target-resolution.dsculpt',old512/'000.dsculpt'])]
cases=current_cases if phase1 else legacy_cases
ldd=[]
for p in ([] if phase1 else [legacy])+[B/x for x in targets]:ldd.append(case('loader-'+p.name+('-old' if p==legacy else ''),['/usr/bin/ldd',p],None,loader=True,timeout=60))
plan={'scope':('Current514 source64 versus2048 and512 targets, owning controls and export; native-only R scope, no legacy/App/public acceptance' if phase1 else 'Actual05 old512 producer and2048 refusal, then514 dependency closure and byte-exact oldScene43 replay; native-only R scope'),'source':'51488b3c0d0c1bfdef0c6a06645f1a01b8e8e70b','legacy_binary':str(legacy),'pins':pins,'dynamic_resolution':resolution,'cwd':str(O),'environment':{'PATH':'/usr/bin:/bin','LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'},'cases':ldd+cases,'strict':False,'prepared':time.time()}
(N/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('ready',N,'pins',len(pins),'cases',len(cases),'providers',len(scanned))
