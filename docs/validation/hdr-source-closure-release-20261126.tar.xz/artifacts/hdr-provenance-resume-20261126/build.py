import pathlib,json,subprocess,os,time,hashlib
OUT=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/hdr-provenance-resume-20261126');BUILD=OUT/'release'
targets=['dome-sculpt-source-hdr-provenance-closure-test','dome-sculpt-source-joint-writable-normal-bake-test','dome-sculpt-source-owning-hdr-domain-test','dome-sculpt-source-owning-hdr-export-test']
env=dict(os.environ,PKG_CONFIG_PATH='/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig',LD_LIBRARY_PATH='/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
cmd=['ninja','-C',str(BUILD),'-d','keepdepfile','-d','keeprsp','-j2','-v',*targets]
status={'terminal':False,'source':'51488b3c0d0c1bfdef0c6a06645f1a01b8e8e70b','command':cmd,'started':time.time(),'scope':'Fresh Release native core/support and four selected HDR fixture executables; no App/UI/XR'}
(OUT/'build-status.json').write_text(json.dumps(status,indent=2)+'\n')
with (OUT/'build.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
status.update(terminal=True,exit=r.returncode,seconds=time.time()-status['started'])
(OUT/'build-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status),flush=True)
raise SystemExit(r.returncode)
