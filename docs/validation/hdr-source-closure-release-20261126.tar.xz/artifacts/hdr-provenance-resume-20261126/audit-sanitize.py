import pathlib,json,hashlib,subprocess,shlex,os,time
OUT=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/hdr-provenance-resume-20261126');B=OUT/'sanitize'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
pins=json.loads((OUT/'before-inputs.json').read_text());errors=[];deps={};objects={};owners=[];derived={}
for record in sorted((OUT/'sanitize-compiler-records').glob('*.json')):
 r=json.loads(record.read_text());obj=pathlib.Path(r['object']);dep=pathlib.Path(r['depfile']);
 if r['exit'] or not obj.is_file() or sha(obj)!=r['object_sha256']:errors.append('Object/compiler failure '+str(obj))
 if not dep.is_file() or sha(dep)!=r['depfile_sha256']:errors.append('Actual MD missing/drift '+str(dep));continue
 text=dep.read_text().replace('\\\n',' '); dependency_text=text.split(':',1)[1]; words=shlex.split(dependency_text)
 actual=[]
 for word in words:
  if word.endswith(':'):continue
  path=pathlib.Path(word);path=(B/path).absolute() if not path.is_absolute() else path
  key=str(path);resolved=str(path.resolve())
  if key not in pins and resolved in pins:key=resolved
  digest=sha(path)
  if key in pins:
   if pins[key]['sha256']!=digest:errors.append('Changed prospective input '+str(path))
  elif path==B/'armorpaint-blur-generated/blur_weights.hpp':
   derived[str(path)]={'sha256':digest,'generator':'cmake/armorpaint-blur-weights.cmake + experiments/armorpaint-blur/vendor/make_blur.c, both prospective source pins'}
  else:errors.append('Unknown actual dependency '+str(path))
  deps[str(path)]=digest;actual.append(str(path))
 objects[str(obj)]=r;owners.append({'object':str(obj),'record':str(record),'actual_md':str(dep),'dependencies':actual})
archives=[]
for lib in sorted(B.glob('*.a')):
 raw=subprocess.check_output(['ninja','-C',str(B),'-t','commands',lib.name],text=True)
 command=raw.splitlines()[-1];args=shlex.split(command);i=next(i for i,x in enumerate(args) if x=='/usr/bin/ar');j=args.index('&&',i) if '&&' in args[i:] else len(args);chunk=args[i:j]
 if chunk[1]!='qc':errors.append('Unexpected ar mode '+str(lib));continue
 written=[str((B/pathlib.Path(x)).absolute()) for x in chunk[3:]]
 members=subprocess.check_output(['ar','t',str(lib)],text=True).splitlines()
 if members!=[pathlib.Path(x).name for x in written]:errors.append('Archive member/writer mismatch '+str(lib))
 for member,obj in zip(members,written):
  data=subprocess.check_output(['ar','p',str(lib),member]);h=hashlib.sha256(data).hexdigest()
  if obj not in objects or h!=objects[obj].get('object_sha256'):errors.append('Archive payload/compiler mismatch '+str(lib)+':'+member)
 archives.append({'path':str(lib),'sha256':sha(lib),'writer_command':command,'actual_members':members,'whole_object_inputs':written})
targets=['dome-sculpt-source-hdr-provenance-closure-test','dome-sculpt-source-joint-writable-normal-bake-test','dome-sculpt-source-owning-hdr-domain-test','dome-sculpt-source-owning-hdr-export-test']
links=[]
for target in targets:
 raw=subprocess.check_output(['ninja','-C',str(B),'-t','commands',target],text=True);command=raw.splitlines()[-1];args=shlex.split(command);inputs=[]
 for x in args:
  if x.endswith(('.a','.o','.so')) or '.so.' in x:
   p=pathlib.Path(x);p=p if p.is_absolute() else B/p
   if p.is_file():inputs.append({'path':str(p),'sha256':sha(p)})
 links.append({'path':str(B/target),'sha256':sha(B/target),'command':command,'actual_link_inputs':inputs,'dynamic':subprocess.check_output(['readelf','-d',str(B/target)],text=True)})
result={'exit':int(bool(errors)),'errors':errors,'source':'51488b3c0d0c1bfdef0c6a06645f1a01b8e8e70b','scope':'Strict ASan/UBSan native-only fresh selected4; no FLTK/UI/App qualification','actual_owners':owners,'owner_count':len(owners),'actual_dependency_paths':len(deps),'derived':derived,'archives':archives,'links':links,'observed':time.time()}
(OUT/'sanitize-build-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['actual_owners','archives','links']},indent=2));raise SystemExit(result['exit'])
