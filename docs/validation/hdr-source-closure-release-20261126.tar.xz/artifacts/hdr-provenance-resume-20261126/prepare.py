import pathlib,os,json,hashlib,subprocess,time
ROOT=pathlib.Path('/home/blux/de-xr/dome-sculpt')
SOURCE=ROOT/'artifacts/source-hdr-provenance-resume-20261126'
OUT=ROOT/'artifacts/hdr-provenance-resume-20261126'
BUILD=OUT/'release'
def digest(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
paths=set()
for base in [SOURCE,'/usr/include','/usr/lib/gcc','/opt/fltk-vr/bdf-runtime/include','/usr/lib64/pkgconfig','/usr/share/pkgconfig','/opt/fltk-vr/bdf-runtime/lib/pkgconfig']:
 for p in pathlib.Path(base).rglob('*'):
  if p.is_file() and '.git' not in p.parts:paths.add(p)
for name in ['c++','cc','gcc','cmake','ninja','pkg-config','ar','ranlib','ld','as','readelf']:
 p=pathlib.Path(subprocess.check_output(['which',name],text=True).strip());paths.add(p);paths.add(p.resolve())
for pat in ['libstdc++*','libgcc*','libOpenEXR*','libIlmThread*','libIex*','libImath*','libpng*','libjpeg*','libz.so*','liblapack*','libblas*','libc.so*','libm.so*','libpthread*','libEGL*','libGL*','libOpenGL*','ld-linux*']:
 paths.update(p for p in pathlib.Path('/usr/lib64').glob(pat) if p.is_file())
pins={str(p):{'sha256':digest(p),'resolved':str(p.resolve())} for p in sorted(paths)}
(OUT/'before-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
env=dict(os.environ,PKG_CONFIG_PATH='/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig',LD_LIBRARY_PATH='/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
cmd=['cmake','-S',str(SOURCE),'-B',str(BUILD),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_COMPUTE_BACKEND=CPU','-DDOME_BUILD_UI=OFF','-DDOME_BUILD_XR=OFF','-DBUILD_TESTING=ON']
start=time.time()
with (OUT/'configure.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(OUT/'configure.json').write_text(json.dumps({'command':cmd,'cwd':str(ROOT),'source':subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),'start':start,'exit':r.returncode,'seconds':time.time()-start,'before_pin_count':len(pins),'scope':'Fresh optimized native-only selected HDR fixtures; no App, UI, XR, FLTK or historical binary reuse'},indent=2)+'\n')
print('configure',r.returncode,'pins',len(pins),flush=True)
raise SystemExit(r.returncode)
