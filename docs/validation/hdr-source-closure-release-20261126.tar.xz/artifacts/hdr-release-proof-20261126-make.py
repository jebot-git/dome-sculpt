import pathlib,json,hashlib,time,tarfile,lzma
R=pathlib.Path('/home/blux/de-xr/dome-sculpt');A=R/'artifacts';W=A/'hdr-release-proof-20261126';D=W/'docs/validation';D.mkdir(exist_ok=True);files=set()
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def add(p):
 p=pathlib.Path(p)
 if p.is_file():files.add(p)
def metadata(o):
 for p in o.iterdir():
  if p.is_file() and p.suffix in ['.json','.py','.log','.txt']:add(p)
 for p in (o/'compiler-records').glob('*'):add(p)
def native(o):
 metadata(o)
 for p in o.glob('*.maps'):add(p)
 # record complete output inventory, preserving actual data in original run only.
 return [{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(o.rglob('*')) if p.is_file() and p.suffix in ['.dsculpt','.glb','.png','.exr']]
stages=['hdr-provenance-resume-20261126','hdr-retained-worker-20261126','texture-set-recipe-release-20261126','hdr-projection-sharing-release-20261126','hdr-projection-fixture-build-20261126']
for name in stages:metadata(A/name)
# Preserve actual original owner records/MD for honest qualified unchanged R provenance.
p=json.loads((A/stages[-2]/'plan.json').read_text())
records=[pathlib.Path(x['record']) for x in p['retained']]+list((A/stages[-2]/'compiler-records').glob('*.json'))
for f in records:
 add(f);r=json.loads(f.read_text());add(r['depfile']);add(pathlib.Path(r['depfile']).with_suffix('.log'))
for f in (A/'hdr-projection-fixture-build-20261126/compiler-records').glob('*.json'):
 r=json.loads(f.read_text());add(r.get('depfile','/nonexistent'))
outputs={}
for name,sub in [('hdr-provenance-resume-20261126','native-release-current-v1'),('hdr-provenance-resume-20261126','native-release-legacy-v1'),('hdr-retained-worker-20261126','native-release-current-v1'),('texture-set-recipe-release-20261126','native-release-current-v1'),('hdr-projection-sharing-release-20261126','native-release-current-v1'),('hdr-projection-sharing-release-20261126','native-release-current-v2'),('hdr-projection-fixture-build-20261126','native-release-v1'),('hdr-projection-fixture-build-20261126','native-sanitize-v1')]:
 d=A/name/sub
 if d.exists():outputs[str(d.relative_to(R))]=native(d)
metadata(A/'hdr-khronos-validation-20261126')
for packed in (A/'hdr-khronos-validation-20261126').glob('*.tgz'):add(packed)
add(A/'hdr-khronos-validation-20261126/validate.cjs')
add(A/'hdr-release-proof-20261126-make.py')
status=json.loads((A/'hdr-projection-sharing-release-20261126/native-release-current-v2/status.json').read_text());assert status['terminal'] and status['exit']==0 and not status['owned'] and not status['drift']
projection={}
for profile in ['release','sanitize']:
 d=json.loads((A/'hdr-projection-fixture-build-20261126'/('native-'+profile+'-v1')/'status.json').read_text());assert d['exit']==0 and d['terminal'] and not d['owned'];projection[profile]=d
inventory=[{'path':str(f.relative_to(R)),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(files)]
archive=D/'hdr-source-closure-release-20261126.tar.xz'
with lzma.open(archive,'wb',preset=6) as out:
 with tarfile.open(fileobj=out,mode='w|') as t:
  for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
receipt={'scope':'Scoped native Release725 component111306 plus separate corrected R11 and strict11 fixture; not complete strict/App/public/device admission','product_source':'725ea10032981e28c7edb0c1ffdd5689e4a3ad32','projection_fixture_source':'a4d0bfde','projection_src_include_exact_product':True,'native_unit':'ds-hdr-projection-sharing-native-cpu-v2-20261126.service','invocation':'2add12f0984f4773abf788da46773c89','positive_checks_main':111306,'positive_checks_corrected_projection_release':11,'positive_checks_corrected_projection_strict':11,'status':status,'projection':projection,'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'authorities':inventory},'outputs_preserved_at_original_paths':outputs,'limitations':['All Nov26 builds reconstructed; no reuse/relabel of absent Nov18 binaries.','Initial Release cc1/cc1plus/collect2 supplemental observation is post-start, not prospectively pinned for earlier owners.','Original failed181 recipe fixture raw .d was overwritten by corrected successful TU before snapshot; exact original SHA/log/source/command/status retained; currentMD used only for successful owner.','Frozen725 original projection fixture setup refusal preserved; a4 supplies genuine N/T/sourceUV without product change.','Full strict725 native cohort is a separately pending run; corrected strict11 alone is not full strict acceptance.','CPU-only jobs never acquire graphics lease; actual noDRI/Mesa sampled, linked OpenGL/EGL libraries can be mapped without device/context.'],'created':time.time()}
(D/'hdr-source-closure-release-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n');print('archive',archive.stat().st_size,'authorities',len(files),'outputs',sum(map(len,outputs.values())))
