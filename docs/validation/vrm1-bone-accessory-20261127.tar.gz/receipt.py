from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert revision.startswith("b1de72a6")
canonical = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo.parent / "DomeD", text=True).strip()
archive_dir = repo / "docs" / "validation"
files = {}

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def capture(path):
    raw = path.read_bytes()
    files[str(path.relative_to(work))] = raw
    return raw

def parse(path):
    return json.loads(capture(path))

def glb(path):
    raw = path.read_bytes()
    magic, version, size, length, kind = struct.unpack_from("<5I", raw)
    assert (magic, version, size, kind) == (0x46546C67, 2, len(raw), 0x4E4F534A)
    return json.loads(raw[20:20+length])

profiles = {}
for profile, case_count in [("release", 7), ("asan", 4)]:
    directory = work / profile
    native = capture(directory / "bone.log").decode()
    assert len(re.findall(r"^PASS ", native, re.M)) == 40
    assert "PASS native VRM1 bone accessory workflow" in native
    for witness in ("A non-rendered source joint gains its actual missing placement chain",
                    "Reattaching to the same bone adds no history entry",
                    "A locked attached mesh refuses the whole linked pose",
                    "A linked pose uses the fitted head's actual pivot"):
        assert witness in native
    assert native.count("Portable accessory is a real child of the posed head") == 4
    assert native.count("Fitted export restores the exact current and first-rest owners") == 2
    for name in ("build.log", "verification-build.log", "configure.log", "registered.log",
                 "registered.xml", "compile_commands.json"):
        capture(directory / name)
    cases = ET.parse(directory / "registered.xml").getroot().findall(".//testcase")
    assert len(cases) == case_count and all(
        case.find("failure") is None and case.find("skipped") is None for case in cases
    )
    profiles[profile] = {
        "focused_assertions": 39,
        "registered": [case.attrib["name"] for case in cases],
        "test_sha256": sha(directory / "dome-sculpt-vrm1-source-export-test"),
        "core_sha256": sha(directory / "libdome-sculpt-core.a")
    }
    if profile == "release":
        profiles[profile]["app_sha256"] = sha(directory / "dome-sculpt")
        profiles[profile]["synthetic_openxr_runtime"] = sha(directory / "libdome-sculpt-test-runtime.so")
    else:
        assert b"VRM1 native texture set: 31 checks" in capture(directory / "previous-accessory.log")

native_names = ["pre-attach.dsculpt", "default-bone.dsculpt", "head-attached.dsculpt", "head-posed.dsculpt"]
vrm_names = ["head-source-only.vrm", "head-standard.vrm", "head-editable.vrm", "fitted-standard.vrm", "fitted-editable.vrm"]
products = {}
for name in native_names + vrm_names:
    products[name] = sha(work / "release" / "bone" / name)
    assert products[name] == sha(work / "asan" / "bone" / name)
wayland_path = work / "release-wayland"
wayland = parse(wayland_path / "report.json")
assert len(wayland["checks"]) == 8 and wayland["complete"] and all(case["passed"] for case in wayland["checks"])
assert sha(wayland_path / "attached.dsculpt") == products["default-bone.dsculpt"]
reports = {"wayland": {"checks": 8, "saved_scene": products["default-bone.dsculpt"]}}
for mode, renderer in [("software", "llvmpipe"), ("arc", "Arc(tm) A770")]:
    folder = work / f"xr-{mode}"
    runtime = parse(folder / "runtime.json")
    assert renderer in runtime["gl_renderer"]
    assert runtime["acquires"] == runtime["image_waits"] == runtime["releases"] > 0
    assert all(runtime["editable_avatar_images"]["13"][eye] > 1000 for eye in ("0", "1"))
    assert sha(folder / "screen-export.vrm") == products["head-editable.vrm"]
    assert sha(folder / "final.dsculpt") == products["head-posed.dsculpt"]
    assert b"PASS five native OpenXR accessory export checks" in capture(work / f"xr-{mode}.log")
    reports[f"xr-{mode}"] = {"checks": 5, "renderer": runtime["gl_renderer"],
                             "physical_headset": False, "releases": runtime["releases"]}

def warnings(result):
    fmt = glb(work / "release" / "bone" / result["name"])
    notices = Counter()
    for item in result["report"]["issues"]["messages"]:
        if item["severity"] != 1:
            continue
        _, table, index, *_ = item["pointer"].split("/")
        key = (item["code"], table, fmt[table][int(index)].get("name", ""))
        notices[key] += 1
    return notices

khronos = parse(work / "khronos.json")
assert [item["name"] for item in khronos["reports"]] == vrm_names
baseline = warnings(khronos["reports"][0])
assert sum(baseline.values()) == 7
assert all(row["report"]["issues"]["numErrors"] == 0 and warnings(row) == baseline for row in khronos["reports"])
schemas = parse(work / "schemas.json")
checks = [item for row in schemas["files"] for item in row["checks"]]
assert len(checks) == 23 and not any(item["errors"] for item in checks) and not schemas["schema_drift"]
cold = {}
for state in ("head", "fitted"):
    cold[state] = sha(work / f"cold-{state}-standard.glb")
    assert cold[state] == sha(work / f"cold-{state}-editable.glb")
for name in ("cold-reopen.log", "release/bone-fixture-archive-context.log", "release/fixture-refresh.log",
             "release/fixture-fitted-build.log", "release-wayland.log", "wayland-bone.py",
             "ui.py", "xr-bone.py", "khronos.cjs", "khronos.log", "schemas.log", "receipt.py"):
    capture(work / name)
combined = work.parent / "portable-mtoon-bake-20261127" / "combined-release"
earlier = json.loads((combined / "status.json").read_text())
run_log = (combined / "ctest.log").read_text()
earlier["observed_passes"] = len(re.findall(r"\. +Passed +\d", run_log))
earlier["observed_reported_failures"] = len(re.findall(r"\*\*\*(?:Failed|Timeout|Exception)", run_log))
files["previous-combined-release-status.json"] = json.dumps(earlier, indent=2).encode()
payload = archive_dir / f"{work.name}.tar.gz"
with payload.open("wb") as stream, gzip.GzipFile(fileobj=stream, filename="", mode="wb", mtime=0) as encoded:
    with tarfile.open(fileobj=encoded, mode="w") as bundle:
        for name, raw in sorted(files.items()):
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(raw), 0o644
            bundle.addfile(member, io.BytesIO(raw))
archive_hashes = {name: digest(raw) for name, raw in files.items()}
with tarfile.open(payload) as bundle:
    assert {member.name: digest(bundle.extractfile(member).read()) for member in bundle.getmembers()} == archive_hashes
receipt = {
    "product_revision": revision, "canonical_domed_revision": canonical, "profiles": profiles,
    "matching_fixture_outputs": products, "runtime_paths": reports,
    "interop": {
        "khronos_version": khronos["version"], "khronos_files": len(vrm_names),
        "khronos_errors": 0, "pinned_schema_checks": len(checks),
        "source_only_warning_control": [
            {"code": code, "table": table, "owner_name": name, "count": count}
            for (code, table, name), count in sorted(baseline.items())
        ],
        "added_khronos_warnings": 0, "identical_cold_open_glb_outputs": cold
    },
    "earlier_combined_release": earlier,
    "scope": "Rigged imported VRM 1.0 with a native rigid painted texture-set bone attachment, including fitted source poses.",
    "archive": {"filename": payload.name, "sha256": sha(payload), "members": archive_hashes}
}
(archive_dir / f"{work.name}.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n")
print("Verified", len(files), "evidence files and", len(products), "matching outputs")
