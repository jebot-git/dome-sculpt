const fs = require('fs');
const path = require('path');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
(async () => {
  const reports = [];
  const files = ['head-source-only.vrm','head-standard.vrm','head-editable.vrm','fitted-standard.vrm','fitted-editable.vrm'];
  for (const name of files) {
    const input = fs.readFileSync(path.join(__dirname,'release','bone',name));
    const report = await validator.validateBytes(input,{uri:name,maxIssues:10000});
    reports.push({name,report});
    console.log(name,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings');
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),reports},null,2)+'\n');
  if (reports.some(item=>item.report.issues.numErrors)) process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1});
