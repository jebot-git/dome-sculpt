// SPDX-License-Identifier: GPL-3.0-or-later
// Separate observation of ordinary creation and actual public canvas anchoring.
// It does not change the preservation-stress fixture or any application camera.
#include "dome/document.hpp"
#include "dome/creation.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <cmath>
#include <iostream>
#include <map>
#include <limits>
using namespace dome;
using Json=nlohmann::json;
struct Extent {
  std::array<double,3> lo{INFINITY,INFINITY,INFINITY},hi{-INFINITY,-INFINITY,-INFINITY};
  size_t vertices=0,inside_vertical=0,behind_eye=0;
};
int main(int argc,char**argv)try{
  if(argc!=4)throw std::invalid_argument("usage: default-creator-probe --native-default|--inspect PROJECT REPORT");
  Document doc;
  if(std::string_view(argv[1])=="--native-default"){
    doc.replace(Scene{});
    doc.create_humanoid_avatar(humanoid_baseline_defaults("vroid-beta-female"),"Default avatar",{},false);
    if(!doc.wait_asset(std::chrono::seconds(60)))throw std::runtime_error("Default creator worker did not settle");
    const auto f=doc.frame();if(!f.state->error.empty())throw std::runtime_error(f.state->error);
    doc.save_async(argv[2]).get();
  }else if(std::string_view(argv[1])=="--inspect")doc.replace(Scene::load(argv[2]));
  else throw std::invalid_argument("Unknown observation mode");
  if(!doc.wait_mesh(std::chrono::seconds(60)))throw std::runtime_error("Real model preview did not settle");
  doc.begin_spatial();SpatialFrame input;input.time=1;input.focused=input.head_valid=true;input.head.position={0,1.6f,0};doc.submit(input);
  if(!doc.wait_input(std::chrono::seconds(10)))throw std::runtime_error("Real spatial anchoring did not settle");
  const auto state=doc.frame().state;const auto scene=doc.copy_scene();const auto canvas=state->canvas;
  Json result{{"scope","Geometry/frustum observation with real default Document anchoring; not visual or physical-HMD acceptance"},{"head",{0,1.6,0}},{"canvas_position",{canvas.position.x,canvas.position.y,canvas.position.z}},{"canvas_scale",canvas.scale},{"canvas_orientation",{canvas.orientation.x,canvas.orientation.y,canvas.orientation.z,canvas.orientation.w}},{"groups",Json::array()}};
  std::map<uint64_t,Extent> extents;
  for(const auto&surface:scene.preview_surfaces()){
    const auto mesh=surface.preview_mesh();const auto world=surface.world_matrix();auto&bounds=extents[scene.object(surface.id).group];
    for(const auto&p:mesh.positions){
      const auto q=world.point({p.x,p.y,p.z});for(size_t axis=0;axis<3;++axis){bounds.lo[axis]=std::min(bounds.lo[axis],q[axis]);bounds.hi[axis]=std::max(bounds.hi[axis],q[axis]);}
      const auto stage=ob::transform(canvas,{float(q[0]),float(q[1]),float(q[2])});
      ++bounds.vertices;if(stage.z>=-.01f){++bounds.behind_eye;continue;}
      const double projected=(stage.y-1.6)/(-stage.z)/std::tan(.6);
      if(std::abs(projected)<=1)++bounds.inside_vertical;
    }
  }
  for(const auto&[id,bounds]:extents){Json row{{"group",id},{"model_world_min",bounds.lo},{"model_world_max",bounds.hi},{"vertices",bounds.vertices},{"vertices_inside_vertical_frustum",bounds.inside_vertical},{"vertices_behind_eye",bounds.behind_eye}};if(id){const auto&group=scene.group(id);row["name"]=group.name;row["group_position"]={group.transform.position.x,group.transform.position.y,group.transform.position.z};if(group.humanoid)row["creator_controls"]=group.humanoid->encode();}result["groups"].push_back(std::move(row));}
  std::ofstream(argv[3])<<result.dump(2)<<'\n';std::cout<<result.dump(2)<<'\n';return 0;
}catch(const std::exception&error){std::cerr<<error.what()<<'\n';return 1;}
