"""Separate production-Document geometry observation; no camera changes."""
from pathlib import Path
import fcntl, hashlib, importlib.util, json, os, subprocess, time, traceback
out=Path(__file__).resolve().parent
case=out/'ordinary-default-framing-v1'; case.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('owned',out/'owned-monitor.py');monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
build=json.loads((out/'default-probe-build.json').read_text());assert build['exit']==0
probe=out/'default-probe';assert sha(probe)==build['ELF_sha256']
pins=json.loads((out/'default-probe-before.json').read_text())
for p in [probe,Path(__file__),out/'default-probe-build.json',out/'owned-monitor.py',Path('/usr/bin/bwrap')]:
    pins[str(p)]=sha(p)
for name in ['build-before.json','review-actual-link-inputs.json','build-review.json']:
    p=out/name;pins[str(p)]=sha(p)
seed=out/'public-fixture-v1/fixture/creator-input.dsculpt';pins[str(seed)]=sha(seed)
for p in (out/'release').glob('*.a'):pins[str(p)]=sha(p)
env={k:v for k,v in os.environ.items()if not k.startswith(('LD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_','DYLD_'))}
for key in ['DISPLAY','WAYLAND_DISPLAY','DBUS_SESSION_BUS_ADDRESS','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']:env.pop(key,None)
env.update(HOME=str(case),LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',XR_RUNTIME_JSON=str(case/'no-physical-runtime.json'))
for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_STATE_HOME','state'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache'),('XDG_RUNTIME_DIR','runtime')]:
    p=case/leaf;p.mkdir(mode=0o700);env[key]=str(p)
native_commands=[[str(probe),'--native-default',str(case/'default.dsculpt'),str(case/'default.json')],[str(probe),'--inspect',str(seed),str(case/'preservation-stress.json')]]
sandbox=['/usr/bin/bwrap','--unshare-all','--die-with-parent','--ro-bind','/','/','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--bind',str(case),str(case),'--chdir',str(case)]
commands=[sandbox+command for command in native_commands]
plan={'source':'5509958f','production':'05f5d1cc','scope':'Separate actual default creation/anchoring geometry and vertical-frustum observation, plus independent preserved stress seed; no rendered-camera or physical-HMD acceptance','CPU_only_authorization':'Root explicitly allowed private /dev and process-monitored geometry observer while sustained Arc runs; no shared GPU lease or loader/display probes','commands':commands,'pins':pins,'environment':{k:v for k,v in env.items()if k.startswith(('XDG_','LD_','XR_','LP_','OPENBLAS_','OMP_'))},'timeout_seconds_each':180,'RSS_limit_bytes':4*1024**3,'virtual_AS_cap':None}
(case/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s={'terminal':False,'steps':[],'plan_sha256':sha(case/'plan.json'),'CPU_only_processes':{},'observed_DRM_FDs':[]};lease=None
def save():(case/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def progress(row):
    for r in row.get('known_processes',[]):
        if not monitor.alive(r):continue
        p=Path('/proc')/str(r['pid'])
        try:
            exe=str((p/'exe').resolve());cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
            assert Path(exe).name in ['bwrap','default-probe'],('Unexpected CPU observation child',exe,cmd)
            native=Path(exe).name=='default-probe'
            if native:assert not (p/'root/dev/dri').exists(),'Private sandbox unexpectedly exposes DRM'
            descriptors=[]
            for fd in (p/'fd').iterdir():
                try:
                    target=os.readlink(fd)
                    if target.startswith('/dev/dri/'):descriptors.append({'fd':fd.name,'target':target})
                except(FileNotFoundError,ProcessLookupError):pass
            assert not descriptors,('CPU observer holds DRM device',descriptors)
            if not monitor.same(r,monitor.identity(r['pid'])):continue
            s['CPU_only_processes'][str(r['pid'])]={'identity':r,'exe':exe,'command':cmd,'private_dev_has_no_dri':True if native else None,'DRM_FDs':descriptors}
        except(FileNotFoundError,ProcessLookupError):pass
    save()
try:
    assert not drift()
    s['CPU_only_exception_started']=time.time();save()
    for i,command in enumerate(commands):
        row=monitor.run(command,cwd=case,env=env,log=case/('process-'+str(i)+'.log'),timeout=180,max_rss=4*1024**3,progress=progress)
        s['steps'].append(row);save();assert row['exit']==0 and not row.get('error')and not row['signals']
    assert not drift();s['exit']=0
except BaseException as e:s.update(exit=1,error=repr(e),traceback=traceback.format_exc())
finally:
    s['input_drift']=drift();s['owned_remaining']=[r for step in s['steps']for r in step.get('known_processes',[])if monitor.alive(r)]
    if s['input_drift']or s['owned_remaining']:s['exit']=1
    s['terminal']=True
    if lease:
        if 'lease'in s:s['lease']['released']=time.time()
        save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
    save()
raise SystemExit(s['exit'])
