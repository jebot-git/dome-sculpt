from concurrent.futures import ThreadPoolExecutor
import re
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base.parent / 'texture-set-prepared-wire-source-20261126'
profile = sys.argv[1]
sanitize = profile == 'asan'
out = base / profile
out.mkdir(mode=0o700, exist_ok=True)
build = out / 'build'
sdk = base.parent / 'sdk-20261126/toolkit-sanitize' if sanitize else Path('/opt/fltk-vr/toolkit')
targets = {
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
    'dome-sculpt-texture-set-native': 'dome-sculpt-texture-set-native-test',
    'dome-sculpt-texture-set-history': 'dome-sculpt-texture-set-history-test',
    'dome-sculpt-texture-set-source-export': 'dome-sculpt-texture-set-source-export-test',
    'bake-recipes': 'dome-sculpt-bake-recipes-test',
    'native-scene-append': 'dome-sculpt-native-scene-append-test',
    'dome-sculpt-texture-set-resolution': 'dome-sculpt-texture-set-resolution-test',
}
start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git', '-C', source, *args], text=True).strip()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

status = {'candidate': git('rev-parse', 'HEAD'), 'profile': profile, 'terminal': False,
          'invocation': os.getenv('INVOCATION_ID'), 'fltk': str(sdk)}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic() - start, 2))
    tmp = out / 'status.tmp'
    tmp.write_text(json.dumps(status, indent=2) + '\n')
    tmp.replace(out / 'status.json')

def run(argv, logname, cwd=None, timeout=1800):
    with (out / logname).open('w') as log:
        print(shlex.join(map(str, argv)), file=log, flush=True)
        subprocess.run(argv, cwd=cwd, check=True, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)

try:
    assert status['candidate'].startswith('ef96e7c2') and not git('status','--porcelain')
    record(phase='configure')
    options = []
    if sanitize:
        options.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C', 'CXX'))
        options.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C', 'CXX'))
    run(['cmake', '-S', source, '-B', build, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON', '-DDOME_COMPUTE_BACKEND=CPU', f'-DFLTK_DIR={sdk}/share/fltk',
         *options], 'configure.log', timeout=120)
    donor = '360d1b7e85bb810b03122f464225809d8d162071'
    prior = base.parent / 'texture-set-prepared-rebase-validation-20261126' / ('asan' if sanitize else 'release')
    status_path = prior / 'status.json'
    prior_status = json.loads(status_path.read_text())
    assert prior_status['candidate'] == donor and prior_status.get('core_sha256')
    if sanitize:
        support = base.parent / 'hdr-preview-history-main-port-validation-20261126/asan/build'
    else:
        support = base.parent / 'texture-set-recipe-main-validation-20261126/release/build'
    parent_core = prior / 'libdome-sculpt-core.a'
    assert sha(parent_core) == prior_status['core_sha256']
    changed = set(git('diff','--name-only', donor, 'HEAD', '--', 'include','src','third_party','assets','cmake').splitlines())
    headers = {p for p in changed if p.endswith('.hpp')}
    assert len(headers) == 2 and all(p.startswith('src/') for p in changed)
    owners = changed - headers
    assert all(p.endswith('.cpp') for p in owners)
    listing = subprocess.check_output(['ninja','-C',support,'-t','deps'],text=True)
    member = ''
    for line in listing.splitlines():
        if line and not line[0].isspace():
            member = line.split(': #deps',1)[0]
        if member.startswith('CMakeFiles/dome-sculpt-core.dir/src/') and any(line.endswith('/'+h) for h in headers):
            owners.add(member.split('.dir/',1)[1][:-2])
    assert len(owners) >= 35
    if os.environ.get('DOME_PREPARED_PROBE'):
        assert not sanitize
        owners = changed - headers
        targets.clear()
        targets['dome-sculpt-texture-set-source-export'] = 'dome-sculpt-texture-set-source-export-test'
    database = json.loads((build/'compile_commands.json').read_text())
    def compile_path(owner, target):
        match = next(row for row in database if row['file'] == str(source / owner)
                     and f'CMakeFiles/{target}.dir/' in row['command'])
        words = shlex.split(match['command'])
        obj = out / (Path(owner).name + '.o')
        position = words.index('-o') + 1
        original = words[position]
        words[position] = str(obj)
        run(words, obj.name + '.log', build, 900)
        return original, obj
    record(phase='build all affected core owners', donor=donor, rebuilt=sorted(owners))
    with ThreadPoolExecutor(max_workers=4 if not sanitize else 3) as pool:
        changed = list(pool.map(lambda owner: compile_path(owner, 'dome-sculpt-core'), sorted(owners)))
    core = out / parent_core.name
    run(['cp', '--reflink=auto', parent_core, core], 'core-copy.log')
    run(['ar', 'r', core, *[obj for _, obj in changed]], 'core-update.log')
    run(['ranlib', core], 'core-index.log')
    digest_objects = {obj.name: sha(obj) for _, obj in changed}
    assert all(hashlib.sha256(subprocess.check_output(['ar','p',core,name])).hexdigest()==digest
               for name,digest in digest_objects.items())
    if sanitize:
        atlas_src = base.parent / 'atlas-aligned-bit-main-port-validation-20261126/asan'
        atlas = atlas_src / 'libxatlas.a'
        atlas_status = json.loads((atlas_src/'status.json').read_text())
        assert atlas_status['exit']==0 and atlas_status['atlas_sha256']==sha(atlas)
    else:
        atlas = support / 'libxatlas.a'
    assert git('diff','--name-only','5c8c8fb1','HEAD','--','third_party/xatlas') == ''
    record(phase='build exact registered tests against matching core', core_sha256=sha(core),
           parent_core_sha256=sha(parent_core), objects=digest_objects, atlas_sha256=sha(atlas))
    for name, target in targets.items():
        link = subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
        link = [word for word in shlex.split(link)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
        entry = next(row for row in database if f'CMakeFiles/{target}.dir/' in row['command'])
        old_obj, obj = compile_path(str(Path(entry['file']).relative_to(source)), target)
        link[link.index(old_obj)] = str(obj)
        link[link.index('libdome-sculpt-core.a')] = str(core)
        link[link.index('libxatlas.a')] = str(atlas)
        for index, value in enumerate(link):
            if value.startswith('lib') and value.endswith('.a'):
                assert (support/value).is_file(), value
                link[index] = str(support/value)
        run(link, name+'-link.log', build)
    record(phase='private native CTest', binaries={name:sha(build/target) for name,target in targets.items()})
    native = ['bwrap', '--die-with-parent', '--unshare-all', '--ro-bind', '/', '/',
              '--bind', build, build, '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp',
              '--tmpfs', '/run/user', '--clearenv', '--setenv', 'PATH', '/usr/bin:/bin',
              '--setenv', 'HOME', '/tmp', '--setenv', 'LD_LIBRARY_PATH',
              f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
    if sanitize:
        native.extend(['--setenv', 'ASAN_OPTIONS', 'detect_leaks=1:halt_on_error=1',
                       '--setenv', 'UBSAN_OPTIONS', 'halt_on_error=1:print_stacktrace=1'])
    run([*native,'ctest','--test-dir',build,'-R','^('+'|'.join([*targets,'texture-set-prepared-recipe-references'])+')$','--output-on-failure','-V'],
        'ctest.log', timeout=1400)
    log = (out/'ctest.log').read_text()
    expected = 2 if os.getenv('DOME_PREPARED_PROBE') else 8
    assert f'100% tests passed, 0 tests failed out of {expected}' in log and re.search(r'PASS \d+ prepared texture recipe controls', log)
    assert git('rev-parse', 'HEAD') == status['candidate'] and not git('status', '--porcelain')
    record(phase='complete', terminal=True, exit=0, ctest_sha256=sha(out/'ctest.log'))
except Exception as error:
    record(terminal=True, exit=1, error=repr(error))
    raise
