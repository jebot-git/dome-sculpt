from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import time

base = Path(__file__).resolve().parent
source = base.parent / 'texture-set-recipe-remap-source-20261126'
support = base / 'asan'
out = base / 'source-probe-asan'
out.mkdir(mode=0o700)
status = {'candidate': '273344dc316e97fe600b557388310b7ebef88cf5', 'terminal': False,
          'invocation': os.getenv('INVOCATION_ID')}
def record(**fields):
    status.update(fields)
    pending = out / 'status.tmp'
    pending.write_text(json.dumps(status, indent=2) + '\n')
    pending.replace(out/'status.json')

def run(name, words):
    with (out/(name+'.log')).open('w') as log:
        print(shlex.join(map(str,words)),file=log,flush=True)
        subprocess.run(words, cwd=support/'build', stdout=log, stderr=subprocess.STDOUT,
                       check=True, timeout=260)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

try:
    record(phase='wait for exact linked core')
    while True:
        report = support/'status.json'
        if report.is_file():
            donor = json.loads(report.read_text())
            assert donor['candidate']==status['candidate']
            if donor['terminal']:
                assert donor['exit']==0, donor
                break
        active = subprocess.check_output(['systemctl','--user','show',
            'ds-texture-recipe-remap-strict-20261126.service','-p','ActiveState','--value'],text=True).strip()
        if active != 'active' and not (report.is_file() and json.loads(report.read_text())['terminal']):
            raise RuntimeError('Matching sanitizer validation ended without a terminal result')
        time.sleep(5)
    assert sha(support/'libdome-sculpt-core.a') == donor['core_sha256']
    code = (source/'tests/texture-set-source-export.cpp').read_text()
    code = code.replace('#include "dome/document.hpp"',
        '#include "dome/document.hpp"\n#include "dome/bake-recipe.hpp"\n#include "dome/native-scene-append.hpp"',1)
    code = code.replace('bool floating=false,bool varying=false){',
                        'bool floating=false,bool varying=false,bool recipes=false){',1)
    anchor = ' Document d;d.replace(s);ready(d);'
    assert code.count(anchor)==1
    code = code.replace(anchor, ''' if (recipes) {
   const auto target = s.active().id;
   const auto recipe_source = s.add("Texture Bake source", Volume{});
   auto &bake_source = s.object(recipe_source);
   bake_source.mesh_active = true;
   bake_source.painted = std::make_shared<PaintedMesh>(m,64);
   s.select(target);
   s.object(target).bake_recipe = capture_bake_recipe(s, recipe_source, {});
 }
''' + anchor)
    code=code[:code.index('int main(')] + '''int main() try {
 auto scene = source(false,false,false,false,true);
 const auto before = scene.encode();
 const auto target = scene.active().id;
 const auto source_id = scene.active().bake_recipe->source.object;
 const auto original = active_texture_set(scene.active());
 check(original.source && original.bake_recipe && original.bake_recipe->source.object == source_id,
       "The real prepared texture field retains its original recipe");
 const auto erased = [&] {
   auto copy = scene.snapshot();
   copy.erase(source_id);
   return copy;
 }();
 const auto erased_field = active_texture_set(erased.object(target));
 check(erased_field.bake_recipe->source.object == unavailable_bake_object &&
       erased_field.source->read_view(erased_field) == original.source->read_view(original),
       "The prepared field rebases metadata while retaining its exact authenticated read view");
 const auto erased_wire = erased.encode();
 check(Scene::decode(erased_wire).encode() == erased_wire,
       "Source-backed native project retains the deleted source marker across reopen");
 auto appended = append_native_scene(scene,scene);
 const auto appended_field = active_texture_set(appended.scene.active());
 check(appended_field.bake_recipe->source.object != source_id &&
       appended_field.bake_recipe->source.original_object == source_id &&
       appended.scene.object(appended_field.bake_recipe->source.object).name == scene.object(source_id).name,
       "Same-source append namespaces the retained material recipe");
 check(appended_field.source->read_view(appended_field) == original.source->read_view(original),
       "Same-source append retains one exact authenticated read view");
 const auto nested = appended.scene.encode();
 check(Scene::decode(nested).encode() == nested && scene.encode() == before,
       "Both source-backed namespaces and the original native archive reopen exactly");
 std::cout << "PASS " << checks << " source-backed texture recipe controls" << std::endl;
 return 0;
} catch(const std::exception &error) {
 std::cerr << "FAIL " << error.what() << std::endl;
 return 1;
}
'''
    product = out/'source-probe.cpp'
    product.write_text(code)
    compile = shlex.split((support/'texture-set-source-export.cpp.o.log').read_text().splitlines()[0])
    compile[compile.index('-c')+1] = str(product)
    compile[compile.index('-o')+1] = str(out/'source-probe.o')
    record(phase='compile exact source diagnostic', core_sha256=donor['core_sha256'])
    run('compile', compile)
    link = shlex.split((support/'dome-sculpt-texture-set-source-export-link.log').read_text().splitlines()[0])
    link[link.index(str(support/'texture-set-source-export.cpp.o'))]=str(out/'source-probe.o')
    link[link.index('-o')+1]=str(out/'source-probe')
    run('link', link)
    record(phase='run source-backed append and deletion')
    run('result', ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--dev','/dev',
        '--proc','/proc','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','HOME','/tmp',
        '--setenv','PATH','/usr/bin:/bin','--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
        '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',out/'source-probe'])
    assert 'source-backed texture recipe controls' in (out/'result.log').read_text()
    record(phase='complete', terminal=True, exit=0, sha256=sha(out/'result.log'))
except Exception as error:
    record(terminal=True, exit=1, error=repr(error))
    raise
