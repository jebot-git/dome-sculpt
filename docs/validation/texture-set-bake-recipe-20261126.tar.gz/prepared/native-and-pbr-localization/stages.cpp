// SPDX-License-Identifier: GPL-3.0-or-later
#include "dome/document.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/native-scene-append.hpp"
#include "dome/normal-preparation.hpp"
#include "dome/gltf-export.hpp"
#include "dome/projection.hpp"
#include "dome/source-maps.hpp"
#include "dome/source-placement.hpp"
#include "texture-set-export.hpp"
#include "texture-set-field-source.hpp"
#include "polygon-surface-preview.hpp"
#include "baked-normal-field.hpp"
#include "gltf-document.hpp"
#include "cgltf.h"
#include "native-paint-sampling.hpp"
#include "polygon-surface-owner.hpp"
#include <bit>
#include <fstream>
#include <iostream>
using namespace dome;
namespace {
size_t checks=0;
void check(bool v,const char*s){if(!v)throw std::runtime_error(s);++checks;}
template<class F>void refuses(F&&f,const char*s){bool rejected=false;try{f();}catch(const std::exception&e){rejected=true;std::cout<<"EXPECTED "<<e.what()<<'\n';}check(rejected,s);}
void ready(Document&d){check(d.wait_asset(std::chrono::seconds(120))&&d.wait_mesh(std::chrono::seconds(120)),"Actual native workers settle");if(!d.frame().state->error.empty())throw std::runtime_error(d.frame().state->error);}
void polygon(Document&d){check(d.wait_polygon(std::chrono::seconds(120)),"Actual native polygon queue settles");if(!d.frame().state->error.empty())throw std::runtime_error(d.frame().state->error);}
Image solid(std::array<uint8_t,4>rgba){Image out{64,64,{}};out.rgba.resize(64*64*4);for(size_t i=0;i<64*64;++i)std::copy(rgba.begin(),rgba.end(),out.rgba.begin()+i*4);return out;}
void native_owner_controls(const Scene&scene){
 const auto exact=scene.encode();const auto &actor=scene.active();const auto binding=actor.material_bindings;const auto native=binding->native_paint_sampling;
 const auto reopened=Scene::decode(exact);check(reopened.encode()==exact,"Actual native UV owner has an exact owning codec cycle before polygon capture");check(binding->sampling_reparameterized,"Genuine native KeepPaint before-binding declares its reparameterized sampling interpretation");
 auto cleared=scene.snapshot();auto cleared_binding=std::make_shared<SourceMaterialBindings>(*binding);cleared.active().material_bindings=cleared_binding;cleared_binding->sampling_reparameterized=false;
 refuses([&]{detail::PolygonSurfaceOwner::capture(cleared,cleared.active().id);},"An otherwise genuine native owner cannot clear its required sampling interpretation flag");
 auto candidate=scene.snapshot();auto changed=std::make_shared<SourceMaterialBindings>(*binding);candidate.active().material_bindings=changed;
 changed->native_paint_sampling=std::shared_ptr<const detail::NativePaintSampling>(native.get(),[](auto*){});
 refuses([&]{detail::PolygonSurfaceOwner::capture(candidate,candidate.active().id);},"A borrowed address/control block cannot authorize native polygon capture");
 candidate=scene.snapshot();changed=std::make_shared<SourceMaterialBindings>(*binding);candidate.active().material_bindings=changed;changed->native_paint_sampling=reopened.active().material_bindings->native_paint_sampling;
 refuses([&]{detail::PolygonSurfaceOwner::capture(candidate,candidate.active().id);},"A genuine foreign decoded native owner cannot borrow the current paint attachment");
 candidate=scene.snapshot();candidate.active().painted=native->before_paint()->snapshot();
 refuses([&]{detail::PolygonSurfaceOwner::capture(candidate,candidate.active().id);},"Original before paint cannot impersonate the current native UV attachment");
 auto future=exact;future.at("paint_sampling").at("version")=3;
 refuses([&]{Scene::decode(future);},"A changed sampling archive version cannot grant current native or polygon authority");
 auto donor=std::make_shared<PaintedMesh>(actor.painted->mesh(),64);BakedTextures bake;bake.maps.color=solid({90,100,110,255});bake.maps.metal_rough=solid({255,160,0,255});bake.maps.emission=solid({0,0,0,255});bake.maps.normal=solid({128,128,255,255});bake.coverage.assign(64*64,255);donor->install_bake(std::move(bake));const auto converted=convert_canonical_normals({donor,{},{},{},actor.material,{}});
 candidate=scene.snapshot();changed=std::make_shared<SourceMaterialBindings>(*binding);candidate.active().material_bindings=changed;changed->normal_frames=converted.material_bindings->normal_frames;changed->normal_frame=SourceMaterialNormalFrame::OriginalAttributes;
 refuses([&]{detail::PolygonSurfaceOwner::capture(candidate,candidate.active().id);},"A real foreign canonical artist frame cannot enter the paint-only native adapter");
 detail::PolygonSurfaceTransferLimits limited;limited.maximum_working_bytes=1024;
 refuses([&]{detail::PolygonSurfaceOwner::capture(scene,actor.id,limited);},"Native field capture preserves prospective owner/snapshot quota refusal");limited={};limited.geometry.cancelled=[]{return true;};
 refuses([&]{detail::PolygonSurfaceOwner::capture(scene,actor.id,limited);},"Native field capture keeps actual cancellation before publication");
 check(scene.encode()==exact,"Every native ownership/version/frame/quota control preserves the complete original Scene");
}
void move(Document&d){
 const auto topology=d.frame().state->polygon->topology;const auto mesh=topology->triangulate().mesh;const auto a=mesh.positions.at(mesh.indices.at(0)),b=mesh.positions.at(mesh.indices.at(1)),c=mesh.positions.at(mesh.indices.at(2));const auto p=a*.2f+b*.3f+c*.5f,n=normalized(cross(b-a,c-a));
 d.polygon_pointer(p+n,n*-1,PolygonAction::BeginDrag);polygon(d);check(d.frame().state->polygon->moving,"Actual selected face ray begins a native Move gesture");const Vec3 delta{.006f,.003f,0};d.polygon_pointer(p+n+delta,n*-1,PolygonAction::Drag);polygon(d);d.polygon_pointer(p+n+delta,n*-1,PolygonAction::EndDrag);polygon(d);
}
Scene source(bool prepared,bool reflected,bool floating=false,bool varying=false,bool recipes=false){
 Mesh m;m.positions={{-.8f,-.6f,0},{.8f,-.6f,0},{.8f,.6f,0},{-.8f,.6f,0}};m.normals.assign(4,{0,0,1});if(varying)m.normals[1]=normalized(Vec3{.2f,.1f,1});m.uv={{{.1f,.1f}},{{.9f,.1f}},{{.9f,.9f}},{{.1f,.9f}}};m.indices={0,1,2,0,2,3};
 Scene s;auto&o=s.active();o.mesh_active=true;o.material.double_sided=true;o.material.color={.4f,.3f,.2f,1};o.painted=std::make_shared<PaintedMesh>(m,64);
 if(prepared){BakedTextures bake;bake.maps.color=solid({90,100,110,255});bake.maps.metal_rough=solid({255,160,0,255});bake.maps.emission=solid({0,0,0,255});bake.maps.normal=solid({128,128,255,255});bake.coverage.assign(64*64,255);for(size_t y=0;y<64;++y)for(size_t x=0;x<64;++x){const auto at=(y*64+x)*4;bake.maps.normal.rgba[at]=uint8_t(96+x/4);bake.maps.normal.rgba[at+1]=uint8_t(112+y/3);bake.maps.normal.rgba[at+2]=240;}o.painted->install_bake(std::move(bake));auto converted=convert_canonical_normals({o.painted,{},{},{},o.material,{}});o.painted=std::move(converted.paint);o.material_bindings=std::move(converted.material_bindings);}
 if(floating){PaintSettings ink;ink.front_only=false;ink.channel=PaintChannel::Emission;ink.emission_units=PaintEmissionUnits::Physical;ink.emission={3,.01f,1};Brush b;b.from=b.to={0,0,0};b.normal={0,0,1};b.radius=2;b.strength=1;o.painted->begin_stroke();o.painted->stamp(b,ink);check(o.painted->end_stroke(),"Negative fixture owns a genuine FLOAT stroke");}
 // The N-only positive must contain real byte paint and request the actual
 // KeepPaint UV transition. Empty ordinary Paint correctly uses the legacy
 // polygon route and is not an original-field ownership receipt.
 if(!prepared&&!floating){PaintSettings ink;ink.front_only=false;ink.channel=PaintChannel::Color;ink.color={.2f,.7f,.4f,1};Brush b;b.from=b.to={0,0,0};b.normal={0,0,1};b.radius=.7f;b.strength=.8f;b.blend=.2f;o.painted->begin_stroke();o.painted->stamp(b,ink);check(o.painted->end_stroke()&&o.painted->has_paint_data()&&!o.painted->has_physical_emission(),"Actual N-only source owns nonempty byte paint without manufactured FLOAT history");}
 if (recipes) {
   const auto target = s.active().id;
   const auto recipe_source = s.add("Texture Bake source", Volume{});
   auto &bake_source = s.object(recipe_source);
   bake_source.mesh_active = true;
   bake_source.painted = std::make_shared<PaintedMesh>(m,64);
   s.select(target);
   s.object(target).bake_recipe = capture_bake_recipe(s, recipe_source, {});
 }
 Document d;d.replace(s);ready(d);
 if(!floating){d.begin_uv();check(d.wait_uv(),"Actual original normal/paint UV workspace opens");if(!prepared){check(d.frame().state->uv->paint_sampling_available,"Actual native KeepPaint action is available");if(!d.frame().state->uv->retain_paint_sampling)d.edit_uv(UvAction::RetainPaint);}d.edit_uv(UvAction::Pick,.5f,.5f);d.edit_uv(UvAction::Scale,.8f);check(d.wait_uv(),"Actual writable UV changes independently of retained original coordinates");d.end_uv(true);ready(d);}
 if(!prepared&&!floating){const auto retained=d.copy_scene();const auto &native=retained.active();check(native.material_bindings&&native.material_bindings->native_paint_sampling&&native.material_bindings->native_paint_sampling->valid_owner(native.material_bindings->native_paint_sampling)&&native.material_bindings->native_paint_sampling->matches_current(*native.painted),"Actual native UV worker publishes its complete paint source/attachment owner");check(native.painted->mesh().uv!=m.uv&&!native.painted->has_physical_emission(),"N-only original paint UV differs from current geometry without FLOAT");native_owner_controls(retained);}

 const auto before_polygon=d.copy_scene().encode();d.begin_polygon(true);polygon(d);d.edit_polygon(PolygonAction::Faces);polygon(d);d.edit_polygon(PolygonAction::SelectAll);polygon(d);move(d);d.edit_polygon(PolygonAction::FlipFaces);polygon(d);d.end_polygon(true);ready(d);
 if(!prepared&&!floating){const auto accepted=d.copy_scene().encode();check(accepted.at("version")==39&&Scene::decode(accepted).encode()==accepted,"Actual native UV to Move/Flip field has an exact owning Scene39 codec cycle");auto cyclic=accepted;const auto &bindings=cyclic.at("source_materials").at("bindings");size_t field_binding=0;while(field_binding<bindings.size()&&bindings.at(field_binding).at("polygon_surface_transfer").is_null())++field_binding;check(field_binding<bindings.size(),"Owning native history has its actual current polygon material node");cyclic.at("source_materials").at("native_paints").at(0).at("before_binding")=field_binding;refuses([&]{Scene::decode(cyclic);},"Nested native history cannot borrow a future current-field material or create a source cycle");check(d.undo()&&d.copy_scene().encode()==before_polygon&&d.redo()&&d.copy_scene().encode()==accepted,"Actual native Move/Flip has exact global Undo/Redo and original UV owner history");Document restart;restart.replace(Scene::decode(accepted));ready(restart);restart.restore_polygon_source();ready(restart);check(restart.copy_scene().encode()==before_polygon,"Restarted polygon source Restore recovers the actual original native UV paint owner");}
 auto result=d.copy_scene();auto&actor=result.active();auto placement=AffineTransform{}.matrix();placement[0]=reflected?-1.2:1.2;placement[1]=.1;placement[4]=.3;placement[5]=.8;placement[9]=.15;placement[10]=1.1;actor.affine_edit=std::make_shared<const NativeAffineEdit>(AffineTransform(placement));
 check(actor.material_bindings&&actor.material_bindings->polygon_surface_transfer,"Actual accepted native edit owns its original field");if(!prepared&&!floating){const auto &before=actor.material_bindings->polygon_surface_transfer->before();check(before->material_bindings&&before->material_bindings->native_paint_sampling&&before->paint->paint_sampling_domain()&&before->paint->paint_sampling_domain()->version()==1&&!before->paint->has_physical_emission(),"Genuine polygon before-root retains the complete native UV paint owner and original non-FLOAT basis");check(actor.material_bindings->polygon_surface_transfer->matches_current(*actor.painted),"Accepted N-only owner authenticates the actual new current Paint attachment");check(before->material_bindings->sampling_reparameterized&&!actor.material_bindings->sampling_reparameterized,"Actual native before=true and polygon current=false remain separate owning sampling interpretations");}const auto object=actor.id;const auto face=actor.polygon->topology.faces().front().id;create_texture_set(result,object,std::array<uint64_t,1>{face},"Exported retained slot",64);
 // Collection publication atomically replaces Scene; retain the stable ID,
 // never a reference into its previous object vector, across public edits.
 edit_texture_set(result,object,1,[](PaintedMesh&,Material&m){m.name="Actual current second material";m.roughness=.3f;return true;});result.validate();const auto wire=result.encode();check(Scene::decode(wire).encode()==wire,"Actual current per-field native source collection survives owning Scene40 and retained history transport");return result;
}
uint32_t word(const std::vector<uint8_t>&b,size_t n){return uint32_t(b.at(n))|uint32_t(b.at(n+1))<<8|uint32_t(b.at(n+2))<<16|uint32_t(b.at(n+3))<<24;}
std::vector<float>attribute(const detail::GltfDocument&d,int index,size_t n,size_t stride){const auto&a=d.json.at("accessors").at(index);check(a.at("componentType")==5126&&n<a.at("count").get<size_t>(),"Actual emitted float accessor has its full domain");const auto&v=d.json.at("bufferViews").at(a.at("bufferView").get<size_t>());const size_t offset=v.value("byteOffset",size_t(0))+a.value("byteOffset",size_t(0))+n*v.value("byteStride",stride*4);std::vector<float>r;for(size_t k=0;k<stride;++k)r.push_back(std::bit_cast<float>(word(d.binary,offset+k*4)));return r;}
uint32_t index_at(const detail::GltfDocument&d,int index,size_t n){const auto&a=d.json.at("accessors").at(index);const auto&v=d.json.at("bufferViews").at(a.at("bufferView").get<size_t>());check(a.at("componentType")==5125&&n<a.at("count").get<size_t>(),"Actual material index accessor has its own range");return word(d.binary,v.value("byteOffset",size_t(0))+a.value("byteOffset",size_t(0))+n*4);}
Vec3 vector(const std::vector<float>&v){return {v.at(0),v.at(1),v.at(2)};}
Vec3 unit(AffineVector v){return normalized(Vec3{float(v[0]),float(v[1]),float(v[2])});}
Image texture_image(const detail::GltfDocument&d,const nlohmann::json&info){const auto&texture=d.json.at("textures").at(info.at("index").get<size_t>());const auto&image=d.json.at("images").at(texture.at("source").get<size_t>());const auto&view=d.json.at("bufferViews").at(image.at("bufferView").get<size_t>());const auto offset=view.value("byteOffset",size_t(0)),count=view.at("byteLength").get<size_t>();check(offset<=d.binary.size()&&count<=d.binary.size()-offset,"Actual material PNG lies within the emitted buffer");return decode_projection_png(std::span(d.binary).subspan(offset,count));}
void audit(bool prepared,bool reflected,bool varying=false){
 auto scene=source(prepared,reflected,false,varying);if(varying)scene.active().affine_edit.reset();const auto exact=scene.encode();const auto surfaces=scene.export_surfaces();check(surfaces.size()==1&&surfaces[0].texture_set_surface,"Real visible source actor yields one shared multi-material export bundle");const auto compiled=detail::compile_texture_set_export(surfaces[0]);const auto output=detail::make_gltf(surfaces);const auto&primitives=output.json.at("meshes").at(0).at("primitives");check(primitives.size()==2&&compiled.fields.size()==2,"Actual source bundle emits both nonempty material ranges");const auto&plan=*surfaces[0].texture_set_surface;const auto world=surfaces[0].world_matrix();
 for(size_t f=0;f<2;++f){const auto&primitive=primitives.at(f);const auto&attrs=primitive.at("attributes");const auto&field=plan.fields()[f];const auto&draw=plan.draws()[f];const auto&material=output.json.at("materials").at(primitive.at("material").get<size_t>());check(primitive.at("extras").at("dome_sculpt_texture_set").at("id")==field.id,"Portable primitive retains its actual object-local material identity");if(f)check(material.at("name")==field.material.name,"Additional portable material retains current authored scalars/name");
  const auto paint_set=material.at("pbrMetallicRoughness").at("baseColorTexture").value("texCoord",0u);const auto paint_attr=attrs.at("TEXCOORD_"+std::to_string(paint_set)).get<int>();const auto native=field.source->source_preview();const auto color=texture_image(output,material.at("pbrMetallicRoughness").at("baseColorTexture"));check(color.rgba==compiled.fields[f].textures->color.rgba,"Actual emitted per-material PNG retains current composite bytes");
  std::optional<PaintSourceTexture>normal_image;int normal_attr=0;
  if(prepared){check(material.contains("normalTexture")&&attrs.contains("TANGENT"),"Prepared retained role exports its actual normal image and tangent attributes");const auto image=texture_image(output,material.at("normalTexture"));check(image.rgba==native->field_owner()->before()->paint->baked()->normal_field->pbr()->rgba,"Actual emitted normal image preserves complete original role bytes");PaintSourceTexture t;t.image=std::make_shared<const Image>(image);t.wrap_s=t.wrap_t=33071;t.min_filter=t.mag_filter=9729;normal_image=t;normal_attr=attrs.at("TEXCOORD_"+std::to_string(material.at("normalTexture").value("texCoord",0u)));}
  bool independent_uv=false;for(size_t c=0;c<draw.count;++c){const auto logical=plan.logical_corners()[draw.first+c],vertex=index_at(output,primitive.at("indices"),c);const auto raw_vertex=plan.geometry()->indices.at(logical);const auto uv=attribute(output,attrs.at("TEXCOORD_0"),vertex,2),paint=attribute(output,paint_attr,vertex,2);check(uv==std::vector<float>(plan.geometry()->uv.at(raw_vertex).begin(),plan.geometry()->uv.at(raw_vertex).end()),"Standard export retains current UV0 separately from original paint grid");check(paint==std::vector<float>(native->paint_coordinates().at(logical).begin(),native->paint_coordinates().at(logical).end()),"Material paint texture uses the actual retained logical corner coordinates");independent_uv|=uv!=paint;if(prepared){const auto role=attribute(output,normal_attr,vertex,2);check(role==std::vector<float>(native->normal_coordinates().at(logical).begin(),native->normal_coordinates().at(logical).end()),"Standard normal texture uses its actual independent role coordinates");}}
  check(independent_uv,"Each exported material keeps genuinely distinct current UV0 and original writable paint coordinates");
  for(size_t c=0;c<draw.count;c+=3)for(const auto bary:{std::array<double,3>{.2,.3,.5},std::array<double,3>{.6,.2,.2}}){Vec3 N{},T{};double u=0,v=0;float w=1;for(size_t k=0;k<3;++k){const auto vertex=index_at(output,primitive.at("indices"),c+k);const auto n=vector(attribute(output,attrs.at("NORMAL"),vertex,3));N+=unit(world.normal({n.x,n.y,n.z}))*float(bary[k]);if(prepared){const auto t=attribute(output,attrs.at("TANGENT"),vertex,4);T+=unit(world.direction({t[0],t[1],t[2]}))*float(bary[k]);w=t[3];const auto uv=attribute(output,normal_attr,vertex,2);u+=uv[0]*bary[k];v+=uv[1]*bary[k];}}
   N=normalized(N);Vec3 emitted=N;if(prepared){T=normalized(T);const auto B=normalized(cross(N,T))*(w*(world.orientation()==AffineOrientation::Reversing?-1.f:1.f));const auto texel=sample_source_texture(*normal_image,float(u),float(v),false);emitted=normalized(T*(texel[0]*2-1)+B*(texel[1]*2-1)+N*(texel[2]*2-1));}const auto triangle=plan.logical_corners()[draw.first+c]/3;check(length(emitted-field.source->normal(triangle,bary,world,true))<2e-5f,"Independent standard glTF N/T/image evaluation agrees with the genuine source owner under actual shear/reflection");}
 }
 const std::string file=varying?"native-smooth.glb":std::string(prepared?"prepared":"native")+(reflected?"-reflected.glb":"-sheared.glb");export_glb(surfaces,file);cgltf_options options{};cgltf_data*data=nullptr;check(cgltf_parse_file(&options,file.c_str(),&data)==cgltf_result_success,"Independent cgltf parses the actual durable GLB");struct Free{cgltf_data*p;~Free(){cgltf_free(p);}}free{data};check(cgltf_load_buffers(&options,data,file.c_str())==cgltf_result_success&&cgltf_validate(data)==cgltf_result_success,"Independent standard glTF consumer validates actual buffers, materials and attributes");check(data->meshes_count==1&&data->meshes[0].primitives_count==2,"Independent consumer sees one geometry with both material primitives");
 check(scene.encode()==exact,"Portable source compilation leaves all original normal/paint/recipe/native history exact");
}
}
void recipe_reference_remap(bool prepared) {
 std::cout << "STAGE prepare source PBR=" << prepared << std::endl;
 auto scene = source(prepared,false,false,false,true);
 std::cout << "STAGE source encode PBR=" << prepared << std::endl;
 const auto before = scene.encode();
 const auto target = scene.active().id;
 const auto source_id = scene.active().bake_recipe->source.object;
 const auto original = active_texture_set(scene.active());
 check(original.source && original.bake_recipe && original.bake_recipe->source.object == source_id,
       "The real prepared texture field retains its original recipe");
 auto erased = scene.snapshot();
 std::cout << "STAGE erase source PBR=" << prepared << std::endl;
 erased.erase(source_id);
 const auto &erased_object = erased.object(target);
 const auto erased_field = active_texture_set(erased_object);
 check(erased_field.bake_recipe->source.object == unavailable_bake_object &&
       erased_field.bake_recipe->source.original_object == source_id &&
       erased_field.source->read_view(erased_field) == original.source->read_view(original),
       "Prepared-field deletion preserves the exact read view and original source identity");
 check(erased_object.polygon->origin == erased_field.source->polygon_owner()->before() &&
       erased_field.source->source_preview()->matches(erased_field.material_bindings,
           original.source->read_view(original)->paint_sampling_attachment()) &&
       erased_field.source->source_preview()->shares_streams(*original.source->source_preview()),
       "Prepared-field deletion preserves one authenticated origin, attachment and preview streams");
 std::cout << "STAGE encode erased PBR=" << prepared << std::endl;
 const auto erased_wire = erased.encode();
 std::cout << "STAGE reopen erased PBR=" << prepared << std::endl;
 check(Scene::decode(erased_wire).encode() == erased_wire,
       "The prepared native project reopens with its deleted source marker");

 std::cout << "STAGE append PBR=" << prepared << std::endl;
 auto appended = append_native_scene(scene,scene);
 const auto &appended_object = appended.scene.active();
 const auto appended_field = active_texture_set(appended_object);
 check(appended_field.bake_recipe->source.object != source_id &&
       appended_field.bake_recipe->source.original_object == source_id &&
       appended.scene.object(appended_field.bake_recipe->source.object).name == scene.object(source_id).name,
       "Same-scene append namespaces the prepared field recipe");
 check(appended_field.source->read_view(appended_field) == original.source->read_view(original) &&
       appended_object.polygon->origin == appended_field.source->polygon_owner()->before() &&
       appended_field.source->source_preview()->shares_streams(*original.source->source_preview()),
       "Same-scene append preserves shared raster and authenticated preview data");
 std::cout << "STAGE encode append PBR=" << prepared << std::endl;
 const auto nested = appended.scene.encode();
 std::cout << "STAGE reopen append PBR=" << prepared << std::endl;
 check(Scene::decode(nested).encode() == nested && scene.encode() == before,
       "Both prepared source namespaces and the original native archive reopen exactly");
 const auto &nodes = nested.at("polygon_surfaces").at("nodes");
 size_t variant = 0;
 while (variant < nodes.size() && nodes[variant].at("version") == 1)
   ++variant;
 check(variant < nodes.size() && nodes[variant].at("sampling_node").get<size_t>() < variant,
       "Prepared source namespaces explicitly share an authenticated earlier sampling node");
 auto forged = nested;
 forged["polygon_surfaces"]["nodes"][variant]["sampling_node"] = variant;
 refuses([&]{Scene::decode(forged);},"Shared polygon sampling rejects a self-reference");
 forged = nested;
 auto &foreign = forged["polygon_surfaces"]["nodes"][variant]["recipe"]["operations"][0];
 foreign["delta"][0] = foreign["delta"][0].get<float>() + 0.01f;
 refuses([&]{Scene::decode(forged);},"Shared polygon sampling rejects a different geometric recipe");

}
int main(int argc,char**argv)try{if(argc==2&&std::string_view(argv[1])=="--recipe-reference-remap"){for(bool prepared:{false,true})recipe_reference_remap(prepared);std::cout<<"PASS "<<checks<<" prepared texture recipe controls\n";return 0;}if(argc>1){std::filesystem::create_directories(argv[1]);std::filesystem::current_path(argv[1]);}for(bool prepared:{false,true})for(bool reflected:{false,true})audit(prepared,reflected);audit(false,false,true);auto varied=source(false,false,false,true);const auto before=varied.encode();refuses([&]{detail::make_gltf(varied.export_surfaces());},"A varying original role is explicitly refused pending its full interpolation adapter");check(varied.encode()==before,"Varying-role refusal preserves the actual native source");auto hdr=source(false,false,true);refuses([&]{detail::make_gltf(hdr.export_surfaces());},"Actual FLOAT source export retains its precision-qualified per-material guard");std::cout<<"PASS "<<checks<<" actual retained standard source export controls\n";return 0;}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
