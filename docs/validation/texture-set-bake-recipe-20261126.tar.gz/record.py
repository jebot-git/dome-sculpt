from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

root = Path.cwd()
artifacts = root/'artifacts'
base = artifacts/'texture-set-recipe-main-validation-20261126'
remap = artifacts/'texture-set-recipe-remap-validation-20261126'
files = {}
receipt = {'sdk_source': 'acc2b70ae61dedec2a23727f67c60c0303d0f76f'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def take(prefix, folder, *names):
    for name in names:
        files[prefix+'/'+name] = (folder/name).read_bytes()

def outcome(prefix, folder, source, expected):
    take(prefix,folder,'status.json','ctest.log')
    status = json.loads(files[prefix+'/status.json'])
    assert status['candidate']==source and status['terminal'] and status['exit']==0
    log = files[prefix+'/ctest.log']
    assert status['ctest_sha256']==sha(log)
    assert b'100% tests passed, 0 tests failed out of 5' in log
    pattern = b'PASS ' + str(expected).encode('ascii') + b' texture-set recipe controls'
    assert pattern in log
    native = folder/'build'/'texture-set-bake-recipe'
    saved = (native/'recipes.dsculpt').read_bytes()
    assert saved == (native/'recipes-reopened.dsculpt').read_bytes()
    return {'status':status, 'native_sha256':sha(saved),
            'checks':sum(int(n) for n in re.findall(rb'^\d+: PASS (\d+) ',log,re.M))}

scene40 = 'fe16a68418a81152949d02a2f4504c1b8e10cac2'
transaction = '273344dc316e97fe600b557388310b7ebef88cf5'
receipt['recipe_persistence'] = {profile:outcome('persistence/'+profile,base/profile,scene40,20)
                                for profile in ('release','asan')}
assert receipt['recipe_persistence']['release']['native_sha256']==receipt['recipe_persistence']['asan']['native_sha256']
take('persistence/asan/before-remap',base/'asan/recipe-reference-probe','probe.cpp','compile.log','link.log','probe.log')
probe=files['persistence/asan/before-remap/probe.log']
assert b'DELETED_SOURCE Bake recipe has a missing or self live reference' in probe
assert b'APPEND_SOURCE Bake recipe has a missing or self live reference' in probe
receipt['before_reference_remap']={'source':scene40,'source_delete':'save refused','native_append':'append refused independently'}
receipt['reference_remap']={}
for profile in ('release','asan'):
    status = remap/profile/'status.json'
    if status.is_file() and json.loads(status.read_text())['terminal']:
        terminal=json.loads(status.read_text())
        if terminal['exit']==0:
            receipt['reference_remap'][profile]=outcome('remap/'+profile,remap/profile,transaction,27)
        else:
            take('remap/'+profile,remap/profile,'status.json')
            receipt['reference_remap'][profile]=terminal
    else:
        receipt['reference_remap'][profile]={'source':transaction,'terminal':False}
source_report = remap/'source-probe-asan/status.json'
if source_report.is_file() and json.loads(source_report.read_text())['terminal']:
    receipt['source_backed_reference_probe']=json.loads(source_report.read_text())
    for name in ('status.json','source-probe.cpp','result.log'):
        if (source_report.parent/name).is_file():
            take('remap/source-backed-probe',source_report.parent,name)
stages = remap/'source-probe-stages-asan'
take('remap/source-backed-stages',stages,'status.json','source-probe.cpp','result.log')
result=files['remap/source-backed-stages/result.log']
assert b'STAGE source built' in result and b'STAGE deletion entered' in result
assert b'STAGE deleted source encode entered' in result and b'STAGE append entered' not in result
assert b'FAIL Polygon field model lost its exact current editable authority and complete source' in result
receipt['source_backed_reference_probe']['failure_stage']='Save encoding after deleting a genuine prepared-polygon Bake source'
assert receipt['reference_remap']['release']['native_sha256']==receipt['reference_remap']['asan']['native_sha256']
for key,filename in {'record.py':Path(__file__), 'run-persistence.py':base/'run.py',
                     'run-remap-asan.py':remap/'run.py', 'run-remap-release.py':remap/'run-both.py',
                     'run-source-probe.py':remap/'source-probe.py'}.items():
    files[key]=filename.read_bytes()
archive=root/'docs/validation/texture-set-bake-recipe-20261126.tar.gz'
with archive.open('wb') as out, gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as encoded, tarfile.open(fileobj=encoded,mode='w') as tar:
    for name,data in sorted(files.items()):
        entry=tarfile.TarInfo(name)
        entry.size=len(data)
        entry.mode=0o644
        tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert set(tar.getnames())==set(files)
    assert all(tar.extractfile(name).read()==payload for name,payload in files.items())
receipt['archive']={'path':str(archive.relative_to(root)), 'sha256':sha(archive.read_bytes()), 'members':len(files)}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
