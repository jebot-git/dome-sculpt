"""One CPU forecast and immutable prior-RGB calibration; no GL consumer."""
import fcntl,hashlib,importlib.util,json,math,os,re,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n')
assert len(sys.argv)==2 and sha(P/'forecast-plan-v1.json')==sys.argv[1],'Exact root-reviewed plan SHA required'
J=json.loads((P/'forecast-plan-v1.json').read_text());pins=dict(J['input_pins']);out=Path(J['output']);out.mkdir(exist_ok=False)
state={'state':'preflight','exit':1,'source':J['source'],'scope':J['scope'],'steps':[],'plan_sha256':sys.argv[1]};lease=None

def save():write(out/'status.json',state)
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
try:
 assert sha(__file__)==J['driver_sha256'];assert not drift(),('Input drift',drift())
 L=json.loads(Path(J['link_status']).read_text());assert L['state']=='terminal'and L['exit']==0 and not L['input_drift']and L['static_ELF_contract_same']and not any(L['link_roster_difference'].values())
 M=Path(J['monitor']);spec=importlib.util.spec_from_file_location('owned_CPU_forecast_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
 lease=Path(J['common_lease']).open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);state['lease']={'owner':monitor.identity(os.getpid()),'released':False,'before_ldd_or_product':True}
 env=dict(J['environment']);state['environment']=env;write(out/'inputs-before.json',pins)
 def run(name,argv):
  command=['/usr/bin/prlimit','--as=2147483648','--core=0','--','/usr/bin/nice','-n','10']+argv
  def progress(row):state['live']={'name':name,**row};save()
  row=monitor.run(command,cwd=out,env=env,log=out/(name+'.log'),timeout=900,max_rss=3*1024**3,progress=progress);row.update(name=name,log_sha256=sha(out/(name+'.log')));state['steps'].append(row);state.pop('live',None);save()
  assert row['exit']==0 and not row.get('error')and not row['signals'],(name,row['exit'],row.get('error'))
  assert not[v for v in row['known_processes']if monitor.alive(v)]
  return(out/(name+'.log')).read_text()
 text=run('ldd',['/usr/bin/ldd',J['product']['path']]);assert 'not found'not in text;providers=[]
 for literal in re.findall(r'(/[^\s()]+)',text):
  if not Path(literal).is_file():continue
  resolved=str(Path(literal).resolve());expected=pins.get(literal,pins.get(resolved));assert expected is not None and sha(literal)==expected,('Unbound actual loader provider',literal,resolved);providers.append({'literal':literal,'resolved':resolved,'sha256':expected})
 state['loader_providers']=providers;save();data=out/'forecast.jsonl'
 text=run('CPU-forecast',[J['product']['path'],'--advanced-contrast-forecast',str(data)])
 assert re.search(r'^PASS CPU advanced contrast forecast views=68; no GL context or normal/material mutation$',text,re.M)
 assert 'ACTUAL_RENDERER 'not in text
 expected_labels=set(J['expected_view_labels']);views={};originals={};pointcounts={};calibration={};original_set={tuple(p)for p in J['original_probes']}
 with data.open()as stream:
  for line in stream:
   row=json.loads(line);label=row['label'];assert label in expected_labels
   if row['kind']=='view':assert label not in views;views[label]=row;continue
   assert row['kind']=='point'and row['frontmost_triangle']==0 and min(row['bary'])>.05
   assert all(math.isfinite(v)for n in row['correct_and3negative_normals']for v in n)
   pointcounts[label]=pointcounts.get(label,0)+1
   if row['original']:
    xy=tuple(row['xy']);assert xy in original_set and xy not in originals.setdefault(label,set());originals[label].add(xy)
    if label==J['known_control_view']:calibration[str(xy[0])+','+str(xy[1])]=row
 assert set(views)==set(originals)==set(pointcounts)==expected_labels and all(v==original_set for v in originals.values())
 assert all(views[k]['points']==pointcounts[k]for k in expected_labels)
 comparisons=[]
 for xy,want in J['known_control_RGB'].items():
  actual=calibration[xy]['correct_and3negative_RGB'];assert len(actual)==len(want)==4
  for mode,got,rgb in zip(['correct','wrong-domain','omitted','swapped-role'],actual,want):
   error=max(abs(a-b)for a,b in zip(got,rgb));comparisons.append({'xy':xy,'mode':mode,'predicted':got,'prior_actual_GL_control':rgb,'RGB_error':error})
 state['prior_control_calibration']=comparisons;save();assert len(comparisons)==16 and max(r['RGB_error']for r in comparisons)<=3,('Predictor does not calibrate against all16immutable actual controls',comparisons)
 state['summary']={'CPU_forecast_views':68,'families':17,'original_points':272,'dense_frontmost_points':sum(pointcounts.values()),'calibrated_prior_PBR_triplets':16,'maximum_prior_RGB_error':max(r['RGB_error']for r in comparisons),'normals_or_materials_mutated':False,'new_GL_tests_executed':False,'Arc_executed':False,'MToon_estimates_not_graphically_calibrated':True,'witnesses_proposed_only':True}
 state['view_forecasts']=views;state['forecast_output']={'path':str(data),'sha256':sha(data),'bytes':data.stat().st_size};state['exit']=0
except BaseException as error:state['error']=repr(error)
finally:
 state['input_drift']=drift();state['exit']=state['exit']or int(bool(state['input_drift']));write(out/'inputs-final.json',pins)
 state['remaining_owned']=[v for row in state['steps']for v in row.get('known_processes',[])if monitor.alive(v)]if 'monitor'in globals()else[];state['exit']=state['exit']or int(bool(state['remaining_owned']))
 if lease:
  if 'lease'in state:state['lease']['released']=True
  fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
raise SystemExit(state['exit'])
