"""Derive one fresh full-TU compile plan; no compiler/linker/products run here."""
from pathlib import Path
import hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=P.parents[1];O=R/'artifacts/advanced-normal-graphics-build-20261117';S=R/'artifacts/advanced-normal-contrast-source-20261117'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(O/'plan-v1.json')=='94e7f7e90b8d22e6368b51d8fe2d0bcb9f924a587cacb7864533540f4c3692a0'
j=json.loads((O/'plan-v1.json').read_text());oldS=j['source_path'];source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();assert source=='4fbd74a4ed2556fca6a80b657a9c8d769e924db5'and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
old=source
for part in ['src','include','third_party']:
 assert subprocess.check_output(['git','rev-parse',source+':'+part],cwd=S,text=True).strip()==j['product_tree_exact_qualified_3d989'][part]
for role in ['compile','precheck']:
 argv=j[role]['argv'];original_D=[v for v in argv if v.startswith('-D')]
 j[role]['argv']=[v if v.startswith('-D')else v.replace(oldS,str(S)).replace(str(O),str(P))for v in argv]
 assert original_D==[v for v in j[role]['argv']if v.startswith('-D')]
 j[role]['cwd']=str(P);j[role]['depfile']=j[role]['depfile'].replace(str(O),str(P))
j['compile']['object']=str(P/'advanced-render.o')
for k in ['output','actual_linker_depfile','cwd']:j['link_HELD'][k]=j['link_HELD'][k].replace(str(O),str(P))
j['link_HELD']['argv']=[v.replace(str(O),str(P))for v in j['link_HELD']['argv']]
pins=dict(j['input_pins'])
for p,h in json.loads((O/'compile-inputs.json').read_text()).items():
 if p.startswith(oldS+'/'):
  new=Path(str(p).replace(oldS,str(S)));h=sha(new);p=str(new)
 elif p.startswith(str(O)+'/'):continue
 assert p not in pins or pins[p]==h,('Conflicting expected historical header/tool',p);assert sha(p)==h;pins[p]=h
for p in [O/'plan-v1.json',O/'compile-status.json',O/'compile-inputs.json',Path(__file__).resolve(),P/'compile-v1.py',S/'tests/source-advanced-normal-forecast.hpp',S/'tests/source-prepared-normal-render.cpp',S/'docs/validation/ADVANCED-NORMAL-CONTRAST-PLAN-20261117.json']:
 pins[str(p)]=sha(p)
assert sha(P/'compile-v1.py')=='506a6eb0400a4e30b47e80b7a1343074bea0e736a5fe79d0fb0351ff1ae13f3a'
j.update(source=source,source_path=str(S),state='prepared-NOT-compiled-or-linked',scope='One new complete existing renderer TU for genuine-material CPU forecast from4fbd; same qualified flags/providers/14tools. No forecast product or GL execution.',input_pins=pins)
j['environment']['TMPDIR']=str(P/'tmp');j['forecast_runtime_HELD']='CPU-only forecast product requires root slot/review after fresh compile/link; compare all16 recorded PBR correct/control triplets before accepting any proposed witness. Matrix and Arc unexecuted.'
assert not(P/'plan-v1.json').exists();(P/'plan-v1.json').write_text(json.dumps(j,indent=2)+'\n');print('SOURCE',source,'PLAN',sha(P/'plan-v1.json'),'DRIVER',sha(P/'compile-v1.py'),'pins',len(pins),'tools',len(j['tools']))
