"""Static CPU forecast admission plan: no ldd/consumer/GL invocation."""
from pathlib import Path
import hashlib,json,re,ast
P=Path(__file__).resolve().parent;R=P.parents[1]
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
pins={}
def pin(p,h):
 p=str(p);assert p not in pins or pins[p]==h,('Conflicting expected pins',p);assert sha(p)==h,('Input drift',p);pins[p]=h
status=P/'link-status-v1.json';assert sha(status)=='a7bcf50e55899ec1530d2f663ac02038aea6b409c69e9c8f1ee72f435da5823d';L=load(status);assert L['state']=='terminal'and L['exit']==0 and not L['input_drift']and L['static_ELF_contract_same']
for p,h in load(P/'link-inputs-final-v1.json').items():pin(p,h)
rt=R/'artifacts/guard87-validation-fresh-v2-20261115/runtime-preflight.json';assert sha(rt)=='949716280d10503f4899694790c1ade8779c7acce793b6f6c6d78408529129d4';runtime=load(rt);assert runtime['state']=='terminal'and runtime['exit']==0
for p,h in runtime['pins'].items():pin(p,h)
pin(runtime['owning_plan']['path'],runtime['owning_plan']['sha256'])
O=R/'artifacts/advanced-normal-graphics-build-20261117/software-v1-20261117';oldstatus=O/'status.json';oldlog=O/'advanced-render.log'
pin(oldstatus,'7795730dbfcd92c3b05d20fed02cc22444a61a945f5fcbf17594ae7f9a8ba4fb');pin(oldlog,'aac2fa9b1e09cdedd1b0391a944efd50845d537bb0e10cdc4a59aa098b29a0a2');old=load(oldstatus);assert old['exit']==1 and not old['input_drift']
view='mt1-rest-shared-raster-source-pbr';witnesses={}
for line in oldlog.read_text().splitlines():
 if not line.startswith('ADVANCED_GL_POINT label='+view+' '):continue
 xy=re.search(r' xy=(\d+,\d+) ',line).group(1);rgb=[]
 for k in ['correct','wrong-domain','omitted','swapped-role']:rgb.append(list(map(int,re.search(r' '+k+r'=(\d+),(\d+),(\d+)',line).groups())))
 witnesses[xy]=rgb
assert len(witnesses)==4 and sum(map(len,witnesses.values()))==16
for p in [status,P/'link-inputs-final-v1.json',P/'link-plan-v1.json',P/'link-unit-terminal-v1.txt',P/'link-unit-journal-v1.txt',P/'link-elf-metadata-v1.json',rt,P/'run-forecast-v1.py',Path(__file__).resolve()]:pin(p,sha(p))
pin(L['product']['path'],L['product']['sha256'])
for n in ['/usr/bin/ldd','/usr/bin/prlimit','/usr/bin/nice','/usr/bin/python3','/usr/bin/sh','/usr/bin/bash']:
 for p in [Path(n),Path(n).resolve()]:pin(p,sha(p))
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';pin(M,'b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269');ast.parse((P/'run-forecast-v1.py').read_text());J=load(P/'plan-v1.json')
families=[a+'-'+b+'-'+c+'-'+d for a in ['mt0','mt1']for b in ['rest','posed']for c in ['shared','seam']for d in ['raster','retained']]+['mt1-posed-seam-retained-three-edits']
env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','LD_LIBRARY_PATH':J['environment']['LD_LIBRARY_PATH'],'LP_NUM_THREADS':'2','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','LIBGL_ALWAYS_SOFTWARE':'1','EGL_PLATFORM':'surfaceless','XR_RUNTIME_JSON':str(P/'CPU-forecast-v1-20261117/no-physical-runtime.json')}
j={'state':'prepared-NOT-executed','source':J['source'],'scope':'One genuine-material68view CPU contrast forecast only; calibrate all16immutable priorordinaryPBRcontrolRGBtriplets before reporting candidateextra witnesses. No GLmatrix/Arc/UI/HMD/wholecandidate admission.','driver_sha256':sha(P/'run-forecast-v1.py'),'link_status':str(status),'product':L['product'],'input_pins':pins,'runtime_boundary':{'path':str(rt),'sha256':sha(rt),'pins':len(runtime['pins'])},'common_lease':'/tmp/dome-sculpt-arc-device.lock','monitor':str(M),'output':str(P/'CPU-forecast-v1-20261117'),'environment':env,'known_control_view':view,'known_control_RGB':witnesses,'known_control_RGB_order':['correct','wrong-domain','omitted','swapped-role'],'known_control_calibration_RGB_bound':3,'original_probes':[[48,48],[45,47],[49,45],[50,50]],'expected_view_labels':[f+'-'+stage+'-'+role for f in families for stage in ['source','target']for role in ['pbr','mtoon']],'bounds':{'jobs':1,'command_seconds':900,'AS_bytes':2*1024**3,'RSS_bytes':3*1024**3,'unit_MemoryMax_bytes':3*1024**3,'unit_RuntimeMax_seconds':1200,'core_bytes':0,'threads_each':2},'all_acceptance_bounds_unchanged':{'normal':.035,'RGB':3,'negative_gap':7,'negative_disjoint':True},'runtime_HELD':'Root review and coordinated productlease required; no actual GLmatrix orArc permitted by CPU-only plan.'}
assert not(P/'forecast-plan-v1.json').exists();(P/'forecast-plan-v1.json').write_text(json.dumps(j,indent=2)+'\n');print('PLAN',sha(P/'forecast-plan-v1.json'),'DRIVER',sha(P/'run-forecast-v1.py'),'PINS',len(pins),'knownRGBtriplets',sum(map(len,witnesses.values())));print('prior_controls',witnesses)
