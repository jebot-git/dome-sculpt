"""Only full-M precheck + one complete TU. Link and products remain held."""
from pathlib import Path
import argparse,hashlib,json,os,shlex,subprocess,importlib.util,time
P=Path(__file__).resolve().parent;R=P.parents[1]
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,d):
 t=p.with_suffix(p.suffix+'.writing');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
def main(args):
 assert sha(P/'plan-v1.json')==args.plan_sha and sha(__file__)==args.driver_sha
 plan=json.loads((P/'plan-v1.json').read_text());source=Path(plan['compile']['argv'][plan['compile']['argv'].index('-c')+1])if 'argv'in plan['compile']else Path(plan['compile']['command'][plan['compile']['command'].index('-c')+1])
 S=source.parents[1];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==plan['source']and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 for p in [plan['compile']['argv'][plan['compile']['argv'].index('-o')+1]if 'argv'in plan['compile']else plan['compile']['command'][plan['compile']['command'].index('-o')+1],plan['precheck']['depfile'],P/'compile-status.json']:assert not Path(p).exists(),('Do not restart/overwrite existing compile',str(p))
 pins=dict(plan['input_pins']);state={'state':'preparing','exit':1,'source':plan['source'],'scope':'Exactly one complete render TU + genuine full-M precheck; no link/product/GL execution','steps':[]};known=[]
 def add(path,want=None):
  path=str(path);value=sha(path);assert want is None or value==want,('Declared input drift',path);assert path not in pins or pins[path]==value,('Conflicting prior expected pin',path);pins[path]=value
 def save():write(P/'compile-status.json',state)
 monitor=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';add(monitor,'b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269')
 spec=importlib.util.spec_from_file_location('qualified_owned_monitor',monitor);mon=importlib.util.module_from_spec(spec);spec.loader.exec_module(mon)
 try:
  for p,h in list(pins.items()):add(p,h)
  for p in [Path(__file__).resolve(),P/'plan-v1.json',Path('/usr/bin/prlimit'),Path('/usr/bin/nice'),Path('/usr/bin/python3')]:add(p);add(p.resolve())
  for p,row in plan['tools'].items():add(p,row['sha256']);add(row['resolved'],row['sha256'])
  for part in ['src','include','third_party']:
   assert subprocess.check_output(['git','rev-parse',plan['source']+':'+part],cwd=S,text=True).strip()==subprocess.check_output(['git','rev-parse','3d989ef5:'+part],cwd=S,text=True).strip(),('Product source footprint changed',part)
  tmp=P/'tmp';tmp.mkdir(exist_ok=True,mode=0o700);env=dict(plan['environment']);state['environment']=env;save()
  def run(name,command):
   wrapped=['/usr/bin/prlimit','--as=2147483648','--core=0','--','/usr/bin/nice','-n','10',*command]
   def progress(row):state['live']={'name':name,**row};save()
   result=mon.run(wrapped,cwd=P,env=env,log=P/(name+'.log'),timeout=900,max_rss=3*1024**3,progress=progress);result.update(name=name,actual_compiler_command=command,cwd=str(P));state['steps'].append(result);state.pop('live',None);known.extend(result['known_processes']);save();assert result['exit']==0 and not result['signals']and not result.get('error'),(name,result)
  run('full-M-precheck',plan['precheck']['argv'])
  def roster(path):
   text=Path(path).read_text().replace('\\\n',' ');target,body=text.split(':',1);assert shlex.split(target)==[str(P/'advanced-render.o')]
   rows=[]
   for value in shlex.split(body):
    f=Path(value);f=f if f.is_absolute()else P/f;add(f);add(f.resolve());rows.append({'literal':value,'absolute_literal':str(f),'resolved':str(f.resolve()),'sha256':sha(f)})
   return rows
  pre=roster(plan['precheck']['depfile']);add(plan['precheck']['depfile']);save()
  run('compile-complete-render-TU',plan['compile']['argv'])
  actual=roster(plan['compile']['depfile']);assert actual==pre,('Actual compiler MD differs from full-M precheck',len(actual),len(pre))
  obj=P/'advanced-render.o';add(obj);add(plan['compile']['depfile']);state.update(exit=0,object={'path':str(obj),'sha256':sha(obj)},actual_MD={'path':plan['compile']['depfile'],'sha256':sha(plan['compile']['depfile']),'owners':1,'dependencies':actual},full_M={'path':plan['precheck']['depfile'],'sha256':sha(plan['precheck']['depfile'])},same_actual_full_header_roster=True)
 except BaseException as error:state.update(error=repr(error),exit=1)
 finally:
  drift=[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h];remaining=[r for r in known if mon.alive(r)];state.update(state='terminal',input_drift=drift,remaining_owned_processes=remaining);state['exit']=state['exit']or int(bool(drift)or bool(remaining));write(P/'compile-inputs.json',pins);state['inputs']={'path':str(P/'compile-inputs.json'),'sha256':sha(P/'compile-inputs.json')};save();print(json.dumps({k:state.get(k)for k in ['state','exit','error','input_drift','remaining_owned_processes']}),flush=True)
 return state['exit']
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--plan-sha',required=True);p.add_argument('--driver-sha',required=True);raise SystemExit(main(p.parse_args()))
