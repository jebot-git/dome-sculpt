"""One bounded CPU link + static ELF checks. Never execute a resulting product."""
import hashlib, importlib.util, json, os, re, shlex, subprocess, sys, time
from pathlib import Path
P=Path(__file__).resolve().parent

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n')
assert len(sys.argv)==2,'Pass the root-reviewed exact link-plan SHA256'
assert sha(P/'link-plan-v1.json')==sys.argv[1]
J=json.loads((P/'link-plan-v1.json').read_text());pins=dict(J['input_pins']);state={'state':'preflight','exit':None,'source':J['source'],'plan_sha256':sys.argv[1],'steps':[],'scope':J['scope']}
def save():write(P/'link-status-v1.json',state)
def drift():return [p for p,h in pins.items() if not Path(p).is_file() or sha(p)!=h]
def metadata(path):
 dynamic=subprocess.check_output(['/usr/bin/readelf','-dW',str(path)],env=J['environment'],text=True,timeout=30)
 symbols=subprocess.check_output(['/usr/bin/readelf','--dyn-syms','--wide',str(path)],env=J['environment'],text=True,timeout=30)
 tags={k:re.findall(r'\('+k+r'\).*?\[(.*?)\]',dynamic) for k in ['NEEDED','SONAME','RUNPATH','RPATH']}
 exports=[]
 for line in symbols.splitlines():
  cols=line.split()
  if len(cols)>=8 and cols[0].endswith(':') and cols[6]!='UND' and cols[4] in ['GLOBAL','WEAK']:
   exports.append([cols[7],cols[3],cols[4],cols[5]])
 return {'dynamic_tags':tags,'defined_dynamic_exports':sorted(exports),'raw_dynamic':dynamic,'raw_symbols':symbols}
try:
 assert sha(__file__)==J['driver_sha256'];assert not drift(),('Preflight input drift',drift())
 S=Path(J['source_path']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==J['source']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 C=json.loads(Path(J['compile_status']).read_text());assert C['state']=='terminal' and C['exit']==0 and C['same_actual_full_header_roster'] and not C['input_drift'] and not C['remaining_owned_processes']
 assert all(row['exit']==0 for row in C['steps'])
 for key in ['output','actual_linker_depfile']:assert not Path(J['command'][key]).exists(),('Existing output',key)
 assert not (P/'link-inputs-before-v1.json').exists(),'One-shot namespace already used'
 write(P/'link-inputs-before-v1.json',pins)
 M=Path(J['monitor']);spec=importlib.util.spec_from_file_location('qualified_link_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
 command=['/usr/bin/prlimit','--as=2147483648','--core=0','--','/usr/bin/nice','-n','10']+J['command']['argv']
 state['state']='linking';save()
 result=monitor.run(command,cwd=str(P),env=J['environment'],log=P/'link-v1.log',timeout=900,max_rss=3*1024**3,progress=lambda row:(state.update(live_link=row),save()))
 state['steps'].append(result);save();assert result['exit']==0 and not result.get('error'),result
 assert not [row for row in result.get('known_processes',[]) if monitor.alive(row)],'Owned process survives CPU link'
 dep=Path(J['command']['actual_linker_depfile']);text=dep.read_text().split('\n\n',1)[0].replace('\\\n',' ');target,tail=text.split(':',1);assert target.strip()==J['command']['output']
 actual=[]
 for literal in shlex.split(tail):
  path=Path(literal);path=path if path.is_absolute() else P/path;resolved=path.resolve();expected=pins.get(str(path),pins.get(str(resolved)));assert expected is not None,('Unbound actual linker provider',str(path),str(resolved))
  assert sha(path)==expected and sha(resolved)==expected,('Actual linker provider drift',str(path))
  actual.append({'literal':literal,'path':str(path),'resolved':str(resolved),'sha256':expected})
 state['actual_link_inputs']=actual;state['actual_link_depfile_sha256']=sha(dep)
 expected={r['resolved'] for r in J['expected_link_inputs']};observed={r['resolved'] for r in actual}
 state['link_roster_difference']={'added':sorted(observed-expected),'removed':sorted(expected-observed)}
 assert observed==expected,state['link_roster_difference']
 old=metadata(J['baseline_executable']['path']);new=metadata(J['command']['output'])
 write(P/'link-elf-metadata-v1.json',{'baseline':old,'fresh':new})
 assert old==J['baseline_ELF_metadata'],'Baseline metadata drift'
 for key in ['dynamic_tags','defined_dynamic_exports']:assert old[key]==new[key],('ELF contract differs',key,old[key],new[key])
 state['product']={'path':J['command']['output'],'sha256':sha(J['command']['output'])};state['static_ELF_contract_same']=True;state['exit']=0
except BaseException as error:state.update(exit=1,error=repr(error))
finally:
 state['input_drift']=drift();state['exit']=state['exit'] or int(bool(state['input_drift']));state['state']='terminal';write(P/'link-inputs-final-v1.json',pins);save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
raise SystemExit(state['exit'])
