"""Static derivation only: no compiler, linker, loader or graphical product."""
from pathlib import Path
import hashlib,json,subprocess,shlex,re
R=Path(__file__).resolve().parents[2];P=Path(__file__).resolve().parent

def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(p):return json.loads(Path(p).read_text())
pins={};provenance={}
def pin(p,h,origin):
 p=str(p);assert p not in pins or pins[p]==h,('Conflicting historical expectations',p);assert sha(p)==h,('Input drift',p);pins[p]=h;provenance.setdefault(p,[]).append(origin)
plan=P/'plan-v1.json';assert sha(plan)=='64fb570a600ae18885caa76c5a527c16550eebb776d630fa49bf05183eabc630';J=load(plan)
cp=P/'compile-status.json';assert sha(cp)=='c4542b32d5863036f8b63d477b07022ab6c390523ff01950a1f3295c9b19d2d3';C=load(cp);assert C['state']=='terminal'and C['exit']==0 and not C['input_drift']and not C['remaining_owned_processes']and C['same_actual_full_header_roster']
ci=P/'compile-inputs.json';assert sha(ci)=='f6746242b2ce8c8361c3ca2e2c14023c41e18f6db614c052da132f775f18a437'
for p,h in load(ci).items():pin(p,h,'actual complete TU/fullM compile successful input closure')
for p,h in J['input_pins'].items():pin(p,h,'reviewed initial contrast plan64fb')
W=R/'artifacts/native90-release-planning-20261115/release-090f00-20261117-audit/plan.json';w=load(W);assert sha(W)=='ccf9931035481459d7f51ec03e829ee2572e424d381d2bbc69a29c1fe26e1661'
B=Path(w['destination']);status=load(W.parent/'execution-native90-v1/status.json');owned=load(status['owned_outputs']['path']);assert status['exit']==0 and status['state']=='terminal'
public=R/'artifacts/advanced-public-normal-links-v2-20261117/link-plan.json';assert sha(public)=='fe5547f4bcbb028a702cda4d92cdd4ac665a275fee8d78d2e33768c5589d6cfe';pub=load(public)
for p,h in pub['expected_provider_provenance_files'].items():pin(p,h,'reviewed publicv2 qualified provider provenance')
cat=dict(w['pins'])
for p,h in pub['supplemental_expected_providers'].items():
 assert p not in cat or cat[p]==h;cat[p]=h
for row in J['link_HELD']['archive_roles']:pin(row['path'],row['sha256'],row['role'])
closure=load(P/'compile-closure-v1.json');pin(closure['object']['path'],closure['object']['sha256'],'actual complete renderer TU exit0')
dep=B/'CMakeFiles/dome-sculpt-source-prepared-normal-render-test.dir/link.d';literals=shlex.split(dep.read_text().split('\n\n')[0].replace('\\\n',' ').split(':',1)[1]);rows=[]
for literal in literals:
 path=Path(literal);path=path if path.is_absolute()else B/path
 if not Path(literal).is_absolute():
  if literal.startswith('CMakeFiles/'):path=Path(closure['object']['path']);expected=closure['object']['sha256'];origin='fresh complete renderer TU exit0'
  elif literal=='libdome-sculpt-core.a':row=next(r for r in J['link_HELD']['archive_roles']if r['path'].endswith('/'+literal));path=Path(row['path']);expected=row['sha256'];origin=row['role']
  else:expected=owned[literal];origin='actual whole090f owning output manifest'
 else:
  expected=cat.get(str(path),cat.get(str(path.resolve())));assert expected is not None,('Unbound historical provider',str(path));origin='whole090f plan pins'if str(path)in w['pins']or str(path.resolve())in w['pins']else'qualified supplemental17 catalog fe5547f4'
 for p in [path,path.resolve()]:pin(p,expected,origin)
 rows.append({'original_literal':literal,'path':str(path),'resolved':str(path.resolve()),'sha256':expected,'provenance':origin})
baseline=B/'dome-sculpt-source-prepared-normal-render-test';pin(baseline,owned[baseline.name],'actual whole090f owning output manifest')
for p in [plan,cp,ci,P/'compile-closure-v1.json',public,dep,Path(__file__).resolve(),P/'link-v1.py']:pin(p,sha(p),'control/proof explicitly bound before reviewed link execution')
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';pin(M,'b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269','qualified strict owner monitor')
for p in ['/usr/bin/readelf','/usr/bin/prlimit','/usr/bin/nice','/usr/bin/git','/usr/bin/python3']:
 for q in [Path(p),Path(p).resolve()]:pin(q,sha(q),'current control tool bound for review before execution')
dynamic=subprocess.check_output(['/usr/bin/readelf','-dW',str(baseline)],text=True,timeout=30);symbols=subprocess.check_output(['/usr/bin/readelf','--dyn-syms','--wide',str(baseline)],text=True,timeout=30)
exports=[]
for line in symbols.splitlines():
 cols=line.split()
 if len(cols)>=8 and cols[0].endswith(':')and cols[6]!='UND'and cols[4]in ['GLOBAL','WEAK']:exports.append([cols[7],cols[3],cols[4],cols[5]])
meta={'dynamic_tags':{k:re.findall(r'\('+k+r'\).*?\[(.*?)\]',dynamic)for k in ['NEEDED','SONAME','RUNPATH','RPATH']},'defined_dynamic_exports':sorted(exports),'raw_dynamic':dynamic,'raw_symbols':symbols}
j={'state':'prepared-NOT-linked-or-run','source':J['source'],'source_path':J['source_path'],'scope':'One fresh CPU Release link only; no resulting product, GL, ldd or loader execution. Preserved actual whole target command/library order/RPATH, fresh468-MD contrast renderer TU and qualified193-owner advanced core.','driver_sha256':sha(P/'link-v1.py'),'compile_status':str(cp),'command':J['link_HELD'],'expected_link_inputs':rows,'input_pins':pins,'input_provenance':provenance,'supplemental_catalog':{'path':str(public),'sha256':sha(public),'provenance':pub['supplemental_provider_provenance']},'baseline_executable':{'path':str(baseline),'sha256':owned[baseline.name]},'baseline_ELF_metadata':meta,'monitor':str(M),'bounds':{'jobs':1,'seconds':900,'AS_bytes':2*1024**3,'aggregate_RSS_bytes':3*1024**3,'core_bytes':0},'environment':J['environment'],'runtime_HELD':'Root review and common graphics lease required; no runtime authorized by this CPU plan.'}
assert not(P/'link-plan-v1.json').exists();(P/'link-plan-v1.json').write_text(json.dumps(j,indent=2)+'\n');print('LINK_PLAN',sha(P/'link-plan-v1.json'),'DRIVER',sha(P/'link-v1.py'),'pins',len(pins),'expectedincidences',len(rows),'uniqueResolved',len({r['resolved']for r in rows}),'exports',len(exports))
