from pathlib import Path
import shlex
import subprocess

work=Path(__file__).resolve().parent
build=work/'release'
commands=subprocess.check_output(['ninja','-C',build,'-t','commands','dome-sculpt-texture-set-source-export-test'],text=True).splitlines()
includes=[flag for flag in shlex.split(next(line for line in commands if line.endswith('/tests/texture-set-source-export.cpp'))) if flag.startswith('-I')]
link=shlex.split(commands[-1])[2:-2]
libs=['-lgcc_s' if flag=='-lgcc_s_asneeded' else str(build/flag) if flag.endswith('.a') else flag for flag in link[link.index('libdome-sculpt-core.a'):]]
with (work/'author-and-apply.log').open('w') as out:
    subprocess.run(['/usr/bin/c++','-std=c++20','-O2',*includes,work/'author-and-apply.cpp','-o',work/'author-and-apply',*libs],stdout=out,stderr=subprocess.STDOUT,check=True)
    subprocess.run([work/'author-and-apply',work/'plain-guide-for-worker.glb',work/'actual-authoring'],stdout=out,stderr=subprocess.STDOUT,check=True)
