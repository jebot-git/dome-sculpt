#include "dome/document.hpp"
#include "dome/import-authoring.hpp"
#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/retopo-authoring.hpp"
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc,char **argv) try {
  using namespace dome;
  if(argc!=3)return 2;
  const auto out=std::filesystem::absolute(argv[2]);
  std::filesystem::create_directories(out);
  ImportAuthoringOptions options;
  options.paint_resolution=64;
  options.prepare_texture_atlas=true;
  auto input=prepare_authoring_import(Scene{},argv[1],options);
  auto scene=std::move(input.scene);
  const auto original=input.objects.at(0);
  const auto donor=scene.add("Native material donor",Volume{});
  {
    auto &d=scene.object(donor);
    const auto &source=scene.object(original);
    d.group=source.group;
    d.transform=source.transform;
    auto geometry=source.painted->mesh();
    for(auto &p:geometry.positions)p.z+=.009f;
    d.mesh_active=true;
    d.painted=std::make_shared<PaintedMesh>(std::move(geometry),64);
    d.material.color={.36f,.22f,.11f,1};
    d.material.emissive={2.4f,.1f,.3f};
  }
  for(const auto &object:scene.objects())if(object.id!=original)scene.object(object.id).visible=false;
  scene.select(original);
  Document doc;
  const auto ready=[&]{
    if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
      throw std::runtime_error("Public worker: "+doc.frame().state->error);
  };
  doc.replace(scene);ready();
  ObjectBakeSettings bake;
  bake.allow_backfaces=true;bake.ao_samples=0;
  doc.bake_from_object(donor,bake);ready();
  auto baked=doc.copy_scene();
  auto &guide=baked.active();
  if(!guide.bake_recipe||guide.bake_recipe->source.object!=donor||!guide.painted->baked()||
     !guide.painted->baked()->emission_field||guide.painted->encode().at("version")!=8)
    throw std::runtime_error("Public Bake did not publish its actual imported guide and recipe");
  auto pose=std::make_shared<DeformationState>(*guide.deformation);
  pose->morph_weights[0]=.8f;
  guide.deformation=std::move(pose);
  const auto world=baked.world_matrix(original);
  const auto geometry=guide.deformation->preview(guide.painted->mesh());
  doc.replace(baked);ready();
  doc.begin_retopology();
  const auto draft=[&]{
    if(!doc.wait_retopology()||!doc.frame().state->retopology->error.empty())
      throw std::runtime_error("Public Retopology: "+doc.frame().state->retopology->error);
  };
  draft();
  for(auto point:geometry.positions){
    if(!doc.begin_desktop())throw std::runtime_error("Could not start native point gesture");
    const auto p=world.point({point.x*.83,point.y*.83,point.z});
    Brush brush;brush.from=brush.to={float(p[0]),float(p[1]),float(p[2])};brush.radius=.01f;
    doc.stamp_desktop(brush);doc.end_desktop();draft();
  }
  doc.edit_retopology(RetopoAction::Face);draft();
  doc.end_retopology(true);ready();
  doc.save_async(out/"actual-authored-bake.dsculpt").get();
  const auto outcome=Scene::load(out/"actual-authored-bake.dsculpt");
  const auto &linked=outcome.object(original);
  if(!outcome.active().retopology||outcome.active().retopology->source!=original||
     !outcome.active().painted->baked()||!linked.bake_recipe||linked.bake_recipe->source.object!=donor||
     linked.visible||!linked.painted->baked()||linked.painted->encode()!=guide.painted->encode())
    throw std::runtime_error("Retopology changed the genuine Bake recipe or original imported guide");
  doc.export_asset(out/"actual-authored-bake.glb",AssetExportFormat::Glb).get();
  std::cout<<"PASS public Bake and first Retopology Apply on the posed imported guide preserve its donor recipe and exact Paint8 payload\n";

  auto reuse=outcome;
  const auto recipient=reuse.add("Native recipient of an imported Bake",Volume{});
  {
    const auto &source=reuse.object(original);
    auto &target=reuse.object(recipient);
    target.group=source.group;
    target.transform=source.transform;
    auto mesh=source.deformation->preview(source.painted->mesh());
    for(auto &p:mesh.positions)p.z-=.004f;
    target.mesh_active=true;
    target.painted=std::make_shared<PaintedMesh>(std::move(mesh),64);
  }
  reuse.select(recipient);
  doc.replace(reuse);ready();
  doc.bake_from_object(original,bake);ready();
  const auto transferred=doc.copy_scene();
  const auto &result=transferred.active();
  if(!result.bake_recipe||result.bake_recipe->source.object!=original||!result.painted->baked()||
     result.painted->baked()->maps.normal.rgba.empty()||!result.painted->baked()->emission_field||
     transferred.object(original).painted->encode()!=guide.painted->encode())
    throw std::runtime_error("Reusing the imported Bake as a native donor lost its paired material or normal data");
  std::cout<<"PASS the previously baked imported guide also donates a normal and FLOAT emission Bake through the public worker\n";

} catch (const std::exception &e) {std::cerr<<e.what()<<'\n';return 1;}
