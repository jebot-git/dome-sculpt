#!/usr/bin/bash
set -euo pipefail
profile="$1"
run="$2"
out="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$out/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/$profile"
sdk=/opt/fltk-vr/toolkit
if [[ "$profile" == asan ]]; then sdk="$repo/artifacts/sdk-20261126/toolkit-sanitize"; fi
prefix=(bwrap --die-with-parent --unshare-all --ro-bind / / --bind "$out/$profile" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH "$sdk/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64" --setenv ASAN_OPTIONS detect_leaks=1:halt_on_error=1 --setenv UBSAN_OPTIONS halt_on_error=1:print_stacktrace=1 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
if [[ "$profile" == asan ]]; then
    "${prefix[@]}" cmake --build "$seed" --parallel 6 --target dome-sculpt-retopo-surface-heat-test dome-sculpt-texture-set-source-export-test > "$out/$profile-$run-build.log" 2>&1
else
    "${prefix[@]}" cmake --build "$seed" --parallel 4 --target dome-sculpt dome-sculpt-texture-set-source-export-test dome-sculpt-vrm1-source-export-test dome-sculpt-retopo-affine-test dome-sculpt-retopo-save-handoff-test dome-sculpt-retopo-held-admission-test dome-sculpt-retopo-authority-admission-test dome-sculpt-test-runtime dome-sculpt-retopo-surface-heat-test dome-sculpt-retopo-authoring-test dome-sculpt-canonical-paint-color-hdr-test dome-sculpt-retopo-history-openxr-test dome-sculpt-texture-set-surfaces-test dome-sculpt-texture-set-export-test dome-sculpt-gltf-test dome-sculpt-normal-frame-export-test dome-sculpt-baked-emission-workflow-test dome-sculpt-baked-emission-native-test dome-sculpt-bake-cage-test dome-sculpt-bake-cage-polygon-test dome-sculpt-bake-recipes-test dome-sculpt-native-paint32-export-test dome-sculpt-native-paint32-skin-export-test dome-sculpt-native-paint-key-frames-test dome-sculpt-source8-preview-test > "$out/$profile-$run-build.log" 2>&1
fi
"${prefix[@]}" ctest --test-dir "$seed" --parallel "${3:-2}" -R "${4:-^retopology-first-material-}" --output-on-failure > "$out/$profile-$run.log" 2>&1
