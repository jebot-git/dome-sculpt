from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'
fixture = Path('retopology-imported-prior-bake')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def git(path):
    return subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()


def read(name):
    return json.loads((work / name).read_text())


baseline = 'baseline-fixture.log'
assert 'FAIL Artist source normal capture requires its unchanged original frame and separate current-normal adapter' in (work / baseline).read_text()
archive_files = [
    'record.py', 'check-profile.sh', 'check-extended.sh', baseline,
    'author-and-apply.cpp', 'author-and-apply.py', 'plain-guide-for-worker.glb', 'author-and-apply.log',
    'run-wayland.py', 'wayland-first-material.py', 'bind-wayland.log', 'wayland-first-material/report.json',
    'wayland-first-material/corners.json', 'wayland-first-material/source-viewport.png',
    'run-render.py', 'xr-first-material.py', 'khronos.cjs', 'khronos.json', 'khronos.log',
]
runs = {}
measurements = {}
for profile, label, count in [('release', 'final', 60), ('asan', 'qualified', 12)]:
    name = f'{profile}-{label}.log'
    log = (work / name).read_text()
    tests = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', log)
    assert len(tests) == len(set(tests)) == count and f'0 tests failed out of {count}' in log
    assert str(fixture) in tests
    runs[profile] = tests
    test_log = (work / profile / 'Testing/Temporary/LastTest.log').read_text()
    match = re.search(r'^\d+/\d+ Testing: retopology-imported-prior-bake\n(.*?)^Test Passed\.', test_log, re.M | re.S)
    assert match
    controls = match[1]
    samples, peak, normal_dot, partial = re.search(
        r'^IMPORTED_PBR interior=(\d+) peak=([\d.]+) min_normal_dot=([\d.]+) partial=(\d+)$', controls, re.M).groups()
    assertions = re.search(r'^PASS (\d+) imported material retopology checks$', controls, re.M)[1]
    assert int(assertions) == 865 and int(samples) == 86 and int(partial) > 30
    measurements[profile] = {'checks': int(assertions), 'interior_samples': int(samples),
                             'partial_coverage_samples': int(partial), 'minimum_normal_dot_rounded': float(normal_dot),
                             'peak_red_radiance_rounded': float(peak)}
    controls_name = f'{profile}-native-controls.log'
    (work / controls_name).write_text(controls)
    archive_files += [name, f'{profile}-{label}-build.log', controls_name]
assert measurements['release'] == measurements['asan']

outputs = {}
for file in ('original-import.glb', 'raw-guide.dsculpt', 'raw-patch.dsculpt', 'raw-standard.glb', 'raw-editable.glb'):
    path = fixture / file
    outputs[file] = digest(work / 'release' / path)
    assert outputs[file] == digest(work / 'asan' / path)
worker = (work / 'author-and-apply.log').read_text().splitlines()
assert len(worker) == 2 and all(line.startswith('PASS ') for line in worker)
worker_outputs = {name: digest(work / 'actual-authoring' / name)
                  for name in ('actual-authored-bake.dsculpt', 'actual-authored-bake.glb')}

wayland = read('wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks']) == 7 and all(row['passed'] for row in wayland['checks'])
validator = read('khronos.json')
assert len(validator['results']) == 5
for row in validator['results']:
    assert row['issues']['numErrors'] == row['issues']['numWarnings'] == 0
    row['sha256'] = digest(work / row['file'])

stereo = {}
for gpu in ('arc', 'software'):
    path = f'xr-{gpu}-affine/compare.json'
    evidence = read(path)
    assert evidence['runtime'] == 'synthetic OpenXR' and evidence['exact_ordered_close']
    assert len(evidence['profiles']) == 2
    for profile in evidence['profiles']:
        assert profile['stereo_submissions'] == 6 and profile['action_syncs'] == 7
        assert profile['acquires'] == profile['image_waits'] == profile['releases'] == 12
    assert min(evidence['differing_rgb_components_per_eye']) > 100
    stereo[gpu] = {'renderer': evidence['profiles'][0]['gl_renderer'], 'stereo_submissions_per_project': 6,
                   'differing_rgb_components_per_eye': evidence['differing_rgb_components_per_eye'],
                   'authoring_pixels_per_eye': evidence['material_pixels_per_eye'], 'exact_ordered_close': True}
    archive_files += [path, f'verified-affine-{gpu}.log']

archive = validation / (work.name + '.tar.gz')
members = {}
with tarfile.open(archive, 'w:gz', compresslevel=9) as out:
    for file in archive_files:
        data = (work / file).read_bytes()
        members[file] = sha256(data).hexdigest()
        entry = tarfile.TarInfo(file)
        entry.size = len(data)
        out.addfile(entry, io.BytesIO(data))

receipt = {
    'product': git(repo), 'previous_product': 'c5caba2f33f12d598c8f3ca588c59c616d4a5aa7',
    'previous_main': '49443e7431a4df7efb8a5ed568756c89dc627e90', 'canonical_domed': git(repo.parent / 'DomeD'),
    'canonical_compositor_sha256': digest(work.parent / 'creator-public-build-20261126/wayland-reference/dome-compositor'),
    'release_app_sha256': digest(work / 'release/dome-sculpt'),
    'strict_asan_ubsan_test_sha256': digest(work / 'asan/dome-sculpt-texture-set-source-export-test'),
    'test_results': runs, 'native_measurements': measurements, 'identical_native_and_glb_outputs_sha256': outputs,
    'public_worker': {'checks': worker, 'outputs_sha256': worker_outputs},
    'wayland': wayland, 'synthetic_stereo': stereo, 'physical_headset': False, 'khronos': validator,
    'archive_sha256': digest(archive), 'archive_members_sha256': members,
}
(validation / (work.name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
