import pathlib,json,subprocess,os,time,hashlib
out=pathlib.Path(__file__).resolve().parent;plan=json.load(open(out/'plan.json'));sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def drift():return[p for p,h in plan['pins'].items()if not pathlib.Path(p).is_file()or sha(p)!=h]
status={'state':'running','scope':plan['scope'],'source':plan['source'],'production':plan['production'],'driver_sha256':sha(__file__),'plan_sha256':sha(out/'plan.json'),'steps':[],'input_drift':drift()}
def save():(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
try:
 assert not status['input_drift'];env=os.environ.copy()
 for k in ['CPATH','C_INCLUDE_PATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','GCC_SPECS','CC','CXX','AR','RANLIB','LD','CFLAGS','CXXFLAGS','CPPFLAGS','LDFLAGS','LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','CMAKE_PREFIX_PATH']:env.pop(k,None)
 for k,v in plan['environment'].items():
  if v is None:env.pop(k,None)
  else:env[k]=v
 for name in ['compile','link']:
  assert not drift();started=time.monotonic()
  with (out/(name+'.log')).open('w')as log:r=subprocess.run(plan[name+'_argv'],cwd=plan[name+'_cwd'],env=env,stdout=log,stderr=subprocess.STDOUT)
  status['steps'].append({'name':name,'argv':plan[name+'_argv'],'cwd':plan[name+'_cwd'],'exit':r.returncode,'seconds':time.monotonic()-started,'log_sha256':sha(out/(name+'.log'))});save();assert r.returncode==0
 status['object_sha256']=sha(plan['object']);status['MD_sha256']=sha(plan['MD']);status['executable_sha256']=sha(plan['executable']);status.update(exit_code=0,state='complete')
except BaseException as e:status.update(exit_code=1,state='failed',error=repr(e))
finally:
 status['input_drift']=drift();
 if status['input_drift']:status.update(exit_code=1,state='failed')
 save()
raise SystemExit(status['exit_code'])
