from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
from owned_monitor import run

here = Path(__file__).resolve().parent
build = json.loads((here/'build-status.json').read_text())
assert build['terminal'] and build['exit']==0
assert not Path('/dev/dri').exists()
assert not any(k in os.environ for k in ('MALLOC_ARENA_MAX','GLIBC_TUNABLES','MALLOC_MMAP_THRESHOLD_'))
out=here/'native'
out.mkdir()
state={'terminal':False,'cases':{}}
def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def save():
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
cases=[
 ('paged-ray','dome-sculpt-native-paged-ray-test',[],r'^[1-9][0-9]* native paged-ray cancel/stale/shutdown checks passed$',600),
 ('surface','dome-sculpt-sculpt-surface-chunks-test',[],r'^26 sculpt chunk checks passed$',900),
 ('pipeline','dome-sculpt-sculpt-chunk-pipeline-test',[str(out/'pipeline')],r'^PASS total 94$',900),
 ('sculpt','dome-sculpt-sculpt-independent-workflow',[str(out/'sculpt')],r'^PASS independent production sculpt workflow checks=167',900)
]
try:
    elf=here/'dome-sculpt'
    version=subprocess.run([elf,'--version'],capture_output=True,text=True,check=True)
    state['app']={'sha256':sha(elf),'version':version.stdout.strip()}
    for name,exe,args,pattern,timeout in cases:
        log=out/(name+'.log')
        row=run([str(here/exe),*args],cwd=out,env=os.environ.copy(),log=log,timeout=timeout,max_rss=4*1024**3)
        row.update(check_passed=bool(re.search(pattern,log.read_text(),re.M)),sha256=sha(here/exe))
        state['cases'][name]=row
        save()
    state['exit']=int(any(v['exit'] or not v['check_passed'] or 'error' in v for v in state['cases'].values()))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
