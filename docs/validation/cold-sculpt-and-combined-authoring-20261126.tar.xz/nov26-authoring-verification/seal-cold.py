from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

artifacts=Path(__file__).resolve().parents[1]
docs=artifacts.parent/'docs/validation'
component=artifacts/'sculpt-cold-representatives-release-v3-20261126'
combined=artifacts/'production-cold-sculpt-projection-release-20261126'
strict=artifacts/'sculpt-cold-representatives-strict-20261126'
sdf=artifacts/'authoring-sdf-dormant-regression-20261126'
def load(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
def verify(directory,source_name,rev):
    source=artifacts/source_name
    actual=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
    patch=subprocess.check_output(['git','-C',str(source),'diff','--binary','c90c9fed','HEAD'])
    assert actual.startswith(rev)
    plan=load(directory/'build-plan.json')
    build=load(directory/'build-status.json')
    native=load(directory/'native/status.json')
    assert hashlib.sha256(patch).hexdigest()==plan['source_diff_sha256']
    assert all(x['terminal'] and x['exit']==0 for x in (build,native))
    assert sha(directory/'libdome-sculpt-core.a')==build['linked_archive']['sha256']
    assert sha(directory/'dome-sculpt')==native['app']['sha256']
    assert '90 native paged-ray' in (directory/'native/paged-ray.log').read_text()
    projects={str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted((directory/'native/sculpt').rglob('*.dsculpt'))}
    assert len(projects)==3 and all(x['sha256']=='d32c725a02d3d9291f3208c879f78ecc343c33511de9e10b5c18d93bb95fd694' for x in projects.values())
    return {'source':actual,'build':build,'native':native,'exact_projects':projects}
r=verify(component,'sculpt-cold-representatives-source-20261126','7b009c92')
c=verify(combined,'production-cold-sculpt-projection-source-20261126','e375b31d')
assert len(c['native']['cases'])==6 and all(x['check_passed'] for x in c['native']['cases'].values())
negative=artifacts/'sculpt-cold-representatives-release-v2-20261126/native/paged-ray.log'
assert 'initial chunk and ordered-run indexes (steps=16000000, limit=16000000)' in negative.read_text()
assert (sdf/'exit').read_text().strip()=='0' and 'PASS 22 new native physical contracts' in (sdf/'product.log').read_text()
strict_state=load(strict/'native/status.json')
strict_log=strict/'native/paged-ray.log'
assert '90 native paged-ray' in strict_log.read_text() and all(strict_state['cases'][name]['exit']==0 and strict_state['cases'][name]['check_passed'] for name in ('paged-ray','surface','pipeline'))
paths=[negative,*[sdf/f for f in ('build.py','commands.json','exit','product.log')],Path(__file__),strict_log]
paths+=sorted((strict/'native').glob('surface.log'))+sorted((strict/'native').glob('pipeline.log'))
paths += [strict/f for f in ('build-plan.json','build-status.json','run-native.py')]
for folder in (component,combined):
    paths += [folder/f for f in ('prepare.py','build.py','run-native.py','build-plan.json','build-status.json','native/status.json')]
    paths += sorted((folder/'native').glob('*.log'))
    paths += sorted((folder/'src').glob('*.d'))
for unit in ('ds-sculpt-cold-representatives-diagnostic-run-20261126',
             'ds-sculpt-cold-representatives-native-v3-20261126',
             'ds-production-cold-sculpt-projection-release-20261126'):
    journal=Path(__file__).parent/(unit+'.journal')
    journal.write_bytes(subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager']))
    assert b'Started' in journal.read_bytes()
    paths.append(journal)
assert any(b'chunk assembly and ordered runs (steps=16000000, limit=16000000)' in f.read_bytes() for f in paths if f.suffix=='.journal')
dest=docs/'cold-sculpt-and-combined-authoring-20261126.tar.xz'
manifest={}
with tarfile.open(dest,'w:xz',preset=6) as ar:
    for p in paths:
        name=str(p.relative_to(artifacts));data=p.read_bytes()
        assert name not in manifest
        manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
        info=tarfile.TarInfo(name);info.size=len(data)
        ar.addfile(info,io.BytesIO(data))
with tarfile.open(dest,'r:xz') as ar:
    assert set(ar.getnames())==set(manifest)
    for info in ar:
        assert info.size==manifest[info.name]['bytes']
        assert hashlib.file_digest(ar.extractfile(info),'sha256').hexdigest()==manifest[info.name]['sha256']
receipt={'scope':'Original paged native ray test on unchanged 16-million-step budget, full native sculpt fixture, and combined Release cut and projection controls. Three completed scoped sanitizer cases on the cold sculpt source. The full sanitizer workflow has its own later outcome.',
         'component':r,'combined':c,'strict_scoped':{n:strict_state['cases'][n] for n in ('paged-ray','surface','pipeline')},
         'sdf_controls':22,'authorities':manifest,'archive':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest)}}
dest.with_name(dest.name.replace('.tar.xz','.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(len(manifest),receipt['archive'])
