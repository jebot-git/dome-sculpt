from pathlib import Path
import os,sys,json,time,hashlib,subprocess,fcntl,re
from owned_monitor import run

O=Path(__file__).resolve().parent;B=O.parent
plan=json.loads((O/'plan.json').read_text());steps=plan['steps']
if '--without-advanced' in sys.argv:steps=[x for x in steps if x['name']!='source-advanced-normal-bake']
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
env=dict(os.environ,DOME_TEST_FILTERED_TIMING='1',LD_LIBRARY_PATH='/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
 LIBGL_ALWAYS_SOFTWARE='1',EGL_PLATFORM='surfaceless',LP_NUM_THREADS='2',
 OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MALLOC_ARENA_MAX='2',
 MALLOC_MMAP_THRESHOLD_='131072',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',
 UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
assert not env.get('LD_PRELOAD') and not env.get('LSAN_OPTIONS')
status={'terminal':False,'source':plan['source'],'scope':plan['scope'],'steps':[],
 'AS_cap':None,'environment':{k:env[k] for k in ['LD_LIBRARY_PATH','ASAN_OPTIONS','UBSAN_OPTIONS','LIBGL_ALWAYS_SOFTWARE','EGL_PLATFORM']}}
def save():(O/'status.json').write_text(json.dumps(status,indent=2)+'\n')
save();lock=os.open('/tmp/dome-sculpt-arc-device.lock',os.O_RDWR|os.O_CREAT,0o600)
try:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 st=os.fstat(lock);status['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino};save()
 for case in steps:
  name=case['name'];exe=Path(case['command'][0]);wanted=sha(exe)
  ld=run(['/usr/bin/ldd',str(exe)],cwd=B,env=env,log=O/(name+'.ldd'),timeout=60,max_rss=case['max_rss'])
  ld['name']=name+'-ldd';status['steps'].append(ld);save();assert ld['exit']==0,ld
  text=(O/(name+'.ldd')).read_text();assert 'not found' not in text
  providers={}
  for path in re.findall(r'(?:=>\s+)?(/[^\s()]+)',text):
   if Path(path).is_file():providers[path]=sha(path)
  handles={};witness={}
  def observe(row):
   pid=row['pid']
   try:
    if pid not in handles:
     handles[pid]=os.open('/proc/'+str(pid)+'/exe',os.O_RDONLY)
    maps=Path('/proc',str(pid),'maps').read_text()
    if '/libasan.so' in maps and '/libubsan.so' in maps and not witness:
     witness.update(pid=pid,start=row['start'],live_ASan_UBSan=True)
     (O/(name+'.maps')).write_text(maps)
   except (FileNotFoundError,ProcessLookupError):pass
   status['live']={'name':name,**row};save()
  row=run(case['command'],cwd=B,env=env,log=O/(name+'.log'),timeout=case['timeout_seconds'],max_rss=case['max_rss'],progress=observe)
  for fd in handles.values():
   with os.fdopen(fd,'rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
   assert actual==wanted,'Actual executed ELF differs'
  row.update(name=name,ELF_sha256=wanted,sanitizer_witness=witness,providers=providers)
  output=(O/(name+'.log')).read_text()
  numbers={int(n) for group in re.findall(r'\bPASS\s+(\d+)\b|\b(\d+)\s+checks\b|\bchecks[=: ]+(\d+)\b',output,re.I) for n in group if n}
  literal_passes=sum(line.startswith('PASS ') for line in output.splitlines())
  row['reported_numbers']=sorted(numbers);row['literal_PASS_lines']=literal_passes
  row['expected_checks']=case['expected_checks']
  status['steps'].append(row);status.pop('live',None);save()
  assert row.get('exit')==0 and 'error' not in row,(name,row)
  assert witness.get('live_ASan_UBSan'),name+' lacks live sanitizer witness'
  assert case['expected_checks'] in numbers or literal_passes==case['expected_checks'],name+' check total mismatch'
  assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:',output),name+' sanitizer report'
  assert sha(exe)==wanted and all(sha(p)==h for p,h in providers.items()),name+' runtime input drift'
 status.update(terminal=True,exit=0)
except BaseException as e:
 status.update(terminal=True,exit=1,error=repr(e))
finally:
 if 'lease' in status:status['lease']['released']=time.time()
 save();os.close(lock)
print(json.dumps({'terminal':status['terminal'],'exit':status['exit'],'error':status.get('error'),'cases':len(status['steps'])}),flush=True)
raise SystemExit(status['exit'])
