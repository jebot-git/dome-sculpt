import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
validation = repo / 'docs' / 'validation'
label = root.name
release = root / 'release'
asan = root / 'asan'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def revision(path):
    return subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip()

def result(name, expected):
    logged=(root/f"{name}-qualified.log").read_text()
    tests=re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',logged)
    assert len(set(tests)) == len(tests) == expected and f'0 tests failed out of {expected}' in logged
    return tests
release_tests=result('release',61)
sanitizer_tests=result('asan',8)
native={}
outputs={}
expected=['color-before.dsculpt','color-after.dsculpt','color-common-control.dsculpt',
          'color-standard.glb','color-editable.glb','color-normal-cleared.dsculpt','color-normal-flat-control.dsculpt',
          'color-normal-unconverted.dsculpt','color-normal-converted.dsculpt',
          'retained-uv-source.dsculpt','retained-uv.dsculpt','retained-uv-standard.glb']
for case in ['plain','affine']:
    scope=f'retopology-prepared-color-normal-uv-{case}'
    for mode, build in [('Release',release),('ASan/UBSan',asan)]:
        log=(build/'Testing/Temporary/LastTest.log').read_text()
        match=re.search(r'^\d+/\d+ Testing: '+scope+r'\n(?P<body>.*?)^Test Passed\.',log,re.M|re.S)
        assert match,(mode,scope)
        body=match['body']
        for witness in ['Save, cold Open and Undo/Redo preserve both field owners after each UV edit',
                        'Rebake writes both prepared fields','Restore and Undo recover the exact paired source',
                        'Both emitted texture roles carry the original ordered UV sequence']:
            assert witness in body,(mode,scope,witness)
        checks=int(re.search(r'^PASS (\d+) retopology Surface Heat controls$',body,re.M)[1])
        native.setdefault(case,{})[mode]=checks
        (root/f'{mode.split("/")[0].lower()}-{case}-controls.log').write_text(body)
    for file in expected:
        name=f'{scope}/{file}'
        value=(release/name).read_bytes()
        assert value==(asan/name).read_bytes(),name
        outputs[name]=sha(value)

wayland = json.loads((root/'wayland-uv/report.json').read_text())
assert wayland['complete'] and all(check['passed'] for check in wayland['checks'])
stereo = {}
for mode in ['software','arc']:
    for case in ['plain','affine']:
        key = f'{mode}-{case}'
        proof = json.loads((root/f'xr-{key}/compare.json').read_text())
        stereo[key] = {'renderer':proof['profiles'][0]['gl_renderer'],
                       'frame_counts':[x['stereo_submissions'] for x in proof['profiles']],
                       'exact_rgb_components':proof['exact_rgb_components_per_eye'],
                       'exact_native_save':proof['exact_ordered_close']}

khronos = json.loads((root/'khronos.json').read_text())
portable = {p['file']:{'errors':p['report']['issues']['numErrors'],
                        'warnings':p['report']['issues']['numWarnings'],
                        'resolved_material_and_explicit_tangent':p['resolved'],
                        'warning_codes':[m['code'] for m in p['report']['issues']['messages'] if m['severity']==1]}
            for p in khronos['results']}
assert len(portable)==6 and not any(p['errors'] or p['warnings'] for p in portable.values())
files=['release-qualified.log','release-qualified-build.log','asan-qualified.log','asan-qualified-build.log',
       'release-plain-controls.log','release-affine-controls.log','asan-plain-controls.log','asan-affine-controls.log',
       'khronos.json','khronos.cjs','check-profile.sh','run-render.py','xr-prepare.py','record.py',
       'run-wayland.py','wayland-uv.py','bind-wayland.log','wayland-uv/report.json',
       *[f'xr-{key}/compare.json' for key in stereo]]
archive = validation/f'{label}.tar.gz'
archived = {}
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
    for name in files:
        data = (root/name).read_bytes()
        archived[name] = sha(data)
        path=tarfile.TarInfo(name)
        path.size=len(data)
        tar.addfile(path,io.BytesIO(data))
summary = {'product':revision(repo),
           'canonical_domed':revision(repo.parent/'DomeD'),
           'canonical_domed_compositor_sha256':sha((root.parent/'creator-public-build-20261126/wayland-reference/dome-compositor').read_bytes()),
           'release_fltk':'/opt/fltk-vr/toolkit',
           'release_app_sha256':sha((release/'dome-sculpt').read_bytes()),
           'release_tests':release_tests,
           'strict_asan_ubsan_tests':sanitizer_tests,
           'native_color_checks':native,
           'byte_identical_release_and_sanitizer':outputs,
           'wayland':wayland,
           'synthetic_openxr':stereo,
           'khronos_version':khronos['version'],
           'khronos':portable,
           
           'combined_release_earlier_revisions':{name:json.loads((root.parent/name/'combined-release/status.json').read_text())
             for name in ['retopology-subdivide-20261127','retopology-prepared-color-20261127']},
           'physical_headset':False,
           'archive_sha256':sha(archive.read_bytes()),
           'archive_members_sha256':archived}
(validation/f'{label}.json').write_text(json.dumps(summary,indent=2)+'\n')
