from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
resolution=int(sys.argv[2])
masked=artifacts/'vrm1-unlit-mask-paint-validation-20261126'
support=(masked/'combined-release' if profile=='release' else artifacts/'core-gltf-normal-export-asan-20261126')
core=support/'libdome-sculpt-core.a' if profile=='release' else masked/'asan-verified-final/libdome-sculpt-core.a'
source=artifacts/'hdr-preview-shared-ownership-source-20261126'
out=base/f'{profile}-{resolution}'
out.mkdir(mode=0o700)


def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


status={'terminal':False,'profile':profile,'resolution':resolution,'candidate':git('rev-parse','HEAD'),
        'parent':git('rev-parse','HEAD^'),'invocation':os.getenv('INVOCATION_ID'),'core_sha256':sha(core)}


def record(**fields):
    status.update(fields)
    temp=out/'status.tmp'
    temp.write_text(json.dumps(status,indent=2)+'\n')
    temp.replace(out/'status.json')


def invoke(cmd, filename, timeout=None, check=True):
    with (out/filename).open('a') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        return subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=check)


try:
    assert git('diff','--name-only','d257ea07','HEAD').splitlines()==['include/dome/paint.hpp','src/paint.cpp','tests/composite-cache.cpp'] and not git('status','--porcelain')
    record(phase='compile complete paint translation unit and native test')
    entries=json.loads((support/'compile_commands.json').read_text())
    for suffix, target, path in [('src/paint.cpp','paint.o',source/'src/paint.cpp'),
                                 ('tests/source-joint-writable-normal-bake.cpp','probe.o',base/'probe.cpp')]:
        entry=next(x for x in entries if x['file'].endswith('/'+suffix))
        old=str(Path(entry['file']).parents[1])
        cmd=shlex.split(entry['command'])
        cmd=[x.replace(old,str(source)) for x in cmd]
        cmd[cmd.index(str(source/suffix))]=str(path)
        cmd[cmd.index('-o')+1]=str(out/target)
        invoke(cmd,'compile.log',timeout=300)
    target='dome-sculpt-source-joint-writable-normal-bake-test'
    raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
    base_cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
    base_cmd[base_cmd.index(core.name)]=str(core)
    old_obj=next(x for x in base_cmd if x.endswith('/source-joint-writable-normal-bake.cpp.o'))
    base_cmd[base_cmd.index(old_obj)]=str(out/'probe.o')
    for mode in ('parent','candidate'):
        cmd=base_cmd.copy()
        cmd[cmd.index('-o')+1]=str(out/mode)
        link_map=out/f'{mode}.map'
        cmd.append(f'-Wl,-Map,{link_map}')
        if mode=='candidate':
            cmd.insert(cmd.index(str(core)),str(out/'paint.o'))
        invoke(cmd,'link.log',timeout=240)
        map_text=link_map.read_text()
        assert (str(core)+'(paint.cpp.o)' in map_text)==(mode=='parent')
    input_profile='asan' if resolution==2048 else 'release'
    project=artifacts/'hdr-strict-full-size-checkpoints-validation-20261126'/f'{input_profile}-{resolution}'/'capture/observed-second-bake.dsculpt'
    input_digest=sha(project)
    cases={}
    for mode in ('parent','candidate'):
        record(phase='composite '+mode,source_sha256=input_digest,results=cases)
        result=out/f'{mode}-planes'
        result.mkdir(mode=0o700)
        cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',result,result,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
             '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
             '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1','--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',
             out/mode,project,result]
        log=f'{mode}.log'
        invoke(cmd,log,timeout=900)
        lines=(out/log).read_text()
        timings=re.search(r'^PREVIEW seconds=([.0-9]+) cpu_seconds=([.0-9]+) (.*)$',lines,re.M)
        assert timings and 'PASS actual HDR baked preview planes' in lines
        cases[mode]={'executable_sha256':sha(out/mode),'preview_elapsed':float(timings[1]),'preview_cpu':float(timings[2]),
                     'metadata':timings[3],'planes':{f.name:sha(f) for f in sorted(result.iterdir())}}
        assert len(cases[mode]['planes'])==10
    assert cases['parent']['planes']==cases['candidate']['planes'] and cases['parent']['metadata']==cases['candidate']['metadata']
    assert sha(project)==input_digest and not git('status','--porcelain')
    record(terminal=True,exit=0,phase='complete',results=cases)
except Exception as failure:
    record(terminal=True,exit=1,error=repr(failure))
    raise
