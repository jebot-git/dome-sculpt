from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
masked=artifacts/'vrm1-unlit-mask-paint-validation-20261126'
support=(masked/'combined-release' if profile=='release' else artifacts/'core-gltf-normal-export-asan-20261126')
core=support/'libdome-sculpt-core.a' if profile=='release' else masked/'asan-verified-final/libdome-sculpt-core.a'
new_paint=base/f'{profile}-2048'/'paint.o'
out=base/f'cohort-{profile}'
out.mkdir(mode=0o700)
source=artifacts/'hdr-preview-shared-ownership-source-20261126'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

status={'terminal':False,'profile':profile,'invocation':os.getenv('INVOCATION_ID'),
        'candidate':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),
        'core_sha256':sha(core),'paint_object_sha256':sha(new_paint),'cases':{}}

def record(**fields):
    status.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')

def run(cmd,log,timeout=300):
    with (out/log).open('a') as output:
        print(shlex.join(map(str,cmd)),file=output,flush=True)
        subprocess.run(cmd,cwd=support,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=timeout)

try:
    compile_db=json.loads((support/'compile_commands.json').read_text())
    for name in ('composite-cache',):
        target=f'dome-sculpt-{name}-test'
        record(phase='build '+name)
        entry=next(x for x in compile_db if x['file'].endswith(f'/tests/{name}.cpp') and target+'.dir' in x['command'])
        cc=shlex.split(entry['command'])
        built_name=cc[cc.index('-o')+1]
        cc[cc.index('-o')+1]=str(out/(name+'.o'))
        cc[cc.index(entry['file'])]=str(source/f'tests/{name}.cpp')
        run(cc,'compile.log')
        raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
        link=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
        link[link.index('-o')+1]=str(out/target)
        link[link.index(built_name)]=str(out/(name+'.o'))
        link[link.index(core.name)]=str(core)
        link.insert(link.index(str(core)),str(new_paint))
        link_map=out/(name+'.map')
        link.append(f'-Wl,-Map,{link_map}')
        run(link,'link.log')
        text=link_map.read_text()
        assert str(core)+'(paint.cpp.o)' not in text and str(new_paint) in text
        record(phase='run '+name)
        run(['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--proc','/proc','--dev','/dev',
             '--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
             '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
             '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',out/target,source/'assets/humanoid/vroid/base-female.vrm',source/'assets/humanoid/vroid/base-male.vrm'],name+'.log')
        log=(out/(name+'.log')).read_text()
        assert 'ERROR: AddressSanitizer' not in log and 'runtime error:' not in log
        assert 'HDR history restores the same immutable preview' in log and 'Eviction frees the prior HDR preview' in log
        status['cases'][name]={'exit':0,'log_sha256':sha(out/(name+'.log')),'last_line':log.splitlines()[-1]}
    record(terminal=True,phase='complete',exit=0)
except Exception as problem:
    record(terminal=True,exit=1,error=repr(problem))
    raise
