from pathlib import Path
import subprocess
import sys

base=Path(__file__).resolve().parent
profile=sys.argv[1]
subprocess.run([sys.executable,base/'run.py',profile,'2048'],check=True)
measurement=base.parent/'hdr-preview-shared-ownership-measurement-20261126/run.py'
subprocess.run([sys.executable,measurement,profile,'2048'],check=True)
subprocess.run([sys.executable,base/'test-cohort.py',profile],check=True)
