from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess

base=Path(__file__).resolve().parent
artifacts=base.parent
support=artifacts/'dormant-main-release-20261126'
old=artifacts/'dormant-main-source-20261126'
source=artifacts/'baked-preview-plane-decode-main-source-20261126'
atlas_dir=artifacts/'xatlas-connected-cancellation-main-validation-20261126/release'
atlas=atlas_dir/'libxatlas.a'
out=base/'release'
out.mkdir(mode=0o700)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def git(path,*args):
    return subprocess.check_output(['git','-C',path,*args],text=True).strip()

status={'terminal':False,'invocation':os.getenv('INVOCATION_ID'),'candidate':git(source,'rev-parse','HEAD'),'results':{}}

def record(**fields):
    status.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')

def invoke(cmd,filename,timeout=240):
    with (out/filename).open('a') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=True)

try:
    before=git(old,'rev-parse','HEAD')
    assert not git(old,'status','--porcelain') and not git(source,'status','--porcelain')
    assert git(source,'diff','--name-only',before,'HEAD','--','src','include','CMakeLists.txt','third_party').splitlines()==[
        'src/paint.cpp','third_party/sources.json','third_party/xatlas/xatlas.cpp']
    atlas_status=json.loads((atlas_dir/'status.json').read_text())
    assert atlas_status['exit']==0 and atlas_status['atlas_sha256']==sha(atlas)
    core=support/'libdome-sculpt-core.a'
    record(phase='compile exact main paint',main_support=before,atlas_sha256=sha(atlas),core_sha256=sha(core))
    db=json.loads((support/'compile_commands.json').read_text())
    def compile(suffix,target,output,code=source):
        entry=next(i for i in db if i['file'].endswith('/'+suffix) and f'{target}.dir/' in i['command'])
        cmd=shlex.split(entry['command'])
        prior=cmd[cmd.index('-o')+1]
        cmd[cmd.index('-o')+1]=str(output)
        cmd[cmd.index(entry['file'])]=str(code/suffix)
        invoke(cmd,'compile.log')
        return prior
    paint=out/'paint.o'
    compile('src/paint.cpp','dome-sculpt-core',paint)
    record(paint_sha256=sha(paint))
    native=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
            '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--chdir',out,
            '--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
    for name in ('app','baked-textures','bake-workflow','source-maps','composite-cache','source-uv'):
        record(phase=name)
        target='dome-sculpt' if name=='app' else f'dome-sculpt-{name}-test'
        raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
        cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
        if name!='app':
            existing=out/(name+'.o')
            member=compile(f'tests/{name}.cpp',target,existing)
            cmd[cmd.index(member)]=str(existing)
        binary=out/target
        cmd[cmd.index('-o')+1]=str(binary)
        cmd.insert(cmd.index(core.name),str(paint))
        cmd[cmd.index('libxatlas.a')]=str(atlas)
        link_map=out/(name+'.map')
        cmd.append(f'-Wl,-Map,{link_map}')
        invoke(cmd,'link.log')
        assert 'libdome-sculpt-core.a(paint.cpp.o)' not in link_map.read_text()
        assets=source/'assets/humanoid/vroid'
        args=['--version'] if name=='app' else [assets/'base-female.vrm',assets/'base-male.vrm'] if name in ('composite-cache','source-uv') else []
        log=f'{name}.log'
        invoke([*native,binary,*args],log,timeout=300)
        lines=(out/log).read_text().splitlines()
        status['results'][name]={'executable_sha256':sha(binary),'log_sha256':sha(out/log),
                                 'assertions':sum(line.startswith('PASS ') for line in lines),'last_line':lines[-1]}
        record()
    record(terminal=True,exit=0,phase='complete')
except Exception as failure:
    record(terminal=True,exit=1,error=repr(failure))
    raise
