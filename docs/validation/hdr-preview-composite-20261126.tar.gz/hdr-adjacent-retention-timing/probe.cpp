#include "dome/document.hpp"
#include "emission-paint-access.hpp"
#include "paint-overlay-packet.hpp"
#include <chrono>
#include <iostream>

namespace {
using Clock = std::chrono::steady_clock;

bool published(dome::Document &doc, const char *label) {
  const auto start = Clock::now();
  const bool default_ready = doc.wait_mesh();
  const auto first_seconds = std::chrono::duration<double>(Clock::now() - start).count();
  const bool ready = default_ready || doc.wait_mesh(std::chrono::seconds(60));
  const auto seconds = std::chrono::duration<double>(Clock::now() - start).count();
  const auto frame = doc.frame();
  std::cout << label << " default_ready=" << default_ready << " first_seconds=" << first_seconds
            << " ready=" << ready << " seconds=" << seconds << " error=" << frame.state->error << std::endl;
  const auto cache = dome::paint_composite_cache_stats();
  std::cout << "CACHE " << label << " retained=" << cache.retained_bytes << " entries=" << cache.retained_maps
            << " limit=" << cache.limit_bytes << " builds=" << cache.builds << " hits=" << cache.hits << std::endl;
  if (frame.surface) for (const auto &range : frame.surface->ranges) {
    if (!range.textures) continue;
    const auto &maps = *range.textures;
    std::cout << "RANGE " << label << " object=" << range.object << " map=" << range.textures.get()
              << " overlay_bytes=" << (maps.overlay ? maps.overlay->storage_bytes() : 0)
              << " base_bytes=" << (maps.baked_base ? maps.baked_base->storage_bytes() : 0)
              << " colors=" << maps.color.rgba.size() << " normal=" << maps.normal.rgba.size() << std::endl;
  }
  return ready && frame.state->error.empty();
}
}

int main(int argc, char **argv) try {
  if (argc != 2) return 2;
  const auto start = Clock::now();
  auto scene = dome::Scene::load(argv[1]);
  const double load_seconds = std::chrono::duration<double>(Clock::now() - start).count();
  const auto &object = scene.active();
  if (!object.painted || !object.painted->baked() || !object.painted->baked()->emission_domain ||
      !dome::detail::EmissionExportAccess::requires_preview(*object.painted, object.material,
                                                         object.material_bindings.get())) return 3;
  std::cout << "OPEN seconds=" << load_seconds << " resolution=" << object.painted->resolution() << std::endl;
  dome::Document doc;
  doc.replace(std::move(scene));
  if (!published(doc, "INITIAL")) return 4;
  doc.clear_bake();
  if (!doc.wait_asset() || !published(doc, "CLEARED") || doc.copy_scene().active().painted->baked()) return 5;
  if (!doc.undo() || !published(doc, "RESTORED") || !doc.copy_scene().active().painted->baked()) return 6;
  if (!doc.redo() || !published(doc, "REDONE") || doc.copy_scene().active().painted->baked()) return 7;
  std::cout << "PASS native preview and genuine clear/undo/redo control" << std::endl;
  return 0;
} catch (const std::exception &error) {
  std::cerr << "FAIL " << error.what() << std::endl;
  return 1;
}
