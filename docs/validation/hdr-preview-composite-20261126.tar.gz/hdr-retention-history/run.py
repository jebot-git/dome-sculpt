from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import signal
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
resolution=sys.argv[2]
source=artifacts/"hdr-preview-retention-candidate-source-20261126"
masked=artifacts/"vrm1-unlit-mask-paint-validation-20261126"
support=(masked/"combined-release" if profile=="release" else
         artifacts/"core-gltf-normal-export-asan-20261126")
core=support/"libdome-sculpt-core.a" if profile=="release" else masked/"asan-verified-final/libdome-sculpt-core.a"
out=base/(profile+"-"+resolution)
out.mkdir(mode=0o700)
target="dome-sculpt-source-joint-writable-normal-bake-test"
fixture="tests/source-joint-writable-normal-bake.cpp"
def git(*args):
    return subprocess.check_output(["git","-C",source,*args],text=True).strip()
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
candidate=git("rev-parse","HEAD")
started=time.monotonic()
status={"profile":profile,"resolution":int(resolution),"candidate":candidate,"terminal":False,
        "invocation":os.getenv("INVOCATION_ID"),"deadline_per_phase_seconds":900,
        "owned_RSS_limit_bytes":4*1024**3,"core_sha256":sha(core)}
def record(**fields):
    status.update(fields,seconds=round(time.monotonic()-started,2))
    temp=out/"status.tmp"
    temp.write_text(json.dumps(status,indent=2)+"\n")
    temp.replace(out/"status.json")
def build():
    entry=next(row for row in json.loads((support/"compile_commands.json").read_text())
               if row["file"].endswith("/"+fixture))
    old=Path(entry["file"]).parents[1]
    obj=out/"fixture.o"
    cmd=[x.replace(str(old),str(source)) for x in shlex.split(entry["command"])]
    cmd[cmd.index("-o")+1]=str(obj)
    with (out/"compile.log").open("w") as log:
        print(shlex.join(cmd),file=log,flush=True)
        subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)
    raw=subprocess.check_output(["ninja","-C",support,"-t","commands",target],text=True).splitlines()[-1]
    cmd=[x for x in shlex.split(raw)[2:-2] if not x.startswith("-Wl,--dependency-file=")]
    cmd[cmd.index("-o")+1]=str(out/target)
    compiled=artifacts/"hdr-preview-retention-candidate-validation-20261126"/(profile+"-512")/"paint.o"
    assert compiled.is_file()
    status["linked_paint_object_sha256"]=sha(compiled)
    cmd[cmd.index(core.name)]=str(core)
    cmd.insert(cmd.index(str(core)),str(compiled))
    link_map=out/"history.map"
    cmd.append(f"-Wl,-Map,{link_map}")
    cmd[next(i for i,x in enumerate(cmd) if x.endswith("/source-joint-writable-normal-bake.cpp.o"))]=str(obj)
    with (out/"link.log").open("w") as log:
        print(shlex.join(cmd),file=log,flush=True)
        subprocess.run(cmd,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True)
    assert str(core)+"(paint.cpp.o)" not in link_map.read_text()
def candidates(pid):
    yield pid
    try:
        children=Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
    except (FileNotFoundError, ProcessLookupError):
        return
    for child in children:
        yield from candidates(int(child))
def capture_witness(pid):
    rn=0
    asan=False
    ubsan=False
    for child in candidates(pid):
        proc=Path(f"/proc/{child}")
        try:
            process=(proc/"status").read_text()
            mem=re.search(r"^VmRSS:\s+(\d+) kB",process,re.M)
            if mem:
                rn+=1024*int(mem.group(1))
            maps=(proc/"maps").read_text()
            asan|="/libasan.so" in maps
            ubsan|="/libubsan.so" in maps
            for fd in (proc/"fd").iterdir():
                try:
                    fd_target=os.readlink(fd)
                except FileNotFoundError:
                    continue
                if fd_target.startswith("/dev/dri/"):
                    raise RuntimeError("A CPU-only oracle acquired a graphics device")
            if "libgallium" in maps or "_dri.so" in maps:
                raise RuntimeError("A CPU-only oracle acquired a graphics driver")
        except (FileNotFoundError, ProcessLookupError):
            continue
    return rn,asan,ubsan

toolkit="/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
def phase(label, arguments, write=None):
    cmd=["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/",
         "--proc","/proc","--dev","/dev","--tmpfs","/tmp","--tmpfs","/run/user","--clearenv",
         "--setenv","PATH","/usr/bin:/bin","--setenv","HOME","/tmp","--setenv","LD_LIBRARY_PATH",toolkit,
         "--setenv","ASAN_OPTIONS","detect_leaks=1:halt_on_error=1",
         "--setenv","UBSAN_OPTIONS","halt_on_error=1:print_stacktrace=1"]
    if write:
        cmd.extend(["--bind",write,write])
    cmd.extend([out/target,*arguments])
    logpath=out/(label+".log")
    peak=0
    begin=time.monotonic()
    mapped=[False,False]
    error=None
    with logpath.open("w") as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            while proc.poll() is None:
                rss,*runtime=capture_witness(proc.pid)
                for k,value in enumerate(runtime):
                    mapped[k]|=value
                peak=max(peak,rss)
                if rss>4*1024**3:
                    raise RuntimeError("Original 4 GiB owned RSS limit reached")
                if time.monotonic()-begin>900:
                    raise RuntimeError("Original 900-second phase deadline reached")
                time.sleep(.5)
        except (RuntimeError,OSError) as problem:
            error=str(problem)
            try:
                os.killpg(proc.pid,signal.SIGTERM)
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL)
                proc.wait()
            except ProcessLookupError:
                proc.wait()
        result={"label":label,"pid":proc.pid,"exit":proc.returncode,"error":error,
                "elapsed_seconds":round(time.monotonic()-begin,3),"peak_owned_rss":peak,
                "libasan_mapped":mapped[0],"libubsan_mapped":mapped[1]}
    text=logpath.read_text()
    counts=re.findall(r"^PASS (\d+) checked joint-writable SOURCE.*",text,re.M)
    result["checks"]=[int(i) for i in counts]
    result["log_sha256"]=sha(logpath)
    (out/(label+".json")).write_text(json.dumps(result,indent=2)+"\n")
    if error or proc.returncode!=0 or len(counts)!=1 or (profile=="asan" and not all(mapped)):
        raise RuntimeError(f"{label} failed: {result}")
    return result


try:
    assert not git("status","--porcelain")
    checkpoint=artifacts/"hdr-strict-full-size-checkpoints-validation-20261126"/(profile+"-"+resolution)
    capture=checkpoint/"capture"
    authority=json.loads((checkpoint/"status.json").read_text())
    assert authority["candidate"].startswith("0833d18a") and authority["capture"]["exit"]==0
    pinned=authority["capture_inputs"]
    assert pinned=={name:sha(capture/name) for name in pinned}
    record(phase="build complete native history fixture",capture_inputs=pinned)
    build()
    results=[]
    outputs={}
    record(binary_sha256=sha(out/target),runs=results)
    for label,operation,filename in (
            ("ordered-history","--checked-ordered-history","000-ordered.dsculpt"),):
        destination=out/label
        destination.mkdir(mode=0o700)
        record(phase=label)
        result=phase(label,[operation,resolution,capture,destination],destination)
        results.append(result)
        outputs[filename]=sha(destination/filename)
        assert outputs[filename]==pinned["observed-second-bake.dsculpt"]
        record(runs=results,outputs=outputs)
    history=(out/"ordered-history.log").read_text()
    assert "CHECKED_SOURCE_REDO invoked=1 preview_ready=1" in history
    assert "CHECKED_SOURCE_REDO native_exact=1" in history
    assert re.findall(r"^CHECKED_SOURCE_HISTORY (\S+)$",history,re.M)==[
        "ordered-save-written","accepted-state-exact","undone-state-exact","redone-state-exact"]
    assert pinned=={name:sha(capture/name) for name in pinned}
    assert git("rev-parse","HEAD")==candidate and not git("status","--porcelain")
    record(phase="complete",terminal=True,exit=0,runs=results,outputs=outputs)
except Exception as problem:
    record(terminal=True,exit=1,error=repr(problem))
    raise
