from pathlib import Path
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
profile=sys.argv[1]
for script in ('build.py','build-helpers.py','test-native.py'):
    subprocess.run([sys.executable,base/script,profile],check=True)
subprocess.run([sys.executable,base/'run-suite.py','arc-asan' if profile=='asan' else 'software-release'],check=True)
