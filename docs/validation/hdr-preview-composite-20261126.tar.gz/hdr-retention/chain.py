from pathlib import Path
import subprocess
import sys

base=Path(__file__).resolve().parent
profile=sys.argv[1]
subprocess.run([sys.executable,base/'run.py',profile,'512'],check=True)
subprocess.run([sys.executable,base/'test-cohort.py',profile],check=True)
if profile=='asan':
    history=base.parent/'hdr-preview-retention-history-20261126/run.py'
    subprocess.run([sys.executable,history,'asan','2048'],check=True)
