from pathlib import Path
import subprocess
import sys

base=Path(__file__).resolve().parent
profile=sys.argv[1]
subprocess.run([sys.executable,base/'run.py',profile,'2048' if profile=='release' else '512'],check=True)
measurement=base.parent/'hdr-preview-retention-priority-measurement-20261126/run.py'
subprocess.run([sys.executable,measurement,profile,'2048'],check=True)
subprocess.run([sys.executable,base/'test-cohort.py',profile],check=True)
if profile=='asan':
    history=base.parent/'hdr-preview-retention-priority-history-20261126/run.py'
    subprocess.run([sys.executable,history,'asan','2048'],check=True)
