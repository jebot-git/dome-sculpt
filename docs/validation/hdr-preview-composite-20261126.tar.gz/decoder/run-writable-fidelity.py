from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
cohort=base/f'cohort-{profile}'
out=base/f'fidelity-{profile}'
out.mkdir(mode=0o700)
assets=artifacts/'vrm1-unlit-mask-paint-source-20261126/assets/humanoid/vroid'
inputs=[assets/f'base-{sex}.vrm' for sex in ('female','male')]
status={'profile':profile,'invocation':os.getenv('INVOCATION_ID'),'terminal':False,'results':{}}

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def record(**fields):
    status.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')

try:
    status['assets']={asset.name:digest(asset) for asset in inputs}
    for test in ('source-uv','composite-cache'):
        record(phase=test)
        log=out/f'{test}.log'
        binary=cohort/f'dome-sculpt-{test}-test'
        command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
                 '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
                 '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--chdir',out,
                 '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
                 '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',binary,*inputs]
        with log.open('w') as log_file:
            result=subprocess.run(command,stdout=log_file,stderr=subprocess.STDOUT,timeout=900)
        lines=log.read_text().splitlines()
        status['results'][test]={'exit':result.returncode,'executable_sha256':digest(binary),
                                 'passes':sum(line.startswith('PASS ') for line in lines),'last_line':lines[-1]}
        assert result.returncode==0
    record(terminal=True,exit=0,phase='complete')
except Exception as failure:
    record(terminal=True,exit=1,error=repr(failure))
    raise
