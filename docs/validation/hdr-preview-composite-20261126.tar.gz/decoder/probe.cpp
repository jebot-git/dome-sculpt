#include "dome/document.hpp"
#include "emission-paint-access.hpp"
#include <array>
#include <chrono>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <utility>

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  using Clock = std::chrono::steady_clock;
  const auto load_start = Clock::now();
  const auto scene = dome::Scene::load(argv[1]);
  const auto &object = scene.active();
  if (!object.painted || !object.painted->baked() || !object.painted->baked()->emission_domain ||
      !dome::detail::EmissionExportAccess::requires_preview(*object.painted, object.material,
                                                         object.material_bindings.get())) return 3;
  std::cout << "OPEN seconds=" << std::chrono::duration<double>(Clock::now() - load_start).count()
            << " resolution=" << object.painted->resolution() << std::endl;
  const auto preview_start = Clock::now();
  const auto cpu_start = std::clock();
  const auto maps = dome::detail::EmissionExportAccess::preview(*object.painted, object.material, {});
  std::cout << "PREVIEW seconds=" << std::chrono::duration<double>(Clock::now() - preview_start).count()
            << " cpu_seconds=" << double(std::clock() - cpu_start) / CLOCKS_PER_SEC
            << " transparent=" << maps->transparent << " pbr_transparent=" << maps->pbr_transparent << std::endl;
  if (!maps->overlay || !maps->baked_base || maps->color.rgba.empty() || maps->metal_rough.rgba.empty()) return 4;
  const auto planes = std::array{
      std::pair{"color", &maps->color}, std::pair{"pbr_color", &maps->pbr_color},
      std::pair{"metal_rough", &maps->metal_rough}, std::pair{"emission", &maps->emission},
      std::pair{"normal", &maps->normal}, std::pair{"mtoon_normal", &maps->mtoon_normal},
      std::pair{"color_coverage", &maps->color_coverage}, std::pair{"emission_coverage", &maps->emission_coverage},
      std::pair{"baked_normal", &maps->baked_normal}, std::pair{"baked_coverage", &maps->baked_coverage}};
  for (const auto &[name, image] : planes) {
    std::ofstream out(std::filesystem::path(argv[2]) / name, std::ios::binary);
    out << image->width << ' ' << image->height << '\n';
    out.write(reinterpret_cast<const char *>(image->rgba.data()), image->rgba.size());
    if (!out) return 5;
  }
  std::cout << "PASS actual HDR baked preview planes" << std::endl;
  return 0;
} catch (const std::exception &error) {
  std::cerr << "FAIL " << error.what() << std::endl;
  return 1;
}
