from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
profile=sys.argv[1]
arc=profile=='asan'
artifacts=base.parent
out=base/profile
out.mkdir(exist_ok=True)
candidate=os.environ['DOME_RENDERER_PROJECTION_CANDIDATE']
source=artifacts/'renderer-projection-combined-source-20261126'
native=artifacts/'renderer-projection-combined-validation-20261126'/profile
runtime=artifacts/'retained-texture-set-public-validation-20261126'/profile
sdk=artifacts/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
state={'candidate':candidate,'profile':profile,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def record(**values):
    state.update(values)
    temp=out/'status.tmp'
    temp.write_text(json.dumps(state,indent=2)+'\n')
    temp.replace(out/'status.json')

def run(command, label):
    with (out/label).open('w') as log:
        print(shlex.join(map(str,command)),file=log,flush=True)
        subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=240)

try:
    record(phase='wait for exact Release or strict renderer product')
    while True:
        status=native/'status.json'
        if status.is_file():
            sealed=json.loads(status.read_text())
            if sealed['terminal']:
                break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        f'ds-renderer-projection-combined-{profile}-20261126.service'],check=True)
        time.sleep(2)
    assert sealed['candidate']==candidate and sealed['exit']==0 and sealed['tests']==8
    app=native/'build/dome-sculpt'
    helper=native/'build/dome-sculpt-projection-native-test'
    synthetic=runtime/'libdome-sculpt-test-runtime.so'
    assert sha(app)==sealed['app_sha256'] and sha(helper)==sealed['binaries'][helper.name]
    assert all(sha(native/'build'/name)==digest for name,digest in sealed['helpers'].items())
    assert sha(synthetic)==json.loads((runtime/'status.json').read_text())['runtime_sha256']
    assert subprocess.check_output(['git','-C',source,'diff','--name-only',
        '33bd2460','HEAD','--','tests/xr_runtime.cpp','tests/projection-xr.py'],text=True)==''

    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    settings={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
              'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    runner=source/'tests/projection-xr.py'
    cutter=source/'tests/cut-color-xr.py'
    if arc:
        prefix.extend(['--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129'])
        settings.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',LIBGL_ALWAYS_SOFTWARE='0',
                        ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                        UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        cut_script=cutter.read_text()
        assert cut_script.count('"LIBGL_ALWAYS_SOFTWARE":"1"')==1
        cutter=out/'cut-arc.py'
        cutter.write_text(cut_script.replace('"LIBGL_ALWAYS_SOFTWARE":"1"','"LIBGL_ALWAYS_SOFTWARE":"0"'))
        script=runner.read_text()
        assert script.count("'LIBGL_ALWAYS_SOFTWARE':'1'")==1 and script.count("'llvmpipe' in")==1
        runner=out/'projection-arc.py'
        runner.write_text(script.replace("'LIBGL_ALWAYS_SOFTWARE':'1'","'LIBGL_ALWAYS_SOFTWARE':'0'")
                          .replace("'llvmpipe' in","'arc(tm) a770' in").replace('requested software GL','requested Intel Arc GL'))
    for key,value in settings.items():
        prefix.extend(['--setenv',key,value])
    record(phase='exercise the actual loader with synthetic controllers',app_sha256=sha(app),
           runtime_sha256=sha(synthetic),runner_sha256=sha(runner),fixture_sha256=sha(helper))
    command=[*prefix,'/usr/bin/python3',runner,app,synthetic,helper,out/'xr']
    cut_command=[*prefix,'/usr/bin/python3',cutter,app,synthetic,out/'cut']
    if arc:
        with open('/tmp/dome-sculpt-arc-device.lock','rb') as lease:
            fcntl.flock(lease,fcntl.LOCK_EX)
            run(command,'xr.log')
            run(cut_command,'cut.log')
    else:
        run(command,'xr.log')
        run(cut_command,'cut.log')
    report=out/'xr/report.json'
    results=json.loads(report.read_text())
    assert results['physical_headset'] is False and len(results['checks'])==10
    assert all(row['passed'] for row in results['checks'])
    cut=out/'cut/report.json'
    cut_results=json.loads(cut.read_text())
    assert cut_results['synthetic_tracking'] and cut_results['failed']==0 and len(cut_results['checks'])==21
    record(phase='complete',terminal=True,exit=0,checks={'projection':len(results['checks']),'cut':len(cut_results['checks'])},
           report_sha256={'projection':sha(report),'cut':sha(cut)})
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
