from pathlib import Path
import hashlib
import json
import shlex
import subprocess

out=Path(__file__).resolve().parent
art=out.parents[1]
build=out.parent/'release/build'
linklog=out.parent/'release/tests/dome-sculpt-projection-native-test/link.log'
prior=art/'cut-owning-material-validation-20261126/release'
core=prior/'libdome-sculpt-core.a'
donor=json.loads((prior/'status.json').read_text())
candidate=json.loads((out.parent/'release/status.json').read_text())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
assert donor['exit']==0 and sha(core)==donor['core_sha256']
assert candidate['donor']==donor['candidate']
link=shlex.split(linklog.read_text().splitlines()[0])
link=[str(core) if Path(word).name==core.name else word for word in link]
target=out/'baseline-projection'
link[link.index('-o')+1]=str(target)
with (out/'build.log').open('w') as log:
    print(shlex.join(link),file=log,flush=True)
    subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
        '--setenv','HOME','/tmp','--setenv','LIBGL_ALWAYS_SOFTWARE','1']
trace=out/'control.log'
with trace.open('w') as log:
    result=subprocess.run([*prefix,target],cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=90)
diagnostic='Projection respects visible sculpt geometry, alpha, target-only mode and editor ghosts'
assert result.returncode==1 and diagnostic in trace.read_text(), trace.read_text()
(out/'status.json').write_text(json.dumps({'candidate_fixture':candidate['candidate'],'parent':donor['candidate'],
    'expected_failure':diagnostic,'exit':result.returncode,'old_core_sha256':sha(core),
    'binary_sha256':sha(target),'trace_sha256':sha(trace)},indent=2)+'\n')
