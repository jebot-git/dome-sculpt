from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from xml.etree import ElementTree
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

out=Path(__file__).resolve().parent/sys.argv[1]
out.mkdir(exist_ok=True)
profile=out.name
asan=profile=='asan'
art=out.parents[1]
root=art.parent
source=art/'renderer-projection-combined-source-20261126'
build=out/'build'
renderer=art/'steady-gpu-retirement-validation-v2-20261126'/profile
projection=art/'sculpt-projection-occlusion-validation-v2-20261126'/profile
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=art/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
expected='c62279e741f9d60eddff95315a1517c2b46b19e4'
renderer_commit='a4ef26ffad36da8814ae1bf863feaa7b02693cd9'
projection_commit='5454c96f0a1551b41cdf81e8fbd4be775b76912e'
tests={
    'render-store-ledger':(renderer,'dome-sculpt-render-store-ledger-test'),
    'renderer-recovery':(renderer,'dome-sculpt-renderer-recovery-test'),
    'source-gpu':(renderer,'dome-sculpt-source-gpu-test'),
    'mtoon-emission':(renderer,'dome-sculpt-mtoon-emission-test'),
    'native-mtoon-physical':(renderer,'dome-sculpt-native-mtoon-physical-test'),
    'pbr-preview':(projection,'dome-sculpt-pbr-preview-test'),
    'projection-native':(projection,'dome-sculpt-projection-native-test'),
    'projection-held':(projection,'dome-sculpt-projection-held-test'),
}
state={'candidate':expected,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
start=time.monotonic()

def record(**fields):
    state.update(fields,elapsed_seconds=round(time.monotonic()-start,2))
    temp=out/'status.tmp'
    temp.write_text(json.dumps(state,indent=2)+'\n')
    temp.replace(out/'status.json')

def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def run(command,log,timeout,cwd,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,command)),file=trace,flush=True)
        return subprocess.run(command,stdout=trace,stderr=subprocess.STDOUT,cwd=cwd,timeout=timeout,check=check)

def verified(parent,name,commit,total):
    while True:
        status=parent/'status.json'
        if status.is_file():
            result=json.loads(status.read_text())
            if result['terminal']:
                break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        f'ds-{name}-{profile}-v2-20261126.service'],check=True)
        time.sleep(2)
    assert result['candidate']==commit and result['tests']==total and result['exit']==0 and not result['failures']
    assert result['app_sha256']==sha(parent/'build/dome-sculpt')
    return result

try:
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    assert set(git('diff','--name-only',renderer_commit,'HEAD','--','src','include','assets','third_party').splitlines())=={'src/document-native.cpp'}
    assert set(git('diff','--name-only',projection_commit,'HEAD','--','src','include','assets','third_party').splitlines())=={'src/render.cpp','src/render-store-ledger.hpp'}
    record(phase='wait for both exact component profiles')
    gpu=verified(renderer,'steady-gpu-retirement',renderer_commit,12)
    paint=verified(projection,'sculpt-projection-occlusion',projection_commit,7)
    core=projection/'libdome-sculpt-core.a'
    render=renderer/'libdome-sculpt-render.a'
    assert sha(core)==paint['core_sha256'] and sha(render)==gpu['render_sha256']
    assert gpu['xr_sha256']==paint['xr_sha256']
    choices={core.name:str(core),render.name:str(render)}
    for name,(parent,target) in tests.items():
        donor,receipt=(renderer_commit,gpu) if parent==renderer else (projection_commit,paint)
        assert not git('diff','--name-only',donor,'HEAD','--',f'tests/{name}.cpp')
        assert sha(parent/'build'/target)==receipt['binaries'][target]
    record(phase='configure and relink exact combined app and selected suites',core_sha256=sha(core),
           render_sha256=sha(render),component_receipts={renderer_commit:sha(renderer/'status.json'),
           projection_commit:sha(projection/'status.json')})
    options=[]
    if asan:
        options.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        options.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    run(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DDOME_COMPUTE_BACKEND=CPU',
         f'-DFLTK_DIR={sdk}/share/fltk',*options],'configure.log',120,out)

    def relink(target,reference,cwd):
        argv=shlex.split(reference.read_text().splitlines()[0])
        argv=[choices.get(Path(word).name,word) for word in argv]
        argv[argv.index('-o')+1]=str(build/target)
        run(argv,target+'-link.log',200,cwd)
        return target,sha(build/target)

    def link_test(pair):
        parent,target=pair
        return relink(target,parent/'tests'/target/'link.log',parent/'build')
    with ThreadPoolExecutor(max_workers=3) as pool:
        binaries=dict(pool.map(link_test,tests.values()))
    app_name,app_sha=relink('dome-sculpt',renderer/'dome-sculpt-link.log',support)
    helpers={}
    for target,digest in json.loads((renderer/'cut-fixtures.json').read_text()).items():
        parent=renderer/'build'/target
        assert sha(parent)==digest
        os.link(parent,build/target)
        helpers[target]=digest
    fixture='dome-sculpt-projection-native-test'
    helpers[fixture]=binaries[fixture]
    record(phase='run registered combined tests',binaries=binaries,app_sha256=app_sha,helpers=helpers)
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    variables={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
               'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        variables.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                         UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in variables.items():
        prefix.extend(['--setenv',key,value])
    report=build/'combined-tests.xml'
    result=run([*prefix,'ctest','--test-dir',build,'-R','^('+'|'.join(tests)+')$','-j3','-V',
                '--output-on-failure','--output-junit',report],'ctest.log',650,out,check=False)
    cases=ElementTree.parse(report).getroot().findall('.//testcase')
    assert len(cases)==len(tests) and set(c.attrib['name'] for c in cases)==set(tests)
    failures=sorted(c.attrib['name'] for c in cases if c.find('failure') is not None or c.find('skipped') is not None)
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain') and sha(build/app_name)==app_sha
    record(phase='complete',exit=result.returncode,terminal=True,tests=len(cases),failures=failures,
           junit_sha256=sha(report),log_sha256=sha(out/'ctest.log'))
    assert result.returncode==0 and not failures, failures
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
