from pathlib import Path
from xml.etree import ElementTree
import gzip
import hashlib
import json
import subprocess
import tarfile

combined=Path(__file__).resolve().parent
art=combined.parent
root=art.parent
output=root/'docs/validation'
public=art/'renderer-projection-combined-public-20261126'
wayland=art/'renderer-projection-combined-wayland-20261126'
projection=art/'sculpt-projection-occlusion-validation-v2-20261126'
projection_xr=art/'sculpt-projection-occlusion-public-v2-20261126'
initial=art/'sculpt-projection-occlusion-validation-20261126'
expected='c62279e741f9d60eddff95315a1517c2b46b19e4'
projection_source='5454c96f0a1551b41cdf81e8fbd4be775b76912e'
members={}

def read(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()

def add(prefix,path,*names):
    for name in names:
        item=path/name
        assert item.is_file(),item
        members[prefix+'/'+name]=item

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

def check_natives(total,summary,report):
    assert summary['terminal'] and summary['exit']==0 and summary['tests']==total and not summary['failures']
    cases=ElementTree.parse(report).getroot().findall('.//testcase')
    assert len(cases)==total and all(c.find('failure') is None and c.find('skipped') is None for c in cases)

assert not git('diff','--name-only',expected,'HEAD','--','src','include','tests','assets','third_party','CMakeLists.txt')
projection_results={}
combined_results={}
for profile in ('release','asan'):
    proj=projection/profile
    pr=projection_xr/profile
    pn=read(proj/'status.json')
    px=read(pr/'status.json')
    assert pn['candidate']==px['candidate']==projection_source
    check_natives(7,pn,proj/'build/projection-tests.xml')
    assert px['exit']==0 and px['checks']==10 and px['app_sha256']==pn['app_sha256']
    add(profile+'/projection',proj,'configure.log','document-native.cpp.log','dome-sculpt-link.log','status.json','ctest.log','build/projection-tests.xml')
    add(profile+'/projection-openxr',pr,'status.json','xr.log','xr/report.json')
    prev=initial/profile
    prior=read(prev/'status.json')
    assert prior['failures']==['pbr-preview']
    assert 'Accepted asset did not enter its barrier' in (prev/'ctest.log').read_text()
    add(profile+'/earlier-projection-fixture',prev,'status.json','ctest.log')
    projection_results[profile]={'native':pn,'synthetic_openxr':px}

    axis=combined/profile
    replay=public/profile
    actual=read(axis/'status.json')
    xr=read(replay/'status.json')
    assert actual['candidate']==xr['candidate']==expected
    check_natives(8,actual,axis/'build/combined-tests.xml')
    assert xr['terminal'] and xr['exit']==0 and xr['checks']=={'projection':10,'cut':21}
    assert xr['app_sha256']==actual['app_sha256']==sha(axis/'build/dome-sculpt')
    add(profile+'/combined',axis,'configure.log','ctest.log','status.json','dome-sculpt-link.log','build/combined-tests.xml')
    add(profile+'/combined-openxr',replay,'status.json','xr.log','cut.log','xr/report.json','cut/report.json')
    if profile=='asan':
        add(profile+'/arc-projection-runner',pr,'projection-arc.py')
        add(profile+'/arc-combined-runners',replay,'projection-arc.py','cut-arc.py')
    combined_results[profile]={'native':actual,'synthetic_openxr':xr}

wl=read(wayland/'status.json')
assert wl['candidate']==expected and wl['exit']==0 and wl['checks']==17
assert wl['app_sha256']==combined_results['release']['native']['app_sha256']
add('wayland',wayland,'run.py','replay.py','status.json','wayland.log','workflow/report.json')
baseline=initial/'baseline'
control=read(baseline/'status.json')
assert control['exit']==1 and sha(baseline/'control.log')==control['trace_sha256']
assert control['expected_failure'] in (baseline/'control.log').read_text()
add('baseline',baseline,'run.py','status.json','build.log','control.log')
add('projection-runner',projection,'run.py')
add('projection-openxr-runner',projection_xr,'run.py')
add('combined-runner',combined,'run.py','record.py')
add('combined-openxr-runner',public,'run.py')
archive=output/'renderer-projection-combined-20261126.tar.gz'
with archive.open('wb') as packed,gzip.GzipFile(filename='',fileobj=packed,mode='wb',mtime=0) as data:
    with tarfile.open(fileobj=data,mode='w') as tar:
        for name,path in sorted(members.items()):
            entry=tar.gettarinfo(str(path),arcname=name)
            entry.uid=entry.gid=entry.mtime=0
            entry.mode=0o644
            entry.uname=entry.gname=''
            with path.open('rb') as file:
                tar.addfile(entry,file)
digests={name:sha(path) for name,path in sorted(members.items())}
with tarfile.open(archive,'r:gz') as check:
    assert {entry.name for entry in check.getmembers()}==set(digests)
    for name,digest in digests.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==digest
receipt={'candidate':expected,'main_merge':git('rev-parse','HEAD'),
         'projection_source':projection_source,'baseline':control,'projection':projection_results,
         'combined':combined_results,'wayland':wl,
         'archive':{'name':archive.name,'sha256':sha(archive),'members':digests}}
(output/'renderer-projection-combined-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(members),'archived evidence members',sha(archive))
