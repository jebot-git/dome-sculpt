const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const output = __dirname;
const base = path.dirname(output);
const validator = require(path.join(base, 'hdr-khronos-validation-20261126/module/package'));
const source = '5c977be9be8d90f0a6ada3ef34df9d4d27769209';

async function validate(profile) {
    const proof = path.join(base, 'combined-atlas-hdr-preview-validation-20261126', profile);
    const status = JSON.parse(fs.readFileSync(path.join(proof, 'status.json'), 'utf8'));
    if (status.candidate !== source || !status.terminal || status.exit !== 0 || status.checks !== 153)
        throw new Error(`Incomplete source or runtime evidence for ${profile}`);
    const report = JSON.parse(fs.readFileSync(path.join(proof, 'workflow/report.json'), 'utf8'));
    const files = path.join(report.project_directory, 'state/dome-sculpt');
    const names = fs.readdirSync(files).filter(name => name.endsWith('.glb'));
    if (names.length !== 1)
        throw new Error(`Expected a single Files workflow GLB in ${profile}`);
    const file = path.join(files, names[0]);
    const bytes = fs.readFileSync(file);
    const gltf = await validator.validateBytes(new Uint8Array(bytes), {uri: names[0], maxIssues: 10000});
    fs.writeFileSync(path.join(output, `${profile}-khronos.json`), JSON.stringify(gltf, null, 2) + '\n');
    return {profile, file, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
        bytes: bytes.length, issues: gltf.issues, app: status.app_sha256};
}

(async () => {
    const results = await Promise.all(['software-release', 'arc-asan'].map(validate));
    const status = {source, terminal: true, validator: validator.version(), results,
        identical_exports: results[0].sha256 === results[1].sha256,
        exit: Number(results.some(value => value.issues.numErrors !== 0))};
    fs.writeFileSync(path.join(output, 'status.json'), JSON.stringify(status, null, 2) + '\n');
    process.exitCode = status.exit;
})().catch(error => { console.error(error); process.exitCode = 1; });
