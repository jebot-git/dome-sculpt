#include "dome/document.hpp"
#include <iostream>
#include <nlohmann/json.hpp>
#include <stdexcept>

int main(int argc, char **argv) try {
    if (argc != 3)
        return 2;
    dome::Document document;
    const auto initial = document.copy_scene();
    const auto original = initial.encode();
    const auto starter = initial.active().id;
    document.import_asset(argv[1], document.import_settings(), document.begin_import());
    if (!document.wait_asset() || !document.wait_mesh() || !document.frame().state->error.empty())
        throw std::runtime_error("Import: " + document.frame().state->error);
    auto imported = document.copy_scene();
    if (imported.objects().size() != initial.objects().size() + 1 || imported.active().id == starter)
        throw std::runtime_error("Import did not publish the separate selected object");
    if (!document.undo() || !document.wait_mesh() || document.copy_scene().encode() != original)
        throw std::runtime_error("Import Undo did not restore every original native field");
    if (!document.redo() || !document.wait_mesh() || document.copy_scene().encode() != imported.encode())
        throw std::runtime_error("Import Redo did not restore every imported native field");
    document.object_visibility(starter, false);
    document.save(argv[2]);
    std::cout << "PASS native Import and exact Undo/Redo\n";
    return 0;
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
}
