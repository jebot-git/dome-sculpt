from collections import Counter
from pathlib import Path
import hashlib
import json
import os
import struct
import shlex
import subprocess

out=Path(__file__).resolve().parent
root=out.parent
workflow=root/'combined-atlas-hdr-preview-validation-20261126'
proof=workflow/'software-release'
receipt=json.loads((proof/'status.json').read_text())
app=workflow/'release/dome-sculpt'
runtime=proof/'libdome-sculpt-test-runtime.so'
source=Path(json.loads((proof/'workflow/report.json').read_text())['project_directory'])/'state/dome-sculpt'
original,=source.glob('*.glb')
native=out/'reimported.dsculpt'
reexported=out/'reexported.glb'
manifest=out/'runtime.json'
state={'candidate':receipt['candidate'],'terminal':False,'invocation':os.getenv('INVOCATION_ID')}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(**fields):
    state.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')


def run(args,label,executable=app):
    with (out/(label+'.log')).open('wb') as log:
        subprocess.run([*command,executable,*args],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=70)


def mesh(path):
    data=path.read_bytes()
    magic,version,declared=struct.unpack_from('<4sII',data)
    assert magic==b'glTF' and version==2 and declared==len(data)
    length,kind=struct.unpack_from('<II',data,12)
    assert kind==0x4E4F534A
    graph=json.loads(data[20:20+length])
    size,kind=struct.unpack_from('<II',data,20+length)
    assert kind==0x004E4942 and size==len(data)-(28+length)
    content=memoryview(data)[28+length:]
    result=[]
    for mesh in graph['meshes']:
        for primitive in mesh['primitives']:
            assert primitive.get('mode',4)==4
            decoded={}
            for semantic,access in {**primitive['attributes'],'INDICES':primitive['indices']}.items():
                info=graph['accessors'][access]
                view=graph['bufferViews'][info['bufferView']]
                assert view['buffer']==0 and 'sparse' not in info
                width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[info['type']]
                kind={5121:'B',5123:'H',5125:'I',5126:'f'}[info['componentType']]
                fmt=struct.Struct('<'+kind*width)
                offset=view.get('byteOffset',0)+info.get('byteOffset',0)
                stride=view.get('byteStride',fmt.size)
                decoded[semantic]=[fmt.unpack_from(content,offset+i*stride) for i in range(info['count'])]
            result.append(decoded)
    return graph,result


def faces(primitives,attributes):
    census=Counter()
    for primitive in primitives:
        index=[item[0] for item in primitive['INDICES']]
        assert len(index)%3==0
        for i in range(0,len(index),3):
            face=tuple(tuple(value for key in attributes for value in primitive[key][vertex]) for vertex in index[i:i+3])
            census[min(face,face[1:]+face[:1],face[2:]+face[:2])]+=1
    return census


try:
    assert receipt['terminal'] and receipt['exit']==0 and receipt['checks']==153
    assert digest(app)==receipt['app_sha256'] and digest(runtime)==receipt['runtime_sha256']
    manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(runtime)}}))
    vars={'PATH':'/usr/bin:/bin','HOME':str(out),'XDG_RUNTIME_DIR':str(out),'XDG_STATE_HOME':str(out/'state'),
          'XDG_CONFIG_HOME':str(out/'config'),'XR_RUNTIME_JSON':str(manifest),
          'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
          'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2'}
    command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    for name,value in vars.items():
        command.extend(['--setenv',name,value])
    record(phase='compile and link ordinary native Import consumer',glb_input_sha256=digest(original))
    support=root/'vrm-consumer-combined-20261126'
    fixture='tests/import-authoring.cpp'
    entry=next(row for row in json.loads((support/'compile_commands.json').read_text())
               if row['file'].endswith('/'+fixture))
    old_source=Path(entry['file']).parents[1]
    head=root/'combined-atlas-hdr-preview-source-20261126'
    flags=[x.replace(str(old_source),str(head)) for x in shlex.split(entry['command'])]
    old_object=flags[flags.index('-o')+1]
    obj=out/'import.o'
    flags[flags.index('-o')+1]=str(obj)
    flags[flags.index(str(head/fixture))]=str(out/'import.cpp')
    executable=out/'import'
    target='dome-sculpt-import-authoring-test'
    raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
    link=[part for part in shlex.split(raw)[2:-2] if not part.startswith('-Wl,--dependency-file=')]
    link[link.index(old_object)]=str(obj)
    link[link.index('-o')+1]=str(executable)
    linked=workflow/'release'
    status=json.loads((linked/'status.json').read_text())
    paint=linked/'dome-sculpt-core.o'
    atlas=linked/'libxatlas.a'
    assert status['candidate']==receipt['candidate'] and status['exit']==0
    assert digest(paint)==status['paint_object_sha256'] and digest(atlas)==status['atlas_sha256']
    link.insert(link.index('libdome-sculpt-core.a'),str(paint))
    link[link.index('libxatlas.a')]=str(atlas)
    with (out/'compile-link.log').open('wb') as log:
        for args in (flags,link):
            subprocess.run(args,cwd=support,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    record(phase='import through the ordinary Document worker and save',consumer_sha256=digest(executable))
    run([original,native],'import',executable)
    assert 'PASS native Import and exact Undo/Redo' in (out/'import.log').read_text()
    record(phase='re-export through ordinary ordered file worker',native_sha256=digest(native))
    run(['--export-project',native,reexported],'export')
    original_json,a=mesh(original)
    output_json,b=mesh(reexported)
    attrs=('POSITION','TEXCOORD_0')
    expected=faces(a,attrs)
    actual=faces(b,attrs)
    original_materials=original_json.get('materials',[])
    output_materials=output_json.get('materials',[])
    record(phase='compare interchange data',glb_output_sha256=digest(reexported),
           triangle_count=[expected.total(),actual.total()],topology_positions_uv_exact=expected==actual,
           original_attributes=[sorted(item) for item in a],reexported_attributes=[sorted(item) for item in b],
           materials_exact=original_materials==output_materials)
    assert expected==actual and expected.total() == 20320
    assert len(original_materials)==len(output_materials) and all(
        m.get('pbrMetallicRoughness',{})==n.get('pbrMetallicRoughness',{})
        for m,n in zip(original_materials,output_materials,strict=True))
    record(phase="complete",terminal=True,exit=0)
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
