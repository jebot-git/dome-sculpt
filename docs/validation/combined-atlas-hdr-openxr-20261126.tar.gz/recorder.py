from pathlib import Path
import gzip
import hashlib
import io
import json
import math
import os
import subprocess
import tarfile

root = Path.cwd()
artifacts = root/'artifacts'
folder = Path(__file__).resolve().parent
combined = artifacts/'combined-atlas-hdr-preview-validation-20261126'
main = artifacts/'main-rendered-xr-replay-validation-20261126'
members = {}


def git(*args):
    return subprocess.check_output(['git',*args],text=True).strip()


def collect(label, directory, *paths):
    for name in ('status.json', *paths):
        members[f'{label}/{name}'] = (directory/name).read_bytes()
    return json.loads(members[f'{label}/status.json'])


suite = {}
for profile in ('software-release', 'arc-asan'):
    outcome = collect('combined-'+profile, combined/profile,'workflow/report.json','workflow/files.json')
    assert outcome['candidate'].startswith('5c977be9') and outcome['terminal'] and outcome['exit']==0
    assert outcome['checks']==153 and outcome['report_complete'] and outcome['uv']['uv_atlas_ready']
    assert outcome['voxel']['exact_native_bytes']
    if profile=='arc-asan':
        assert outcome['arc_witnesses']['files']['node']=='/dev/dri/renderD129'
        outcome['arc_witness_count']=len(outcome.pop('arc_witnesses'))
    suite[profile]=outcome
export = collect('independent-glb',folder,'validate.cjs','software-release-khronos.json','arc-asan-khronos.json')
assert export['exit']==0 and export['identical_exports']
assert all(x['issues']['numErrors']==x['issues']['numWarnings']==0 for x in export['results'])
for result in export['results']:
    path=Path(result['file'])
    assert path.stat().st_size==result['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==result['sha256']

replay=collect('main-software',main/'software-release','workflow/report.json','workflow/scene.json')
assert replay['checks']==153 and replay['report_complete'] and replay['exit']==0
assert replay['app_source'].startswith('66d31263') and replay['candidate'].startswith('518a1d89')
positive=json.loads(members['main-software/workflow/scene.json'])
assert positive['scene_materials_seen'] and positive['scene_sliders_seen']
active_path=Path(json.loads(members['main-software/workflow/report.json'])['project_directory'])/'scene.dsculpt'
info=subprocess.check_output([main/'release/dome-sculpt','--project-info',active_path],
      env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'})
scene=json.loads(info)
assert scene['object_count']==2 and all(math.isclose(value,want,abs_tol=1e-4) for value,want in zip(scene['active_color'],(.04,.12,.8,1),strict=True))
replay['active_color']=scene['active_color']
replay['scene_sha256']=hashlib.sha256(active_path.read_bytes()).hexdigest()
replay['objects']=scene['object_count']
roundtrip_source=artifacts/'combined-atlas-hdr-native-roundtrip-v2-20261126'
roundtrip=collect('native-glb-roundtrip',roundtrip_source,'run.py','import.cpp','import.log','khronos.json','normals.json')
assert roundtrip['exit']==0 and roundtrip['triangle_count']==[20320,20320]
assert roundtrip['topology_positions_uv_exact'] and roundtrip['materials_exact']
assert roundtrip['glb_input_sha256']==export['results'][0]['sha256']
assert hashlib.sha256((roundtrip_source/'reexported.glb').read_bytes()).hexdigest()==roundtrip['glb_output_sha256']
normals=json.loads(members['native-glb-roundtrip/normals.json'])
assert normals['corner_normals']==60960 and normals['max_euclidean_difference']==0
assert normals['input_sha256']==roundtrip['glb_input_sha256'] and normals['reexport_sha256']==roundtrip['glb_output_sha256']
independent=json.loads(members['native-glb-roundtrip/khronos.json'])['issues']
assert independent['numErrors']==independent['numWarnings']==0
roundtrip['normals']=normals
roundtrip['khronos_issues']=independent
history=collect('combined-hdr-history-release',artifacts/'combined-atlas-hdr-native-history-20261126/release-2048',
                'ordered-history.log','ordered-history.json')
assert history['candidate'].startswith('5c977be9') and history['exit']==0 and history['runs'][0]['checks']==[8]
assert history['outputs']['000-ordered.dsculpt']==history['capture_inputs']['observed-second-bake.dsculpt']
root_roles=['src','include','tests','third_party','assets','tools','CMakeLists.txt']
merged=git('rev-parse','4f083e6e')
validated=git('rev-parse','5c977be9')
assert not git('diff','--name-only',validated,merged,'--',*root_roles)
assert not git('diff','--name-only','66d31263','518a1d89','--','src','include','third_party','assets','tools','CMakeLists.txt')
record={'combined_replay':suite,'independent_glb':export,'main_rendered_controls':replay,
        'roundtrip':roundtrip,'hdr_history_release':history,
        'combined_merge_candidate':{'merge':merged,'validated':validated,'identical_paths':root_roles}}
if (main/'arc-asan/status.json').is_file() and json.loads((main/'arc-asan/status.json').read_text())['terminal']:
    main_arc=collect('main-arc',main/'arc-asan','workflow/report.json','workflow/files.json')
    assert main_arc['app_source'].startswith('66d31263') and main_arc['candidate'].startswith('518a1d89')
    assert main_arc['checks']==146 and main_arc['exit']==1 and 'timed out after 40 seconds' in main_arc['error']
    assert main_arc['voxel']['exact_native_bytes'] and main_arc['uv']['uv_atlas_ready']
    assert json.loads(members['main-arc/workflow/files.json'])['frames_ended']==45
    main_arc['arc_witness_count']=len(main_arc.pop('arc_witnesses'))
    record['main_arc_replay']=main_arc

timing=collect('main-combined-matched-files',artifacts/'main-vs-combined-arc-files-20261126','run.py')
assert timing['exit']==0 and timing['identical_native'] and timing['identical_glb']
assert len(timing['runs'])==4 and all(row['seconds']>40 and row['arc_device'] for row in timing['runs'])
assert all(row['glb_sha256']==[export['results'][0]['sha256']] for row in timing['runs'])
record['main_combined_matched_files']=timing
cli_root=artifacts/'headless-standard-glb-owned-hdr-20261126'
cli={}
for profile in ('release','asan'):
    test=collect('headless-export-'+profile,cli_root/profile,'retained-hdr-parent.log',
                 'verify-native-round-trip.log','close-with-invalid-project.log','khronos.json')
    assert test['candidate'].startswith('7470d805') and test['exit']==0
    assert test['exact_worker_glb'] and test['invalid_project_preserves_previous_output']
    assert test['hdr']['prior_exit']==1 and test['hdr']['no_prior_output']
    assert b'Physical emission requires its linear composite adapter' in members[f'headless-export-{profile}/retained-hdr-parent.log']
    assert b'PASS exact native HDR scene in GLB' in members[f'headless-export-{profile}/verify-native-round-trip.log']
    issues=json.loads(members[f'headless-export-{profile}/khronos.json'])['issues']
    assert issues['numErrors']==issues['numWarnings']==0
    cli[profile]=test
assert cli['release']['hdr']==cli['asan']['hdr']
for name in ('run.py','fixture.cpp','khronos-summary.json'):
    members['headless-export/'+name]=(cli_root/name).read_bytes()
record['headless_export']=cli

wayland=artifacts/'creator-public-build-20261126/combined-wayland5c977be9-v1'
if (wayland/'status.json').is_file() and json.loads((wayland/'status.json').read_text())['terminal']:
    wayland_result=collect('combined-native-wayland',wayland,'workflow/report.json')
    wayland_report=json.loads(members['combined-native-wayland/workflow/report.json'])
    assert wayland_result['exit']==0 and wayland_result['actual_checks']==14
    assert wayland_result['input_drift']==wayland_result['owned_remaining']==[]
    assert wayland_report['complete'] and len(wayland_report['checks'])==14
    assert all(check['passed'] for check in wayland_report['checks'])
    plan=json.loads((wayland/'plan.json').read_text())
    assert hashlib.sha256((wayland/'plan.json').read_bytes()).hexdigest()==wayland_result['plan_sha256']
    assert plan['App_sha256']==suite['software-release']['app_sha256']
    record['native_wayland']={key:wayland_result[key] for key in ('terminal','source','exit','actual_checks','plan_sha256')}
    record['native_wayland'].update({key:plan[key] for key in ('compositor_source','compositor_sha256','App_sha256')})
archive=root/'docs/validation/combined-atlas-hdr-openxr-20261126.tar.gz'
members['recorder.py']=Path(__file__).read_bytes()
with archive.open('wb') as stream, gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed,mode='w') as tar:
    for name,payload in sorted(members.items()):
        item=tarfile.TarInfo(name)
        item.size=len(payload)
        item.mode=0o644
        tar.addfile(item,io.BytesIO(payload))
with tarfile.open(archive) as tar:
    assert set(tar.getnames())==set(members)
    assert all(tar.extractfile(name).read()==payload for name,payload in members.items())
record['archive']={'path':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(members)}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
