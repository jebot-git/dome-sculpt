from pathlib import Path
import gzip
import hashlib
import io
import json
import math
import os
import subprocess
import tarfile

root = Path.cwd()
artifacts = root/'artifacts'
folder = Path(__file__).resolve().parent
combined = artifacts/'combined-atlas-hdr-preview-validation-20261126'
main = artifacts/'main-rendered-xr-replay-validation-20261126'
members = {}


def git(*args):
    return subprocess.check_output(['git',*args],text=True).strip()


def collect(label, directory, *paths):
    for name in ('status.json', *paths):
        members[f'{label}/{name}'] = (directory/name).read_bytes()
    return json.loads(members[f'{label}/status.json'])


suite = {}
for profile in ('software-release', 'arc-asan'):
    outcome = collect('combined-'+profile, combined/profile,'workflow/report.json','workflow/files.json')
    assert outcome['candidate'].startswith('5c977be9') and outcome['terminal'] and outcome['exit']==0
    assert outcome['checks']==153 and outcome['report_complete'] and outcome['uv']['uv_atlas_ready']
    assert outcome['voxel']['exact_native_bytes']
    if profile=='arc-asan':
        assert outcome['arc_witnesses']['files']['node']=='/dev/dri/renderD129'
        outcome['arc_witness_count']=len(outcome.pop('arc_witnesses'))
    suite[profile]=outcome
export = collect('independent-glb',folder,'validate.cjs','software-release-khronos.json','arc-asan-khronos.json')
assert export['exit']==0 and export['identical_exports']
assert all(x['issues']['numErrors']==x['issues']['numWarnings']==0 for x in export['results'])
for result in export['results']:
    path=Path(result['file'])
    assert path.stat().st_size==result['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==result['sha256']

replay=collect('main-software',main/'software-release','workflow/report.json','workflow/scene.json')
assert replay['checks']==153 and replay['report_complete'] and replay['exit']==0
assert replay['app_source'].startswith('66d31263') and replay['candidate'].startswith('518a1d89')
positive=json.loads(members['main-software/workflow/scene.json'])
assert positive['scene_materials_seen'] and positive['scene_sliders_seen']
active_path=Path(json.loads(members['main-software/workflow/report.json'])['project_directory'])/'scene.dsculpt'
info=subprocess.check_output([main/'release/dome-sculpt','--project-info',active_path],
      env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'})
scene=json.loads(info)
assert scene['object_count']==2 and all(math.isclose(value,want,abs_tol=1e-4) for value,want in zip(scene['active_color'],(.04,.12,.8,1),strict=True))
replay['active_color']=scene['active_color']
replay['scene_sha256']=hashlib.sha256(active_path.read_bytes()).hexdigest()
replay['objects']=scene['object_count']
root_roles=['src','include','tests','third_party','assets','tools','CMakeLists.txt']
merged=git('rev-parse','4f083e6e')
validated=git('rev-parse','5c977be9')
assert not git('diff','--name-only',validated,merged,'--',*root_roles)
assert not git('diff','--name-only','66d31263','518a1d89','--','src','include','third_party','assets','tools','CMakeLists.txt')
record={'combined_replay':suite,'independent_glb':export,'main_rendered_controls':replay,
        'combined_merge_candidate':{'merge':merged,'validated':validated,'identical_paths':root_roles}}
archive=root/'docs/validation/combined-atlas-hdr-openxr-20261126.tar.gz'
members['recorder.py']=Path(__file__).read_bytes()
with archive.open('wb') as stream, gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed,mode='w') as tar:
    for name,payload in sorted(members.items()):
        item=tarfile.TarInfo(name)
        item.size=len(payload)
        item.mode=0o644
        tar.addfile(item,io.BytesIO(payload))
with tarfile.open(archive) as tar:
    assert set(tar.getnames())==set(members)
    assert all(tar.extractfile(name).read()==payload for name,payload in members.items())
record['archive']={'path':str(archive.relative_to(root)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(members)}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
