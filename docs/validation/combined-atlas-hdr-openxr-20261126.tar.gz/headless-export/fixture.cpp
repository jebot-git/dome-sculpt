#include "dome/scene.hpp"
#include <iostream>
#include <nlohmann/json.hpp>
#include <stdexcept>

int main(int argc, char **argv) try {
    if (argc == 3) {
        if (dome::Scene::load(argv[1]).encode() != dome::Scene::load(argv[2]).encode())
            throw std::runtime_error("Native HDR ownership and paint did not round-trip exactly");
        std::cout << "PASS exact native HDR scene in GLB\n";
        return 0;
    }
    if (argc != 2)
        return 2;
    dome::Scene scene;
    dome::Mesh mesh;
    mesh.positions = {{-.5f,-.5f,0}, {.5f,-.5f,0}, {.5f,.5f,0}, {-.5f,.5f,0}};
    mesh.normals.assign(4, {0,0,1});
    mesh.indices = {0,1,2,0,2,3};
    mesh.uv = {{{0,0}}, {{1,0}}, {{1,1}}, {{0,1}}};
    auto &object = scene.active();
    object.mesh_active = true;
    object.painted = std::make_shared<dome::PaintedMesh>(mesh,64);
    object.material.emissive = {8,.016f,.16f};
    dome::PaintSettings ink;
    ink.channel = dome::PaintChannel::Emission;
    ink.emission_units = dome::PaintEmissionUnits::Physical;
    ink.emission = {12,.005f,3};
    ink.front_only = false;
    dome::Brush brush;
    brush.from = brush.to = {0,0,0};
    brush.normal = {0,0,1};
    brush.radius = .19f;
    brush.strength = .73f;
    object.painted->begin_stroke();
    object.painted->stamp(brush,ink);
    if (!object.painted->end_stroke() || !object.painted->has_physical_emission())
        throw std::runtime_error("Fixture requires genuine physical paint");
    scene.save(argv[1]);
    return 0;
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
}
