from pathlib import Path
import hashlib
import json
import os
import shlex
import struct
import subprocess
import sys

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
source=artifacts/'headless-standard-glb-export-source-20261126'
parent=artifacts/'atlas-direct-grid-main-port-validation-20261126'/profile
support=artifacts/'hdr-preview-history-main-port-validation-20261126/asan/build' if profile=='asan' else artifacts/'dormant-main-release-20261126'
old=artifacts/('hdr-preview-history-main-port-source-20261126' if profile=='asan' else 'dormant-main-source-20261126')
out=base/profile
out.mkdir(mode=0o700)
state={'profile':profile,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}


def git(path,*args):
    return subprocess.check_output(['git','-C',path,*args],text=True).strip()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def save(**fields):
    state.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')


def run(cmd,name,cwd=support,ok=True,timeout=120):
    with (out/(name+'.log')).open('w') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        status=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
    if ok is not None:
        assert (status==0)==ok,(name,status)
    return status


def inspect(path):
    with path.open('rb') as file:
        magic, version, total, size, kind=struct.unpack('<4sIIII',file.read(20))
        assert magic==b'glTF' and version==2 and total==path.stat().st_size and kind==0x4e4f534a
        parsed=json.loads(file.read(size))
    mesh,=parsed['meshes']
    primitive,=mesh['primitives']
    access=parsed['accessors'][primitive['indices']]
    return {'sha256':sha(path),'triangles':access['count']//3,'attributes':sorted(primitive['attributes'])}


try:
    checked=json.loads((parent/'status.json').read_text())
    assert checked['terminal'] and checked['exit']==0 and sha(parent/'dome-sculpt')==checked['linked']['dome-sculpt']
    assert not git(source,'status','--porcelain')
    assert git(source,'diff','--name-only',checked['candidate'],'HEAD','--','src','include','CMakeLists.txt','third_party').splitlines()==['src/app.cpp']
    previous=artifacts/'headless-standard-glb-export-validation-20261126'/profile
    baseline=json.loads((previous/'status.json').read_text())
    binary=previous/'dome-sculpt'
    assert baseline['candidate']==git(source,'rev-parse','HEAD') and baseline['app_sha256']==sha(binary)
    assert (previous/'files.glb').is_file()
    save(phase='qualify ordinary and retained HDR exports',candidate=baseline['candidate'],core_source=checked['candidate'])
    sdk=(artifacts/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit'))
    variables={'PATH':'/usr/bin:/bin','HOME':'/tmp','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
               'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,'--proc','/proc','--dev','/dev',
            '--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    for key,value in variables.items():
        prefix.extend(['--setenv',key,value])
    data=artifacts/'atlas-sparse-boundary-grid-timing-20261126/parent-1/state/dome-sculpt'
    native,=data.glob('*.dsculpt')
    expected,=data.glob('*.glb')
    expected_result=inspect(expected)
    save(phase='normal worker matches XR Files export',app_sha256=sha(binary),native_input_sha256=sha(native),expected=expected_result)
    case=previous/'files.glb'
    observed=inspect(case)
    assert observed==expected_result
    old_case=previous/'direct-predecessor.glb'
    old_code=0
    old_result=inspect(old_case)
    assert old_result==observed
    target='dome-sculpt-emission-export-test'
    entry=next(row for row in json.loads((support/'compile_commands.json').read_text()) if row['file'].endswith('/tests/emission-export.cpp'))
    flags=[word.replace(str(old),str(source)) for word in shlex.split(entry['command'])]
    slot=flags[flags.index('-o')+1]
    obj=out/'fixture.o'
    flags[flags.index('-o')+1]=str(obj)
    flags[flags.index(str(source/'tests/emission-export.cpp'))]=str(base/'fixture.cpp')
    run(flags,'compile-fixture')
    raw=subprocess.check_output(['ninja','-C',support,'-t','commands',target],text=True).splitlines()[-1]
    link=[word for word in shlex.split(raw)[2:-2] if not word.startswith('-Wl,--dependency-file=')]
    fixture=out/'fixture'
    link[link.index(slot)]=str(obj)
    link[link.index('-o')+1]=str(fixture)
    atlas=parent/'libxatlas.a'
    assert sha(atlas)==checked['atlas_sha256']
    link[link.index('libxatlas.a')]=str(atlas)
    if profile=='release':
        paint=artifacts/'hdr-preview-history-main-port-validation-20261126/release/paint.o'
        assert sha(paint)==checked['reused_exact_paint']
        link.insert(link.index('libdome-sculpt-core.a'),str(paint))
    run(link,'link-fixture')
    hdr=out/'owned-hdr.dsculpt'
    run([*prefix,fixture,hdr],'generate')
    hdr_result=out/'retained-hdr.glb'
    hdr_parent=out/'retained-hdr-parent.glb'
    record=run([*prefix,parent/'dome-sculpt','--export-project',hdr,hdr_parent],'retained-hdr-parent',ok=False)
    assert not hdr_parent.exists()
    run([*prefix,binary,'--export-project',hdr,hdr_result],'retained-hdr-worker')
    with hdr_result.open('rb') as stream:
        magic,version,total,size,kind=struct.unpack('<4sIIII',stream.read(20))
        assert magic==b'glTF' and version==2 and total==hdr_result.stat().st_size and kind==0x4e4f534a
        attributes=json.loads(stream.read(size))
    assert all(k in attributes for k in ('scenes','extensionsUsed','textures','images'))
    run([*prefix,fixture,hdr,hdr_result],'verify-native-round-trip')
    assert 'PASS exact native HDR scene in GLB' in (out/'verify-native-round-trip.log').read_text()
    save(hdr={'input_sha256':sha(hdr),'output_sha256':sha(hdr_result),'extensions':attributes['extensionsUsed'],
              'prior_exit':record,'no_prior_output':True})
    protected=out/'files.glb'
    protected.write_bytes(case.read_bytes())
    broken=out/'truncated.dsculpt'
    broken.write_bytes(native.read_bytes()[:50])
    run([*prefix,binary,'--export-project',broken,protected],'close-with-invalid-project',ok=False)
    assert inspect(protected)==observed and not git(source,'status','--porcelain')
    save(phase='complete',terminal=True,exit=0,export=observed,previous_export=old_result,previous_exit=old_code,
         exact_worker_glb=True,invalid_project_preserves_previous_output=True)
except Exception as error:
    save(terminal=True,exit=1,error=repr(error))
    raise
