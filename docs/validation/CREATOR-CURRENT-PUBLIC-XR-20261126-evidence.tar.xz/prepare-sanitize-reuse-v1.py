from pathlib import Path
import hashlib,json,re,shlex,subprocess,os,time
out=Path(__file__).resolve().parent;b=out/'sanitize';src=out.parent/'vroid-creator-public-resume-20261126'
parent=out.parent/'current-normal-sanitize-20261126';parent_src=out.parent/'current-normal-resume-20261126'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=json.loads((parent/'audit.json').read_text());assert not audit['errors']and audit['actual_core_owners']==197
prior_pins=json.loads((parent/'before-inputs.json').read_text())
def old_hash(p):
    if str(p)in prior_pins:return prior_pins[str(p)]['sha256']
    return audit['derived_inputs'].get(str(p))
old_commands={str(Path(v['output']).relative_to(parent)):v for v in json.loads((parent/'compile_commands.json').read_text())}
commands={str(Path(v['output']).relative_to(b)):v for v in json.loads((b/'compile_commands.json').read_text())}
qualified={str(Path(v['object']).relative_to(parent)):v for v in audit['owners']}
required=[]
for line in (out/'sanitize-target-commands.txt').read_text().splitlines():
    if line.startswith(('/usr/bin/c++ ','/usr/bin/cc '))and' -c 'in line:
        tokens=shlex.split(line);required.append(tokens[tokens.index('-o')+1])
reused={};reasons={};pins={}
for rel in required:
    if rel not in qualified:reasons[rel]='No qualified parent owner';continue
    current=commands[rel];old=old_commands[rel];owner=qualified[rel]
    if current['file'].endswith('/vroid-creator.cpp'):reasons[rel]='Genuine source-asset root macro consumer must be rebuilt for this source tree';continue
    normalized=old['command'].replace(str(parent_src),str(src)).replace(str(parent),str(b))
    if shlex.split(normalized)!=shlex.split(current['command']):reasons[rel]='Effective compile context differs';continue
    assert sha(owner['object'])==owner['object_sha256']and sha(owner['depfile'])==owner['depfile_sha256']
    record=json.loads(Path(owner['record']).read_text());assert record['exit']==0 and record['object_sha256']==owner['object_sha256']
    for name in owner['dependencies']:
        path=Path(name);expected=old_hash(path);assert expected and sha(path)==expected,('Parent dependency changed',name)
        if path.is_relative_to(parent_src):
            counterpart=src/path.relative_to(parent_src);assert counterpart.is_file()and sha(counterpart)==expected,('Current source/ABI dependency differs',name)
        elif path.is_relative_to(parent):
            assert name in audit['derived_inputs'],('Unknown parent generated dependency',name)
        pins[name]=expected
    pins[owner['object']]=owner['object_sha256'];pins[owner['depfile']]=owner['depfile_sha256'];pins[owner['record']]=sha(owner['record'])
    reused[rel]={'object':owner['object'],'object_sha256':owner['object_sha256'],'actual_MD':owner['depfile'],'actual_MD_sha256':owner['depfile_sha256'],'actual_record':owner['record'],'effective_command_normalization':'Only equivalent source/build prefixes; all actual dependency bytes checked. No object/MD copied or relabelled.','source_dependencies_verified':len(owner['dependencies'])}
# Generate genuine current headers before the fresh owning compiles.
recipes=[['/usr/bin/cmake','-DSOURCE='+str(src/'experiments/armorpaint-blur/vendor/make_blur.c'),'-DOUTPUT='+str(b/'armorpaint-blur-generated/blur_weights.hpp'),'-P',str(src/'cmake/armorpaint-blur-weights.cmake')],['/usr/bin/wayland-scanner','client-header',str(src/'third_party/desktop/appmenu.xml'),str(b/'appmenu-client.h')],['/usr/bin/wayland-scanner','private-code',str(src/'third_party/desktop/appmenu.xml'),str(b/'appmenu-protocol.c')]]
for path in [Path('/usr/bin/cmake'),Path('/usr/bin/wayland-scanner'),src/'experiments/armorpaint-blur/vendor/make_blur.c',src/'cmake/armorpaint-blur-weights.cmake',src/'third_party/desktop/appmenu.xml']:pins[str(path)]=sha(path)
for command in recipes:subprocess.run(command,cwd=b,check=True)
for path in [b/'armorpaint-blur-generated/blur_weights.hpp',b/'appmenu-client.h',b/'appmenu-protocol.c']:pins[str(path)]=sha(path)
pins.update(json.loads((out/'build-before.json').read_text()));pins.update(json.loads((out/'build-before-system-link.json').read_text())['pins']);pins.update(json.loads((out/'followup-before.json').read_text())['extra_pins'])
sdk=out.parent/'sdk-20261126/toolkit-sanitize'
for path in sdk.rglob('*'):
    if path.is_file():pins[str(path)]=sha(path)
# Keep real parent object inputs in the build graph. Remove only their child
# compiler edges; original raw graph and real parent MDs remain authoritative.
ninja=b/'build.ninja';original=ninja.read_text();(b/'build.original.ninja').write_text(original)
blocks=original.split('\n\n');removed=0;result=[]
for block in blocks:
    first=next((line for line in block.splitlines()if line.startswith('build ')),None)
    if first:
        output=first[6:].split(':',1)[0]
        if output in reused:removed+=1;continue
    result.append(block)
text='\n\n'.join(result)
assert removed==len(reused),(removed,len(reused))
for rel,row in sorted(reused.items(),key=lambda x:len(x[0]),reverse=True):
    text=re.sub(r'(?<![A-Za-z0-9_./-])'+re.escape(rel)+r'(?![A-Za-z0-9_./-])',row['object'],text)
ninja.write_text(text)
plan={'source':'5509958f','production':'05f5d1cc','parent_source':audit['source'],'parent_audit_sha256':sha(parent/'audit.json'),'prepared_epoch':time.time(),'actual_required_unique_owners':len(required),'qualified_unchanged_owners':reused,'fresh_required_owners':reasons,'actual_fresh_unique_owners':len(required)-len(reused),'generator_commands':recipes,'original_graph_sha256':sha(b/'build.original.ninja'),'qualified_graph_sha256':sha(ninja),'source_code_changed':False,'no_copied_or_fabricated_parent_MD':True}
(out/'sanitize-before.json').write_text(json.dumps(pins,indent=2)+'\n');(out/'sanitize-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({k:v for k,v in plan.items()if k not in ['qualified_unchanged_owners','fresh_required_owners','generator_commands']},indent=2))
