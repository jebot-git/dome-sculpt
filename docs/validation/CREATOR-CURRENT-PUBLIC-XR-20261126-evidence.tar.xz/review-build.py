"""Independent audit of actual fresh compiler/archive/link outputs.

The primary executor deliberately retains its original unclassified generated
input failure. This audit identifies that genuine CMake-derived header using
its prospectively pinned generator/source and an independent exact replay.
"""
from pathlib import Path
import hashlib,json,os,re,shlex,subprocess,time
out=Path(__file__).resolve().parent;b=out/'release';src=out.parent/'vroid-creator-public-resume-20261126'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins=json.loads((out/'build-before.json').read_text())
system=json.loads((out/'build-before-system-link.json').read_text())
pins.update(system['pins']);plan=json.loads((out/'build-plan.json').read_text())
followup=json.loads((out/'followup-before.json').read_text());pins.update(followup['extra_pins'])
status={'exit':1,'scope':'Independent actual fresh source5509958f/production05 App+creator inspector/runtime/clock build audit only; no runtime acceptance'}
def dep_names(path):
    text=Path(path).read_text().replace('\\\n',' ')
    line=text.splitlines()[0]
    return shlex.split(line.split(':',1)[1])
def absolute(name):
    path=Path(name)
    return Path(os.path.normpath(path if path.is_absolute()else b/path))
try:
    drift=[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
    assert not drift,drift
    header=b/'armorpaint-blur-generated/blur_weights.hpp'
    generator=src/'cmake/armorpaint-blur-weights.cmake';source=src/'experiments/armorpaint-blur/vendor/make_blur.c'
    assert str(generator)in pins and str(source)in pins
    replay=out/'generator-replay/blur_weights.hpp';replay.parent.mkdir(exist_ok=True)
    command=['/usr/bin/cmake','-DSOURCE='+str(source),'-DOUTPUT='+str(replay),'-P',str(generator)]
    result=subprocess.run(command,capture_output=True,text=True)
    (out/'generator-replay.log').write_text(result.stdout+result.stderr)
    assert result.returncode==0 and replay.read_bytes()==header.read_bytes()
    derived={str(header):{'sha256':sha(header),'actual_before_pinned_inputs':[str(generator),str(source)],'independent_replay_command':command,'exact_replay':True,'not_called_a_prospective_generated_byte_pin':True}}
    owners=[];objects={};unknown=set()
    for md in sorted(b.rglob('*.o.d')):
        obj=Path(str(md)[:-2]);assert obj.is_file()and obj.stat().st_mtime>=plan['started']
        dependencies=[]
        for name in dep_names(md):
            path=absolute(name);key=str(path)
            if key not in pins and key not in derived:unknown.add(key)
            dependencies.append(key)
        digest=sha(obj);objects[str(obj)]=digest
        owners.append({'actual_MD':str(md),'actual_MD_sha256':sha(md),'actual_object':str(obj),'actual_object_sha256':digest,'dependencies':dependencies})
    assert not unknown,sorted(unknown)
    ninja=(b/'build.ninja').read_text();archives={}
    for archive in sorted(b.glob('*.a')):
        match=re.search(r'^build '+re.escape(archive.name)+r': [^\n]+$',ninja,re.M);assert match
        object_paths=[absolute(name)for name in shlex.split(match.group().split(':',1)[1])if name.endswith('.o')]
        members=subprocess.check_output(['/usr/bin/ar','t',str(archive)],text=True).splitlines()
        assert members==[p.name for p in object_paths]and len(members)==len(set(members)),archive
        for member,path in zip(members,object_paths):
            assert str(path)in objects,(archive,path)
            payload=subprocess.check_output(['/usr/bin/ar','p',str(archive),member])
            assert hashlib.sha256(payload).hexdigest()==objects[str(path)],(archive,member)
        archives[archive.name]={'sha256':sha(archive),'actual_verified_payloads':len(members),'actual_object_writers':[str(p)for p in object_paths]}
    links={}
    for target in ['dome-sculpt','dome-sculpt-creator-workspace-test','dome-sculpt-creator-workspace-runtime','dome-sculpt-xr-fixture-clock-test','dome-sculpt-source-joint-writable-normal-bake-test']:
        dependency=b/'CMakeFiles'/(target+'.dir')/'link.d';assert dependency.is_file(),dependency
        inputs=[]
        for name in dep_names(dependency):
            path=absolute(name);key=str(path);resolved=str(path.resolve())
            if key in pins:assert sha(path)==pins[key]
            elif resolved in pins:assert sha(path)==pins[resolved]
            else:assert path.is_relative_to(b)and(path.suffix in ['.o','.a']or path.name in ['libdome-sculpt-core.a']),('Unknown external actual linker input',path)
            inputs.append({'literal':name,'path':key,'sha256':sha(path)})
        links[target]={'actual_link_dependency_file':str(dependency),'sha256':sha(dependency),'inputs':inputs}
    for path in followup['actual_affected_complete_owners']:assert Path(path).stat().st_mtime>=followup['started']
    status.update(exit=0,actual_complete_TUs=len(owners),fresh_initial_TUs=249,actual_recompiled_complete_TUs=3,new_joint_TUs=1,actual_core_members=archives['libdome-sculpt-core.a']['actual_verified_payloads'],actual_archives=archives,actual_link_targets=len(links),known_derived_inputs=derived,prospectively_pinned_generator_replays=followup['generator_exact_replays'],unknown_dependencies=[],input_drift=[],actual_MDs_sha256=None,products={p.name:sha(p)for p in [b/'dome-sculpt',b/'dome-sculpt-creator-workspace-test',b/'libdome-sculpt-creator-workspace-runtime.so',b/'dome-sculpt-xr-fixture-clock-test',b/'dome-sculpt-source-joint-writable-normal-bake-test']})
    (out/'review-actual-MD-owners.json').write_text(json.dumps(owners,indent=2)+'\n');(out/'review-actual-link-inputs.json').write_text(json.dumps(links,indent=2)+'\n')
    status['actual_MDs_sha256']=sha(out/'review-actual-MD-owners.json')
except BaseException as error:status['error']=repr(error)
(out/'build-review.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps({k:v for k,v in status.items()if k not in ['actual_archives','known_derived_inputs']},indent=2))
raise SystemExit(status['exit'])
