from pathlib import Path
import hashlib,json,shlex,subprocess,os,re,time
out=Path(__file__).resolve().parent;b=out/'sanitize';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((out/'sanitize-plan.json').read_text());pins=json.loads((out/'sanitize-before.json').read_text())
def absolute(name):
    p=Path(name);return Path(os.path.normpath(p if p.is_absolute()else b/p))
def dependencies(file):return shlex.split(Path(file).read_text().replace('\\\n',' ').splitlines()[0].split(':',1)[1])
status={'exit':1,'scope':'Matched strict current05 App/public fixtures build only; not public runtime acceptance'}
try:
    assert sha(b/'build.ninja')==plan['qualified_graph_sha256']
    drift=[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h];assert not drift,drift
    owners=[];objects={};unknown=set()
    for rel,row in plan['qualified_unchanged_owners'].items():
        assert sha(row['object'])==row['object_sha256']and sha(row['actual_MD'])==row['actual_MD_sha256']
        objects[row['object']]=row['object_sha256'];owners.append({'role':'Qualified unchanged strict parent whole TU; original object/MD paths retained',**row})
    for md in sorted(b.rglob('*.o.d')):
        obj=Path(str(md)[:-2]);assert obj.is_file()
        deps=[]
        for name in dependencies(md):
            p=absolute(name);key=str(p)
            if key not in pins and str(p.resolve())not in pins:unknown.add(key)
            deps.append(key)
        objects[str(obj)]=sha(obj);owners.append({'role':'Fresh complete strict TU','object':str(obj),'object_sha256':sha(obj),'actual_MD':str(md),'actual_MD_sha256':sha(md),'dependencies':deps})
    assert not unknown,sorted(unknown)
    assert len(owners)==plan['actual_required_unique_owners']and len(owners)-len(plan['qualified_unchanged_owners'])==plan['actual_fresh_unique_owners']
    ninja=(b/'build.ninja').read_text();archives={}
    for archive in sorted(b.glob('*.a')):
        line=re.search(r'^build '+re.escape(archive.name)+r': [^\n]+$',ninja,re.M);assert line
        object_paths=[absolute(name)for name in shlex.split(line.group().split(':',1)[1])if name.endswith('.o')]
        members=subprocess.check_output(['/usr/bin/ar','t',str(archive)],text=True).splitlines()
        assert members==[p.name for p in object_paths]and len(set(members))==len(members)
        for member,obj in zip(members,object_paths):
            assert str(obj)in objects
            payload=subprocess.check_output(['/usr/bin/ar','p',str(archive),member]);assert hashlib.sha256(payload).hexdigest()==objects[str(obj)]
        archives[archive.name]={'sha256':sha(archive),'actual_verified_payloads':len(members),'actual_object_writers':[str(p)for p in object_paths]}
    links={}
    for target in ['dome-sculpt','dome-sculpt-creator-workspace-test','dome-sculpt-creator-workspace-runtime','dome-sculpt-xr-fixture-clock-test']:
        md=b/'CMakeFiles'/(target+'.dir')/'link.d';assert md.is_file()
        inputs=[]
        for name in dependencies(md):
            p=absolute(name);key=str(p);resolved=str(p.resolve());assert '/opt/fltk-vr/toolkit/lib/'not in key and '/creator-public-build-20261126/release/'not in key,('Release input in strict link',key)
            if key in pins:assert sha(p)==pins[key]
            elif resolved in pins:assert sha(p)==pins[resolved]
            else:assert p.is_relative_to(b)and p.suffix in ['.a','.o'],('Unknown actual strict linker input',key)
            inputs.append({'path':key,'sha256':sha(p)})
        elf=b/('lib'+target+'.so'if target.endswith('runtime')else target)
        needed=subprocess.check_output(['/usr/bin/readelf','-d',str(elf)],text=True)
        assert 'libasan.so'in needed and 'libubsan.so'in needed
        links[target]={'actual_MD':str(md),'actual_MD_sha256':sha(md),'inputs':inputs,'ELF':str(elf),'ELF_sha256':sha(elf),'ASan_and_UBSan_DT_NEEDED':True}
    status.update(exit=0,actual_unique_owners=len(owners),qualified_parent_whole_owners=len(plan['qualified_unchanged_owners']),fresh_whole_owners=plan['actual_fresh_unique_owners'],core_members=archives['libdome-sculpt-core.a']['actual_verified_payloads'],archives=archives,links=links,unknown_dependencies=[],input_drift=[],completed_epoch=time.time())
    (out/'sanitize-actual-owner-audit.json').write_text(json.dumps(owners,indent=2)+'\n')
except BaseException as error:status['error']=repr(error)
(out/'sanitize-review.json').write_text(json.dumps(status,indent=2)+'\n')
print(json.dumps({k:v for k,v in status.items()if k not in ['archives','links']},indent=2));raise SystemExit(status['exit'])
