import pathlib,json,subprocess,hashlib,os,time,shlex
out=pathlib.Path(__file__).resolve().parent;src=out.parent/'vroid-creator-public-resume-20261126';build=out/'release';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,x):(out/n).write_text(json.dumps(x,indent=2)+'\n')
started=time.time();env=os.environ.copy();env.update(PKG_CONFIG_PATH='/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig',LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=src).decode().split('\0');paths={str(src/p)for p in tracked if p and (src/p).is_file()}
roots=[pathlib.Path('/usr/include'),pathlib.Path('/opt/fltk-vr/toolkit/include'),pathlib.Path('/opt/fltk-vr/bdf-runtime/include'),pathlib.Path(subprocess.check_output(['/usr/bin/c++','-print-file-name=include'],text=True).strip())]
for root in roots:
 paths.update(str(p)for p in root.rglob('*')if p.is_file())
paths.update(str(p)for p in build.rglob('*')if p.is_file()and p.suffix in ['.h','.hpp','.cmake'])
for root in [pathlib.Path('/opt/fltk-vr/toolkit/lib'),pathlib.Path('/opt/fltk-vr/bdf-runtime/lib')]:paths.update(str(p)for p in root.rglob('*')if p.is_file())
paths.update(str(pathlib.Path(x).resolve())for x in ['/usr/bin/c++','/usr/bin/cc','/usr/bin/ld','/usr/bin/ar','/usr/bin/ninja','/usr/bin/cmake'])
pins={p:sha(p)for p in sorted(paths)};save('build-before.json',pins)
cmd=['/usr/bin/ninja','-C',str(build),'-d','keepdepfile','-d','keeprsp','-j2','dome-sculpt','dome-sculpt-creator-workspace-test','dome-sculpt-creator-workspace-runtime','dome-sculpt-xr-fixture-clock-test'];save('build-plan.json',{'source':'5509958f','command':cmd,'cwd':str(src),'environment':{k:env[k]for k in ['PKG_CONFIG_PATH','LD_LIBRARY_PATH']},'before_count':len(pins),'started':started})
status={'terminal':False,'started':started};save('build-status.json',status)
try:
 with (out/'build.log').open('w')as log:r=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
 status.update(exit=r.returncode,seconds=time.time()-started,drift=[p for p,h in pins.items()if not pathlib.Path(p).is_file()or sha(p)!=h]);assert r.returncode==0 and not status['drift'],status
 owners=[];unknown=set()
 for md in sorted(build.rglob('*.o.d')):
  text=md.read_text().replace('\\\n',' ');deps=shlex.split(text.split(':',1)[1]);record=[]
  for name in deps:
   p=pathlib.Path(name);p=p if p.is_absolute()else build/p;p=pathlib.Path(os.path.normpath(p));key=str(p)
   if key not in pins:unknown.add(key)
   record.append(key)
  owners.append({'MD':str(md),'MD_sha256':sha(md),'object':str(md)[:-2],'object_sha256':sha(str(md)[:-2]),'dependencies':record})
 save('actual-MD-owners.json',owners);status.update(actual_complete_TUs=len(owners),unknown_dependencies=sorted(unknown),products={p.name:sha(p)for p in [build/'dome-sculpt',build/'dome-sculpt-creator-workspace-test',build/'libdome-sculpt-creator-workspace-runtime.so',build/'dome-sculpt-xr-fixture-clock-test']});assert not unknown,sorted(unknown)
except BaseException as e:status.update(error=repr(e),exit=1)
finally:status['terminal']=True;save('build-status.json',status)
raise SystemExit(status.get('exit',1))
