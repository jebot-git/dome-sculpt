from pathlib import Path
import hashlib
import json
import os
import re

from owned_monitor import run

here=Path(__file__).resolve().parent
plan=json.loads((here/'build-plan.json').read_text())
build=json.loads((here/'build-status.json').read_text())
assert plan['source']=='ec578e561c99ec681e9db57f657c0823526b0151'
assert build['terminal'] and build['exit']==0 and build['linked_archive']['members']==197
assert not Path('/dev/dri').exists()
assert not any(k in os.environ for k in ('MALLOC_ARENA_MAX','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES'))
for obj in plan['replacement_objects']:
    d=Path(obj+'.d').read_text()
    assert 'production-sculpt-index-integration-source-20261126/src/sculpt-chunk-index.hpp' in d
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
out=here/'native-default'
out.mkdir()
state={'source':plan['source'],'terminal':False,'cases':{},'no_dri_nodes':True,
       'allocator':'default','app_sha256':sha(here/'dome-sculpt')}
def save():
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
save()
try:
    tests=[
       ('sculpt-surface-chunks-test',[],r'^26 sculpt chunk checks passed$'),
       ('sculpt-chunk-pipeline-test',[str(out/'pipeline')],r'^PASS total 92$'),
       ('sculpt-independent-workflow',[str(out/'sculpt')],r'^PASS independent production sculpt workflow checks=167'),
    ]
    for name,args,pattern in tests:
        elf=here/f'dome-sculpt-{name}'
        log=out/f'{name}.log'
        row=run([str(elf),*args],cwd=out,env=os.environ.copy(),log=log,timeout=900,max_rss=4*1024**3)
        row.update(sha256=sha(elf),check_passed=bool(re.search(pattern,log.read_text(),re.M)))
        state['cases'][name]=row
        save()
    state['exit']=int(any(x['exit']!=0 or 'error' in x or not x['check_passed'] for x in state['cases'].values()))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
