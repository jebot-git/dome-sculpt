from pathlib import Path
import json,os,shlex,subprocess,sys,hashlib
base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
asan=profile=='asan'
out=base/profile
out.mkdir(exist_ok=True)
source=artifacts/'retained-target-export-final-source-20261126'
prior=artifacts/'retained-target-bake-final-20261126'/profile
objects=artifacts/'retained-target-bake-qualified-20261126'/profile
support=artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
build=prior/'build'
candidate=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
status={'candidate':candidate,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def record(**fields):
 status.update(fields)
 temp=out/'status.tmp'
 temp.write_text(json.dumps(status,indent=2)+'\n');temp.replace(out/'status.json')
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(argv, log, cwd=out, timeout=240):
 with (out/log).open('w') as file:
  print(shlex.join(map(str,argv)),file=file,flush=True)
  subprocess.run(argv,cwd=cwd,stdout=file,stderr=subprocess.STDOUT,check=True,timeout=timeout)
try:
 assert candidate=='eff4e04760a87cfc77191d5840cfbff85565c4c5'
 assert not subprocess.check_output(['git','-C',source,'status','--porcelain'])
 assert subprocess.check_output(['git','-C',source,'diff','--name-only','HEAD^','HEAD'],text=True).splitlines()==['tests/texture-set-source-export.cpp']
 base_status=json.loads((prior/'status.json').read_text())
 assert base_status['exit']==0 and base_status['core_sha256']==digest(objects/'libdome-sculpt-core.a')
 prepared=artifacts/'retained-target-export-worker-20261126'/profile
 source_record=json.loads((prepared/'pre-link-status.json').read_text()) if (prepared/'pre-link-status.json').is_file() else json.loads((prepared/'status.json').read_text())
 assert source_record['candidate']=='f4bf166c8fdf5a9d80bbdfb3ac5f3f75649786e9' and source_record['terminal']
 core=prepared/'libdome-sculpt-core.a'
 assert source_record['core_sha256']==digest(core)
 app=out/'dome-sculpt'
 link=shlex.split((prior/'dome-sculpt-link.log').read_text().splitlines()[0])
 link[link.index('-o')+1]=str(app)
 link=[str(core) if w.endswith('/libdome-sculpt-core.a') else w for w in link]
 run(link,'app-link.log',support)
 for name in ('corner-uv','hdr-worker'):
  (out/name).symlink_to(prepared/name)
 test='dome-sculpt-texture-set-source-export-test'
 row=next(r for r in json.loads((build/'compile_commands.json').read_text())
     if r['file'].endswith('/tests/texture-set-source-export.cpp'))
 cmd=shlex.split(row['command']);obj=out/'source-uv.o'
 spot=cmd.index('-o')+1
 old=cmd[spot];cmd[spot]=str(obj)
 original=artifacts/'retained-target-bake-final-source-20261126'
 cmd=[word.replace(str(original),str(source)) for word in cmd]
 run(cmd,'source-fixture-build.log',build,360)
 link=shlex.split(subprocess.check_output(['ninja','-C',build,'-t','commands',test],text=True).splitlines()[-1])[2:-2]
 link=[str(obj) if w==old else w for w in link if not w.startswith('-Wl,--dependency-file=')]
 link[link.index('-o')+1]=str(out/'source-uv')
 link=[str(core) if Path(w).name==core.name else str(support/w) if w.startswith('lib') and w.endswith('.a') else w for w in link]
 run(link,'source-fixture-link.log',build)
 record(core_sha256=digest(core),fixture_sha256=digest(obj))
 cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
  '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
  '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH',
  f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
 if asan:cmd+=['--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1','--setenv','UBSAN_OPTIONS','halt_on_error=1']
 record(phase='test retained portable GLB, genuine HDR, and archive guard',app_sha256=digest(app))
 scene=artifacts/'retained-target-bake-public-20261126'/'release'/'workflow'/'accept.dsculpt'
 cases=[('corner-uv',[out/'corner-uv']),
        ('retained-target',[out/'source-uv','--retained-bake-target',out/'target']),
        ('hdr-worker',[out/'hdr-worker',out/'hdr']),
        ('headless-export',[app,'--export-project',scene,out/'retained.glb'])]
 for name,argv in cases:
  run([*cmd,*argv],name+'.log',out,360)
 assert 'PASS 79 retained target Bake controls' in (out/'retained-target.log').read_text()
 assert (out/'retained.glb').read_bytes()[:4]==b'glTF'
 record(phase='complete',terminal=True,exit=0,headless_glb_sha256=digest(out/'retained.glb'),
        case_sha256={n:digest(out/(n+'.log')) for n,_ in cases})
except Exception as err:
 record(terminal=True,exit=1,error=repr(err))
 raise
