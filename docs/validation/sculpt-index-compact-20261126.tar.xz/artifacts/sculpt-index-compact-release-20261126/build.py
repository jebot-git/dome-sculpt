import pathlib,subprocess,shlex,hashlib,json,time,sys
B=pathlib.Path(__file__).resolve().parent; strict='sanitize' in B.name
R=B.parent/('sculpt-index-lifetimes-sanitize-20261126' if strict else 'sculpt-index-lifetimes-release-20261126')
C=B.parent/('sculpt-workflow-sanitize-20261126' if strict else 'sculpt-workflow-release-20261126')
Support=B.parent/'current-normal-sanitize-20261126' if strict else B.parent/'sculpt-workflow-release-20261126'
oldS=B.parent/'sculpt-workflow-source-20261126'; S=B.parent/'sculpt-index-compact-source-20261126'
fixtureOld=B.parent/('sculpt-workflow-input-scope-sanitize-20261126' if strict else 'sculpt-workflow-input-scope-release-20261126')
targets=['dome-sculpt-sculpt-independent-workflow','dome-sculpt-sculpt-sustained','dome-sculpt-sculpt-surface-chunks-test','dome-sculpt-sculpt-chunk-pipeline-test']
changed=['sculpt-surface-chunks.cpp.o']
st={'source':'7a06dbe5','started':time.time(),'terminal':False,'scope':'One changed complete surface compiler TU;196 qualified current owners and all4 actual existing consumer TUs after MD/source-byte equality; compact owner account only','strict':strict}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(B/'status.json').write_text(json.dumps(st,indent=2)+'\n')
def deps(p):return shlex.split(pathlib.Path(p).read_text().replace('\\\n',' ').split(':',1)[1].split('\n')[0])
def run(a,label):
 with (B/(label+'.log')).open('w') as f:r=subprocess.run(a,cwd=B,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(label,r.returncode)
def checkdeps(md,pins):
 for d in deps(md):
  p=pathlib.Path(d).resolve();pins[str(p)]=sha(p)
  for root in [oldS,B.parent/'current-normal-resume-20261126',B.parent/'sculpt-workflow-input-scope-source-20261126',B.parent/'sculpt-index-lifetimes-source-20261126']:
   if p.is_relative_to(root):
    q=S/p.relative_to(root);assert sha(q)==sha(p),(str(md),str(q));pins[str(q)]=sha(q);break
save()
try:
 assert json.loads((R/'status.json').read_text())['exit']==0
 coreowners=json.loads((R/'actual-core-owners.json').read_text())['owners']
 assert len(coreowners)==197
 pins={};comp=[];fresh=[];selected={};records=[]
 cmdlines=subprocess.check_output(['ninja','-C',str(C),'-t','commands',*targets],text=True).splitlines()
 for o in coreowners:
  name=pathlib.Path(o['object']).name
  if name in changed:
   c=next(shlex.split(x) for x in cmdlines if x.startswith('/usr/bin/') and ' -c ' in x and 'dome-sculpt-core.dir/src/'+name+' ' in x)
   c=[x.replace(str(oldS),str(S)) for x in c];c[c.index('-o')+1]=str(B/name);c[c.index('-MF')+1]=str(B/(name+'.d'));c.append('-fdump-lang-class='+str(B/'source-layout.class'));comp.append(c);fresh.append(name);selected[name]=str(B/name)
  else:
   assert sha(o['object'])==o['sha256'];checkdeps(o['actual_md'],pins);pins[o['object']]=sha(o['object']);pins[o['actual_md']]=sha(o['actual_md']);selected[name]=o['object'];records.append(o)
 fixtures={}
 for t in targets:
  if t=='dome-sculpt-sculpt-independent-workflow':
   op=fixtureOld/(t+'.o');md=fixtureOld/(t+'.o.d');assert json.loads((fixtureOld/('link-status.json' if strict else 'status.json')).read_text())['exit']==0;checkdeps(md,pins);fixtures[t]=str(op);pins[str(op)]=sha(op);pins[str(md)]=sha(md)
  elif t in ['dome-sculpt-sculpt-surface-chunks-test','dome-sculpt-sculpt-sustained']:
   op=R/(t+'.o');md=R/(t+'.o.d');checkdeps(md,pins);fixtures[t]=str(op);pins[str(op)]=sha(op);pins[str(md)]=sha(md)
  elif t=='dome-sculpt-sculpt-chunk-pipeline-test':
   op=C/'CMakeFiles'/(t+'.dir/tests/sculpt-chunk-pipeline.cpp.o');md=pathlib.Path(str(op)+'.d');checkdeps(md,pins);fixtures[t]=str(op);pins[str(op)]=sha(op);pins[str(md)]=sha(md)
  else:
   c=next(shlex.split(x) for x in cmdlines if x.startswith('/usr/bin/') and ' -c ' in x and t+'.dir/tests/' in x)
   c=[x.replace(str(oldS),str(S)) for x in c];c[c.index('-o')+1]=str(B/(t+'.o'));c[c.index('-MF')+1]=str(B/(t+'.o.d'));comp.append(c);fresh.append(t+'.o');fixtures[t]=str(B/(t+'.o'))
 for i,c in enumerate(comp):
  a=[c[0]];j=1
  while j<len(c):
   if c[j] in ['-o','-MF','-MT','-MQ']:j+=2;continue
   if c[j] in ['-MD','-MMD','-c']:j+=1;continue
   a.append(c[j]);j+=1
  d=B/(str(i)+'.prospective.d');run(a+['-M','-MF',str(d),'-MT','prospective'],'scan-'+str(i))
  for q in deps(d):p=pathlib.Path(q).resolve();pins[str(p)]=sha(p)
  pins[str(pathlib.Path(c[0]).resolve())]=sha(pathlib.Path(c[0]).resolve())
 links=[]
 for t in targets:
  line=next(x for x in cmdlines if x.startswith(': && /usr/bin/c++') and ' -o '+t+' ' in x);a=shlex.split(line.removeprefix(': && ').removesuffix(' && :'))
  for i,x in enumerate(a):
   if x.endswith('.a') and not x.startswith('/'):a[i]=str(B/x) if x=='libdome-sculpt-core.a' else str(Support/x)
   elif x.endswith('.o') and not x.startswith('/'):a[i]=fixtures[t]
   elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(B/(t+'.link.d'))
  a[a.index('-o')+1]=str(B/t);links.append(a)
  for p in a:
   q=pathlib.Path(p)
   if q.is_absolute() and q.is_file():pins[str(q.resolve())]=sha(q)
 (B/'before-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(B/'commands.json').write_text(json.dumps({'compile':comp,'link':links},indent=2)+'\n');(B/'qualified-core-owners.json').write_text(json.dumps(records,indent=2)+'\n')
 for i,c in enumerate(comp):run(c,'compile-'+str(i));assert all(str(pathlib.Path(q).resolve()) in pins for q in deps(c[c.index('-MF')+1]))
 order=subprocess.check_output(['ar','t',str(R/'libdome-sculpt-core.a')],text=True).splitlines();assert len(set(order))==197
 core=B/'libdome-sculpt-core.a';assert not core.exists();run(['/usr/bin/ar','qc',str(core),*[selected[n] for n in order]],'archive');run(['/usr/bin/ranlib',str(core)],'ranlib')
 for n in order:assert hashlib.sha256(subprocess.check_output(['ar','p',str(core),n])).hexdigest()==sha(selected[n]),n
 for i,a in enumerate(links):run(a,'link-'+str(i));e=subprocess.check_output(['readelf','-d',str(B/targets[i])],text=True);(B/(targets[i]+'.dynamic.txt')).write_text(e);assert not strict or ('libasan' in e and 'libubsan' in e)
 drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift
 st.update({'exit':0,'state':'passed','fresh_whole_TUs':len(comp),'fresh_core_owners':1,'qualified_unchanged_core_owners':196,'actual_archive_payloads':197,'input_drift':drift,'core_sha256':sha(core),'products':{t:sha(B/t) for t in targets}})
except BaseException as e:
 import traceback
 traceback.print_exc()
 st.update({'exit':1,'state':'failed','error':repr(e),'error_filename':getattr(e,'filename',None)})
finally:st.update({'terminal':True,'seconds':time.time()-st['started']});save()
raise SystemExit(st['exit'])
