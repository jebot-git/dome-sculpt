import subprocess,pathlib,json,time
B=pathlib.Path(__file__).resolve().parent
cases=[(B,'surface'),(B,'pipeline'),(B.parent/'sculpt-index-compact-sanitize-20261126','surface'),(B.parent/'sculpt-index-compact-sanitize-20261126','pipeline')]
s={'started':time.time(),'terminal':False,'cases':[]}
for p,k in cases:
 r=subprocess.run(['/usr/bin/python3',str(p/'run-regression-cpu.py'),k]);s['cases'].append({'path':str(p),'case':k,'exit':r.returncode})
 if r.returncode:break
s.update({'terminal':True,'finished':time.time(),'exit':int(any(c['exit'] for c in s['cases']))});(B/'regression-cohort-status.json').write_text(json.dumps(s,indent=2)+'\n')
raise SystemExit(s['exit'])
