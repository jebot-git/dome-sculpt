/home/blux/de-xr/dome-sculpt/artifacts/sculpt-index-compact-release-20261126/dome-sculpt-sculpt-surface-chunks-test: \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crt1.o \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crti.o \
  /usr/lib/gcc/x86_64-redhat-linux/16/crtbegin.o \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-index-lifetimes-release-20261126/dome-sculpt-sculpt-surface-chunks-test.o \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-index-compact-release-20261126/libdome-sculpt-core.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-paint-gpu.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-native-graphics.a \
  /usr/lib64/libOpenGL.so \
  /usr/lib64/libEGL.so \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-affine.a \
  /usr/lib64/liblapacke.so \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-polygon.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libxatlas.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libmikktspace.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libmikktspace-robust.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libufbx.a \
  /usr/lib64/libpng.so \
  /usr/lib64/libjpeg.so \
  /usr/lib64/libz.so \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-emission-codec.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-baked-emission.a \
  /usr/lib64/libOpenEXR-3_2.so \
  /usr/lib64/libOpenEXRUtil-3_2.so \
  /usr/lib64/libOpenEXRCore-3_2.so \
  /usr/lib64/libIex-3_2.so \
  /usr/lib64/libIlmThread-3_2.so \
  /usr/lib64/libImath-3_1.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libstdc++.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libm.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libm.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libm.so \
  /lib64/libm.so.6 \
  /lib64/libmvec.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so \
  /usr/lib64/libatomic.so.1.2.0 \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libc.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libc.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libc.so \
  /lib64/libc.so.6 \
  /usr/lib64/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/crtend.o \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crtn.o \
  /usr/lib64/libGLdispatch.so.0 \
  /usr/lib64/libtmglib.so.3 \
  /usr/lib64/liblapack.so.3 \
  /usr/lib64/libdeflate.so.0 \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib64/libblas.so.3 \
  /lib64/libmvec.so.1 \
  /usr/lib64/libgfortran.so.5

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crt1.o:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crti.o:

/usr/lib/gcc/x86_64-redhat-linux/16/crtbegin.o:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-index-lifetimes-release-20261126/dome-sculpt-sculpt-surface-chunks-test.o:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-index-compact-release-20261126/libdome-sculpt-core.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-paint-gpu.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-native-graphics.a:

/usr/lib64/libOpenGL.so:

/usr/lib64/libEGL.so:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-affine.a:

/usr/lib64/liblapacke.so:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-polygon.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libxatlas.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libmikktspace.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libmikktspace-robust.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libufbx.a:

/usr/lib64/libpng.so:

/usr/lib64/libjpeg.so:

/usr/lib64/libz.so:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-emission-codec.a:

/home/blux/de-xr/dome-sculpt/artifacts/sculpt-workflow-release-20261126/libdome-sculpt-baked-emission.a:

/usr/lib64/libOpenEXR-3_2.so:

/usr/lib64/libOpenEXRUtil-3_2.so:

/usr/lib64/libOpenEXRCore-3_2.so:

/usr/lib64/libIex-3_2.so:

/usr/lib64/libIlmThread-3_2.so:

/usr/lib64/libImath-3_1.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libstdc++.so:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libm.so:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libm.so:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libm.so:

/lib64/libm.so.6:

/lib64/libmvec.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so:

/usr/lib64/libatomic.so.1.2.0:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libc.so:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libc.so:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/libc.so:

/lib64/libc.so.6:

/usr/lib64/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/crtend.o:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crtn.o:

/usr/lib64/libGLdispatch.so.0:

/usr/lib64/libtmglib.so.3:

/usr/lib64/liblapack.so.3:

/usr/lib64/libdeflate.so.0:

/lib64/ld-linux-x86-64.so.2:

/usr/lib64/libblas.so.3:

/lib64/libmvec.so.1:

/usr/lib64/libgfortran.so.5:
