from pathlib import Path
import json,hashlib,tarfile,io
R=Path(__file__).resolve().parent;S=R.parent/'sculpt-index-compact-sanitize-20261126';SRC=R.parent/'sculpt-index-compact-source-20261126';ROOT=R.parents[1];V=SRC/'docs/validation';V.mkdir(exist_ok=True);files={}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):p=Path(p).resolve();assert p.is_file();files[str(p.relative_to(ROOT))]=p
for B in [R,S]:
 for p in B.iterdir():
  if p.is_file() and p.suffix in ['.py','.json','.d','.log','.txt','.class']:add(p)
 for name in ['surface-cpu-v1','pipeline-cpu-v1','native-cpu-v1']:
  for p in (B/name).iterdir():
   if p.is_file():add(p)
for name in ['src/sculpt-surface-chunks.cpp','src/sculpt-chunk-index.hpp','tests/sculpt-surface-chunks.cpp','docs/SCULPT-INDEX-ALLOCATION-LIFETIME.md']:add(SRC/name)
projects=[]
for B in [R,S]:
 for p in (B/'native-cpu-v1/workflow').rglob('*.dsculpt'):
  h=sha(p);assert h=='d32c725a02d3d9291f3208c879f78ecc343c33511de9e10b5c18d93bb95fd694';projects.append({'actual_path':str(p),'size':p.stat().st_size,'sha256':h})
q={'source':'7a06dbe5','scope':'Separate compact allocator on6d component. Actualsharedallocations8Bsmaller; Release167andR/S26+92pass. Fullstrict167 failsunchangedRSS4GiB; noRSSimprovementorcombinedapplicationacceptanceclaimed.','same_original_bounds':True,'builds':{},'runtimes':{},'allocation_layout':json.loads((R/'allocation-layout-comparison.json').read_text()),'native_projects':projects,'native_payload_reference':{'proof_commit':'9cc18990','archive_sha256':'b649ca2be7dd656d1d1bce902594abd08619cdd6414df9c88e9cc98e83226b62','member':'native-projects/d32c725a02d3d9291f3208c879f78ecc343c33511de9e10b5c18d93bb95fd694.dsculpt'},'authorities':[]}
for kind,B in [('Release',R),('ASAN_UBSAN',S)]:q['builds'][kind]=json.loads((B/'status.json').read_text());q['runtimes'][kind]={k:json.loads((B/(k+'-cpu-v1/status.json')).read_text()) for k in ['surface','pipeline','native']}
for name,p in sorted(files.items()):q['authorities'].append({'name':name,'actual_path':str(p),'sha256':sha(p),'size':p.stat().st_size})
payload=(json.dumps(q,indent=2)+'\n').encode();dest=V/'sculpt-index-compact-20261126.tar.xz';assert not dest.exists()
with tarfile.open(dest,'w:xz',preset=6) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('index.json');info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
with tarfile.open(dest,'r:xz') as tar:
 for a in q['authorities']:assert hashlib.sha256(tar.extractfile(a['name']).read()).hexdigest()==a['sha256'];assert sha(a['actual_path'])==a['sha256']
q['archive']={'name':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest),'members':len(files)+1};(V/'sculpt-index-compact-20261126.json').write_text(json.dumps(q,indent=2)+'\n');print(q['archive'])
