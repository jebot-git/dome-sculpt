import pathlib,json,os,fcntl,subprocess,time,hashlib,signal,re,resource,stat
B=pathlib.Path(__file__).resolve().parent;D=B/'native-cpu-v1';D.mkdir()
exe=B/'dome-sculpt-sculpt-independent-workflow';deadline=900;rsslimit=4*1024**3
status={'production_source':'7a06dbe5','fixture_source':'7a06dbe5','terminal':False,'started':time.time(),'command':[str(exe),str(D/'workflow')],'timeout_seconds':deadline,'rss_limit_bytes':rsslimit,'AS_cap':None,'scope':'Full-size four independent objects: native Document layers, masks, native gestures, history, ordered Save, cold Open, durable recovery and exact independent geometry; no GUI/physical-HMD claim'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(): (D/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def proc(pid):
 try:
  z=(pathlib.Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'ppid':int(z[1]),'pgrp':int(z[2]),'start':int(z[19]),'RSS':int(z[21])*os.sysconf('SC_PAGE_SIZE'),'state':z[0]}
 except (FileNotFoundError,ProcessLookupError):return None
status['allocator_profile']={'MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'};status['driver_sha256']=sha(__file__);save();fd=os.open('/tmp/dome-sculpt-sculpt-cpu-20261126.lock',os.O_RDWR|os.O_CREAT,0o600);child=None;known={}
try:
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(fd);status['cpu_lock']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino,'GPU_lease':False,'ldd_invoked':False,'isolated_CPU_only':True};save()
 pins=json.loads((B/'runtime-before-input-pins.json').read_text());drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift,drift
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'})
 reference=B.parent/'sculpt-workflow-recovery-release-20261126'
 providers=json.loads((reference/'native-v1/provider-before-pins.json').read_text())
 def dynamic(p):return sorted(re.findall(r'\((?:NEEDED|RPATH|RUNPATH)\).*?\[(.*?)\]',subprocess.check_output(['readelf','-d',str(p)],text=True)))
 assert dynamic(exe)==dynamic(reference/'dome-sculpt-sculpt-independent-workflow')
 assert all(sha(p)==h for p,h in providers.items())
 (D/'provider-before-pins.json').write_text(json.dumps(providers,indent=2)+'\n')
 status['provider_authority']='Previously executed fe94 native167 actual24 closure; exact DT_NEEDED/RPATH matches; no ldd/GL/device lease'
 status['executable_sha256']=sha(exe);status['providers']=len(providers);save()
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'})
 def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 with (D/'product.log').open('w') as out:
  child=subprocess.Popen(status['command'],cwd=B,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits)
  status['pid']=child.pid;first=proc(child.pid);assert first;status['process_identity']=first;start=time.monotonic();peak=0;samples=0;mapped=False;drm_seen=[];mapped_elfs=set();next_maps=0
  while child.poll() is None:
   own=[]
   for q in pathlib.Path('/proc').iterdir():
    if q.name.isdigit():
     a=proc(int(q.name))
     if a and a['pgrp']==child.pid:own.append(a);known[(a['pid'],a['start'])]=a
   peak=max(peak,sum(a['RSS'] for a in own));samples+=1
   if not mapped:
    try:
     actual=os.readlink('/proc/'+str(child.pid)+'/exe');maps=pathlib.Path('/proc/'+str(child.pid)+'/maps').read_text()
     if actual==str(exe) and maps:
      (D/'actual-maps.txt').write_text(maps);status['actual_executable_path']=actual;mapped=True
    except (FileNotFoundError,ProcessLookupError):pass
   elapsed=time.monotonic()-start
   for fp in (pathlib.Path('/proc')/str(child.pid)/'fd').glob('*'):
    try:
     st=os.stat(fp)
     if stat.S_ISCHR(st.st_mode) and os.major(st.st_rdev)==226:drm_seen.append(str(fp))
    except FileNotFoundError:pass
   if elapsed>=next_maps:
    try:
     maps=pathlib.Path('/proc/'+str(child.pid)+'/maps').read_text();(D/'actual-maps-latest.txt').write_text(maps)
     for line in maps.splitlines():
      q=line.split(None,5)
      if len(q)==6 and q[5].startswith('/'):
       p=pathlib.Path(q[5]);p=p.resolve()
       if p.is_file() and p!=exe:
        with p.open('rb') as f:magic=f.read(4)
        if magic==b'\x7fELF':mapped_elfs.add(str(p))
    except (FileNotFoundError,ProcessLookupError):pass
    next_maps=elapsed+1
   if elapsed>deadline or peak>rsslimit or drm_seen:
    status['limit_failure']='deadline' if elapsed>deadline else ('RSS' if peak>rsslimit else 'Unexpected DRM access in CPU-only case');w=proc(child.pid)
    if w and w['start']==first['start']:os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
    break
   time.sleep(.05)
  status.update({'product_exit':child.wait(),'seconds':time.monotonic()-start,'peak_owned_RSS_bytes':peak,'samples':samples,'mapped_witness':mapped})
 survivors=[x for (pid,start),x in known.items() if (a:=proc(pid)) and a['start']==start and a['state']!='Z'];status['owned_survivors']=survivors;assert not survivors
 status['DRM_FDs_observed']=drm_seen;status['mapped_external_ELFs']=sorted(mapped_elfs);assert not drm_seen and mapped_elfs.issubset(providers),sorted(mapped_elfs-set(providers))
 status['input_drift']=[p for p,h in pins.items() if sha(p)!=h];status['provider_drift']=[p for p,h in providers.items() if sha(p)!=h];assert not status['input_drift'] and not status['provider_drift']
 log=(D/'product.log').read_text();m=re.search(r'PASS independent production sculpt workflow checks=(\d+) objects=4',log);status['checks']=int(m.group(1)) if m else None
 assert status['product_exit']==0 and mapped and m and 'FAIL ' not in log
 status.update({'exit':0,'state':'passed'})
except BaseException as e:status.update({'exit':1,'state':'failed','error':repr(e)})
finally:
 status['terminal']=True;status['finished']=time.time()
 if 'cpu_lock' in status:status['cpu_lock']['released']=time.time()
 save();os.close(fd)
raise SystemExit(status['exit'])
