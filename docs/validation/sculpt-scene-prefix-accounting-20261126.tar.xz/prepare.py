from pathlib import Path
import hashlib
import json
import shlex
import subprocess

here=Path(__file__).resolve().parent
build=here.parent/'serialize-sculpt-objects-release-20261126'
parent=here.parent/'serialize-sculpt-objects-source-20261126'
base=here.parent/'broad-source-regression-source-20261126'
source=here.parent/'sculpt-scene-prefix-accounting-source-20261126'
archive=here.parent/'broad-source-regression-release-20261126/libdome-sculpt-core.a'
previous=json.loads((archive.parent/'build-status.json').read_text())
assert previous['terminal'] and previous['exit']==0
core=set()
others=[]
for dep in sorted((build/'CMakeFiles').glob('**/*.o.d')):
    if '/sculpt-scene-chunks.hpp' not in dep.read_text():
        continue
    if 'dome-sculpt-core.dir' in dep.parts:
        core.add('src/'+dep.name.removesuffix('.o.d'))
    else:
        others.append(str(dep))
assert core=={'src/document.cpp','src/material-visibility.cpp','src/sculpt-chunk-masks.cpp',
    'src/sculpt-placed-chunks.cpp','src/sculpt-placed-chunk.cpp','src/sculpt-scene-chunks.cpp','src/document-cut.cpp'}
commands={x['file']:x for x in json.loads((build/'compile_commands.json').read_text())}
compiles=[]
def compile_owner(name,template,root,path):
    obj=here/(name+'.o')
    argv=shlex.split(commands[str(parent/template)]['command'].replace(str(parent),str(root)))
    argv=[str(path) if v==str(root/template) else v for v in argv]
    argv[argv.index('-o')+1]=str(obj)
    argv[1:1]=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
    compiles.append({'name':name,'argv':argv})
    return str(obj)
replacement=[compile_owner(Path(rel).name,rel,source,source/rel) for rel in sorted(core)]
tests={
 'dome-sculpt-sculpt-chunk-pipeline-test':'tests/sculpt-chunk-pipeline.cpp',
 'dome-sculpt-sculpt-independent-workflow':'tests/sculpt-independent-workflow.cpp',
}
links=[]
def link_owner(target,template,rel,obj,core_archive):
    _,line,_=subprocess.check_output(['ninja','-t','commands',template],cwd=build,text=True).splitlines()[-1].split(' && ')
    argv=[]
    for value in shlex.split(line):
        if value.startswith('-Wl,--dependency-file='): value=f'-Wl,--dependency-file={here}/{target}.link.d'
        elif value==template: value=str(here/target)
        elif value=='libdome-sculpt-core.a': value=str(core_archive)
        elif value.endswith('/'+rel+'.o'): value=obj
        argv.append(value)
    assert obj in argv
    links.append({'name':target,'argv':argv})
for target,rel in tests.items():
    obj=compile_owner(Path(rel).name,rel,source,source/rel)
    link_owner(target,target,rel,obj,here/'libdome-sculpt-core.a')
probe='tests/sculpt-chunk-pipeline.cpp'
template='dome-sculpt-sculpt-chunk-pipeline-test'
for name,root,core_archive in [('before',base,archive),('after',source,here/'libdome-sculpt-core.a')]:
    target=f'capture-profile-{name}'
    obj=compile_owner(target,probe,root,here/'capture-profile.cpp')
    link_owner(target,template,probe,obj,core_archive)
diff=subprocess.check_output(['git','-C',str(source),'diff','--binary','HEAD'])
plan={'base':'5735ab7f','source_diff_sha256':hashlib.sha256(diff).hexdigest(),
      'baseline_archive':str(archive),'baseline_archive_sha256':previous['linked_archive']['sha256'],
      'cwd':str(build),'compiler':compiles,'links':links,'replacement_objects':replacement,
      'application_and_render_recompile_needed':others}
(here/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(len(compiles),len(links),plan['source_diff_sha256'])
