#include "sculpt-scene-chunks.hpp"
#include <chrono>
#include <iostream>
#include <stdexcept>

int main(int argc, char **argv) try {
  if (argc != 2) return 2;
  auto scene = dome::Scene::load(argv[1]);
  using dome::detail::SculptSceneChunks;
  auto current = SculptSceneChunks::capture(scene, {81,0,1,true,true}).chunks;
  if (current->objects().size() != 4)
    throw std::runtime_error("Expected the four actual independent sculpt objects");
  for (uint64_t i=1; i<=16; ++i) {
    scene.active().volume->fill_mask(float(i % 4) * .17f);
    const auto start = std::chrono::steady_clock::now();
    auto next = SculptSceneChunks::capture(scene, {81,i,1,true,true}, current).chunks;
    const auto elapsed = std::chrono::steady_clock::now() - start;
    if (next->objects().size() != current->objects().size())
      throw std::runtime_error("Mask edit changed the visible object count");
    for (const auto &object : next->objects()) {
      const auto *previous = current->find(object.object);
      if (!previous || previous->geometry != object.geometry || previous->placed != object.placed)
        throw std::runtime_error("Mask edit changed an immutable placed geometry owner");
    }
    std::cout << "MASK_CAPTURE " << i << ' '
              << std::chrono::duration<double,std::milli>(elapsed).count() << ' '
              << next->retained_bytes() << '\n';
    current = std::move(next);
  }
  return 0;
} catch(const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
