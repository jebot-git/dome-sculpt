from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import shlex
import shutil
import subprocess

here=Path(__file__).resolve().parent
build=here.parent/'serialize-sculpt-objects-release-20261126'
parent=here.parent/'serialize-sculpt-objects-source-20261126'
source=here.parent/'sculpt-scene-prefix-accounting-source-20261126'
base=json.loads((here/'build-status.json').read_text())
plan=json.loads((here/'build-plan.json').read_text())
core=here/'libdome-sculpt-core.a'
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
assert base['terminal'] and base['exit']==0 and sha(core)==base['linked_archive']['sha256']
diff=subprocess.check_output(['git','-C',str(source),'diff','--binary','5735ab7f'])
assert hashlib.sha256(diff).hexdigest()==plan['source_diff_sha256']
unchanged=build/'libdome-sculpt-render.a'
reference=sha(unchanged)
render=here/unchanged.name
log_root=here/'app-build'
log_root.mkdir()
commands={x['file']:x for x in json.loads((build/'compile_commands.json').read_text())}
owners={}
compiles=[]
for rel in ('src/render.cpp','src/app.cpp','tests/sculpt-sustained.cpp'):
    argv=shlex.split(commands[str(parent/rel)]['command'].replace(str(parent),str(source)))
    obj=log_root/(Path(rel).name+'.o')
    argv[argv.index('-o')+1]=str(obj)
    argv[1:1]=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
    compiles.append({'name':Path(rel).name,'argv':argv})
    owners[rel]=obj
links=[]
for target,rel in [('dome-sculpt','src/app.cpp'),('dome-sculpt-sculpt-sustained','tests/sculpt-sustained.cpp')]:
    _,line,_=subprocess.check_output(['ninja','-t','commands',target],cwd=build,text=True).splitlines()[-1].split(' && ')
    argv=[]
    for value in shlex.split(line):
        if value.startswith('-Wl,--dependency-file='): value=f'-Wl,--dependency-file={log_root}/{target}.link.d'
        elif value==target: value=str(here/target)
        elif value=='libdome-sculpt-core.a': value=str(core)
        elif value=='libdome-sculpt-render.a': value=str(render)
        elif value.endswith('/'+rel+'.o'): value=str(owners[rel])
        argv.append(value)
    assert str(owners[rel]) in argv and str(render) in argv and str(core) in argv
    links.append({'name':target,'argv':argv})
state={'terminal':False,'source_diff_sha256':plan['source_diff_sha256'],
       'compile':compiles,'links':links,'baseline_render_sha256':reference,
       'core_sha256':sha(core),'objects':{},'executables':{}}
def save():
    tmp=log_root/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(log_root/'status.json')
def do(step):
    with (log_root/(step['name']+'.log')).open('w') as log:
        result=subprocess.run(step['argv'],cwd=build,stdout=log,stderr=subprocess.STDOUT)
    return step['name'],result.returncode
save()
try:
    with ThreadPoolExecutor(max_workers=3) as p:
        results=dict(p.map(do,compiles))
    assert set(results.values())=={0}
    for rel,obj in owners.items():
        assert 'sculpt-scene-prefix-accounting-source-20261126/src/sculpt-scene-chunks.hpp' in Path(str(obj)+'.d').read_text()
        state['objects'][rel]=sha(obj)
    shutil.copyfile(unchanged,render)
    item=owners['src/render.cpp']
    subprocess.run(['ar','r',str(render),str(item)],check=True)
    def members(p):
        return subprocess.check_output(['ar','t',str(p)],text=True).splitlines()
    assert members(render)==members(unchanged) and len(members(render))==len(set(members(render)))
    for name in members(render):
        payload=subprocess.check_output(['ar','p',str(render),name])
        prior=item.read_bytes() if name==item.name else subprocess.check_output(['ar','p',str(unchanged),name])
        assert payload==prior,name
    assert sha(unchanged)==reference
    state['render_sha256']=sha(render)
    state['render_archive_members']=len(members(render))
    for step in links:
        name,code=do(step)
        assert code==0,name
        state['executables'][name]=sha(here/name)
    state['exit']=0
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
print(json.dumps(state['executables']),flush=True)
raise SystemExit(state['exit'])
