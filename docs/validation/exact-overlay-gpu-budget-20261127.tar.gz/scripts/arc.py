from pathlib import Path
import shlex
import subprocess
import sys

out=Path(__file__).resolve().parent
profile=sys.argv[1]
sdk=Path('/opt/fltk-vr/toolkit') if profile=='release' else out.parent/'sdk-20261126/toolkit-sanitize'
build=out/(profile+'-admit')
work=out/(profile+'-arc')
work.mkdir(exist_ok=True)
capsule=['flock','--timeout','360','/tmp/dome-sculpt-arc-device.lock','bwrap','--die-with-parent','--unshare-all',
         '--ro-bind','/','/','--bind',out,out,'--proc','/proc','--dev','/dev',
         '--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129',
         '--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
for key,value in {
    'PATH':'/usr/bin:/bin','HOME':'/tmp','DRI_PRIME':'pci-0000_03_00_0','EGL_PLATFORM':'surfaceless',
    'MESA_SHADER_CACHE_DISABLE':'1','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
    'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
}.items():
    capsule.extend(['--setenv',key,value])
tests={
    'recovery':('dome-sculpt-renderer-recovery-test',['--hardware']),
    'physical':('dome-sculpt-native-mtoon-physical-test',[work/'physical','--hardware']),
    'overlay':('dome-sculpt-paint-overlay-gpu-test',['--hardware']),
    'baked':('dome-sculpt-baked-emission-gpu-test',[]),
}
for label in sys.argv[2:]:
    name,args=tests[label]
    run=[*capsule,build/name,*args]
    with (work/(label+'.log')).open('w') as log:
        print(shlex.join(map(str,run)),file=log,flush=True)
        subprocess.run(run,stdout=log,stderr=subprocess.STDOUT,cwd=work,check=True,timeout=540)
    print(profile, label, 'Arc PASS',flush=True)
