from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess
import sys

recipe = Path(__file__).resolve().parents[1]/"texture-set-retained-production-20261127/admit.py"
driver = recipe.read_text().split("\nchanged=")[0]
driver = driver.replace('elif word==codec.name:',
    'elif word=="libdome-sculpt-render.a":word=str(renderer)\n        elif word==codec.name:')
driver = driver.replace('and f"{target}.dir/" in word',
    'and f"/{target}.dir/" in "/"+word')
exec(driver)
prior = artifacts/"native-mtoon-bake-20261127"/(profile+"-admit")
render_prior = artifacts/"retained-multi-field-rebake-20261127"/(profile+"-admit")/"libdome-sculpt-render.a"
renderer = out/render_prior.name
core = prior/core.name

def replace_archive():
    obj = compile_object("render.cpp","dome-sculpt-render")
    shutil.copyfile(render_prior,renderer)
    run(["ar","rs",renderer,obj],"archive")
    assert subprocess.check_output(["ar","t",renderer]) == subprocess.check_output(["ar","t",render_prior])
    assert subprocess.check_output(["ar","p",renderer,obj.name]) == obj.read_bytes()
    args = shlex.split((prior/"app-link.log").read_text().splitlines()[0])
    args = [str(renderer) if Path(word).name==renderer.name else word for word in args]
    args[args.index("-o")+1] = str(out/"dome-sculpt")
    run(args,"app-link")
    run([out/"dome-sculpt","--version"],"version")

def build_test(item):
    target, file, args = item
    name = target.replace("dome-sculpt-","").removesuffix("-test")
    obj = compile_object(file,target)
    binary = link(target,obj)
    return name, binary, args

mode = sys.argv[2]
if mode == "product":
    replace_archive()
else:
    fixtures = {
        "recovery":("dome-sculpt-renderer-recovery-test","renderer-recovery.cpp",[]),
        "native":("dome-sculpt-native-mtoon-physical-test","native-mtoon-physical.cpp",[out/"physical"]),
        "overlay":("dome-sculpt-paint-overlay-gpu-test","paint-overlay-gpu.cpp",[]),
        "baked":("dome-sculpt-baked-emission-gpu-test","baked-emission-gpu.cpp",[]),
        "painted":("dome-sculpt-mtoon-render-test","mtoon-render.cpp",["--baked-texture-sets",out/"mtoon-baked"]),
        "ledger":("dome-sculpt-render-store-ledger-test","render-store-ledger.cpp",[])
    }
    with ThreadPoolExecutor(max_workers=2 if profile=="release" else 1) as pool:
        tests = list(pool.map(build_test,[fixtures[label] for label in sys.argv[2:]]))
    def execute(test):
        label,binary,args = test
        run([binary,*args],label)
    with ThreadPoolExecutor(max_workers=2 if profile=="release" else 1) as pool:
        list(pool.map(execute,tests))
