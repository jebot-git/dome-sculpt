from pathlib import Path
import hashlib
import json
import shlex
import subprocess

out = Path(__file__).resolve().parent
artifacts = out.parent
root = out/'release-arc-xr'
root.mkdir(exist_ok=True)
previous = artifacts/'native-mtoon-bake-20261127/release-admit'
runtime = artifacts/'current-integrated-full-release-20261127/build/libdome-sculpt-test-runtime.so'
capsule = ['flock','--timeout','360','/tmp/dome-sculpt-arc-device.lock',
           'bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
           '--proc','/proc','--dev','/dev','--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129',
           '--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
for key,value in {
    'PATH':'/usr/bin:/bin','HOME':'/tmp','DRI_PRIME':'pci-0000_03_00_0',
    'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
    'EGL_PLATFORM':'surfaceless','MESA_SHADER_CACHE_DISABLE':'1',
}.items():
    capsule.extend(['--setenv',key,value])
args = [*capsule,'/usr/bin/python3.14',out/'arc-xr-replay.py',out/'release-admit/dome-sculpt',
        runtime,previous/'dome-sculpt-bake-recipes-test',root,'--texture-set','--mtoon']
with (root/'run.log').open('w') as log:
    print(shlex.join(map(str,args)),file=log,flush=True)
    subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=720)
report = json.loads((root/'report.json').read_text())
assert not report['physical_headset'] and len(report['checks'])==19
assert all(case['passed'] for case in report['checks'])
for name in ('source','reference','accept','cancel','focus'):
    path = root/(name+'.dsculpt')
    assert path.read_bytes()==(previous.parent/'release-openxr'/path.name).read_bytes()
print('Arc OpenXR typed Bake',len(report['checks']),'checks and exact software project parity')
