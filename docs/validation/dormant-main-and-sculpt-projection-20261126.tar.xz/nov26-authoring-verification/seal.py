from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

root=Path(__file__).resolve().parents[1]
docs=root.parent/'docs/validation'
main=root/'dormant-main-release-20261126'
probe=root/'projection-occluding-sculpt-baseline-20261126'
release=root/'projection-occluding-sculpt-release-20261126'
strict=root/'projection-occluding-sculpt-strict-20261126'
source=root/'projection-occluding-sculpt-source-20261126'
def read(p):return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pick(folder,names):return [folder/name for name in names.split()]

m=read(main/'status.json')
assert m['source']=='6a63f6fef24ef7c3e144fe38c652c414ffb1652a' and m['terminal'] and m['exit']==0
assert all(sha(main/k)==v for k,v in m['executables'].items())
assert '[266/266]' in (main/'build.log').read_text()
assert '100% tests passed, 0 tests failed out of 3' in (main/'native.log').read_text()
assert 'FLTK_DIR:UNINITIALIZED=/opt/fltk-vr/toolkit/share/fltk' in (main/'CMakeCache.txt').read_text()
assert 'DOME_BITMAP_RUNTIME_freetype2_LIBDIR:INTERNAL=/opt/fltk-vr/bdf-runtime/lib' in (main/'CMakeCache.txt').read_text()
assert (probe/'exit').read_text().strip()=='1' and 'FAIL Projection respects visible sculpt geometry' in (probe/'product.log').read_text()
assert (release/'exit').read_text().strip()=='0' and '124 native projection workflow checks passed' in (release/'product.log').read_text()
s=read(strict/'native/status.json')
r=read(release/'build-status.json')
assert s['terminal'] and s['exit']==0 and r['terminal'] and r['exit']==0
assert s['cases']['dome-sculpt-projection-native-test']['check_passed']
rev=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
patch=subprocess.check_output(['git','-C',str(source),'diff','--binary','c90c9fed','HEAD'])
assert rev.startswith('f5136b36') and hashlib.sha256(patch).hexdigest()==read(release/'build-plan.json')['source_diff_sha256']==read(strict/'build-plan.json')['source_diff_sha256']
xr=read(release/'xr/report.json')
assert len(xr['checks'])==10 and all(c['passed'] for c in xr['checks']) and not xr['physical_headset']
paths=pick(main,'run.py status.json configure.log build.log native.log version.log')
paths+=pick(probe,'build.py commands.json product.log exit')
paths+=pick(release,'prepare.py build-plan.json build-status.json product.log exit xr/report.json xr/accept.json xr/focus.json xr/accept.log xr/focus.log')
paths+=pick(strict,'prepare.py build-plan.json build-status.json native/status.json native/dome-sculpt-projection-native-test.log')
base=root/'nov26-authoring-verification'
for unit in ('ds-dormant-main-release-20261126','ds-projection-occluding-sculpt-xr-20261126'):
    p=base/(unit+'.journal')
    p.write_bytes(subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager']))
    assert b'Started' in p.read_bytes()
    paths.append(p)
paths.append(Path(__file__))
dest=docs/'dormant-main-and-sculpt-projection-20261126.tar.xz'
manifest={}
with tarfile.open(dest,'w:xz',preset=6) as ar:
    for p in paths:
        name=str(p.relative_to(root));data=p.read_bytes()
        assert name not in manifest
        manifest[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
        item=tarfile.TarInfo(name);item.size=len(data)
        ar.addfile(item,io.BytesIO(data))
with tarfile.open(dest,'r:xz') as ar:
    assert set(ar.getnames())==set(manifest)
    for item in ar:
        assert hashlib.file_digest(ar.extractfile(item),'sha256').hexdigest()==manifest[item.name]['sha256']
status={'scope':'Exact main Release build and three native tests for the dormant-paint fix. Separate component tests for sculpt occlusion in the projection worker in Release and ASan/UBSan, plus software OpenXR projection accept/focus regressions.',
        'main':m,'main_build_invocation':'c8601f5c6de04eaeb6448c8700e22825',
        'projection_source':rev,'projection_release':r,'projection_strict':s,'projection_xr':xr,
        'projection_app_sha256':sha(release/'dome-sculpt'),
        'projection_xr_invocation':'dabda634bdb84ac7836fc336f00476c5',
        'authorities':manifest,'archive':{'file':dest.name,'sha256':sha(dest),'bytes':dest.stat().st_size}}
dest.with_name(dest.name.replace('.tar.xz','.json')).write_text(json.dumps(status,indent=2)+'\n')
print(len(manifest),status['archive'])
