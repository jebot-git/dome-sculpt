from pathlib import Path
import hashlib
import json
import shlex
import subprocess

here = Path(__file__).resolve().parent
artifacts = here.parent
config = artifacts / 'serialize-sculpt-objects-strict-20261126'
original = artifacts / 'serialize-sculpt-objects-source-20261126'
source = artifacts / 'projection-occluding-sculpt-source-20261126'
base = artifacts / 'cut-current-paint-strict-20261126'
archive = base / 'libdome-sculpt-core.a'
previous = json.loads((base / 'build-status.json').read_text())
assert previous['terminal'] and previous['exit']==0
commands = {x['file']: x['command'] for x in json.loads((config/'compile_commands.json').read_text())}
fixtures = {'dome-sculpt-projection-native-test':'tests/projection-native.cpp'}
owners = {}
compile = []
for rel in ('src/document-native.cpp', *fixtures.values()):
    obj = here / (Path(rel).name + '.o')
    argv = shlex.split(commands[str(original/rel)].replace(str(original),str(source)))
    argv[argv.index('-o')+1] = str(obj)
    argv[1:1] = ['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
    compile.append({'name':Path(rel).name, 'argv':argv})
    owners[rel] = obj
def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
links = []
for target,rel in fixtures.items():
    _, cmd, _ = subprocess.check_output(['ninja','-t','commands',target],cwd=config,text=True).splitlines()[-1].split(' && ')
    argv = []
    for value in shlex.split(cmd):
        if value.startswith('-Wl,--dependency-file='): value=f'-Wl,--dependency-file={here}/{target}.link.d'
        elif value==target: value=str(here/target)
        elif value=='libdome-sculpt-core.a': value=str(here/value)
        elif value.endswith('/'+rel+'.o'): value=str(owners[rel])
        argv.append(value)
    assert str(owners[rel]) in argv
    links.append({'name':target, 'argv':argv})
diff = subprocess.check_output(['git','-C',str(source),'diff','--binary','c90c9fed'])
assert sha(archive)==previous['linked_archive']['sha256']
plan = {'base':'c90c9fed', 'source_diff_sha256':hashlib.sha256(diff).hexdigest(),
        'compiler':compile, 'links':links, 'replacement_objects':[str(owners['src/document-native.cpp'])],
        'baseline_archive':str(archive),'baseline_archive_sha256':sha(archive),'cwd':str(config)}
(here/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(len(compile),len(links),plan['source_diff_sha256'])
