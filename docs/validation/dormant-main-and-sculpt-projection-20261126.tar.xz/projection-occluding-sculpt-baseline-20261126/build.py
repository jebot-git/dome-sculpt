from pathlib import Path
import hashlib,json,shlex,subprocess

here=Path(__file__).resolve().parent
a=here.parent
config=a/'production-full-regression-release-20261126'
old=a/'production-full-regression-source-20261126'
src=a/'projection-occluding-sculpt-source-20261126'
prior=a/'cut-current-paint-release-20261126'
core=prior/'libdome-sculpt-core.a'
assert hashlib.sha256(core.read_bytes()).hexdigest()==json.loads((prior/'build-status.json').read_text())['linked_archive']['sha256']
rel='tests/projection-native.cpp';exe='dome-sculpt-projection-native-test'
compile=next(shlex.split(c['command'].replace(str(old),str(src))) for c in json.loads((config/'compile_commands.json').read_text()) if c['file']==str(old/rel))
obj=here/(Path(rel).name+'.o')
compile[compile.index('-o')+1]=str(obj)
compile[1:1]=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
_,link,_=subprocess.check_output(['ninja','-t','commands',exe],cwd=config,text=True).splitlines()[-1].split(' && ')
argv=[]
for v in shlex.split(link):
    if v.startswith('-Wl,--dependency-file='):v=f'-Wl,--dependency-file={here}/{exe}.link.d'
    elif v==exe:v=str(here/exe)
    elif v.endswith('/'+rel+'.o'):v=str(obj)
    elif v==core.name:v=str(core)
    argv.append(v)
(here/'commands.json').write_text(json.dumps([compile,argv],indent=2)+'\n')
for command in (compile,argv):
    subprocess.run(command,cwd=config,check=True)
