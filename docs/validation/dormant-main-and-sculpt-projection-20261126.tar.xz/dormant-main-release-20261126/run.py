from pathlib import Path
import hashlib
import json
import os
import subprocess

out=Path(__file__).resolve().parent
source=out.parent/'dormant-main-source-20261126'
env=os.environ.copy()
env['PKG_CONFIG_PATH']='/opt/fltk-vr/bdf-runtime/lib/pkgconfig'
state={'terminal':False,'steps':[]}
def save():
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
def run(name,argv):
    with (out/(name+'.log')).open('w') as f:
        r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT)
    state['steps'].append({'name':name,'exit':r.returncode});save()
    r.check_returncode()
state['source']=git('rev-parse','HEAD');save()
assert state['source'].startswith('6a63f6fe') and not git('status','--porcelain')
try:
    tool=['/usr/bin/cmake','-S',str(source),'-B',str(out),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
          '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_BUILD_UI=ON','-DDOME_BUILD_XR=ON',
          '-DDOME_COMPUTE_BACKEND=CPU','-DFLTK_DIR=/opt/fltk-vr/toolkit/share/fltk','-DBUILD_TESTING=ON']
    run('configure',tool)
    tools=['dome-sculpt','dome-sculpt-document-transactions-test','dome-sculpt-source-uv-adopt-test','dome-sculpt-gpu-color-blur-native-test']
    run('build',['/usr/bin/cmake','--build',str(out),'--parallel','2','--target',*tools])
    state['executables']={exe:hashlib.sha256((out/exe).read_bytes()).hexdigest() for exe in tools}
    args=['/usr/bin/bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',str(out),str(out),
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
          '--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
          '--setenv','LIBGL_ALWAYS_SOFTWARE','1','--setenv','LP_NUM_THREADS','2']
    run('version',[*args,str(out/'dome-sculpt'),'--version'])
    run('native',[*args,'/usr/bin/ctest','--test-dir',str(out),'--output-on-failure',
                  '-R','^(transaction-sculpt-undo|source-uv-adopt|gpu-color-blur-native-software)$'])
    assert not git('status','--porcelain')
    state['exit']=0
except Exception as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True;save()
raise SystemExit(state['exit'])
