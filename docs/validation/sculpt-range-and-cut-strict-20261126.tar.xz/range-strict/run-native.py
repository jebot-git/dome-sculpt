from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

here=Path(__file__).resolve().parent
sys.path.insert(0,str(here))
from owned_monitor import run

plan=json.loads((here/'build-plan.json').read_text())
build=json.loads((here/'build-status.json').read_text())
assert build['terminal'] and build['exit']==0 and build['linked_archive']['members']==197
assert not Path('/dev/dri').exists()
assert not any(k in os.environ for k in ('MALLOC_ARENA_MAX','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES'))
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
assert all(sha(Path(x['path']))==x['sha256'] for x in plan['authenticated_reused_objects'].values())
out=here/'native'
out.mkdir()
profile=plan['profile']
state={'terminal':False,'source':plan['source'],'profile':profile,'cases':{}}
def save():
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
tests=[
    ('sculpt-surface-chunks-test',[],r'^26 sculpt chunk checks passed$'),
    ('sculpt-chunk-pipeline-test',[str(out/'pipeline')],r'^PASS total 94$'),
    ('sculpt-independent-workflow',[str(out/'sculpt')],r'^PASS independent production sculpt workflow checks=167'),
]
if profile=='strict':
    tests[:0]=[
       ('scene-file-test',[str(out/'scene-file')],r'^Native scene file: 23 checks$'),
       ('document-recovery-test',[],21),
       ('atomic-write-allocation-test',[str(out/'atomic-write-allocation')],r'^PASS 22 atomic allocation checks$'),
       ('corner-color-uv23-domain-test',[],r'^PASS current-corner UV1 replacement refuses'),
       ('baked-emission-workflow-test',['--source-worker-controls',str(out/'uv1')],r'^Baked emission UV1 worker 180375 checks PASS$'),
    ]
save()
try:
    if profile=='release':
        app=here/'dome-sculpt'
        result=subprocess.run([str(app),'--version'],capture_output=True,text=True,check=True)
        state['app']={'sha256':sha(app),'version':result.stdout.strip()}
        state['sustained_sha256']=sha(here/'dome-sculpt-sculpt-sustained')
        save()
    for name,args,pattern in tests:
        elf=here/f'dome-sculpt-{name}'
        log=out/f'{name}.log'
        if profile=='strict':
            needed=subprocess.check_output(['readelf','-d',str(elf)],text=True)
            assert 'libasan.so.' in needed and 'libubsan.so.' in needed
        row=run([str(elf),*args],cwd=out,env=os.environ.copy(),log=log,timeout=900,max_rss=4*1024**3)
        text=log.read_text()
        valid=(sum(line.startswith('PASS ') for line in text.splitlines())==pattern
               if isinstance(pattern,int) else bool(re.search(pattern,text,re.M)))
        row.update(sha256=sha(elf),check_passed=valid)
        state['cases'][name]=row
        save()
    state['exit']=int(any(x['exit']!=0 or 'error' in x or not x['check_passed'] for x in state['cases'].values()))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
