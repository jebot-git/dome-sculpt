from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
from owned_monitor import run

here = Path(__file__).resolve().parent
build = json.loads((here/'build-status.json').read_text())
assert build['terminal'] and build['exit']==0 and len(build['linked_archive']['replacements'])==1
assert not Path('/dev/dri').exists()
out = here/'native'
out.mkdir()
state={'terminal':False,'cases':{}}
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def save():
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
fixtures=[
    ('dome-sculpt-cut-boundaries-test',[],r'^PASS Retried cut publishes shell and cap as exactly one global Undo transaction'),
]
try:
    for target,args,pattern in fixtures:
        log=out/(target+'.log')
        exe=here/target
        needed=subprocess.check_output(['readelf','-d',str(exe)],text=True)
        assert 'libasan.so.' in needed and 'libubsan.so.' in needed
        row=run([str(exe),*args],cwd=out,env=os.environ.copy(),log=log,timeout=900,max_rss=4*1024**3)
        count=re.search(pattern,log.read_text(),re.M)
        if target=='dome-sculpt-cut-boundaries-test':
            assert len(re.findall(pattern,log.read_text(),re.M))==2
            assert 'Controller sample drains' in log.read_text()
        row.update(sha256=sha(exe),check_passed=bool(count),passed_cases=[l for l in log.read_text().splitlines() if l.startswith('PASS ')])
        state['cases'][target]=row
        save()
    state['exit']=int(any(v['exit'] or not v['check_passed'] or 'error' in v for v in state['cases'].values()))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
