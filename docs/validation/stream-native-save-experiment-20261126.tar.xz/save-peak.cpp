#include "dome/scene.hpp"

#include <cerrno>
#include <filesystem>
#include <iostream>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  const auto scene = dome::Scene::load(argv[1]);
  size_t tasks = 0;
  for ([[maybe_unused]] const auto &entry :
       std::filesystem::directory_iterator("/proc/self/task")) ++tasks;
  if (tasks != 1) throw std::runtime_error("Save probe requires a single-thread scene loader");
  const auto child = fork();
  if (child < 0) throw std::runtime_error("Cannot start save probe child");
  if (child == 0) {
    scene.save(argv[2]);
    rusage usage{};
    if (getrusage(RUSAGE_SELF, &usage)) _exit(3);
    std::cout << "SAVE_CHILD_PEAK_KIB " << usage.ru_maxrss << std::endl;
    _exit(0);
  }
  int result = 0;
  pid_t waited;
  do {
    waited = waitpid(child, &result, 0);
  } while (waited < 0 && errno == EINTR);
  return waited == child && WIFEXITED(result) ? WEXITSTATUS(result) : 4;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
