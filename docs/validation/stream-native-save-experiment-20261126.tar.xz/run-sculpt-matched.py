from pathlib import Path
import hashlib
import json
import os
from owned_monitor import run

HERE = Path(__file__).resolve().parent
OUT = HERE / 'native-matched'
OUT.mkdir()
REFERENCE = HERE.parent / 'production-combined-release-20261126/native-sculpt-matched/sculpt/accepted.dsculpt'
status = {'terminal': False, 'cases': []}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save():
    (OUT / 'status.json').write_text(json.dumps(status, indent=2) + '\n')


save()
try:
    steps = [('sculpt-independent-workflow', [str(OUT / 'sculpt')])]
    for name, args in steps:
        binary = HERE / ('dome-sculpt-' + name)
        log = OUT / (name + '.log')
        initial = digest(binary)
        row = run([str(binary), *args], cwd=OUT, env=os.environ.copy(), log=log,
                  timeout=900, max_rss=4 * 1024**3)
        log_text = log.read_text()
        if name == 'sculpt-independent-workflow':
            accepted = OUT / 'sculpt/accepted.dsculpt'
            row['reference_sha256'] = digest(REFERENCE)
            row['accepted_sha256'] = digest(accepted) if accepted.is_file() else None
            row['byte_identical'] = row['reference_sha256'] == row['accepted_sha256']
            row['verified'] = (row['exit'] == 0 and row['byte_identical'] and
                               'checks=167 objects=4 voxel=.0125' in log_text)
        else:
            row['verified'] = row['exit'] == 0 and 'PASS ' in log_text
            if name == 'atomic-write-allocation-test':
                row['verified'] &= 'Streaming failure after a written chunk preserves exact old output' in log_text
        row.update(name=name, executable_sha256=initial)
        assert digest(binary) == initial
        status['cases'].append(row)
        save()
    status['exit'] = int(not all(row['verified'] for row in status['cases']))
except Exception as error:
    status.update(exit=1, error=repr(error))
finally:
    status['terminal'] = True
    save()
raise SystemExit(status['exit'])
