#include "dome/document.hpp"
#include "dome/emission-native.hpp"
#include "dome/scene.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <nlohmann/json.hpp>

int main(int argc, char **argv) try {
  using namespace dome;
  if (argc != 3) throw std::invalid_argument("Usage: standard-varied PROJECT OUTPUT_DIR");
  const auto folder = std::filesystem::path(argv[2]);
  std::filesystem::create_directories(folder);
  const auto glb = folder / "standard-hdr.glb";
  Document doc;
  doc.open(argv[1]);
  if (!doc.wait_asset() || !doc.wait_mesh() || !doc.frame().state->error.empty())
    throw std::runtime_error(doc.frame().state->error);
  std::cout << "Opened converted varying 2048 HDR key" << std::endl;
  doc.export_asset(glb, AssetExportFormat::Glb).get();
  std::cout << "Standard GLB wrote " << std::filesystem::file_size(glb) << " bytes" << std::endl;
  std::ifstream stream(glb, std::ios::binary);
  const std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(stream)), {});
  const auto restored = extract_native_emission(bytes);
  if (!restored || restored->encode() != Scene::load(argv[1]).encode())
    throw std::runtime_error("Standard GLB did not restore the exact native project");
  std::cout << "Standard GLB restores exact native Scene" << std::endl;
  try {
    const auto editable = folder / "editable-hdr.glb";
    doc.export_asset(editable, AssetExportFormat::EditableGlb512).get();
    std::cout << "Editable GLB wrote " << std::filesystem::file_size(editable) << " bytes" << std::endl;
  } catch(const std::exception &e) {
    std::cerr << "Editable GLB refusal: " << e.what() << std::endl;
  }
  return 0;
} catch(const std::exception &e) {
  std::cerr << "Standard GLB refusal: " << e.what() << std::endl;
  return 1;
}
