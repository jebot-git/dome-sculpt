const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const validator = require(path.resolve(__dirname, '../hdr-khronos-validation-20261126/module/package'));

(async () => {
  for (const filename of process.argv.slice(2)) {
    const bytes = fs.readFileSync(filename);
    const report = await validator.validateBytes(new Uint8Array(bytes), {uri: path.basename(filename)});
    fs.writeFileSync(filename + '.khronos.json', JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify({filename, validator: validator.version(),
      bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
      errors: report.issues.numErrors, warnings: report.issues.numWarnings}));
    if (report.issues.numErrors) process.exitCode = 1;
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
