from pathlib import Path
import json
import os
import shlex
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
profile=sys.argv[1]
out=root/profile
linked=root.parent/"native-hdr-compact-20261126"/profile/"build"
baseline=root.parent/"native-shared-bake-20261127"/profile
work=out/"full-resolution-fixture"
work.mkdir(exist_ok=True)
environment=os.environ.copy()
sdk=root.parent/"sdk-20261126/toolkit-sanitize" if profile=="asan" else Path("/opt/fltk-vr/toolkit")
environment.update(LD_LIBRARY_PATH=f"{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
    ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
def run(args, name, cwd=out):
    with (work/name).open("w") as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,check=True,env=environment,timeout=480)
target="dome-sculpt-source-writable-normal-bake-test"
data=json.loads((baseline/"build/compile_commands.json").read_text())
entry=next(v for v in data if f"/{target}.dir/" in v["output"])
previous=root.parent/"native-shared-bake-20261127/source"
source=root/"source"
compile=shlex.split(entry["command"].replace(str(previous),str(source)))
object_file=work/"source-writable-normal-bake.cpp.o"
compile[compile.index("-o")+1]=str(object_file)
run(compile,"compile.log")
link=shlex.split(subprocess.check_output(["ninja","-t","commands",target],cwd=linked,text=True).splitlines()[-1])[2:-2]
args=[]
for word in link:
    if word.startswith("-Wl,--dependency-file"):
        continue
    if word.endswith("source-writable-normal-bake.cpp.o"):
        word=str(object_file)
    elif word in ("libdome-sculpt-core.a","libdome-sculpt-emission-codec.a"):
        word=str(out/word)
    elif not word.startswith("/") and word.endswith((".a",".o")):
        word=str(linked/word)
    args.append(word)
binary=work/target
args[args.index("-o")+1]=str(binary)
run(args,"link.log")
keyed="keyed-2048-varied-hdr.dsculpt"
shutil.copyfile(baseline/"build/native-writable-first-key-2048"/keyed,work/keyed)
run([binary,"--dense-hdr-portable",work],"run.log")
