from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = root.parents[1]
destination = repo / "docs/validation"
name = "native-hdr-standard-streaming-20261127"
product = subprocess.check_output(["git", "-C", repo, "rev-parse", sys.argv[1]], text=True).strip()
assert subprocess.check_output(["git", "-C", repo, "show", "--format=", "--binary", product]) == (
    root / "source.patch"
).read_bytes()
files = {}

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def keep(filename):
    path = root / filename
    files[filename] = path
    return sha(path)

def read(filename):
    return json.loads((root / filename).read_text())

report = {"product":product,"source_patch_sha256":keep("source.patch"),"profiles":{},"frontends":{},
          "scope":"Native 2048-square spatially varying HDR Bake with an edited key and portable normal frame. Bounded FLOAT scanline Standard GLB export and native reopen, with the legacy EXR and container budgets retained."}
for filename in ("product.patch","run.py","run-fixture.py","standard-varied.cpp","validate.cjs",
                 "record.py","public-focus.py","wayland.py","xr-public.py","xr-focus.py",
                 "xr-runtime-build.py","xr-portable-runtime.cpp"):
    keep(filename)
expected = None
for profile in ("release","asan"):
    state = read(f"{profile}/status.json")
    assert state["terminal"] and state["exit"] == 0
    harness = (root/f"{profile}/standard-varied.log").read_text()
    assert "Standard GLB wrote 51266256 bytes" in harness and "Standard GLB restores exact native Scene" in harness
    assert "Editable GLB refusal: Native nonemission compilation exceeds cumulative sample budget" in harness
    fixture = (root/f"{profile}/full-resolution-fixture/run.log").read_text()
    assert "PASS 9 full-resolution portable HDR checks" in fixture
    assert sha(root/f"{profile}/full-resolution-fixture/portable-varied-hdr-native.dsculpt") == sha(
        root/f"{profile}/full-resolution-fixture/portable-varied-hdr-restored.dsculpt")
    package = root/f"{profile}/standard-varied-outputs/standard-hdr.glb"
    digest = sha(package)
    assert package.stat().st_size == 51266256
    assert digest == sha(root/f"{profile}/full-resolution-fixture/portable-varied-hdr-2048.glb")
    assert not expected or digest == expected
    expected = digest
    tests = {
        "dome-sculpt-baked-emission-exr-test.log": "648 checks PASS",
        "dome-sculpt-baked-emission-workflow-test.log": "16417 checks PASS",
        "dome-sculpt-emission-export-test.log": "Native HDR export: 32 checks",
        "dome-sculpt-emission-exr-owned-test.log": "PASS owning EXR 972 checks",
        "dome-sculpt-emission-package-budget-test.log": "Native HDR aggregate field budget: 4 checks",
    }
    for file, result in tests.items():
        assert result in (root/profile/file).read_text()
    logs = {}
    for file in (
        "status.json","standard-varied.log","standard-varied-compile.log",
        "dome-sculpt-core-archive.log","dome-sculpt-emission-codec-archive.log","dome-sculpt-link.log",
        "full-resolution-fixture/compile.log","full-resolution-fixture/link.log",
        "full-resolution-fixture/run.log",*tests,
    ):
        logs[file] = keep(f"{profile}/{file}")
    report["profiles"][profile] = {"app_sha256":state["app_sha256"],"invocation":state["invocation"],
        "focused_fixtures":6,"glb_sha256":digest,"logs_sha256":logs}
for mode in ("wayland","software","arc"):
    where = f"{mode}-focus-hdr-standard"
    state = read(f"{where}/status.json")
    assert state["terminal"] and state["exit"] == 0
    assert state["checks"] == (7 if mode=="wayland" else 10)
    assert state["native_sha256"] == expected
    for file in ("status.json","run.log","workflow/report.json"):
        keep(f"{where}/{file}")
    if mode=="wayland":
        for file in ("runtime-maps.txt","client.log","compositor.log"):
            keep(f"{where}/workflow/{file}")
    else:
        for step in ("accept","focus"):
            for file in ("graphics.json","application.log"):
                keep(f"{where}/workflow/{step}/{file}")
    report["frontends"][mode]=state
file = "release/full-resolution-fixture/portable-varied-hdr-2048.glb.khronos.json"
validation = read(file)
assert validation["issues"]["numErrors"] == 0 and validation["issues"]["numWarnings"] == 1
assert [m["code"] for m in validation["issues"]["messages"] if m["severity"]==1] == ["NODE_SKINNED_MESH_NON_ROOT"]
report["khronos"] = {"errors":0,"warnings":["NODE_SKINNED_MESH_NON_ROOT"],"report_sha256":keep(file)}
for filename in ("release/standard-varied-early.log","release/editable-varied.log",
                 "wayland-focus-hdr-standard-observer-v1/status.json",
                 "wayland-focus-hdr-standard-observer-v1/run.log"):
    keep(filename)
report["open"] = "Editable GLB 512 still reaches its cumulative nonemission sample budget. Full regression and physical headset verification remain open."
archive = destination/(name+".tar.gz")
with archive.open("wb") as raw,gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode="w") as tar:
    for filename,path in sorted(files.items()):
        payload=path.read_bytes()
        item=tarfile.TarInfo(filename)
        item.size=len(payload)
        tar.addfile(item,io.BytesIO(payload))
report["archive"]={"file":archive.name,"sha256":sha(archive),"members":len(files)}
(destination/(name+".json")).write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
print(product,report["archive"])
