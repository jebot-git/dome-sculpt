import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

root = Path(__file__).resolve().parent
src = root / "source"
profile = sys.argv[1]
baseline = root.parent / "native-shared-bake-20261127" / profile
old = root.parent / "native-hdr-compact-20261126" / profile / "build"
out = root / profile
out.mkdir(exist_ok=True)
state = {"profile": profile, "invocation": os.environ.get("INVOCATION_ID")}
previous_state = json.loads((out / "status.json").read_text()) if (out / "status.json").exists() else {}
resume = previous_state.get("terminal") and previous_state.get("exit")==1

def status(phase, **entries):
    state.update(phase=phase, **entries)
    (out / "status.json").write_text(json.dumps(state, indent=2) + "\n")

def run(args, log, cwd=out):
    with (out / log).open("w") as stream:
        print(shlex.join(map(str,args)), file=stream, flush=True)
        subprocess.run(args, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT,
                       check=True, timeout=960, env=environment)

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

environment = os.environ.copy()
toolkit = root.parent / "sdk-20261126/toolkit-sanitize" if profile == "asan" else Path("/opt/fltk-vr/toolkit")
environment.update(LD_LIBRARY_PATH=f"{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
                   ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",
                   UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1", EGL_PLATFORM="surfaceless",
                   LIBGL_ALWAYS_SOFTWARE="1", LP_NUM_THREADS="2")
try:
    compile_db = json.loads((baseline / "build/compile_commands.json").read_text())
    previous = root.parent / "native-shared-bake-20261127/source"
    core = {"emission-export.cpp", "emission-package.cpp", "export.cpp", "vrm.cpp",
            "vrm1-export.cpp", "document.cpp", "native-authoring.cpp", "paint.cpp"}
    codec = {"emission-exr.cpp", "emission-exr-owned.cpp"}
    tests = {"emission-exr-owned.cpp": "dome-sculpt-emission-exr-owned-test",
             "emission-package-budget.cpp": "dome-sculpt-emission-package-budget-test",
             "emission-export.cpp": "dome-sculpt-emission-export-test",
             "baked-emission-workflow.cpp": "dome-sculpt-baked-emission-workflow-test",
             "baked-emission-exr.cpp": "dome-sculpt-baked-emission-exr-test"}
    expected = {(file, "dome-sculpt-core") for file in core}
    expected.update((file, "dome-sculpt-emission-codec") for file in codec)
    expected.update(tests.items())
    compile_db = {(Path(row["file"]).name, row["output"].split("CMakeFiles/",1)[1].split("/",1)[0].removesuffix(".dir")): row
                  for row in compile_db}
    def compile_one(key):
        filename, owner = key
        command = shlex.split(compile_db[key]["command"].replace(str(previous), str(src)))
        dest = out / (owner + "-" + filename + ".o")
        command[command.index("-o")+1] = str(dest)
        old_hashes = previous_state.get("inputs", {})
        new_hashes = state["inputs"]
        same_inputs = old_hashes == new_hashes
        revision = {name for name in set(old_hashes)|set(new_hashes)
                    if old_hashes.get(name)!=new_hashes.get(name)}
        accessor_revision = revision <= {"src/emission-export.cpp","src/paint.cpp","src/emission-paint-access.hpp"}
        can_reuse = same_inputs or (accessor_revision and filename not in {"paint.cpp","emission-export.cpp"})
        if not (resume and can_reuse and dest.is_file()):
            run(command, dest.stem + ".log")
        return key, dest
    status("compile current owners", inputs={p:sha(src / p) for p in subprocess.check_output(
        ["git","diff","--name-only"],cwd=src,text=True).splitlines()})
    with ThreadPoolExecutor(max_workers=2) as pool:
        objects = dict(pool.map(compile_one, sorted(expected)))
    libraries = {}
    for owner, files, archive in (("dome-sculpt-core",core,baseline/"libdome-sculpt-core.a"),
                                   ("dome-sculpt-emission-codec",codec,old/"libdome-sculpt-emission-codec.a")):
        path = out / archive.name
        shutil.copyfile(archive, path)
        members = out / owner
        members.mkdir(exist_ok=True)
        for file in files:
            shutil.copyfile(objects[file,owner], members/(file+".o"))
        run(["ar","rs",path,*(members/(file+".o") for file in sorted(files))],owner+"-archive.log")
        for file in files:
            assert subprocess.check_output(["ar","p",path,file+".o"]) == objects[file,owner].read_bytes()
        libraries[archive.name] = path
    def relink(target, replacement=None):
        line = subprocess.check_output(["ninja","-t","commands",target],cwd=old,text=True).splitlines()[-1]
        raw = shlex.split(line)[2:-2]
        args = []
        for word in raw:
            if word.startswith("-Wl,--dependency-file"):
                continue
            if word in libraries:
                word = str(libraries[word])
            elif replacement and target+".dir/" in word and word.endswith(".o"):
                word = str(replacement)
            elif not word.startswith("/") and word.endswith((".a",".o")):
                word = str(old / word)
            args.append(word)
        args[args.index("-o")+1] = str(out/target)
        run(args,target+"-link.log")
    status("relink selected application and validation programs")
    probe = out / "standard-varied.o"
    probe_cmd = shlex.split(compile_db[("emission-export.cpp","dome-sculpt-core")]["command"].replace(str(previous),str(src)))
    probe_cmd[probe_cmd.index("-o")+1] = str(probe)
    probe_cmd[-1] = str(root / "standard-varied.cpp")
    run(probe_cmd,"standard-varied-compile.log")
    targets = ("dome-sculpt", "dome-sculpt-emission-exr-owned-test", "dome-sculpt-emission-export-test",
               "dome-sculpt-emission-package-budget-test", "dome-sculpt-baked-emission-workflow-test",
               "dome-sculpt-baked-emission-exr-test")
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda target: relink(target,next((objects[file,owner] for file,owner in tests.items()
                                                       if target==owner),None)),targets))
    relink("dome-sculpt-emission-export-test", probe)
    (out / "dome-sculpt-emission-export-test").rename(out / "standard-varied")
    relink("dome-sculpt-emission-export-test", objects["emission-export.cpp","dome-sculpt-emission-export-test"])
    status("run selected CTests and full-resolution Document worker probe", app_sha256=sha(out/"dome-sculpt"))
    sample = root.parent / "native-shared-bake-20261127/release/edited/converted-varied-key.dsculpt"
    run([out/"standard-varied",sample,out/"standard-varied-outputs"],"standard-varied.log")
    for target in targets[1:]:
        args=[out/target]
        if target not in ("dome-sculpt-emission-exr-owned-test","dome-sculpt-baked-emission-exr-test"):
            args.append(out/(target+"-outputs"))
        run(args,target+".log")
    status("complete",terminal=True,exit=0)
except BaseException as error:
    status("failed",terminal=True,exit=1,error=repr(error))
    raise
