"""Package existing eight-case evidence only; this never executes a product."""
import argparse,hashlib,json,pathlib,tarfile
P=pathlib.Path(__file__).resolve().parent
CASES=[method+'-'+mt+'-'+pose for method in ['raster','retained'] for mt in ['mt0','mt1'] for pose in ['rest','posed']]
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main(a):
 proof=a.proof.resolve(); output=proof/'docs/validation'; output.mkdir(exist_ok=True)
 stem='advanced-public-'+('source' if a.workflow=='source-use' else 'uv')+'-'+a.phase+'-matrix-20261118'
 archive=output/(stem+'.tar.gz'); assert not archive.exists()
 rows=[]; members={}; dirs=[]; source_tuple=None; maxima=[]
 for case in CASES:
  tag='canary-v1-20261118' if a.workflow=='source-use' and a.phase=='xr' and case=='raster-mt1-rest' else 'matrix-v1-20261118'
  d=P/('release-'+a.workflow+'-'+a.phase+'-'+case+'-'+tag)
  s=json.loads((d/'status.json').read_text()); r=json.loads((d/'workflow/report.json').read_text())
  assert s['state']=='terminal' and s['exit']==0 and not s['input_drift'] and not s['remaining_owned_processes']
  assert len(s['actual_app_pids'])==2 and r['complete'] and not r['error'] and not r['drift'] and all(x['passed'] for x in r['checks'])
  assert s['lease_released_epoch']>=s['lease_acquired_epoch'] and s['lease_before_any_graphics_child']
  assert source_tuple in [None,s['source_tuple']]; source_tuple=s['source_tuple']
  closure=next(d.glob('closure*.json')); c=json.loads(closure.read_text())
  assert c['status_sha256']==sha(d/'status.json') and c['all_Apps_absent'] and not c['remaining_owned'] and not c['input_drift'] and c['unit_stopped'] and c['unit_ExecMainStatus']==0 and c['unit_Result']=='success'
  assert (c.get('independent_NB',{}).get('free') or c.get('independent_NB_free'))
  native=[]
  for f in sorted((d/'workflow').rglob('native-*.json')):
   n=json.loads(f.read_text()); assert n['verified']
   if n.get('normal_oracle') is not None:
    o=n['normal_oracle']; assert o['finite_samples'] and o['maximum_allowed_error']==.035
    v=o['maximum_component_error']; maxima.extend(v if isinstance(v,list) else [v])
    if a.workflow=='source-use':
     assert o['minimum_negative_error']==.05 and all(x>.05 for role in ['omitted','swapped','wrong_domain'] for x in o[role])
   native.append({'path':str(f.relative_to(P)),'sha256':sha(f),'verification':n})
  assert native
  rows.append({'case':case,'status_path':str(d/'status.json'),'status_sha256':sha(d/'status.json'),'checks':s['checks'],'seconds':s['seconds'],'peak_RSS':s['peak_RSS'],'input_pin_count':len(s['pins']),'critical_observed':s['critical_observed'],'critical_expected_ELFs':s['critical_expected_ELFs'],'actual_App_PIDs':s['actual_app_pids'],'device_reports':s.get('device_reports'),'report':r,'native_verifications':native,'closure':c})
  dirs.append(d)
 files=[]
 for d in dirs:files.extend(f for f in d.rglob('*') if f.is_file())
 files.extend(P/f for f in ['run-v1.py','cohort.py','operational-plan-v1.json','scenario-provenance.json','audit-close-public-case-20261118.py','launch-one-parent-authorized-20261118.py','run-sequential-public-cases-20261118.py','process_observer.py','monitor_lifetime_v2.py','monitor_lifetime_v3.py'])
 files.extend(P.glob('parent-authorized-'+a.workflow+'-'+a.phase+'*.json'))
 files.extend(f for f in (P/'scenarios').rglob('*') if f.is_file())
 files.extend(f for f in (P/'bin').rglob('*') if f.is_file())
 files.append(pathlib.Path(__file__).resolve())
 files=sorted(set(files))
 with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
  for f in files:
   name=str(f.relative_to(P)); assert not f.is_symlink(); members[name]=sha(f); tar.add(f,arcname=name,recursive=False)
 with tarfile.open(archive,'r:gz') as tar:
  assert set(tar.getnames())==set(members)
  for m in tar:
   assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==members[m.name]
 summary={'state':'terminal','exit':0,'workflow':a.workflow,'phase':a.phase,'cases':8,'checks':sum(r['checks'] for r in rows),'fresh_Apps':16,'source_tuple':source_tuple,'maximum_normal_component_error':max(maxima),'normal_error_bound_unchanged':.035,'driver_sha256':sha(P/'run-v1.py'),'cohort_sha256':sha(P/'cohort.py'),'rows':rows,'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':members},'scope':'Advanced component App41a/native91b/runtimee6c/font1afa. GUI private-Xvfb softwareGL or authenticated Arc real-loader synthetic XR as recorded. No whole advanced owning build, main product admission, native Wayland or physical HMD acceptance.'}
 assert summary['maximum_normal_component_error']<.035
 (output/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({k:v for k,v in summary.items() if k not in ['rows','archive']},indent=2));print(archive,archive.stat().st_size)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workflow',choices=['source-use','uv-create'],required=True);p.add_argument('--phase',choices=['gui','xr'],required=True);p.add_argument('--proof',type=pathlib.Path,required=True);main(p.parse_args())
