"""Sequential orchestration of existing authorized immutable per-case runner."""
import argparse,hashlib,json,pathlib,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent
CASES=[method+'-'+mt+'-'+pose for method in ['raster','retained'] for mt in ['mt0','mt1'] for pose in ['rest','posed']]
def main(a):
 review=P/('parent-authorized-'+a.workflow+'-'+a.phase+('-remaining' if a.workflow=='source-use' else '')+'-20261118.json')
 h=hashlib.sha256(review.read_bytes()).hexdigest();j=json.loads(review.read_text())
 assert j['workflow']==a.workflow and j['phase']==a.phase
 for case in (a.cases or CASES):
  assert case in j['cases']
  tag='matrix-v1-20261118';out=P/('release-'+a.workflow+'-'+a.phase+'-'+case+'-'+tag)
  assert not out.exists(),('Do not rerun existing case',str(out))
  unit='ds-advanced-'+a.workflow+'-'+a.phase+'-'+case+'-'+tag+'.service'
  argv=[sys.executable,str(P/'launch-one-parent-authorized-20261118.py'),'--workflow',a.workflow,'--phase',a.phase,'--case',case,'--tag',tag,'--gui-tag',a.gui_tag,'--review',str(review),'--review-sha',h]
  subprocess.run(argv,check=True)
  print('LAUNCHED '+unit,flush=True);deadline=time.monotonic()+620
  while True:
   fields=subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','SubState','-p','ExecMainStatus'],text=True);props=dict(x.split('=',1) for x in fields.splitlines())
   if props['MainPID']=='0' and props['SubState'] in ['exited','failed','dead']:break
   assert time.monotonic()<deadline,('Orchestration wait expired; inspect actual unit',unit)
   time.sleep(2)
  cmd=[sys.executable,str(P/'audit-close-public-case-20261118.py'),'--workflow',a.workflow,'--phase',a.phase,'--case',case,'--tag',tag,'--unit',unit]
  if a.workflow=='source-use' and a.phase=='xr':cmd+=['--expected-checks','65']
  subprocess.run(cmd,check=True)
  print('CLOSED '+unit,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workflow',choices=['source-use','uv-create'],required=True);p.add_argument('--phase',choices=['gui','xr'],required=True);p.add_argument('--gui-tag',default='matrix-v1-20261118');p.add_argument('--cases',nargs='*');main(p.parse_args())
