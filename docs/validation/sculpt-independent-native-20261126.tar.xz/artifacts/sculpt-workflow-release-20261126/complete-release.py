import pathlib,subprocess,json,shlex,hashlib,time
B=pathlib.Path(__file__).resolve().parent
status={'started':time.time(),'terminal':False,'scope':'Necessary native-graphics whole-TU recompile after prospective pins, actual dependent links, and two existing sculpt regression consumers. Original early generator compile preserved separately.'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(B/'completion-status.json').write_text(json.dumps(status,indent=2)+'\n')
def deps(p):return shlex.split(pathlib.Path(p).read_text().replace('\\\n',' ').split(':',1)[1].split('\n')[0])
save()
try:
 before=json.loads((B/'before-input-pins.json').read_text());assert all(sha(p)==h for p,h in before.items())
 assert json.loads((B/'resume-status.json').read_text())['exit']==0
 T=['dome-sculpt-sculpt-independent-workflow','dome-sculpt-sculpt-sustained','dome-sculpt-sculpt-surface-chunks-test','dome-sculpt-sculpt-chunk-pipeline-test']
 commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands',*T],text=True).splitlines();(B/'completion-commands.txt').write_text('\n'.join(commands)+'\n')
 comp=[shlex.split(x) for x in commands if x.startswith('/usr/bin/') and ' -c ' in x]
 extra=[c for c in comp if c[-1].endswith(('/sculpt-surface-chunks.cpp','/sculpt-chunk-pipeline.cpp')) and '/tests/' in c[-1]]
 pp=B/'regression-prospective';pp.mkdir()
 epins={}
 for i,c in enumerate(extra):
  a=[c[0]];j=1
  while j<len(c):
   if c[j] in ['-o','-MF','-MT','-MQ']:j+=2;continue
   if c[j] in ['-MD','-MMD','-c']:j+=1;continue
   a.append(c[j]);j+=1
  d=pp/(str(i)+'.d');r=subprocess.run(a+['-M','-MF',str(d),'-MT','prospective'],cwd=B,capture_output=True,text=True);assert r.returncode==0,r.stderr
  for q in deps(d):p=pathlib.Path(q).resolve();epins[str(p)]=sha(p)
 (B/'regression-before-pins.json').write_text(json.dumps(epins,indent=2)+'\n')
 c=next(c for c in comp if c[-1].endswith('/third_party/openbrush/graphics.cpp'))
 with (B/'native-graphics-qualified-recompile.log').open('w') as f:r=subprocess.run(c,cwd=B,stdout=f,stderr=subprocess.STDOUT)
 status['support_recompile']={'command':c,'cwd':str(B),'exit':r.returncode,'object_sha256':sha(B/c[c.index('-o')+1]),'md_sha256':sha(B/c[c.index('-MF')+1])};assert r.returncode==0
 with (B/'completion-build.log').open('w') as f:r=subprocess.run(['ninja','-C',str(B),'-d','keepdepfile','-d','keeprsp','-j2',*T],stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0
 drift=[p for p,h in (before|epins).items() if sha(p)!=h];assert not drift
 objects=[]
 for c in comp:
  obj=B/c[c.index('-o')+1];md=B/c[c.index('-MF')+1];assert obj.is_file() and md.is_file();objects.append({'object':str(obj),'sha256':sha(obj),'md':str(md),'md_sha256':sha(md)})
 (B/'qualified-current-objects.json').write_text(json.dumps(objects,indent=2)+'\n')
 status.update({'exit':0,'state':'passed','input_drift':drift,'unique_compiler_owners':len(objects),'core_members':len(subprocess.check_output(['ar','t',str(B/'libdome-sculpt-core.a')],text=True).splitlines()),'products':{t:sha(B/t) for t in T}})
except BaseException as e:status.update({'exit':1,'state':'failed','error':repr(e)})
finally:status.update({'terminal':True,'seconds':time.time()-status['started']});save()
raise SystemExit(status['exit'])
