import pathlib,subprocess,json,shlex,hashlib,time,concurrent.futures,os
B=pathlib.Path(__file__).resolve().parent
S=B.parent/'sculpt-workflow-source-20261126'
T=['dome-sculpt-sculpt-independent-workflow','dome-sculpt-sculpt-sustained']
status={'source':'6d3ca25e49692ce777f65c280a7deffb616b729f','started':time.time(),'terminal':False,'scope':'Fresh selected headless native Document and actual EGL sustained renderer; no UI/XR or whole-suite claim'}
def save(): (B/'resume-status.json').write_text(json.dumps(status,indent=2)+'\n')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def deps(p):
 t=pathlib.Path(p).read_text().replace('\\\n',' ')
 return shlex.split(t.split(':',1)[1].split('\n')[0])
save()
try:
 g=subprocess.run(['ninja','-C',str(B),'-d','keepdepfile','armorpaint-blur-generated/blur_weights.hpp'],capture_output=True,text=True);(B/'generator.log').write_text(g.stdout+g.stderr);assert g.returncode==0
 commands=subprocess.check_output(['ninja','-C',str(B),'-t','commands',*T],text=True).splitlines()
 (B/'selected-commands.txt').write_text('\n'.join(commands)+'\n')
 comp=[shlex.split(x) for x in commands if x.startswith('/usr/bin/') and ' -c ' in x]
 P=B/'prospective-md';P.mkdir()
 def scan(item):
  i,c=item;out=P/(str(i)+'.d');a=[c[0]];j=1
  while j<len(c):
   if c[j] in ['-o','-MF','-MT','-MQ']:j+=2;continue
   if c[j] in ['-MD','-MMD','-c']:j+=1;continue
   a.append(c[j]);j+=1
  a+=['-M','-MF',str(out),'-MT','prospective']
  r=subprocess.run(a,cwd=B,capture_output=True,text=True);(P/(str(i)+'.log')).write_text(r.stdout+r.stderr)
  assert r.returncode==0,(i,r.returncode,r.stderr[-500:]);return list(deps(out))
 allpaths=set()
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for row in pool.map(scan,enumerate(comp)):allpaths.update(row)
 for x in subprocess.check_output(['git','-C',str(S),'ls-files'],text=True).splitlines():allpaths.add(str(S/x))
 for x in ['/usr/bin/c++','/usr/bin/cc','/usr/bin/ninja','/usr/bin/cmake','/usr/bin/ar','/usr/bin/ranlib','/usr/bin/ld','/usr/libexec/gcc/x86_64-redhat-linux/16/cc1plus','/usr/libexec/gcc/x86_64-redhat-linux/16/cc1','/usr/libexec/gcc/x86_64-redhat-linux/16/collect2']:allpaths.add(x)
 for c in commands:
  for v in shlex.split(c):
   if v.startswith('/') and pathlib.Path(v).is_file():allpaths.add(v)
 pins={str(pathlib.Path(x).resolve()):sha(x) for x in allpaths if pathlib.Path(x).is_file()}
 (B/'before-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
 status.update({'prospective_compile_owners':len(comp),'before_inputs':len(pins),'state':'compiling'});save()
 with (B/'fresh-build.log').open('w') as f:r=subprocess.run(['ninja','-C',str(B),'-d','keepdepfile','-d','keeprsp','-j2',*T],stdout=f,stderr=subprocess.STDOUT)
 status['build_exit']=r.returncode;assert r.returncode==0
 drift=[p for p,h in pins.items() if not pathlib.Path(p).is_file() or sha(p)!=h]
 actual=[];unknown=set()
 for c in comp:
  obj=c[c.index('-o')+1];md=c[c.index('-MF')+1];op=B/obj;dp=B/md;assert op.is_file() and dp.is_file(),obj
  ds=deps(dp)
  for d in ds:
   q=str(pathlib.Path(d).resolve() if pathlib.Path(d).is_absolute() else (B/d).resolve())
   if q not in pins:unknown.add(q)
  actual.append({'object':str(op),'sha256':sha(op),'md':str(dp),'md_sha256':sha(dp),'dependencies':len(ds)})
 (B/'actual-objects.json').write_text(json.dumps(actual,indent=2)+'\n')
 status.update({'input_drift':drift,'unknown_dependencies':sorted(unknown),'actual_objects':len(actual),'core_members':len(subprocess.check_output(['ar','t',str(B/'libdome-sculpt-core.a')],text=True).splitlines()),'products':{t:sha(B/t) for t in T}})
 assert not drift and not unknown
 status.update({'state':'passed','exit':0})
except BaseException as e:status.update({'state':'failed','exit':1,'error':repr(e)})
finally:status.update({'terminal':True,'seconds':time.time()-status['started']});save()
raise SystemExit(status['exit'])
