import pathlib,subprocess,json,shlex,hashlib,time
B=pathlib.Path(__file__).resolve().parent;A=B.parent/'sculpt-workflow-sanitize-20261126';P=B.parent/'current-normal-sanitize-20261126';PS=B.parent/'current-normal-resume-20261126';S=B.parent/'sculpt-workflow-source-20261126';F=B.parent/'sculpt-workflow-recovery-source-20261126';T='dome-sculpt-sculpt-independent-workflow'
st={'production_source':'6d3ca25e49692ce777f65c280a7deffb616b729f','fixture_source':'fe94b416','terminal':False,'started':time.time(),'scope':'Matched strict native workflow: ten fresh changed/context core owners plus187 actual qualified unchanged ASan/UBSan parent owners; actual parent MDs/paths preserved'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(B/'assembly-status.json').write_text(json.dumps(st,indent=2)+'\n')
save()
try:
 audit=json.loads((P/'audit.json').read_text());assert audit['errors']==[] and audit['actual_core_owners']==197
 assert json.loads((B/'compile-status.json').read_text())['exit']==0
 assert json.loads((A/'resume-status.json').read_text())['exit']==0
 owners=[o for o in audit['owners'] if '/CMakeFiles/dome-sculpt-core.dir/' in o['object']];assert len(owners)==197
 fresh={pathlib.Path(x['object']).name:x for x in json.loads((A/'actual-objects.json').read_text()) if '/CMakeFiles/dome-sculpt-core.dir/' in x['object']};assert len(fresh)==10
 oldcommands=json.loads((P/'compile_commands.json').read_text());newcommands=json.loads((A/'compile_commands.json').read_text());newbyfile={str(pathlib.Path(x['file']).relative_to(S)):x for x in newcommands}
 pins={};records=[];selected={}
 for o in owners:
  op=pathlib.Path(o['object']);name=op.name
  if name in fresh:
   n=fresh[name];assert sha(n['object'])==n['sha256'] and sha(n['md'])==n['md_sha256'];selected[name]=n['object'];records.append({'role':'fresh_changed_or_resource_context','object':n['object'],'sha256':n['sha256'],'actual_md':n['md']});continue
  assert sha(op)==o['object_sha256'] and sha(o['depfile'])==o['depfile_sha256']
  for d in o['dependencies']:
   p=pathlib.Path(d)
   if p.is_relative_to(PS):
    q=S/p.relative_to(PS);assert q.is_file() and sha(q)==sha(p),(op,d,str(q));pins[str(q)]=sha(q)
   pins[str(p.resolve())]=sha(p)
  rel=str(pathlib.Path(next(c['file'] for c in oldcommands if '-o '+str(op.relative_to(P))+' ' in c['command'])).relative_to(PS));oc=next(c['command'] for c in oldcommands if c['file']==str(PS/rel));nc=newbyfile[rel]['command'];assert oc.replace(str(PS),str(S)).replace(str(P),str(A))==nc,rel
  assert rel!='src/vroid-creator.cpp'
  selected[name]=str(op);records.append({'role':'qualified_unchanged_parent','object':str(op),'sha256':o['object_sha256'],'actual_md':o['depfile']})
 order=subprocess.check_output(['ar','t',str(P/'libdome-sculpt-core.a')],text=True).splitlines();assert len(order)==197 and len(set(order))==197 and set(order)==set(selected)
 for r in records:pins[str(pathlib.Path(r['object']).resolve())]=r['sha256'];pins[str(pathlib.Path(r['actual_md']).resolve())]=sha(r['actual_md'])
 for p,h in audit['derived_inputs'].items():assert sha(p)==h;pins[p]=h
 for a in audit['archives']:assert sha(a['path'])==a['sha256'];pins[a['path']]=a['sha256']
 c=json.loads((B/'compile-commands.json').read_text())[0];fixture=B/(T+'.o');assert sha(fixture)==json.loads((B/'compile-status.json').read_text())['objects'][T];pins[str(fixture)]=sha(fixture)
 (B/'continuation-before-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(B/'core-owning-objects.json').write_text(json.dumps(records,indent=2)+'\n')
 core=B/'libdome-sculpt-core.a';cmd=['/usr/bin/ar','qc',str(core),*[selected[n] for n in order]];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stderr;subprocess.run(['/usr/bin/ranlib',str(core)],check=True)
 for n in order:assert hashlib.sha256(subprocess.check_output(['ar','p',str(core),n])).hexdigest()==sha(selected[n]),n
 raw=subprocess.check_output(['ninja','-C',str(A),'-t','commands',T],text=True).splitlines();line=next(x for x in raw if x.startswith(': && /usr/bin/c++') and ' -o '+T+' ' in x);link=shlex.split(line.removeprefix(': && ').removesuffix(' && :'))
 for i,x in enumerate(link):
  if x.endswith('.a') and not x.startswith('/'):link[i]=str(core) if x=='libdome-sculpt-core.a' else str(P/x)
  elif x.endswith('.o') and not x.startswith('/'):link[i]=str(fixture)
  elif x.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(B/(T+'.link.d'))
 link[link.index('-o')+1]=str(B/T);assert '-fsanitize=address,undefined' in link
 (B/'archive-and-link-commands.json').write_text(json.dumps({'archive':cmd,'link':link},indent=2)+'\n')
 with (B/'link.log').open('w') as f:r=subprocess.run(link,cwd=B,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0
 elf=subprocess.check_output(['readelf','-d',str(B/T)],text=True);(B/'ELF-dynamic.txt').write_text(elf);assert 'libasan' in elf and 'libubsan' in elf
 drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift
 st.update({'exit':0,'state':'passed','fresh_core_owners':10,'qualified_unchanged_core_owners':187,'actual_archive_payloads':197,'input_drift':drift,'ELF_sha256':sha(B/T),'core_sha256':sha(core)})
except BaseException as e:st.update({'exit':1,'state':'failed','error':repr(e)})
finally:st.update({'terminal':True,'seconds':time.time()-st['started']});save()
raise SystemExit(st['exit'])
