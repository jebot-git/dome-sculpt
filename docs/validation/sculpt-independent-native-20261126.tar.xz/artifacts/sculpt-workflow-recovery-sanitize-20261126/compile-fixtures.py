import pathlib,json,subprocess,shlex,hashlib,time
B=pathlib.Path(__file__).resolve().parent;P=B.parent/'sculpt-workflow-sanitize-20261126';oldS=B.parent/'sculpt-workflow-source-20261126';S=B.parent/'sculpt-workflow-recovery-source-20261126';T=['dome-sculpt-sculpt-independent-workflow']
st={'production_source':'6d3ca25e','fixture_source':'fe94b416','terminal':False,'started':time.time(),'scope':'One corrected complete ASan/UBSan fixture TUs; link awaits independently qualified parent core continuation'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(B/'compile-status.json').write_text(json.dumps(st,indent=2)+'\n')
def deps(p):return shlex.split(pathlib.Path(p).read_text().replace('\\\n',' ').split(':',1)[1].split('\n')[0])
save()
try:
 pins=json.loads((P/'before-input-pins.json').read_text());assert all(sha(p)==h for p,h in pins.items());cmds=(P/'selected-commands.txt').read_text().splitlines();commands=[]
 for i,t in enumerate(T):
  c=next(shlex.split(x) for x in cmds if x.startswith('/usr/bin/') and ' -c ' in x and t+'.dir/tests/' in x);c=[x.replace(str(oldS),str(S)) for x in c];c[c.index('-o')+1]=str(B/(t+'.o'));c[c.index('-MF')+1]=str(B/(t+'.o.d'));commands.append(c)
  a=[c[0]];j=1
  while j<len(c):
   if c[j] in ['-o','-MF','-MT','-MQ']:j+=2;continue
   if c[j] in ['-MD','-MMD','-c']:j+=1;continue
   a.append(c[j]);j+=1
  d=B/(str(i)+'.prospective.d');r=subprocess.run(a+['-M','-MF',str(d),'-MT','prospective'],cwd=B,capture_output=True,text=True);assert r.returncode==0,r.stderr
  for q in deps(d):p=pathlib.Path(q).resolve();pins[str(p)]=sha(p)
 (B/'before-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(B/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 for i,a in enumerate(commands):
  with (B/(str(i)+'.log')).open('w') as f:r=subprocess.run(a,cwd=B,stdout=f,stderr=subprocess.STDOUT)
  assert r.returncode==0,(i,r.returncode)
  assert all(str(pathlib.Path(q).resolve()) in pins for q in deps(a[a.index('-MF')+1]))
 drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift
 st.update({'exit':0,'state':'passed','input_drift':drift,'fresh_whole_TUs':1,'objects':{t:sha(B/(t+'.o')) for t in T}})
except BaseException as e:st.update({'exit':1,'state':'failed','error':repr(e)})
finally:st.update({'terminal':True,'seconds':time.time()-st['started']});save()
raise SystemExit(st['exit'])
