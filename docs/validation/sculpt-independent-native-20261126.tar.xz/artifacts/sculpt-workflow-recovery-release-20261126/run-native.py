import pathlib,json,os,fcntl,subprocess,time,hashlib,signal,re,resource
B=pathlib.Path(__file__).resolve().parent;D=B/'native-v1';D.mkdir()
exe=B/'dome-sculpt-sculpt-independent-workflow';deadline=900;rsslimit=4*1024**3
status={'production_source':'6d3ca25e49692ce777f65c280a7deffb616b729f','fixture_source':'fe94b416','terminal':False,'started':time.time(),'command':[str(exe),str(D/'workflow')],'timeout_seconds':deadline,'rss_limit_bytes':rsslimit,'AS_cap':None,'scope':'Full-size four independent objects: native Document layers, masks, native gestures, history, ordered Save, cold Open, durable recovery and exact independent geometry; no GUI/physical-HMD claim'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(): (D/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def proc(pid):
 try:
  z=(pathlib.Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'ppid':int(z[1]),'pgrp':int(z[2]),'start':int(z[19]),'RSS':int(z[21])*os.sysconf('SC_PAGE_SIZE'),'state':z[0]}
 except (FileNotFoundError,ProcessLookupError):return None
status['driver_sha256']=sha(__file__);save();fd=os.open('/tmp/dome-sculpt-arc-device.lock',os.O_RDWR);child=None;known={}
try:
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(fd);status['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino,'before_ldd_and_product':True};save()
 pins=json.loads((B/'before-input-pins.json').read_text());drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift,drift
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'})
 r=subprocess.run(['/usr/bin/ldd',str(exe)],env=env,capture_output=True,text=True,timeout=60);(D/'ldd.txt').write_text(r.stdout+r.stderr);assert r.returncode==0 and 'not found' not in r.stdout
 providers=set()
 for line in r.stdout.splitlines():
  m=re.search(r'(?:=>\s+)?(/\S+)',line)
  if m:providers.add(str(pathlib.Path(m.group(1)).resolve()))
 providers={p:sha(p) for p in sorted(providers)};(D/'provider-before-pins.json').write_text(json.dumps(providers,indent=2)+'\n');status['executable_sha256']=sha(exe);status['providers']=len(providers);save()
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'})
 def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 with (D/'product.log').open('w') as out:
  child=subprocess.Popen(status['command'],cwd=B,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits)
  status['pid']=child.pid;first=proc(child.pid);assert first;status['process_identity']=first;start=time.monotonic();peak=0;samples=0;mapped=False
  while child.poll() is None:
   own=[]
   for q in pathlib.Path('/proc').iterdir():
    if q.name.isdigit():
     a=proc(int(q.name))
     if a and a['pgrp']==child.pid:own.append(a);known[(a['pid'],a['start'])]=a
   peak=max(peak,sum(a['RSS'] for a in own));samples+=1
   if not mapped:
    try:
     actual=os.readlink('/proc/'+str(child.pid)+'/exe');maps=pathlib.Path('/proc/'+str(child.pid)+'/maps').read_text()
     if actual==str(exe) and maps:
      (D/'actual-maps.txt').write_text(maps);status['actual_executable_path']=actual;mapped=True
    except (FileNotFoundError,ProcessLookupError):pass
   elapsed=time.monotonic()-start
   if elapsed>deadline or peak>rsslimit:
    status['limit_failure']='deadline' if elapsed>deadline else 'RSS';w=proc(child.pid)
    if w and w['start']==first['start']:os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
    break
   time.sleep(.05)
  status.update({'product_exit':child.wait(),'seconds':time.monotonic()-start,'peak_owned_RSS_bytes':peak,'samples':samples,'mapped_witness':mapped})
 survivors=[x for (pid,start),x in known.items() if (a:=proc(pid)) and a['start']==start and a['state']!='Z'];status['owned_survivors']=survivors;assert not survivors
 status['input_drift']=[p for p,h in pins.items() if sha(p)!=h];status['provider_drift']=[p for p,h in providers.items() if sha(p)!=h];assert not status['input_drift'] and not status['provider_drift']
 log=(D/'product.log').read_text();m=re.search(r'PASS independent production sculpt workflow checks=(\d+) objects=4',log);status['checks']=int(m.group(1)) if m else None
 assert status['product_exit']==0 and mapped and m and 'FAIL ' not in log
 status.update({'exit':0,'state':'passed'})
except BaseException as e:status.update({'exit':1,'state':'failed','error':repr(e)})
finally:
 status['terminal']=True;status['finished']=time.time()
 if 'lease' in status:status['lease']['released']=time.time()
 save();os.close(fd)
raise SystemExit(status['exit'])
