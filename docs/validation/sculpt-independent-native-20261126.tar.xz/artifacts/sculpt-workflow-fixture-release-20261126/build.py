import pathlib,subprocess,shlex,hashlib,json,time
B=pathlib.Path(__file__).resolve().parent;R=B.parent/'sculpt-workflow-release-20261126';oldS=B.parent/'sculpt-workflow-source-20261126';S=B.parent/'sculpt-workflow-fixture-source-20261126';targets=['dome-sculpt-sculpt-independent-workflow','dome-sculpt-sculpt-sustained']
st={'production_source':'6d3ca25e49692ce777f65c280a7deffb616b729f','fixture_source':'87f6b41f','started':time.time(),'terminal':False,'scope':'Exactly two complete fixture TUs; qualified unchanged Release core/support/render owners retain actual old paths and provenance'}
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save():(B/'status.json').write_text(json.dumps(st,indent=2)+'\n')
def deps(p):return shlex.split(pathlib.Path(p).read_text().replace('\\\n',' ').split(':',1)[1].split('\n')[0])
save()
try:
 assert json.loads((R/'completion-status.json').read_text())['exit']==0
 pins=json.loads((R/'before-input-pins.json').read_text());assert all(sha(p)==h for p,h in pins.items())
 cmds=(R/'completion-commands.txt').read_text().splitlines();comp=[];links=[]
 for t in targets:
  c=next(shlex.split(x) for x in cmds if x.startswith('/usr/bin/') and ' -c ' in x and t+'.dir/tests/' in x)
  c=[x.replace(str(oldS),str(S)) for x in c];c[c.index('-o')+1]=str(B/(t+'.o'));c[c.index('-MF')+1]=str(B/(t+'.o.d'));comp.append(c)
  raw=next(x for x in cmds if x.startswith(': && /usr/bin/c++') and ' -o '+t+' ' in x);a=shlex.split(raw.removeprefix(': && ').removesuffix(' && :'))
  for i,x in enumerate(a):
   if x.endswith('.a') and not x.startswith('/'):a[i]=str(R/x)
   elif x.endswith('.o') and not x.startswith('/'):a[i]=str(B/(t+'.o'))
   elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(B/(t+'.link.d'))
  a[a.index('-o')+1]=str(B/t);links.append(a)
 for i,c in enumerate(comp):
  a=[c[0]];j=1
  while j<len(c):
   if c[j] in ['-o','-MF','-MT','-MQ']:j+=2;continue
   if c[j] in ['-MD','-MMD','-c']:j+=1;continue
   a.append(c[j]);j+=1
  d=B/(str(i)+'.prospective.d');p=subprocess.run(a+['-M','-MF',str(d),'-MT','prospective'],capture_output=True,text=True,cwd=B);assert p.returncode==0,p.stderr
  for q in deps(d):p=pathlib.Path(q).resolve();pins[str(p)]=sha(p)
 for a in links:
  for p in a:
   if p.startswith('/') and pathlib.Path(p).is_file():pins[str(pathlib.Path(p).resolve())]=sha(p)
 (B/'before-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(B/'commands.json').write_text(json.dumps({'compile':comp,'link':links},indent=2)+'\n')
 for i,a in enumerate(comp+links):
  with (B/(str(i)+'.log')).open('w') as f:r=subprocess.run(a,cwd=B,stdout=f,stderr=subprocess.STDOUT)
  assert r.returncode==0,(i,r.returncode)
 drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift
 for c in comp:
  ds=deps(c[c.index('-MF')+1]);assert all(str(pathlib.Path(q).resolve()) in pins for q in ds)
 st.update({'exit':0,'state':'passed','input_drift':drift,'fresh_whole_TUs':2,'products':{t:sha(B/t) for t in targets}})
except BaseException as e:st.update({'exit':1,'state':'failed','error':repr(e)})
finally:st.update({'terminal':True,'seconds':time.time()-st['started']});save()
raise SystemExit(st['exit'])
