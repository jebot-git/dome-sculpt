from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import signal
import subprocess
import time

base=Path(__file__).resolve().parent
artifacts=base.parent
candidate=artifacts/"vrm-consumer-source-20261126"
build=artifacts/"vrm-consumer-combined-asan-20261126"
source=candidate/"tests/retopo-affine-xr.py"
binary=build/"dome-sculpt"
runtime=build/"libdome-sculpt-test-runtime.so"
out=base/"workflow"
out.mkdir(mode=0o700,exist_ok=False)
confirmed=subprocess.check_output(["git","-C",candidate,"rev-parse","HEAD"],text=True).strip()
assert confirmed=="ccbbe02093bed6997bdacdf0d36b3a11bc1f177d"
assert not subprocess.check_output(["git","-C",candidate,"status","--porcelain"],text=True)
def sha(path):
    with path.open("rb") as s:
        return hashlib.file_digest(s,"sha256").hexdigest()
original=source.read_text()
old="'LIBGL_ALWAYS_SOFTWARE':'1'"
assert original.count(old)==1
replay=base/"retopo-affine-arc.py"
replay.write_text(original.replace(old,"'LIBGL_ALWAYS_SOFTWARE':'0'"))
node="/dev/dri/renderD129"
libpath=str(artifacts/"sdk-20261126/toolkit-sanitize/lib")+":/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
command=["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/",
         "--bind",out,out,"--proc","/proc","--dev","/dev","--dev-bind",node,node,
         "--tmpfs","/tmp","--tmpfs","/run/user","--clearenv"]
env={"PATH":"/usr/bin:/bin","HOME":"/tmp","LD_LIBRARY_PATH":libpath,
     "DRI_PRIME":"pci-0000_03_00_0","MESA_SHADER_CACHE_DISABLE":"1","LP_NUM_THREADS":"2",
     "ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1","UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1"}
for key,value in env.items():
    command.extend(["--setenv",key,value])
command.extend(["/usr/bin/python3.14",replay,binary,runtime,build/"dome-sculpt-native-authoring-inspect",build/"retopology-affine-ui.dsculpt",out])
def descendants(pid):
    yield pid
    try:
        children=Path(f"/proc/{pid}/task/{pid}/children").read_text().split()
    except (FileNotFoundError,ProcessLookupError):
        return
    for child in children:
        yield from descendants(int(child))
def observe(pid):
    for child in descendants(pid):
        proc=Path(f"/proc/{child}")
        try:
            if (proc/"exe").resolve()!=binary.resolve():
                continue
            maps=(proc/"maps").read_text()
            descriptors=set()
            for fd in (proc/"fd").iterdir():
                try:
                    descriptors.add(os.readlink(fd))
                except (FileNotFoundError,ProcessLookupError):
                    pass
            if node not in descriptors or "/libasan.so" not in maps or "/libubsan.so" not in maps:
                continue
            files=[s.rsplit(None,1)[-1] for s in maps.splitlines() if "/libgallium" in s or "/iris_dri.so" in s]
            if files:
                args=(proc/"cmdline").read_bytes().split(b"\0")
                witnesses[str(child)]={"argv":[x.decode(errors="replace") for x in args if x],
                                       "drm":node,"mesa_files":sorted(set(files)),
                                       "asan_ubsan":True}
        except (FileNotFoundError,ProcessLookupError):
            continue
state={"candidate":confirmed,"invocation":os.getenv("INVOCATION_ID"),"terminal":False,
       "app_sha256":sha(binary),"runtime_sha256":sha(runtime),"original_runner_sha256":sha(source),
       "arc_runner_sha256":sha(replay),"arc_selector":env["DRI_PRIME"]}
receipt=base/"status.json"
begin=time.monotonic()
witnesses={}
def write(**fields):
    state.update(fields,elapsed=round(time.monotonic()-begin,2))
    temporary=base/"status.tmp"
    temporary.write_text(json.dumps(state,indent=2)+"\n")
    temporary.replace(receipt)
with open("/tmp/dome-sculpt-arc-device.lock","rb") as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    write(phase="loader and Arc")
    with (base/"run.log").open("w") as log:
        print(shlex.join(map(str,command)),file=log,flush=True)
        proc=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        while proc.poll() is None:
            observe(proc.pid)
            if time.monotonic()-begin>600:
                os.killpg(proc.pid,signal.SIGTERM)
                proc.wait(timeout=10)
                break
            time.sleep(.15)
report=json.loads((out/"report.json").read_text())
passed=sum(row["passed"] for row in report["checks"])
write(terminal=True,exit=proc.returncode,arc_processes=witnesses,checks=passed,
      report_complete=(report["failed"]==0 and proc.returncode==0),report_error=report.get("error"))
raise SystemExit(proc.returncode or not witnesses or report["failed"] or proc.returncode!=0 or not passed)
