from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
profile=sys.argv[1]
hardware=profile=='asan'
art=base.parent
out=base/profile
out.mkdir(exist_ok=True)
source=art/'current-sculpt-selection-fixtures-source-20261126'
fixtures=art/'current-sculpt-selection-fixtures-validation-20261126'/profile
parent=art/'renderer-projection-combined-validation-20261126'/profile
runtime=art/'retained-texture-set-public-validation-20261126'/profile
sdk=art/'sdk-20261126/toolkit-sanitize' if hardware else Path('/opt/fltk-vr/toolkit')
candidate='6f7fa6f9721ff3b87997c2baa5efa0d9e451fa53'
status={'candidate':candidate,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def save(**updates):
    status.update(updates)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')

try:
    save(phase='wait for validated selection fixtures')
    while True:
        receipt=fixtures/'status.json'
        if receipt.is_file():
            state=json.loads(receipt.read_text())
            break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        f'ds-current-sculpt-selection-fixtures-{profile}-20261126.service'],check=True)
        time.sleep(1)
    assert state['candidate']==candidate and len(state['results'])==3 and all(row['exit']==0 for row in state['results'])
    test='object-selection'
    helper=fixtures/test/f'dome-sculpt-{test}-test'
    digest=next(row['binary_sha256'] for row in state['results'] if row['test']==test)
    assert sha(helper)==digest
    app=parent/'build/dome-sculpt'
    app_state=json.loads((parent/'status.json').read_text())
    assert app_state['candidate']==state['donor'] and app_state['exit']==0 and sha(app)==app_state['app_sha256']
    library=runtime/'libdome-sculpt-test-runtime.so'
    assert sha(library)==json.loads((runtime/'status.json').read_text())['runtime_sha256']
    assert subprocess.check_output(['git','-C',source,'diff','--name-only','33bd2460','HEAD','--',
        'tests/xr_runtime.cpp','tests/object-selection-xr.py'],text=True)==''
    sandbox=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    settings={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
              'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if hardware:
        arc='/dev/dri/renderD129'
        sandbox.extend(['--dev-bind',arc,arc])
        settings.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
                        DOME_SELECTION_HARDWARE='1',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                        UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in settings.items():sandbox.extend(['--setenv',key,value])
    script=source/'tests/object-selection-xr.py'
    argv=[*sandbox,'/usr/bin/python3',script,app,library,helper,out/'xr']
    save(phase='exercise real stereo and synthetic selection input',app_sha256=sha(app),
         helper_sha256=digest,runtime_sha256=sha(library))
    with (out/'xr.log').open('w') as log, open('/tmp/dome-sculpt-arc-device.lock','rb') as lock:
        if hardware:fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,argv)),file=log,flush=True)
        subprocess.run(argv,cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    report=out/'xr/report.json'
    result=json.loads(report.read_text())
    actual=json.loads((out/'xr/runtime.json').read_text())['gl_renderer']
    assert ('Arc(tm) A770' if hardware else 'llvmpipe') in actual
    assert result['synthetic_tracking'] and result['failed']==0 and len(result['checks'])==11
    save(phase='complete',terminal=True,exit=0,checks=len(result['checks']),renderer=actual,report_sha256=sha(report))
except Exception as error:
    save(terminal=True,exit=1,error=repr(error))
    raise
