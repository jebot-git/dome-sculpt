from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

fixtures=Path(__file__).resolve().parent
root=fixtures.parents[1]
public=fixtures.parent/'current-sculpt-selection-public-20261126'
base=fixtures/'baseline'
validation=root/'docs/validation'
candidate='6f7fa6f9721ff3b87997c2baa5efa0d9e451fa53'
tests=('object-selection','object-isolation','modal-selection-controls')
files={}

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def add(prefix,folder,*members):
    for name in members:
        path=folder/name
        assert path.is_file(),path
        files[prefix+'/'+name]=path

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

assert git('diff','--name-only',candidate,'HEAD','--','src','include','tests','assets','third_party','CMakeLists.txt')==''
control=read(base/'status.json')
assert len(control['results'])==3 and all(item['exit']==1 for item in control['results'])
add('baseline',base,'status.json',*[name+'.log' for name in tests])
profiles={}
for profile in ('release','asan'):
    state=read(fixtures/profile/'status.json')
    replay=read(public/profile/'status.json')
    assert state['candidate']==replay['candidate']==candidate
    assert len(state['results'])==3 and all(item['exit']==0 for item in state['results'])
    assert replay['terminal'] and replay['exit']==0 and replay['checks']==11
    assert sha(public/profile/'xr/report.json')==replay['report_sha256']
    add(profile+'/native',fixtures/profile,'status.json',*[name+'/run.log' for name in tests])
    add(profile+'/openxr',public/profile,'status.json','xr.log','xr/report.json','xr/runtime.json')
    profiles[profile]={'native':state,'synthetic_openxr':replay}
add('native-runner',fixtures,'run.py','record.py')
add('openxr-runner',public,'run.py')
archive=validation/'selection-fixtures-20261126.tar.gz'
with archive.open('wb') as output,gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as data:
    with tarfile.open(fileobj=data,mode='w') as tar:
        for name,path in sorted(files.items()):
            info=tar.gettarinfo(str(path),arcname=name)
            info.uid=info.gid=info.mtime=0
            info.mode=0o644
            info.uname=info.gname=''
            with path.open('rb') as source:
                tar.addfile(info,source)
hashes={name:sha(path) for name,path in files.items()}
with tarfile.open(archive,'r:gz') as check:
    assert len(check.getmembers())==len(hashes)
    for name,digest in hashes.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==digest
receipt={'fixtures':candidate,'main_merge':git('rev-parse','HEAD'),'baseline':control,'profiles':profiles,
    'archive':{'name':archive.name,'sha256':sha(archive),'members':dict(sorted(hashes.items()))}}
(validation/'selection-fixtures-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(hashes),'evidence files',sha(archive))
