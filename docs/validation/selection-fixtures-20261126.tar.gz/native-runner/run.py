from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parents[2]
artifact=root/'artifacts'
profile=sys.argv[1]
base=Path(__file__).resolve().parent
out=base/profile
out.mkdir(exist_ok=True)
source=artifact/'current-sculpt-selection-fixtures-source-20261126'
parent=artifact/'renderer-projection-combined-validation-20261126'/profile
core=artifact/'sculpt-projection-occlusion-validation-v2-20261126'/profile/'libdome-sculpt-core.a'
tooling=artifact/'steady-gpu-retirement-validation-v2-20261126'/profile/'build'
support=artifact/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=artifact/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit')
donor='c62279e741f9d60eddff95315a1517c2b46b19e4'
candidate='6f7fa6f9721ff3b87997c2baa5efa0d9e451fa53'
tests=('object-selection','object-isolation','modal-selection-controls')

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

assert git('rev-parse','HEAD')==candidate and not git('status','--porcelain')
assert set(git('diff','--name-only',donor,'HEAD').splitlines())=={
    'docs/HANDOFF.md','docs/REQUIREMENTS.md','docs/validation/steady-gpu-retirement-20261126.json',
    'docs/validation/steady-gpu-retirement-20261126.tar.gz','docs/validation/renderer-projection-combined-20261126.json',
    'docs/validation/renderer-projection-combined-20261126.tar.gz',*(f'tests/{name}.cpp' for name in tests)}
status=json.loads((parent/'status.json').read_text())
assert status['candidate']==donor and status['exit']==0 and sha(core)==status['core_sha256']
database=json.loads((tooling/'compile_commands.json').read_text())
isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
variables={'HOME':'/tmp','PATH':'/usr/bin:/bin','LIBGL_ALWAYS_SOFTWARE':'1',
           'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if profile=='asan':
    variables.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                     UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for key,value in variables.items():isolated.extend(['--setenv',key,value])

def execute(name):
    target=f'dome-sculpt-{name}-test'
    directory=out/name
    directory.mkdir(exist_ok=True)
    entry=next(row for row in database if f'CMakeFiles/{target}.dir/' in row['command'])
    compile=[word.replace(str(artifact/'steady-gpu-retirement-source-20261126'),str(source)) for word in shlex.split(entry['command'])]
    index=compile.index('-o')+1
    before=compile[index]
    obj=directory/(Path(entry['file']).name+'.o')
    compile[index]=str(obj)
    binary=directory/target
    commands=subprocess.check_output(['ninja','-C',tooling,'-t','commands',target],text=True)
    words=[word for word in shlex.split(commands.splitlines()[-1])[2:-2] if not word.startswith('-Wl,--dependency-file=')]
    words[words.index(before)]=str(obj)
    words[words.index('-o')+1]=str(binary)
    words=[str(core if word==core.name else support/word) if word.startswith('lib') and word.endswith('.a') else word for word in words]
    with (directory/'build.log').open('w') as trace:
        for argv in (compile,words):
            print(shlex.join(argv),file=trace,flush=True)
            subprocess.run(argv,cwd=tooling,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=180)
    with (directory/'run.log').open('w') as trace:
        result=subprocess.run([*isolated,binary],cwd=directory,stdout=trace,stderr=subprocess.STDOUT,timeout=180)
    return {'test':name,'exit':result.returncode,'binary_sha256':sha(binary),
            'last':(directory/'run.log').read_text().splitlines()[-4:]}

with ThreadPoolExecutor(max_workers=2) as threads:
    results=list(threads.map(execute,tests))
assert git('rev-parse','HEAD')==candidate and not git('status','--porcelain')
(out/'status.json').write_text(json.dumps({'candidate':candidate,'donor':donor,'invocation':os.getenv('INVOCATION_ID'),
    'profile':profile,'core_sha256':sha(core),'results':results},indent=2)+'\n')
assert all(row['exit']==0 for row in results),results
