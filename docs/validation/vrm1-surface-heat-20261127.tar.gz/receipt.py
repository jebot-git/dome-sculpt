from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
docs = repo / 'docs' / 'validation'
name = 'vrm1-surface-heat-20261127'
files = {}


def git(directory, *args):
    return subprocess.check_output(['git', *args], cwd=directory, text=True).strip()


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def digest_file(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def capture(path):
    contents = (work / path).read_bytes()
    files[path] = contents
    return contents


def load(path):
    return json.loads(capture(path))


def lines(path):
    output = capture(path).decode()
    assert not any(line.startswith('FAIL ') for line in output.splitlines()), path
    return [line for line in output.splitlines() if line.startswith('PASS ')]


def registered(path, count):
    items = ET.fromstring(capture(path)).findall('.//testcase')
    names = {item.attrib['name'] for item in items}
    assert len(items) == len(names) == count
    assert all(item.find(tag) is None for item in items for tag in ('failure', 'error', 'skipped'))
    return sorted(names)


revision = git(repo, 'rev-parse', sys.argv[1])
assert not git(repo, 'diff', '--name-only', revision, '--', 'src', 'include', 'tests', 'CMakeLists.txt')
dome = repo.parent / 'DomeD'
canonical = git(dome, 'rev-parse', 'HEAD')
assert canonical == 'acc2b70ae61dedec2a23727f67c60c0303d0f76f'
assert git(dome, 'ls-remote', '--exit-code', 'origin', 'refs/heads/main').split()[0] == canonical

profiles = {}
for profile in ('release', 'asan'):
    assertions = lines(f'{profile}/bone.log')
    assert len(assertions) == 192 and len(lines(f'{profile}/retention.log')) == 11
    assert assertions[-1] == 'PASS native VRM1 bone accessory workflow'
    new = assertions[-12:-1]
    assert any('stale worker cannot overwrite' in line for line in new)
    assert any('Cancellation during linked bind publication' in line for line in new)
    assert any('Editable VRM retains the solved weights and physical emission Bake' in line for line in new)
    denial = load(f'{profile}/factory-sampled/report.json')
    assert not denial['exhaustive_helper'] and len(denial['helper_prefixes']) >= 50
    assert denial['actual_detached_publication_prefixes'] > 100
    capture(f'{profile}/factory-sampled.log')
    capture(f'{profile}/registered.log')
    cases = registered(f'{profile}/registered.xml', 5)
    if profile == 'release':
        cases += registered('release/xr-registered.xml', 2)
        capture('release/xr-registered.log')
    publication = load(f'{profile}/surface-heat/real-publication-faults/report.json')
    assert publication['real_preparation_each_attempt'] and publication['actual_post_helper_publication_prefixes'] > 300
    profiles[profile] = {
        'focused_native_assertions': 191,
        'new_surface_heat_assertions': len(new),
        'retention_assertions': 11,
        'registered_cases': cases,
        'sampled_factory_failures': len(denial['helper_prefixes']),
        'exhaustive_detached_publication_failures': denial['actual_detached_publication_prefixes'],
        'exhaustive_document_publication_failures': publication['actual_post_helper_publication_prefixes'],
        'fixture_sha256': digest_file(work / profile / 'dome-sculpt-vrm1-source-export-test'),
    }

exports = {}
for key in ('heat-before.dsculpt', 'heat-bound.dsculpt', 'heat-bound-editable.vrm'):
    path = f'release/bone/{key}'
    exports[key] = digest(capture(path))
    assert digest_file(work / 'asan' / 'bone' / key) == exports[key], key

wayland = load('wayland/report.json')
assert wayland['complete'] and len(wayland['checks']) == 9 and all(x['passed'] for x in wayland['checks'])
assert digest(capture('wayland/heat-bound.dsculpt')) == exports['heat-bound.dsculpt']
xr = {}
for mode, child, renderer in (('software', 'release/vrm1-attachment-xr', 'llvmpipe'), ('arc', 'arc', 'A770')):
    summary = load(f'{child}/report.json')
    assert not summary['physical_headset'] and len(summary['checks']) == 24 and all(x['passed'] for x in summary['checks'])
    metrics = load(f'{child}/skin-texture-set-heat.json')
    assert renderer in metrics['gl_renderer'] and metrics['acquires'] == metrics['image_waits'] == metrics['releases'] > 0
    assert metrics['stereo_submissions'] > 0
    assert digest(capture(f'{child}/skin-texture-set-heat.dsculpt')) == exports['heat-bound.dsculpt']
    capture(f'{child}/skin-texture-set-heat.log')
    xr[mode] = {'assertions': len(summary['checks']), 'renderer': metrics['gl_renderer'],
                'surface_heat_stereo_submissions': metrics['stereo_submissions'],
                'surface_heat_swapchain_releases': metrics['releases']}

cc0 = {}
for base in ('female', 'male'):
    assert 'nineteen-target unskinned humanoid' in lines(f'release/cc0-{base}.log')[0]
    prefix = f'../vrm1-xr-attachment-20261127/combined-release/build/anatomical-native/{base}'
    cc0[base] = {
        'input_sha256': digest_file(work / prefix / 'fitted-unskinned.dsculpt'),
        'unskinned_native_sha256': digest_file(work / 'release' / f'cc0-{base}' / 'native-unskinned.dsculpt'),
        'bound_sha256': digest_file(work / 'release' / f'cc0-{base}' / 'bound.dsculpt'),
    }
validator = load('khronos.json')
issue = validator['reports'][0]['report']['issues']
assert issue['numErrors'] == 0 and issue['numWarnings'] == 8
schema = load('schemas.json')['files']
assert len(schema) == 1 and len(schema[0]['checks']) == 4 and not any(check['errors'] for check in schema[0]['checks'])
for path in ('receipt.py', 'verify-ui.py', 'wayland-heat.py', 'arc.log', 'wayland.log', 'wayland/client.log',
             'wayland/compositor.log', 'release-configure.log', 'release-build.log', 'cc0-build.log',
             'asan-configure.log', 'asan-build.log', 'khronos.cjs', 'khronos.log', 'schemas.log'):
    capture(path)

archive = docs / (name + '.tar.gz')
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed, \
        tarfile.open(fileobj=compressed, mode='w|') as tar:
    for path, payload in sorted(files.items()):
        item = tarfile.TarInfo(path)
        item.size = len(payload)
        item.mode = 0o644
        tar.addfile(item, io.BytesIO(payload))
receipt = {
    'revision': revision, 'canonical_domed_revision': canonical,
    'release_fltk': '/opt/fltk-vr/toolkit', 'asan_fltk': 'artifacts/sdk-20261126/toolkit-sanitize',
    'bitmap_runtime': '/opt/fltk-vr/bdf-runtime',
    'release_application_sha256': digest_file(work / 'release' / 'dome-sculpt'),
    'profiles': profiles, 'nested_wayland_assertions': len(wayland['checks']),
    'synthetic_openxr': xr, 'physical_headset_tested': False,
    'identical_release_asan_exports_and_projects_sha256': exports,
    'release_cc0_nineteen_target_regressions': cc0,
    'consumer': {'khronos': validator['version'], 'khronos_errors': 0,
                 'khronos_warnings': dict(Counter(m['code'] for m in issue['messages'] if m['severity'] == 1)),
                 'pinned_vrm_schema_checks': len(schema[0]['checks'])},
    'archive': {'path': archive.name, 'sha256': digest_file(archive),
                'members_sha256': {path: digest(payload) for path, payload in sorted(files.items())}},
}
(docs / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(archive, archive.stat().st_size)
