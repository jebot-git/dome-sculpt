from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
docs = repo / "docs" / "validation"
members = {}

def git(directory, *args):
    return subprocess.check_output(["git", *args], cwd=directory, text=True).strip()

def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def capture(path, name=None):
    raw = path.read_bytes()
    members[name or path.relative_to(work).as_posix()] = raw
    return raw

def load(path, name=None):
    return json.loads(capture(path, name))

def cases(path, expected, name=None):
    report = ET.fromstring(capture(path, name))
    items = report.findall(".//testcase")
    names = [item.attrib["name"] for item in items]
    assert len(names) == len(set(names)) == expected
    assert all(item.find(tag) is None for item in items for tag in ("failure", "error", "skipped"))
    return names

revision = git(work / "source", "rev-parse", "HEAD")
assert revision == "eea224999d5e542c20f1a383be893b68ffdc3b37"
assert not git(work / "source", "status", "--porcelain")
canonical = git(repo.parent / "DomeD", "rev-parse", "HEAD")
assert canonical == "acc2b70ae61dedec2a23727f67c60c0303d0f76f"
assert git(repo.parent / "DomeD", "ls-remote", "--exit-code", "origin",
           "refs/heads/main").split()[0] == canonical

profiles = {}
for profile in ("release", "asan"):
    directory = work / profile
    log = capture(directory / "bone.log").decode()
    assert len([line for line in log.splitlines() if line.startswith("PASS ")]) == 50
    for witness in ("A different selected object retires stale attachment authority",
                    "Controller Apply and ordered Save match the shared worker",
                    "includes the chosen avatar instance only",
                    "Controller attachment publishes one complete Undo and Redo"):
        assert witness in log
    for name in ("configure.log", "build.log", "verification-build.log", "registered.log"):
        capture(directory / name)
    profiles[profile] = {
        "focused_native_assertions": 49,
        "registered_cases": cases(directory / "registered.xml", 6),
        "executables_sha256": {
            name: sha(directory / name)
            for name in (("dome-sculpt",) if profile == "release" else ())
            + ("dome-sculpt-vrm1-source-export-test",)
        },
    }

directory = work / "release"
capture(directory / "registered-openxr.log")
openxr_cases = cases(directory / "registered-openxr.xml", 2)
fixtures = {}
for name in ("xr-before-attach.dsculpt", "xr-attached.dsculpt", "xr-attachment-editable.vrm"):
    fixtures[name] = sha(directory / "bone" / name)
    assert sha(work / "asan" / "bone" / name) == fixtures[name]
    capture(directory / "bone" / name)

xr = {}
for label, path, renderer in (("software_gl", "release/vrm1-attachment-xr", "llvmpipe"),
                              ("intel_arc_a770", "xr-arc", "A770")):
    directory = work / path
    summary = load(directory / "report.json")
    assert len(summary["checks"]) == 18 and all(item["passed"] for item in summary["checks"])
    assert summary["physical_headset"] is False
    scenarios = {}
    for scenario in ("accept", "cancel", "focus", "tracking"):
        metrics = load(directory / f"{scenario}.json")
        capture(directory / f"{scenario}.log")
        assert renderer in metrics["gl_renderer"]
        assert metrics["acquires"] == metrics["image_waits"] == metrics["releases"] > 0
        assert metrics["stereo_submissions"] > 0
        panel = metrics["attachment_palette_pixels"]
        for eye in ("0", "1"):
            assert all(panel[frame][eye] > panel["58"][eye] + 200 for frame in ("34", "46"))
        if scenario == "focus":
            assert metrics["focus_losses"] == metrics["focus_regains"] == 1
        if scenario == "tracking":
            assert metrics["attachment_tracking_loss"] and metrics["tracking_losses"] > 0
        scene = directory / f"{scenario}.dsculpt"
        expected = "xr-attached.dsculpt" if scenario == "accept" else "xr-before-attach.dsculpt"
        assert sha(scene) == fixtures[expected]
        scenarios[scenario] = {
            "renderer": metrics["gl_renderer"],
            "balanced_acquires_waits_releases": metrics["acquires"],
            "stereo_submissions": metrics["stereo_submissions"],
            "panel_pixels_by_frame_and_eye": panel,
            "scene_sha256": fixtures[expected],
            "captures_sha256": {image.name: sha(image) for image in
                                 sorted(directory.glob(f"{scenario}.json.*.ppm"))},
        }
    xr[label] = {"assertions": len(summary["checks"]), "scenarios": scenarios}

wayland = load(work / "release-wayland/report.json")
assert len(wayland["checks"]) == 8 and all(item["passed"] for item in wayland["checks"])
assert sha(work / "release-wayland/attached.dsculpt") == sha(work / "release/bone/default-bone.dsculpt")
xr_export_log = capture(work / "xr-export-arc.log").decode()
assert len([line for line in xr_export_log.splitlines() if line.startswith("PASS ")]) == 6
xr_export = load(work / "xr-export-arc/runtime.json")
assert "A770" in xr_export["gl_renderer"] and xr_export["overlay"]
assert sha(work / "xr-export-arc/screen-export.vrm") == fixtures["xr-attachment-editable.vrm"]
assert sha(work / "xr-export-arc/final.dsculpt") == fixtures["xr-attached.dsculpt"]

issues = load(work / "khronos.json")["reports"][0]["report"]["issues"]
original = repo / "artifacts/vrm1-bone-accessory-20261127/khronos.json"
source_issues = next(item["report"]["issues"] for item in load(
    original, "source-only-khronos.json")["reports"] if item["name"] == "head-source-only.vrm")
def warnings(report):
    return Counter((item["code"], item["message"]) for item in report["messages"]
                   if item["severity"] == 1)
assert issues["numErrors"] == 0 and issues["numWarnings"] == source_issues["numWarnings"] == 7
assert warnings(issues) == warnings(source_issues)
schemas = load(work / "schemas.json")["files"][0]["checks"]
assert len(schemas) == 5 and all(not check["errors"] for check in schemas)

older = repo / "artifacts/portable-mtoon-bake-20261127/combined-release"
baseline = load(older / "status.json", "baseline-full-release/status.json")
assert baseline["candidate"] == "662d889da2b3a56e36f2f58f5280a624ae798906"
assert baseline["terminal"] and baseline["exit"] == 0
assert baseline["registered"] == 1366
assert baseline["totals"] == {"pass": 1366, "fail": 0, "skip": 0}
assert sha(older / "full.xml") == baseline["junit_sha256"]
cases(older / "full.xml", 1366, "baseline-full-release/full.xml")
capture(older / "ctest.log", "baseline-full-release/ctest.log")

for name in ("receipt.py", "xr-arc.log", "release-wayland.log", "release-wayland/compositor.log",
             "ui.py", "wayland-bone.py", "xr-export.py", "khronos.cjs", "khronos.log",
             "schemas.log", "release/color-metric-ctest.log", "xr-arc-color-metric.log",
             "xr-arc-color-metric/accept.json", "release/vrm1-attachment-color-metric/accept.json"):
    capture(work / name)
for name in ("tests/vrm1-attachment-xr.py", "tests/xr_runtime.cpp"):
    capture(work / "source" / name, name)

bundle = docs / "vrm1-xr-attachment-20261127.tar.gz"
with bundle.open("wb") as output, gzip.GzipFile(filename="", fileobj=output, mode="wb",
                                                mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as archive:
        for name, contents in sorted(members.items()):
            entry = tarfile.TarInfo(name)
            entry.size = len(contents)
            archive.addfile(entry, io.BytesIO(contents))
receipt = {
    "revision": revision,
    "canonical_domed": canonical,
    "release_fltk": "/opt/fltk-vr/toolkit",
    "sanitized_fltk": "artifacts/sdk-20261126/toolkit-sanitize",
    "bitmap_runtime": "/opt/fltk-vr/bdf-runtime",
    "profiles": profiles,
    "registered_software_openxr_cases": openxr_cases,
    "synthetic_openxr": xr,
    "nested_domed_wayland_assertions": len(wayland["checks"]),
    "arc_controller_export_assertions": 5,
    "matching_release_and_sanitizer_fixtures": fixtures,
    "gltf_validator": {"errors": 0, "warnings": 7, "warnings_match_source_only": True},
    "pinned_vrm1_mtoon_schema_checks": len(schemas),
    "earlier_full_software_release": {name: baseline[name] for name in
                                     ("candidate", "totals", "junit_sha256")},
    "physical_headset_tested": False,
    "archive": {"file": bundle.name, "sha256": sha(bundle),
                "members_sha256": {name: hashlib.sha256(contents).hexdigest()
                                   for name, contents in sorted(members.items())}},
}
(docs / "vrm1-xr-attachment-20261127.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Verified {len(members)} authorities and wrote {bundle.name}")
