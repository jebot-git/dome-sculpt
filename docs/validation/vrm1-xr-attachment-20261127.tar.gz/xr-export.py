from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile

work=Path(__file__).resolve().parent
cancel=len(sys.argv)>2 and sys.argv[2]=='cancel'
out=work/('xr-export-'+sys.argv[1]+('-cancel' if cancel else ''))
out.mkdir(exist_ok=True)
app=work/'release'/'dome-sculpt'
native=work/'release'/'bone'
gate=work.parent/'current-integrated-full-release-20261127'/'build'/'libdome-sculpt-export-cancel-gate.so'
binary=(work/'release'/'vrm1-attachment-xr'/'accept.dsculpt').read_bytes()
reference=(native/'xr-attachment-editable.vrm').read_bytes()

def check(passed,label):
    print(('PASS ' if passed else 'FAIL ')+label,flush=True)
    assert passed,label

with tempfile.TemporaryDirectory() as directory:
    tmp=Path(directory)
    source=tmp/'sample.dsculpt'
    source.write_bytes(binary)
    manifest=tmp/'runtime.json'
    manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':
                    {'library_path':str(work/'release'/'libdome-sculpt-test-runtime.so')}}))
    gate_files=tmp/'gate'
    gate_files.mkdir()
    target=source.with_suffix('.vrm')
    if cancel:target.write_bytes(b'Previous Editable Avatar VRM')
    report=out/'runtime.json'
    env=dict(os.environ,HOME=directory,XR_RUNTIME_JSON=str(manifest),DOME_XR_FIXTURE_EDITABLE_AVATAR='cancel' if cancel else '512',
        DOME_XR_FIXTURE_FILES='1',DOME_XR_FIXTURE_REPORT=str(report),DOME_TEST_EXPORT_OUTPUT=str(target),
        DOME_TEST_EXPORT_GATE_DIR=str(gate_files),LD_PRELOAD=str(gate),LP_NUM_THREADS='2')
    for kind in ['config','state','data','cache','runtime']:
        path=tmp/kind
        path.mkdir(mode=0o700)
        env['XDG_'+kind.upper()+('_DIR' if kind=='runtime' else '_HOME')]=str(path)
    if sys.argv[1]=='software':
        env['LIBGL_ALWAYS_SOFTWARE']='1'
    elif sys.argv[1]=='arc':
        env.update(DRI_PRIME='pci-0000_03_00_0',EGL_PLATFORM='surfaceless',MESA_SHADER_CACHE_DISABLE='1')
    else:
        raise ValueError(sys.argv[1])
    with (out/'app.log').open('w') as log:
        result=subprocess.run([app,'--xr','--open',source,'--frames','3000','--save',out/'final.dsculpt'],
                              env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    info=json.loads(report.read_text())
    check(result.returncode==0 and (gate_files/'entered').is_file() and (gate_files/'release').is_file(),
          'Controller reaches the durable output boundary before cancelling the editable export' if cancel else
          'Controller selects the Editable Avatar VRM 512 slot and the actual durable export completes')
    check(info['acquires']==info['image_waits']==info['releases'] and info['acquires']>0 and
          all(info.get('editable_avatar_images',{}).get('13',{}).get(eye,0)>1000 for eye in ('0','1')),
          'Actual synthetic OpenXR presents both eyes on the Files page with balanced swapchain ownership')
    check(('Arc(tm) A770' if sys.argv[1]=='arc' else 'llvmpipe') in info['gl_renderer'],
          'The intended GPU or software renderer owns both stereo views')
    output=target.read_bytes()
    (out/'screen-export.vrm').write_bytes(output)
    check(output==(b'Previous Editable Avatar VRM' if cancel else reference) and not list(tmp.glob('*.tmp-*')),
          'Joystick Cancel preserves the prior bytes and cleans temporary output' if cancel else
          'Joystick export matches the independent Editable VRM1 fixture byte for byte')
    check((out/'final.dsculpt').read_bytes()==binary and source.read_bytes()==binary,
          'Joystick Save and ordered close preserve the exact selected accessory project')
print('PASS five native OpenXR accessory export checks')
