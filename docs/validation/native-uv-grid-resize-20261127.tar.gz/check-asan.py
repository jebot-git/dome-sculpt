from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shlex
import subprocess

work = Path(__file__).resolve().parent
repo = work.parent.parent
prior = work.parent / 'retopology-portable-mtoon-20261127/asan'
baseline = work.parent / 'texture-set-mtoon-resize-20261127/asan/libdome-sculpt-core.a'
out = work / 'asan'
out.mkdir(exist_ok=True)
target = 'dome-sculpt-native-paint-resolution-test'
commands = subprocess.check_output(['ninja', '-C', prior, '-t', 'commands', target], text=True).splitlines()
bwrap = ['bwrap', '--die-with-parent', '--unshare-all', '--ro-bind', '/', '/',
         '--bind', out, out, '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp', '--tmpfs', '/run/user']
source = [part for name in ('src','include','tests') for part in
          ('--ro-bind', work / 'frozen' / name, repo / name)]

def compile(name):
    command = shlex.split(next(line for line in commands if line.endswith('/' + name)))
    assert '-fsanitize=address,undefined' in command
    obj = out / (name + '.o')
    command[command.index('-o') + 1] = str(obj)
    if '-MF' in command:
        command[command.index('-MF') + 1] = str(obj.with_suffix('.d'))
    with (out / (name + '.build.log')).open('w') as log:
        subprocess.run([*bwrap, *source, *command], cwd=prior, stdout=log, stderr=subprocess.STDOUT, check=True)
    return obj

with ThreadPoolExecutor(max_workers=3) as workers:
    objects = list(workers.map(compile, ('paint.cpp','scene.cpp','material-bindings.cpp','polygon-scene.cpp','native-paint-sampling.cpp','texture-set-resample.cpp','native-paint-resolution.cpp')))
archive = out / baseline.name
subprocess.run(['cp', '--reflink=always', baseline, archive], check=True)
subprocess.run(['ar', 'rs', archive, *objects[:-1]], check=True)
link = shlex.split(commands[-1])[2:-2]
binary = out / target
link[link.index('-o') + 1] = str(binary)
link[link.index(archive.name)] = str(archive)
link[link.index(next(term for term in link if term.endswith('/' + objects[-1].name)))] = str(objects[-1])
link = [term for term in link if not term.startswith('-Wl,--dependency-file=')]
subprocess.run(link, cwd=prior, check=True)
sdk = repo / 'artifacts/sdk-20261126/toolkit-sanitize'
env = {'PATH': '/usr/bin:/bin', 'HOME': '/tmp', 'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1',
       'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1',
       'LD_LIBRARY_PATH': f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
runtime = bwrap + ['--clearenv'] + [part for k,v in env.items() for part in ('--setenv',k,v)]
for name in ('retained','baked','painted'):
    with (out / (name + '.log')).open('w') as log:
        subprocess.run([*runtime, binary, name, out / name], cwd=out, stdout=log, stderr=subprocess.STDOUT,
                       check=True, timeout=300)
