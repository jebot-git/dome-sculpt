import json
import math
from pathlib import Path
import struct

work = Path(__file__).resolve().parent
fixture = work / 'retained-v2'
proof = {}
for name in ('resized-standard.glb','resized-editable.glb','portable.glb'):
    raw = (fixture / name).read_bytes()
    length, = struct.unpack_from('<I', raw, 12)
    doc = json.loads(raw[20:20+length])
    binary = memoryview(raw)[28+length:]
    primitive, = doc['meshes'][0]['primitives']
    material, = doc['materials']
    pbr = material['pbrMetallicRoughness']
    attrs = primitive['attributes']

    def accessor(index, fmt, shape):
        a = doc['accessors'][index]
        v = doc['bufferViews'][a['bufferView']]
        start = v.get('byteOffset',0) + a.get('byteOffset',0)
        assert a['type'] == shape and a['componentType'] == 5126
        stride = v.get('byteStride',struct.calcsize(fmt))
        return [struct.unpack_from(fmt, binary, start+i*stride) for i in range(a['count'])]

    display = accessor(attrs['TEXCOORD_0'], '<2f', 'VEC2')
    paint = accessor(attrs['TEXCOORD_1'], '<2f', 'VEC2')
    tangent = accessor(attrs['TANGENT'], '<4f', 'VEC4')
    assert len(display)==len(paint)==len(tangent)==4
    for d, p in zip(display, paint):
        assert all(abs((.5+.6*(v-.5))-w)<1e-7 for v,w in zip(p,d))
    assert all(math.isclose(math.hypot(*t[:3]),1,abs_tol=1e-6) and abs(t[3])==1 for t in tangent)
    assert len(primitive['targets'])==1 and 'POSITION' in primitive['targets'][0]
    strength = material['extensions']['KHR_materials_emissive_strength']['emissiveStrength']
    assert abs(strength-2.9)<1e-6
    images = {}
    for role, info in {'base': pbr['baseColorTexture'], 'metal_rough': pbr['metallicRoughnessTexture'],
                       'occlusion': material['occlusionTexture'], 'normal': material['normalTexture'],
                       'emission': material['emissiveTexture']}.items():
        assert info['texCoord']==1
        image = doc['images'][doc['textures'][info['index']]['source']]
        start = doc['bufferViews'][image['bufferView']].get('byteOffset',0)
        assert image['mimeType']=='image/png' and binary[start+12:start+16]==b'IHDR'
        images[role] = struct.unpack_from('>II',binary,start+16)
    assert set(images.values())=={(256,256)}
    proof[name] = {'display_uv':display,'paint_uv':paint,'tangents':tangent,'images':images,'emissive_strength':strength}
assert len({json.dumps(layout,sort_keys=True) for layout in proof.values()})==1
(work/'portable-attributes.json').write_text(json.dumps(proof,indent=2)+'\n')
