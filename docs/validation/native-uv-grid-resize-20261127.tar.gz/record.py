from hashlib import file_digest, sha256
from pathlib import Path
import gzip
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
previous = 'e0b0b115a9605cb2a2a262bb91f63989f3333861'

def git(path, *args):
    return subprocess.check_output(['git', '-C', path, *args], text=True).strip()

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()

def load(path):
    return json.loads((work / path).read_text())

product = git(repo, 'rev-parse', 'HEAD')
assert git(repo, 'rev-parse', 'HEAD^') == previous
patch = subprocess.check_output(['git', 'diff', '--binary', previous, product], cwd=repo)
assert sha256(patch).hexdigest() == digest(work / 'source-v2.patch')
for path in git(repo, 'diff', '--name-only', previous, product).splitlines():
    assert digest(repo / path) == digest(work / 'frozen-v2' / path)
    if path.startswith('src/'):
        assert digest(work / 'frozen-v2' / path) == digest(work / 'frozen' / path)
domed = git(repo.parent / 'DomeD', 'rev-parse', 'HEAD')
assert domed == git(repo.parent / 'DomeD', 'ls-remote', 'origin', 'refs/heads/main').split()[0]

release = []
for name, count in [('native-uv-resize',19),('native-uv-bake-checks',4)]:
    cases = list(ET.parse(work / f'release/{name}.xml').getroot().iter('testcase'))
    assert len(cases) == count and all(case.find('failure') is None and case.find('skipped') is None for case in cases)
    release.extend(case.attrib['name'] for case in cases)
assert len(set(release)) == 23 and 'native-retained-paint-resolution' in release
assert 'REFUSED unchanged: Resolution editing needs an actual writable native grid' in (work/'baseline-old.log').read_text()
assert 'PASS retained UV resize 256 pixels' in (work/'baseline-new.log').read_text()
measurement = re.search(r'PASS retained UV resize 1024 pixels, (\d+) work, (\d+) bytes',
                        (work/'retained1024.log').read_text())
assert measurement and 'REFUSED unchanged:' in (work/'retained1024-default-budget.log').read_text()
native = (work/'retained-v2.log').read_text()
asan = {}
for mode, count in [('retained',24),('baked',11),('painted',42)]:
    run = (work / f'asan/{mode}.log').read_text()
    assert len(re.findall(r'^PASS ', run, re.M)) == count and not re.search(r'FAIL|AddressSanitizer|runtime error:', run)
    if mode == 'retained':
        assert native == run
    asan[mode] = count

hashes = {}
for name in ('baked128.dsculpt','baked256.dsculpt','unbaked256.dsculpt','second-uv.dsculpt',
             'resized-standard.glb','resized-editable.glb'):
    values = {digest(work / folder / name) for folder in
              ('retained-v2','release/native-retained-paint-resolution','asan/retained')}
    assert len(values) == 1
    hashes[name] = values.pop()
for name in ('wayland-resize/painted256.dsculpt','field-xr-paced-arc/final.dsculpt',
             'field-xr-paced-software/final.dsculpt'):
    assert digest(work / name) == hashes['baked256.dsculpt']

def verified_controls(directory, log):
    controls = load(f'{directory}/report.json')
    assert controls['complete'] and len(controls['checks']) == 12
    labels = [item if isinstance(item, str) else item['check'] for item in controls['checks']]
    assert labels == re.findall(r'^PASS (.+)$', (work / log).read_text(), re.M)
    return controls

wayland = verified_controls('wayland-resize','bind-wayland.log')
xr = {}
visual = {}
for mode, renderer in [('arc','Arc(tm) A770'), ('software','llvmpipe')]:
    directory = f'field-xr-paced-{mode}'
    reports = verified_controls(directory, f'{directory}.log')
    assert renderer in reports['renderer']
    xr[mode] = reports
    render = (work / f'retained-v2/render-portable-{mode}.log').read_text()
    assert renderer in render and 'PORTABLE_BAKE pixels=10368 maximum=0 rms=0' in render
    assert 'PASS package-free Bake and explicit Mikk tangent replay' in render
    visual[mode] = {'renderer':renderer, 'visible_pixels':10368, 'maximum_rgba8_error':0}

gltf = load('khronos.json')
attributes = load('portable-attributes.json')
assert len(gltf['results']) == len(attributes) == 3 and all(
    row['issues']['numErrors']==row['issues']['numWarnings']==0 for row in gltf['results'])

names = ['record.py','source-v2.patch','build.sh','build-v2.sh','check-release-v2.sh','check-bake.sh',
         'release-build.log','release-v2-build.log','regression-build.log','release-tests.log',
         'bake-build.log','bake-tests.log','release/native-uv-resize.xml','release/native-uv-bake-checks.xml',
         'retained-v1.log','retained-v2.log','retained1024-default-budget.log','retained1024.log',
         'check-asan.py','check-asan-v2.py','asan/retained-v1.log','baseline-probe.cpp',
         'check-baseline.py','baseline-old.log','baseline-new.log','run-wayland.py','wayland-resize.py',
         'wayland-resize/report.json','bind-wayland.log','field-xr-paced.py','run-field-xr-paced.py',
         'render-portable.cpp','render-portable.py','strip-editable-package.py','khronos.cjs','khronos.log',
         'khronos.json','inspect-portable.py','portable-attributes.json']
names.extend(f'asan/{mode}.log' for mode in asan)
for mode in xr:
    slot=f'field-xr-paced-{mode}'
    names.extend((f'{slot}.log', f'{slot}/report.json', f'{slot}/runtime.json',
                  f'retained-v2/render-portable-{mode}.log'))
folder = repo / 'docs/validation'
name = 'native-uv-grid-resize-20261127'
bundle = folder / (name + '.tar.gz')
members = {name:digest(work / name) for name in sorted(names)}
with bundle.open('wb') as output, gzip.GzipFile(mode='wb', filename='', fileobj=output, mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as archive:
        for relative in members:
            path = work / relative
            info = archive.gettarinfo(str(path), arcname=relative)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with path.open('rb') as stream:
                archive.addfile(info,stream)
with tarfile.open(bundle) as archive:
    assert members == {entry.name:sha256(archive.extractfile(entry).read()).hexdigest() for entry in archive}
report = dict(product=product, previous_main=previous, canonical_domed=domed, backend='CPU',
              release_tests=sorted(release), sanitizer_checks=asan, native_fixture_checks=24,
              wayland=wayland, synthetic_controller=xr, visuals=visual, portable_attributes=attributes, khronos=gltf,
              native_budget_1024={'measured_work':int(measurement[1]), 'accounted_peak_bytes':int(measurement[2])},
              physical_headset=False, matching_native_and_glb_sha256=hashes,
              release_application_sha256=digest(work/'release/dome-sculpt'),
              archive_sha256=digest(bundle), archive_members_sha256=members,
              source_patch_sha256=sha256(patch).hexdigest())
(folder/(name+'.json')).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(product, 'Release23, ASan/UBSan3, Wayland12, synthetic OpenXR12+12, pixel-identical GLB, Khronos3')
