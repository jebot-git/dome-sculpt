#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$work/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/release"
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$work/frozen-v2/CMakeLists.txt" "$repo/CMakeLists.txt" --ro-bind "$work/frozen-v2/src" "$repo/src" --ro-bind "$work/frozen-v2/include" "$repo/include" --ro-bind "$work/frozen-v2/tests" "$repo/tests" --bind "$work/release" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${sandbox[@]}" cmake --build "$seed" --parallel 3 --target dome-sculpt-source-writable-normal-bake-test dome-sculpt-native-paint-sampling-transitions-test > "$work/bake-build.log" 2>&1
"${sandbox[@]}" ctest --test-dir "$seed" --parallel 3 -R '^(native-writable-bake-recipient|native-key-writable-bake-recipient|legacy-native-key-bake-conversion|native-paint-sampling-transitions)$' --output-on-failure --output-junit "$seed/native-uv-bake-checks.xml" > "$work/bake-tests.log" 2>&1
