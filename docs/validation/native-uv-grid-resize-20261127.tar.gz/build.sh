#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$work/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/release"
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$work/frozen/CMakeLists.txt" "$repo/CMakeLists.txt" --ro-bind "$work/frozen/src" "$repo/src" --ro-bind "$work/frozen/include" "$repo/include" --ro-bind "$work/frozen/tests" "$repo/tests" --bind "$work/release" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${sandbox[@]}" cmake --build "$seed" --parallel 5 --target dome-sculpt dome-sculpt-native-paint-resolution-test dome-sculpt-texture-set-resolution-test > "$work/release-build.log" 2>&1
