#include "dome/texture-set-resolution.hpp"
#include "texture-set-resample.hpp"
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc, char **argv) try {
  if (argc != 2 && argc != 3)
    return 2;
  auto scene = dome::Scene::load(argv[1]);
  const auto original = scene.encode();
  const auto prior = scene.active().painted;
  const uint32_t size = argc == 3 ? uint32_t(std::stoul(argv[2])) : 256;
  try {
    const auto report = dome::resample_native_texture_grid(scene, scene.active().id, {size}, dome::detail::native_texture_grid_limits());
    if (!report.changed || scene.active().painted->resolution() != size ||
        prior->mesh_owner() != scene.active().painted->mesh_owner() ||
        prior->paint_sampling_attachment() != scene.active().painted->paint_sampling_attachment())
      return 2;
    std::cout << "PASS retained UV resize " << size << " pixels, " << report.work
              << " work, " << report.peak_bytes << " bytes\n";
  } catch (const std::exception &error) {
    if (scene.encode() != original)
      return 2;
    std::cout << "REFUSED unchanged: " << error.what() << '\n';
    return 1;
  }
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 2;
}
