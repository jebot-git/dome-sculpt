from pathlib import Path
import os,json,shlex,hashlib,subprocess,fcntl,time,signal
root=Path('/home/blux/de-xr/dome-sculpt');base=root/'artifacts/artist-advanced-normal-compile-20261117';out=Path(__file__).parent;links=base/'links-v5';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
closure=json.loads((links/'compile-closure.json').read_text());pins=closure['input_pins'];pins.update({str(links/'compile-closure.json'):sha(links/'compile-closure.json'),str(links/'archive-members.json'):sha(links/'archive-members.json')})
prior=json.loads((root/'artifacts/artist-public-snapshot-compile-20261117/compile-inputs.json').read_text())
for p in ['/usr/bin/cc','/usr/bin/gcc','/usr/bin/c++','/usr/bin/ar','/usr/bin/ranlib','/usr/bin/ld','/usr/bin/ld.bfd','/usr/bin/ninja-build','/usr/bin/ninja','/usr/libexec/gcc/x86_64-redhat-linux/16/cc1plus','/usr/libexec/gcc/x86_64-redhat-linux/16/cc1','/usr/libexec/gcc/x86_64-redhat-linux/16/collect2','/usr/bin/as']:
 assert sha(p)==prior[p],p;pins[p]=prior[p]
for c in json.loads((links/'status.json').read_text()):
 assert c['exit_code']==0;p=Path(c['argv'][c['argv'].index('-o')+1]);assert sha(p)==c['elf_sha256'];pins[str(p)]=c['elf_sha256']
 for dep in shlex.split(Path(str(p)+'.link.d').read_text().replace('\\\n',' ').splitlines()[0].split(':',1)[1]):
  q=Path(dep);q=q if q.is_absolute() else links/q;h=sha(q);assert str(q) not in pins or pins[str(q)]==h;pins[str(q)]=h
(out/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
s={'owner_pid':os.getpid(),'phase':'preflight','terminal':False,'steps':[],'rss_limit':4*1024**3,'per_command_seconds':900,'graphics':False,'source_commit':'3a308c368716a68d94cc3804d522a76d70f2a5f4'}
def record(): (out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def verify():
 drift=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h];assert not drift,drift
record();verify();lock=open('/tmp/dome-sculpt-arc-device.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);s['lease_acquired']=time.time();record()
env=os.environ.copy()
for k in ['DISPLAY','WAYLAND_DISPLAY','DBUS_SESSION_BUS_ADDRESS','LD_PRELOAD']:env.pop(k,None)
env.update(LD_LIBRARY_PATH=str(root/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',XR_RUNTIME_JSON='/nonexistent/blocked-headset.json',XDG_CACHE_HOME=str(out/'cache'),XDG_CONFIG_HOME=str(out/'config'),XDG_DATA_HOME=str(out/'data'))
def identity(pid):
 try:
  t=Path('/proc')/str(pid);v=(t/'stat').read_text().rsplit(')',1)[1].split();rss=peak=0
  for line in (t/'status').read_text().splitlines():
   if line.startswith('VmRSS:'):rss=int(line.split()[1])*1024
   if line.startswith('VmPeak:'):peak=int(line.split()[1])*1024
  return {'pid':pid,'ppid':int(v[1]),'pgrp':int(v[2]),'start':v[19],'rss':rss,'vmpeak':peak}
 except (OSError,ValueError):return None
try:
 # ldd is inside the common lease and its actual providers are retained.
 for name in ['source-advanced-normal-bake','source-prepared-normal-bake','source-artist-normal-bake']:
  verify();cmd=[str(links/name),str(out/(name+'-outputs'))];s['phase']=name
  with (out/(name+'.ldd')).open('w') as f:subprocess.run(['/usr/bin/ldd',cmd[0]],stdout=f,stderr=subprocess.STDOUT,env=env,check=True,timeout=60)
  start=time.monotonic();peak=vmpeak=0;seen={};guard=None
  with (out/(name+'.log')).open('w') as f:
   p=subprocess.Popen(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);own=identity(p.pid);assert own and own['pgrp']==p.pid;seen[p.pid]=own;s['child_pid']=p.pid;s['child_start']=own['start'];record()
   while p.poll() is None:
    allp=[x for d in Path('/proc').iterdir() if d.name.isdigit() and (x:=identity(int(d.name)))];owned={p.pid}
    while True:
     more={x['pid'] for x in allp if x['ppid'] in owned};previous=len(owned);owned|=more
     if len(owned)==previous:break
    live=[x for x in allp if x['pid'] in owned];peak=max(peak,sum(x['rss'] for x in live));vmpeak=max(vmpeak,sum(x['vmpeak'] for x in live))
    for x in live:seen[x['pid']]=x
    if peak>s['rss_limit'] or time.monotonic()-start>900:
     guard='rss' if peak>s['rss_limit'] else 'wall';current=identity(p.pid)
     if current and current['start']==own['start'] and current['pgrp']==p.pid:os.killpg(p.pid,signal.SIGTERM)
     try:p.wait(timeout=5)
     except subprocess.TimeoutExpired:
      current=identity(p.pid)
      if current and current['start']==own['start'] and current['pgrp']==p.pid:os.killpg(p.pid,signal.SIGKILL)
     break
    time.sleep(.05)
   code=p.wait()
  step={'name':name,'argv':cmd,'cwd':str(out),'exit_code':code,'elapsed':time.monotonic()-start,'peak_aggregate_rss':peak,'peak_aggregate_vmpeak':vmpeak,'guard':guard,'owned':list(seen.values())};s['steps'].append(step);record();verify()
  if code or guard:raise RuntimeError(str(step))
 s['exit_code']=0
except BaseException as e:s['exit_code']=1;s['error']=str(e)
finally:
 s['input_drift']=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h];s['terminal']=True;s['lease_released']=time.time();s['child_pid']=None;record();fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
raise SystemExit(s['exit_code'])
