import json,os,subprocess,resource,time,hashlib
from pathlib import Path
p=Path(__file__).parent
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
r=[]
for i,c in enumerate(json.loads((p/'plan.json').read_text())):
 assert hashlib.sha256(Path(c['source']).read_bytes()).hexdigest()==c['source_sha256']
 with (p/(str(i)+'.log')).open('w') as log:
  x=subprocess.run(c['argv'],cwd=c['cwd'],stdout=log,stderr=subprocess.STDOUT,timeout=900)
 r.append(dict(c,exit_code=x.returncode))
 (p/'status.json').write_text(json.dumps(r,indent=2)+'\n')
 if x.returncode:raise SystemExit(x.returncode)
