from pathlib import Path
import sys,json,shlex,hashlib,subprocess,resource
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
b=Path(__file__).parent;version,output,commit=sys.argv[1:];out=b/output;out.mkdir();old=json.loads((b/'links-chain-v1/compile-closure.json').read_text());new=json.loads((b/version/'status.json').read_text());assert len(new)==1 and new[0]['exit_code']==0
c=new[0];a=c['argv'];obj=a[a.index('-o')+1];dep=a[a.index('-MF')+1];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();ds=shlex.split(Path(dep).read_text().replace('\\\n',' ').split(':',1)[1]);entry={'source':c['source'],'object':obj,'object_sha256':sha(obj),'depfile':dep,'depfile_sha256':sha(dep),'dependencies':[{'path':q,'sha256':sha(q)} for q in ds],'argv':a,'cwd':c['cwd']};old_owner_pins={q for x in old['fresh_owners'] for q in [x['object'],x['depfile'],*[d['path'] for d in x['dependencies']]]};retained_pins={q:h for q,h in old['input_pins'].items() if q not in old_owner_pins}
old['fresh_owners']=[entry if x['source']==c['source'] else x for x in old['fresh_owners']];pins=retained_pins
for x in old['fresh_owners']:
 for item in x['dependencies']:
  q,h=item['path'],item['sha256'];assert q not in pins or pins[q]==h;pins[q]=h
 pins[x['object']]=x['object_sha256'];pins[x['depfile']]=x['depfile_sha256']
for q,h in pins.items():assert sha(q)==h,q
old['input_pins']=pins;(out/'compile-closure.json').write_text(json.dumps(old,indent=2)+'\n');(out/'archive-members.json').write_bytes((b/'links-chain-v1/archive-members.json').read_bytes());commands=json.loads((b/'links-chain-v1/status.json').read_text());c=commands[0];a=c['argv'];a[a.index('-o')+1]=str(out/'source-advanced-normal-bake');a=[x.replace(str(b/'v10/source-advanced-normal-bake.cpp.o'),obj) for x in a];a=[x.replace(str(b/'links-chain-v1/source-advanced-normal-bake')+'.link.d',str(out/'source-advanced-normal-bake')+'.link.d') for x in a];c['argv']=a;c['cwd']=str(out)
with (out/'source-advanced-normal-bake.log').open('w') as log:p=subprocess.run(a,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=900)
c['exit_code']=p.returncode
if p.returncode:raise SystemExit(p.returncode)
c['elf_sha256']=sha(out/'source-advanced-normal-bake');(out/'status.json').write_text(json.dumps(commands,indent=2)+'\n')
for q,h in pins.items():assert sha(q)==h,q
n=b/('native-'+output);n.mkdir();script=(b/'native-v2/run.py').read_text().replace("links=base/'links-v2'","links=base/"+repr(output)).replace("'source_commit':'102f0af4ec05560da340c9e51d415702c2f519de'","'source_commit':"+repr(commit));(n/'run.py').write_text(script);print(n/'run.py')
