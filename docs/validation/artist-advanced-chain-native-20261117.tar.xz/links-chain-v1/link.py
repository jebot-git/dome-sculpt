from pathlib import Path
import json,shlex,subprocess,hashlib,resource
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
root=Path('/home/blux/de-xr/dome-sculpt');src=root/'artifacts/artist-advanced-chain-budget-20261117';p=root/'artifacts/artist-advanced-normal-compile-20261117';out=Path(__file__).parent;build=root/'artifacts/native90-release-planning-20261115/release-090f00-20261117-owning'
sha=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest()
owners=[]
for d in sorted((build/'CMakeFiles/dome-sculpt-core.dir').rglob('*.d')):
 if 'source-bake-normal.hpp' in d.read_text():owners.append(str(d.relative_to(build)))
assert len(owners)==3,owners
pins={};entries=[]
def pin(q):
 q=Path(q);h=sha(q);assert str(q) not in pins or pins[str(q)]==h;pins[str(q)]=h;return h
for v in ['v10']:
 for c in json.loads((p/v/'status.json').read_text()):
  assert c['exit_code']==0 and sha(c['source'])==c['source_sha256'];a=c['argv'];o=Path(a[a.index('-o')+1]);d=Path(a[a.index('-MF')+1]);deps=shlex.split(d.read_text().replace('\\\n',' ').split(':',1)[1]);closed=[{'path':dep,'sha256':pin(dep)} for dep in deps]
  entries.append({'source':c['source'],'object':str(o),'object_sha256':pin(o),'depfile':str(d),'depfile_sha256':pin(d),'dependencies':closed,'argv':a,'cwd':c['cwd']})
core=build/'libdome-sculpt-core.a';pin(core);new=out/'libdome-sculpt-core.a';assert not new.exists();new.write_bytes(core.read_bytes())
replacements=[p/'v10'/n for n in ['bake.cpp.o','emission-bake-source.cpp.o','bake-authoring.cpp.o']]
subprocess.run(['/usr/bin/ar','rD',str(new),*[str(x) for x in replacements]],check=True,timeout=900)
subprocess.run(['/usr/bin/ranlib','-D',str(new)],check=True,timeout=900)
before=subprocess.check_output(['/usr/bin/ar','t',str(core)]).decode().splitlines();after=subprocess.check_output(['/usr/bin/ar','t',str(new)]).decode().splitlines();assert before==after and len(after)==193
changed=[];members=[]
for n in before:
 a=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(core),n])).hexdigest();b=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(new),n])).hexdigest();members.append({'name':n,'before_sha256':a,'after_sha256':b})
 if a!=b:changed.append(n)
assert set(changed)=={x.name for x in replacements},changed
(out/'archive-members.json').write_text(json.dumps({'provider':str(core),'provider_sha256':sha(core),'new':str(new),'new_sha256':pin(new),'count':len(after),'changed':changed,'members':members},indent=2)+'\n')
s=(build/'build.ninja').read_text();start=s.index('build dome-sculpt-source-prepared-normal-bake-test:');block=s[start:].split('\n\n',1)[0];libs=shlex.split(next(x.strip().split(' = ',1)[1] for x in block.splitlines() if x.strip().startswith('LINK_LIBRARIES = ')));commands=[]
for name in ['source-advanced-normal-bake','source-prepared-normal-bake','source-artist-normal-bake']:
 obj=p/'v10'/(name+'.cpp.o');elf=out/name;argv=['/usr/bin/c++','-O3','-DNDEBUG','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-Wl,--dependency-file='+str(elf)+'.link.d',str(obj),'-o',str(elf)]
 for lib in libs:
  q=new if lib=='libdome-sculpt-core.a' else build/lib if lib.endswith('.a') and '/' not in lib else lib;argv.append(str(q))
  if not str(q).startswith('-'):pin(q)
 commands.append({'argv':argv,'cwd':str(out)})
for c in commands:
 for q,h in pins.items():assert sha(q)==h,q
 elf=Path(c['argv'][c['argv'].index('-o')+1])
 with (out/(elf.name+'.log')).open('w') as f:x=subprocess.run(c['argv'],cwd=c['cwd'],stdout=f,stderr=subprocess.STDOUT,timeout=900)
 c['exit_code']=x.returncode
 if x.returncode==0:c['elf_sha256']=sha(elf)
 (out/'status.json').write_text(json.dumps(commands,indent=2)+'\n')
 if x.returncode:raise SystemExit(x.returncode)
for q,h in pins.items():assert sha(q)==h,q
(out/'compile-closure.json').write_text(json.dumps({'actual_provider_header_owners':owners,'fresh_owners':entries,'input_pins':pins},indent=2)+'\n')
print(json.dumps({'header_owners':owners,'fresh_compiled':len(entries),'fresh_input_pins':len(pins),'links':[x['exit_code'] for x in commands],'archive_changed':changed}))

(out/'compile-closure.json').write_text(json.dumps({'actual_provider_header_owners':owners,'fresh_owners':entries,'input_pins':pins},indent=2)+'\n')
