from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

home = Path(__file__).resolve().parent
artifacts = home.parent
repo = artifacts.parent
profile, mode = sys.argv[1:]
asan = profile == 'asan'
prior = artifacts/'writable-donor-current-validation-v2-20261126'/profile
joint = artifacts/'writable-donor-current-validation-v3-20261126'/profile
out = home/f'{profile}-{mode}'
out.mkdir(exist_ok=True)
trial = out/'build'
trial.mkdir(exist_ok=True)
sdk = (artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit'))
baseline = json.loads((prior/'status.json').read_text())
core = prior/'libdome-sculpt-core.a'
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
old_source = artifacts/'writable-donor-current-source-20261126'
fixture='dome-sculpt-source-writable-normal-bake-test'
env = os.environ.copy()
env['PKG_CONFIG_PATH'] = '/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig'

def sha(path):
    with Path(path).open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()

def first(log):
    return shlex.split(Path(log).read_text().splitlines()[0])

def invoke(cmd, log, cwd=trial, timeout=900):
    with (out/log).open('w') as stream:
        print(shlex.join(map(str,cmd)),file=stream,flush=True)
        return subprocess.run(cmd, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT, env=env, timeout=timeout).returncode

def compile_from(log):
    cmd = [word.replace(str(old_source),str(source)) for word in first(log)]
    obj = out/Path(cmd[cmd.index('-o')+1]).name
    cmd[cmd.index('-o')+1] = str(obj)
    cmd[cmd.index('-MF')+1] = str(obj)+'.d'
    assert not invoke(cmd,obj.with_suffix('.log').name)
    return obj

source = Path(os.environ.get('DOME_RECIPIENT_SOURCE', repo))
candidate = subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
assert sha(core)==baseline['core_sha256']
assert sha(prior/'libdome-sculpt-render.a')==baseline['render_sha256']
fixture_log = prior/'tests'/fixture
test_obj = compile_from(fixture_log/'source-writable-normal-bake.cpp.log')
linked_core = core
if mode == 'current':
    assert subprocess.check_output(['git','-C',source,'diff','--binary'])==(home/'source.patch').read_bytes()
    changed = set(subprocess.check_output(['git','-C',source,'diff','--name-only',baseline['candidate'],'--','src','include','assets','third_party'],text=True).splitlines())
    assert changed == {'src/bake-authoring.cpp'}, changed
    obj = compile_from(prior/'core/bake-authoring.cpp.log')
    linked_core = out/core.name
    shutil.copyfile(core,linked_core)
    assert not invoke(['ar','rs',linked_core,obj],'archive.log')
    assert subprocess.check_output(['ar','t',core])==subprocess.check_output(['ar','t',linked_core])
    assert hashlib.sha256(subprocess.check_output(['ar','p',linked_core,obj.name])).hexdigest()==sha(obj)
test_link = first(fixture_log/'link.log')
test_link = [str(test_obj) if w.endswith('/'+test_obj.name) else str(linked_core) if w==str(core) else w for w in test_link]
assert not invoke(test_link,'test-link.log')
runtime = ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',trial,trial,'--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--setenv','EGL_PLATFORM','surfaceless','--setenv','LIBGL_ALWAYS_SOFTWARE','1','--setenv','LP_NUM_THREADS','2','--setenv','LD_LIBRARY_PATH',f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
if asan:
    runtime.extend(['--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1','--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1'])
exit_code = invoke([*runtime,trial/fixture,'--recipient',trial/'canonical-writable-bake-recipient'],'recipient.log')
status = {'candidate':candidate,'profile':profile,'patch_sha256':sha(home/'source.patch'),'baseline':baseline['candidate'],'core_sha256':sha(linked_core),'fixture_sha256':sha(trial/fixture),'exit':exit_code,'log_sha256':sha(out/'recipient.log')}
if mode=='current' and exit_code==0:
    app_link = first(prior/'app-link.log')
    app_link = [str(linked_core) if w==str(core) else w for w in app_link]
    app = trial/'dome-sculpt'
    app_link[app_link.index('-o')+1] = str(app)
    assert not invoke(app_link,'app-link.log',support)
    status['app_sha256'] = sha(app)
    test_runtime=prior/'build/libdome-sculpt-test-runtime.so'
    (trial/test_runtime.name).symlink_to(test_runtime.resolve())
    status['runtime_sha256'] = sha(test_runtime)
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
raise SystemExit(exit_code)
