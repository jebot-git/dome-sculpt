#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/scene.hpp"
#include <algorithm>
#include <iostream>

int main(int argc,char **argv) try {
  if(argc!=4)return 2;
  auto scene=dome::Scene::load(argv[1]);
  const auto donor=std::find_if(scene.objects().begin(),scene.objects().end(),
      [](const auto &object){return object.name=="Colour and FLOAT projection donor";});
  if(donor==scene.objects().end())throw std::runtime_error("Recipient donor is missing");
  const auto source=donor->id;
  dome::ObjectBakeSettings settings;
  settings.corresponding_topology=true;
  settings.ao_samples=0;
  settings.padding=0;
  scene.active().bake_recipe=dome::capture_bake_recipe(scene,source,settings);
  scene.save(argv[2]);
  settings.prepare_normals=true;
  dome::bake_object(scene,source,settings);
  scene.save(argv[3]);
  return 0;
} catch(const std::exception &error) {
  std::cerr<<error.what()<<'\n';
  return 1;
}
