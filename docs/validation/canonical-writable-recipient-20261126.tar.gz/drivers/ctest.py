from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
from xml.etree import ElementTree

root=Path(__file__).resolve().parent
art=root.parent
profile=sys.argv[1]
strict=profile=='asan'
prior=art/'writable-donor-current-validation-v2-20261126'/profile
qualified=root/(profile+'-current')
output=root/(profile+'-regression')
output.mkdir(exist_ok=True)
build=output/'build'
source=root/'source'
sdk=art/'sdk-20261126/toolkit-sanitize' if strict else Path('/opt/fltk-vr/toolkit')
env={**os.environ,'PKG_CONFIG_PATH':'/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig'}
targets={
    'canonical-writable-bake-recipient':'dome-sculpt-source-writable-normal-bake-test',
    'bake':'dome-sculpt-bake-test',
    'bake-workflow':'dome-sculpt-bake-workflow-test',
    'mesh-processing':'dome-sculpt-mesh-processing-test',
    'source-artist-normal-bake':'dome-sculpt-source-artist-normal-bake-test',
    'source-prepared-normal-bake':'dome-sculpt-source-prepared-normal-bake-test',
    'texture-set-retained-bake-source':'dome-sculpt-texture-set-source-export-test',
    'texture-set-bake-recipe':'dome-sculpt-texture-set-bake-recipe-test',
    'bake-custom-cage':'dome-sculpt-bake-cage-test',
    'bake-projection-policy':'dome-sculpt-bake-projection-policy-test',
}
def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def invoke(cmd,log,**kwargs):
    with (output/log).open('w') as stream:
        print(shlex.join(map(str,cmd)),file=stream,flush=True)
        return subprocess.run(cmd,env=env,stdout=stream,stderr=subprocess.STDOUT,**kwargs).returncode

receipt=json.loads((qualified/'status.json').read_text())
assert receipt['patch_sha256']==sha(root/'source.patch')
assert subprocess.check_output(['git','-C',source,'diff','--binary'])==(root/'source.patch').read_bytes()
assert sha(qualified/'libdome-sculpt-core.a')==receipt['core_sha256']
assert receipt['exit']==0
opts=[]
if strict:
    opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
    opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
assert not invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',timeout=120)
for name,target in targets.items():
    if name=='canonical-writable-bake-recipient':
        exe=qualified/'build'/target
        assert sha(exe)==receipt['fixture_sha256']
        (build/target).symlink_to(exe)
    else:
        cmd=shlex.split((prior/'tests'/target/'link.log').read_text().splitlines()[0])
        cmd=[str(qualified/'libdome-sculpt-core.a') if w==str(prior/'libdome-sculpt-core.a') else w for w in cmd]
        cmd[cmd.index('-o')+1]=str(build/target)
        assert not invoke(cmd,name+'-link.log',cwd=prior/'build',timeout=180)
cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
     '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
     '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--setenv','EGL_PLATFORM','surfaceless',
     '--setenv','LIBGL_ALWAYS_SOFTWARE','1','--setenv','LP_NUM_THREADS','2',
     '--setenv','LD_LIBRARY_PATH',f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
if strict:
    cmd.extend(['--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
                '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1'])
report=build/'regressions.xml'
exit_code=invoke([*cmd,'ctest','--test-dir',build,'-V','-j2','--output-on-failure','--output-junit',report,
                  '-R','^('+'|'.join(targets)+')$'],'ctest.log',timeout=720)
cases={test.attrib['name']:test for test in ElementTree.parse(report).getroot().findall('.//testcase')}
assert set(cases)==set(targets),cases.keys()
failed=[test for test,entry in cases.items() if entry.find('failure') is not None or entry.find('skipped') is not None]
status={'candidate':receipt['candidate'],'patch_sha256':receipt['patch_sha256'],'invocation':os.environ.get('INVOCATION_ID'),
        'tests':list(cases),'failed':failed,'exit':exit_code,'ctest_sha256':sha(output/'ctest.log'),
        'binaries':{target:sha(build/target) for target in targets.values()}}
(output/'status.json').write_text(json.dumps(status,indent=2)+'\n')
raise SystemExit(exit_code or bool(failed))
