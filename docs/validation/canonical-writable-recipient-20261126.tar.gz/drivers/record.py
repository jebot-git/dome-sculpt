from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
name='canonical-writable-recipient-20261126'
dest=repo/'docs/validation'
archive=dest/(name+'.tar.gz')
candidate=subprocess.check_output(['git','-C',repo,'rev-parse','b40ce089'],text=True).strip()
def sha(p):
    with Path(p).open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()

patch=root/'source.patch'
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',candidate])==patch.read_bytes()
members={}
def include(prefix,*files):
    for path in files:
        assert path.is_file(),path
        key=prefix+'/'+path.name
        assert key not in members,key
        members[key]=path
def state(folder):
    return json.loads((folder/'status.json').read_text())

old_uv=root/'release-prior-control'
old_hdr=root/'release-prior'
controls={}
for label,folder,message in (
        ('display_uv',old_uv,'Bake takes coverage from the writable atlas'),
        ('float_normal_pass',old_hdr,'Invalid texture image')):
    result=state(folder)
    assert result['exit']==1 and 'FAIL '+message in (folder/'recipient.log').read_text()
    controls[label]=result
    include('prior/'+label,folder/'status.json',folder/'recipient.log',
            folder/'source-writable-normal-bake.cpp.log',folder/'test-link.log')

native={}
for profile in ('release','asan'):
    folder=root/(profile+'-current')
    result=state(folder)
    assert result['exit']==0 and result['patch_sha256']==sha(patch)
    data=(folder/'recipient.log').read_text()
    assert 'PASS 77 writable recipient checks' in data
    result['cases']={}
    for match in re.finditer(r'^WRITABLE_RECIPIENT (\S+) projected=(\d+) missed=(\d+) preserved=(\d+) rays=(\d+)$',data,re.MULTILINE):
        result['cases'][match[1]]=dict(zip(('projected','missed','preserved','rays'),map(int,match.groups()[1:])))
    assert len(result['cases'])==3
    run=root/(profile+'-regression')
    result['regression']=state(run)
    assert result['regression']['exit']==0 and not result['regression']['failed'] and len(result['regression']['tests'])==10
    assert result['regression']['patch_sha256']==sha(patch)
    native[profile]=result
    include(profile,folder/'status.json',folder/'recipient.log',folder/'app-link.log',folder/'archive.log',
            folder/'source-writable-normal-bake.cpp.log',folder/'bake-authoring.cpp.log',folder/'test-link.log')
    include(profile+'/ctest',run/'status.json',run/'configure.log',run/'ctest.log',run/'build/regressions.xml',
            *sorted(run.glob('*-link.log')))

projects={}
release=root/'release-current/build/canonical-writable-bake-recipient'
asan=root/'asan-current/build/canonical-writable-bake-recipient'
for path in sorted(release.glob('*.dsculpt')):
    projects[path.name]=sha(path)
    assert projects[path.name]==sha(asan/path.name)
assert len(projects)==9
frontends={}
for mode in ('software','arc','wayland'):
    folder=root/(mode+'-recipient')
    result=state(folder)
    assert result['terminal'] and result['exit']==0 and result['checks']==10 and result['input_sha256']==sha(root/'before.dsculpt')
    assert result['app_sha256']==native['asan' if mode=='arc' else 'release']['app_sha256']
    frontends[mode]=result
    include(mode,folder/'status.json',folder/'run.log',folder/'workflow/report.json')
    if mode=='wayland':
        include(mode,*(folder/'workflow'/n for n in ('client.log','compositor.log','runtime-maps.txt')))
    else:
        include(mode,*(folder/'workflow'/f'{op}.{ext}' for op in ('accept','cancel') for ext in ('log','json')))
assert len({r['native_sha256'] for r in frontends.values()})==1
accepted=frontends['wayland']['native_sha256']
assert accepted==sha(root/'expected.dsculpt')
include('drivers',patch,*(root/n for n in ('run.py','ctest.py','public-fixture.cpp','public.py','xr.py','wayland.py','record.py')))
include('fixtures',root/'before.dsculpt',root/'expected.dsculpt')
with tarfile.open(archive,'w:gz',compresslevel=9) as pack:
    for key,path in sorted(members.items()):
        pack.add(path,arcname=key)
report={
    'candidate':candidate,
    'scope':'Canonical retained writable UV recipients and independent HDR normal pass on the shared Bake worker. Frozen source delta with refreshed recipient TU and matched native and real application frontend routes.',
    'source_patch_sha256':sha(patch),
    'prior_controls':controls,
    'native':native,
    'matching_native_projects':projects,
    'matching_public_project_sha256':accepted,
    'frontends':frontends,
    'archive':{'file':archive.name,'sha256':sha(archive),
               'members':{key:sha(path) for key,path in sorted(members.items())}},
}
(dest/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(archive) as pack:
    assert {m.name:hashlib.sha256(pack.extractfile(m).read()).hexdigest() for m in pack.getmembers()}==report['archive']['members']
print(candidate, len(projects), accepted, len(members))
