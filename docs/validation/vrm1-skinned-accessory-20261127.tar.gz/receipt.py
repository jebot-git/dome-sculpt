from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
docs = repo / 'docs' / 'validation'
name = 'vrm1-skinned-accessory-20261127'
members = {}


def git(directory, *args):
    return subprocess.check_output(['git', *args], cwd=directory, text=True).strip()


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def digest_file(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def capture(path):
    contents = (work / path).read_bytes()
    members[path] = contents
    return contents


def load(path):
    return json.loads(capture(path))


def assertions(path, count):
    text = capture(path).decode()
    assert not any(line.startswith('FAIL ') for line in text.splitlines()), path
    lines = [line for line in text.splitlines() if line.startswith('PASS ')]
    assert len(lines) == count, (path, len(lines))
    return lines


def cases(path, count):
    items = ET.fromstring(capture(path)).findall('.//testcase')
    names = {item.attrib['name'] for item in items}
    assert len(items) == len(names) == count
    assert all(item.find(tag) is None for item in items for tag in ('failure', 'error', 'skipped'))
    return sorted(names)


revision = git(repo, 'rev-parse', '8012992c')
assert not git(repo, 'diff', '--name-only', revision, '--', 'src', 'include', 'tests', 'CMakeLists.txt')
dome = repo.parent / 'DomeD'
canonical = git(dome, 'rev-parse', 'HEAD')
assert canonical == 'acc2b70ae61dedec2a23727f67c60c0303d0f76f'
assert git(dome, 'ls-remote', '--exit-code', 'origin', 'refs/heads/main').split()[0] == canonical

profiles = {}
for profile, build, n in (('release', 'release-final', 9), ('asan_ubsan', 'asan', 8)):
    lines = assertions(f'{build}/final-bone.log', 181)
    assert sum('Actual portable joint/IBM/weight/morph evaluation agrees' in line for line in lines) == 24
    assert sum('restore the exact linked native authoring state' in line for line in lines) == 4
    for witness in ('both genuine joint influences', 'same file cannot transfer its rig authority',
                    'same original joint identities and native paint', 'first rig transports the linked skin',
                    'Forged source joint slots refuse to replace'):
        assert any(witness in line for line in lines), witness
    capture(f'{build}/final-test-build.log')
    capture(f'{build}/final-registered.log')
    profiles[profile] = {
        'native_assertions': len(lines) - 1,
        'new_linked_skin_assertions': len(lines) - 90,
        'registered_cases': cases(f'{build}/final-registered.xml', n),
        'fixture_binary_sha256': digest_file(work / build / 'dome-sculpt-vrm1-source-export-test'),
    }

artifacts = {}
for file in ('skinned-source.vrm', 'skin-before.dsculpt', 'skin-bound.dsculpt', 'skin-ready-to-export.dsculpt',
             'skin-pose.vrm', 'skin-pose-editable.vrm', 'skin-rest.vrm', 'skin-rest-editable.vrm'):
    path = f'release-final/bone-qualified/{file}'
    artifacts[file] = digest(capture(path))
    assert digest_file(work / 'asan' / 'bone-qualified' / file) == artifacts[file], file

wayland = load('wayland/report.json')
assert wayland['complete'] and len(wayland['checks']) == 9 and all(check['passed'] for check in wayland['checks'])
assert digest(capture('wayland/skin-bound.dsculpt')) == artifacts['skin-bound.dsculpt']
registered = load('release-final/vrm1-attachment-xr/report.json')
assert len(registered['checks']) == 21 and all(check['passed'] for check in registered['checks'])
assert digest(capture('release-final/vrm1-attachment-xr/skin-transfer.dsculpt')) == artifacts['skin-bound.dsculpt']
load('release-final/vrm1-attachment-xr/skin-transfer.json')


def renderer_metrics(path, renderer):
    report = load(f'{path}/runtime.json')
    assert renderer in report['gl_renderer']
    assert report['acquires'] == report['image_waits'] == report['releases'] > 0
    assert report['stereo_submissions'] > 0
    capture(f'{path}/app.log')
    return {'renderer': report['gl_renderer'], 'stereo_submissions': report['stereo_submissions'],
            'swapchain_releases': report['releases']}


xr = {}
for mode, renderer in (('software', 'llvmpipe'), ('arc', 'A770')):
    bind = f'{mode}-bind'
    export = f'xr-export-{mode}'
    assertions(f'{bind}.log', 3)
    assert digest(capture(f'{bind}/controller-bound.dsculpt')) == artifacts['skin-bound.dsculpt']
    assertions(f'{mode}.log', 6)
    assert digest(capture(f'{export}/screen-export.vrm')) == artifacts['skin-pose-editable.vrm']
    assert digest(capture(f'{export}/final.dsculpt')) == artifacts['skin-ready-to-export.dsculpt']
    xr[mode] = {'controller_bind': renderer_metrics(bind, renderer), 'controller_export': renderer_metrics(export, renderer)}

khronos = load('khronos.json')
expected = {'MULTIPLE_EXTENSIONS': 3, 'NODE_SKINNED_MESH_NON_ROOT': 3, 'NODE_SKINNED_MESH_LOCAL_TRANSFORMS': 2}
assert len(khronos['reports']) == 4
for item in khronos['reports']:
    issues = item['report']['issues']
    assert issues['numErrors'] == 0 and issues['numWarnings'] == 8
    assert Counter(msg['code'] for msg in issues['messages'] if msg['severity'] == 1) == expected
schemas = load('schemas.json')['files']
assert len(schemas) == 4 and all(len(entry['checks']) == 4 and
    not any(check['errors'] for check in entry['checks']) for entry in schemas)

for path in ('receipt.py', 'verify-ui.py', 'wayland-skin.py', 'xr-bind.py', 'xr-export.py', 'khronos.cjs',
             'khronos.log', 'schemas.log', 'release-final-configure.log', 'release-final-build.log',
             'asan-configure.log', 'asan-build.log', 'wayland.log', 'wayland/client.log', 'wayland/compositor.log',
             'first-wayland.log', 'second-wayland.log', 'release-final/initial-inverse-bind-fixture.log',
             'release-final/initial-bind-restore.log', 'release-final/surface-heat-scope.log'):
    capture(path)

archive = docs / (name + '.tar.gz')
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed, \
        tarfile.open(fileobj=compressed, mode='w|') as tar:
    for path, payload in sorted(members.items()):
        item = tarfile.TarInfo(path)
        item.size = len(payload)
        item.mode = 0o644
        tar.addfile(item, io.BytesIO(payload))
receipt = {
    'revision': revision, 'canonical_domed_revision': canonical,
    'release_fltk': '/opt/fltk-vr/toolkit', 'asan_fltk': 'artifacts/sdk-20261126/toolkit-sanitize',
    'bitmap_runtime': '/opt/fltk-vr/bdf-runtime',
    'release_application_sha256': digest_file(work / 'release-final' / 'dome-sculpt'),
    'profiles': profiles, 'native_wayland_assertions': len(wayland['checks']),
    'registered_openxr_assertions': len(registered['checks']), 'synthetic_openxr': xr,
    'physical_headset_tested': False, 'identical_release_asan_exports_and_projects_sha256': artifacts,
    'consumer': {'cgltf_posed_corner_comparisons': 24, 'khronos_version': khronos['version'],
                 'khronos_errors_per_file': 0, 'khronos_warnings_per_file': expected,
                 'pinned_vrm_schema_checks': sum(len(entry['checks']) for entry in schemas)},
    'unqualified': ['Surface Heat resource ownership for texture-set paint', 'affine interactive weight brushes',
                    'VRM 0.x linked skins', 'retained-source accessory fields', 'physical input devices'],
    'archive': {'path': archive.name, 'sha256': digest_file(archive),
                'members_sha256': {path: digest(payload) for path, payload in sorted(members.items())}},
}
(docs / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(archive, archive.stat().st_size)
