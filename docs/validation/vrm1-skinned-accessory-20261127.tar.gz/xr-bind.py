from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile

work = Path(__file__).resolve().parent
build = work / "release-final"
fixture = build / "bone-qualified"
mode = sys.argv[1]
out = work / (mode + "-bind")
out.mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(prefix="dome-xr-skin-") as directory:
    home = Path(directory)
    manifest = home / "runtime.json"
    manifest.write_text(json.dumps({
        "file_format_version": "1.0.0",
        "runtime": {"library_path": str(build / "libdome-sculpt-test-runtime.so")},
    }))
    env = {**os.environ, "HOME": directory, "XR_RUNTIME_JSON": str(manifest),
           "DOME_XR_FIXTURE_SKIN": "transfer", "DOME_XR_FIXTURE_REPORT": str(out / "runtime.json")}
    for name in ("config", "state", "data", "cache", "runtime"):
        path = home / name
        path.mkdir(mode=0o700)
        env["XDG_" + name.upper() + ("_DIR" if name == "runtime" else "_HOME")] = str(path)
    if mode == "arc":
        env.update(DRI_PRIME="pci-0000_03_00_0", EGL_PLATFORM="surfaceless", MESA_SHADER_CACHE_DISABLE="1")
    else:
        env["LIBGL_ALWAYS_SOFTWARE"] = "1"
    target = out / "controller-bound.dsculpt"
    with (out / "app.log").open("w") as log:
        result = subprocess.run(
            [build / "dome-sculpt", "--xr", "--open", fixture / "skin-before.dsculpt",
             "--frames", "90", "--save", target],
            env=env, stdout=log, stderr=subprocess.STDOUT, timeout=150,
        )

def check(passed, message):
    print(("PASS " if passed else "FAIL ") + message, flush=True)
    assert passed, message

check(result.returncode == 0, "OpenXR and the ordered file worker drain successfully")
metrics = json.loads((out / "runtime.json").read_text())
label = "A770" if mode == "arc" else "llvmpipe"
check(label in metrics["gl_renderer"] and metrics["acquires"] == metrics["image_waits"] == metrics["releases"] > 0
      and metrics["stereo_submissions"] > 0, "The intended renderer submits both eyes with balanced ownership")
check(target.read_bytes() == (fixture / "skin-bound.dsculpt").read_bytes(),
      "Joystick Transfer publishes the byte-exact native original-rig attachment")
