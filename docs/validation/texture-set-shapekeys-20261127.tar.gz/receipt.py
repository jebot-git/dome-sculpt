from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
docs = repo / "docs" / "validation"
members = {}

def git(directory, *args):
    return subprocess.check_output(["git", *args], cwd=directory, text=True).strip()

def sha(path):
    with path.open("rb") as file:
        return hashlib.file_digest(file, "sha256").hexdigest()

def capture(name):
    contents = (work / name).read_bytes()
    members[name] = contents
    return contents

def load(name):
    return json.loads(capture(name))

def passes(name, count):
    lines = [line for line in capture(name).decode().splitlines() if line.startswith("PASS ")]
    assert len(lines) == count, (name, len(lines))
    return lines

def cases(name, expected):
    items = ET.fromstring(capture(name)).findall(".//testcase")
    names = {item.attrib["name"] for item in items}
    assert len(items) == len(names) == expected
    assert all(item.find(tag) is None for item in items for tag in ("failure", "error", "skipped"))
    return sorted(names)

revision = git(repo, "rev-parse", "17367cb0")
assert revision == "17367cb07b3878c9ed0ed61f9a57899731a9d6af"
assert not git(repo, "diff", "--name-only", revision, "--", "src", "include", "tests", "CMakeLists.txt")
canonical = git(repo.parent / "DomeD", "rev-parse", "HEAD")
assert canonical == "acc2b70ae61dedec2a23727f67c60c0303d0f76f"
assert git(repo.parent / "DomeD", "ls-remote", "--exit-code", "origin", "refs/heads/main").split()[0] == canonical

profiles = {}
for profile, tests in (("release", 4), ("asan", 7)):
    native = passes(f"{profile}/bone.log", 90)
    assert sum("Portable position and derived normal match" in line for line in native) == 12
    assert sum("preserves the native morph tangent" in line for line in native) == 6
    for witness in ("Legacy texture-only history", "Partial rig-field omission",
                    "Live partitioned preview", "XR focus loss rolls back", "Mirroring the sculpted target"):
        assert any(witness in line for line in native)
    for name in (f"{profile}-configure.log", f"{profile}-build.log", f"{profile}/registered.log"):
        capture(name)
    profiles[profile] = {
        "native_assertions": len(native) - 1,
        "added_texture_set_assertions": len(native) - 50,
        "registered_cases": cases(f"{profile}/registered.xml", tests) +
            (cases("release/legacy.xml", 4) if profile == "release" else []),
        "fixture_binary_sha256": sha(work / profile / "dome-sculpt-vrm1-source-export-test"),
    }

artifacts = {}
for name in ("shape-before.dsculpt", "shape-created.dsculpt", "shape-sculpted.dsculpt",
             "shape-ready-to-export.dsculpt", "shape-accessory.vrm", "shape-accessory-editable.vrm"):
    path = f"release/bone/{name}"
    capture(path)
    artifacts[name] = sha(work / path)
    assert sha(work / "asan" / "bone" / name) == artifacts[name]

wayland = load("wayland/report.json")
assert wayland["complete"] and len(wayland["checks"]) == 9
assert all(check["passed"] for check in wayland["checks"])
assert sha(work / "wayland/shape-created.dsculpt") == artifacts["shape-created.dsculpt"]
xr = {}
for mode, renderer in (("software", "llvmpipe"), ("arc", "A770")):
    passes(f"{mode}.log", 6)
    directory = f"xr-export-{mode}"
    runtime = load(f"{directory}/runtime.json")
    assert renderer in runtime["gl_renderer"] and runtime["overlay"]
    assert runtime["acquires"] == runtime["image_waits"] == runtime["releases"] > 0
    assert sha(work / directory / "final.dsculpt") == artifacts["shape-ready-to-export.dsculpt"]
    assert sha(work / directory / "screen-export.vrm") == artifacts["shape-accessory-editable.vrm"]
    capture(f"{directory}/app.log")
    xr[mode] = {"renderer": runtime["gl_renderer"], "assertions": 5,
                "swapchain_releases": runtime["releases"], "stereo_frames": runtime["stereo_submissions"]}

khronos = load("khronos.json")
def warnings(report):
    return Counter((m["code"], m["message"]) for m in report["messages"] if m["severity"] == 1)
issues = {item["name"]: item["report"]["issues"] for item in khronos["reports"]}
assert len(issues) == 3
baseline = warnings(issues["head-source-only.vrm"])
for issue in issues.values():
    assert issue["numErrors"] == 0 and issue["numWarnings"] == 7 and warnings(issue) == baseline
schemas = load("schemas.json")["files"]
assert len(schemas) == 2 and all(len(entry["checks"]) == 5 and
    not any(check["errors"] for check in entry["checks"]) for entry in schemas)

for name in ("receipt.py", "verify-ui.py", "wayland-shape.py", "wayland.log", "wayland/compositor.log",
             "xr-export.py", "khronos.cjs", "khronos.log", "schemas.log", "release-refresh.log",
             "release-final-build.log", "release-archive-build.log", "asan-refresh.log",
             "release-legacy-build.log", "release/legacy.log",
             "release-archive-compile-refusal.log", "release/initial-fixture.log",
             "release/legacy-scene-field-refusal.log",
             "release/vrm1-attachment-xr/report.json"):
    capture(name)

archive_path = docs / "texture-set-shapekeys-20261127.tar.gz"
with archive_path.open("wb") as file, gzip.GzipFile(filename="", fileobj=file, mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as archive:
        for name, contents in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size = len(contents)
            archive.addfile(info, io.BytesIO(contents))
receipt = {
    "revision": revision,
    "canonical_domed_revision": canonical,
    "release_fltk": "/opt/fltk-vr/toolkit",
    "sanitizer_fltk": "artifacts/sdk-20261126/toolkit-sanitize",
    "bitmap_runtime": "/opt/fltk-vr/bdf-runtime",
    "build_profiles": profiles,
    "release_application_sha256": sha(work / "release" / "dome-sculpt"),
    "nested_domed_wayland_assertions": len(wayland["checks"]),
    "synthetic_openxr_files_menu": xr,
    "physical_headset_tested": False,
    "files_matching_across_native_profiles_sha256": artifacts,
    "consumer_validation": {"cgltf": "independent positions, normals and tangents at weight one",
                            "khronos_revision": khronos["version"],
                            "khronos_errors_per_sample": 0,
                            "khronos_source_control_warnings_per_sample": 7,
                            "pinned_vrm_schema_checks": 10},
    "archive": {"path": archive_path.name, "sha256": sha(archive_path),
                "members_sha256": {name: hashlib.sha256(contents).hexdigest()
                                   for name, contents in sorted(members.items())}},
}
(docs / "texture-set-shapekeys-20261127.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(f"Verified {len(members)} captured artifacts")
