from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
validation = repo / 'docs/validation'
label = root.name
release = root / 'release'
asan = root / 'asan'

def digest(data):
    return sha256(data).hexdigest()

def git(path):
    return subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip()

def read(path):
    return json.loads((root/path).read_text())

def tests(profile,count):
    log=(root/f'{profile}-qualified.log').read_text()
    names=re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',log)
    assert len(names)==len(set(names))==count and f'0 tests failed out of {count}' in log
    return names

release_tests=tests('release',34)
sanitizer_tests=tests('asan',6)
checks={}
exact={}
bodies=[]
for placement in ['plain','affine']:
    name=f'retopology-first-material-{placement}'
    checks[placement]={}
    for profile, directory in [('release',release),('asan',asan)]:
        logging=(directory/'Testing/Temporary/LastTest.log').read_text()
        case=re.search(r'^\d+/\d+ Testing: '+name+r'\n(.*?)^Test Passed\.',logging,re.M|re.S)
        assert case
        body=case[1]
        assert body.count('PASS Crossing a material boundary refuses before changing the original scene')==2
        assert 'Reapply changes the newly transferred patch' in body
        checks[placement][profile]=int(re.search(r'^PASS (\d+) retopology Surface Heat controls$',body,re.M)[1])
        log=f'{profile}-{placement}-controls.log'
        (root/log).write_text(body)
        bodies.append(log)
    for path in sorted((release/name).glob('first-material-*')):
        relative=path.relative_to(release)
        assert path.read_bytes()==(asan/relative).read_bytes(),str(relative)
        exact[str(relative)]=digest(path.read_bytes())
assert len(exact)==9

wayland=read('wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks'])==7 and all(it['passed'] for it in wayland['checks'])
khronos=read('khronos.json')
portable={p['file']:{key:value for key,value in p['issues'].items() if key.startswith('num')} for p in khronos['results']}
assert len(portable)==4 and all(not (p['numErrors'] or p['numWarnings']) for p in portable.values())
xr={}
for renderer in ['arc','software']:
    for placement in ['plain','affine']:
        name=f'{renderer}-{placement}'
        proof=read(f'xr-{name}/compare.json')
        assert proof['exact_ordered_close'] and len(proof['profiles'])==2
        assert all(it['stereo_submissions']==6 and it['action_syncs']==7 for it in proof['profiles'])
        assert all(v>100 for v in proof['differing_rgb_components_per_eye'])
        xr[name]={'renderer':proof['profiles'][0]['gl_renderer'],'submissions_per_project':6,
                  'differing_rgb_components_per_eye':proof['differing_rgb_components_per_eye'],
                  'exact_native_save':True}

files=['check-profile.sh','relink-sanitizer.py','release-qualified.log','release-qualified-build.log',
       'asan-qualified.log','asan-qualified-configure.log','asan-qualified-build.log',*bodies,
       'khronos.cjs','khronos.json','run-wayland.py','wayland-first-material.py','bind-wayland.log',
       'wayland-first-material/report.json','wayland-first-material/corners.json','record.py','run-render.py','xr-first-material.py',
       *[f'xr-{name}/compare.json' for name in xr]]
archive=validation/(label+'.tar.gz')
members={}
with tarfile.open(archive,'w:gz',compresslevel=9) as output:
    for name in files:
        data=(root/name).read_bytes()
        members[name]=digest(data)
        member=tarfile.TarInfo(name)
        member.size=len(data)
        output.addfile(member,io.BytesIO(data))

receipt={'product':git(repo),'canonical_domed':git(repo.parent/'DomeD'),
         'canonical_domed_compositor_sha256':digest((root.parent/'creator-public-build-20261126/wayland-reference/dome-compositor').read_bytes()),
         'release_binary_sha256':digest((release/'dome-sculpt').read_bytes()),
         'sanitizer_binary_sha256':digest((asan/'dome-sculpt-retopo-surface-heat-test').read_bytes()),
         'release_tests':release_tests,'strict_asan_ubsan':sanitizer_tests,'native_checks':checks,
         'identical_native_projects_and_glbs_sha256':exact,'wayland':wayland,'synthetic_openxr':xr,
         'khronos_version':khronos['validator'],'khronos':portable,'physical_headset':False,
         'archive_sha256':digest(archive.read_bytes()),'archive_members_sha256':members}
(validation/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
