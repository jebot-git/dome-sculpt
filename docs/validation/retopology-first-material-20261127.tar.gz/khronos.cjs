const fs = require('node:fs');
const path = require('node:path');
const validator = require('../hdr-khronos-validation-20261126/module/package');
const files = ['release/retopology-first-material-plain/first-material-standard.glb',
               'release/retopology-first-material-plain/first-material-editable.glb',
               'release/retopology-first-material-affine/first-material-editable.glb',
               'wayland-first-material/wayland-patch.glb'];
async function main() {
  const results = [];
  for (const file of files) {
    const bytes = fs.readFileSync(path.join(__dirname, file));
    const report = await validator.validateBytes(new Uint8Array(bytes), {uri: file});
    if (report.issues.numErrors) throw new Error(JSON.stringify(report.issues));
    results.push({file, issues: report.issues});
    console.log(file, report.issues.numErrors, report.issues.numWarnings);
  }
  fs.writeFileSync(path.join(__dirname, 'khronos.json'),
                   JSON.stringify({validator: validator.version(), results}, null, 2) + '\n');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
