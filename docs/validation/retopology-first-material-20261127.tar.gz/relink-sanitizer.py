from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import shlex
import subprocess
import sys

build = Path(sys.argv[1])
targets = ["dome-sculpt-retopo-surface-heat-test"]
commands = {target: subprocess.check_output(['ninja','-t','commands',target], cwd=build, text=True).splitlines()
            for target in targets}

def compile_source(suffix):
    row, = [row for row in commands[targets[0]] if ' -c ' in row and row.endswith('/' + suffix)]
    command = shlex.split(row)
    assert '-fsanitize=address,undefined' in command
    print(shlex.join(command), flush=True)
    subprocess.run(command, cwd=build, check=True)
    return command[command.index('-o')+1] if suffix.startswith('src/') else None

sources = sys.argv[2:] or ['src/retopo-authoring.cpp','src/texture-sets.cpp','src/paint.cpp','tests/retopo-surface-heat.cpp']
with ThreadPoolExecutor(max_workers=4) as pool:
    objects = list(filter(None,pool.map(compile_source, sources)))
subprocess.run(['/usr/bin/ar','r','libdome-sculpt-core.a',*objects], cwd=build, check=True)
subprocess.run(['/usr/bin/ranlib','libdome-sculpt-core.a'], cwd=build, check=True)
for target in targets:
    link = shlex.split(commands[target][-1])
    assert link[:2]==[':','&&'] and link[-2:]==['&&',':']
    assert '-fsanitize=address,undefined' in link and target in link
    print(shlex.join(link[2:-2]), flush=True)
    subprocess.run(link[2:-2], cwd=build, check=True)
