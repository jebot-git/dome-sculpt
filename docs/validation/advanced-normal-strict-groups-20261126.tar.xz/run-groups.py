from concurrent.futures import ProcessPoolExecutor, as_completed
from multiprocessing import get_context
from pathlib import Path
import hashlib
import json
import os
import re

from owned_monitor import run


BUILD = Path(__file__).resolve().parent
WORKFLOW = BUILD / 'native-groups'
FIXTURE = BUILD.parent / 'current-normal-resume-20261126/tests/fixtures/normal-filter-legacy64-retained.dsculpt'
EXECUTABLE = BUILD / 'advanced-shards-test'
GROUPS = {
    'common': {'unbound-normalmap'},
    'mt1-rest': set(),
    'mt1-posed': set(),
    'mt0-rest': set(),
    'mt0-posed': set(),
    'three-edits': {'mt1-posed-seam-retained-three-edits'},
}
for group in ('mt1-rest', 'mt1-posed', 'mt0-rest', 'mt0-posed'):
    GROUPS[group] = {f'{group}-{seam}-{method}' for seam in ('shared', 'seam')
                     for method in ('raster', 'retained')}


def digest(path):
    with open(path, 'rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def run_group(group, compiled_hash, fixture_hash):
    out = WORKFLOW / group
    out.mkdir()
    command = [str(EXECUTABLE), '--filtered-workflow-group', str(out / 'workflow'),
               str(FIXTURE), '2048', '2048', group]
    env = dict(os.environ, LD_LIBRARY_PATH='/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
               MALLOC_ARENA_MAX='2', MALLOC_MMAP_THRESHOLD_='131072',
               OPENBLAS_NUM_THREADS='2', OMP_NUM_THREADS='2',
               ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    assert not env.get('LD_PRELOAD') and not env.get('LSAN_OPTIONS')
    assert digest(EXECUTABLE) == compiled_hash and digest(FIXTURE) == fixture_hash
    witness = {}

    def observe(row):
        if witness:
            return
        try:
            proc = Path('/proc') / str(row['pid'])
            if not (proc / 'exe').samefile(EXECUTABLE):
                return
            maps = (proc / 'maps').read_text()
            if '/libasan.so' in maps and '/libubsan.so' in maps:
                (out / 'live-maps.txt').write_text(maps)
                witness.update(pid=row['pid'], start=row['start'])
        except (ProcessLookupError, FileNotFoundError):
            pass

    log = out / 'product.log'
    row = run(command, cwd=BUILD, env=env, log=log, timeout=900,
              max_rss=3 * 1024**3, progress=observe)
    output = log.read_text()
    families = re.findall(r'^FILTERED_RESOLUTION_WORKFLOW (\S+) target_resolution=2048 source_resolution=64$', output, re.M)
    summary = re.findall(r'^PASS (\d+) filtered Bake workflow positives=(\d+) original64_refusals=(\d+) target_resolution=2048 ordinary_target_resolution=2048$', output, re.M)
    expected = GROUPS[group]
    expected_refusals = 2 if len(expected) == 4 else 0
    expected_positives = len(expected) if group != 'common' else 0
    reported_checks, positives, refusals = map(int, summary[0]) if len(summary) == 1 else (0, -1, -1)
    accepted = (row['exit'] == 0 and 'error' not in row and bool(witness) and
                f'FILTERED_WORKFLOW_GROUP {group}\n' in output and
                set(families) == expected and len(families) == len(expected) and
                positives == expected_positives and refusals == expected_refusals and
                not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|runtime error:', output) and
                digest(EXECUTABLE) == compiled_hash and digest(FIXTURE) == fixture_hash)
    row.update(group=group, accepted=accepted, families=families, checks=reported_checks,
               positives=positives, refusals=refusals, sanitizer_witness=witness)
    (out / 'result.json').write_text(json.dumps(row, indent=2) + '\n')
    return row


def main():
    WORKFLOW.mkdir()
    build = json.loads((BUILD / 'build-status.json').read_text())
    assert build['terminal'] and build['exit'] == 0
    compiled_hash = build['ELF']
    fixture_hash = digest(FIXTURE)
    status = {'terminal': False, 'groups': list(GROUPS), 'completed': [],
              'ELF': compiled_hash, 'fixture_sha256': fixture_hash, 'parallelism': 3}

    def save():
        temporary = WORKFLOW / 'status.tmp'
        temporary.write_text(json.dumps(status, indent=2) + '\n')
        temporary.replace(WORKFLOW / 'status.json')

    save()
    try:
        with ProcessPoolExecutor(max_workers=3, mp_context=get_context('spawn')) as processes:
            futures = [processes.submit(run_group, group, compiled_hash, fixture_hash)
                       for group in GROUPS]
            for future in as_completed(futures):
                status['completed'].append(future.result())
                save()
        rows = status['completed']
        checks = sum(row['checks'] for row in rows)
        accepted = (all(row['accepted'] for row in rows) and len(rows) == len(GROUPS) and
                    len({family for row in rows for family in row['families']}) == 18 and
                    sum(row['positives'] for row in rows) == 17 and
                    sum(row['refusals'] for row in rows) == 8 and checks == 645)
        status.update(exit=int(not accepted), checks=checks,
                      full_workflow_check_count=checks+int(accepted))
    except Exception as error:
        status.update(exit=1, error=repr(error))
    finally:
        status['terminal'] = True
        save()
    return status['exit']


if __name__ == '__main__':
    raise SystemExit(main())
