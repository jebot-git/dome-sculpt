from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
source=artifacts/"hdr-closure-independent-seed-source-20261126"
out=base/profile
out.mkdir(mode=0o700)
parent=artifacts/"vrm1-unlit-mask-paint-validation-20261126"
support=(parent/"combined-release" if profile=="release" else
         artifacts/"core-gltf-normal-export-asan-20261126")
core=support/"libdome-sculpt-core.a" if profile=="release" else parent/"asan-verified-final/libdome-sculpt-core.a"
expected=subprocess.check_output(["git","-C",source,"rev-parse","HEAD"],text=True).strip()
invocation=os.getenv("INVOCATION_ID")
status={"profile":profile,"candidate":expected,"invocation":invocation,"terminal":False}
start=time.monotonic()
toolkit="/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
os.environ["LD_LIBRARY_PATH"]=toolkit
os.environ["PKG_CONFIG_PATH"]="/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig"

def update(**fields):
    status.update(fields, seconds=round(time.monotonic()-start,2))
    temporary=out/"status.tmp"
    temporary.write_text(json.dumps(status,indent=2)+"\n")
    temporary.replace(out/"status.json")

def run(command, logfile, cwd=out):
    with logfile.open("w") as log:
        print(shlex.join(map(str,command)),file=log,flush=True)
        return subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT).returncode

update(phase="configure test graph")
assert not subprocess.check_output(["git","-C",source,"status","--porcelain"],text=True)
rc=run(["cmake","-G","Ninja","-S",source,"-B",out,"-DCMAKE_BUILD_TYPE=Release",
        "-DDOME_COMPUTE_BACKEND=CPU","-DFLTK_DIR=/opt/fltk-vr/toolkit/share/fltk"],
       out/"configure.log")
if rc:
    update(terminal=True,exit=rc)
    raise SystemExit(rc)

targets={"source-joint-writable-normal-bake", "source-hdr-provenance-closure", "source-retained-emission-worker"}
commands=json.loads((support/"compile_commands.json").read_text())
def compile_and_link(test):
    path="tests/"+test+".cpp"
    record=next(row for row in commands if row["file"].endswith("/"+path))
    old=str(Path(record["file"]).parents[1])
    compile_command=[x.replace(old,str(source)) for x in shlex.split(record["command"])]
    obj=out/(test+".o")
    compile_command[compile_command.index("-o")+1]=str(obj)
    assert run(compile_command,out/(test+".compile.log"),support)==0
    target="dome-sculpt-"+test+"-test"
    raw=subprocess.check_output(["ninja","-C",support,"-t","commands",target],text=True).splitlines()[-1]
    command=[arg for arg in shlex.split(raw)[2:-2] if not arg.startswith("-Wl,--dependency-file=")]
    command[command.index("-o")+1]=str(out/target)
    command[command.index(core.name)]=str(core)
    command[next(i for i,arg in enumerate(command) if arg.endswith("/"+test+".cpp.o"))]=str(obj)
    assert run(command,out/(test+".link.log"),support)==0
    return target

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

update(phase="compile complete owning fixtures",core=str(core),core_sha256=digest(core))
try:
    with ThreadPoolExecutor(max_workers=2) as workers:
        built=sorted(workers.map(compile_and_link,sorted(targets)))
except Exception as error:
    update(terminal=True,exit=1,error=str(error))
    raise
selected="^(source-hdr-provenance-closure|source-retained-emission-worker)$"
if profile=="release":
    selected="^(source-hdr-provenance-closure|source-retained-emission-worker|source-hdr-joint-full-size)$"
update(phase="registered isolated CTest",targets=built,selected=selected)
rc=run(["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/","--bind",out,out,
        "--proc","/proc","--dev","/dev","--tmpfs","/tmp","--tmpfs","/run/user","--clearenv",
        "--setenv","PATH","/usr/bin:/bin","--setenv","HOME","/tmp","--setenv","LD_LIBRARY_PATH",toolkit,
        "--setenv","ASAN_OPTIONS","detect_leaks=1:halt_on_error=1",
        "--setenv","UBSAN_OPTIONS","halt_on_error=1:print_stacktrace=1",
        "ctest","--test-dir",out,"-R",selected,"-j2","-V","--output-junit",out/"ctest.xml"],
        out/"ctest.log")
update(phase="complete",terminal=True,exit=rc,clean=not subprocess.check_output(["git","-C",source,"status","--porcelain"],text=True))
raise SystemExit(rc)
