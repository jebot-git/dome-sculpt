"""Separate ordinary baseline observation in exact combined9e4 App, unchanged camera."""
from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,re,subprocess,time,traceback
out=Path(__file__).resolve().parent;root=out.parent.parent
build=root/'artifacts/production-hdr-combined-release-20261126';source=root/'artifacts/production-hdr-integration-20261126'
case=out/'ordinary-default-rendered9e4-v1';case.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n,p):
    spec=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
monitor=load('owned',out/'owned-monitor.py');providers=load('providers',out/'provider-witness-v4.py')
app=build/'dome-sculpt';runtime=out/'release/libdome-sculpt-creator-workspace-runtime.so';observer=out/'device-auth.so';baseline=out/'ordinary-default-framing-v2/default.dsculpt'
assert sha(app)=='2959bb7f0c87c733edffddca5e6042b6c0a245b22124a345fd3eba229902367d'
assert sha(runtime)=='2cb3885e673babc4160fca528269ef30cb6ab644549693939c4d76618ed36ece'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='9e4f79f6c37ac4c4ca52cc6a0c0f288b60454d55'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
assert json.loads((out/'ordinary-default-framing-v2/status.json').read_text())['exit']==0
authority=json.loads((out/'default-framing-milestone/receipt.json').read_text());assert sha(baseline)==authority['external_native_projects'][str(baseline)]['sha256']
loader=case/'loader.json';loader.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(runtime)}})+'\n')
env={k:v for k,v in os.environ.items()if not k.startswith(('LD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_','DYLD_'))}
for k in ['DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','XR_RUNTIME_JSON','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']:env.pop(k,None)
settings={'HOME':str(case),'PATH':'/usr/local/bin:/usr/bin','LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','LD_PRELOAD':str(observer),'LP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2','XR_RUNTIME_JSON':str(loader),'DOME_XR_FIXTURE_REPORT':str(case/'runtime.json'),'DOME_XR_FIXTURE_CREATOR':'reopen','DOME_MARKER_DEVICE_REPORT':str(case/'actual-device'),'DRI_PRIME':'pci-0000_03_00_0','MESA_LOADER_DRIVER_OVERRIDE':'iris','EGL_PLATFORM':'surfaceless','__EGL_VENDOR_LIBRARY_FILENAMES':'/usr/share/glvnd/egl_vendor.d/50_mesa.json'}
for k,leaf in [('XDG_CONFIG_HOME','config'),('XDG_STATE_HOME','state'),('XDG_DATA_HOME','data'),('XDG_CACHE_HOME','cache'),('XDG_RUNTIME_DIR','runtime')]:
    p=case/leaf;p.mkdir(mode=0o700);settings[k]=str(p)
appearance=Path(settings['XDG_CONFIG_HOME'])/'dome/appearance.json';appearance.parent.mkdir();appearance.write_text(json.dumps({'font':'Unifont / Sans-Serif','font_size':16,'font_scale':1})+'\n')
env.update(settings);pins={}
def pin(p):
    p=Path(p)
    if p.is_file():pins[str(p.resolve())]=sha(p)
for p in [app,runtime,observer,baseline,loader,appearance,Path(__file__),out/'owned-monitor.py',out/'provider-witness-v4.py',build/'build-review.json',build/'build-status.json','/usr/share/glvnd/egl_vendor.d/50_mesa.json']:pin(p)
for directory in [Path('/usr/lib64'),Path('/opt/fltk-vr/toolkit/lib'),Path('/opt/fltk-vr/bdf-runtime/lib')]:
    for p in directory.rglob('*.so*'):
        if p.is_file():
            try:
                with p.open('rb')as f:
                    if f.read(4)==b'\x7fELF':pin(p)
            except PermissionError:pass
for name in subprocess.check_output(['git','ls-files','-z'],cwd=source,text=True).split('\0'):
    if name:pin(source/name)
command=[str(app),'--xr','--open',str(baseline),'--frames','90','--save',str(case/'final.dsculpt')]
plan={'scope':'Ordinary default-baseline presentation through exact9e4 production App and qualified clock-correct synthetic runtime in reopen/no-creator-input mode. No camera/view/model changes, no physical-HMD acceptance or full creator/fidelity-suite claim.','production':'9e4f79f6c37ac4c4ca52cc6a0c0f288b60454d55','runtime_owning_source':'5509958f','command':command,'environment':settings,'pins':pins,'timeout_seconds':240,'RSS_limit_bytes':4*1024**3,'virtual_AS_cap':None}
(case/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
w=providers.Witness(pins,app,out/'private-x11/usr/bin/Xvfb');s={'terminal':False,'steps':[],'plan_sha256':sha(case/'plan.json')};lease=None
def save():(case/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def live(row):w.observe(row,monitor);s['live']=row;s['observed']=w.result();save()
try:
    assert not drift();lease=open('/tmp/dome-sculpt-arc-device.lock','a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(lease.fileno());s['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino,'before_any_loader_or_product':True};save()
    row=monitor.run(command,cwd=case,env=env,log=case/'app.log',timeout=240,max_rss=4*1024**3,progress=live);s['steps'].append(row);s.pop('live',None);s['observed']=w.result();save();assert row['exit']==0 and not row.get('error')and not row['signals']
    report=json.loads((case/'runtime.json').read_text());assert report['frames_waited']==report['frames_begun']==report['frames_ended']==90;assert report['acquires']==report['image_waits']==report['releases']and report['stereo_submissions']>0
    assert report['sessions_begun']==report['sessions_destroyed']==1 and report['swapchains_created']==report['swapchains_destroyed']==2
    assert not report.get('creator_buttons')and not report.get('creator_pressures')
    assert report['gl_vendor']=='Intel'and'Arc'in report['gl_renderer']and'A770'in report['gl_renderer']
    captures=report['creator_captures'];assert all(f'{frame}-{eye}'in captures for frame in [2,4,37,61,85,89]for eye in [0,1])
    for r in captures.values():assert Path(r['ppm']).stat().st_size>r['width']*r['height']*3
    assert report['left_eye_nonblank']>0 and report['right_eye_nonblank']>0
    assert sha(case/'final.dsculpt')==sha(baseline),'Ordinary reopen changed canonical native bytes'
    devices=list((case/'actual-device').glob('*/device.txt'));assert len(devices)==1
    for p in devices:
        d=dict(line.split('=',1)for line in p.read_text().splitlines()if'='in line and not line.startswith('fd='));assert d['vendor']=='Intel'and'Arc'in d['renderer']and'A770'in d['renderer']and d['render_node']=='/dev/dri/renderD129'and d['pci'].endswith('/0000:03:00.0')and d['vendor_id']=='0x8086'and d['device_id']=='0x56a0';assert int(d['egl_display'],16)and int(d['egl_context'],16)and re.search(r'^fd=\d+$',p.read_text(),re.M)
    assert len(w.apps)==1 and not drift();s.update(exit=0,actual_frames=90,actual_released_eye_captures=len(captures),canonical_native_sha256=sha(baseline),actual_device_reports={str(p):sha(p)for p in devices})
except BaseException as e:s.update(exit=1,error=repr(e),traceback=traceback.format_exc())
finally:
    s['input_drift']=drift();s['owned_remaining']=[r for row in s['steps']for r in row.get('known_processes',[])if monitor.alive(r)]
    if s['input_drift']or s['owned_remaining']:s['exit']=1
    s['terminal']=True
    if lease:
        if'lease'in s:s['lease']['released']=time.time()
        save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
    save()
raise SystemExit(s['exit'])
