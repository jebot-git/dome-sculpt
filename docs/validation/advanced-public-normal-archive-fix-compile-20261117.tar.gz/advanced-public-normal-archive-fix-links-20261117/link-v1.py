"""One reviewed fresh native CPU link; no built product/ldd execution."""
import hashlib,importlib.util,json,os,resource,shlex,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];EXPECTED_PLAN="1179d8b0683a5f41855277cf97951ea0cd1a5a956edca14293e4c33c8f2b4f97"
J=json.loads((P/'link-plan-v1.json').read_text());pins={};state={'state':'preparing','exit':1,'source_tuple':J['source_tuple'],'scope':J['scope'],'steps':[],'driver_pid':os.getpid(),'source':J['source']}
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,want=None):
 p=str(p);h=sha(p);assert want is None or h==want,('Input drift',p);assert p not in pins or pins[p]==h,('Conflicting expected pin',p);pins[p]=h

def save():(P/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';assert sha(M)=='b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269';spec=importlib.util.spec_from_file_location('qualified_single_native_link_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','LD_LIBRARY_PATH':str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'};state['environment']=env

def run(name,argv):
 row={'name':name,'argv':argv,'cwd':str(P),'started':time.time()};state['steps'].append(row);save()
 with(P/(name+'.log')).open('w')as log:
  proc=subprocess.Popen(argv,cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);owned=monitor.Owned(proc);deadline=time.monotonic()+900
  try:
   while proc.poll()is None:
    rss=owned.refresh();row.update(owned.result());save()
    if rss>3*1024**3:raise monitor.BudgetExceeded('Owned aggregate RSS exceeds3GiB')
    if time.monotonic()>deadline:raise monitor.BudgetExceeded('Command exceeds900s')
    time.sleep(.01)
   code=proc.wait();owned.refresh();row.update(owned.result());assert not[v for v in owned.known.values()if monitor.alive(v)]
  except BaseException as error:owned.terminate(str(error));row.update(owned.result());save();raise
 row.update(exit=code,seconds=time.time()-row['started'],log_sha256=sha(P/(name+'.log')));save();print(name,code,flush=True);assert code==0
try:
 pin(P/'link-plan-v1.json',EXPECTED_PLAN);pin(Path(__file__).resolve());pin(M)
 for key in ['compile_plan','actual_native_compile_status','actual_native_compile_inputs','actual_native_compile_closure','actual_native_compile_plan','original_unrun_link_plan','prior_actual_native_link_status','prior_actual_native_linkdeps']:pin(J[key]['path'],J[key]['sha256'])
 compile_state=json.loads(Path(J['actual_native_compile_status']['path']).read_text());assert compile_state['state']=='terminal'and compile_state['exit']==0 and not compile_state['input_drift']and len(compile_state['dependency_owners'])==1
 owner=compile_state['dependency_owners'][0];assert owner['same_roster']and owner['object']==J['actual_native_object']and owner['object_sha256']==J['actual_native_object_sha256'];state['source']=compile_state['source']
 cplan=json.loads(Path(J['actual_native_compile_plan']['path']).read_text());S=Path(cplan['source']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==compile_state['source']and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 for p,h in json.loads(Path(J['actual_native_compile_inputs']['path']).read_text()).items():pin(p,h)
 pin(J['actual_native_object'],J['actual_native_object_sha256'])
 for p,h in J['expected_providers'].items():pin(p,h)
 assert len(J['closed_current_compiler_tools'])==14
 for p,row in J['closed_current_compiler_tools'].items():assert str(Path(p).resolve())==row['resolved'];pin(p,row['sha256']);pin(row['resolved'],row['sha256'])
 for row in J['retained_products'].values():pin(row['path'],row['sha256'])
 pin('/usr/bin/readelf');pin(Path('/usr/bin/readelf').resolve());(P/'inputs-before.json').write_text(json.dumps(pins,indent=2)+'\n');cmd=J['command'];assert not Path(cmd['output']).exists()and not Path(cmd['actual_link_dependencies']).exists();run('native-link',cmd['argv'])
 text=Path(cmd['actual_link_dependencies']).read_text().split('\n\n',1)[0].replace('\\\n',' ');target,tail=text.split(':',1);assert target.strip()==cmd['output'];deps=[]
 for literal in shlex.split(tail):
  p=Path(literal);p=p if p.is_absolute()else P/p;r=p.resolve();want=pins.get(str(p),pins.get(str(r)));assert want is not None,('Actual linker input outside declared current provider closure',str(p),str(r));pin(p,want);pin(r,want);deps.append({'literal':literal,'path':str(p),'resolved':str(r),'sha256':want})
 pin(cmd['actual_link_dependencies']);pin(cmd['output']);state['actual_link_dependencies']={'native':{'path':cmd['actual_link_dependencies'],'sha256':sha(cmd['actual_link_dependencies']),'rows':deps,'actual_CWD':str(P)}}
 run('native-dynamic-boundary',['/usr/bin/readelf','-dW',cmd['output']]);run('native-dynamic-symbols',['/usr/bin/readelf','--dyn-syms','--wide',cmd['output']]);state.update(products={'native':{'path':cmd['output'],'sha256':sha(cmd['output'])},**J['retained_products']},exit=0)
except BaseException as error:state.update(error=repr(error),exit=1)
finally:
 state['input_drift']=[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h];state['exit']=state['exit']or int(bool(state['input_drift']));state['remaining_owned']=[r for step in state['steps']for r in step.get('known_processes',[])if monitor.alive(r)];state['exit']=state['exit']or int(bool(state['remaining_owned']));(P/'inputs-final.json').write_text(json.dumps(pins,indent=2)+'\n');state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
raise SystemExit(state['exit'])
