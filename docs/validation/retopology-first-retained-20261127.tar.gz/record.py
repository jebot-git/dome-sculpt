from hashlib import sha256
import io
import json
import math
from pathlib import Path
import re
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = root.parent.parent
validation = repo / 'docs/validation'

def git(path):
    return subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()

def digest(data):
    return sha256(data).hexdigest()

def read(name):
    return json.loads((root / name).read_text())

runs = {}
measurements = {}
matching_outputs = {}
files = ['record.py', 'check-profile.sh', 'run-wayland.py', 'wayland-first-material.py',
         'bind-wayland-initial.log', 'bind-wayland.log', 'wayland-first-material/report.json',
         'wayland-first-material/viewport.json', 'wayland-first-material/corners.json',
         'wayland-first-material/source-viewport.png', 'run-render.py', 'xr-first-material.py',
         'khronos.cjs', 'khronos.json']
for profile, count in [('release', 44), ('asan', 11)]:
    name = f'{profile}-qualified.log'
    log = (root / name).read_text()
    names = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', log)
    assert len(names) == len(set(names)) == count and f'0 tests failed out of {count}' in log
    runs[profile] = names
    files += [name, f'{profile}-qualified-build.log']
    native_log = (root / profile / 'Testing/Temporary/LastTest.log').read_text()
    measurements[profile] = {}
    for placement in ('plain', 'affine'):
        case = f'texture-set-retained-retopology-{placement}'
        result = re.search(r'^\d+/\d+ Testing: ' + case + r'\n(.*?)^Test Passed\.', native_log, re.M | re.S)
        assert result, case
        body = result[1]
        samples, cos_angle = re.search(r'^RETOPO_NORMAL samples=(\d+) min_dot=(\d+\.\d+)$', body, re.M).groups()
        controls = re.search(r'^PASS (\d+) retained material retopology checks$', body, re.M)[1]
        assert int(samples) >= 70 and float(cos_angle) > math.cos(.02)
        assert (root / profile / case / 'imported-pbr-donor.glb').is_file() == (placement == 'plain')
        measurements[profile][placement] = {'checks': int(controls), 'normal_samples': int(samples),
                                             'minimum_normal_dot_rounded': float(cos_angle)}
        case_log = f'{profile}-{placement}-controls.log'
        (root / case_log).write_text(body)
        files.append(case_log)
        for path in sorted((root / profile / case).iterdir()):
            if path.suffix not in {'.dsculpt', '.glb'}:
                continue
            key = str(path.relative_to(root / profile))
            if profile == 'release':
                matching_outputs[key] = digest(path.read_bytes())
            else:
                assert matching_outputs[key] == digest(path.read_bytes()), key
assert len(matching_outputs) == 9 and measurements['release'] == measurements['asan']

wayland = read('wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks']) == 7 and all(row['passed'] for row in wayland['checks'])
validator = read('khronos.json')
assert len(validator['results']) == 5
assert all(not (row['issues']['numErrors'] or row['issues']['numWarnings']) for row in validator['results'])
for row in validator['results']:
    row['sha256'] = digest((root / row['file']).read_bytes())

xr = {}
for device in ('arc', 'software'):
    for placement in ('plain', 'affine'):
        name = f'{device}-{placement}'
        json_path = f'xr-{name}/compare.json'
        result = read(json_path)
        assert result['exact_ordered_close'] and len(result['profiles']) == 2
        for profile in result['profiles']:
            assert profile['stereo_submissions'] == 6 and profile['action_syncs'] == 7
            assert profile['acquires'] == profile['image_waits'] == profile['releases'] == 12
        assert min(result['differing_rgb_components_per_eye']) > 100
        assert all(min(eyes.values()) > 6000 for eyes in result['material_pixels_per_eye'].values())
        xr[name] = {
            'gl_renderer': result['profiles'][0]['gl_renderer'],
            'stereo_submissions_per_project': 6,
            'differing_rgb_components_per_eye': result['differing_rgb_components_per_eye'],
            'authoring_pixels_per_eye': result['material_pixels_per_eye'],
            'exact_ordered_close': True,
        }
        files += [json_path, f'verified-{placement}-{device}.log']

archive = validation / (root.name + '.tar.gz')
archived = {}
with tarfile.open(archive, 'w:gz', compresslevel=9) as output:
    for name in files:
        data = (root / name).read_bytes()
        archived[name] = digest(data)
        member = tarfile.TarInfo(name)
        member.size = len(data)
        output.addfile(member, io.BytesIO(data))

receipt = {
    'product': git(repo), 'canonical_domed': git(repo.parent / 'DomeD'),
    'compositor_sha256': digest((root.parent / 'creator-public-build-20261126/wayland-reference/dome-compositor').read_bytes()),
    'release_app_sha256': digest((root / 'release/dome-sculpt').read_bytes()),
    'strict_asan_ubsan_fixture_sha256': digest((root / 'asan/dome-sculpt-texture-set-source-export-test').read_bytes()),
    'native_tests': runs, 'measurements': measurements, 'matching_release_and_sanitizer_outputs_sha256': matching_outputs,
    'wayland': wayland, 'synthetic_openxr': xr, 'physical_headset': False, 'khronos': validator,
    'archive_sha256': digest(archive.read_bytes()), 'archive_members_sha256': archived,
}
(validation / (root.name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
