from hashlib import file_digest, sha256
from pathlib import Path
import gzip
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
previous = '1c99af36583c1ecbdc1358319912baa50e9365fe'
old = work.parent / 'retopology-color-normal-hdr-20261127/combined-release'
unit = 'ds-held-cut-combined-release-20261127.service'

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()

def command(*argv):
    return subprocess.check_output(argv, cwd=repo, text=True).strip()

product = command('git', 'rev-parse', 'HEAD')
assert command('git', 'rev-parse', 'HEAD^') == previous
patch = subprocess.check_output(['git', 'diff', '--binary', previous, product], cwd=repo)
assert sha256(patch).hexdigest() == digest(work / 'product.patch')
for path in command('git', 'diff', '--name-only', previous, product).splitlines():
    assert digest(work / 'frozen' / path) == digest(repo / path)
domed = command('git', '-C', '../DomeD', 'rev-parse', 'HEAD')
assert domed == command('git', '-C', '../DomeD', 'ls-remote', 'origin', 'refs/heads/main').split()[0]
old_status = json.loads((old / 'status.json').read_text())
assert old_status["terminal"] and old_status["totals"] == {"pass": 1404, "fail": 2, "skip": 0}
assert old_status['failed'] == ['colored-cut-allocation', 'native-worker-held-publication']
assert digest(old / 'full.xml') == old_status['junit_sha256']
old_tests = {case.attrib['name']: case for case in ET.parse(old / 'full.xml').getroot().iter('testcase')}
old_held = old_tests['native-worker-held-publication'].findtext('system-out')
old_cut = old_tests['colored-cut-allocation'].findtext('system-out')
assert 'Actual held contact gesture reaches native worker' in old_held
assert 'Reached cut allocation boundary 56576' in old_cut
(work / 'frozen-failures.json').write_text(json.dumps({'status': old_status, 'held': old_held, 'cut': old_cut}, indent=2) + '\n')

assert '0 tests failed out of 16' in (work / 'release-tests.log').read_text()
cases = list(ET.parse(work / 'release/held-cut-release.xml').getroot().iter('testcase'))
assert len(cases) == 16 and all(case.find('failure') is None and case.find('skipped') is None for case in cases)
names = {case.attrib['name']: case for case in cases}
shards = []
cut_logs = {}
full_output = (work / "release/Testing/Temporary/LastTest.log").read_text()
next_first = 1
for index in range(8):
    case = names[f'colored-cut-allocation-{index}']
    output = re.search(rf'^\d+/\d+ Testing: {case.attrib["name"]}\n(.*?)^Test Passed\.', full_output, re.M | re.S)[1]
    cut_logs[case.attrib['name']] = output
    measured, first, last = map(int, re.search(r'(\d+) measured cut allocations; checking (\d+) through (\d+)', output).groups())
    assert first == next_first and first <= last <= measured
    denied = last-first+1
    assert f'{denied} actual persistent colored-cut allocation boundaries preserve exact originals and retry' in output
    next_first = last + 1
    shards.append(dict(name=case.attrib['name'], measured=measured, first=first, last=last, denied=denied,
                       seconds=float(case.attrib['time'])))
assert next_first == measured + 1 and sum(i['denied'] for i in shards) == measured
assert all(i['measured'] == measured for i in shards)
(work / "release-cut-shards.json").write_text(json.dumps(cut_logs, indent=2) + "\n")
for name, count in [('native-worker-publication', 16), ('native-worker-generation', 16),
                    ('native-worker-held-publication', 27)]:
    assert f'{count} actual native-thread allocation recovery checks;' in names[name].findtext('system-out')
assert '57 actual affine controller contact/pose/metric/ordered-save checks passed' in (work / 'affine-contact.log').read_text()
assert len(re.findall(r'^27 actual native-thread allocation recovery checks; [1-9]\d* denied allocations',
                      (work / 'held-repeat.log').read_text(), re.M)) == 64

asan_cases = ('native-default','native-held','native-replace','colored-boundaries','colored-first','colored-last')
asan = {name: (work / 'asan' / (name + '.log')).read_text() for name in asan_cases}
assert all('ERROR: AddressSanitizer' not in log and 'runtime error:' not in log and 'FAIL ' not in log for log in asan.values())
assert '27 actual native-thread allocation recovery checks' in asan['native-held']
assert '81 cut color boundary checks' in asan['colored-boundaries']
assert 'checking 1 through 128' in asan['colored-first']
assert f'checking {measured-127} through {measured}' in asan['colored-last']
assert all('128 actual persistent colored-cut allocation boundaries' in asan[name] for name in ('colored-first','colored-last'))

xr = {}
for scenario, count in [('contact-xr-arc', 10), ('contact-xr-software', 10), ('cut-xr-software', 21)]:
    report = json.loads((work / scenario / 'report.json').read_text())
    assert report['failed'] == 0 and all(row['passed'] for row in report['checks'])
    assert len(report['checks']) == count, (scenario, len(report['checks']))
    xr[scenario] = report

state = json.loads((work / 'combined-release/status.json').read_text())
assert state['candidate'] == product
fields = dict(line.split('=', 1) for line in command('systemctl','--user','show',unit,'-p','ActiveState',
              '-p','SubState','-p','ExecMainPID','-p','InvocationID').splitlines())
assert fields['ActiveState'] == 'active' and fields['SubState'] == 'running' and int(fields['ExecMainPID'])
assert not state['terminal'] and fields['InvocationID'] == state['invocation']

names = ['record.py','product.patch','check-asan.py','check-release.sh','check-xr.sh','full-release.py',
         'release-build.log','release-tests.log','release-cut-shards.json','release/held-cut-release.xml','held-repeat.log',
         'repeated-frozen-held.log','frozen-failures.json','xr-helpers.log','affine-contact.log',
         'asan/native-worker-publication.build.log','asan/cut-color-boundaries.build.log']
names += [f'asan/{name}.log' for name in asan]
for scenario in xr:
    names.extend((scenario+'.log',scenario+'/report.json'))
names = sorted(names)
validation = repo / 'docs/validation'
record = 'held-cut-regression-20261127'
bundle = validation / (record + '.tar.gz')
with bundle.open('wb') as output, gzip.GzipFile(fileobj=output, filename='', mode='wb', mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as archive:
        for name in names:
            file = work / name
            info = archive.gettarinfo(str(file), arcname=name)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with file.open('rb') as stream:
                archive.addfile(info, stream)
members = {name: digest(work / name) for name in names}
with tarfile.open(bundle) as archive:
    assert members == {e.name: sha256(archive.extractfile(e).read()).hexdigest() for e in archive}
receipt = {'candidate': product, 'previous_main': previous, 'canonical_domed': domed,
           'source_patch_sha256': sha256(patch).hexdigest(), 'previous_combined_release': old_status,
           'release_tests': sorted(case.attrib['name'] for case in cases),
           'release_application_sha256': digest(work / 'release/dome-sculpt'),
           'release_core_sha256': digest(work / 'release/libdome-sculpt-core.a'),
           'release_exhaustive_cut_allocations': measured, 'release_cut_shards': shards,
           'release_held_repeat_passes': 64, 'release_affine_contact_checks': 57, 'sanitizer_checks': sorted(asan),
           'sanitizer_first_and_last_cut_faults': 256, 'synthetic_controller': xr,
           'next_combined_release': {'process_observation': fields, 'status_at_recording': state},
           'archive_sha256': digest(bundle), 'archive_members_sha256': members}
(validation / (record+'.json')).write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(product, f'Release16 with {measured} exhaustive faults, ASan/UBSan6, held64, synthetic OpenXR proofs')
