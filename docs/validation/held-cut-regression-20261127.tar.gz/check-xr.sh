#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$work/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/release"
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$work/frozen/CMakeLists.txt" "$repo/CMakeLists.txt" --ro-bind "$work/frozen/src" "$repo/src" --ro-bind "$work/frozen/include" "$repo/include" --ro-bind "$work/frozen/tests" "$repo/tests" --bind "$work/release" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${sandbox[@]}" cmake --build "$seed" --parallel 3 --target dome-sculpt-affine-contact-test dome-sculpt-cut-authoring-test > "$work/xr-helpers.log" 2>&1
runtime="$work/release/libdome-sculpt-test-runtime.so"
app="$work/release/dome-sculpt"
helper="$work/release/dome-sculpt-affine-contact-test"
headless=(bwrap --die-with-parent --unshare-all --ro-bind / / --bind "$work" "$work" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LP_NUM_THREADS 2 --setenv MESA_SHADER_CACHE_DISABLE 1)
"${headless[@]}" python3.14 "$work/frozen/tests/affine-contact-xr.py" "$app" "$runtime" "$helper" "$work/contact-xr-software" > "$work/contact-xr-software.log" 2>&1 &
software=$!
"${headless[@]}" python3.14 "$work/frozen/tests/cut-color-xr.py" "$app" "$runtime" "$work/cut-xr-software" > "$work/cut-xr-software.log" 2>&1 &
cut=$!
flock --timeout 180 /tmp/dome-sculpt-arc-device.lock "${headless[@]}" --dev-bind /dev/dri/renderD129 /dev/dri/renderD129 --setenv DRI_PRIME pci-0000_03_00_0 --setenv DOME_CONTACT_XR_HARDWARE 1 python3.14 "$work/frozen/tests/affine-contact-xr.py" "$app" "$runtime" "$helper" "$work/contact-xr-arc" > "$work/contact-xr-arc.log" 2>&1 &
arc=$!
status=0
for test in "$software" "$cut" "$arc"; do wait "$test" || status=1; done
exit "$status"
