#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$work/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/release"
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$work/frozen/CMakeLists.txt" "$repo/CMakeLists.txt" --ro-bind "$work/frozen/src" "$repo/src" --ro-bind "$work/frozen/include" "$repo/include" --ro-bind "$work/frozen/tests" "$repo/tests" --bind "$work/release" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${sandbox[@]}" cmake --build "$seed" --parallel 5 --target dome-sculpt-native-worker-publication-test dome-sculpt-cut-color-boundaries-test dome-sculpt-cut-color-test dome-sculpt-cut-color-document-test dome-sculpt-cut-color-admission-test dome-sculpt-worker-publication-test > "$work/release-build.log" 2>&1
"${sandbox[@]}" ctest --test-dir "$seed" --parallel 6 -R '^(native-worker-(held-publication|publication|generation)|input-worker-publication|colored-(cut-(boundaries|allocation-[0-7]|admission|document)|plane-cut))$' --output-on-failure --output-junit "$seed/held-cut-release.xml" > "$work/release-tests.log" 2>&1
