from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import re
import shlex
import subprocess

work = Path(__file__).resolve().parent
repo = work.parent.parent
seed = work.parent / 'retopology-portable-mtoon-20261127/asan'
core = work.parent / 'texture-set-bake-resize-20261127/asan/libdome-sculpt-core.a'
out = work / 'asan'
out.mkdir(exist_ok=True)
sandbox = ['bwrap', '--die-with-parent', '--unshare-all', '--ro-bind', '/', '/',
           '--bind', out, out, '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp',
           '--tmpfs', '/run/user', '--clearenv', '--setenv', 'PATH', '/usr/bin:/bin',
           '--setenv', 'HOME', '/tmp']
sources = [item for name in ('src', 'include', 'tests')
           for item in ('--ro-bind', work / 'frozen' / name, repo / name)]
native, cut = 'native-worker-publication', 'cut-color-boundaries'

def build(name):
    target = f'dome-sculpt-{name}-test'
    commands = subprocess.check_output(['ninja', '-C', seed, '-t', 'commands', target], text=True).splitlines()
    argv = shlex.split(next(line for line in commands if line.endswith('/tests/' + name + '.cpp')))
    assert '-fsanitize=address,undefined' in argv
    obj = out / (name + '.cpp.o')
    argv[argv.index('-o') + 1] = str(obj)
    if '-MF' in argv:
        argv[argv.index('-MF') + 1] = str(obj.with_suffix('.d'))
    binary = out / target
    with (out / (name + '.build.log')).open('w') as log:
        subprocess.run([*sandbox, *sources, *argv], cwd=seed, stdout=log, stderr=subprocess.STDOUT, check=True)
        link = shlex.split(commands[-1])[2:-2]
        link[link.index('-o') + 1] = str(binary)
        link[link.index(core.name)] = str(core)
        link[link.index(next(term for term in link if term.endswith('/' + obj.name)))] = str(obj)
        link = [term for term in link if not term.startswith('-Wl,--dependency-file=')]
        subprocess.run(link, cwd=seed, stdout=log, stderr=subprocess.STDOUT, check=True)
    return binary

with ThreadPoolExecutor(max_workers=2) as pool:
    native_bin, cut_bin = pool.map(build, (native, cut))

sdk = repo / 'artifacts/sdk-20261126/toolkit-sanitize'
settings = {'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1', 'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1',
            'LD_LIBRARY_PATH': f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
runtime = [*sandbox, *(part for k, v in settings.items() for part in ('--setenv', k, v))]

def check(name, binary, *args):
    log = out / (name + '.log')
    with log.open('w') as stream:
        subprocess.run([*runtime, binary, *map(str, args)], cwd=out, stdout=stream, stderr=subprocess.STDOUT,
                       check=True, timeout=500)
    return log.read_text()

for mode in ('', 'replace', 'held'):
    check('native-' + (mode or 'default'), native_bin, *((mode,) if mode else ()))
check('colored-boundaries', cut_bin)
start = check('colored-first', cut_bin, '--fault-range', 1, 128)
measured = int(re.search(r'^(\d+) measured cut allocations', start, re.M)[1])
check('colored-last', cut_bin, '--fault-range', measured-127, measured)
