from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
source = root / "combined-source"
out = root / "combined-release"
out.mkdir(exist_ok=True)
build = out / "build"
sdk = "/opt/fltk-vr/toolkit"
bitmap = "/opt/fltk-vr/bdf-runtime"
start = time.monotonic()
def git(*args):
    return subprocess.check_output(["git", "-C", source, *args], text=True).strip()
state = {"candidate":git("rev-parse", "HEAD"),"terminal":False,
         "invocation":os.environ.get("INVOCATION_ID")}
def record(**fields):
    state.update(fields, elapsed_seconds=round(time.monotonic()-start, 3))
    temp = out / "status.tmp"
    temp.write_text(json.dumps(state, indent=2)+"\n")
    temp.replace(out / "status.json")
def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()
settings = {"PATH":"/usr/bin:/bin", "PKG_CONFIG_PATH":f"{bitmap}/lib/pkgconfig:/usr/lib64/pkgconfig",
            "LD_LIBRARY_PATH":f"{sdk}/lib:{bitmap}/lib:/usr/lib64","LIBGL_ALWAYS_SOFTWARE":"1",
            "LP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","OMP_NUM_THREADS":"2"}
for variable, name in [("HOME","home"),("XDG_CACHE_HOME","cache"),("XDG_CONFIG_HOME","config"),
                       ("XDG_DATA_HOME","data"),("XDG_RUNTIME_DIR","runtime"),("XDG_STATE_HOME","state")]:
    directory = out / "private" / name
    directory.mkdir(parents=True, mode=0o700, exist_ok=True)
    settings[variable] = str(directory)
prefix = ["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/",
          "--bind",out,out,"--proc","/proc","--dev","/dev","--tmpfs","/tmp",
          "--tmpfs","/run/user","--clearenv"]
for variable, value in settings.items():
    prefix.extend(["--setenv",variable,value])
def run(command, name, timeout, check=True):
    with (out/name).open("w") as log:
        return subprocess.run([*prefix,*command],cwd=out,stdout=log,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check).returncode
try:
    assert not git("status","--porcelain")
    assert not build.exists()
    record(phase="configure fresh Release")
    run(["cmake","-S",source,"-B",build,"-G","Ninja","-DCMAKE_BUILD_TYPE=Release",
         f"-DFLTK_DIR={sdk}/share/fltk","-DDOME_COMPUTE_BACKEND=CPU"],"configure.log",240)
    record(phase="build every registered target")
    run(["cmake","--build",build,"--parallel","6"],"build.log",7200)
    registered = subprocess.check_output([*prefix,"ctest","--test-dir",build,"--show-only=json-v1"],cwd=out)
    (out/"registered.json").write_bytes(registered)
    tests = json.loads(registered)["tests"]
    names = {test["name"] for test in tests}
    assert len(names)==len(tests) and all(test.get("command") for test in tests)
    assert {"texture-set-retained-shapekeys","affine-weight-openxr","vrm1-attachment-openxr",
            "dome-sculpt-texture-set-source-export","surface-heat-real-caller-all-faults","prepared-keys-after-uv-render","retopology-surface-heat-plain","retopology-linked-vrm1","texture-set-mtoon-derivative-tangent",
            "texture-set-mtoon-varying-alpha","retopology-subdivide-seam-plain","retopology-subdivide-seam-affine","retopology-prepared-color-plain","retopology-prepared-color-affine","resolution-quality-host-aggregate","canonical-paint-color-hdr","xr-canonical-paint-color-hdr-export"}<=names
    cut_shards = {f'colored-cut-allocation-{i}' for i in range(8)}
    assert cut_shards <= names and 'colored-cut-allocation' not in names
    assert {'native-worker-held-publication','dome-sculpt-texture-set-baked-resolution',
            'retopology-imported-bake-resize'} <= names
    app = sha(build/"dome-sculpt")
    record(phase="run all Release tests",registered=len(names),app_sha256=app,
           cache_sha256=sha(build/"CMakeCache.txt"))
    junit = out/"full.xml"
    code = run(["ctest","--test-dir",build,"-j6","--output-on-failure","--output-junit",junit],
               "ctest.log",14400,check=False)
    cases = ET.parse(junit).getroot().findall(".//testcase")
    assert len(cases)==len(names) and {case.attrib["name"] for case in cases}==names
    failed = sorted(case.attrib["name"] for case in cases if case.find("failure") is not None)
    skipped = sorted(case.attrib["name"] for case in cases if case.find("skipped") is not None)
    assert sha(build/"dome-sculpt")==app
    assert git("rev-parse","HEAD")==state["candidate"] and not git("status","--porcelain")
    record(phase="complete",terminal=True,exit=code,
           totals={"pass":len(cases)-len(failed)-len(skipped),"fail":len(failed),"skip":len(skipped)},
           failed=failed,skipped=skipped,junit_sha256=sha(junit))
except Exception as e:
    record(terminal=True,exit=1,error=repr(e))
    raise
raise SystemExit(state["exit"])
