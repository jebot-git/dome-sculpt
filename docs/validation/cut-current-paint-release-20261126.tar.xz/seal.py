from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

here=Path(__file__).resolve().parent
artifacts=here.parent
docs=artifacts.parent/'docs/validation'
source=artifacts/'cut-current-paint-source-20261126'
plan=json.loads((here/'build-plan.json').read_text())
built=json.loads((here/'build-status.json').read_text())
native=json.loads((here/'native/status.json').read_text())
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args])
commit=git('rev-parse','HEAD').decode().strip()
assert not git('status','--porcelain')
assert hashlib.sha256(git('diff','--binary','c5fbb0bd','HEAD')).hexdigest()==plan['source_diff_sha256']
assert built['terminal'] and built['exit']==0 and built['linked_archive']['replacements']==['document-cut.cpp.o']
assert built['linked_archive']['members']==197 and len(built['compile'])==4 and len(built['links'])==4
assert native['terminal'] and native['exit']==0 and len(native['cases'])==3
assert all(row['exit']==0 and row['check_passed'] for row in native['cases'].values())
broad=artifacts/'production-full-regression-release-20261126/full-private-ctest/ctest.log'
original=broad.read_text()
failures=here/'broad-original-cut-test.log'
m=re.search(r'^.*Test +#\d+: cut-cancellation-boundaries +[.]+\*\*\*Failed[^\n]*\n(?:(?!^ +Start ).*\n)*',original,re.M)
assert m and 'The same preview can be explicitly retried' in m[0]
failures.write_text(m[0])
trigger=artifacts/'cut-retry-diagnostic-20261126'
assert 'error=Invalid texture image' in (trigger/'result.log').read_text()
assert '174 of 174' in (here/'native/dome-sculpt-cut-color-admission-test.log').read_text()
assert '157 native/controller colored cut checks' in (here/'native/dome-sculpt-cut-color-document-test.log').read_text()
for name in ('result.log','commands.json','cut-boundaries.cpp'):
    (here/('diagnostic-'+name)).write_bytes((trigger/name).read_bytes())
paths=[here/p for p in ('prepare.py','build.py','run-native.py','owned_monitor.py','build-plan.json','build-status.json','native/status.json','seal.py','diagnostic-commands.json','diagnostic-cut-boundaries.cpp')]
paths+=sorted(here.glob('*.d'))+sorted(here.glob('*.log'))+sorted((here/'native').glob('*.log'))
archive=docs/'cut-current-paint-release-20261126.tar.xz'
manifest={}
with tarfile.open(archive,'w:xz',preset=6) as f:
    for path in paths:
        key=str(path.relative_to(here))
        assert key not in manifest
        data=path.read_bytes()
        member=tarfile.TarInfo(key)
        member.size=len(data)
        manifest[key]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        f.addfile(member,io.BytesIO(data))
with tarfile.open(archive,'r:xz') as f:
    assert set(f.getnames())==set(manifest)
    for file in f:
        assert file.size==manifest[file.name]['bytes']
        assert hashlib.file_digest(f.extractfile(file),'sha256').hexdigest()==manifest[file.name]['sha256']
receipt={'source':commit,'baseline':'c5fbb0bd','build_invocation':'92fe175aa3974bbea26ae0730bd72000',
         'native_invocation':'285e6d47a57e4b57abc13352fa514f41',
         'scope':'Actual private Release plain current-grid plane cut and desktop/controller cancel and retry, colored cut admission faults and held/source authoring controls.',
         'build':built,'native':native,'authorities':manifest,
         'archive':{'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}}
archive.with_name(archive.name.replace('.tar.xz','.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(commit,len(paths),receipt['archive'])
