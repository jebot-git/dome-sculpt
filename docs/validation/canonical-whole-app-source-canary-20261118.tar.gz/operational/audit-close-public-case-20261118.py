"""Audit an already-terminal authorized case and stop only its named finished unit."""
import argparse,fcntl,hashlib,json,os,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
def main(a):
 out=P/('release-'+a.workflow+'-'+a.phase+'-'+a.case+'-'+a.tag)
 status=out/'status.json';s=json.loads(status.read_text());assert s['state']=='terminal'
 u=a.unit if a.unit.endswith('.service')else a.unit+'.service'
 text=subprocess.check_output(['systemctl','--user','show',u],text=True);props=dict(x.split('=',1)for x in text.splitlines()if'='in x)
 assert props['MainPID']=='0'and props['SubState']in ['exited','failed','dead']
 (out/'unit-final.txt').write_text(text);(out/'unit-journal.txt').write_text(subprocess.check_output(['journalctl','--user','-u',u,'--no-pager'],text=True))
 subprocess.run(['systemctl','--user','stop',u],check=True)
 (out/'unit-stopped.txt').write_text(subprocess.check_output(['systemctl','--user','show',u,'-p','ActiveState','-p','SubState','-p','ExecMainStatus','-p','Result'],text=True))
 apps=s.get('actual_app_pids',[]);absent=all(not(Path('/proc')/str(pid)).exists()for pid in apps)
 f=Path('/tmp/dome-sculpt-arc-device.lock').open('a+')
 try:
  try:
   fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(f.fileno());nb={'free':True,'epoch':time.time(),'inode':st.st_ino,'dev':st.st_dev};fcntl.flock(f,fcntl.LOCK_UN)
  except BlockingIOError:nb={'free':False,'epoch':time.time(),'reason':'Lease currently held; no next product authorized by this audit'}
 finally:f.close()
 report=out/'workflow/report.json';r=json.loads(report.read_text())if report.exists()else None
 proof={'state':'terminal','actual_exit':s['exit'],'workflow':a.workflow,'phase':a.phase,'case':a.case,'status_sha256':hashlib.sha256(status.read_bytes()).hexdigest(),'checks':s.get('checks'),'scenario_complete':r.get('complete')if r else None,'seconds':s.get('seconds'),'error':s.get('error'),'actual_App_PIDs':apps,'all_Apps_absent':absent,'remaining_owned':s.get('remaining_owned_processes'),'input_pin_count':len(s['pins']),'input_drift':s['input_drift'],'critical_observed':s.get('critical_observed'),'device_reports':s.get('device_reports'),'unit_ExecMainStatus':int(props['ExecMainStatus']),'unit_Result':props['Result'],'unit_stopped':True,'lease_released':s.get('lease_released_epoch'),'independent_NB':nb}
 (out/'closure-20261118.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
 assert s['exit']==0 and not s['input_drift']and not s['remaining_owned_processes']and len(apps)==2 and absent and nb['free']and props['ExecMainStatus']=='0'and props['Result']=='success'
 assert r and r['complete']and not r['error']and not r['drift']and all(x['passed']for x in r['checks'])
 if a.expected_checks is not None:assert s['checks']==a.expected_checks
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workflow',choices=['source-use','uv-create'],required=True);p.add_argument('--phase',choices=['gui','xr'],required=True);p.add_argument('--case',required=True);p.add_argument('--tag',required=True);p.add_argument('--unit',required=True);p.add_argument('--expected-checks',type=int);main(p.parse_args())
