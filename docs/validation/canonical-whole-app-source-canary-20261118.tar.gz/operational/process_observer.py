"""Passive /proc identity evidence. Never launches, signals or waits for processes."""
import json,os,time
from pathlib import Path
class ProcessObserver:
 def __init__(self,out,identity):
  self.out=Path(out);self.identity=identity;self.rows={};self.started=time.monotonic()
 def capture(self,pid,expected,stage,force=False):
  now=self.identity(pid);row={'pid':pid,'stage':stage,'elapsed':time.monotonic()-self.started,'epoch':time.time(),'expected':expected}
  if now is None or now['start']!=expected['start']:
   row.update(present=False,identity=now)
  else:
   row.update(present=True,identity=now)
   proc=Path('/proc')/str(pid)
   for name,read in [('cmdline',lambda:(proc/'cmdline').read_bytes().split(b'\0')),('exe',lambda:os.readlink(proc/'exe'))]:
    try:
     value=read();row[name]=[v.decode(errors='replace')for v in value if v]if name=='cmdline'else value
    except(FileNotFoundError,ProcessLookupError,PermissionError)as e:row[name+'_error']=type(e).__name__
   after=self.identity(pid);row['identity_after_read']=after
   row['stable_start_during_read']=after is not None and after['start']==now['start']
  key=str(pid)+':'+str(expected['start']);prior=self.rows.get(key)
  signature=lambda d:(d.get('present'),d.get('exe'),d.get('cmdline'),(d.get('identity')or{}).get('ppid'),(d.get('identity')or{}).get('pgrp'))
  if force or prior is None or signature(prior['last'])!=signature(row):
   with(self.out/'owned-process-observations.jsonl').open('a')as stream:stream.write(json.dumps(row)+'\n')
  if prior is None:self.rows[key]={'first':row,'last':row}
  else:prior['last']=row
  return row
 def snapshot(self,owned,stage):
  rows=[self.capture(pid,expected,stage,True)for pid,expected in owned.items()]
  path=self.out/('owned-processes-'+stage+'.json');path.write_text(json.dumps({'stage':stage,'epoch':time.time(),'processes':rows},indent=2)+'\n')
  (self.out/'owned-process-ledger.json').write_text(json.dumps(self.rows,indent=2)+'\n')
  return rows
