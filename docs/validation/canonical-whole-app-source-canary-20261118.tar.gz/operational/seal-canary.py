"""Seal only completed fresh whole-App desktop and matching Arc-XR canaries."""
import hashlib,json,pathlib,tarfile
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1];B=R/'artifacts/authoring-canonical-public-release-20261118';PROOF=R/'artifacts/advanced-public-normal-proof-20261117';OUT=PROOF/'docs/validation';STEM='canonical-whole-app-source-canary-20261118';TAG='whole8a-canary-v1-20261118';APP='d64c26081d2d4ba8db83033316a20d8e9eed50d31c956b03726b4f8549b59331'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
files={};rows=[];maximum=0;source_tuple=None;apps=set()
for phase,wanted in [('gui',16),('xr',65)]:
 d=P/('release-source-use-'+phase+'-raster-mt1-rest-'+TAG);s=json.loads((d/'status.json').read_text());c=json.loads((d/'closure-20261118.json').read_text());report=json.loads((d/'workflow/report.json').read_text());provider=json.loads((d/'provider-admission.json').read_text())
 assert s['state']=='terminal'and s['exit']==0 and s['checks']==wanted and len(s['actual_app_pids'])==2 and not s['input_drift']and not s['remaining_owned_processes'];apps.update(s['actual_app_pids'])
 assert s['critical_expected_ELFs']['consumer']['sha256']==APP and provider['targets']['app']['sha256']==APP
 assert c['actual_exit']==0 and c['status_sha256']==sha(d/'status.json')and c['all_Apps_absent']and c['unit_stopped']and c['unit_ExecMainStatus']==0 and c['unit_Result']=='success'and c['independent_NB']['free']
 assert report['complete']and not report['error']and not report['drift']and all(v['passed']for v in report['checks'])
 assert source_tuple in [None,s['source_tuple']];source_tuple=s['source_tuple'];native=[]
 for f in sorted((d/'workflow').rglob('native-*.json')):
  n=json.loads(f.read_text());assert n['verified'];o=n.get('normal_oracle')
  if o:
   assert o['finite_samples']and o['maximum_allowed_error']==.035 and o['minimum_negative_error']==.05;maximum=max(maximum,*o['maximum_component_error']);assert all(x>.05 for role in ['wrong_domain','omitted','swapped']for x in o[role])
  native.append({'path':str(f.relative_to(P)),'verification':n,'sha256':sha(f)})
 assert len(native)==4
 rows.append({'phase':phase,'status_sha256':sha(d/'status.json'),'checks':s['checks'],'seconds':s['seconds'],'peak_RSS':s['peak_RSS'],'input_pin_count':len(s['pins']),'critical_expected_ELFs':s['critical_expected_ELFs'],'critical_observed':s['critical_observed'],'device_reports':s.get('device_reports'),'actual_private_Xvfb':s.get('actual_private_Xvfb'),'closure':c,'report':report,'native_verifications':native,'whole_application_build_authority':provider['whole_application_build_authority'],'loader_admission':provider['component_loader_admission']})
 for f in d.rglob('*'):
  if f.is_file():files[str(f.relative_to(P))]=f
assert len(apps)==4 and maximum<.035
for f in P.rglob('*'):
 if f.is_file()and ((f.parent==P and f.suffix in ['.py','.json','.txt'])or f.relative_to(P).parts[0]in ['scenarios','bin']):files['operational/'+str(f.relative_to(P))]=f
for path in json.loads((P/'whole-app-authorities.json').read_text()):
 f=pathlib.Path(path);files['whole-app-authorities/'+f.name]=f
machine=R/'docs/validation/CANONICAL-PUBLIC-RELEASE-APP-20261118.json';m=json.loads(machine.read_text());archive_source=machine.parent/m['archive']['file'];assert sha(archive_source)==m['archive']['sha256'];files['whole-app-authorities/'+machine.name]=machine;files['whole-app-authorities/'+archive_source.name]=archive_source
archive=OUT/(STEM+'.tar.gz');assert not archive.exists();members={}
with tarfile.open(archive,'w:gz',compresslevel=6)as tar:
 for name,f in sorted(files.items()):assert not f.is_symlink();members[name]=sha(f);tar.add(f,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 assert set(tar.getnames())==set(members)
 for member in tar:assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==members[member.name]
j={'state':'terminal','exit':0,'case':'raster-mt1-rest','checks':81,'GUI_checks':16,'XR_checks':65,'fresh_Apps':4,'application_sha256':APP,'source_tuple':source_tuple,'maximum_normal_component_error':maximum,'normal_bound_unchanged':.035,'negative_normal_bound_unchanged':.05,'rows':rows,'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':members},'scope':'One source-use integration canary on the actual fresh coherent whole App8a/production85. Separate original expected fixture91b/27ff/product90fad, runtimee6c/scenarios8bb/font1afa remain explicit. No full application matrix, sanitizer inference, physicalHMD or main production85 admission.'};(OUT/(STEM+'.json')).write_text(json.dumps(j,indent=2)+'\n');print(json.dumps({k:v for k,v in j.items()if k not in ['rows','archive']},indent=2));print('Archive',j['archive']['sha256'],j['archive']['bytes'])
