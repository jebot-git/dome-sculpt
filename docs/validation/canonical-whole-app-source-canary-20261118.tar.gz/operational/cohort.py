"""One coherent fresh whole-App canary with explicitly separate native fixtures."""
import importlib.util,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1];BASE_ROOT=R/'artifacts/advanced-public-normal-operational-20261117'
_spec=importlib.util.spec_from_file_location('frozen_advanced_base_cohort',BASE_ROOT/'cohort.py');base=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(base)
for _name in ['S','B','HEAD','G','sha','write','verify','merge_pins','SOURCE','FIXTURE_SOURCE']:globals()[_name]=getattr(base,_name)
CASES=['raster-mt1-rest']
APPLICATION_SOURCE='8a8ecea1b1b37b5ed317a99af2d48c9f2b2fa9c2'
PRODUCT_SOURCE='85eafc420b0319ae9c3a553336df617590a6946d'
APP_SHA='d64c26081d2d4ba8db83033316a20d8e9eed50d31c956b03726b4f8549b59331'
WHOLE=R/'artifacts/authoring-canonical-public-release-20261118';FROZEN=R/'artifacts/authoring-canonical-public-integration-20261118'
SOURCE_TUPLE={'product':PRODUCT_SOURCE,'application_source':APPLICATION_SOURCE,'native_fixture':base.SOURCE,'native_fixture_product':base.APPLICATION_SOURCE,'runtime_scenarios':base.SCENARIO_SOURCE,'UI_and_asset_source':APPLICATION_SOURCE,'font':base.SOURCE_TUPLE['font']}
TARGETS={key:dict(value)for key,value in base.TARGETS.items()};TARGETS['app']={'path':str(WHOLE/'dome-sculpt'),'sha256':APP_SHA}
AUTHORITY_SHA='e0c97a2e949866f3187903a5398fab3723ea87e1531c93b7d7369386064e95d7'
def admit(profile,native_status,native_sha,workflow,case):
 assert workflow=='source-use'and case=='raster-mt1-rest'
 prior=base.admit(profile,native_status,native_sha,workflow,case);pins=dict(prior['pins'])
 assert sha(P/'whole-app-authorities.json')==AUTHORITY_SHA
 authorities=json.loads((P/'whole-app-authorities.json').read_text());assert not verify(authorities);merge_pins(pins,authorities)
 plan=json.loads((WHOLE/'build-plan.json').read_text());receipt=json.loads((WHOLE/'build-receipt.json').read_text());status=json.loads((WHOLE/'build-status.json').read_text())
 assert plan['source']==receipt['source']==status['source']==APPLICATION_SOURCE
 assert receipt['state']=='fresh_application_build_only'and receipt['exit']==0 and status['state']=='terminal'and status['exit']==0 and not status['input_drift']
 assert receipt['application_sha256']==status['application_sha256']==APP_SHA and sha(WHOLE/'dome-sculpt')==APP_SHA
 assert receipt['complete_actual_MD_owners']==status['genuine_compiler_depfile_count']==242 and receipt['core_members']==193 and receipt['dependency_incidences']==93903 and receipt['unique_actual_dependency_paths']==1623
 assert receipt['unit_InvocationID']=='7d8c6f8b6e694690b7970cc3e097a259'and receipt['unit_Result']=='success'
 for file,key in [('build-plan.json','source_plan'),('build-status.json','status'),('actual-MD-owners.json','actual_MD_owners'),('actual-MD-inputs.json','actual_MD_inputs')]:assert sha(WHOLE/file)==receipt[key]
 merge_pins(pins,plan['source_input_pins']);deps=json.loads((WHOLE/'actual-MD-inputs.json').read_text());assert len(deps)==1623;merge_pins(pins,deps)
 owners=json.loads((WHOLE/'actual-MD-owners.json').read_text());assert len(owners)==242 and sum('/dome-sculpt-core.dir/'in x['object']for x in owners)==193
 for owner in owners:
  for name,key in [('object','sha256'),('actual_compiler_MD','MD_sha256')]:
   f=WHOLE/owner[name];assert sha(f)==owner[key];merge_pins(pins,{str(f):owner[key]})
 link=json.loads((WHOLE/'actual-link-inputs.json').read_text());assert len(link)==174
 for row in link:
  for key in ['literal','resolved']:
   f=Path(row[key]);assert f.is_file()and sha(f)==row['sha256'];merge_pins(pins,{str(f):row['sha256']})
  if Path(row['resolved']).name.startswith('libdome-sculpt-')and Path(row['resolved']).suffix=='.a':assert Path(row['resolved']).parent==WHOLE
 assert (WHOLE/'libdome-sculpt-core.a').exists()
 members=subprocess.check_output(['/usr/bin/ar','t',str(WHOLE/'libdome-sculpt-core.a')],text=True).splitlines();assert len(members)==193
 integration=FROZEN/'docs/validation/CANONICAL-PUBLIC-INTEGRATION-DRAFT-20261118.json';composition=json.loads(integration.read_text());assert composition['production_source']==PRODUCT_SOURCE and composition['production_file_count']==765 and not composition['production_differences']and len(composition['production_files'])==765
 for name,h in composition['production_files'].items():assert sha(FROZEN/name)==h;merge_pins(pins,{str(FROZEN/name):h})
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=FROZEN,text=True).strip()==APPLICATION_SOURCE and not subprocess.check_output(['git','status','--porcelain'],cwd=FROZEN,text=True)
 loader_file=WHOLE/'loader-version-status.json';loader=json.loads(loader_file.read_text());assert loader['state']=='terminal'and loader['exit']==0 and loader['source']==APPLICATION_SOURCE and loader['application_sha256']==APP_SHA and len(loader['providers'])==72 and len(loader['steps'])==2 and all(x['exit']==0 for x in loader['steps'])
 prior_providers=json.loads(base.NATIVE.read_text())['providers']['app'];assert {(x['literal'],x['resolved'],x['sha256'])for x in loader['providers']}=={(x['literal'],x['resolved'],x['sha256'])for x in prior_providers}
 assert loader['prior_provider_status_sha256']==base.NATIVE_SHA and loader['lease_released']>=loader['lease_acquired']and loader['independent_NB_free']>=loader['lease_released']
 for provider in loader['providers']:
  for key in ['literal','resolved']:assert sha(provider[key])==provider['sha256'];merge_pins(pins,{provider[key]:provider['sha256']})
 canonical=R/'artifacts/artist-canonical-normal-compile-20261117/native-snapshot-v1/status.json';assert sha(canonical)=='da83c133ef1e1122628d45c9de872e44bd4fe38b24c4b4338c70dcac2620b961';n=json.loads(canonical.read_text());assert n['terminal']and n['exit_code']==0 and n['source']==PRODUCT_SOURCE and not n['input_drift']and not n['owned_remaining']
 advanced=next(x for x in n['steps']if x['name']=='source-advanced-normal-bake');assert advanced['exit']==0 and advanced['actual_pass_count']==263495 and len(advanced['ordered_pairs'])==17
 provenance=json.loads((P/'scenario-provenance.json').read_text());assert provenance['application_source']==APPLICATION_SOURCE and provenance['production_source']==PRODUCT_SOURCE
 for row in provenance['scenarios'].values():assert sha(row['source'])==sha(row['copy'])==row['sha256'];merge_pins(pins,{row['source']:row['sha256'],row['copy']:row['sha256']})
 for f in [P/'whole-app-authorities.json',P/'scenario-provenance.json',P/'cohort.py',WHOLE/'dome-sculpt']:merge_pins(pins,{str(f):sha(f)})
 assert not verify(pins)
 loader_admission={'path':str(loader_file),'sha256':sha(loader_file),'App_provider_count':72,'version_exit':0,'application_source':APPLICATION_SOURCE,'application_sha256':APP_SHA}
 return {**prior,'pins':pins,'targets':TARGETS,'source_tuple':SOURCE_TUPLE,'component_loader_admission':loader_admission,'whole_application_build_authority':{'source':APPLICATION_SOURCE,'production':PRODUCT_SOURCE,'application_sha256':APP_SHA,'authorities':authorities,'actual_complete_MD_owners':242,'actual_core_members':193,'actual_MD_incidences':93903,'actual_link_incidences':174,'native_advanced17_compatibility_status':str(canonical)},'scope':'Fresh coherent whole Appd64c source8a/production85 with separate original qualified native91b/fixture27ff/product90fad, runtimee6c/scenarios8bb and font1afa/source6c8. One source-use canary only; no inherited full matrix, sanitizer, Wayland, HMD or main admission.'}
