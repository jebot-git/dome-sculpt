"""Execute the authorized fresh-App GUI canary, then only its matching XR canary."""
import hashlib,json,pathlib,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent;TAG='whole8a-canary-v1-20261118';CASE='raster-mt1-rest'
for phase in ['gui','xr']:
 review=P/('parent-authorized-source-use-'+phase+'-20261118.json');h=hashlib.sha256(review.read_bytes()).hexdigest();unit='ds-advanced-source-use-'+phase+'-'+CASE+'-'+TAG+'.service'
 cmd=[sys.executable,str(P/'launch-one-parent-authorized-20261118.py'),'--workflow','source-use','--phase',phase,'--case',CASE,'--tag',TAG,'--gui-tag',TAG,'--review',str(review),'--review-sha',h]
 subprocess.run(cmd,check=True);print('LAUNCHED '+unit,flush=True);deadline=time.monotonic()+620
 while True:
  props=dict(x.split('=',1)for x in subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','SubState'],text=True).splitlines())
  if props['MainPID']=='0'and props['SubState']in ['exited','dead','failed']:break
  if time.monotonic()>deadline:raise TimeoutError(('Inspect actual unit; do not restart',unit))
  time.sleep(2)
 subprocess.run([sys.executable,str(P/'audit-close-public-case-20261118.py'),'--workflow','source-use','--phase',phase,'--case',CASE,'--tag',TAG,'--unit',unit,'--expected-checks','16'if phase=='gui'else'65'],check=True)
 print('CLOSED '+unit,flush=True)
