from pathlib import Path
import json,hashlib,subprocess,sys,shlex
root=Path('/home/blux/de-xr/dome-sculpt');src=root/'artifacts/capacity-traffic-observer-20261111';provider=root/'artifacts/authoring-query-owning-20261111';profile=sys.argv[1]if len(sys.argv)>1 else'release';out=root/'artifacts/capacity-actual-streams-proof-20261111'/profile;out.mkdir(parents=True,exist_ok=True)
status=provider/(profile+'-resume')/'status.json';data=json.loads(status.read_text());assert data['exit']==0 and not data['pin_drift'] and not data['output_drift']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','diff','44be6d0d','HEAD','--','include','src','assets','third_party'],cwd=src,text=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True)
record={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'provider_source':data['source'],'provider_status':str(status),'provider_status_sha256':sha(status),'commands':[],'pins':{}}
objkey='CMakeFiles/dome-sculpt-document-render-capacity-test.dir/tests/document-render-capacity.cpp.o';cmd=data['fresh_objects'][objkey]['command'];old=str(root/'artifacts/authoring-query-final-20261111');cmd=[v.replace(old,str(src))for v in cmd];cmd[cmd.index('-o')+1]=str(out/'capacity.cpp.o')
def run(a,name):
 with (out/name).open('w')as log:
  log.write(shlex.join(a)+'\n');log.flush();p=subprocess.run(a,cwd=out,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'command':a,'log':name,'exit':p.returncode})
 if p.returncode:raise RuntimeError(name)
run(cmd,'compile.log')
steps=data['steps'];link=next(s['command']for s in steps if s['name']=='link-dome-sculpt-document-render-capacity-test');link=list(link);link=[v for v in link if not v.startswith('-Wl,--dependency-file=')]
for i,v in enumerate(link):
 if v.endswith('tests/document-render-capacity.cpp.o'):link[i]=str(out/'capacity.cpp.o')
link[link.index('-o')+1]=str(out/'capacity-trace')
for v in link:
 p=Path(v)
 if v.startswith('/')and p.is_file()and v not in [str(out/'capacity.cpp.o')]:record['pins'][v]=sha(p)
core=str(provider/profile/'libdome-sculpt-core.a');assert record['pins'][core]==data['core_archive']['sha256']
run(link,'link.log');record['elf_sha256']=sha(out/'capacity-trace');record['elf']=str(out/'capacity-trace');record['drift']=[p for p,h in record['pins'].items()if sha(p)!=h];assert not record['drift'];(out/'build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['source','provider_source','elf','elf_sha256','drift']},indent=2))
