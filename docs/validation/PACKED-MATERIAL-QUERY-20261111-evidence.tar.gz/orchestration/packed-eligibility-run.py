from pathlib import Path
import hashlib,json,os,resource,signal,subprocess,sys,time
root=Path('/home/blux/de-xr/dome-sculpt');source=root/'artifacts/packed-query-eligibility-20261111';profile=sys.argv[1];mode=sys.argv[2];out=root/'artifacts/packed-eligibility-proof-20261111'/profile;status=json.loads((out/'build.json').read_text());assert status['exit']==0;binary=out/('dome-sculpt-packed-material-query-test'if mode=='native'else'dome-sculpt-document-render-capacity-test');cmd=[str(binary)]+(['--large-buffer']if mode=='large'else[]);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==h for p,h in status['outputs'].items());assert all(sha(p)==h for p,h in status['source_pins'].items());record={'source':status['source'],'profile':profile,'mode':mode,'argv':cmd,'timeout_seconds':180 if mode=='native'else 240,'rss_limit_bytes':(8 if profile=='sanitize'else 4)*1024**3};env=os.environ.copy()
for k in ['DRI_PRIME','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','LSAN_OPTIONS']:env.pop(k,None)
env.update(LD_LIBRARY_PATH='/usr/lib64',LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1');start=time.monotonic();guard=None
with(out/(mode+'.log')).open('w')as log:
 p=subprocess.Popen(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  try:
   row=next(x for x in Path(f'/proc/{p.pid}/status').read_text().splitlines()if x.startswith('VmRSS:'));rss=int(row.split()[1])*1024
   if rss>record['rss_limit_bytes']:guard='rss';os.killpg(p.pid,signal.SIGKILL);break
  except(OSError,StopIteration):pass
  if time.monotonic()-start>record['timeout_seconds']:guard='deadline';os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.01)
 record['exit']=p.wait()
record.update(seconds=time.monotonic()-start,guard=guard,maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss);record['provider_drift']=[p for p,h in status['pins'].items()if sha(p)!=h];record['source_drift']=[p for p,h in status['source_pins'].items()if sha(p)!=h];record['output_drift']=[p for p,h in status['outputs'].items()if sha(p)!=h];record['elf_sha256']=sha(binary);record['log_sha256']=sha(out/(mode+'.log'));(out/(mode+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2));sys.exit(0 if record['exit']==0 and not guard and not record['provider_drift']and not record['source_drift']and not record['output_drift']else 1)
