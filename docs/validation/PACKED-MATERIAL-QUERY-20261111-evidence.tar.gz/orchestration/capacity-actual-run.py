from pathlib import Path
import hashlib,json,os,resource,signal,subprocess,sys,time
root=Path('/home/blux/de-xr/dome-sculpt');source=root/'artifacts/capacity-traffic-observer-20261111';profile=sys.argv[2]if len(sys.argv)>2 else'release';out=root/'artifacts/capacity-actual-streams-proof-20261111'/profile;mode=sys.argv[1];cmd=[str(out/'capacity-trace')]+(['--large-buffer']if mode=='large'else[]);record={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'mode':mode,'argv':cmd,'timeout_seconds':240,'rss_limit_bytes':(8 if profile=='sanitize'else 4)*1024**3};env=os.environ.copy()
for k in ['DRI_PRIME','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','LSAN_OPTIONS']:env.pop(k,None)
env.update(LD_LIBRARY_PATH='/usr/lib64',LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2');env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1');start=time.monotonic();guard=None
with(out/(mode+'.log')).open('w')as log:
 p=subprocess.Popen(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  try:
   row=next(x for x in Path(f'/proc/{p.pid}/status').read_text().splitlines()if x.startswith('VmRSS:'));rss=int(row.split()[1])*1024
   if rss>record['rss_limit_bytes']:guard='rss';os.killpg(p.pid,signal.SIGKILL);break
  except(OSError,StopIteration):pass
  if time.monotonic()-start>240:guard='deadline';os.killpg(p.pid,signal.SIGKILL);break
  time.sleep(.01)
 record['exit']=p.wait()
record.update(seconds=time.monotonic()-start,guard=guard,maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss);status=json.loads((out/'build.json').read_text());record['provider_drift']=[q for q,h in status['pins'].items()if hashlib.sha256(Path(q).read_bytes()).hexdigest()!=h];record['source_drift']=subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip();record['elf_sha256']=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest();record['log_sha256']=hashlib.sha256((out/(mode+'.log')).read_bytes()).hexdigest();(out/(mode+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
