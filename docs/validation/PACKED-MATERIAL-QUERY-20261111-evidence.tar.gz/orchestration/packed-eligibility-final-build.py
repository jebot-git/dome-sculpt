from pathlib import Path
import json,hashlib,subprocess,sys,shlex,concurrent.futures,shutil,time
root=Path('/home/blux/de-xr/dome-sculpt');src=root/'artifacts/packed-query-eligibility-20261111';provider=root/'artifacts/authoring-query-owning-20261111';profile=sys.argv[1]if len(sys.argv)>1 else'release';out=root/'artifacts/packed-eligibility-final-proof-20261111'/profile;out.mkdir(parents=True,exist_ok=True)
status=provider/(profile+'-resume')/'status.json';data=json.loads(status.read_text());assert data['exit']==0 and not data['pin_drift']and not data['output_drift']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=src,text=True)
record={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'profile':profile,'provider_source':data['source'],'provider_status':str(status),'provider_status_sha256':sha(status),'steps':[],'pins':{},'source_pins':{}}
for rel in subprocess.check_output(['git','ls-files','src','include','tests/packed-material-query.cpp','tests/document-render-capacity.cpp'],cwd=src,text=True).splitlines():record['source_pins'][str(src/rel)]=sha(src/rel)
old=str(root/'artifacts/authoring-query-final-20261111');objects={}
def run(a,name):
 start=time.monotonic()
 with(out/(name+'.log')).open('w')as log:
  log.write(shlex.join(a)+'\n');log.flush();p=subprocess.run(a,cwd=out,stdout=log,stderr=subprocess.STDOUT)
 entry={'name':name,'command':a,'exit':p.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(out/(name+'.log'))};record['steps'].append(entry)
 if p.returncode:raise RuntimeError(name)
keys=['CMakeFiles/dome-sculpt-core.dir/src/material-visibility.cpp.o','CMakeFiles/dome-sculpt-core.dir/src/mesh-processing.cpp.o','CMakeFiles/dome-sculpt-packed-material-query-test.dir/tests/packed-material-query.cpp.o','CMakeFiles/dome-sculpt-document-render-capacity-test.dir/tests/document-render-capacity.cpp.o']
def compile(key):
 cmd=[v.replace(old,str(src))for v in data['fresh_objects'][key]['command']];obj=out/Path(key).name;cmd[cmd.index('-o')+1]=str(obj);run(cmd,'compile-'+obj.name);objects[key]=str(obj)
try:
 # Two product ownership units first, then two matched independent consumers.
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(compile,keys[:2]))
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(compile,keys[2:]))
 original=provider/profile/'libdome-sculpt-core.a';record['pins'][str(original)]=sha(original);assert sha(original)==data['core_archive']['sha256'];core=out/'libdome-sculpt-core.a';shutil.copyfile(original,core)
 run(['/usr/bin/ar','r',str(core),objects[keys[0]],objects[keys[1]]],'replace-two-owning-members');run(['/usr/bin/ranlib',str(core)],'ranlib');members=subprocess.check_output(['/usr/bin/ar','t',str(core)],text=True).splitlines();assert len(members)==data['core_archive']['members']
 record['core']={'path':str(core),'sha256':sha(core),'members':len(members),'replaced':[objects[keys[0]],objects[keys[1]]]}
 for target,key in [('dome-sculpt-packed-material-query-test',keys[2]),('dome-sculpt-document-render-capacity-test',keys[3])]:
  cmd=list(next(s['command']for s in data['steps']if s['name']=='link-'+target));cmd=[x for x in cmd if not x.startswith('-Wl,--dependency-file=')]
  for i,v in enumerate(cmd):
   if v.endswith(str(Path(key))):cmd[i]=objects[key]
   elif v==str(original):cmd[i]=str(core)
  cmd[cmd.index('-o')+1]=str(out/target)
  for v in cmd:
   p=Path(v)
   if v.startswith('/')and p.is_file()and p!=core and v not in objects.values():record['pins'][v]=sha(p)
  run(cmd,'link-'+target)
 record['outputs']={str(p):sha(p)for p in [core,*[Path(o)for o in objects.values()],out/'dome-sculpt-packed-material-query-test',out/'dome-sculpt-document-render-capacity-test']}
 record['provider_drift']=[p for p,h in record['pins'].items()if sha(p)!=h];record['source_drift']=[p for p,h in record['source_pins'].items()if sha(p)!=h];assert not record['provider_drift']and not record['source_drift'];record['exit']=0
except Exception as e:record['exit']=1;record['error']=str(e);raise
finally:(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['source','profile','provider_source','core','exit']},indent=2))
