"""Observe the existing owned build only; never launch or restart a build/product."""
from pathlib import Path
import hashlib,json,subprocess,time,shlex
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent
A=R/'artifacts/native90-sanitize-planning-20261115/sanitize-090f00-20261117-audit';UNIT='ds-native90-sanitize-build-v2-20261117.service';INV='f2bcbf89dda84a1dae2590e06d016dd4';PID='2140804';PLAN_SHA='62116c27b70b37459d186e037acc51984d34fac8262760e5f50351ac8c21f8d9';HEAD='090f009ede2c0623ca616fe892223b4f68f1c2c4'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,d):
 t=p.with_suffix(p.suffix+'.writing');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
def props():
 text=subprocess.check_output(['systemctl','--user','show',UNIT,'--property=LoadState,ActiveState,SubState,MainPID,ExecMainPID,Result,ExecMainCode,ExecMainStatus,InvocationID,ControlGroup,MemoryPeak,MemoryMax,RuntimeMaxUSec,ExecMainStartTimestampMonotonic,ExecMainExitTimestampMonotonic'],text=True)
 return text,dict(x.split('=',1)for x in text.splitlines())
started=time.monotonic();state={'state':'observing-existing-build','unit':UNIT,'invocation':INV,'main_pid':PID,'samples':[]};last=None
try:
 while True:
  text,properties=props();assert properties['LoadState']=='loaded'and properties['InvocationID']==INV and properties['ExecMainPID']==PID,('Same actual build identity lost',properties)
  actual=json.loads((A/'execution-native90-v2/status.json').read_text());row={k:actual.get(k)for k in ['state','exit','completed_compilations','completed_links','completed_generators','staged_whole_objects','seconds','error']};row.update(observed_epoch=time.time(),unit_SubState=properties['SubState'],unit_MainPID=properties['MainPID'])
  summary=tuple(row.get(k)for k in ['state','completed_compilations','completed_links','completed_generators','error'])
  if summary!=last:print(json.dumps(row),flush=True);state['samples'].append(row);last=summary;write(P/'observer-status.json',state)
  if properties['SubState']!='running':break
  assert properties['MainPID']==PID and Path('/proc',PID).exists(),'Actual live unit MainPID absent'
  assert time.monotonic()-started<14400,'Observer bound reached; do not restart owned job'
  time.sleep(25)
 (P/'owning-unit-terminal.txt').write_text(text);journal=subprocess.check_output(['journalctl','--user','-u',UNIT,'--no-pager','-o','short-precise'],text=True);(P/'owning-unit-journal.txt').write_text(journal)
 assert properties['Result']=='success'and properties['ExecMainStatus']=='0'and properties['MainPID']=='0'and properties['SubState']=='exited',('Owning unit actually failed',properties)
 assert actual['state']=='terminal'and actual['exit']==0 and actual['source']==HEAD and not actual['input_drift']and not actual['remaining_owned_same_start']and actual['external_signal']is None,('Owning materialization not qualified',row)
 assert [actual[k]for k in ['completed_compilations','completed_links','completed_generators','staged_whole_objects']]==[291,737,3,745]
 planpath=A/'plan-v2.json';assert sha(planpath)==PLAN_SHA and actual['plan']=={'path':str(planpath),'sha256':PLAN_SHA};plan=json.loads(planpath.read_text());B=Path(plan['destination']);S=Path(plan['source_path']);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==HEAD and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 ownedref=actual['owned_outputs'];assert sha(ownedref['path'])==ownedref['sha256'];owned=json.loads(Path(ownedref['path']).read_text());assert set(owned)==set(plan['objects'])|set(plan['links'])|set(plan['generated_outputs'])and len(owned)==ownedref['count']==1776
 depref=actual['actual_current_dependency_audit'];assert sha(depref['path'])==depref['sha256'];deps=json.loads(Path(depref['path']).read_text());assert deps['state']=='passed'and not deps['errors']and depref['owners']==deps['owners_visited']==1036 and set(deps['records'])==set(plan['objects'])
 routes={'compile-complete-TU':0,'reuse-authenticated-whole-object':0};lineages={};incidences=0;unique=set()
 for key,row in deps['records'].items():
  routes[row['route']]+=1
  if row['newly_compiled']:
   assert row['route']=='compile-complete-TU';md=Path(row['depfile']);digest=row['actual_MD']['raw_sha256'];cwd=Path(row['actual_compile_cwd']);assert cwd==B
  else:
   assert row['route']=='reuse-authenticated-whole-object'and not(B/plan['objects'][key]['depfile']).exists();md=Path(row['unchanged_snapshot']);digest=row['actual_original_MD']['raw_sha256'];cwd=Path(row['original_actual_compile_cwd']);assert sha(row['original_depfile'])==sha(row['true_original_compiler_depfile'])==digest
   lineage=row['provider_current_owner_lineage'];assert lineage==plan['objects'][key]['provider_current_owner_lineage'];lineages[lineage]=lineages.get(lineage,0)+1
  assert sha(md)==digest;target,body=md.read_text().replace('\\\n',' ').split(':',1);assert shlex.split(target)in [[key],[str(cwd/key)]]
  actualdeps=[str((Path(x)if Path(x).is_absolute()else cwd/x).resolve())for x in shlex.split(body)];assert actualdeps==[r['resolved']for r in row['dependencies']];incidences+=len(actualdeps);unique.update(actualdeps)
 assert routes=={'compile-complete-TU':291,'reuse-authenticated-whole-object':745}
 state.update(state='rechecking-closed-output-bytes',native_MD_owners=1036,dependency_routes=routes,provider_lineages=lineages,MD_incidences=incidences,unique_resolved_MD_paths=len(unique));write(P/'observer-status.json',state);print('Rechecking1776actualclosedoutputs',flush=True)
 bad=[key for key,h in owned.items()if not(B/key).is_file()or sha(B/key)!=h];assert not bad,('Closed owned output drift',bad)
 assert properties.get('ControlGroup','')==''or not(Path('/sys/fs/cgroup')/properties['ControlGroup'].lstrip('/')/'cgroup.procs').read_text().split()
 assert not Path('/proc',PID).exists(),'Finished owning MainPID survives'
 state.update(state='terminal',exit=0,source=HEAD,owning_status={'path':str(A/'execution-native90-v2/status.json'),'sha256':sha(A/'execution-native90-v2/status.json')},plan={'path':str(planpath),'sha256':PLAN_SHA},owned_outputs=ownedref,actual_dependency_manifest=depref,independent_closed_output_recheck_count=1776,closed_output_drift=bad,terminal_properties=properties,terminal_unit_capture_sha256=sha(P/'owning-unit-terminal.txt'),unit_journal_sha256=sha(P/'owning-unit-journal.txt'),no_products_tests_install_or_session_action=True)
 write(P/'observer-status.json',state);print('ActualClosedSANowningPASS',flush=True)
except BaseException as error:
 state.update(state='observer-or-owning-failed',exit=1,error=repr(error));write(P/'observer-status.json',state);print(json.dumps({'state':state['state'],'error':repr(error)}),flush=True);raise
