import pathlib,json,hashlib,tarfile,lzma,time,subprocess
R=pathlib.Path('/home/blux/de-xr/dome-sculpt');A=R/'artifacts';O=A/'hdr-projection-sharing-sanitize-20261126';N=O/'native-sanitize-current-v1';W=A/'hdr-release-proof-20261126';D=W/'docs/validation';files=set()
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def add(p):
 p=pathlib.Path(p)
 if p.is_file():files.add(p)
def meta(p):
 for f in p.iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.log','.txt','.maps']:add(f)
 for f in (p/'compiler-records').glob('*.json'):add(f)
s=json.loads((N/'status.json').read_text());assert s['terminal'];assert not s['owned'];assert not s['drift']
for name in ['hdr-retained-worker-sanitize-20261126','texture-set-recipe-sanitize-20261126','hdr-projection-sharing-sanitize-20261126']:meta(A/name)
meta(N);p=json.loads((O/'plan.json').read_text())
for f in [pathlib.Path(x['record']) for x in p['retained']]+list((O/'compiler-records').glob('*.json')):
 add(f);record=json.loads(f.read_text());add(record['depfile'])
fixture=A/'hdr-projection-fixture-build-20261126/native-sanitize-v1';meta(fixture)
outputs=[{'path':str(f),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(N.rglob('*')) if f.is_file() and f.suffix in ['.dsculpt','.glb','.exr','.png']]
inventory=[{'path':str(f.relative_to(R)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in sorted(files)]
archive=D/'hdr-source-closure-strict-20261126.tar.xz'
with lzma.open(archive,'wb',preset=6) as out:
 with tarfile.open(fileobj=out,mode='w|') as t:
  for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
positive=sum(step.get('actual_checks',0) for step in s['steps'] if step.get('exit')==0)
r={'source':'725ea10032981e28c7edb0c1ffdd5689e4a3ad32','scope':'Actual strict original725 whole native cohort; completed endpoints and any full2048 failure remain separate. Corrected projection11 exact725/a4 has separate actual strict pass. No App/display/physicalXR admission.','invocation':'0b2fabbf1c8648448646a7ef510a8a52','unit':'ds-hdr-projection-sharing-native-strict-v1-20261126.service','complete_original_cohort_pass':s['exit']==0,'completed_positive_checks':positive,'separate_corrected_projection_positive_checks':11,'status':s,'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'authorities':inventory},'outputs_preserved_at_actual_paths':outputs,'strict_build_profile':json.loads((O/'strict-profile-audit.json').read_text()),'created':time.time()};(D/'hdr-source-closure-strict-20261126.json').write_text(json.dumps(r,indent=2)+'\n');print('strictproof',positive,'wholeexit',s['exit'],'authorities',len(files),'archivebytes',archive.stat().st_size)
