// SPDX-License-Identifier: GPL-3.0-or-later
#include "dome/vrm-expression.hpp"
#include "dome/import-authoring.hpp"
#include "dome/humanoid-creator.hpp"
#include "dome/material-bindings.hpp"
#include "dome/source-maps.hpp"
#include <iostream>
using namespace dome;
int main(int argc,char**argv) {
 if(argc!=2)return 2;
 Scene empty;
 empty.active().visible=false;
 ImportAuthoringOptions options;
 options.prepare_texture_atlas=true;
 options.paint_resolution=64;
 auto imported=prepare_authoring_import(empty,argv[1],options);
 for(const auto id:imported.objects){
  const auto &o=imported.scene.object(id);
  auto binding=o.material_bindings;
  std::cout<<"object="<<id<<" typed="<<(binding&&binding->has_mtoon)<<" original_grid="
    <<o.painted->source_sampling_prepared()<<" frames="<<bool(binding&&binding->normal_frames)
    <<" material="<<(o.appearance?o.appearance->source_material:-2)<<'\n';
  if(binding&&binding->normal_frames)
    std::cout<<"role="<<int(binding->normal_frame)
      <<" generated="<<binding->normal_frames->pbr->generated_tangents
      <<" uv_orig="<<bool(binding->uv_origin)
      <<" norm_img="<<bool(binding->roles[size_t(MToonSlot::Normal)].image)<<'\n';
 }
 Vrm1ExpressionWeights w;
 w.preset={{"happy",.25f},{"blink",.8f}};
 w.custom={{"ink",.2f}};
 try {
  const auto after=bake_vrm1_expression_pose(imported.scene,imported.objects.front(),w);
  std::cout<<"ACCEPTED"<<std::endl;
 } catch(const std::exception &error) {
  std::cout<<"REFUSED "<<error.what()<<std::endl;
 }
}
