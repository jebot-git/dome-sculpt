// SPDX-License-Identifier: GPL-3.0-or-later
#include "texture-set-graph.hpp"
#include "dome/polygon-scene.hpp"
#include <iostream>

using namespace dome;

std::shared_ptr<PolygonAuthority> outer(std::shared_ptr<PolygonAuthority> inner,
                                        const SculptObject &base,int count) {
  for(int step=0;step<count;++step) {
    auto origin=std::make_shared<PolygonOrigin>();
    origin->name=base.name;
    origin->material=base.material;
    origin->source_object=base.id;
    origin->volume=base.volume;
    origin->polygon=std::move(inner);
    inner=std::make_shared<PolygonAuthority>();
    inner->active=false;
    inner->topology=PolygonMesh::grid();
    inner->origin=std::move(origin);
  }
  return inner;
}
int main() {
  Scene scene;
  auto owner=std::make_shared<PolygonAuthority>();
  owner->active=false;
  owner->topology=PolygonMesh::grid();
  auto short_path=outer(owner,scene.active(),16);
  auto deep_path=outer(short_path,scene.active(),16);
  scene.active().polygon=short_path;
  const auto second=scene.add("Another root",Volume{});
  scene.object(second).polygon=deep_path;
  try {
    detail::validate_texture_set_graph(scene);
    std::cout << "ACCEPTED" << std::endl;
  } catch(const std::exception &e) {
    std::cout << "REFUSED " << e.what() << std::endl;
  }
}
