from pathlib import Path
import fcntl,hashlib,json,os,subprocess,time
root=Path(__file__).resolve().parent
art=root.parent
source=art/'current-authoring-regressions-validation-v5-20261126/release'
status={'terminal':False,'invocation':os.getenv('INVOCATION_ID'),'phase':'wait for matched Release'}
def record(**fields):
    status.update(fields)
    file=root/'status.tmp'
    file.write_text(json.dumps(status,indent=2)+'\n')
    file.replace(root/'status.json')
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
try:
    record()
    unit='ds-current-authoring-regressions-release-v5-20261126.service'
    while True:
        file=source/'status.json'
        if file.is_file():
            prior=json.loads(file.read_text())
            if prior['terminal']:break
        assert subprocess.check_output(['systemctl','--user','is-active',unit],text=True).strip()=='active'
        time.sleep(2)
    assert prior['exit']==0 and prior['tests']==7
    executable=source/'build/dome-sculpt-normal-preparation-render-test'
    assert sha(executable)==prior['binaries'][executable.name]
    cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',root,root,
         '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
         '--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129']
    env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'0',
         'MESA_SHADER_CACHE_DISABLE':'1','DRI_PRIME':'pci-0000_03_00_0',
         'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    for key,value in env.items():cmd.extend(('--setenv',key,value))
    cmd.extend((executable,root/'arc-prepared-normal','--hardware'))
    record(phase='render independent prepared normal consumer on Intel Arc',candidate=prior['candidate'],
           application_sha256=sha(executable))
    log=root/'render.log'
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock,log.open('w') as trace:
        fcntl.flock(lock,fcntl.LOCK_EX)
        subprocess.run(cmd,cwd=root,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=180)
    text=log.read_text().splitlines()
    assert any('Arc(tm) A770' in line for line in text)
    checks=sum(line.startswith('PASS ') for line in text)
    assert checks>0
    record(phase='complete',terminal=True,exit=0,checks=checks,log_sha256=sha(log))
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
