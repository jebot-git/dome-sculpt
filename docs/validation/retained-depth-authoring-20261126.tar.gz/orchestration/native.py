from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import time

home = Path(__file__).resolve().parent
artifacts = home.parent
source = artifacts/'current-authoring-regressions-fixture-20261126'
profile = sys.argv[1]
asan = profile == 'asan'
out = home/profile
out.mkdir(exist_ok=True)
build = out/'build'
prior = artifacts/'native-authored-grid-validation-v3-20261126'/profile
prior_product = artifacts/'native-authored-grid-validation-20261126'/profile
gpu = artifacts/'steady-gpu-retirement-validation-v2-20261126'/profile
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk = artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
test_targets = {
    'polygon-scene-archive': 'dome-sculpt-polygon-scene-test',
    'polygon-scene-faults': 'dome-sculpt-polygon-scene-faults-test',
    'texture-set-bake-recipe': 'dome-sculpt-texture-set-bake-recipe-test',
    'normal-preparation-native': 'dome-sculpt-normal-preparation-test',
    'normal-preparation-render': 'dome-sculpt-normal-preparation-render-test',
    'source-prepared-normal-bake': 'dome-sculpt-source-prepared-normal-bake-test',
    'vrm1-expressions': 'dome-sculpt-vrm1-expressions-test',
}
start = time.monotonic()

def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()

def sha(file):
    with Path(file).open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

status = {'candidate':git('rev-parse','HEAD'), 'profile':profile, 'terminal':False,
          'fltk':str(sdk),'invocation':os.getenv('INVOCATION_ID')}

def record(**fields):
    status.update(fields, elapsed_seconds=round(time.monotonic()-start,2))
    temp=out/'status.tmp'
    temp.write_text(json.dumps(status,indent=2)+'\n')
    temp.replace(out/'status.json')

def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check)

try:
    expected=os.environ['DOME_PAINT_GRID_CANDIDATE']
    assert expected==status['candidate'] and not git('status','--porcelain')
    opts = []
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    record(phase='configure canonical toolkit')
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,out)
    prior=artifacts/'current-authoring-regressions-validation-20261126'/profile
    product=json.loads((prior/'status.json').read_text())
    assert product['terminal'] and product['candidate']==git('rev-parse','b0057eef')
    assert git('diff','--name-only',product['candidate'],'HEAD').splitlines()==['tests/vrm1-expressions.cpp']
    core=prior/'libdome-sculpt-core.a'
    assert sha(core)==product['core_sha256']
    (out/core.name).symlink_to(core)
    base=prior/'build'
    binaries={}
    for name in sorted(set(test_targets.values())-{'dome-sculpt-vrm1-expressions-test'}):
        binary=base/name
        assert sha(binary)==product['binaries'][name]
        (build/name).symlink_to(binary)
        binaries[name]=sha(binary)
    app=base/'dome-sculpt'
    assert sha(app)==product['app_sha256']
    (build/'dome-sculpt').symlink_to(app)
    database=json.loads((build/'compile_commands.json').read_text())
    entry=next(e for e in database if e['file']==str(source/'tests/vrm1-expressions.cpp'))
    arguments=shlex.split(entry['command'])
    obj=out/'vrm1-expressions.cpp.o'
    arguments[arguments.index('-o')+1]=str(obj)
    record(phase='compile corrected genuine authored/generated fixtures',donor=product['donor'],
           exact_product=product['candidate'],core_sha256=sha(core),app_sha256=sha(app),
           render_sha256=product['render_sha256'],xr_sha256=product['xr_sha256'])
    invoke(arguments,'vrm1-expressions.cpp.log',500)
    name='dome-sculpt-vrm1-expressions-test'
    link=shlex.split((prior/'tests'/name/'link.log').read_text().splitlines()[0])
    link=[str(obj) if word.endswith('/vrm1-expressions.cpp.o') else word for word in link]
    invoke(link,'vrm1-expressions-link.log',500)
    binaries[name]=sha(build/name)
    record(phase='run the complete scoped authoring matrix',binaries=binaries)

    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:
        environment.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                           UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in environment.items():
        isolated.extend(['--setenv',key,value])
    # Emit JUnit before enforcing success so a failed case can be diagnosed
    # against its exact executable while preserving all other results.
    report=build/'authoring-regressions.xml'
    run=invoke([*isolated,'ctest','--test-dir',build,'-R','^('+'|'.join(test_targets)+')$',
                '--output-on-failure','-V','-j2','--output-junit',report],
               'ctest.log',850,check=False)
    from xml.etree import ElementTree
    cases={case.attrib['name']:case for case in ElementTree.parse(report).getroot().findall('.//testcase')}
    assert set(cases)==set(test_targets)
    failure=sorted(name for name,case in cases.items() if case.find('failure') is not None or case.find('skipped') is not None)
    assert git('rev-parse','HEAD')==expected and not git('status','--porcelain')
    record(phase='complete',terminal=True,exit=run.returncode,failures=failure,tests=len(cases),
           ctest_sha256=sha(out/'ctest.log'),junit_sha256=sha(report))
    assert run.returncode==0 and not failure, failure
except Exception as error:
    record(terminal=True,exit=1,error=repr(error))
    raise
