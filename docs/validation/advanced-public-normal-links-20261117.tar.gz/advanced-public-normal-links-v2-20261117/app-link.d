/home/blux/de-xr/dome-sculpt/artifacts/advanced-public-normal-links-v2-20261117/dome-sculpt: \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crt1.o \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crti.o \
  /usr/lib/gcc/x86_64-redhat-linux/16/crtbegin.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/native-display-runtime.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/vrm-expression-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/rig-fit-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/projection-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/spacenav-options.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/app.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/polygon-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/import-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/procedural-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/resolution-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/sculpt-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/creator-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/rig-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/shapekey-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/weight-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/skin-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/mesh-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/bake-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/object-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/texture-set-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/paint-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/uv-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/ui-conventions.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/session-appearance.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/export-editor.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/third_party/desktop/desktop-menu.cpp.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/appmenu-protocol.c.o \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-spacenav.a \
  /home/blux/de-xr/dome-sculpt/artifacts/artist-advanced-normal-compile-20261117/links-chain-v1/libdome-sculpt-core.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-render.a \
  /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib/libfltk_images.so.1.4.5 \
  /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib/libfltk_gl.so.1.4.5 \
  /usr/lib64/libGLU.so \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-xr.a \
  /usr/lib64/libjpeg.so \
  /usr/lib64/libpng.so \
  /home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib/libfltk.so.1.4.5 \
  /usr/lib64/libcairo.so \
  /usr/lib64/libX11.so \
  /usr/lib64/libGLU.so \
  /usr/lib64/libGL.so \
  /usr/lib64/libdl.a \
  /usr/lib64/libSM.so \
  /usr/lib64/libICE.so \
  /usr/lib64/libXext.so \
  /usr/lib64/libXinerama.so \
  /usr/lib64/libXfixes.so \
  /usr/lib64/libXcursor.so \
  /usr/lib64/libXrender.so \
  /usr/lib64/libcairo.so \
  /usr/lib64/libfreetype.so \
  /usr/lib64/libXft.so \
  /usr/lib64/libwayland-egl.so \
  /usr/lib64/libwayland-cursor.so \
  /usr/lib64/libxkbcommon.so \
  /usr/lib64/libGLX.so \
  /usr/lib64/libOpenGL.so \
  /usr/lib64/libz.so \
  /opt/fltk-vr/bdf-runtime/lib/libcairo.so \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-render.a \
  /home/blux/de-xr/dome-sculpt/artifacts/artist-advanced-normal-compile-20261117/links-chain-v1/libdome-sculpt-core.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-paint-gpu.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-affine.a \
  /usr/lib64/liblapacke.so \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-polygon.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libxatlas.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libmikktspace.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libmikktspace-robust.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libufbx.a \
  /usr/lib64/libpng.so \
  /usr/lib64/libjpeg.so \
  /usr/lib64/libz.so \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-emission-codec.a \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-baked-emission.a \
  /usr/lib64/libOpenEXR-3_2.so \
  /usr/lib64/libOpenEXRUtil-3_2.so \
  /usr/lib64/libOpenEXRCore-3_2.so \
  /usr/lib64/libIex-3_2.so \
  /usr/lib64/libIlmThread-3_2.so \
  /usr/lib64/libImath-3_1.so \
  /home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-native-graphics.a \
  /usr/lib64/libOpenGL.so \
  /usr/lib64/libEGL.so \
  /opt/fltk-vr/bdf-runtime/lib/libharfbuzz.so \
  /usr/lib64/libGL.so \
  /usr/lib64/libfontconfig.so \
  /opt/fltk-vr/bdf-runtime/lib/libfreetype.so \
  /usr/lib64/libicui18n.so \
  /usr/lib64/libicuuc.so \
  /usr/lib64/libopenxr_loader.so \
  /usr/lib64/libgio-2.0.so \
  /usr/lib64/libgobject-2.0.so \
  /usr/lib64/libglib-2.0.so \
  /usr/lib64/libX11.so \
  /usr/lib64/libwayland-client.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libstdc++.so \
  /usr/lib64/libm.so \
  /usr/lib64/libm.so \
  /usr/lib64/libm.so \
  /lib64/libm.so.6 \
  /lib64/libmvec.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so \
  /usr/lib64/libatomic.so.1.2.0 \
  /usr/lib64/libc.so \
  /usr/lib64/libc.so \
  /usr/lib64/libc.so \
  /lib64/libc.so.6 \
  /usr/lib64/libc_nonshared.a \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so \
  /lib64/libgcc_s.so.1 \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a \
  /usr/lib/gcc/x86_64-redhat-linux/16/crtend.o \
  /usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crtn.o \
  /usr/lib64/libxcb.so.1 \
  /usr/lib64/libxcb-render.so.0 \
  /usr/lib64/libxcb-shm.so.0 \
  /usr/lib64/libpixman-1.so.0 \
  /usr/lib64/libGLdispatch.so.0 \
  /usr/lib64/libuuid.so.1 \
  /usr/lib64/libbz2.so.1 \
  /usr/lib64/libbrotlidec.so.1 \
  /usr/lib64/libtmglib.so.3 \
  /usr/lib64/liblapack.so.3 \
  /usr/lib64/libdeflate.so.0 \
  /usr/lib64/libgraphite2.so.3 \
  /usr/lib64/libxml2.so.2 \
  /usr/lib64/libicudata.so.77 \
  /usr/lib64/libjsoncpp.so.26 \
  /usr/lib64/libgmodule-2.0.so.0 \
  /usr/lib64/libmount.so.1 \
  /usr/lib64/libffi.so.8 \
  /usr/lib64/libpcre2-8.so.0 \
  /lib64/ld-linux-x86-64.so.2 \
  /usr/lib64/libXau.so.6 \
  /usr/lib64/libbrotlicommon.so.1 \
  /usr/lib64/libblas.so.3 \
  /lib64/libmvec.so.1 \
  /usr/lib64/libgfortran.so.5 \
  /usr/lib64/liblzma.so.5 \
  /usr/lib64/libblkid.so.1

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crt1.o:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crti.o:

/usr/lib/gcc/x86_64-redhat-linux/16/crtbegin.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/native-display-runtime.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/vrm-expression-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/rig-fit-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/projection-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/spacenav-options.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/app.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/polygon-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/import-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/procedural-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/resolution-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/sculpt-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/creator-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/rig-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/shapekey-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/weight-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/skin-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/mesh-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/bake-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/object-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/texture-set-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/paint-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/uv-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/ui-conventions.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/session-appearance.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/src/export-editor.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/third_party/desktop/desktop-menu.cpp.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/CMakeFiles/dome-sculpt.dir/appmenu-protocol.c.o:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-spacenav.a:

/home/blux/de-xr/dome-sculpt/artifacts/artist-advanced-normal-compile-20261117/links-chain-v1/libdome-sculpt-core.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-render.a:

/home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib/libfltk_images.so.1.4.5:

/home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib/libfltk_gl.so.1.4.5:

/usr/lib64/libGLU.so:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-xr.a:

/usr/lib64/libjpeg.so:

/usr/lib64/libpng.so:

/home/blux/de-xr/dome-sculpt/artifacts/sdk-20261111/toolkit-release/lib/libfltk.so.1.4.5:

/usr/lib64/libcairo.so:

/usr/lib64/libX11.so:

/usr/lib64/libGLU.so:

/usr/lib64/libGL.so:

/usr/lib64/libdl.a:

/usr/lib64/libSM.so:

/usr/lib64/libICE.so:

/usr/lib64/libXext.so:

/usr/lib64/libXinerama.so:

/usr/lib64/libXfixes.so:

/usr/lib64/libXcursor.so:

/usr/lib64/libXrender.so:

/usr/lib64/libcairo.so:

/usr/lib64/libfreetype.so:

/usr/lib64/libXft.so:

/usr/lib64/libwayland-egl.so:

/usr/lib64/libwayland-cursor.so:

/usr/lib64/libxkbcommon.so:

/usr/lib64/libGLX.so:

/usr/lib64/libOpenGL.so:

/usr/lib64/libz.so:

/opt/fltk-vr/bdf-runtime/lib/libcairo.so:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-render.a:

/home/blux/de-xr/dome-sculpt/artifacts/artist-advanced-normal-compile-20261117/links-chain-v1/libdome-sculpt-core.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-paint-gpu.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-affine.a:

/usr/lib64/liblapacke.so:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-polygon.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libxatlas.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libmikktspace.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libmikktspace-robust.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libufbx.a:

/usr/lib64/libpng.so:

/usr/lib64/libjpeg.so:

/usr/lib64/libz.so:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-emission-codec.a:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-baked-emission.a:

/usr/lib64/libOpenEXR-3_2.so:

/usr/lib64/libOpenEXRUtil-3_2.so:

/usr/lib64/libOpenEXRCore-3_2.so:

/usr/lib64/libIex-3_2.so:

/usr/lib64/libIlmThread-3_2.so:

/usr/lib64/libImath-3_1.so:

/home/blux/de-xr/dome-sculpt/artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/libdome-sculpt-native-graphics.a:

/usr/lib64/libOpenGL.so:

/usr/lib64/libEGL.so:

/opt/fltk-vr/bdf-runtime/lib/libharfbuzz.so:

/usr/lib64/libGL.so:

/usr/lib64/libfontconfig.so:

/opt/fltk-vr/bdf-runtime/lib/libfreetype.so:

/usr/lib64/libicui18n.so:

/usr/lib64/libicuuc.so:

/usr/lib64/libopenxr_loader.so:

/usr/lib64/libgio-2.0.so:

/usr/lib64/libgobject-2.0.so:

/usr/lib64/libglib-2.0.so:

/usr/lib64/libX11.so:

/usr/lib64/libwayland-client.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libstdc++.so:

/usr/lib64/libm.so:

/usr/lib64/libm.so:

/usr/lib64/libm.so:

/lib64/libm.so.6:

/lib64/libmvec.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so:

/usr/lib64/libatomic.so.1.2.0:

/usr/lib64/libc.so:

/usr/lib64/libc.so:

/usr/lib64/libc.so:

/lib64/libc.so.6:

/usr/lib64/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc_s.so:

/lib64/libgcc_s.so.1:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/libgcc.a:

/usr/lib/gcc/x86_64-redhat-linux/16/crtend.o:

/usr/lib/gcc/x86_64-redhat-linux/16/../../../../lib64/crtn.o:

/usr/lib64/libxcb.so.1:

/usr/lib64/libxcb-render.so.0:

/usr/lib64/libxcb-shm.so.0:

/usr/lib64/libpixman-1.so.0:

/usr/lib64/libGLdispatch.so.0:

/usr/lib64/libuuid.so.1:

/usr/lib64/libbz2.so.1:

/usr/lib64/libbrotlidec.so.1:

/usr/lib64/libtmglib.so.3:

/usr/lib64/liblapack.so.3:

/usr/lib64/libdeflate.so.0:

/usr/lib64/libgraphite2.so.3:

/usr/lib64/libxml2.so.2:

/usr/lib64/libicudata.so.77:

/usr/lib64/libjsoncpp.so.26:

/usr/lib64/libgmodule-2.0.so.0:

/usr/lib64/libmount.so.1:

/usr/lib64/libffi.so.8:

/usr/lib64/libpcre2-8.so.0:

/lib64/ld-linux-x86-64.so.2:

/usr/lib64/libXau.so.6:

/usr/lib64/libbrotlicommon.so.1:

/usr/lib64/libblas.so.3:

/lib64/libmvec.so.1:

/usr/lib64/libgfortran.so.5:

/usr/lib64/liblzma.so.5:

/usr/lib64/libblkid.so.1:
