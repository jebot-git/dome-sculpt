"""Root-authorized3 CPU links only; never run any resulting product."""
import hashlib,importlib.util,json,os,resource,shlex,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;J=json.loads((P/'link-plan.json').read_text());R=P.parents[1];C=R/'artifacts/advanced-public-normal-compile-20261117';S=Path(J['source_path'])
EXPECTED='fe5547f4bcbb028a702cda4d92cdd4ac665a275fee8d78d2e33768c5589d6cfe'
pins={};state={'state':'preparing','exit':1,'source':J['source_commit'],'scope_tuple':J['scope_tuple'],'scope':'Three fresh complete CPU links only, qualified90fad core +8bb native/runtime TUs +immutable090f UI/support context. No product/ldd/version/GL/runtime execution.','cwd':str(P),'steps':[],'actual_link_dependencies':{}}
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,want=None):
 p=str(p);v=sha(p);assert want is None or want==v,('Input drift',p);assert p not in pins or pins[p]==v,('Conflicting expected pin',p);pins[p]=v

def save():(P/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';assert sha(M)=='b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269';spec=importlib.util.spec_from_file_location('qualified_owned_link_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','LD_LIBRARY_PATH':str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'};state['environment']=env

def run(name,argv):
 row={'name':name,'argv':argv,'cwd':str(P),'started':time.time()};state['steps'].append(row);save()
 with(P/(name+'.log')).open('w')as log:
  child=subprocess.Popen(argv,cwd=P,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);owned=monitor.Owned(child);deadline=time.monotonic()+900
  try:
   while child.poll()is None:
    rss=owned.refresh();row.update(owned.result());save()
    if rss>3*1024**3:raise monitor.BudgetExceeded('Owned aggregate link RSS exceeds3GiB')
    if time.monotonic()>deadline:raise monitor.BudgetExceeded('CPU link exceeds900s')
    time.sleep(.01)
   code=child.wait();owned.refresh();row.update(owned.result());assert not[v for v in owned.known.values()if monitor.alive(v)]
  except BaseException as error:owned.terminate(str(error));row.update(owned.result());save();raise
 row.update(exit=code,seconds=time.time()-row['started'],log_sha256=sha(P/(name+'.log')));save();print(name,code,flush=True);assert code==0,(name,code)

try:
 pin(P/'link-plan.json',EXPECTED);pin(Path(__file__).resolve());pin(M);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==J['source_commit']and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 for key in ['compile_status','compile_inputs','owning_status','owning_plan','owning_manifest','core','old_whole_core_preserved']:pin(J[key]['path'],J[key]['sha256'])
 compile_state=json.loads(Path(J['compile_status']['path']).read_text());assert compile_state['state']=='terminal'and compile_state['exit']==0 and not compile_state['input_drift']and compile_state['source']==J['source_commit']and len(compile_state['dependency_owners'])==2 and len(compile_state['actual_tools'])==14
 for p,h in json.loads(Path(J['compile_inputs']['path']).read_text()).items():pin(p,h)
 for owner in compile_state['dependency_owners']:
  assert owner['same_roster'];pin(owner['object'],owner['object_sha256'])
  for role in ['precheck','actual_compiler']:pin(owner[role]['path'],owner[role]['sha256'])
 whole=json.loads(Path(J['owning_plan']['path']).read_text());owned_status=json.loads(Path(J['owning_status']['path']).read_text());assert owned_status['state']=='terminal'and owned_status['exit']==0 and not owned_status['input_drift']and not owned_status['remaining_owned_same_start']
 for p,h in whole['pins'].items():pin(p,h)
 for p,h in J['canonical_command_sources'].items():pin(p,h)
 for key in ['original_link_plan','preserved_failure']:pin(J[key]['path'],J[key]['sha256'])
 for p,h in J['expected_provider_provenance_files'].items():pin(p,h)
 for p,h in J['supplemental_expected_providers'].items():pin(p,h)
 for p,h in J['immutable_whole_providers'].items():pin(p,h)
 for row in J['UI_objects']:
  pin(row['object'],row['sha256']);pin(row['actual_MD'],row['actual_MD_sha256'])
  for dep in row['source_body_checks']:pin(dep['prior'],dep['sha256']);pin(dep['current_source_body'],dep['sha256'])
 for key in ['src','include','third_party']:subprocess.run(['git','diff','--exit-code','90fad800',J['source_commit'],'--',key],cwd=S,check=True,stdout=subprocess.DEVNULL)
 pin(Path('/usr/bin/readelf'));pin(Path('/usr/bin/readelf').resolve());(P/'inputs-before.json').write_text(json.dumps(pins,indent=2)+'\n');products={}
 for row in J['commands']:
  assert not Path(row['output']).exists()and not Path(row['actual_link_dependencies']).exists();run('link-'+row['name'],row['argv']);pin(row['output']);pin(row['actual_link_dependencies'])
  text=Path(row['actual_link_dependencies']).read_text().split('\n\n',1)[0].replace('\\\n',' ');target,tail=text.split(':',1);assert target.strip()==row['output'];deps=[]
  for literal in shlex.split(tail):
   path=Path(literal);path=path if path.is_absolute()else P/path;resolved=path.resolve();want=pins.get(str(path),pins.get(str(resolved)));assert want is not None,('Actual linker input outside declared current provider closure',str(path),str(resolved));pin(path,want);pin(resolved,want);deps.append({'literal':literal,'path':str(path),'resolved':str(resolved),'sha256':want})
  state['actual_link_dependencies'][row['name']]={'path':row['actual_link_dependencies'],'sha256':sha(row['actual_link_dependencies']),'rows':deps,'actual_CWD':str(P)};products[row['name']]={'path':row['output'],'sha256':sha(row['output'])};save()
  run('readelf-'+row['name'],['/usr/bin/readelf','-dW',row['output']]);run('exports-'+row['name'],['/usr/bin/readelf','--dyn-syms','--wide',row['output']])
 state.update(products=products,exit=0)
except BaseException as error:state.update(error=repr(error),exit=1)
finally:
 state['input_drift']=[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h];state['exit']=state['exit']or int(bool(state['input_drift']));state['state']='terminal';(P/'inputs-final.json').write_text(json.dumps(pins,indent=2)+'\n');save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
raise SystemExit(state['exit'])
