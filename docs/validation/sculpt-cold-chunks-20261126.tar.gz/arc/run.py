from pathlib import Path
import fcntl,hashlib,json,os,shlex,subprocess,time

out=Path(__file__).resolve().parent
artifact=out.parent/'sculpt-cold-chunk-validation-20261126/release'
build=artifact/'build'
state=json.loads((artifact/'status.json').read_text())
assert state['candidate']=='a2b46ea72c9188c3ec48dcfa216873f078bd6c14'
assert state['terminal'] and state['exit']==0
arc='/dev/dri/renderD129'
prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
        '--proc','/proc','--dev','/dev','--dev-bind',arc,arc,'--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
variables={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'0',
           'MESA_SHADER_CACHE_DISABLE':'1','DRI_PRIME':'pci-0000_03_00_0',
           'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
for key,value in variables.items():
    prefix.extend(['--setenv',key,value])
reports={}
with open('/tmp/dome-sculpt-arc-device.lock','rb') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX)
    for name,target,args in [('sculpt-chunk-render','dome-sculpt-sculpt-chunk-render-test',[out/'pixels']),
                             ('sculpt-mask-render','dome-sculpt-mask-render-test',[])]:
        binary=build/target
        digest=hashlib.sha256(binary.read_bytes()).hexdigest()
        assert digest==state['binaries'][binary.name]
        command=[*prefix,binary,*args]
        trace=out/(name+'.log')
        with trace.open('w') as capture:
            print(shlex.join(map(str,command)),file=capture,flush=True)
            result=subprocess.run(command,cwd=out,stdout=capture,stderr=subprocess.STDOUT,timeout=250)
        text=trace.read_text()
        assert result.returncode==0,text[-3000:]
        assert 'PASS ' in text
        reports[name]={'binary_sha256':digest,'log_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),
                       'checks':sum(line.startswith('PASS ') for line in text.splitlines())}
        if name=='sculpt-chunk-render':
            device=next(line[4:] for line in text.splitlines() if line.startswith('GPU '))
            assert 'Arc(tm) A770' in device
(out/'status.json').write_text(json.dumps({'candidate':state['candidate'],'invocation':os.getenv('INVOCATION_ID'),
    'exit':0,'renderer':device,'render_node':arc,'cases':reports},indent=2)+'\n')
