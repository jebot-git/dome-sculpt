// SPDX-License-Identifier: GPL-3.0-or-later
#include "sculpt-surface-chunks.hpp"
#include "ray-corridor.hpp"
#include <iostream>
#include <chrono>
#include <bit>
using namespace dome;
using namespace dome::detail;
int main(int argc,char **argv) {
  try {
    auto field=test::dense_ray_corridor();
    SculptChunkLimits limits;
    if(argc==2)limits.steps=std::stoul(argv[1]);
    auto started=std::chrono::steady_clock::now();
    const auto chunks=SculptSurfaceChunks::build(field,limits);
    const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
    const auto &r=chunks->report();
    uint64_t hash=1469598103934665603ULL;
    const auto word=[&](uint64_t x){hash^=x;hash*=1099511628211ULL;};
    const auto point=[&](Vec3 v){for(float x:{v.x,v.y,v.z})word(std::bit_cast<uint32_t>(x));};
    const auto coordinate=[&](Int3 cell){for(int i:{cell.x,cell.y,cell.z})word(uint32_t(i));};
    size_t chunk_count=0,run_count=0;
    chunks->for_each_chunk([&](const auto &chunk){
      ++chunk_count;
      coordinate(chunk->coordinate);
      for(const auto &stream:{&chunk->mesh.positions,&chunk->mesh.normals})
        for(Vec3 value:*stream)point(value);
      for(uint32_t index:chunk->mesh.indices)word(index);
      for(const auto &origin:chunk->triangles){coordinate(origin.cell);word(origin.triangle);}
    });
    chunks->for_each_run([&](const SculptSurfaceRun &run){
      ++run_count;
      coordinate(run.chunk->coordinate);
      word(run.first);word(run.count);
      point(run.bounds.minimum);point(run.bounds.maximum);
    });
    if(chunks->source_owner()->geometry_owner()!=field.geometry_owner())
      throw std::runtime_error("Dense build lost the immutable input owner");
    std::cout<<"work_limit="<<limits.steps<<" vertices="<<r.vertices<<" indices="<<r.indices
             <<" dependency_edges="<<r.dependency_edges<<" chunks="<<chunk_count<<" runs="<<run_count
             <<" digest="<<hash<<" working="<<r.working_bytes<<" retained="<<r.retained_bytes
             <<" elapsed="<<elapsed<<'\n';
    if(!r.indices)throw std::runtime_error("Dense fixture lacks actual geometry");
    return 0;
  }catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}
}
