from pathlib import Path
import json,shlex,subprocess,re,hashlib

out=Path(__file__).resolve().parent
base=out.parent
cand=base/'sculpt-cold-chunk-validation-20261126/release'
old=base/'retained-smooth-atlas-validation-20261126/release'
build=cand/'build'
source=base/'sculpt-cold-chunk-source-20261126'
info=json.loads((cand/'status.json').read_text())
assert info['candidate']=='a2b46ea72c9188c3ec48dcfa216873f078bd6c14' and info['terminal'] and info['exit']==0
db=json.loads((build/'compile_commands.json').read_text())
entry=next(e for e in db if e['file']==str(source/'tests/native-paged-ray.cpp'))
def run(argv,log,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,argv)),file=trace,flush=True)
        return subprocess.run(argv,cwd=build,stdout=trace,stderr=subprocess.STDOUT,check=check,timeout=120).returncode
argv=shlex.split(entry['command'])
obj=out/'oracle.o'
argv[argv.index('-o')+1]=str(obj)
argv[-1]=str(out/'witness.cpp')
argv.insert(1,'-I'+str(source/'tests'))
run(argv,'build.log')
link=shlex.split((old/'dome-sculpt-texture-set-source-export-link.log').read_text().splitlines()[0])
records={}
for label,stage,limits in (('baseline',old,[16_000_000,36_000_000]),('candidate',cand,[12_000_000,16_000_000])):
    exec_path=out/label
    command=link.copy()
    archive=stage/'libdome-sculpt-core.a'
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==json.loads((stage/'status.json').read_text())['core_sha256']
    for i,word in enumerate(command):
        if word.endswith('/texture-set-source-export.cpp.o'):command[i]=str(obj)
        if Path(word).name==archive.name:command[i]=str(archive)
    command[command.index('-o')+1]=str(exec_path)
    run(command,label+'-link.log')
    for cap in limits:
        key=f'{label}-{cap}'
        status=run([exec_path,str(cap)],key+'.log',check=False)
        output=(out/(key+'.log')).read_text().splitlines()[-1]
        assert status==0 or 'work limit exceeded' in output
        records[key]={'exit':status,'data':dict(re.findall(r'(\w+)=([\d.]+)',output)),'message':output}
before=records['baseline-36000000']
after=records['candidate-16000000']
assert records['baseline-16000000']['exit']==records['candidate-12000000']['exit']==1
assert before['exit']==after['exit']==0
for name in ('vertices','indices','dependency_edges','chunks','runs','digest','retained'):
    assert before['data'][name]==after['data'][name]
assert int(after['data']['working'])<int(before['data']['working'])
(out/'status.json').write_text(json.dumps({'candidate':info['candidate'],'results':records},indent=2)+'\n')
print(after['message'])
