from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
from xml.etree import ElementTree

root=Path(__file__).resolve().parents[2]
artifacts=root/'artifacts'
base=artifacts/'sculpt-cold-chunk-validation-20261126'
quad=artifacts/'sculpt-cold-chunk-dense-oracle-20261126'
arc=artifacts/'sculpt-cold-chunk-arc-20261126'
wayland=artifacts/'sculpt-cold-chunk-wayland-20261126'
source='a2b46ea72c9188c3ec48dcfa216873f078bd6c14'
validation=root/'docs/validation'
files={}

def load(path):
    return json.loads(path.read_text())

def digest(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()

def add(parent,prefix,*names):
    for name in names:
        path=parent/name
        assert path.is_file(),path
        files[prefix+'/'+name]=path

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

def verified(path):
    status=load(path/'status.json')
    assert status['candidate']==source and status['exit']==0,status
    return status

native={}
for profile in ('release','asan'):
    path=base/profile
    state=verified(path)
    assert state['terminal'] and state['tests']==16 and not state['failures']
    assert digest(path/'ctest.log')==state['ctest_sha256']
    assert digest(path/'build/chunk-tests.xml')==state['junit_sha256']
    tree=ElementTree.parse(path/'build/chunk-tests.xml')
    passed={x.attrib['name'] for x in tree.findall('.//testcase') if
            x.find('failure') is None and x.find('skipped') is None}
    assert {'native-paged-ray-cancellation','sculpt-mask-document','scene-authoring',
            'sculpt-mask-controller','native-live-preview'}<=passed
    assert '90 native paged-ray cancel/stale/shutdown checks passed' in (path/'ctest.log').read_text()
    native[profile]=state|{'passed':sorted(passed)}
    add(path,'native/'+profile,'status.json','ctest.log','build/chunk-tests.xml','dome-sculpt-link.log',
        'sculpt-surface-chunks.cpp.log','configure.log')
add(base,'validation-source','run.py','record.py')

oracle=load(quad/'status.json')
assert oracle['candidate']==source
assert oracle['results']['candidate-16000000']['data']['digest']=='3438701520078628339'
add(quad,'dense','run.py','witness.cpp','status.json','baseline-16000000.log','baseline-36000000.log',
    'candidate-12000000.log','candidate-16000000.log')
hardware=verified(arc)
assert 'Arc(tm) A770' in hardware['renderer']
assert set(hardware['cases'])=={'sculpt-chunk-render','sculpt-mask-render'}
for name,row in hardware['cases'].items():
    assert row['log_sha256']==digest(arc/(name+'.log'))
    assert row['binary_sha256'] in native['release']['binaries'].values()
add(arc,'arc','run.py','status.json','sculpt-chunk-render.log','sculpt-mask-render.log')
add(arc,'arc',*[str(p.relative_to(arc)) for p in (arc/'pixels').glob('*.rgba')])
desktop=verified(wayland)
assert desktop['checks']==17 and desktop['app_sha256']==native['release']['app_sha256']
add(wayland,'nested-wayland','run.py','replay.py','status.json','wayland.log','workflow/report.json')
assert git('diff','--name-only',source,'HEAD','--','src','include','tests','CMakeLists.txt')==''
archive=validation/'sculpt-cold-chunks-20261126.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as stream:
        for label,path in sorted(files.items()):
            info=stream.gettarinfo(str(path),arcname=label)
            info.uid=info.gid=info.mtime=0
            info.mode=0o644
            info.uname=info.gname=''
            with path.open('rb') as item:
                stream.addfile(info,item)
with tarfile.open(archive,'r:gz') as check:
    assert len(check.getmembers())==len(files)
    for name,path in files.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==digest(path)
receipt={'product':source,'main_merge':git('rev-parse','HEAD'),'physical_headset':False,
         'scope':'Cold sculpt edge representatives and ordered draw runs. Dense preview within original quotas, exact mesh/draw fingerprint, cancellation, masks, multi-object authoring and live immutable snapshot checks.',
         'native':native,'dense_oracle':oracle,'intel_arc':hardware,'nested_wayland_bake_smoke':desktop,
         'raw':{'archive':archive.name,'sha256':digest(archive),'members':{name:digest(path) for name,path in sorted(files.items())}}}
(validation/'sculpt-cold-chunks-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(files),'members',receipt['raw']['sha256'])
