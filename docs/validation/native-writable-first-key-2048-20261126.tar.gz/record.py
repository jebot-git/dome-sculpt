from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
destination=repo/'docs/validation'
name='native-writable-first-key-2048-20261126'
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):return json.loads(path.read_text())
files={}
def keep(path,reference=None):
    files[reference or str(path.relative_to(root))]=path
    return sha(path)
product=subprocess.check_output(['git','-C',repo,'rev-parse','ed491ddf'],text=True).strip()
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',product])==(root/'source.patch').read_bytes()
report={'product':product,'patch_sha256':keep(root/'source.patch'),'native':{},'frontend':{},'byte_parity':{},
        'scope':'Native writable LDR atlas at 2048 with a retained Bake and later first shapekey. Exact ordered Save, cold reopen, Undo/Redo, displacement, portable conversion, Standard GLB and Shape Restore. Expanded tests cover sampling, UV, texture sets and faults.'}
for path in ('run.py','expanded.py','public-focus.py','wayland.py','xr-focus.py','xr-portable-runtime.cpp','xr-runtime-build.py',
             'first-key-extra.cpp','first-key-extra-diagnostic.cpp','extra-release.sh','record.py','khronos-standard.json'):
    keep(root/path)
for p in ('release','asan'):
    old=root.parent/'first-key-2048-20261126'/p
    state=read(old/'status.json')
    assert state['terminal'] and state['exit']==8
    assert (old/'ctest.log').read_text().count('FAIL HDR archive has unreferenced paint owners')>=3
    keep(old/'status.json','initial/'+p+'/status.json')
    keep(old/'ctest.log','initial/'+p+'/ctest.log')
    out=root/p
    state=read(out/'status.json')
    assert state['terminal'] and state['exit']==0 and len(state['tests'])==12
    message=(out/'ctest.log').read_text()
    assert 'DENSE_FIRST_KEY 214323981 archive bytes; Restore exact' in message
    assert '100% tests passed, 0 tests failed out of 12' in message
    paths=['status.json','ctest.log','build/regressions.xml','app-link.log',
           'key-derivation-codec.cpp.log','material-bindings.cpp.log','normal-key-derivation.cpp.log',
           'paint.cpp.log','scene.cpp.log','source-writable-normal-bake.cpp.log']
    record={n:keep(out/n) for n in paths}
    expanded=root/('expanded-'+p); more=read(expanded/'status.json')
    assert more['exit']==0 and '100% tests passed, 0 tests failed out of 8' in (expanded/'ctest.log').read_text()
    for n in ('status.json','ctest.log'):
        keep(expanded/n)
    keep(out/'build/expanded.xml')
    report['native'][p]={'ctests':state['tests'],'app_sha256':state['app_sha256'],'core_sha256':state['core'],
        'log_sha256':record,'expanded_ctests':8}
def case(p,n):return root/p/'build/native-writable-first-key-2048'/n
for filename in ('retained-2048.dsculpt','baked-2048.dsculpt','keyed-2048.dsculpt','converted-2048.dsculpt','restored-2048.dsculpt','portable-2048.glb'):
    assert sha(case('release',filename))==sha(case('asan',filename)),filename
    report['byte_parity'][filename]=sha(case('release',filename))
assert report['byte_parity']['baked-2048.dsculpt']==report['byte_parity']['restored-2048.dsculpt']
xr_file=case('release','keyed-auto-2048.dsculpt')
for mode in ('wayland','software','arc'):
    out=root/(mode+'-focus-first-key')
    state=read(out/'status.json')
    assert state['terminal'] and state['exit']==0 and state['checks']==10
    assert state['native_sha256']==(report['byte_parity']['keyed-2048.dsculpt'] if mode=='wayland' else sha(xr_file))
    report['frontend'][mode]={**state,'status_sha256':keep(out/'status.json'),'log_sha256':keep(out/'run.log')}
    for path in (('workflow/report.json','workflow/client.log','workflow/compositor.log','workflow/runtime-maps.txt') if mode=='wayland'
                else ('workflow/report.json','workflow/accept.json','workflow/cancel.json','workflow/accept.log','workflow/cancel.log')):
        keep(out/path)
    if mode!='wayland':
        p='asan' if mode=='arc' else 'release'
        report['frontend'][mode]['synthetic_runtime_sha256']=sha(root/p/'libdome-sculpt-portable-test-runtime.so')
        keep(root/p/'xr-portable-runtime-compile.log');keep(root/p/'xr-portable-runtime-link.log')
failed_observer=root/'arc-focus-first-key-observer-v1'
assert read(failed_observer/'status.json')['exit']==1
assert 'FileNotFoundError' in (failed_observer/'run.log').read_text()
for n in ('status.json','run.log','workflow/report.json','workflow/accept.json','workflow/accept.log'):
    keep(failed_observer/n)
keep(root.parent/'first-key-2048-20261126/source.patch','initial/source.patch')
checks=read(root/'khronos-standard.json')['issues']
assert checks['numErrors']==0
diagnostic=root/'extra-release'
assert sha(diagnostic/'editable-diagnostic-2048.dsculpt')==report['byte_parity']['converted-2048.dsculpt']
assert 'Native nonemission compilation exceeds cumulative sample budget' in (root/'extra-release.log').read_text()
assert read(root/'khronos-editable-diagnostic.json')['issues']['numErrors']==0
keep(root/'extra-release.log')
keep(root/'khronos-editable-diagnostic.json')
report['standard_format']={'errors':checks['numErrors'],'warnings':checks['numWarnings']}
report['separate_checks']={
    'standard_default_ao_key_sha256':sha(diagnostic/'keyed-default-ao-2048.dsculpt'),
    'editable_default_refusal':'Native nonemission compilation exceeds cumulative sample budget',
    'editable_diagnostic_sample_operations_limit':512*1024*1024,
    'editable_diagnostic_container_sha256':sha(diagnostic/'editable-diagnostic-2048.glb'),
    'editable_diagnostic_scene_sha256':sha(diagnostic/'editable-diagnostic-2048.dsculpt')}
archive=destination/(name+'.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for n,p in sorted(files.items()):
        payload=p.read_bytes()
        member=tarfile.TarInfo(n)
        member.size=len(payload)
        tar.addfile(member,io.BytesIO(payload))
report['archive']={'file':archive.name,'sha256':sha(archive),'members':len(files)}
(destination/(name+'.json')).write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(product,report['archive'])
