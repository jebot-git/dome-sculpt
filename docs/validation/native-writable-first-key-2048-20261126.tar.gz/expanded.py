from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import re
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parent
art=root.parent
profile=sys.argv[1]
publish=root/profile
build=publish/'build'
extra=root/('expanded-'+profile)
extra.mkdir(exist_ok=True)
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=art/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit')
core=publish/'libdome-sculpt-core.a'
render=art/'native-key-bake-v2-20261126'/profile/'libdome-sculpt-render.a'
state=json.loads((publish/'status.json').read_text())
assert core.is_file() and render.is_file() and state['phase'] in ('execute native Bake regressions','complete')
variants=('native-key-uv','native-key-uv-metadata','native-key-uv-worker','native-key-uv-render','native-paint-sampling','native-paint-sampling-faults','native-paint-sampling-transitions','texture-set-native')
sources=json.loads((build/'compile_commands.json').read_text())
def invoke(cmd,log,cwd):
    with (extra/log).open('w') as f:
        print(shlex.join(map(str,cmd)),file=f,flush=True)
        return subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=900).returncode
def build_test(variant):
    name='dome-sculpt-'+variant+'-test'
    entry=next(e for e in sources if name+'.dir/' in e['command'])
    compile_args=shlex.split(entry['command'])
    obj=extra/(variant+'.o')
    compile_args[compile_args.index('-o')+1]=str(obj)
    assert invoke(compile_args,variant+'-compile.log',build)==0
    raw=subprocess.check_output(['ninja','-t','commands',name],cwd=build,text=True).splitlines()[-1]
    link=[x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file')]
    archives={'libdome-sculpt-core.a':core,'libdome-sculpt-render.a':render}
    def replace(a):
        if name+'.dir/' in a and a.endswith('.o'):return str(obj)
        if a.startswith('lib') and a.endswith('.a'):
            selected=archives.get(a,support/a)
            assert selected.is_file(),str(selected)
            return str(selected)
        return a
    link=[replace(a) for a in link]
    link[link.index('-o')+1]=str(build/name)
    assert invoke(link,variant+'-link.log',build)==0
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(build_test,variants))
prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2',
     'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if profile=='asan':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for k,v in env.items():prefix.extend(['--setenv',k,v])
pattern='^('+'|'.join(variants[:-1]+('dome-sculpt-texture-set-native',))+')$'
rc=invoke([*prefix,'ctest','--test-dir',str(build),'-V','-j2','-R',pattern,'--output-on-failure','--output-junit',str(build/'expanded.xml')],'ctest.log',build)
(extra/'status.json').write_text(json.dumps({'invocation':os.getenv('INVOCATION_ID'),'profile':profile,'exit':rc},indent=2)+'\n')
raise SystemExit(rc)
