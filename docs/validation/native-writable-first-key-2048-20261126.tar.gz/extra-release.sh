#!/usr/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
build="$root/release/build"
case_dir="$build/native-writable-first-key-2048"
extra="$root/extra-release"
mkdir -p "$extra"
export LD_LIBRARY_PATH=/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64
"$build/first-key-extra" auto-key "$case_dir/baked-2048.dsculpt" "$case_dir/keyed-auto-2048.dsculpt"
"$build/first-key-extra" auto-key "$root/../default-ao-bake-2048-20261126/release/build/native-writable-default-ao-2048/baked-2048.dsculpt" "$extra/keyed-default-ao-2048.dsculpt"
"$build/first-key-extra" editable "$case_dir/converted-2048.dsculpt" "$extra/editable-2048.glb"
cmp "$case_dir/converted-2048.dsculpt" "$extra/editable-2048.dsculpt"
sha256sum "$case_dir/keyed-auto-2048.dsculpt" "$extra/keyed-default-ao-2048.dsculpt" "$extra/editable-2048.glb" "$extra/editable-2048.dsculpt"
