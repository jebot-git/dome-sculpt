from pathlib import Path
import os,json,hashlib,fcntl,time,re,importlib.util,sys,traceback
sys.dont_write_bytecode=True
out=Path(__file__).parent;os.chdir(out);p=json.loads((out/'plan.json').read_text());pins=dict(p['input_pins']);lease=None;monitor=None
s={'state':'preparing','steps':[],'live_apps':{},'actual_private_xvfb':{},'providers':{},'mapped_ELFs':{},'plan_sha256':hashlib.sha256((out/'plan.json').read_bytes()).hexdigest()}
def sha(f):
 with Path(f).open('rb')as h:return hashlib.file_digest(h,'sha256').hexdigest()
def save():(out/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return[f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
loaded=set()
def provider(f):
 f=Path(f);resolved=f.resolve();want=pins.get(str(f))or pins.get(str(resolved))or p['runtime_provider_expected_catalog'].get(str(f))or p['runtime_provider_expected_catalog'].get(str(resolved));assert want,'Unknown selected provider '+str(f);assert sha(f)==want,'Selected provider changed '+str(f);pins[str(f)]=want;pins[str(resolved)]=want;return {'literal':str(f),'resolved':str(resolved),'sha256':want}
def live(row):
 s['live']=row
 for record in row.get('known_processes',[]):
  pid=record['pid']
  if not monitor.alive(record):continue
  try:
   exe=Path('/proc',str(pid),'exe');st=exe.stat();app=Path(p['app']).stat()
   if(st.st_dev,st.st_ino)==(app.st_dev,app.st_ino):
    assert sha(exe)==p['app_sha256'];assert os.readlink('/proc/'+str(pid)+'/ns/mnt')==os.readlink('/proc/self/ns/mnt');s['live_apps'][str(pid)]=record
    for line in Path('/proc',str(pid),'maps').read_text().splitlines():
     fields=line.split(None,5)
     if len(fields)!=6 or not fields[5].startswith('/')or fields[5].endswith('(deleted)'):continue
     f=Path(fields[5]);key=(pid,str(f))
     if key in loaded:continue
     with f.open('rb')as h:
      if h.read(4)!=b'\x7fELF':continue
     v=provider(f);fs=f.stat();major,minor=map(lambda x:int(x,16),fields[3].split(':'));proof=mount_identity.certify_mapping(f,os.makedev(major,minor),int(fields[4]),pid);assert fs.st_dev==proof['stat_device']and fs.st_ino==proof['inode'];v.update(pid=pid,start=record['start'],map_device=fields[3],inode=fs.st_ino,mount_certificate=proof);s['mapped_ELFs'][str(pid)+':'+str(f)]=v;loaded.add(key)
   elif p['phase']=='desktop' and str(pid)not in s['actual_private_xvfb']:
    target=Path(p['xvfb_exe']).stat()
    if(st.st_dev,st.st_ino)==(target.st_dev,target.st_ino):s['actual_private_xvfb'][str(pid)]=xidentity.certify(pid,pins,sealing=False)
  except(FileNotFoundError,ProcessLookupError):continue
  except BaseException as error:
   s['observer_failure']={'record':record,'error':repr(error),'traceback':traceback.format_exc()};save();raise
 save()
try:
 assert not drift();gate=json.loads(Path(p['native_review']).read_text());assert gate['review_exit']==0 and gate['total_actual_checks']==845 and not gate['input_drift']and not gate['remaining_owned']
 assert gate['production']==p['production'];assert sha(p['app'])==p['app_sha256'];monitor=load('creator_public_owned_monitor',p['monitor']);xidentity=load('creator_private_xvfb_identity',p['xvfb_identity']);mount_identity=load('creator_certified_mount_identity',p['mount_identity'])
 lease=open('/tmp/dome-sculpt-arc-device.lock','a+');assert os.fstat(lease.fileno()).st_ino==99618 and os.fstat(lease.fileno()).st_dev==40;fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);s['lease']={'acquired':time.time(),'owner_pid':os.getpid(),'before_any_ldd_or_product':True,'inode':99618};save()
 env={k:v for k,v in os.environ.items()if not k.startswith(('LD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_','DYLD_'))}
 for k in ['DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','XR_RUNTIME_JSON','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(k,None)
 env.update(p['environment']);env['PYTHONDONTWRITEBYTECODE']='1';s['environment']={k:env.get(k)for k in p['environment']};save()
 for f in p['loader_objects']:
  row=monitor.run(['/usr/bin/ldd',f],cwd=out,env=env,log=out/(Path(f).name+'.ldd'),timeout=30,max_rss=p['RSS_limit']);s['steps'].append({'name':'loader '+f,**row});assert row['exit']==0 and not row.get('signals')and not row.get('error');text=(out/(Path(f).name+'.ldd')).read_text();assert 'not found'not in text;s['providers'][f]=[provider(v)for v in re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text)];save()
 row=monitor.run(p['command'],cwd=out,env=env,log=out/'process.log',timeout=240,max_rss=p['RSS_limit'],progress=live);s['steps'].append({'name':'actual public creator '+p['phase'],**row});s.pop('live',None);save();assert row['exit']==0 and not row.get('signals')and not row.get('error')
 report=json.loads((out/'workflow/report.json').read_text());assert report['complete']and not report['error']and not report['drift']and all(v['passed']for v in report['checks']);assert report['count']>=10;s['actual_checks']=report['count'];s['report_sha256']=sha(out/'workflow/report.json')
 assert len(s['live_apps'])==p['expected_apps'];assert all(any(v['pid']==int(pid)and v['literal']==p['app']for v in s['mapped_ELFs'].values())for pid in s['live_apps'])
 if p['phase']=='desktop':assert s['actual_private_xvfb']
 else:
  reports=list((out/'actual-device').glob('*/device.txt'));assert reports
  for f in reports:
   text=f.read_text();v=dict(line.split('=',1)for line in text.splitlines()if '='in line and not line.startswith('fd='));assert'Arc'in v['renderer']and'A770'in v['renderer']and v['vendor']=='Intel'and v['render_node']=='/dev/dri/renderD129'and v['pci'].endswith('/0000:03:00.0')and v['vendor_id']=='0x8086'and v['device_id']=='0x56a0';assert int(v['egl_context'],16)and int(v['egl_display'],16)and re.search(r'^fd=\d+$',text,re.M)and(f.parent/'context-maps.txt').is_file()
  assert Path('/sys/dev/char/226:129/device/driver').resolve().name=='i915';s['actual_device_reports']={str(f):sha(f)for f in reports}
 assert not drift();s.update(state='complete',exit_code=0)
except BaseException as error:s.update(state='failed',exit_code=1,error=repr(error),traceback=traceback.format_exc())
finally:
 s['input_drift']=drift();s['remaining_owned']=[]
 if monitor:
  for row in s['steps']:
   for rec in row.get('known_processes',[]):
    if monitor.alive(rec):s['remaining_owned'].append(rec)
 if s['input_drift']or s['remaining_owned']:s.update(state='failed',exit_code=1)
 s['terminal']=True
 if lease:
  if'lease'in s:s['lease']['released']=time.time()
  save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 (out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');save()
raise SystemExit(s['exit_code'])
