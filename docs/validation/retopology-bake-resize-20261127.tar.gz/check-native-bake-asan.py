from pathlib import Path
import shlex
import subprocess

work=Path(__file__).resolve().parent
repo=work.parent.parent
base=work.parent/'retopology-portable-mtoon-20261127/asan'
out=work/'exact-v1-asan'
target='dome-sculpt-native-paint-resolution-test'
commands=subprocess.check_output(['ninja','-C',base,'-t','commands',target],text=True).splitlines()
compile=shlex.split(next(row for row in commands if row.endswith('/native-paint-resolution.cpp')))
assert '-fsanitize=address,undefined' in compile
obj=out/'native-paint-resolution.cpp.o'
compile[compile.index('-o')+1]=str(obj)
if '-MF' in compile:compile[compile.index('-MF')+1]=str(out/'native-paint-resolution.cpp.d')
runner=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user']
for directory in ('src','include','tests'):
    runner.extend(['--ro-bind',work/'source-v2'/directory,repo/directory])
with (out/'native-paint-resolution.cpp.build.log').open('w') as log:
    subprocess.run([*runner,*compile],cwd=base,stdout=log,stderr=subprocess.STDOUT,check=True)
link=shlex.split(commands[-1])[2:-2]
link[link.index('-o')+1]=str(out/target)
link[link.index(next(term for term in link if term.endswith('/native-paint-resolution.cpp.o')))]=str(obj)
link[link.index('libdome-sculpt-core.a')]=str(out/'libdome-sculpt-core.a')
link=[term for term in link if not term.startswith('-Wl,--dependency-file=')]
subprocess.run(link,cwd=base,check=True)
sdk=repo/'artifacts/sdk-20261126/toolkit-sanitize'
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
     'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
runner+=['--clearenv']
for name,value in env.items():runner.extend(['--setenv',name,value])
with (work/'asan-native-bake.log').open('w') as log:
    subprocess.run([*runner,out/target,'baked',out/'native-baked-paint-resolution'],stdout=log,stderr=subprocess.STDOUT,check=True)
