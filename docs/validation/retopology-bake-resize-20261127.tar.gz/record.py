from hashlib import file_digest, sha256
import gzip
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile

work=Path(__file__).resolve().parent
repo=work.parent.parent
baseline=work.parent/'retopology-paint-resize-20261127'
validation=repo/'docs/validation'
previous='c09a737f189df8dff98cb892b2461c73d5e222f0'

def digest(path):
    with path.open('rb') as file:return file_digest(file,'sha256').hexdigest()

def git(directory,*args):
    return subprocess.check_output(['git','-C',directory,*args]).decode().strip()

def load(name):
    return json.loads((work/name).read_text())

product=git(repo,'rev-parse','HEAD')
assert git(repo,'rev-parse','HEAD^')==previous
patch=subprocess.check_output(['git','-C',repo,'diff','--binary',previous,product])
assert sha256(patch).hexdigest()==digest(work/'source-v2.patch')
for relative in ('src/paint.cpp','src/texture-set-resample.cpp','src/texture-set-resample.hpp',
                 'tests/texture-set-source-export.cpp','CMakeLists.txt'):
    assert digest(work/'source-v1'/relative)==digest(work/'source-v2'/relative)
canonical=git(repo.parent/'DomeD','rev-parse','HEAD')
assert canonical==git(repo.parent/'DomeD','ls-remote','origin','refs/heads/main').split()[0]
assert 'FAIL The genuine native Bake keeps the patch resize control enabled' in (work/'baseline-native.log').read_text()

members=['record.py','check-v1.sh','check-v2.sh','check-v1-asan.py','check-native-bake-asan.py',
         'release-v1-build.log','release-v2-build.log','release-v2-tests.log','asan-v1-tests.log','asan-native-bake.log',
         'baseline-native.log','run-wayland.py','wayland-resize.py','bind-wayland.log','wayland-resize/report.json',
         'run-field-xr.py','field-xr.py','run-field-xr-paced.py','field-xr-paced.py','khronos.cjs','khronos.json','khronos.log',
         'strip-editable-package.py','render-portable.cpp','render-portable.py','run-render.py','xr-portable.py']
for name in ('paint.cpp','texture-set-resample.cpp','texture-set-source-export.cpp','native-paint-resolution.cpp'):
    members.append(f'exact-v1-asan/{name}.build.log')
case='retopology-imported-bake-resize'
profiles={}
for directory,log,count in [('release','release-v2-tests.log',25),('exact-v1-asan','asan-v1-tests.log',18)]:
    output=(work/log).read_text()
    passed=re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',output)
    assert f'0 tests failed out of {count}' in output and len(passed)==count and case in passed
    source=(work/directory/'Testing/Temporary/LastTest.log').read_text()
    controls=re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.',source,re.M|re.S)[1]
    assert 'PASS 941 imported material retopology checks' in controls
    member=f'{directory}-retopo-controls.log'
    (work/member).write_text(controls);members.append(member)
    if directory=='release':
        controls=re.search(r'^\d+/\d+ Testing: native-baked-paint-resolution\n(.*?)^Test Passed\.',source,re.M|re.S)[1]
        standalone=re.findall(r'^PASS (.+)$',controls,re.M)
        assert len(standalone)==11 and standalone==re.findall(r'^PASS (.+)$',(work/'asan-native-bake.log').read_text(),re.M)
        member='release-native-baked-controls.log'
        (work/member).write_text(controls);members.append(member)
    profiles[directory]=passed

hashes={}
for name in ('original-import.glb','raw-guide.dsculpt','raw-patch.dsculpt','resized-bake.dsculpt',
             'raw-standard.glb','raw-editable.glb','resized-bake-standard.glb','resized-bake-editable.glb'):
    paths=[work/f'{where}-retopo-bake'/name for where in ('v1','v2')]
    paths += [work/directory/case/name for directory in ('release','exact-v1-asan')]
    values={digest(path) for path in paths}
    assert len(values)==1
    hashes[name]=values.pop()
assert digest(work/'v1-retopo-bake/portable.glb')==digest(work/'v2-retopo-bake/portable.glb')
for name in ('native-float-bake64.dsculpt','native-ldr-bake64.dsculpt'):
    checksum=digest(work/'release/native-baked-paint-resolution'/name)
    assert checksum==digest(work/'exact-v1-asan/native-baked-paint-resolution'/name)==digest(work/'v2-native-bake'/name)
    hashes[name]=checksum
assert digest(work/'wayland-resize/painted256.dsculpt')==hashes['resized-bake.dsculpt']
wayland=load('wayland-resize/report.json')
assert wayland['complete'] and len(wayland['checks'])==12 and all(item['passed'] for item in wayland['checks'])

rendering={}
controller={}
for mode,renderer in [('software','llvmpipe'),('arc','Arc(tm) A770')]:
    path=f'v1-retopo-bake/render-portable-{mode}.log'
    log=(work/path).read_text()
    assert renderer in log and 'PASS package-free Bake and explicit Mikk tangent replay' in log
    row=re.search(r'PORTABLE_BAKE pixels=(\d+) maximum=(\d+) rms=([.\d]+)',log)
    pixels,maximum,rms=map(float,row.groups())
    assert pixels==5754 and maximum==1 and rms<.5
    stereo=f'xr-{mode}-v1-retopo-bake/compare.json'
    replay=load(stereo)
    assert replay['runtime']=='synthetic OpenXR' and replay['exact_ordered_close']
    assert all(eye['maximum_channel_difference']<=2 for eye in replay['differing_rgb_components_per_eye'])
    rendering[mode]=dict(renderer=renderer,pixels=int(pixels),maximum_8_bit=int(maximum),rms=rms,
                        per_eye=replay['differing_rgb_components_per_eye'])
    field='field-xr-'+('paced-' if mode=='software' else '')+mode
    proof=load(f'{field}/report.json')
    assert proof['complete'] and len(proof['checks'])==12 and renderer in proof['renderer']
    assert digest(work/field/'final.dsculpt')==hashes['resized-bake.dsculpt']
    controller[mode]=proof
    members.extend([path,stereo,f'v1-retopo-bake/verified-stereo-{mode}.log',f'{field}.log',f'{field}/report.json',f'{field}/runtime.json'])

khronos=load('khronos.json')
assert len(khronos['results'])==6
for result in khronos['results']:
    assert result['issues']['numErrors']==result['issues']['numWarnings']==0
    result['sha256']=digest(work/result['file'])
    raw=(work/result['file']).read_bytes()
    if 'resized-bake' in result['file']:
        count=struct.unpack_from('<I',raw,12)[0]
        document=json.loads(raw[20:20+count])
        assert 'TANGENT' in document['meshes'][0]['primitives'][0]['attributes']

archive=validation/(work.name+'.tar.gz')
archive_members={}
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0) as packed:
    with tarfile.open(fileobj=packed,mode='w') as tar:
        for name in members:
            binary=(work/name).read_bytes()
            archive_members[name]=sha256(binary).hexdigest()
            item=tarfile.TarInfo(name);item.size=len(binary)
            tar.addfile(item,io.BytesIO(binary))
receipt=dict(product=product,previous_main=previous,canonical_domed=canonical,
    release_application_sha256=digest(work/'release/dome-sculpt'),source_patch_sha256=digest(work/'source-v2.patch'),
    prior_release_core_sha256=digest(baseline/'release/libdome-sculpt-core.a'),
    asan_test_sha256=digest(work/'exact-v1-asan/dome-sculpt-texture-set-source-export-test'),
    asan_reduction_test_sha256=digest(work/'exact-v1-asan/dome-sculpt-native-paint-resolution-test'),
    tests=profiles,asan_additional_native_reduction_controls=standalone,matching_native_and_glb_sha256=hashes,
    enlargement=dict(original=64,resized=256,raw_bake_cells_exact=True,hidden_layer_cells_exact=True,
                     normal_representation='Canonical Mikk',portrayal='explicit GLB tangents'),
    analytical_reduction=dict(original=128,resized=64,float_coverage=.00125,absolute_red=10,
                              legacy_red=.00025,default_sharp_normals_refused=True),
    baseline_baked_resize=False,khronos=khronos,wayland=wayland,synthetic_controller=controller,
    graphics=rendering,physical_headset=False,backend='CPU paint resolution worker',
    archive_sha256=digest(archive),archive_members_sha256=archive_members)
(validation/(work.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
