"""PREPARE by default; --execute requires separately reviewed source and plan."""
import argparse,fcntl,hashlib,importlib.util,json,os,re,sys,time
from pathlib import Path
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent;CONTRACT=R/'artifacts/guard87-validation-fresh-v2-20261115';sys.path.insert(0,str(CONTRACT))
from runtime_contract import read_runtime,merge_pins
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';spec=importlib.util.spec_from_file_location('prepared_public_owned_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,j):Path(p).write_text(json.dumps(j,indent=2)+'\n')
def drift(pins):return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def main(a):
 review=json.loads((P/'native-public-plan-review-v1.json').read_text())
 if not a.execute:print(json.dumps(review,indent=2));return 0
 assert a.reviewed_source==review['source_commit']and a.output_tag and '/'not in a.output_tag
 out=P/a.output_tag;out.mkdir(exist_ok=False);linked=json.loads((P/'status.json').read_text());assert linked['state']=='terminal'and linked['exit']==0 and not linked['input_drift']and linked['source']==a.reviewed_source
 pins=json.loads((P/'inputs.json').read_text());assert not drift(pins);runtime=read_runtime();merge_pins(pins,runtime['pins'])
 for p in [Path(__file__).resolve(),M,P/'status.json',P/'inputs.json',P/'native-public-plan-review-v1.json',CONTRACT/'runtime_contract.py',CONTRACT/'runtime-preflight.json']:pins[str(p)]=sha(p)
 for row in review['prerequisite_files']:
  assert sha(row['path'])==row['sha256'];pins[row['path']]=row['sha256']
 app_loader=json.loads(Path(review['app_loader_status']['path']).read_text());assert app_loader['state']=='terminal'and app_loader['exit']==0 and not app_loader['input_drift'];merge_pins(pins,app_loader['pins'])
 products=linked['products'];inspector=products['prepared']['path'];font=products['font']['path'];state={'state':'preparing','exit':1,'pid':os.getpid(),'source':a.reviewed_source,'product':'1bc13125','scope':review['scope'],'steps':[]};lease=None
 env={k:v for k,v in os.environ.items()if not k.startswith(('DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for k in ['LD_PRELOAD','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(k,None)
 env.update(LD_LIBRARY_PATH=str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',LP_NUM_THREADS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',XR_RUNTIME_JSON=str(out/'physical-xr-blocked.json'))
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(out/leaf);Path(env[key]).mkdir(mode=0o700)
 def save():write(out/'status.json',state)
 def execute(name,cmd,expected=0):
  def progress(row):state['live']={'name':name,**row};save()
  row=monitor.run(cmd,cwd=out,env=env,log=out/(name+'.log'),timeout=900,max_rss=4*1024**3,progress=progress);row.update(name=name,log_sha256=sha(out/(name+'.log')));state['steps'].append(row);state.pop('live',None);save();print(name,row.get('exit'),flush=True)
  assert row['exit']==expected and 'error'not in row and not row['signals'],(name,row)
  return(out/(name+'.log')).read_text()
 try:
  assert not drift(pins);lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);state['lease']={'owner_pid':os.getpid(),'owner_identity':monitor.identity(os.getpid()),'acquired_epoch':time.time(),'before_any_built_product':True};save()
  for name,prod in products.items():
   text=execute('ldd-'+name,['ldd',prod['path']]);assert 'not found'not in text
   for p in re.findall(r'(/[^\s()]+)',text):
    if Path(p).is_file():assert p in pins and sha(p)==pins[p],('Actual loader provider outside current boundary',p)
  write(out/'inputs-before.json',pins)
  text=execute('native91',[inspector,str(out/'native91')]);assert 'PASS 91 prepared source controls'in text
  text=execute('public-producer',[inspector,'--public-fixtures',str(out/'capsules')]);assert re.search(r'PASS [1-9][0-9]* public prepared-source capsule checks',text)
  suite=json.loads((out/'capsules/manifest.json').read_text());assert suite['version']==1 and suite['kind']=='ordinary-prepared-normal-public-suite'and set(suite['cases'])=={'mt0-rest','mt0-posed','mt1-rest','mt1-posed'}and suite['existing_native91_unchanged']and suite['new_targets']==0
  requests=out/'capsules'/suite['label_requests'];labels=json.loads(requests.read_text());assert len(labels)==22 and len({r['key']for r in labels})==22
  cases={}
  for name,relative in suite['cases'].items():
   mf=out/'capsules'/relative;m=json.loads(mf.read_text());assert m['all_three_objects_retained']and m['source_choice_initial']==m['original_source']and m['source_choice_required']==m['prepared_source']and m['genuine_first_bake_source']==m['original_source']and m['wrong_original_must_fail_full_native_endpoint'];cases[name]=m
   for route in ['desktop','xr']:
    files=m['routes'][route];expected=mf.parent/files['expected'];wrong=mf.parent/files['wrong_original']
    for phase,file in [('accepted',expected),('undone',mf.parent/m['before']),('redone',expected),('reopened',expected)]:
     text=execute(name+'-'+route+'-'+phase,[inspector,'--verify-public',str(mf),route,phase,str(file)]);j=json.loads(text);assert j['verified']and j['all_sources_and_first_recipe_exact']
    text=execute(name+'-'+route+'-negative-wrong-original',[inspector,'--verify-public',str(mf),route,'accepted',str(wrong)],expected=1);assert 'Actual UI must match the independent prepared endpoint and reject the independently produced wrong-Original endpoint'in text
  default=out/'titles-default.json';extended=out/'titles-public.json';execute('font-default',[font,str(default)]);execute('font-additive',[font,str(extended),str(requests)]);d=json.loads(default.read_text());e=json.loads(extended.read_text());baseline=json.loads(Path(review['old_font_reference']['path']).read_text());assert d==baseline and set(d['masks'])=={'Dome Sculpt','Objects','Mesh tools','Mesh baking'}
  assert e['font_file']==d['font_file']and e['font_pixels']==d['font_pixels']==16 and e['unit']==d['unit']==1 and e['width']==e['height']==640 and e['opacity']==255
  assert set(e['masks'])==set(d['masks'])|{r['key']for r in labels}
  for key,m in d['masks'].items():assert e['masks'][key]==m
  for request in labels:
   m=e['masks'][request['key']];assert m['ink']and all(0<=x<640 and 0<=y<640 for x,y in m['ink'])
  pins[d['font_file']]=sha(d['font_file']);write(out/'verified-summary.json',{'source':a.reviewed_source,'native91':91,'cases':list(cases),'routes':['desktop','xr'],'positive_verifier_calls':32,'wrong_original_rejections':8,'full_three_object_context':True,'finite_first_prepared_to_second_normal_bound':.035,'existing_original_artist_sensitivity':'Separately retained native91/artist139/component24 proofs; this default public producer is an endpoint/source-choice and prepared-normal preservation oracle','original_font4_exact':True,'additive_labels':22,'new_targets':0,'UI_execution':False})
  state['outputs']={str(p):sha(p)for root in [out/'native91',out/'capsules']for p in root.rglob('*')if p.is_file()};state['outputs'].update({str(p):sha(p)for p in [default,extended,out/'verified-summary.json']});state['exit']=0
 except BaseException as e:state['error']=repr(e)
 finally:
  state['input_drift']=drift(pins);state['exit']=state['exit']or int(bool(state['input_drift']));write(out/'inputs-final.json',pins)
  if lease:state['lease']['released_epoch']=time.time();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
  state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
 return state['exit']
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--reviewed-source');p.add_argument('--output-tag');raise SystemExit(main(p.parse_args()))
