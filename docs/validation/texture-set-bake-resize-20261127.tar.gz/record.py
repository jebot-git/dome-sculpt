import gzip
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
previous = 'ba94b8d0e3f062ec8b01643ec54728c8dd7dcd10'
base = work.parent / 'retopology-bake-resize-20261127'

def git(directory, *args):
    return subprocess.check_output(['git', '-C', directory, *args]).decode().strip()

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()

def load(name):
    return json.loads((work / name).read_text())

product = git(repo, 'rev-parse', 'HEAD')
assert git(repo, 'rev-parse', 'HEAD^') == previous
patch = subprocess.check_output(['git', '-C', repo, 'diff', '--binary', previous, product])
assert sha256(patch).hexdigest() == digest(work / 'source-v2.patch')
files = git(repo, 'diff', '--name-only', previous, product).splitlines()
assert len(files) == 5
for relative in files:
    assert digest(work / 'source-v2' / relative) == digest(repo / relative)
    if relative.startswith('src/'):
        assert digest(work / 'source-v1' / relative) == digest(work / 'source-v2' / relative)

domed = repo.parent / 'DomeD'
canonical = git(domed, 'rev-parse', 'HEAD')
assert canonical == git(domed, 'ls-remote', 'origin', 'refs/heads/main').split()[0]

members = ['record.py', 'check-v1.sh', 'check-v2.sh', 'check-asan.py', 'check-baseline.py',
           'source-v2.patch', 'release-v1-tests.log', 'release-v2-tests.log', 'release-v1-build.log',
           'release-v2-build.log', 'asan-tests.log', 'baseline.log', 'run-wayland.py', 'wayland-resize.py',
           'bind-wayland.log', 'wayland-resize/report.json', 'field-xr-paced.py', 'run-field-xr-paced.py',
           'check-portable.py', 'portable-attributes.json', 'khronos.cjs', 'khronos.json', 'khronos.log',
           'strip-editable-package.py', 'render-portable.cpp', 'render-portable.py', 'run-render.py', 'xr-portable.py',
           'alpha-observer-software.log']
members.extend(f'asan/{name}.build.log' for name in ('paint.cpp', 'texture-set-resample.cpp', 'texture-set-resolution.cpp'))
assert 'Source/baked/prepared field resolution needs its authenticated writable-grid transition' in (work / 'baseline.log').read_text()
assert 'FAIL after 43 checks' in (work / 'release-v1-tests.log').read_text()

profiles = {}
for directory, log, count in [('release', 'release-v2-tests.log', 27), ('asan', 'asan-tests.log', 20)]:
    output = (work / log).read_text()
    passed = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', output)
    assert f'0 tests failed out of {count}' in output and len(passed) == count
    assert 'dome-sculpt-texture-set-baked-resolution' in passed and 'dome-sculpt-texture-set-resolution' in passed
    log = (work / directory / 'Testing/Temporary/LastTest.log').read_text()
    case = 'dome-sculpt-texture-set-baked-resolution'
    controls = re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.', log, re.M | re.S)[1]
    assert 'PASS 52 measured texture resolution checks' in controls
    member = f'{directory}-baked-material-controls.log'
    (work / member).write_text(controls)
    members.append(member)
    profiles[directory] = list(sorted(passed))

hashes = {}
for relative in ('baked-member-128.dsculpt', 'baked-member-256.dsculpt',
                 'baked-member-standard.glb', 'baked-member-editable.glb'):
    paths = [work / 'v2-baked' / relative]
    paths += [work / p / 'texture-set-baked-resolution-output' / relative for p in profiles]
    values = {digest(path) for path in paths}
    assert len(values) == 1
    hashes[relative] = values.pop()

def controls(report, log):
    assert report['complete'] and len(report['checks']) == 12
    expected = [check if isinstance(check, str) else check['check'] for check in report['checks']]
    assert re.findall(r'^PASS (.+)$', (work / log).read_text(), re.M) == expected
    return report

wayland = controls(load('wayland-resize/report.json'), 'bind-wayland.log')
assert digest(work / 'wayland-resize/painted256.dsculpt') == hashes['baked-member-256.dsculpt']
rendering = {}
controller = {}
for mode, renderer in [('software', 'llvmpipe'), ('arc', 'Arc(tm) A770')]:
    path = f'v2-baked/render-portable-{mode}.log'
    report = (work / path).read_text()
    assert renderer in report and 'PASS package-free Bake and explicit Mikk tangent replay' in report
    pixels, maximum, rms, left, right = map(float, re.search(
        r'PORTABLE_BAKE pixels=(\d+) maximum=(\d+) rms=([.\d]+) left=(\d+) right=(\d+)', report).groups())
    assert pixels == left + right and min(left, right) > 5000 and maximum == 1 and rms < .1
    stereo = f'xr-{mode}-v2-baked/compare.json'
    replay = load(stereo)
    assert replay['runtime'] == 'synthetic OpenXR' and replay['exact_ordered_close']
    assert all(eye['maximum_channel_difference'] <= 1 for eye in replay['differing_rgb_components_per_eye'])
    rendering[mode] = dict(renderer=renderer, pixels_by_material=[int(left), int(right)], maximum_8_bit=int(maximum),
                           rms=rms, per_eye=replay['differing_rgb_components_per_eye'])
    field = f'field-xr-paced-{mode}'
    proof = controls(load(f'{field}/report.json'), f'{field}.log')
    assert renderer in proof['renderer'] and digest(work / field / 'final.dsculpt') == hashes['baked-member-256.dsculpt']
    controller[mode] = proof
    members.extend([path, stereo, f'v2-baked/verified-stereo-{mode}.log', f'{field}.log',
                    f'{field}/report.json', f'{field}/runtime.json'])

khronos = load('khronos.json')
assert len(khronos['results']) == 3 and all(
    row['issues']['numErrors'] == row['issues']['numWarnings'] == 0 for row in khronos['results'])
attributes = load('portable-attributes.json')
assert len(attributes) == 3 and all(len(row) == 2 for row in attributes.values())
validation = repo / 'docs/validation'
name = 'texture-set-bake-resize-20261127'
bundle = validation / (name + '.tar.gz')
members = sorted(set(members))
with bundle.open('wb') as output, gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as archive:
        for relative in members:
            path = work / relative
            info = archive.gettarinfo(str(path), arcname=relative)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with path.open('rb') as stream:
                archive.addfile(info, stream)
archive_hashes = {relative: digest(work / relative) for relative in members}
with tarfile.open(bundle) as archive:
    assert {entry.name: sha256(archive.extractfile(entry).read()).hexdigest() for entry in archive} == archive_hashes
summary = dict(product=product, previous_main=previous, canonical_domed=canonical, backend='CPU',
               source_patch_sha256=sha256(patch).hexdigest(), tests=profiles, baked_material_checks=52,
               previous_worker_refusal=(work / 'baseline.log').read_text(),
               previous_core_sha256=digest(base / 'release/libdome-sculpt-core.a'),
               release_application_sha256=digest(work / 'release/dome-sculpt'),
               sanitizer_core_sha256=digest(work / 'asan/libdome-sculpt-core.a'),
               matching_native_and_glb_sha256=hashes, wayland=wayland, synthetic_controller=controller,
               portable_attributes=attributes, graphics=rendering, khronos=khronos, physical_headset=False,
               archive_sha256=digest(bundle), archive_members_sha256=archive_hashes)
(validation / (name + '.json')).write_text(json.dumps(summary, indent=2, sort_keys=True) + '\n')
print(product, 'Release27, ASan/UBSan20, Wayland12, synthetic OpenXR12+12, Khronos3')
