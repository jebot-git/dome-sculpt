from pathlib import Path
import json
import math
import struct

work = Path(__file__).resolve().parent
fixture = work / 'v2-baked'

def inspect(path):
    data = path.read_bytes()
    magic, version, total, length, chunk = struct.unpack_from('<5I', data)
    assert (magic, version, total, chunk) == (0x46546c67, 2, len(data), 0x4e4f534a)
    doc = json.loads(data[20:20+length])
    binary = memoryview(data)[28+length:]
    assert len(doc['meshes']) == 1 and len(doc['materials']) == 2

    def accessor(index, component_type, shape, fmt):
        spec = doc['accessors'][index]
        view = doc['bufferViews'][spec['bufferView']]
        start = view.get('byteOffset', 0) + spec.get('byteOffset', 0)
        assert spec['componentType'] == component_type and spec['type'] == shape
        size = struct.calcsize(fmt)
        stride = view.get('byteStride', size)
        return [struct.unpack_from(fmt, binary, start + i * stride) for i in range(spec['count'])]

    def dimensions(info):
        texture = doc['textures'][info['index']]
        image = doc['images'][texture['source']]
        view = doc['bufferViews'][image['bufferView']]
        start = view.get('byteOffset', 0)
        assert image['mimeType'] == 'image/png' and binary[start+12:start+16] == b'IHDR'
        return struct.unpack_from('>II', binary, start + 16)

    result = []
    for slot, primitive in enumerate(doc['meshes'][0]['primitives']):
        assert primitive['material'] == slot
        material = doc['materials'][slot]
        attrs = primitive['attributes']
        positions = accessor(attrs['POSITION'], 5126, 'VEC3', '<3f')
        tangents = accessor(attrs['TANGENT'], 5126, 'VEC4', '<4f')
        indices = [i[0] for i in accessor(primitive['indices'], 5125, 'SCALAR', '<I')]
        assert indices == [i + 4 * slot for i in (0, 1, 2, 0, 2, 3)]
        assert all(positions[i][0] * (1 if slot else -1) > 0 for i in indices)
        assert len(tangents) == len(positions) and all(
            math.isclose(math.hypot(*tangents[i][:3]), 1, abs_tol=1e-6) and abs(tangents[i][3]) == 1
            for i in indices)
        pbr = material['pbrMetallicRoughness']
        maps = {'base': pbr['baseColorTexture'], 'metal_rough': pbr['metallicRoughnessTexture'],
                'occlusion': material['occlusionTexture'], 'normal': material['normalTexture'],
                'emission': material['emissiveTexture']}
        resolution = 256 if slot else 64
        sizes = {role: dimensions(info) for role, info in maps.items()}
        assert set(sizes.values()) == {(resolution, resolution)}
        strength = material.get('extensions', {}).get('KHR_materials_emissive_strength', {}).get('emissiveStrength', 1)
        assert strength > 100 if slot else strength == 1
        result.append({'material': material['name'], 'indices': indices, 'maps': sizes,
                       'tangents_available': True, 'emissive_strength': strength})
    assert len(result) == 2
    return result

reports = {name: inspect(fixture / name) for name in
           ('baked-member-standard.glb', 'baked-member-editable.glb', 'portable.glb')}
assert len(set(json.dumps(row, sort_keys=True) for row in reports.values())) == 1
(work / 'portable-attributes.json').write_text(json.dumps(reports, indent=2) + '\n')
