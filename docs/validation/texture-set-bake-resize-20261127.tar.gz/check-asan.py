from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import re
import shlex
import subprocess

work = Path(__file__).resolve().parent
repo = work.parent.parent
seed = work.parent / 'retopology-portable-mtoon-20261127/asan'
previous = work.parent / 'retopology-bake-resize-20261127/exact-v1-asan'
out = work / 'asan'
out.mkdir(exist_ok=True)
target = 'dome-sculpt-texture-set-resolution-test'
targets = (target, 'dome-sculpt-retopo-surface-heat-test', 'dome-sculpt-texture-set-source-export-test')
commands = {name: subprocess.check_output(['ninja', '-C', seed, '-t', 'commands', name], text=True).splitlines()
            for name in targets}
sandbox = ['bwrap', '--die-with-parent', '--unshare-all', '--ro-bind', '/', '/',
           '--bind', out, out, '--proc', '/proc', '--dev', '/dev', '--tmpfs', '/tmp', '--tmpfs', '/run/user']
sources = [item for directory in ('src', 'include', 'tests')
           for item in ('--ro-bind', work / 'source-v2' / directory, repo / directory)]

def compile_unit(name):
    command = shlex.split(next(line for line in commands[target] if line.endswith('/' + name)))
    assert '-fsanitize=address,undefined' in command
    obj = out / (name + '.o')
    command[command.index('-o') + 1] = str(obj)
    if '-MF' in command:
        command[command.index('-MF') + 1] = str(out / (name + '.d'))
    with (out / (name + '.build.log')).open('w') as log:
        subprocess.run([*sandbox, *sources, *command], cwd=seed, stdout=log, stderr=subprocess.STDOUT, check=True)
    return obj

with ThreadPoolExecutor(max_workers=3) as workers:
    objects = list(workers.map(compile_unit, ('paint.cpp', 'texture-set-resample.cpp', 'texture-set-resolution.cpp')))

archive = out / 'libdome-sculpt-core.a'
subprocess.run(['cp', '--reflink=always', previous / archive.name, archive], check=True)
subprocess.run(['ar', 'rs', archive, *objects[:2]], check=True)
for name in targets:
    link = shlex.split(commands[name][-1])[2:-2]
    link[link.index('-o') + 1] = str(out / name)
    link[link.index(archive.name)] = str(archive)
    if name == target:
        link[link.index(next(term for term in link if term.endswith('/texture-set-resolution.cpp.o')))] = str(objects[2])
    if name == targets[2]:
        link[link.index(next(term for term in link if term.endswith('/texture-set-source-export.cpp.o')))] = str(previous / 'texture-set-source-export.cpp.o')
    link = [term for term in link if not term.startswith('-Wl,--dependency-file=')]
    subprocess.run(link, cwd=seed, check=True)

release_seed = work.parent / 'retained-texture-set-shape-20261127/release'
old_tests = (previous / 'CTestTestfile.cmake').read_text().replace(str(previous), str(out)).rstrip()
new_tests = []
for line in (work / 'release/CTestTestfile.cmake').read_text().splitlines():
    if re.match(r'^add_test\(\[=\[dome-sculpt-texture-set-(baked-)?resolution\]=\]', line):
        new_tests.append(line.replace(str(release_seed), str(out)))
assert len(new_tests) == 2
(out / 'CTestTestfile.cmake').write_text('\n'.join([old_tests, *new_tests]) + '\n')
sdk = repo / 'artifacts/sdk-20261126/toolkit-sanitize'
env = {'PATH': '/usr/bin:/bin', 'HOME': '/tmp', 'LIBGL_ALWAYS_SOFTWARE': '1', 'LP_NUM_THREADS': '2',
       'LD_LIBRARY_PATH': f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
       'ASAN_OPTIONS': 'detect_leaks=1:halt_on_error=1',
       'UBSAN_OPTIONS': 'halt_on_error=1:print_stacktrace=1'}
environment = [item for name, value in env.items() for item in ('--setenv', name, value)]
with (work / 'asan-tests.log').open('w') as log:
    subprocess.run([*sandbox, '--clearenv', *environment, 'ctest', '--test-dir', out, '--parallel', '3',
                    '--output-on-failure'], stdout=log, stderr=subprocess.STDOUT, check=True)
