#include "dome/material-bindings.hpp"
#include "dome/render.hpp"
#include "dome/import-authoring.hpp"
#include "dome/texture-sets.hpp"
#include "graphics.h"
#include <algorithm>
#include <iostream>

using namespace dome;
namespace {
constexpr int width = 128;
constexpr int height = 128;
const Mat4 identity{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
using Pixels = std::array<uint8_t,width*height*4>;

Pixels draw(SurfaceRenderer &renderer, const Scene &scene,bool pbr=false) {
  Document document;
  document.replace(scene);
  if (pbr) document.shading(false);
  if (!document.wait_asset() || !document.wait_mesh() || !document.frame().state->error.empty())
    throw std::runtime_error(document.frame().state->error);
  renderer.draw(document.frame().surface,{},identity,{0,0,2},width,height,true);
  Pixels result{};
  glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,result.data());
  if (glGetError()!=GL_NO_ERROR) throw std::runtime_error("Fixture framebuffer read failed");
  return result;
}

}

int main(int argc, char **argv) try {
  if (argc!=3&&argc!=4) return 2;
  NativeGraphics graphics;
  std::cout<<"GPU "<<glGetString(GL_RENDERER)<<'\n';
  GLuint framebuffer=0, color=0, depth=0;
  glGenFramebuffers(1,&framebuffer);
  glBindFramebuffer(GL_FRAMEBUFFER,framebuffer);
  glGenTextures(1,&color);
  glBindTexture(GL_TEXTURE_2D,color);
  glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
  glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,color,0);
  glGenRenderbuffers(1,&depth);
  glBindRenderbuffer(GL_RENDERBUFFER,depth);
  glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,width,height);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,depth);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)
    throw std::runtime_error("Incomplete fixture framebuffer");
  SurfaceRenderer renderer;
  const auto scene=Scene::load(argv[1]);
  const auto consume=[](const auto *path) {
    auto imported=prepare_authoring_import(Scene{},path,{});
    if (imported.objects.size() != 2)
      throw std::runtime_error("Portable import must keep both material primitives");
    for (const auto &object : imported.scene.objects())
      if (std::find(imported.objects.begin(), imported.objects.end(), object.id) == imported.objects.end())
        imported.scene.object(object.id).visible = false;
    for (const auto id : imported.objects) {
      const auto &rendered = imported.scene.object(id);
      if (!rendered.appearance || !rendered.material_bindings || rendered.material_bindings->has_mtoon ||
          !rendered.material_bindings->normal_frames || !rendered.material_bindings->normal_frames->pbr ||
          rendered.material_bindings->normal_frames->pbr->generated_tangents)
        throw std::runtime_error("Package-free import failed to retain a material's supplied PBR tangent frame");
    }
    return imported.scene;
  };
  const auto portable=consume(argv[2]);
  if(argc==4)portable.save(argv[3]);
  const auto rendered=draw(renderer,portable,true);
  const auto native=draw(renderer,scene,true);
  const auto compare=[](const Pixels &before,const Pixels &imported) {
    size_t opaque=0,borders=0;
    std::array<size_t,2> materials{};
    int worst=0;
    double squared=0;
    for(size_t at=0;at<before.size();at+=4){
      borders+=(before[at+3]>0)!=(imported[at+3]>0);
      if(!before[at+3]||!imported[at+3]) continue;
      ++opaque;
      ++materials[(at / 4) % width >= width / 2];
      for(size_t k=0;k<4;++k) {
        const auto d=std::abs(int(before[at+k])-imported[at+k]);
        worst=std::max(worst,d);
        squared+=double(d)*d;
      }
    }
    std::cout << "VISIBILITY left=" << materials[0] << " right=" << materials[1] << " borders=" << borders << '\n';
    for(int x : {32, 96}) {
      std::cout << "PIXEL " << x;
      for(const auto &image : {&before, &imported}) for(int channel=0;channel<4;++channel)
        std::cout << " " << int((*image)[4*(64*width+x)+channel]);
      std::cout << '\n';
    }
    if(*std::min_element(materials.begin(),materials.end())<200||borders>20)throw std::runtime_error("Portable visibility differs from the native surface");
    return std::tuple{opaque,worst,std::sqrt(squared/(4*opaque)),materials};
  };
  const auto [pixels,maximum,rms,materials]=compare(native,rendered);
  std::cout<<"PORTABLE_BAKE pixels="<<pixels<<" maximum="<<maximum<<" rms="<<rms<<" left="<<materials[0]<<" right="<<materials[1]<<std::endl;
  if(maximum>5||rms>1.5)throw std::runtime_error("Portable baked PBR differs from native rendering");
  std::cout<<"PASS package-free Bake and explicit Mikk tangent replay"<<std::endl;
  glDeleteRenderbuffers(1,&depth);
  glDeleteTextures(1,&color);
  glDeleteFramebuffers(1,&framebuffer);
} catch (const std::exception &error) {
  std::cerr<<"FAIL "<<error.what()<<'\n';
  return 1;
}
