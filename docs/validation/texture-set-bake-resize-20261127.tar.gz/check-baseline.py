from pathlib import Path
import os
import shlex
import subprocess

work = Path(__file__).resolve().parent
build = work / 'release'
prior = work.parent / 'retopology-bake-resize-20261127/release/libdome-sculpt-core.a'
target = 'dome-sculpt-texture-set-resolution-test'
binary = work / 'previous-core-resolution-test'
row = subprocess.check_output(['ninja', '-C', build, '-t', 'commands', target], text=True).splitlines()[-1]
link = shlex.split(row)[2:-2]
link[link.index('-o') + 1] = str(binary)
link[link.index(prior.name)] = str(prior)
link = [term for term in link if not term.startswith('-Wl,--dependency-file=')]
subprocess.run(link, cwd=build, check=True)
env = dict(os.environ, LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
result = subprocess.run([binary, work / 'previous-core-baked', 'baked'], env=env, text=True,
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=20)
(work / 'baseline.log').write_text(result.stdout)
assert result.returncode == 1 and 'Source/baked/prepared field resolution' in result.stdout, result.stdout
