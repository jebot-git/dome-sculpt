from hashlib import file_digest, sha256
from pathlib import Path
import gzip
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work = Path(__file__).resolve().parent
repo = work.parent.parent
previous = '43fc158b6e5fc91a81a76ee46dc1afdab3d4f3ef'

def git(path, *args):
    return subprocess.check_output(['git', '-C', path, *args], text=True).strip()

def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()

def load(path):
    return json.loads((work / path).read_text())

product = git(repo, 'rev-parse', 'HEAD')
assert git(repo, 'rev-parse', 'HEAD^') == previous
patch = subprocess.check_output(['git', 'diff', '--binary', previous, product], cwd=repo)
assert sha256(patch).hexdigest() == digest(work / 'source-v4.patch')
for name in git(repo, 'diff', '--name-only', previous, product).splitlines():
    assert digest(repo / name) == digest(work / 'frozen-v4' / name)
canonical = git(repo.parent / 'DomeD', 'rev-parse', 'HEAD')
assert canonical == git(repo.parent / 'DomeD', 'ls-remote', 'origin', 'refs/heads/main').split()[0]

cases = list(ET.parse(work / 'release/mtoon-resize.xml').getroot().iter('testcase'))
release = sorted(case.attrib['name'] for case in cases)
assert len(release) == 29 and all(case.find('failure') is None and case.find('skipped') is None for case in cases)
assert '0 tests failed out of 29' in (work / 'release-tests.log').read_text()
assert {'dome-sculpt-texture-set-baked-mtoon-resolution','mtoon-resized-texture-set'} <= set(release)
assert 'PASS 68 measured texture resolution checks' in (work / 'native-v4.log').read_text()
assert 'REFUSED unchanged: Source or independently prepared field resolution' in (work / 'baseline-old.log').read_text()
assert 'PASS typed Bake resize' in (work / 'baseline-new.log').read_text()
asan = {}
for mode, count in [('default',2319), ('baked',52), ('baked-mtoon',68)]:
    text = (work / f'asan/{mode}.log').read_text()
    assert f'PASS {count} measured texture resolution checks' in text
    assert 'runtime error:' not in text and 'AddressSanitizer' not in text
    asan[mode] = count

hashes = {}
def match(name, dirs):
    values = {digest(work / directory / name) for directory in dirs}
    assert len(values) == 1, (name, values)
    hashes[name] = values.pop()

for name in ('baked-member-128.dsculpt','baked-member-256.dsculpt','baked-member-standard.glb',
             'baked-member-editable.glb','mtoon-core-images.dsculpt'):
    match(name, ('baked-v4','release/texture-set-baked-mtoon-resolution-output','asan/baked-mtoon'))
for name in ('painted-original.dsculpt','painted-resized.dsculpt','rendered-varying-mtoon.glb',
             'painted-resized-editable.glb'):
    match(name, ('painted-v4','release/mtoon-resized-texture-set','painted-arc'))
for name in ('wayland-resize/painted256.dsculpt','field-xr-paced-arc/final.dsculpt',
             'field-xr-paced-software/final.dsculpt'):
    assert digest(work / name) == hashes['baked-member-256.dsculpt']

def verified_controls(directory, log):
    controls = load(f'{directory}/report.json')
    assert controls['complete'] and len(controls['checks']) == 12
    assert [item if isinstance(item, str) else item['check'] for item in controls['checks']] == \
        re.findall(r'^PASS (.+)$', (work / log).read_text(), re.M)
    return controls

wayland = verified_controls('wayland-resize','bind-wayland.log')
xr = {}
pictures = {}
for gpu, renderer in [('arc','Arc(tm) A770'),('software','llvmpipe')]:
    directory = f'field-xr-paced-{gpu}'
    xr[gpu] = verified_controls(directory, f'{directory}.log')
    assert renderer in xr[gpu]['renderer']
    painted = (work / f'painted-v4-{gpu}.log').read_text()
    baked = (work / f'baked-v4/render-portable-{gpu}.log').read_text()
    assert renderer in painted and renderer in baked
    assert 'PASS 49 resized MToon texture-set graphics checks' in painted
    assert 'visible=780 hole_probes=40 max_rgb=1 alpha_differences=0' in painted and 'rays=35' in painted
    assert 'PASS package-free Bake and explicit Mikk tangent replay' in baked
    values = re.search(r'PORTABLE_BAKE pixels=(\d+) maximum=(\d+) rms=([.\d]+) left=(\d+) right=(\d+)', baked)
    pixels, maximum, rms, left, right = map(float, values.groups())
    assert pixels == 11628 and maximum == 1 and left == right == 5814 and rms < .2
    pictures[gpu] = {'baked_pixels': int(pixels), 'baked_max_rgba8': int(maximum), 'baked_rms': rms,
                     'painted_max_rgb8': 1, 'painted_alpha_differences': 0, 'painted_visibility_rays': 35}
khronos = load('khronos.json')
schemas = load('schemas.json')
assert len(khronos['results']) == 5 and all(
    entry['issues']['numErrors'] == entry['issues']['numWarnings'] == 0 for entry in khronos['results'])
assert schemas['cases'] == [entry['uri'] for entry in khronos['results']] and schemas['malformed_shade_role_refused']

files = ['record.py','source-v4.patch','build-v4.sh','check-release.sh','check-asan.py','check-baseline.py',
         'baseline-probe.cpp','baseline-old.log','baseline-new.log','native-v4.log','release-v4-build.log',
         'release-tests.log','regression-build.log','release/mtoon-resize.xml','check-arc.sh',
         'run-wayland.py','wayland-resize.py','bind-wayland.log','first-wayland.log','first-wayland.json',
         'wayland-resize/report.json','run-field-xr-paced.py','field-xr-paced.py','render-portable.cpp',
         'render-portable.py','strip-editable-package.py','painted-v2-software.log','khronos.cjs','khronos.log',
         'khronos.json','schemas.py','schemas.log','schemas.json']
files.extend(f'asan/{mode}.log' for mode in asan)
for gpu in xr:
    slot = f'field-xr-paced-{gpu}'
    files.extend((f'painted-v4-{gpu}.log',f'baked-v4/render-portable-{gpu}.log',f'{slot}.log',f'{slot}/report.json',
                  f'{slot}/runtime.json'))

record = 'texture-set-mtoon-resize-20261127'
folder = repo / 'docs/validation'
bundle = folder / (record + '.tar.gz')
members = {name: digest(work / name) for name in sorted(files)}
with bundle.open('wb') as output, gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode='w') as archive:
        for name in members:
            path = work / name
            info = archive.gettarinfo(str(path), arcname=name)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with path.open('rb') as stream:
                archive.addfile(info, stream)
with tarfile.open(bundle) as archive:
    assert members == {entry.name: sha256(archive.extractfile(entry).read()).hexdigest() for entry in archive}
receipt = dict(product=product, previous_main=previous, canonical_domed=canonical, resize_backend='CPU',
               release_tests=release, sanitizer_checks=asan, wayland=wayland, synthetic_controller=xr,
               rendering=pictures, khronos=khronos, mtoon_schema=schemas, physical_headset=False,
               matching_native_and_glb_sha256=hashes, archive_sha256=digest(bundle), archive_members_sha256=members,
               release_application_sha256=digest(work / 'release/dome-sculpt'),
               source_patch_sha256=sha256(patch).hexdigest())
(folder / (record + '.json')).write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(product, 'Release29, ASan/UBSan3, Wayland12, synthetic OpenXR12+12, Khronos5, pinned MToon5')
