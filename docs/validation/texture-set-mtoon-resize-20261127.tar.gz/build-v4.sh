#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$work/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/release"
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$work/frozen-v4/CMakeLists.txt" "$repo/CMakeLists.txt" --ro-bind "$work/frozen-v4/src" "$repo/src" --ro-bind "$work/frozen-v4/include" "$repo/include" --ro-bind "$work/frozen-v4/tests" "$repo/tests" --bind "$work/release" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${sandbox[@]}" cmake --build "$seed" --parallel 4 --target dome-sculpt dome-sculpt-texture-set-resolution-test dome-sculpt-mtoon-render-test > "$work/release-v4-build.log" 2>&1
