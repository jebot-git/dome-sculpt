const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const validator = require('../hdr-khronos-validation-20261126/module/package');

async function main() {
    const results = [];
    const cases = [
        'baked-v4/baked-member-standard.glb',
        'baked-v4/baked-member-editable.glb',
        'baked-v4/portable.glb',
        'painted-v4/rendered-varying-mtoon.glb',
        'painted-v4/painted-resized-editable.glb',
    ];
    for (const uri of cases) {
        const bytes = fs.readFileSync(path.join(__dirname, uri));
        const document = JSON.parse(bytes.toString('utf8', 20, 20 + bytes.readUInt32LE(12)));
        const primitives = document.meshes[0].primitives;
        assert.equal(primitives.length, 2, uri);
        const typed = primitives.filter(p => document.materials[p.material].extensions?.VRMC_materials_mtoon);
        assert.equal(typed.length, 1, uri);
        const primitive = typed[0];
        const material = document.materials[primitive.material];
        const extension = material.extensions.VRMC_materials_mtoon;
        assert.equal(extension.specVersion, '1.0', uri);
        assert(extension.shadeMultiplyTexture && material.emissiveTexture && material.pbrMetallicRoughness.baseColorTexture, uri);
        if (uri.startsWith('baked-v4')) {
            assert(primitive.attributes.TANGENT !== undefined && material.normalTexture, uri);
            assert(material.extensions.KHR_materials_emissive_strength?.emissiveStrength > 1, uri);
        } else {
            assert.equal(material.alphaMode, 'MASK', uri);
        }
        const {issues} = await validator.validateBytes(bytes, {uri});
        console.log(uri, issues.numErrors, issues.numWarnings);
        assert.equal(issues.numErrors, 0, JSON.stringify(issues));
        results.push({uri, extension, issues});
    }
    fs.writeFileSync(path.join(__dirname, 'khronos.json'), JSON.stringify({validator: validator.version(), results}, null, 2) + '\n');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
