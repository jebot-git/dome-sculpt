#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
flock --timeout 180 /tmp/dome-sculpt-arc-device.lock bwrap --die-with-parent --unshare-all --ro-bind / / --bind "$work" "$work" --proc /proc --dev /dev --dev-bind /dev/dri/renderD129 /dev/dri/renderD129 --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv EGL_PLATFORM surfaceless --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv DRI_PRIME pci-0000_03_00_0 --setenv LP_NUM_THREADS 2 "$work/release/dome-sculpt-mtoon-render-test" --resized-texture-set "$work/painted-arc" > "$work/painted-v4-arc.log" 2>&1
