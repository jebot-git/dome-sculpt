#include "dome/texture-set-resolution.hpp"
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc, char **argv) try {
  if (argc != 2)
    return 2;
  auto scene = dome::Scene::load(argv[1]);
  const auto original = scene.encode();
  try {
    const auto report = dome::resample_texture_set(scene, scene.active().id, 1, {256});
    if (!report.changed || dome::active_texture_set(scene.active()).painted->resolution() != 256)
      return 2;
    std::cout << "PASS typed Bake resize\n";
  } catch (const std::exception &error) {
    if (scene.encode() != original)
      return 2;
    std::cout << "REFUSED unchanged: " << error.what() << '\n';
    return 1;
  }
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 2;
}
