from pathlib import Path
import subprocess
import sys

work=Path(__file__).resolve().parent
mode=sys.argv[1]
launch=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',work,work,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LP_NUM_THREADS':'2','MESA_SHADER_CACHE_DISABLE':'1',
     'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if mode=='arc':
    launch=['flock','--timeout','180','/tmp/dome-sculpt-arc-device.lock',*launch,
            '--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129']
    env['DRI_PRIME']='pci-0000_03_00_0'
else:
    env['LIBGL_ALWAYS_SOFTWARE']='1'
for key,value in env.items():launch.extend(['--setenv',key,value])
with (work/f'field-xr-paced-{mode}.log').open('w') as log:
    subprocess.run([*launch,'/usr/bin/python3.14',work/'field-xr-paced.py',mode,sys.argv[2]],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=260)
