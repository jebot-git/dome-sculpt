from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from jsonschema import Draft4Validator, Draft202012Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT4

work = Path(__file__).resolve().parent
repo = work.parent.parent
schema = work.parent / 'vrm1-core-pbr-expression-schemas-20261126/specification/VRMC_materials_mtoon-1.0/schema'
pinned = json.loads((work.parent / 'mtoon-static-normal-uv-20261127/schemas.json').read_text())['consumed_schema_sha256']
sources = {}
resources = []
for path in schema.glob('*.schema.json'):
    data = path.read_bytes()
    relative = str(path.relative_to(repo))
    checksum = sha256(data).hexdigest()
    assert checksum == pinned[relative], relative
    sources[relative] = checksum
    contents = json.loads(data)
    resource = Resource.from_contents(contents, default_specification=DRAFT4)
    resources.append((path.as_uri(), resource))
    if '$id' in contents:
        resources.append((contents['$id'], resource))
registry = Registry().with_resources(resources)
validator = Draft4Validator({'$ref': (schema / 'VRMC_materials_mtoon.schema.json').as_uri()}, registry=registry)
texture = Draft202012Validator({'$ref': (schema / 'textureInfo.schema.json').as_uri()}, registry=registry)
cases = json.loads((work / 'khronos.json').read_text())['results']
for case in cases:
    validator.validate(case['extension'])
    shade = case['extension']['shadeMultiplyTexture']
    texture.validate(shade)
    missing = deepcopy(shade)
    missing.pop('index')
    assert not texture.is_valid(missing)
(work / 'schemas.json').write_text(json.dumps({'cases': [case['uri'] for case in cases],
    'pinned_schema_sha256': sources, 'malformed_shade_role_refused': True}, indent=2, sort_keys=True) + '\n')
print('Five MToon 1.0 materials pass the pinned schema and missing-index control')
