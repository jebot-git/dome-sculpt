import os
from pathlib import Path
import shlex
import subprocess
import sys

work=Path(__file__).resolve().parent
build=work/'release'
app=work/'render-portable'
if sys.argv[1]=='build':
    commands=subprocess.check_output(['ninja','-C',build,'-t','commands','dome-sculpt-mtoon-render-test'],text=True).splitlines()
    compile=shlex.split(next(line for line in commands if line.endswith('/tests/mtoon-render.cpp')))
    includes=[flag for flag in compile if flag.startswith(('-I','-D'))]
    link=shlex.split(commands[-1])[2:-2]
    libs=link[link.index('libdome-sculpt-render.a'):]
    libs=['-lgcc_s' if flag=='-lgcc_s_asneeded' else flag for flag in libs]
    with (work/'render-portable-build.log').open('w') as log:
        subprocess.run(['/usr/bin/c++','-std=c++20','-O2',*includes,work/'render-portable.cpp','-o',app,*libs],cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    sys.exit(0)
mode=sys.argv[1]
assert mode in ('arc','software')
args=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
      '--bind',work,work,'--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LP_NUM_THREADS':'2','EGL_PLATFORM':'surfaceless',
     'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if mode=='arc':
    args=['flock','--timeout','180','/tmp/dome-sculpt-arc-device.lock',*args,
          '--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129']
    env['DRI_PRIME']='pci-0000_03_00_0'
else:
    env['LIBGL_ALWAYS_SOFTWARE']='1'
for key,value in env.items(): args.extend(['--setenv',key,value])
fixture=work/sys.argv[2]
result=[fixture/'portable.dsculpt'] if mode=='software' else []
with (fixture/f'render-portable-{mode}.log').open('w') as log:
    subprocess.run([*args,app,fixture/'baked-member-256.dsculpt',fixture/'portable.glb',*result],
                   env=os.environ,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=220)
