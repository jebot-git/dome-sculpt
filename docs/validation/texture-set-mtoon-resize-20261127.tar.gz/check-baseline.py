from pathlib import Path
import os
import shlex
import subprocess

work = Path(__file__).resolve().parent
build = work / 'release'
target = 'dome-sculpt-texture-set-resolution-test'
prior = work.parent / 'held-cut-regression-20261127/release/libdome-sculpt-core.a'
commands = subprocess.check_output(['ninja', '-C', build, '-t', 'commands', target], text=True).splitlines()
argv = shlex.split(next(row for row in commands if row.endswith('/tests/texture-set-resolution.cpp')))
includes = [arg for arg in argv if arg.startswith('-I')]
obj = work / 'baseline-probe.o'
subprocess.run(['/usr/bin/c++', '-std=c++20', '-O2', *includes, '-c', work / 'baseline-probe.cpp', '-o', obj],
               cwd=build, check=True)
env = dict(os.environ, LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
for label, core in [('old', prior), ('new', build / prior.name)]:
    binary = work / ('baseline-probe-' + label)
    link = shlex.split(commands[-1])[2:-2]
    link[link.index('-o') + 1] = str(binary)
    link[link.index('libdome-sculpt-core.a')] = str(core)
    link[link.index(next(term for term in link if term.endswith('/texture-set-resolution.cpp.o')))] = str(obj)
    link = [term for term in link if not term.startswith('-Wl,--dependency-file=')]
    subprocess.run(link, cwd=build, check=True)
    run = subprocess.run([binary, work / 'baked-v4/baked-member-128.dsculpt'], env=env,
                         text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=20)
    (work / f'baseline-{label}.log').write_text(run.stdout)
    if label == 'old':
        assert run.returncode == 1 and 'REFUSED unchanged: Source or independently prepared field resolution' in run.stdout, run.stdout
    else:
        assert run.returncode == 0 and 'PASS typed Bake resize' in run.stdout, run.stdout
