import json
from pathlib import Path
import struct
import sys

source=Path(sys.argv[1]).read_bytes()
length,=struct.unpack_from('<I',source,12)
doc=json.loads(source[20:20+length])
for name in ('domeSculptAuthoring','domeSculptEmission'):
    doc.get('extras',{}).pop(name,None)
if not doc.get('extras'):doc.pop('extras',None)
encoded=json.dumps(doc,separators=(',',':')).encode()
encoded+=b' '*((-len(encoded))%4)
bin_chunk=source[20+length:]
Path(sys.argv[2]).write_bytes(struct.pack('<5I',0x46546c67,2,20+len(encoded)+len(bin_chunk),len(encoded),0x4e4f534a)+encoded+bin_chunk)
