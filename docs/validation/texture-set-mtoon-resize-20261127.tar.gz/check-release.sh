#!/usr/bin/bash
set -euo pipefail
work="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$work/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/release"
sandbox=(bwrap --die-with-parent --unshare-all --ro-bind / / --ro-bind "$work/frozen-v4/CMakeLists.txt" "$repo/CMakeLists.txt" --ro-bind "$work/frozen-v4/src" "$repo/src" --ro-bind "$work/frozen-v4/include" "$repo/include" --ro-bind "$work/frozen-v4/tests" "$repo/tests" --bind "$work/release" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH /opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
"${sandbox[@]}" cmake --build "$seed" --parallel 4 --target dome-sculpt-native-paint-resolution-test dome-sculpt-texture-set-source-export-test dome-sculpt-retopo-surface-heat-test dome-sculpt-native-mtoon-preview-contracts-test > "$work/regression-build.log" 2>&1
"${sandbox[@]}" ctest --test-dir "$seed" --parallel 3 -R '^(retopology-(mtoon-.*|first-material-.*|imported-(pbr|prior-bake|bake-resize|mtoon-.*))|native-mikk-export|mtoon-(texture-sets|painted-texture-sets|baked-texture-sets|resized-texture-set)|native-mtoon-preview-contracts.*|native-(empty|authored|baked)-paint-resolution|dome-sculpt-texture-set-(baked-(mtoon-)?)?resolution)$' --output-on-failure --output-junit "$seed/mtoon-resize.xml" > "$work/release-tests.log" 2>&1
