from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

here = Path(__file__).resolve().parent
release = here / 'release'
source = here.parent / 'production-compact-sculpt-source-20261126'
docs = here.parent.parent / 'docs/validation'
unit = 'ds-production-compact-sculpt-release-20261126'
invocation = 'bfbd6c45e3934b41ad69eeae67ae09e2'
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def load(path):
    return json.loads(path.read_text())
def git(*args):
    return subprocess.check_output(['git', '-C', str(source), *args], text=True).strip()
plan = load(release / 'build-plan.json')
built = load(release / 'build-status.json')
native = load(release / 'native/status.json')
assert git('rev-parse','HEAD') == native['source'] == plan['source']
assert not git('status','--porcelain')
assert all(x['terminal'] and x['exit'] == 0 for x in (built,native))
assert len(built['compile']) == 1 and len(built['links']) == 5
assert built['linked_archive']['members'] == 197
assert built['linked_archive']['replacements'] == ['sculpt-surface-chunks.cpp.o']
assert sha(release/'libdome-sculpt-core.a') == built['linked_archive']['sha256']
assert all(v['exit']==0 and v['check_passed'] for v in native['cases'].values())
assert sha(release / 'dome-sculpt') == native['app']['sha256']
assert sha(release / 'dome-sculpt-sculpt-sustained') == native['sustained_sha256']
projects = {str(p.relative_to(release)): {'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted((release/'native/sculpt').rglob('*.dsculpt'))}
assert len(projects) == 3 and all(x['sha256']=='d32c725a02d3d9291f3208c879f78ecc343c33511de9e10b5c18d93bb95fd694'
                                   for x in projects.values())
paths = [here / name for name in ('prepare.py', 'run-build-and-native.py', 'seal-release.py')]
paths += [release / name for name in ('build.py','run-native.py','owned_monitor.py','build-plan.json','build-status.json','native/status.json')]
paths += sorted(release.glob('*.d')) + sorted(release.glob('*.log')) + sorted((release/'native').glob('*.log'))
journal = subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager'])
assert journal and b'-- No entries --' not in journal and b'memory peak.' in journal and b'Failed with result' not in journal
journal_path = here / (unit + '.journal.txt')
journal_path.write_bytes(journal)
paths.append(journal_path)
archive_path = docs / 'production-compact-sculpt-release-20261126.tar.xz'
manifest = {}
with tarfile.open(archive_path,'w:xz',preset=6) as archive:
    for p in paths:
        rel = str(p.relative_to(here))
        assert rel not in manifest
        data = p.read_bytes()
        manifest[rel] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        item = tarfile.TarInfo(rel)
        item.size = len(data)
        archive.addfile(item, io.BytesIO(data))
with tarfile.open(archive_path,'r:xz') as archive:
    assert set(archive.getnames()) == set(manifest)
    for item in archive:
        assert manifest[item.name]['bytes'] == item.size
        assert manifest[item.name]['sha256'] == hashlib.file_digest(archive.extractfile(item),'sha256').hexdigest()
receipt = {
    'source': native['source'],
    'scope': 'Combined CPU Release archive and application links, version, 26 surface, 94 pipeline and 167 production native sculpt checks. CPU-only isolated run with the default allocator. Physical headset, matched graphics, and strict full-sculpt results are outside this receipt.',
    'service': unit, 'invocation': invocation,
    'build': built, 'native': native, 'exact_projects': projects,
    'authorities': manifest,
    'archive': {'file': archive_path.name, 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path)},
}
archive_path.with_name(archive_path.name.replace('.tar.xz','.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['source'],len(manifest),receipt['archive'])
