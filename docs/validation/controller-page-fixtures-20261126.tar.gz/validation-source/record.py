from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile

root=Path(__file__).resolve().parents[2]
artifacts=root/'artifacts'
source='cf8c9b9b'
product='fadacc0076aef8f7b2ed8ec5a9a9cfbbbaa8ca17'
validation=root/'docs/validation'
files={}
results={}
def add(directory,prefix,*names):
    for name in names:
        path=directory/name
        assert path.is_file()
        files[prefix+'/'+name]=path
def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()
def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()
for profile,suffix in (('release',''),('asan','-asan')):
    controls=artifacts/f'controller-page-regression-triage{suffix}-20261126'
    rig=artifacts/f'current-anatomical-controller-triage{suffix}-20261126'
    state=json.loads((controls/'status.json').read_text())
    rig_state=json.loads((rig/'status.json').read_text())
    assert state['candidate']==rig_state['candidate']==product
    assert len(state['results'])==4 and all(token['exit']==0 for token in state['results'])
    assert len(rig_state['reports'])==2 and all(token['exit']==0 for token in rig_state['reports'])
    assert all('Public anatomical worker checks 35' in token['last'] for token in rig_state['reports'])
    results[profile]={'pages':state['results'],'anatomical':rig_state['reports']}
    add(controls,profile+'/controls','run.py','status.json',
        *[token['test']+'/run.log' for token in state['results']])
    add(rig,profile+'/anatomical','run.py','status.json','female-generate.log','male-generate.log',
        'female-worker.log','male-worker.log')
add(artifacts/'controller-page-regression-triage-20261126','validation-source','record.py')
assert git('diff','--name-only',source,'HEAD','--','src','include','tests','CMakeLists.txt')==''
archive=validation/'controller-page-fixtures-20261126.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode='w') as stream:
        for filename,path in sorted(files.items()):
            info=stream.gettarinfo(str(path),arcname=filename)
            info.uname=info.gname=''
            info.uid=info.gid=info.mtime=0
            info.mode=0o644
            with path.open('rb') as raw:
                stream.addfile(info,raw)
with tarfile.open(archive,'r:gz') as check:
    assert len(check.getmembers())==len(files)
    for name,path in files.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==sha(path)
fixture=artifacts/'retained-texture-set-full-release-20261126/build/native-paint32-fixture.dsculpt'
status={'product':product,'fixture_commit':git('rev-parse',source),'main_merge':git('rev-parse','HEAD'),
        'scope':'Existing controller behavior, latest page registry, actual anatomical and surface-heat Method control, native/GLB output, exact history and cancellation.',
        'reused_native32_project_sha256':sha(fixture),'profiles':results,
        'raw':{'archive':archive.name,'sha256':sha(archive),'members':{name:sha(path) for name,path in sorted(files.items())}}}
(validation/'controller-page-fixtures-20261126.json').write_text(json.dumps(status,indent=2)+'\n')
print(len(files),'members',status['raw']['sha256'])
