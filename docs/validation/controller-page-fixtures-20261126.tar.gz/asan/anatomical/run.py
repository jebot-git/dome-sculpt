from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,shlex,subprocess

out=Path(__file__).resolve().parent
artifacts=out.parent
donor=artifacts/'cut-owning-material-validation-20261126/asan'
build=donor/'build'
support=artifacts/'texture-set-recipe-and-hdr-validation-20261126/asan/build'
source=artifacts/'controller-page-regression-source-20261126'
owner=json.loads((donor/'status.json').read_text())
assert owner['candidate']=='fadacc0076aef8f7b2ed8ec5a9a9cfbbbaa8ca17' and owner.get('app_sha256') and owner.get('core_sha256')
core=donor/'libdome-sculpt-core.a'
assert hashlib.sha256(core.read_bytes()).hexdigest()==owner['core_sha256']
database=json.loads((build/'compile_commands.json').read_text())
def link(target):
    entry=next(e for e in database if f'CMakeFiles/{target}.dir/' in e['command'])
    words=[w.replace('cut-owning-material-source-20261126','controller-page-regression-source-20261126')
           for w in shlex.split(entry['command'])]
    obj=out/(target+'.o')
    at=words.index('-o')+1
    original=words[at]
    words[at]=str(obj)
    exe=out/target
    with (out/(target+'.log')).open('w') as log:
        subprocess.run(words,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=160)
        last=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
        cmd=[w for w in shlex.split(last)[2:-2] if not w.startswith('-Wl,--dependency-file=')]
        cmd[cmd.index(original)]=str(obj)
        cmd[cmd.index('-o')+1]=str(exe)
        cmd=[str(core if w==core.name else support/w) if w.startswith('lib') and w.endswith('.a') else w for w in cmd]
        subprocess.run(cmd,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    return exe
isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
          '--bind',out,out,'--proc','/proc','--dev','/dev','--tmpfs','/tmp',
          '--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
          '--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH',
          f'{artifacts}/sdk-20261126/toolkit-sanitize/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
          '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
          '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1']
with ThreadPoolExecutor(max_workers=2) as pool:
    fixture,worker=pool.map(link,['dome-sculpt-anatomical-fixture-test','dome-sculpt-anatomical-authoring-worker-test'])
def run(base):
    dest=out/base
    with (out/(base+'-generate.log')).open('w') as log:
        model=source/f'assets/humanoid/vroid/base-{base}.vrm'
        subprocess.run([*isolated,fixture,model,dest],cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=500)
    path=out/(base+'-worker.log')
    with path.open('w') as log:
        finish=subprocess.run([*isolated,worker,dest/'fitted-unskinned.dsculpt',dest/'bound.dsculpt',out/(base+'-checks')],
                              cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=600)
    return {'base':base,'exit':finish.returncode,'last':path.read_text().splitlines()[-5:]}
with ThreadPoolExecutor(max_workers=2) as pool:
    reports=list(pool.map(run,('female','male')))
(out/'status.json').write_text(json.dumps({'candidate':owner['candidate'],'reports':reports},indent=2)+'\n')
