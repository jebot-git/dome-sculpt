from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import shlex
import subprocess

out = Path(__file__).resolve().parent
artifacts = out.parent
qualified = artifacts/'cut-owning-material-validation-20261126/asan'
support = artifacts/'texture-set-recipe-and-hdr-validation-20261126/asan/build'
build = qualified/'build'
state = json.loads((qualified/'status.json').read_text())
assert state['candidate'] == 'fadacc0076aef8f7b2ed8ec5a9a9cfbbbaa8ca17' and state.get('core_sha256') and state.get('app_sha256')
database = json.loads((build/'compile_commands.json').read_text())
suite = {
  'import-options-controller': ('dome-sculpt-import-options-test', []),
  'emission-controls': ('dome-sculpt-emission-controls-test', []),
  'xr-editable-export': ('dome-sculpt-xr-editable-export-test', []),
  'xr-native-paint32-export': ('dome-sculpt-xr-editable-export-test',
      [artifacts/'retained-texture-set-full-release-20261126/build/native-paint32-fixture.dsculpt']),
}
isolated = ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
            '--bind',out,out,'--proc','/proc','--dev','/dev','--tmpfs','/tmp',
            '--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
            '--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH',
            f'{artifacts}/sdk-20261126/toolkit-sanitize/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
            '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
            '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1']

def process(case):
    name, (target, args) = case
    current = out/name
    current.mkdir(exist_ok=True)
    entry = next(row for row in database if f'CMakeFiles/{target}.dir/' in row['command'])
    compile = [x.replace('cut-owning-material-source-20261126','controller-page-regression-source-20261126') for x in shlex.split(entry['command'])]
    index = compile.index('-o')+1
    original, obj = compile[index], current/(Path(entry['file']).name+'.o')
    compile[index] = str(obj)
    binary = current/target
    with (current/'build.log').open('w') as log:
        subprocess.run(compile,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
        commands = subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True)
        link = [w for w in shlex.split(commands.splitlines()[-1])[2:-2] if not w.startswith('-Wl,--dependency-file=')]
        link[link.index(original)] = str(obj)
        link[link.index('-o')+1] = str(binary)
        rendered = artifacts/'retained-smooth-atlas-validation-20261126/asan'
        link = [str(qualified/w if (qualified/w).is_file() else rendered/w if (rendered/w).is_file() else support/w)
                if w.startswith('lib') and w.endswith('.a') else w for w in link]
        subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    with (current/'run.log').open('w') as log:
        child = subprocess.run([*isolated,binary,current/'output',*args],cwd=current,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    return {'test':name, 'exit':child.returncode, 'last_lines':(current/'run.log').read_text().splitlines()[-4:]}

with ThreadPoolExecutor(max_workers=2) as pool:
    reports = list(pool.map(process,suite.items()))
(out/'status.json').write_text(json.dumps({'candidate':state['candidate'],'results':reports},indent=2)+'\n')
