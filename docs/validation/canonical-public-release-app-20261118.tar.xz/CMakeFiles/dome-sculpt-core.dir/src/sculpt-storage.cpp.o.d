CMakeFiles/dome-sculpt-core.dir/src/sculpt-storage.cpp.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-canonical-public-integration-20261118/src/sculpt-storage.cpp \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/authoring-canonical-public-integration-20261118/include/dome/sculpt-storage.hpp \
 /usr/include/c++/16/cstddef \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++config.h \
 /usr/include/bits/wordsize.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/cpu_defines.h \
 /usr/include/c++/16/pstl/pstl_config.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stddef.h \
 /usr/include/c++/16/bits/version.h /usr/include/c++/16/limits \
 /usr/include/c++/16/memory /usr/include/c++/16/bits/memoryfwd.h \
 /usr/include/c++/16/bits/allocator.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++allocator.h \
 /usr/include/c++/16/bits/new_allocator.h /usr/include/c++/16/new \
 /usr/include/c++/16/bits/exception.h \
 /usr/include/c++/16/bits/new_except.h \
 /usr/include/c++/16/bits/exception_defines.h \
 /usr/include/c++/16/bits/new_throw.h /usr/include/c++/16/bits/move.h \
 /usr/include/c++/16/type_traits /usr/include/c++/16/bits/stl_tempbuf.h \
 /usr/include/c++/16/bits/stl_construct.h \
 /usr/include/c++/16/bits/stl_iterator_base_types.h \
 /usr/include/c++/16/bits/iterator_concepts.h \
 /usr/include/c++/16/concepts /usr/include/c++/16/bits/ptr_traits.h \
 /usr/include/c++/16/bits/ranges_cmp.h \
 /usr/include/c++/16/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/16/bits/concept_check.h \
 /usr/include/c++/16/debug/assertions.h \
 /usr/include/c++/16/bits/stl_pair.h /usr/include/c++/16/bits/utility.h \
 /usr/include/c++/16/compare /usr/include/c++/16/ext/numeric_traits.h \
 /usr/include/c++/16/bits/cpp_type_traits.h \
 /usr/include/c++/16/ext/type_traits.h \
 /usr/include/c++/16/bits/stl_uninitialized.h \
 /usr/include/c++/16/bits/stl_algobase.h \
 /usr/include/c++/16/bits/stl_iterator.h \
 /usr/include/c++/16/debug/debug.h \
 /usr/include/c++/16/bits/predefined_ops.h \
 /usr/include/c++/16/bits/stl_function.h \
 /usr/include/c++/16/backward/binders.h /usr/include/c++/16/bit \
 /usr/include/c++/16/ext/alloc_traits.h \
 /usr/include/c++/16/bits/alloc_traits.h \
 /usr/include/c++/16/bits/stl_raw_storage_iter.h \
 /usr/include/c++/16/bits/align.h \
 /usr/include/c++/16/bits/uses_allocator.h \
 /usr/include/c++/16/bits/unique_ptr.h /usr/include/c++/16/tuple \
 /usr/include/c++/16/bits/invoke.h /usr/include/c++/16/bits/ranges_util.h \
 /usr/include/c++/16/bits/ranges_base.h \
 /usr/include/c++/16/initializer_list \
 /usr/include/c++/16/bits/max_size_type.h /usr/include/c++/16/numbers \
 /usr/include/c++/16/bits/functional_hash.h \
 /usr/include/c++/16/bits/hash_bytes.h /usr/include/c++/16/bits/ostream.h \
 /usr/include/c++/16/bits/requires_hosted.h /usr/include/c++/16/ios \
 /usr/include/c++/16/iosfwd /usr/include/c++/16/bits/stringfwd.h \
 /usr/include/c++/16/bits/postypes.h /usr/include/c++/16/cwchar \
 /usr/include/wchar.h /usr/include/bits/libc-header-start.h \
 /usr/include/bits/floatn.h /usr/include/bits/floatn-common.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdarg.h \
 /usr/include/bits/wchar.h /usr/include/bits/types/wint_t.h \
 /usr/include/bits/types/mbstate_t.h \
 /usr/include/bits/types/__mbstate_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/locale_t.h \
 /usr/include/bits/types/__locale_t.h /usr/include/c++/16/exception \
 /usr/include/c++/16/bits/exception_ptr.h \
 /usr/include/c++/16/bits/cxxabi_init_exception.h \
 /usr/include/c++/16/typeinfo /usr/include/c++/16/bits/nested_exception.h \
 /usr/include/c++/16/bits/char_traits.h \
 /usr/include/c++/16/bits/localefwd.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++locale.h \
 /usr/include/c++/16/clocale /usr/include/locale.h \
 /usr/include/bits/locale.h /usr/include/c++/16/cctype \
 /usr/include/ctype.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/c++/16/bits/ios_base.h /usr/include/c++/16/ext/atomicity.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/gthr.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/gthr-default.h \
 /usr/include/pthread.h /usr/include/sched.h \
 /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/include/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/include/asm/posix_types.h \
 /usr/include/asm/posix_types_64.h /usr/include/asm-generic/posix_types.h \
 /usr/include/bits/types/struct_sched_param.h /usr/include/bits/cpu-set.h \
 /usr/include/time.h /usr/include/bits/time.h /usr/include/bits/timex.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/clockid_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/bits/setjmp.h \
 /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct___jmp_buf_tag.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/atomic_word.h \
 /usr/include/sys/single_threaded.h \
 /usr/include/c++/16/bits/locale_classes.h \
 /usr/include/c++/16/bits/functexcept.h /usr/include/c++/16/string \
 /usr/include/c++/16/bits/ostream_insert.h \
 /usr/include/c++/16/bits/cxxabi_forced.h \
 /usr/include/c++/16/bits/stdexcept_throw.h \
 /usr/include/c++/16/bits/stdexcept_throwfwd.h \
 /usr/include/c++/16/bits/range_access.h \
 /usr/include/c++/16/bits/erase_if.h \
 /usr/include/c++/16/bits/basic_string.h /usr/include/c++/16/string_view \
 /usr/include/c++/16/bits/string_view.tcc \
 /usr/include/c++/16/ext/string_conversions.h /usr/include/c++/16/cstdlib \
 /usr/include/stdlib.h /usr/include/bits/waitflags.h \
 /usr/include/bits/waitstatus.h /usr/include/sys/types.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-bsearch.h /usr/include/bits/stdlib-float.h \
 /usr/include/c++/16/bits/std_abs.h /usr/include/c++/16/cstdio \
 /usr/include/stdio.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__fpos64_t.h \
 /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/stdio.h \
 /usr/include/c++/16/cerrno /usr/include/errno.h \
 /usr/include/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h /usr/include/bits/types/error_t.h \
 /usr/include/c++/16/bits/charconv.h \
 /usr/include/c++/16/bits/basic_string.tcc \
 /usr/include/c++/16/bits/memory_resource.h \
 /usr/include/c++/16/bits/uses_allocator_args.h \
 /usr/include/c++/16/bits/locale_classes.tcc \
 /usr/include/c++/16/system_error \
 /usr/include/c++/16/x86_64-redhat-linux/bits/error_constants.h \
 /usr/include/c++/16/stdexcept \
 /usr/include/c++/16/bits/stdexcept_except.h \
 /usr/include/c++/16/streambuf /usr/include/c++/16/bits/streambuf.tcc \
 /usr/include/c++/16/bits/basic_ios.h \
 /usr/include/c++/16/bits/locale_facets.h /usr/include/c++/16/cwctype \
 /usr/include/wctype.h /usr/include/bits/wctype-wchar.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/ctype_base.h \
 /usr/include/c++/16/bits/streambuf_iterator.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/ctype_inline.h \
 /usr/include/c++/16/bits/locale_facets.tcc \
 /usr/include/c++/16/bits/basic_ios.tcc \
 /usr/include/c++/16/bits/shared_ptr.h \
 /usr/include/c++/16/bits/shared_ptr_base.h \
 /usr/include/c++/16/bits/allocated_ptr.h \
 /usr/include/c++/16/bits/refwrap.h \
 /usr/include/c++/16/ext/aligned_buffer.h \
 /usr/include/c++/16/ext/concurrence.h \
 /usr/include/c++/16/bits/shared_ptr_atomic.h \
 /usr/include/c++/16/bits/atomic_base.h \
 /usr/include/c++/16/bits/atomic_lockfree_defines.h \
 /usr/include/c++/16/bits/atomic_wait.h \
 /usr/include/c++/16/backward/auto_ptr.h \
 /usr/include/c++/16/bits/ranges_uninitialized.h \
 /usr/include/c++/16/bits/ranges_algobase.h \
 /usr/include/c++/16/pstl/glue_memory_defs.h \
 /usr/include/c++/16/pstl/execution_defs.h /usr/include/c++/16/atomic \
 /usr/include/c++/16/cstdint \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h
