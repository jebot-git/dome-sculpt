from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import time

out = Path(__file__).resolve().parent
artifacts = out.parent
product = artifacts/'vrm-consumer-combined-asan-20261126'
parent = artifacts/'vrm-consumer-source-20261126'
renderer = artifacts/'combined-atlas-xr-candidate-validation-20261126'/'arc-asan'
base = '3cb2fe81e00a0a71bdac5c505ad169eb16d67b6d'
change = '0fa8eabab49f13cf56651e04fc2a824bc7460066'
status = {'terminal':False, 'invocation':os.environ.get('INVOCATION_ID'), 'profiles':{}}


def write(**fields):
    status.update(fields)
    tmp = out/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(out/'status.json')


def logged(cmd, dest, seconds):
    with dest.open('wb') as log:
        start = time.monotonic()
        subprocess.run(cmd,cwd=product,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=seconds)
        return time.monotonic()-start


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


try:
    entries = json.loads((product/'compile_commands.json').read_text())
    entry = next(x for x in entries if x['file'].endswith('/third_party/xatlas/xatlas.cpp'))
    target = 'dome-sculpt-voxel-authoring-test'
    template = next(x for x in entries if x['file'].endswith('/tests/voxel-authoring.cpp'))
    harness = out/'export.o'
    cmd = shlex.split(template['command'])
    harness_object = cmd[cmd.index('-o')+1]
    cmd[cmd.index('-o')+1] = str(harness)
    cmd[-1] = str(out/'export.cpp')
    logged(cmd, out/'harness-build.log',90)
    raw = subprocess.check_output(['ninja','-C',product,'-t','commands',target],text=True).splitlines()[-1]
    xr = artifacts/'atlas-sparse-boundary-grid-timing-20261126'/'parent-1'
    native_input = next((xr/'state/dome-sculpt').glob('*.dsculpt'))
    for name, rev in (('baseline',base),('candidate',change)):
        folder = out/name
        folder.mkdir()
        write(phase='compile '+name)
        source = subprocess.check_output(['git','-C',parent,'show',f'{rev}:third_party/xatlas/xatlas.cpp'])
        assert source.count(b'static bool s_printVerbose = false;') == 1
        source = source.replace(b'static bool s_printVerbose = false;',b'static bool s_printVerbose = true;')
        tu = folder/'xatlas.cpp'
        tu.write_bytes(source)
        obj = folder/'xatlas.o'
        compile = shlex.split(entry['command'])
        compile[compile.index('-o')+1] = str(obj)
        compile[-1] = str(tu)
        logged([*compile,'-DXA_PROFILE=1'],folder/'compile.log',180)
        lib = folder/'libxatlas.a'
        logged(['ar','rcs',lib,obj],folder/'archive.log',20)
        app = folder/'dome-sculpt'
        link = [x for x in shlex.split(raw)[2:-2] if not x.startswith('-Wl,--dependency-file=')]
        link[link.index('-o')+1] = str(app)
        link[link.index('libxatlas.a')] = str(lib)
        link[link.index(harness_object)] = str(harness)
        logged(link,folder/'link.log',100)
        write(phase='run '+name)
        cmd = ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',folder,folder,
               '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
               '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp',
               '--setenv','XDG_STATE_HOME',str(folder/'state'),
               '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1',
               '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1']
        scene = folder/'files.dsculpt'
        glb = folder/'export.glb'
        run_log = folder/'application.log'
        seconds = logged([*cmd,app,native_input,glb,scene],run_log,160)
        assert glb.read_bytes()[:4] == b'glTF'
        stages = [line.strip() for line in run_log.read_text().splitlines() if re.search(r'\d+\.\d+ seconds \(.+? ms\)$',line)]
        assert len(stages) >= 15
        status['profiles'][name] = {'source':rev,'seconds':round(seconds,3),'app_sha256':digest(app),
                                    'glb_sha256':digest(glb),'scene_sha256':digest(scene),'stages':stages}
        write()
    assert len({(item['glb_sha256'],item['scene_sha256']) for item in status['profiles'].values()}) == 1
    write(terminal=True,phase='complete',exit=0,identity=True,input_sha256=digest(native_input))
except Exception as error:
    write(terminal=True,exit=1,error=repr(error))
    raise
