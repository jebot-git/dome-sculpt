#include "dome/document.hpp"
#include <cstdlib>
#include <iostream>

int main(int argc, char **argv) try {
    if (argc != 4)
        return 2;
    dome::Document document;
    document.open(argv[1]);
    auto export_job = document.export_asset(argv[2]);
    document.save(argv[3]);
    export_job.get();
    return 0;
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
}
