from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

root = Path.cwd()
artifacts = root / 'artifacts'
receipt = {}
members = {}


def snapshot(label, folder, *extras):
    directory = artifacts / folder
    status = json.loads((directory / 'status.json').read_text())
    assert status['terminal'], (label, status['phase'])
    receipt[label] = status
    for name in ('status.json', *extras):
        members[f'{label}/{name}'] = (directory / name).read_bytes()
    return status


combined = 'combined-atlas-xr-candidate-validation-20261126'
profiles = (('combined-arc', 'arc-asan'), ('combined-arc-rerun', 'arc-asan-rerun'))
for label, profile in profiles:
    result = snapshot(label, f'{combined}/{profile}')
    assert result['checks'] == 146 and result['exit'] == 1
    assert 'timed out after 40 seconds' in result['error']
    assert len(result['arc_witnesses']) >= 8
    result['arc_witness_count'] = len(result.pop('arc_witnesses'))

sparse = snapshot('sparse-timing', 'atlas-sparse-boundary-grid-timing-20261126', 'run.py')
assert sparse['exit'] == 0 and len(sparse['runs']) == 4
assert len({(tuple(r['glb_sha256']), r['scene_sha256']) for r in sparse['runs']}) == 1
assert all(r['passed'] and r['arc_device'] and r['seconds'] > 40 for r in sparse['runs'])
for profile in ('release', 'asan'):
    fixture = snapshot(f'grid-{profile}', f'atlas-sparse-grid-fixture-20261126/{profile}')
    assert fixture['exit'] == 0
    assert all('574 analytic intersections' in row['result'] for row in fixture['results'].values())
    native = snapshot(f'sparse-native-{profile}', f'atlas-sparse-boundary-grid-validation-20261126/native-{profile}')
    assert native['exit'] == 0 and len(native['results']) == 6

prefix = 'hdr-preview-retention-priority-measurement-20261126'
for profile in ('release-2048', 'asan-2048'):
    label = f'hdr-clear-undo-{profile}'
    result = snapshot(label, f'{prefix}/{profile}', 'preview.log')
    preview = members[f'{label}/preview.log'].decode()
    maps = re.findall(r'^RANGE (?:INITIAL|RESTORED) object=4 map=(\S+)', preview, re.M)
    ready = re.search(r'^RESTORED default_ready=1 first_seconds=([\d.]+)', preview, re.M)
    retained = re.search(r'^CACHE RESTORED retained=(\d+) entries=\d+ limit=(\d+) builds=(\d+) ', preview, re.M)
    cleared = re.search(r'^CACHE CLEARED .* builds=(\d+) ', preview, re.M)
    assert result['exit'] == 0 and len(maps) == 2 and maps[0] == maps[1]
    assert float(ready[1]) < 10 and int(retained[1]) <= int(retained[2]) == 512 * 1024 * 1024
    assert retained[3] == cleared[1]
    result['restored_preview_seconds'] = float(ready[1])
    result['restored_retention_bytes'] = int(retained[1])
    result['same_immutable_preview'] = True

main = snapshot('hdr-main-port-release', 'hdr-preview-history-main-port-validation-20261126/release')
assert main['exit'] == 0 and len(main['results']) == 6
members['recorder.py'] = Path(__file__).read_bytes()
archive = root / 'docs/validation/atlas-grid-hdr-history-20261126.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as tar:
    for name, payload in sorted(members.items()):
        member = tarfile.TarInfo(name)
        member.mode = 0o644
        member.size = len(payload)
        tar.addfile(member, io.BytesIO(payload))
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(members)
    assert all(tar.extractfile(name).read() == payload for name, payload in members.items())
receipt['archive'] = {'path': str(archive.relative_to(root)), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(members)}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
