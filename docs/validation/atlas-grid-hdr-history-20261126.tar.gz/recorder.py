from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

root = Path.cwd()
artifacts = root / 'artifacts'
receipt = {}
members = {}


def snapshot(label, folder, *extras):
    directory = artifacts / folder
    status = json.loads((directory / 'status.json').read_text())
    assert status['terminal'], (label, status['phase'])
    receipt[label] = status
    for name in ('status.json', *extras):
        members[f'{label}/{name}'] = (directory / name).read_bytes()
    return status


combined = 'combined-atlas-xr-candidate-validation-20261126'
profiles = (('combined-arc', 'arc-asan'), ('combined-arc-rerun', 'arc-asan-rerun'))
for label, profile in profiles:
    result = snapshot(label, f'{combined}/{profile}')
    assert result['checks'] == 146 and result['exit'] == 1
    assert 'timed out after 40 seconds' in result['error']
    assert len(result['arc_witnesses']) >= 8
    result['arc_witness_count'] = len(result.pop('arc_witnesses'))

sparse = snapshot('sparse-timing', 'atlas-sparse-boundary-grid-timing-20261126', 'run.py')
assert sparse['exit'] == 0 and len(sparse['runs']) == 4
assert len({(tuple(r['glb_sha256']), r['scene_sha256']) for r in sparse['runs']}) == 1
assert all(r['passed'] and r['arc_device'] and r['seconds'] > 40 for r in sparse['runs'])
for profile in ('release', 'asan'):
    fixture = snapshot(f'grid-{profile}', f'atlas-sparse-grid-fixture-20261126/{profile}')
    assert fixture['exit'] == 0
    assert all('574 analytic intersections' in row['result'] for row in fixture['results'].values())
    native = snapshot(f'sparse-native-{profile}', f'atlas-sparse-boundary-grid-validation-20261126/native-{profile}')
    assert native['exit'] == 0 and len(native['results']) == 6

prefix = 'hdr-preview-retention-priority-measurement-20261126'
for profile in ('release-2048', 'asan-2048'):
    label = f'hdr-clear-undo-{profile}'
    result = snapshot(label, f'{prefix}/{profile}', 'preview.log')
    preview = members[f'{label}/preview.log'].decode()
    maps = re.findall(r'^RANGE (?:INITIAL|RESTORED) object=4 map=(\S+)', preview, re.M)
    ready = re.search(r'^RESTORED default_ready=1 first_seconds=([\d.]+)', preview, re.M)
    retained = re.search(r'^CACHE RESTORED retained=(\d+) entries=\d+ limit=(\d+) builds=(\d+) ', preview, re.M)
    cleared = re.search(r'^CACHE CLEARED .* builds=(\d+) ', preview, re.M)
    assert result['exit'] == 0 and len(maps) == 2 and maps[0] == maps[1]
    assert float(ready[1]) < 10 and int(retained[1]) <= int(retained[2]) == 512 * 1024 * 1024
    assert retained[3] == cleared[1]
    result['restored_preview_seconds'] = float(ready[1])
    result['restored_retention_bytes'] = int(retained[1])
    result['same_immutable_preview'] = True

main = snapshot('hdr-main-port-release', 'hdr-preview-history-main-port-validation-20261126/release')
assert main['exit'] == 0 and len(main['results']) == 6
history = snapshot('hdr-bake-ordered-history-asan', 'hdr-preview-retention-priority-history-20261126/asan-2048',
                   'ordered-history.log', 'ordered-history.json')
history_result, = history['runs']
history_log = members['hdr-bake-ordered-history-asan/ordered-history.log']
assert history['exit'] == history_result['exit'] == 0
assert history_result['checks'] == [8] and history_result['libasan_mapped'] and history_result['libubsan_mapped']
assert history_result['peak_owned_rss'] < history['owned_RSS_limit_bytes']
assert history_result['elapsed_seconds'] < history['deadline_per_phase_seconds']
assert hashlib.sha256(history_log).hexdigest() == history_result['log_sha256']
assert b'CHECKED_SOURCE_REDO invoked=1 preview_ready=1' in history_log
assert b'CHECKED_SOURCE_REDO native_exact=1' in history_log
native_save = artifacts/'hdr-preview-retention-priority-history-20261126/asan-2048/ordered-history/000-ordered.dsculpt'
with native_save.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == history['capture_inputs']['observed-second-bake.dsculpt']

for profile in ('release', 'asan'):
    frontier = snapshot(f'frontier-native-{profile}', f'atlas-chart-frontier-validation-20261126/native-{profile}')
    assert frontier['exit'] == 0 and len(frontier['results']) == 6
    oracle = snapshot(f'frontier-oracle-{profile}', f'atlas-chart-frontier-oracle-20261126/{profile}')
    assert oracle['exit'] == 0 and oracle['identical_output'] and oracle['full_rescan_oracle']
    assert len(oracle['cases']) == 4
software = snapshot('frontier-software-xr', 'atlas-chart-frontier-validation-20261126/software-release')
assert software['exit'] == 0 and software['checks'] == 153 and software['report_complete']
frontier_timing = snapshot('frontier-timing', 'atlas-chart-frontier-timing-20261126', 'run.py')
assert frontier_timing['exit'] == 0 and len(frontier_timing['runs']) == 4
assert len({(tuple(r['glb_sha256']), r['scene_sha256']) for r in frontier_timing['runs']}) == 1
assert all(r['passed'] and r['arc_device'] for r in frontier_timing['runs'])

for profile in ('release', 'asan'):
    direct = snapshot(f'direct-grid-native-{profile}', f'atlas-direct-grid-visit-validation-20261126/native-{profile}')
    assert direct['exit'] == 0 and len(direct['results']) == 6
    grid = snapshot(f'direct-grid-oracle-{profile}', f'atlas-direct-grid-visit-oracle-20261126/{profile}')
    assert grid['exit'] == 0 and all('574 analytic intersections' in row['result'] for row in grid['results'].values())
direct_xr = snapshot('direct-grid-software-xr', 'atlas-direct-grid-visit-validation-20261126/software-release')
assert direct_xr['exit'] == 0 and direct_xr['checks'] == 153 and direct_xr['report_complete']

strict_status = artifacts/'hdr-preview-history-main-port-validation-20261126/asan/status.json'
if json.loads(strict_status.read_text())['terminal']:
    strict = snapshot('hdr-main-port-asan', 'hdr-preview-history-main-port-validation-20261126/asan', 'ctest.log', 'app.log')
    assert strict['exit'] == 0 and len(strict['tests']) == 5 and strict['source'] == main['candidate']
    assert b'100% tests passed, 0 tests failed out of 5' in members['hdr-main-port-asan/ctest.log']
    assert b'Dome Sculpt 0.1.0 / CPU' in members['hdr-main-port-asan/app.log']

members['recorder.py'] = Path(__file__).read_bytes()
archive = root / 'docs/validation/atlas-grid-hdr-history-20261126.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as tar:
    for name, payload in sorted(members.items()):
        member = tarfile.TarInfo(name)
        member.mode = 0o644
        member.size = len(payload)
        tar.addfile(member, io.BytesIO(payload))
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(members)
    assert all(tar.extractfile(name).read() == payload for name, payload in members.items())
receipt['archive'] = {'path': str(archive.relative_to(root)), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(members)}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
