from pathlib import Path
import fcntl
import hashlib
import json
import os
import signal
import subprocess
import time

base=Path(__file__).resolve().parent
artifacts=base.parent
products=artifacts/'combined-atlas-xr-candidate-validation-20261126'
sparse=artifacts/'atlas-chart-frontier-validation-20261126'
candidate=sparse/'asan/dome-sculpt'
parent=products/'asan/dome-sculpt'
app=candidate
runtime=products/'arc-asan/libdome-sculpt-test-runtime.so'
node='/dev/dri/renderD129'
library=str(artifacts/'sdk-20261126/toolkit-sanitize/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'
status={'terminal':False,'invocation':os.getenv('INVOCATION_ID'),'runs':[]}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def record(**fields):
    status.update(fields)
    tmp=base/'status.tmp'
    tmp.write_text(json.dumps(status,indent=2)+'\n')
    tmp.replace(base/'status.json')

def children(pid):
    yield pid
    try:
        listing=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
    except (ProcessLookupError,FileNotFoundError):
        return
    for child in listing:
        yield from children(int(child))

def process(pid):
    for n in children(pid):
        proc=Path(f'/proc/{n}')
        try:
            if (proc/'exe').resolve()==app:
                return n
        except (ProcessLookupError,FileNotFoundError):
            pass
    return None

try:
    fixture=json.loads((products/'arc-asan/status.json').read_text())
    assert fixture['runtime_sha256']==sha(runtime) and fixture['app_sha256']==sha(parent)
    awaiting=time.monotonic()+600
    record(phase='wait for qualified atlas test build and the earlier Arc replay')
    while True:
        native=sparse/'native-asan/status.json'
        prior=products/'arc-asan-rerun/status.json'
        if native.is_file() and prior.is_file():
            checked=json.loads(native.read_text())
            earlier=json.loads(prior.read_text())
            if checked['terminal'] and earlier['terminal']:
                assert checked['exit']==0
                break
        assert time.monotonic()<awaiting
        time.sleep(2)
    built=json.loads((sparse/'asan/status.json').read_text())
    assert built['linked']['dome-sculpt']==sha(candidate)
    assert (artifacts/'atlas-chart-frontier-source-20261126/tests/xr_runtime.cpp').read_bytes()==(artifacts/'combined-atlas-xr-candidate-source-20261126/tests/xr_runtime.cpp').read_bytes()
    record(phase='matched Arc exports',candidate=built['candidate'],input_runtime_sha256=sha(runtime))
    lease=Path('/tmp/dome-sculpt-arc-device.lock')
    with lease.open('rb') as handle:
        fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for name,app in [('parent-1',parent),('candidate-1',candidate),('candidate-2',candidate),('parent-2',parent)]:
            out=base/name
            out.mkdir(mode=0o700)
            record(phase=name)
            manifest=out/'runtime.json'
            manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(runtime)}}))
            scene=out/'files.dsculpt'
            report=out/'files.json'
            command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
                     '--proc','/proc','--dev','/dev','--dev-bind',node,node,'--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
            environment={'PATH':'/usr/bin:/bin','HOME':str(out),'XDG_RUNTIME_DIR':str(out),
                         'XDG_STATE_HOME':str(out/'state'),'XDG_CONFIG_HOME':str(out/'config'),
                         'XR_RUNTIME_JSON':str(manifest),'LD_LIBRARY_PATH':library,
                         'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
                         'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1','DOME_XR_FIXTURE_FILES':'1',
                         'DOME_XR_FIXTURE_REPORT':str(report),'MESA_SHADER_CACHE_DISABLE':'1',
                         'DRI_PRIME':'pci-0000_03_00_0','LIBGL_ALWAYS_SOFTWARE':'0','LP_NUM_THREADS':'2'}
            for key,value in environment.items():
                command.extend(['--setenv',key,value])
            command.extend([app,'--xr','--frames','45','--save',scene])
            observed=False
            cpu_ticks=None
            start=time.monotonic()
            with (out/'application.log').open('w') as log:
                running=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                while running.poll() is None:
                    seconds=time.monotonic()-start
                    if seconds>=100:
                        os.killpg(running.pid,signal.SIGTERM)
                        try:
                            running.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            os.killpg(running.pid,signal.SIGKILL)
                            running.wait()
                        break
                    n=process(running.pid)
                    if n:
                        try:
                            proc_stat=Path(f'/proc/{n}/stat').read_text().rsplit(')',1)[1].split()
                            cpu_ticks=int(proc_stat[11])+int(proc_stat[12])
                        except (FileNotFoundError,ProcessLookupError):
                            pass
                        for descriptor in Path(f'/proc/{n}/fd').glob('*'):
                            try:
                                observed|=os.readlink(descriptor)==node
                            except (FileNotFoundError,ProcessLookupError):
                                pass
                    time.sleep(.2)
            evidence=json.loads(report.read_text()) if report.exists() else {}
            exports=list((out/'state/dome-sculpt').glob('*.glb'))
            native=list((out/'state/dome-sculpt').glob('*.dsculpt'))
            row={'case':name,'exit':running.returncode,'seconds':round(time.monotonic()-start,3),
                 'arc_device':observed,'frames':evidence.get('frames_ended'),'native_scene':scene.is_file(),
                 'stereo_export_panel':evidence.get('file_export_images',{}).get('32'),
                 'native_recovery':sum(f.stat().st_size>100 for f in native),
                 'valid_glb':sum(f.open('rb').read(4)==b'glTF' for f in exports),
                 'app_sha256':sha(app),'scene_sha256':sha(scene) if scene.is_file() else None,
                 'process_cpu_seconds':cpu_ticks/os.sysconf('SC_CLK_TCK') if cpu_ticks else None,
                 'glb_sha256':[sha(f) for f in exports]}
            passed=all((row['exit']==0,observed,row['frames']==45,row['native_scene'],
                        row['native_recovery'],row['valid_glb'],
                        row['stereo_export_panel'] and min(row['stereo_export_panel'].values())>1000))
            status['runs'].append({**row,'passed':passed})
            record()
    ok=(all(row['passed'] for row in status['runs']) and
        len({tuple(row['glb_sha256']) for row in status['runs']})==1 and
        len({row['scene_sha256'] for row in status['runs']})==1)
    record(phase='complete',terminal=True,exit=int(not ok))
    raise SystemExit(not ok)
except Exception as failure:
    record(terminal=True,exit=1,error=repr(failure))
    raise
