import hashlib,json,pathlib,shlex,sys
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1]
sys.path.insert(0,str(R/'artifacts/guard87-validation-admitted-v3-20261115'));from runtime_contract import read_runtime
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
prior=R/'artifacts/advanced-public-normal-links-v2-20261117/inputs-before.json';catalogs=[('selected_current_runtime',read_runtime()['pins']),('same_prior_runtime_link_tool/startup',json.loads(prior.read_text()))];selected={}
for role,catalog in catalogs:
 for f,h in catalog.items():
  if pathlib.Path(f).is_file():selected.setdefault(str(pathlib.Path(f).resolve()),(h,role))
state=json.loads((P/'compile-status.json').read_text());assert state['state']=='terminal'and state['exit']==0 and not state['input_drift'];own=state['dependency_owners'][0];deps=[];pins={str(prior):sha(prior)}
text=(P/'runtime-link.d').read_text().replace('\\\n',' ')
for literal in shlex.split(text.split(':',1)[1].split('\n\n',1)[0]):
 f=pathlib.Path(literal)
 if not f.is_absolute():f=P/f
 if not f.is_file():continue
 actual=sha(f)
 if f==P/'advanced-runtime.o':want=own['object_sha256'];role='fresh_complete_TU'
 else:want,role=selected.get(str(f.resolve()),(None,None))
 assert want==actual,('Expected same selected link input absent/changed',str(f),want,actual)
 deps.append({'path':str(f),'resolved':str(f.resolve()),'sha256':actual,'expected_authority':role});pins[str(f)]=actual;pins[str(f.resolve())]=actual
assert deps
for f in [P/'runtime-link.d',P/'compile-status.json',P/'compile-inputs.json',P/'libdome-sculpt-source8-public-runtime.so',pathlib.Path(__file__).resolve()]:pins[str(f)]=sha(f)
(P/'link-selected-closure.json').write_text(json.dumps({'state':'terminal','exit':0,'runtime':state['runtime'],'actual_link_dependencies':deps,'pins':pins,'scope':'Postlink same selected-runtime/link-tool input audit from actual linker dependency file, with complete compile owner proof. This is not a claim of prelink monitoring or ldd/product/GL execution.'},indent=2)+'\n');print('Actual independently matched link dependencies',len(deps))
