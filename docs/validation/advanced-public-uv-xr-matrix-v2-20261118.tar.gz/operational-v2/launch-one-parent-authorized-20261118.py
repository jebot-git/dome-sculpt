"""Launch one explicitly authorized immutable driver case in a bounded user unit."""
import argparse,hashlib,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main(a):
 assert sha(P/'run-v2.py')=='ca4aaa9378520d50a4b16da546d70f566ef90f015e9df297cf388b650055a423'
 assert sha(P/'cohort.py')=='04559c384dd1dab10055ddf5d2cd22fd52f73833bea44965dabfb6222a726a91'
 assert sha(a.review)==a.review_sha
 review=json.loads(a.review.read_text());assert review['state']=='reviewed-advanced-public-operational'and review['phase']==a.phase and review['workflow']==a.workflow and a.case in review['cases']
 assert a.case in ['raster-'+mt+'-'+pose for mt in ['mt0','mt1']for pose in ['rest','posed']]+['retained-'+mt+'-'+pose for mt in ['mt0','mt1']for pose in ['rest','posed']]
 assert a.tag and '/'not in a.tag and a.gui_tag and '/'not in a.gui_tag
 out=P/('release-'+a.workflow+'-'+a.phase+'-'+a.case+'-'+a.tag);assert not out.exists()
 unit='ds-advanced-'+a.workflow+'-'+a.phase+'-'+a.case+'-'+a.tag
 argv=['/usr/bin/python3',str(P/'run-v2.py'),'release',a.phase,'--workflow',a.workflow,'--case',a.case,'--tag',a.tag,'--gui-tag',a.gui_tag,'--native-status',review['native_status'],'--native-sha',review['native_status_sha256'],'--review',str(a.review.resolve()),'--review-sha',a.review_sha,'--execute']
 cmd=['systemd-run','--user','--unit='+unit,'--property=Type=exec','--property=RemainAfterExit=yes','--property=MemoryMax=8G','--property=RuntimeMaxSec=600','--property=TimeoutStopSec=10','--property=KillMode=control-group','--working-directory='+str(P),*argv]
 subprocess.run(cmd,check=True)
 fields=subprocess.check_output(['systemctl','--user','show',unit+'.service','-p','MainPID','-p','InvocationID','-p','ActiveState','-p','SubState'],text=True)
 record={'unit':unit+'.service','argv':argv,'launch_command':cmd,'initial_properties':dict(x.split('=',1)for x in fields.splitlines()),'scope':'One actual case under existing explicit parent authorization; original immutable driver owns all product/oracle/lease bounds.'}
 (P/(unit+'-launch.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'unit':record['unit'],**record['initial_properties'],'review_sha256':a.review_sha},indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--workflow',choices=['source-use','uv-create'],required=True);p.add_argument('--phase',choices=['gui','xr'],required=True);p.add_argument('--case',required=True);p.add_argument('--tag',required=True);p.add_argument('--gui-tag',required=True);p.add_argument('--review',type=Path,required=True);p.add_argument('--review-sha',required=True);main(p.parse_args())
