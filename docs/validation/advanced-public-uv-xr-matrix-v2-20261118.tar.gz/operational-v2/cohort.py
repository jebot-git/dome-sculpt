"""Explicit XR observation child; reuse unchanged App/native/desktop authority."""
import importlib.util,json,subprocess
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
BASE_ROOT=R/'artifacts/advanced-public-normal-operational-20261117'
_spec=importlib.util.spec_from_file_location('frozen_advanced_base_cohort',BASE_ROOT/'cohort.py');base=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(base)
for _name in ['S','B','HEAD','G','sha','write','verify','merge_pins','SOURCE','FIXTURE_SOURCE','APPLICATION_SOURCE','CASES']:globals()[_name]=getattr(base,_name)
CHILD_SOURCE='b7d6ff17925bd5373cc981dda2fcf9a94766f607'
GUI_AUTHORITY_ROOT=BASE_ROOT;GUI_SOURCE_TUPLE=dict(base.SOURCE_TUPLE)
SOURCE_TUPLE={**base.SOURCE_TUPLE,'runtime_scenarios':CHILD_SOURCE}
TARGETS={key:dict(value) for key,value in base.TARGETS.items()}
TARGETS['runtime']={'path':str(R/'artifacts/advanced-public-uv-xr-runtime-build-20261118/libdome-sculpt-source8-public-runtime.so'),'sha256':'2f473c6785096fbaa848d71686e592df0dfc281c14b019dad6f4722dc66997fb'}

for name in ['S','B','HEAD','G','sha','write','verify','SOURCE','FIXTURE_SOURCE','APPLICATION_SOURCE','CASES']:globals()[name]=getattr(base,name)
from runtime_contract import merge_pins
CHILD_SOURCE='b7d6ff17925bd5373cc981dda2fcf9a94766f607'
CHILD_ROOT=R/'artifacts/advanced-public-uv-xr-runtime-fix-20261118'
BUILD=R/'artifacts/advanced-public-uv-xr-runtime-build-20261118'
BUILD_SHA='325ce4cd8d571acdfd7ecf86cac4e24a8f7889bf0ba860e0939c43d00d2eb1a4';LINK_SHA='84bf2253367c64db2f7848ae296502e3d8e90d552b9648db53864d15e910fd8e';PROVENANCE_SHA='fddb2579c123f7846844c3efc360a07f3ef0e61a236e63ba4d7d8178c4573a67'
GUI_AUTHORITY_ROOT=BASE_ROOT;GUI_SOURCE_TUPLE=dict(base.SOURCE_TUPLE)
SOURCE_TUPLE={**base.SOURCE_TUPLE,'runtime_scenarios':CHILD_SOURCE}
TARGETS={k:dict(v)for k,v in base.TARGETS.items()};TARGETS['runtime']={'path':str(BUILD/'libdome-sculpt-source8-public-runtime.so'),'sha256':'2f473c6785096fbaa848d71686e592df0dfc281c14b019dad6f4722dc66997fb'}
def admit(profile,native_status,native_sha,workflow,case):
 assert workflow=='uv-create'
 assert sha(BASE_ROOT/'cohort.py')=='c003e8c9cd26145d5ad9263c78ab0a43894c8c2a980faa87eb9416a5e30225c8'
 prior=base.admit(profile,native_status,native_sha,workflow,case);pins=dict(prior['pins'])
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=CHILD_ROOT,text=True).strip()==CHILD_SOURCE and not subprocess.check_output(['git','status','--porcelain'],cwd=CHILD_ROOT,text=True)
 changed=subprocess.check_output(['git','diff','--name-only',base.SCENARIO_SOURCE,CHILD_SOURCE],cwd=CHILD_ROOT,text=True).splitlines();assert sorted(changed)==['tests/source-advanced-uv-xr.py','tests/source8-public-runtime.cpp']
 assert sha(BUILD/'compile-status.json')==BUILD_SHA and sha(BUILD/'link-selected-closure.json')==LINK_SHA
 status=json.loads((BUILD/'compile-status.json').read_text());closure=json.loads((BUILD/'link-selected-closure.json').read_text())
 assert status['state']=='terminal'and status['exit']==0 and not status['input_drift']and status['source']==CHILD_SOURCE and len(status['dependency_owners'])==1 and len(status['steps'])==3 and all(x['exit']==0 for x in status['steps'])
 assert closure['state']=='terminal'and closure['exit']==0 and closure['runtime']==TARGETS['runtime'];assert status['runtime']==TARGETS['runtime']
 merge_pins(pins,json.loads((BUILD/'compile-inputs.json').read_text()));merge_pins(pins,closure['pins'])
 assert sha(P/'scenario-provenance.json')==PROVENANCE_SHA;provenance=json.loads((P/'scenario-provenance.json').read_text());assert provenance['source']==CHILD_SOURCE and provenance['unchanged_App_native_GUI_font']
 for key in ['scenario','runtime_source']:
  row=provenance[key];source=Path(row.get('source',row.get('path')));assert sha(source)==row['sha256'];merge_pins(pins,{str(source):row['sha256']})
  if 'copy'in row:assert sha(row['copy'])==row['sha256'];merge_pins(pins,{row['copy']:row['sha256']})
 for f in [P/'scenario-provenance.json',P/'cohort.py',BUILD/'compile-status.json',BUILD/'compile-inputs.json',BUILD/'link-selected-closure.json',Path(TARGETS['runtime']['path'])]:merge_pins(pins,{str(f):sha(f)})
 assert not verify(pins)
 return {**prior,'pins':pins,'targets':TARGETS,'source_tuple':SOURCE_TUPLE,'scope':'Same App41a/native91b/font1afa/unchangedGUI product90fad/fixture27ff with observation-only XR runtime/scenario childb7d6ff17, fresh DSO2f473c. Generic render/tracking losses, actions and all numerical/time/frame/RSS bounds remain unchanged.','GUI_authority_bridge':{'root':str(GUI_AUTHORITY_ROOT),'source_tuple':GUI_SOURCE_TUPLE,'unchanged_App_native_GUI_font':True,'XR_only_test_runtime_and_scenario_child':CHILD_SOURCE,'reason':'Desktop qualification does not load the XR test runtime; only runtime pressure evidence and impossible capture observations changed.'}}
