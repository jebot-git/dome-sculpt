"""Archive terminal actual UV XR v2 cases plus preserved original failure."""
import hashlib,json,pathlib,tarfile
P=pathlib.Path(__file__).resolve().parent;R=P.parents[1];PROOF=R/'artifacts/advanced-public-normal-proof-20261117';OUT=PROOF/'docs/validation';STEM='advanced-public-uv-xr-matrix-v2-20261118'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
CASES=[m+'-'+t+'-'+p for m in ['raster','retained']for t in ['mt0','mt1']for p in ['rest','posed']]
rows=[];maximum=0;files={};tuple_expected=None
for case in CASES:
 d=P/('release-uv-create-xr-'+case+'-matrix-v2-20261118');s=json.loads((d/'status.json').read_text());c=json.loads((d/'closure-20261118.json').read_text());report=json.loads((d/'workflow/report.json').read_text())
 assert s['state']=='terminal'and s['exit']==0 and s['checks']==26 and len(s['actual_app_pids'])==2 and not s['input_drift']and not s['remaining_owned_processes']
 assert c['actual_exit']==0 and c['status_sha256']==sha(d/'status.json')and c['all_Apps_absent']and c['unit_stopped']and c['unit_ExecMainStatus']==0 and c['unit_Result']=='success'and c['independent_NB']['free']
 assert report['complete']and not report['error']and not report['drift']and all(v['passed']for v in report['checks'])
 assert tuple_expected in [None,s['source_tuple']];tuple_expected=s['source_tuple'];native=[];runtimes=[];frames=0
 for stage,phase in [('author','accepted'),('reopen','reopened')]:
  n=json.loads((d/'workflow'/stage/'native-verified.json').read_text());assert n['verified']and n['phase']==phase and n['normal_oracle']['finite_samples']and n['normal_oracle']['maximum_allowed_error']==.035;maximum=max(maximum,n['normal_oracle']['maximum_component_error']);native.append(n)
  runtime=json.loads((d/'workflow'/stage/'runtime.json').read_text());assert runtime['frames_waited']==runtime['frames_begun']==runtime['frames_ended'];assert runtime['acquires']==runtime['image_waits']==runtime['releases'];frames+=runtime['frames_waited'];runtimes.append({'stage':stage,'frames':runtime['frames_waited'],'acquires':runtime['acquires'],'stereo_submissions':runtime['stereo_submissions'],'empty_submissions':runtime.get('empty_submissions'),'renderer':runtime['gl_renderer'],'actual_pressure_events':runtime.get('advanced_uv_pressures',[]),'capture_keys':sorted(runtime.get('advanced_uv_captures',{}))})
 assert frames<=6000
 rows.append({'case':case,'status_sha256':sha(d/'status.json'),'checks':s['checks'],'seconds':s['seconds'],'peak_RSS':s['peak_RSS'],'input_pin_count':len(s['pins']),'source_tuple':s['source_tuple'],'critical_expected_ELFs':s['critical_expected_ELFs'],'critical_observed':s['critical_observed'],'device_reports':s['device_reports'],'closure':c,'report':report,'native_verifications':native,'actual_runtime':runtimes,'total_frames':frames})
 for f in d.rglob('*'):
  if f.is_file():files[str(f.relative_to(P))]=f
old=R/'artifacts/advanced-public-normal-operational-20261117';failed=old/'release-uv-create-xr-raster-mt0-rest-matrix-v1-20261118';failure=json.loads((failed/'status.json').read_text());assert failure['exit']==1 and not failure['input_drift']and not failure['remaining_owned_processes'];fc=json.loads((failed/'closure-20261118.json').read_text());assert fc['unit_stopped']and fc['all_Apps_absent']and fc['independent_NB']['free']
for f in failed.rglob('*'):
 if f.is_file():files['original-failure/'+str(f.relative_to(failed))]=f
for name in ['run-v1.py','cohort.py','scenarios/source-advanced-uv-xr.py','parent-authorized-uv-create-xr-20261118.json']:files['original-operational/'+name]=old/name
for f in P.rglob('*'):
 if f.is_file()and f.parent==P and f.suffix in ['.py','.json','.diff']:files['operational-v2/'+f.name]=f
for sub in ['scenarios','bin']:
 for f in (P/sub).rglob('*'):
  if f.is_file():files['operational-v2/'+str(f.relative_to(P))]=f
build=R/'artifacts/advanced-public-uv-xr-runtime-build-20261118'
for f in build.iterdir():
 if f.is_file():files['runtime-build/'+f.name]=f
source=R/'artifacts/advanced-public-uv-xr-runtime-fix-20261118'
for name in ['tests/source8-public-runtime.cpp','tests/source-advanced-uv-xr.py']:files['runtime-scenario-child/'+name]=source/name
archive=OUT/(STEM+'.tar.gz');assert not archive.exists();members={}
with tarfile.open(archive,'w:gz',compresslevel=6)as tar:
 for name,f in sorted(files.items()):assert not f.is_symlink();members[name]=sha(f);tar.add(f,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz')as tar:
 assert set(tar.getnames())==set(members)
 for m in tar:assert hashlib.sha256(tar.extractfile(m).read()).hexdigest()==members[m.name]
summary={'state':'terminal','exit':0,'cases':8,'checks':208,'fresh_Apps':16,'source_tuple':tuple_expected,'runtime_ELF_sha256':'2f473c6785096fbaa848d71686e592df0dfc281c14b019dad6f4722dc66997fb','maximum_normal_component_error':maximum,'normal_error_bound_unchanged':.035,'actual_input_stream_shouldRender_viewloss_unchanged':True,'actual_capture_frames':[13,16,19,25,29],'original_failure':{'status_sha256':sha(failed/'status.json'),'report':json.loads((failed/'workflow/report.json').read_text()),'closure':fc},'runtime_build':json.loads((build/'compile-status.json').read_text()),'selected_link_closure':json.loads((build/'link-selected-closure.json').read_text()),'GUI_authority_bridge':json.loads((P/'static-admission-v2.json').read_text())['GUI_authority_bridge'],'rows':rows,'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':members},'scope':'Advanced component syntheticXR test-runtime/scenario observation child; App/native/GUI/font unchanged. No whole advanced owning/nativeWayland/physicalHMD/mainproduct admission.'}
assert maximum<.035;(OUT/(STEM+'.json')).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items()if k not in ['rows','archive','runtime_build','selected_link_closure','original_failure']},indent=2));print(archive,archive.stat().st_size)
