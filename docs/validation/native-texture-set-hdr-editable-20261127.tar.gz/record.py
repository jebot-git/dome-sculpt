from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
dest=repo/"docs/validation"
name="native-texture-set-hdr-editable-20261127"
commit=subprocess.check_output(["git","-C",repo,"rev-parse",sys.argv[1]],text=True).strip()
assert subprocess.check_output(["git","-C",repo,"show","--format=","--binary",commit])==(root/"source.patch").read_bytes()
files={}
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
def keep(file):
    files[file]=root/file
    return sha(root/file)
def read(file):
    return json.loads((root/file).read_text())

report={"product":commit,"source_patch_sha256":keep("source.patch"),"profiles":{},"frontends":{},"khronos":{},
        "scope":"Per-material physical emission for plain and retained PBR texture sets through the Editable GLB worker, with exact native restore and portable per-field radiance and paint coordinates."}
for file in ("product-v2.patch","record.py","run-v1.py","run.py","checks.py","editable.cpp",
             "registered-release.log","registered-ctest.json","public-focus.py","wayland.py","xr-focus.py"):
    keep(file)
packages=("probe/editable.glb","checks/plain/editable-texture-set-hdr.glb","checks/retained/editable-retained-hdr.glb")
expected={}
for mode in ("release-v2","asan-v2"):
    prefix=mode+"/"
    run=read(prefix+"status.json")
    checks=read(prefix+"checks/status.json")
    assert run["terminal"] and run["exit"]==0 and checks["terminal"] and checks["exit"]==0
    assert run["diff_sha256"]==sha(root/"product-v2.patch")
    for log,text in (
        ("editable.log","Editable reopens exact native Scene"),
        ("checks/plain.log","PASS 81 texture-set multi-primitive export controls"),
        ("checks/retained.log","PASS 44 retained Editable HDR controls"),
        ("checks/retained-legacy.log","PASS 6074 actual retained standard source export controls"),
        ("checks/native-authoring.log","Native authoring package: 28 checks"),
    ):
        assert text in (root/(prefix+log)).read_text()
        keep(prefix+log)
    for log in ("status.json","checks/status.json","archive.log","dome-sculpt-link.log",
                "texture-set-export.cpp.log","editable-link.log"):
        keep(prefix+log)
    for file in packages:
        digest=sha(root/(prefix+file))
        if mode=="release-v2":expected[file]=digest
        else:assert digest==expected[file]
    report["profiles"][mode]={"app_sha256":run["app_sha256"],"native_checks":{"plain":81,"retained_hdr":44,
        "retained_legacy":6074,"native_authoring":28},"files_sha256":dict(expected)}
for mode in ("wayland","software","arc"):
    folder=f"{mode}-focus-texture-set-editable-hdr/"
    run=read(folder+"status.json")
    assert run["exit"]==0 and run["checks"]==(9 if mode=="wayland" else 10)
    assert run["native_sha256"]==expected[packages[0]]
    for log in ("status.json","run.log","workflow/report.json"):
        keep(folder+log)
    if mode=="wayland":
        for log in ("runtime-maps.txt","client.log","compositor.log"):
            keep(folder+"workflow/"+log)
    else:
        for step in ("accept","focus"):
            for log in ("application.log","graphics.json"):
                keep(folder+f"workflow/{step}/{log}")
    report["frontends"][mode]=run
for file,warnings in zip(packages,(0,1,0)):
    result="release-v2/"+file+".khronos.json"
    issues=read(result)["issues"]
    assert issues["numErrors"]==0 and issues["numWarnings"]==warnings
    report["khronos"][file]={"errors":0,"warnings":warnings,"report_sha256":keep(result)}
report["open"]="Exact Standard GLB per-field FLOAT packaging, typed texture-set and alternate emission domains, physical headset checks, and full integrated regression remain open."
archive=dest/(name+".tar.gz")
with archive.open("wb") as raw,gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode="w") as tar:
    for filename,path in sorted(files.items()):
        payload=path.read_bytes()
        item=tarfile.TarInfo(filename)
        item.size=len(payload)
        tar.addfile(item,io.BytesIO(payload))
report["archive"]={"file":archive.name,"sha256":sha(archive),"members":len(files)}
(dest/(name+".json")).write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
print(commit,report["archive"])
