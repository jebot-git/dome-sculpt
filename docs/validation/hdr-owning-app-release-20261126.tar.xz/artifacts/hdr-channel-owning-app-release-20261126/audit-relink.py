from pathlib import Path
import json,hashlib,subprocess,shlex,time,os
O=Path(__file__).resolve().parent;D=O/'relink-v3';P=json.loads((D/'plan.json').read_text());B=Path(P['cwd']);pins=json.loads((D/'before-inputs.json').read_text());A=json.loads((O/'audit.json').read_text());S=json.loads((D/'status.json').read_text());assert S['terminal'] and S['exit']==0;errors=[]
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def norm(p):
 p=Path(p);return Path(os.path.normpath(p if p.is_absolute() else B/p))
def known(p):
 p=norm(p);v=pins.get(str(p),pins.get(str(p.resolve())));return v and p.is_file() and sha(p)==v['sha256']
for p,v in pins.items():
 if sha(p)!=v['sha256']:errors.append('Relink beforeinput changed '+p)
for owner in A['actual_owners']:
 if sha(owner['object'])!=owner['object_sha256'] or sha(owner['actual_MD'])!=owner['actual_MD_sha256']:errors.append('Original actual compiler owner changed '+owner['object'])
for arc in A['archives']:
 if sha(arc['path'])!=arc['sha256']:errors.append('Original actual archive payload changed '+arc['path'])
links=[]
for row in P['links']:
 args=row['command'];path=Path(row['path']);md=Path(str(path)+'.link.d');inputs=[]
 for word in shlex.split(md.read_text().replace('\\\n',' ').split(':',1)[1]):
  if word.endswith(':'):continue
  p=norm(word);inputs.append({'path':str(p),'sha256':sha(p) if p.is_file() else None})
  if not known(p):errors.append('Actual admitted linker input unknown/drift '+str(p))
 if sha(row['original_ELF'])!=row['original_ELF_SHA256']:errors.append('Original first ELF not preserved '+row['original_ELF'])
 links.append({'path':str(path),'sha256':sha(path),'actual_command':args,'actual_link_MD':str(md),'actual_link_MD_sha256':sha(md),'actual_link_MD_inputs':inputs,'DT_NEEDED':subprocess.check_output(['/usr/bin/readelf','-d',str(path)],text=True),'byte_equal_original_unadmitted_ELF':sha(path)==row['original_ELF_SHA256']})
r={'exit':int(bool(errors)),'errors':errors,'source':A['source'],'named_parent':A['named_parent'],'scope':'Actual second links on same verified254 fresh whole compiler owners/14archives after prospective GCC16 atomic implicit providers. First9ELFs/rawlinkMD/audit1 preserved unadmitted; setup-only failedrelinkv2 has no product link. Runtime remains separate.','actual_whole_TUs':A['actual_whole_TUs'],'actual_dependency_paths':A['actual_dependency_paths'],'actual_owners':A['actual_owners'],'archives':A['archives'],'links':links,'original_audit1_sha256':sha(O/'audit.json'),'admitted_link_before_sha256':sha(D/'before-inputs.json'),'observed':time.time()};(D/'audit.json').write_text(json.dumps(r,indent=2)+'\n');print('admittedaudit',r['exit'],'whole',r['actual_whole_TUs'],'archives',len(r['archives']),'ELFs',len(links),'errors',errors[:12]);raise SystemExit(r['exit'])
