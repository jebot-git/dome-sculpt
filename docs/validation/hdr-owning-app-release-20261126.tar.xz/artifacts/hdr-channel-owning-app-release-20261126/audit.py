from pathlib import Path
import json,hashlib,shlex,subprocess,time,re,os
O=Path(__file__).resolve().parent;P=json.loads((O/'plan.json').read_text());B=Path(P['build_dir']);pins=json.loads((O/'final-before-inputs.json').read_text());status=json.loads((O/'status.json').read_text());assert status['terminal'] and status['exit']==0;errors=[]
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def norm(p):
 p=Path(p);p=p if p.is_absolute() else B/p;return Path(os.path.normpath(p))
def known(p):
 p=norm(p);return str(p) in pins and sha(p)==pins[str(p)]['sha256'] or str(p.resolve()) in pins and sha(p)==pins[str(p.resolve())]['sha256']
records={}
for file in (O/'compiler-records').glob('*.json'):
 r=json.loads(file.read_text());records[r['object']]=(file,r)
owners=[];objects={};deps_all=set()
for planned in P['planned_compiles']:
 obj=planned['object'];file,r=records[obj];assert r['exit']==0 and sha(obj)==r['object_sha256'] and sha(r['depfile'])==r['depfile_sha256'];deps=[]
 for value in shlex.split(Path(r['depfile']).read_text().replace('\\\n',' ').split(':',1)[1]):
  if value.endswith(':'):continue
  p=norm(value);deps.append(str(p));deps_all.add(str(p))
  if not known(p):errors.append('Actual compiler dependency unknown/drift '+str(p))
 flags=[x for x in r['command'] if re.fullmatch(r'-O[0-3sgz]',x)]
 if not flags or flags[-1]!='-O3' or '-DNDEBUG' not in r['command']:errors.append('Actual selected owner lacks ReleaseO3/NDEBUG '+obj)
 objects[obj]=r['object_sha256'];owners.append({'record':str(file),'object':obj,'object_sha256':r['object_sha256'],'actual_MD':r['depfile'],'actual_MD_sha256':r['depfile_sha256'],'dependencies':deps,'actual_command':r['command'],'actual_cwd':r['cwd']})
rows=(O/'selected-commands.txt').read_text().splitlines();archives=[];archive_map={};links=[]
for row in rows:
 cmd=shlex.split(row)
 if '/usr/bin/ar' not in cmd:continue
 start=cmd.index('/usr/bin/ar');end=cmd.index('&&',start) if '&&' in cmd[start:] else len(cmd);args=cmd[start:end];path=norm(args[2]);inputs=[norm(x) for x in args[3:]];members=subprocess.check_output(['/usr/bin/ar','t',str(path)],text=True).splitlines();assert len(set(members))==len(members)
 if members!=[p.name for p in inputs]:errors.append('Actual archive member sequence differs '+str(path))
 for member,obj in zip(members,inputs):
  payload=hashlib.sha256(subprocess.check_output(['/usr/bin/ar','p',str(path),member])).hexdigest()
  if objects.get(str(obj))!=payload:errors.append('Archive member differs from admitted real whole compiler owner '+str(path)+':'+member)
 a={'path':str(path),'sha256':sha(path),'members':members,'whole_object_inputs':list(map(str,inputs)),'actual_command':args};archives.append(a);archive_map[str(path)]=a['sha256']
for row in rows:
 cmd=shlex.split(row)
 if '/usr/bin/c++' not in cmd or '-o' not in cmd or '-c' in cmd:continue
 start=cmd.index('/usr/bin/c++');end=cmd.index('&&',start) if '&&' in cmd[start:] else len(cmd);args=cmd[start:end];path=norm(args[args.index('-o')+1]);inputs=[]
 for value in args:
  if value.endswith(('.o','.a','.so')) or '.so.' in value:
   p=norm(value)
   if p.is_file():
    digest=sha(p);inputs.append({'path':str(p),'sha256':digest})
    if str(p) not in objects and str(p) not in archive_map and not known(p):errors.append('Actual link input unknown/drift '+str(p))
 linkmd=next((norm(x.split('=',1)[1]) for x in args if x.startswith('-Wl,--dependency-file=')),None);actual_ld=[]
 if linkmd:
  for value in shlex.split(linkmd.read_text().replace('\\\n',' ').split(':',1)[1]):
   if value.endswith(':'):continue
   p=norm(value);actual_ld.append({'path':str(p),'sha256':sha(p) if p.is_file() else None})
   if str(p) not in objects and str(p) not in archive_map and not known(p):errors.append('Actual linker MD unknown/drift '+str(p))
 links.append({'path':str(path),'sha256':sha(path),'actual_command':args,'inputs':inputs,'actual_link_MD':str(linkmd) if linkmd else None,'actual_link_MD_inputs':actual_ld,'DT_NEEDED':subprocess.check_output(['/usr/bin/readelf','-d',str(path)],text=True)})
for p,v in pins.items():
 if not Path(p).is_file() or sha(p)!=v['sha256']:errors.append('Prospective input drift '+p)
result={'exit':int(bool(errors)),'errors':errors,'source':P['source'],'named_parent':P['named_parent'],'scope':'Fresh selected optimized owning App and HDR consumers; each real whole-TU MD, all fresh archive payloads and actual ELF/link-MD inputs checked. Canonical installed toolkit reused as explicitly pinned provider, not rebuilt/admitted as new SDK. Runtime/UI/native qualification remains separate.','actual_whole_TUs':len(owners),'actual_dependency_paths':len(deps_all),'actual_owners':owners,'archives':archives,'links':links,'before_inputs_sha256':sha(O/'final-before-inputs.json'),'observed':time.time()};(O/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print('audit',result['exit'],'owners',len(owners),'dependencies',len(deps_all),'archives',len(archives),'links',len(links),'errors',errors[:8]);raise SystemExit(result['exit'])
