from pathlib import Path
import json,subprocess,time,hashlib,os
O=Path(__file__).resolve().parent;P=json.loads((O/'plan.json').read_text());B=Path(P['build_dir']);S={'terminal':False,'source':P['source'],'started':time.time(),'scope':P['scope']};pins=json.loads((O/'final-before-inputs.json').read_text());cmd=['/usr/bin/ninja','-C',str(B),'-d','keepdepfile','-d','keeprsp','-j2',*P['targets']];env=dict(os.environ,**P['environment'])
def save():(O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
save()
try:
 assert not [p for p,v in pins.items() if sha(p)!=v['sha256']],'Prospective input drift before actual whole compilation'
 S['actual_command']=cmd;S['before_pins_sha256']=sha(O/'final-before-inputs.json');S['actual_build_script_sha256']=sha(O/'build.py');S['compilation_started']=time.time();save()
 with (O/'build.log').open('w') as f:r=subprocess.run(cmd,env=env,cwd=B,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
 S['exit']=r.returncode;S['input_drift']=[p for p,v in pins.items() if sha(p)!=v['sha256']];assert r.returncode==0 and not S['input_drift'],'Fresh owning compilation/link result or input drift'
except BaseException as e:S.update(exit=1,error=repr(e))
S.update(terminal=True,seconds=time.time()-S['started']);save();print(json.dumps(S),flush=True);raise SystemExit(S['exit'])
