CMakeFiles/dome-sculpt-affine.dir/src/affine.cpp.o: \
 /home/blux/de-xr/dome-sculpt/artifacts/source-hdr-channel-app-20261126/src/affine.cpp \
 /usr/include/stdc-predef.h \
 /home/blux/de-xr/dome-sculpt/artifacts/source-hdr-channel-app-20261126/include/dome/affine.hpp \
 /usr/include/c++/16/array /usr/include/c++/16/compare \
 /usr/include/c++/16/bits/version.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++config.h \
 /usr/include/bits/wordsize.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/cpu_defines.h \
 /usr/include/c++/16/pstl/pstl_config.h /usr/include/c++/16/concepts \
 /usr/include/c++/16/type_traits /usr/include/c++/16/initializer_list \
 /usr/include/c++/16/bits/stdexcept_throw.h \
 /usr/include/c++/16/bits/exception_defines.h \
 /usr/include/c++/16/bits/stdexcept_throwfwd.h \
 /usr/include/c++/16/bits/stl_algobase.h \
 /usr/include/c++/16/bits/cpp_type_traits.h \
 /usr/include/c++/16/ext/type_traits.h \
 /usr/include/c++/16/ext/numeric_traits.h \
 /usr/include/c++/16/bits/stl_pair.h /usr/include/c++/16/bits/move.h \
 /usr/include/c++/16/bits/utility.h \
 /usr/include/c++/16/bits/stl_iterator_base_types.h \
 /usr/include/c++/16/bits/iterator_concepts.h \
 /usr/include/c++/16/bits/ptr_traits.h \
 /usr/include/c++/16/bits/ranges_cmp.h \
 /usr/include/c++/16/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/16/bits/concept_check.h \
 /usr/include/c++/16/debug/assertions.h \
 /usr/include/c++/16/bits/stl_iterator.h /usr/include/c++/16/new \
 /usr/include/c++/16/bits/exception.h \
 /usr/include/c++/16/bits/new_except.h \
 /usr/include/c++/16/bits/stl_construct.h \
 /usr/include/c++/16/debug/debug.h \
 /usr/include/c++/16/bits/predefined_ops.h \
 /usr/include/c++/16/bits/stl_function.h \
 /usr/include/c++/16/backward/binders.h /usr/include/c++/16/bit \
 /usr/include/c++/16/bits/range_access.h /usr/include/c++/16/algorithm \
 /usr/include/c++/16/bits/stl_algo.h \
 /usr/include/c++/16/bits/algorithmfwd.h \
 /usr/include/c++/16/bits/stl_heap.h \
 /usr/include/c++/16/bits/uniform_int_dist.h \
 /usr/include/c++/16/bits/stl_tempbuf.h /usr/include/c++/16/cstdlib \
 /usr/include/stdlib.h /usr/include/bits/libc-header-start.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stddef.h \
 /usr/include/bits/waitflags.h /usr/include/bits/waitstatus.h \
 /usr/include/bits/floatn.h /usr/include/bits/floatn-common.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/sys/types.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/time_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-bsearch.h /usr/include/bits/stdlib-float.h \
 /usr/include/c++/16/bits/std_abs.h \
 /usr/include/c++/16/bits/ranges_algo.h \
 /usr/include/c++/16/bits/ranges_algobase.h \
 /usr/include/c++/16/bits/ranges_base.h \
 /usr/include/c++/16/bits/max_size_type.h /usr/include/c++/16/numbers \
 /usr/include/c++/16/limits /usr/include/c++/16/bits/invoke.h \
 /usr/include/c++/16/bits/ranges_util.h \
 /usr/include/c++/16/pstl/glue_algorithm_defs.h \
 /usr/include/c++/16/pstl/execution_defs.h /usr/include/c++/16/cmath \
 /usr/include/c++/16/bits/requires_hosted.h /usr/include/math.h \
 /usr/include/bits/math-vector.h /usr/include/bits/libm-simd-decl-stubs.h \
 /usr/include/bits/flt-eval-method.h /usr/include/bits/fp-logb.h \
 /usr/include/bits/fp-fast.h /usr/include/bits/mathcalls-macros.h \
 /usr/include/bits/mathcalls-helper-functions.h \
 /usr/include/bits/mathcalls.h /usr/include/bits/mathcalls-narrow.h \
 /usr/include/bits/iscanonical.h /usr/include/c++/16/bits/specfun.h \
 /usr/include/c++/16/tr1/gamma.tcc \
 /usr/include/c++/16/tr1/special_function_util.h \
 /usr/include/c++/16/tr1/bessel_function.tcc \
 /usr/include/c++/16/tr1/beta_function.tcc \
 /usr/include/c++/16/tr1/ell_integral.tcc \
 /usr/include/c++/16/tr1/exp_integral.tcc \
 /usr/include/c++/16/tr1/hypergeometric.tcc \
 /usr/include/c++/16/tr1/legendre_function.tcc \
 /usr/include/c++/16/tr1/modified_bessel_func.tcc \
 /usr/include/c++/16/tr1/poly_hermite.tcc \
 /usr/include/c++/16/tr1/poly_laguerre.tcc \
 /usr/include/c++/16/tr1/riemann_zeta.tcc /usr/include/c++/16/stdexcept \
 /usr/include/c++/16/exception /usr/include/c++/16/bits/exception_ptr.h \
 /usr/include/c++/16/bits/cxxabi_init_exception.h \
 /usr/include/c++/16/typeinfo /usr/include/c++/16/bits/hash_bytes.h \
 /usr/include/c++/16/bits/nested_exception.h /usr/include/c++/16/string \
 /usr/include/c++/16/bits/stringfwd.h \
 /usr/include/c++/16/bits/memoryfwd.h \
 /usr/include/c++/16/bits/char_traits.h \
 /usr/include/c++/16/bits/postypes.h /usr/include/c++/16/cwchar \
 /usr/include/wchar.h \
 /usr/lib/gcc/x86_64-redhat-linux/16/include/stdarg.h \
 /usr/include/bits/wchar.h /usr/include/bits/types/wint_t.h \
 /usr/include/bits/types/mbstate_t.h \
 /usr/include/bits/types/__mbstate_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/c++/16/bits/allocator.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++allocator.h \
 /usr/include/c++/16/bits/new_allocator.h \
 /usr/include/c++/16/bits/new_throw.h \
 /usr/include/c++/16/bits/localefwd.h \
 /usr/include/c++/16/x86_64-redhat-linux/bits/c++locale.h \
 /usr/include/c++/16/clocale /usr/include/locale.h \
 /usr/include/bits/locale.h /usr/include/c++/16/iosfwd \
 /usr/include/c++/16/cctype /usr/include/ctype.h \
 /usr/include/c++/16/bits/ostream_insert.h \
 /usr/include/c++/16/bits/cxxabi_forced.h \
 /usr/include/c++/16/bits/erase_if.h \
 /usr/include/c++/16/bits/basic_string.h \
 /usr/include/c++/16/ext/alloc_traits.h \
 /usr/include/c++/16/bits/alloc_traits.h /usr/include/c++/16/string_view \
 /usr/include/c++/16/bits/functional_hash.h \
 /usr/include/c++/16/bits/string_view.tcc \
 /usr/include/c++/16/ext/string_conversions.h /usr/include/c++/16/cstdio \
 /usr/include/stdio.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__fpos64_t.h \
 /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/stdio.h \
 /usr/include/c++/16/cerrno /usr/include/errno.h \
 /usr/include/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h /usr/include/bits/types/error_t.h \
 /usr/include/c++/16/bits/charconv.h \
 /usr/include/c++/16/bits/basic_string.tcc \
 /usr/include/c++/16/bits/memory_resource.h /usr/include/c++/16/cstddef \
 /usr/include/c++/16/bits/uses_allocator.h \
 /usr/include/c++/16/bits/uses_allocator_args.h /usr/include/c++/16/tuple \
 /usr/include/c++/16/bits/stdexcept_except.h
