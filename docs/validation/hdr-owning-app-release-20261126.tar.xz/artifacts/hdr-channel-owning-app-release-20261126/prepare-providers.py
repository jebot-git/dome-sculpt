from pathlib import Path
import json,subprocess,hashlib,re,time
O=Path(__file__).resolve().parent;pins=json.loads((O/'before-inputs.json').read_text());P=json.loads((O/'plan.json').read_text());pending=[Path(k) for k in P['prospective_link_inputs']];pending += [Path(k) for k in json.loads((O/'preconfigure-tools.json').read_text())['tools']];pending += [Path('/usr/bin/bash'),Path('/usr/bin/ranlib'),Path('/usr/bin/readelf')];rows=[];seen=set()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def add(p,role):
 p=Path(p).absolute();assert p.is_file();pins[str(p)]={'sha256':sha(p),'resolved':str(p.resolve()),'role':role}
for name in ['crt1.o','Scrt1.o','crti.o','crtn.o','crtbegin.o','crtbeginS.o','crtend.o','crtendS.o','libstdc++.so','libgcc.a','libgcc_s.so','libgcc_s.so.1','libgcc_s_asneeded.so','libc.so','libm.so']:
 q=Path(subprocess.check_output(['/usr/bin/c++','-print-file-name='+name],text=True).strip())
 if q.is_absolute() and q.is_file():pending.append(q)
cache={}
for line in subprocess.check_output(['/sbin/ldconfig','-p'],text=True).splitlines():
 m=re.match(r'\s*(\S+)\s+\(.*x86-64.*\)\s+=>\s+(\S+)',line)
 if m:cache.setdefault(m[1],m[2])
while pending:
 p=pending.pop();add(p,'actual source/compiler/link/provider closure before whole compilation');real=p.resolve();add(real,'resolved source/compiler/link/provider closure before whole compilation')
 if str(real) in seen:continue
 seen.add(str(real));prefix=real.read_bytes()[:4]
 if prefix!=b'\x7fELF':
  # GNU linker scripts among explicit/implicit link inputs contain real paths.
  try:text=real.read_text()
  except UnicodeDecodeError:continue
  for value in re.findall(r'(?:/[^\s();]+|\b(?:lib\S+?\.so(?:\.\d+)*|\w+\.a))',text):
   q=Path(value);q=q if q.is_absolute() else real.parent/q
   if q.is_file():pending.append(q)
  continue
 raw=subprocess.check_output(['/usr/bin/readelf','-d',str(real)],text=True,stderr=subprocess.DEVNULL);rpaths=[]
 for entry in re.findall(r'\((?:RUNPATH|RPATH)\).*\[(.*?)\]',raw):rpaths+=entry.replace('$ORIGIN',str(real.parent)).split(':')
 for name in re.findall(r'\(NEEDED\).*\[(.*?)\]',raw):
  chosen=None
  for parent in ['/opt/fltk-vr/toolkit/lib','/opt/fltk-vr/bdf-runtime/lib',*rpaths,'/usr/lib64','/lib64']:
   q=Path(parent)/name
   if q.is_file():chosen=q;break
  if chosen is None and name in cache:chosen=Path(cache[name])
  assert chosen,'Unknown static provider '+name;rows.append({'from':str(real),'needed':name,'literal':str(chosen),'resolved':str(chosen.resolve()),'sha256':sha(chosen)});pending.append(chosen)
 raw=subprocess.check_output(['/usr/bin/readelf','-l',str(real)],text=True,stderr=subprocess.DEVNULL);m=re.search(r'Requesting program interpreter: (.*?)\]',raw)
 if m:pending.append(Path(m[1]))
for name in ['plan.json','before-inputs.json','prepare-providers.py']:add(O/name,'actual immutable qualification plan/pins/provider preparation')
(O/'provider-closure.json').write_text(json.dumps({'observed':time.time(),'scope':'Prospective static toolchain, explicit/implicit link, interpreter and DT_NEEDED provider closure; actual loader/maps remain separate runtime evidence','resolution':rows,'unique_files':len(seen)},indent=2)+'\n');add(O/'provider-closure.json','prospective provider resolution record')
for path,v in pins.items():assert sha(path)==v['sha256'],'Prospective changed input '+path
(O/'final-before-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');print('finalbefore0',len(pins),'pins',len(seen),'providerfiles',len(rows),'needededges')
