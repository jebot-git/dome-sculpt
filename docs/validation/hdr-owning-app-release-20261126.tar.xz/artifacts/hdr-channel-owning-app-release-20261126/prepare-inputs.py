from pathlib import Path
import json,subprocess,hashlib,shlex,time,concurrent.futures,os
O=Path(__file__).resolve().parent;P=json.loads((O/'plan.json').read_text());S=Path(P['source_dir']);B=Path(P['build_dir']);pins={}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def add(p,role):
 p=Path(p);assert p.is_file(),p;p=p.absolute();pins[str(p)]={'sha256':sha(p),'resolved':str(p.resolve()),'role':role}
assert not subprocess.check_output(['git','-C',str(S),'status','--porcelain'],text=True)
for rel in subprocess.check_output(['git','-C',str(S),'ls-files'],text=True).splitlines():add(S/rel,'actual frozen0813 source')
for p,v in json.loads((O/'preconfigure-tools.json').read_text())['tools'].items():assert sha(p)==v['sha256'];add(p,'tool verified before generation/probes and admitted compiles')
for p in ['/usr/bin/bash','/usr/bin/ranlib','/usr/bin/readelf']:add(p,'generator/link/audit tool')
for name in ['cc1','cc1plus','collect2']:
 p=Path(subprocess.check_output(['/usr/bin/c++','-print-prog-name='+name],text=True).strip());assert p.is_absolute();add(p,'actual GCC auxiliary tool before probes and whole compiles')
for p in O.glob('*.py'):add(p,'actual build/probe/launcher script')
rows=(O/'selected-commands.txt').read_text().splitlines();generators=[r for r in rows if 'wayland-scanner ' in r or (' -P ' in r and 'cmake' in r)]
(O/'before-generation.json').write_text(json.dumps({'observed':time.time(),'pins':pins,'generator_commands':generators},indent=2)+'\n')
for r in generators:
 with (O/'generation.log').open('a') as f:subprocess.run(r,shell=True,cwd=B,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=60)
selected={}
for row in rows:
 argv=shlex.split(row)
 if '-c' in argv and '-o' in argv:
  obj=Path(argv[argv.index('-o')+1]);obj=obj if obj.is_absolute() else B/obj;selected[str(obj)]=argv
cc=json.loads((B/'compile_commands.json').read_text());compiles=[]
for c in cc:
 obj=str(Path(c['output']).absolute())
 if obj in selected:compiles.append(c)
assert {str(Path(x['output']).absolute()) for x in compiles}==set(selected),(len(compiles),len(selected))
D=O/'prospective-dependencies';D.mkdir(exist_ok=True)
def probe(c):
 cmd=shlex.split(c['command']);key=hashlib.sha256(c['output'].encode()).hexdigest();out=D/(key+'.d');args=[];skip=False
 for i,arg in enumerate(cmd):
  if skip:skip=False;continue
  if arg in ['-o','-MF','-MT','-MQ']:skip=True;continue
  if arg in ['-c','-MD','-MMD']:continue
  args.append(arg)
 args+=['-M','-MF',str(out),'-MT',c['output']];start=time.time()
 with (D/(key+'.log')).open('w') as log:r=subprocess.run(args,cwd=c['directory'],stdout=log,stderr=subprocess.STDOUT,timeout=900)
 record={'scope':'Prospective preprocessing dependency discovery only; not an owning object or substituted actualMD','command':args,'cwd':c['directory'],'exit':r.returncode,'seconds':time.time()-start,'depfile':str(out),'planned_object':c['output']};(D/(key+'.json')).write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,(D/(key+'.log')).read_text()[-1500:];return record
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:probes=list(pool.map(probe,compiles))
for row in probes:
 for name in shlex.split(Path(row['depfile']).read_text().replace('\\\n',' ').split(':',1)[1]):
  if name.endswith(':'):continue
  p=Path(name);p=p if p.is_absolute() else Path(row['cwd'])/p;add(p,'prospective actual selected-TU preprocessing closure')
# Explicit generated C/header/config outputs are prospective for every owner.
for p in B.rglob('*'):
 if p.is_file() and (p.suffix in ['.h','.hpp','.cmake'] or p.name in ['CMakeCache.txt','build.ninja','rules.ninja','compile_commands.json','appmenu-protocol.c']):add(p,'actual generated/configured owning input before compilation')
# Pin every real explicit external link input and its literal/resolved provider.
link_inputs={}
for row in rows:
 for value in shlex.split(row):
  p=Path(value)
  if p.is_absolute() and p.is_file() and (value.endswith(('.a','.so')) or '.so.' in value):
   add(p,'actual explicit selected link input');add(p.resolve(),'resolved explicit selected link input');link_inputs[str(p)]=pins[str(p)]['sha256']
for p in ['/opt/fltk-vr/toolkit/share/fltk/FLTKConfig.cmake','/opt/fltk-vr/toolkit/share/fltk/FLTK-Targets.cmake']:
 if Path(p).is_file():add(p,'current canonical toolkit configure contract')
for k,v in pins.items():assert sha(k)==v['sha256'],'Prospective discovery input drift '+k
P['planned_compiles']=[{'object':c['output'],'source':c['file'],'command':c['command'],'cwd':c['directory']} for c in compiles];P['probe_records']=probes;P['prospective_link_inputs']=link_inputs;P['admitted_compile_not_started']=True;P['before_pins_observed']=time.time();(O/'plan.json').write_text(json.dumps(P,indent=2)+'\n');add(O/'plan.json','actual selected owning build plan');(O/'before-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');print('prospective0',len(compiles),'wholeowners',len(pins),'source/header/tool/generated/link pins','generators',len(generators))
