from pathlib import Path
import json,hashlib,subprocess,time
O=Path(__file__).resolve().parent;A=json.loads((O/'audit.json').read_text());assert A['exit']==1;allowed={'/usr/lib/gcc/x86_64-redhat-linux/16/libatomic_asneeded.so','/usr/lib/gcc/x86_64-redhat-linux/16/libatomic.so','/usr/lib64/libatomic.so.1.2.0'};assert A['errors'] and all(x.startswith('Actual linker MD unknown/drift ') and x.split('Actual linker MD unknown/drift ',1)[1] in allowed for x in A['errors']);D=O/'relink-v3';D.mkdir(exist_ok=False);pins=json.loads((O/'final-before-inputs.json').read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def add(p,role):
 p=Path(p);pins[str(p)]={'sha256':sha(p),'resolved':str(p.resolve()),'role':role};pins[str(p.resolve())]={'sha256':sha(p),'resolved':str(p.resolve()),'role':role}
for name in ['libatomic_asneeded.so','libatomic.so','libatomic.so.1']:
 p=Path(subprocess.check_output(['/usr/bin/c++','-print-file-name='+name],text=True).strip());assert p.is_absolute() and p.is_file(),name;add(p,'Actual implicit provider before admitted second link only; original first link unadmitted')
for name in ['audit.json','prepare-relink.py']:add(O/name,'Original first link audit/followup preparation')
for owner in A['actual_owners']:add(owner['object'],'Already authenticated real whole-TU output for admitted relink');add(owner['actual_MD'],'Original authenticated actual whole-TU MD')
for arc in A['archives']:add(arc['path'],'Already authenticated fresh archive including every actual compiler payload')
links=[]
for old in A['links']:
 args=list(old['actual_command']);path=D/Path(old['path']).name;args[args.index('-o')+1]=str(path);args=[('-Wl,--dependency-file='+str(path)+'.link.d') if x.startswith('-Wl,--dependency-file=') else x for x in args];links.append({'path':str(path),'command':args,'original_ELF':old['path'],'original_ELF_SHA256':old['sha256'],'original_link_MD':old['actual_link_MD']})
p={'source':A['source'],'scope':'Separate actual second owning App/native links after prospective actual GCC16 implicit atomic providers. Original9ELFs/rawMD/audit1 retained at originalpaths; all254 real objects/14archives unchanged and authenticated. No retroactive firstlink admission.','cwd':str(O/'release'),'links':links,'before_pins_observed':time.time()};(D/'plan.json').write_text(json.dumps(p,indent=2)+'\n');add(D/'plan.json','Actual admitted second link plan');(D/'before-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');print('relinkready9 source',A['source'],'pins',len(pins))
