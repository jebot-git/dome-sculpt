from pathlib import Path
import json,hashlib,time,subprocess,re
O=Path(__file__).resolve().parent;A=O.parent;D=O/'relink-v3';N=O/'native-release-full-v1';N.mkdir(exist_ok=False);P=json.loads((O/'plan.json').read_text());audit=json.loads((D/'audit.json').read_text());assert audit['exit']==0;pins={k:v['sha256'] for k,v in json.loads((D/'before-inputs.json').read_text()).items()}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for f in [D/'audit.json',O/'audit-relink.py',O/'native-runner.py',O/'prepare-native.py']:pins[str(f)]=sha(f)
pending=[Path(x['path']) for x in audit['links']];cache={};scanned=set();resolution=[]
for line in subprocess.check_output(['/sbin/ldconfig','-p'],text=True).splitlines():
 m=re.match(r'\s*(\S+)\s+\(.*x86-64.*\)\s+=>\s+(\S+)',line)
 if m:cache.setdefault(m[1],m[2])
while pending:
 p=pending.pop();real=p.resolve();pins[str(p)]=pins[str(real)]=sha(real)
 if str(real) in scanned:continue
 scanned.add(str(real));raw=subprocess.check_output(['/usr/bin/readelf','-d',str(real)],text=True);rpaths=[]
 for value in re.findall(r'\((?:RUNPATH|RPATH)\).*\[(.*?)\]',raw):rpaths+=value.replace('$ORIGIN',str(real.parent)).split(':')
 for name in re.findall(r'\(NEEDED\).*\[(.*?)\]',raw):
  chosen=None
  for parent in ['/opt/fltk-vr/toolkit/lib','/opt/fltk-vr/bdf-runtime/lib',*rpaths,'/usr/lib64','/lib64']:
   q=Path(parent)/name
   if q.is_file():chosen=q;break
  if chosen is None and name in cache:chosen=Path(cache[name])
  assert chosen,name;resolution.append({'from':str(real),'needed':name,'literal':str(chosen),'resolved':str(chosen.resolve()),'sha256':sha(chosen)});pending.append(chosen)
 raw=subprocess.check_output(['/usr/bin/readelf','-l',str(real)],text=True);m=re.search(r'Requesting program interpreter: (.*?)\]',raw)
 if m:pending.append(Path(m[1]))
old=A/'hdr-provenance-resume-20261126/native-release-legacy-v1/legacy2048/selected-target-resolution.dsculpt';historical=A/'hdr-legacy-fixture-check-20261126/hdr-legacy/scene43-full-context.dsculpt'
for f in [old,historical]:pins[str(f)]=sha(f)
def c(name,args,checks,produces=(),consumes=(),**extra):return {'name':name,'command':list(map(str,args)),'checks':checks,'timeout':900,'RSS_limit_bytes':4*1024**3,'produces':list(map(str,produces)),'consumes_generated':list(map(str,consumes)),**extra}
joint=D/'dome-sculpt-source-joint-writable-normal-bake-test';seed=N/'current512/000.dsculpt';full=N/'current2048/000.dsculpt';cases=[c('projection11',[D/'dome-sculpt-normal-projection-sharing-test',N/'projection'],11),c('worker22',[D/'dome-sculpt-source-retained-emission-worker-test',old],22),c('current2048',[joint,'--checked-case','000','2048',N/'current2048'],47409,[full,N/'current2048/selected-target-resolution.dsculpt']),c('current512',[joint,'--checked-case','000','512',N/'current512'],47409,[seed]),c('owner24',[D/'dome-sculpt-source-owning-hdr-domain-test',seed,N/'owner'],24,[],[seed]),c('export16400',[D/'dome-sculpt-source-owning-hdr-export-test',seed,N/'export'],16400,[],[seed]),c('recipe20',[D/'dome-sculpt-texture-set-bake-recipe-test',N/'recipe'],20),c('closure22',[D/'dome-sculpt-source-hdr-provenance-closure-test',old,historical,N/'closure'],22),c('current-is-not-historical',[D/'dome-sculpt-source-hdr-provenance-closure-test',old,seed,N/'not-historical'],None,[],[seed],expected_exit=1,expected_text='a current source-only seed is not historical proof'),c('differential576',[D/'dome-sculpt-color-projection-channel-reuse-test',full],576,[],[full],expected_text='ACTUAL_NATIVE_RECEIPT exact=1 cells=5934012 width=2048 height=2048')]
p={'scope':'Fresh owning current0cdd+channel optimization0813 App/core with original full2048 and512 workflows, unchanged dense oracle, source ownership/history/orderedSave/native export/recipe/authentic legacy replay and independent frozen-reference differential. All native correctness only; Appversion/loader/privategraphics remain separate. Original725strictgroups/failures remain separate.','source':P['source'],'named_parent':P['named_parent'],'pins':pins,'dynamic_resolution':resolution,'cwd':str(O),'cpu_only_no_graphics_lease':True,'strict':False,'environment':{'PATH':'/usr/bin:/bin','LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','LP_NUM_THREADS':'2','MALLOC_ARENA_MAX':'2','MALLOC_MMAP_THRESHOLD_':'131072'},'cases':cases,'prepared':time.time()};(N/'plan.json').write_text(json.dumps(p,indent=2)+'\n');print('owning nativeprepared',p['source'],'cases',len(cases),'pins',len(pins),'ELFproviders',len(scanned))
