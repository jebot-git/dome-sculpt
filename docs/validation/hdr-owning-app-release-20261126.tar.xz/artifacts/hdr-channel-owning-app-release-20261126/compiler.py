import sys,pathlib,os,time,json,hashlib,subprocess,signal
O=pathlib.Path(__file__).resolve().parent;cmd=sys.argv[1:];cwd=pathlib.Path.cwd()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
obj=pathlib.Path(cmd[cmd.index('-o')+1]);obj=obj if obj.is_absolute() else cwd/obj
if '-MF' not in cmd:cmd+=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
md=pathlib.Path(cmd[cmd.index('-MF')+1]);md=md if md.is_absolute() else cwd/md
key=hashlib.sha256(('\0'.join(cmd)).encode()).hexdigest();D=O/'compiler-records';D.mkdir(exist_ok=True);r={'command':cmd,'cwd':str(cwd),'started':time.time(),'object':str(obj),'depfile':str(md),'timeout_seconds':900}
with (D/(key+'.log')).open('w') as f:
 p=subprocess.Popen(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True);r['pid']=p.pid
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  r['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
r.update(exit=code,seconds=time.time()-r['started'])
for file,label in [(obj,'object'),(md,'depfile')]:
 if file.is_file():r[label+'_sha256']=sha(file)
(D/(key+'.json')).write_text(json.dumps(r,indent=2)+'\n')
if code:print((D/(key+'.log')).read_text(),file=sys.stderr)
raise SystemExit(code)
