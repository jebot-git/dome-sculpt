from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

here = Path(__file__).resolve().parent
open_release = here.parent / 'stream-native-open-release-20261126'
release = here.parent / 'production-hdr-combined-release-20261126'
baseline_source = here.parent / 'stream-native-open-source-20261126'
variant_source = here.parent / 'serialize-sculpt-objects-source-20261126'
profile = sys.argv[1]
assert profile in ('baseline', 'variant')
out = here / f'profile-{profile}'
out.mkdir()
base = profile == 'baseline'
source = baseline_source if base else variant_source
build = release if base else here
archive = (open_release if base else here) / 'libdome-sculpt-core.a'
assert archive.exists()
obj = out / 'save-peak.o'
exe = out / 'save-peak'
compile = ['/usr/bin/c++', '-std=c++20', '-O3', '-DNDEBUG', '-MD', '-MF', str(obj) + '.d',
           '-I' + str(source / 'include'), '-I' + str(source / 'third_party/nlohmann'),
           '-I' + str(source / 'third_party/openbrush'), '-c', str(here / 'save-peak.cpp'), '-o', str(obj)]
link_template = json.loads((open_release / 'build-plan.json').read_text())['links'][0]['argv']
link = []
for arg in link_template:
    if arg.startswith('-Wl,--dependency-file='):
        arg = f'-Wl,--dependency-file={out}/save-peak.link.d'
    elif arg.endswith('/scene-file.cpp.o'):
        arg = str(obj)
    elif arg.endswith('/dome-sculpt-scene-file-test'):
        arg = str(exe)
    elif arg.endswith('/libdome-sculpt-core.a'):
        arg = str(archive)
    link.append(arg)
plan = {'cwd': str(build), 'compile': compile, 'link': link}
(out / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
subprocess.run(compile, cwd=build, check=True)
subprocess.run(link, cwd=build, check=True)

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

env = {k: v for k, v in os.environ.items()
       if k not in {'GLIBC_TUNABLES', 'MALLOC_ARENA_MAX', 'MALLOC_MMAP_THRESHOLD_'}}
cases = []
for test in ('sculpt', 'hdr2048'):
    input_file = open_release / f'{test}-baseline.dsculpt'
    output_file = out / f'{test}.dsculpt'
    result = subprocess.run([str(exe), str(input_file), str(output_file)], env=env, cwd=out,
                            timeout=300, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (out / f'{test}.log').write_text(result.stdout)
    actual_sha = sha(input_file)
    assert result.returncode == 0 and sha(output_file) == actual_sha, result.stdout
    fields = {k: int(v) for k, v in re.findall(r'(SAVE_\w+_KIB) (\d+)', result.stdout)}
    assert fields.keys() == {'SAVE_START_KIB', 'SAVE_PEAK_KIB'}
    cases.append({'project': test, 'bytes': input_file.stat().st_size,
                  'input_output_sha256': actual_sha, **fields})
record = {'profile': profile, 'exe_sha256': sha(exe), 'archive_sha256': sha(archive), 'cases': cases,
          'scope': 'Same probe and native Open implementation. Trim free glibc arenas and reset kernel VmHWM once, before real Scene::save. Native output must match the project bytes.'}
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)
