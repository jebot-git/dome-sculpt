from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET

here = Path(__file__).resolve().parent
root = here.parent.parent
out = root / 'docs/validation/native-save-one-volume-20261126.tar.xz'
def json_at(path):
    return json.loads((here/path).read_text())
def sha(file):
    return hashlib.file_digest(file, 'sha256').hexdigest()
def pins(names):
    return [here / n for n in names.split()]

status = json_at('validation/status.json')
build = json_at('build-status.json')
assert build['terminal'] and build['exit'] == 0 and status['terminal']
assert status['native_exit'] == status['save_peak_exit'] == 0
assert status['workflows']['owning-hdr-export']['exit'] == 0
assert status['workflows']['owning-hdr-export']['reported_expected']
xml = ET.parse(here / 'validation/native.xml').getroot()
assert all(xml.get(k) == v for k,v in {'tests':'3', 'failures':'0', 'skipped':'0'}.items())
baseline = json_at('profile-baseline/result.json')
candidate = json_at('profile-variant/result.json')
comparison = {}
for old, new in zip(baseline['cases'], candidate['cases'], strict=True):
    assert old['project'] == new['project'] and old['input_output_sha256'] == new['input_output_sha256']
    comparison[old['project']] = dict(peak_reduction_kib=old['SAVE_PEAK_KIB'] - new['SAVE_PEAK_KIB'],
        baseline_peak_kib=old['SAVE_PEAK_KIB'], candidate_peak_kib=new['SAVE_PEAK_KIB'])
units = {'build': 'ds-serialize-sculpt-objects-release-20261126',
         'validation': 'ds-serialize-sculpt-objects-validate-20261126',
         'comparison_baseline': 'ds-serialize-sculpt-objects-save-peak-baseline-20261126'}
for key, unit in units.items():
    journal = subprocess.check_output(['journalctl', '--user', '-u', unit, '--no-pager'])
    assert journal and b'-- No entries --' not in journal
    (here / f'{key}.journal.txt').write_bytes(journal)
paths = pins('build-plan.json build-status.json build.log configure.log CMakeCache.txt compile_commands.json '
             'save-peak.cpp save-peak.py validate.py owned_monitor.py seal.py '
             'Testing/Temporary/LastTest.log validation/native.xml validation/native.log validation/save-peak.log '
             'validation/status.json validation/owning-hdr-export.log validation/sculpt-default.log '
             'CMakeFiles/dome-sculpt-core.dir/src/scene.cpp.o.d '
             'CMakeFiles/dome-sculpt-scene-file-test.dir/tests/scene-file.cpp.o.d')
for profile in ('profile-baseline','profile-variant'):
    paths += [here / profile / name for name in ('plan.json','result.json','sculpt.log','hdr2048.log',
                                                   'save-peak.o.d', 'save-peak.link.d')]
paths += [here / f'{key}.journal.txt' for key in units]
manifest = {}
with tarfile.open(out, 'w:xz', preset=6) as archive:
    for path in paths:
        name = str(path.relative_to(here))
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        assert name not in manifest
        manifest[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(out, 'r:xz') as archive:
    assert len(archive.getmembers()) == len(manifest)
    for member in archive:
        expected = manifest[member.name]
        assert member.size == expected['bytes']
        assert sha(archive.extractfile(member)) == expected['sha256']
receipt = {'scope': 'Release single-volume Save component with native file, recovery, direct HDR export and default allocator workflow. Isolated Save uses the same input bytes, loader, and glibc trim/VmHWM reset before each operation.',
           'source': build['source'], 'baseline_source': '9368689df6ad7b8b026bcaf6dd7005de0423965d',
           'build': build, 'units': units, 'actual_validation': status, 'isolated_save_comparison': comparison,
           'isolated_save_reads': [baseline, candidate],
           'authorities': manifest, 'archive': {'name':out.name, 'bytes':out.stat().st_size, 'sha256':sha(out.open('rb'))}}
out.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(comparison, receipt['archive'])
