#include "dome/scene.hpp"

#include <fstream>
#include <iostream>
#include <malloc.h>
#include <stdexcept>
#include <string>

long peak_resident_kib() {
  std::ifstream status("/proc/self/status");
  for (std::string line; std::getline(status, line);)
    if (line.starts_with("VmHWM:"))
      return std::stol(line.substr(6));
  throw std::runtime_error("Missing VmHWM");
}

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  const auto scene = dome::Scene::load(argv[1]);
  malloc_trim(0);  // Equalize released loader arenas in both save-only probes.
  {
    std::ofstream reset("/proc/self/clear_refs");
    reset.exceptions(std::ios::failbit | std::ios::badbit);
    reset << "5\n";
    reset.close();
  }
  std::cout << "SAVE_START_KIB " << peak_resident_kib() << std::endl;
  scene.save(argv[2]);
  std::cout << "SAVE_PEAK_KIB " << peak_resident_kib() << std::endl;
  return 0;
} catch (const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
