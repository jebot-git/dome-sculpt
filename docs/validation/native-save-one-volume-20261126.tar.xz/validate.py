from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import time

from owned_monitor import run

here = Path(__file__).resolve().parent
build_unit = 'ds-serialize-sculpt-objects-release-20261126.service'
expected_source = '07025cd3'
plan = json.loads((here / 'build-plan.json').read_text())
assert plan['source'].startswith(expected_source)
build_status = here / 'build-status.json'
state = {'source': plan['source'], 'build_unit': build_unit, 'build_pending': True, 'terminal': False}
out = here / 'validation'
out.mkdir()
def save_state():
    temporary = out / 'status.tmp'
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(out / 'status.json')

def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

save_state()
try:
    while True:
        build = json.loads(build_status.read_text())
        assert build['source'] == plan['source']
        if build['terminal']:
            assert build['exit'] == 0
            break
        live = subprocess.check_output(['systemctl', '--user', 'is-active', build_unit], text=True)
        assert live.strip() == 'active'
        time.sleep(2)
    state['build_pending'] = False
    save_state()
    env = {k: v for k, v in os.environ.items() if k not in
           {'GLIBC_TUNABLES', 'MALLOC_ARENA_MAX', 'MALLOC_MMAP_THRESHOLD_'}}
    tests = ['ctest', '--output-on-failure', '--output-junit', str(out/'native.xml'),
             '-R', '^(scene-file|document-recovery|atomic-write-allocation)$']
    with (out / 'native.log').open('w') as log:
        status = subprocess.run(tests, env=env, cwd=here, stdout=log, stderr=subprocess.STDOUT, timeout=220)
    state['native_exit'] = status.returncode
    save_state()
    with (out / 'save-peak.log').open('w') as log:
        profile = subprocess.run(['/usr/bin/python3', str(here/'save-peak.py'), 'variant'], env=env,
                                 cwd=here, stdout=log, stderr=subprocess.STDOUT, timeout=620)
    state['save_peak_exit'] = profile.returncode
    save_state()
    hdr_fixture = here.parent / ('production-hdr-combined-release-20261126/'
                                 'source-joint-writable-normal-bake-checked/000.dsculpt')
    tests = [('owning-hdr-export', here/'dome-sculpt-source-owning-hdr-export-test',
              [str(hdr_fixture), str(out/'hdr-export')], r'16400', 900, 4*1024**3),
             ('sculpt-default', here/'dome-sculpt-sculpt-independent-workflow',
              [str(out/'sculpt')], r'^PASS independent production sculpt workflow checks=167',
              900, 4*1024**3)]
    state['workflows'] = {}
    for name, elf, args, pattern, timeout, limit in tests:
        log = out / f'{name}.log'
        sha = digest(elf)
        row = run([str(elf), *args], cwd=here, env=env, log=log, timeout=timeout, max_rss=limit)
        row.update({'elf_sha256': sha, 'reported_expected': bool(re.search(pattern, log.read_text(), re.M))})
        state['workflows'][name] = row
        save_state()
    state['exit'] = int(any((state['native_exit'], state['save_peak_exit'],
                            any(row['exit'] != 0 or not row['reported_expected'] or 'error' in row
                                for row in state['workflows'].values()))))
except BaseException as error:
    state.update(exit=1, error=repr(error))
finally:
    state['terminal'] = True
    save_state()
raise SystemExit(state['exit'])
