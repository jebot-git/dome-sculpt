from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[2]
dest=repo/"docs/validation"
name="native-texture-set-hdr-standard-20261127"
commit=subprocess.check_output(["git","-C",repo,"rev-parse",sys.argv[1]],text=True).strip()
assert subprocess.check_output(["git","-C",repo,"show","--format=","--binary",commit])==(root/"standard-only.patch").read_bytes()
files={}
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
def keep(file):
    files[file]=root/file
    return sha(root/file)
def read(file):
    return json.loads((root/file).read_text())

report={"product":commit,"source_patch_sha256":keep("standard-only.patch"),"profiles":{},"frontends":{},"khronos":{},
        "scope":"Standard HDR package6 with exact per-material OpenEXR fields for plain and retained PBR texture sets. Actual membership and paint coordinates, mixed standalone HDR, exact native reopen, and rehashed record refusal."}
for file in ("source.patch","record.py","run-v1.py","run.py","checks-final.py","standard.cpp",
             "registered-release.log","registered-ctest.json","public-focus-final.py","xr-public-final.py","wayland.py","xr-focus.py"):
    keep(file)
packages=("probe/standard.glb","checks/plain/standard-texture-set-hdr.glb",
          "checks/retained/standard-retained-hdr.glb","checks/plain/mixed-standard-hdr.glb")
expected={}
for mode in ("release-final","asan-final"):
    prefix=mode+"/"
    run=read(prefix+"status.json")
    checks=read(prefix+"checks/status.json")
    assert run["terminal"] and run["exit"]==0 and checks["terminal"] and checks["exit"]==0
    assert run["diff_sha256"]==sha(root/"standard-only.patch")
    for log,text in (
        ("standard.log","Standard reopens exact native Scene"),
        ("checks/plain.log","PASS 90 texture-set multi-primitive export controls"),
        ("checks/retained.log","PASS 50 retained Standard HDR controls"),
        ("checks/editable.log","PASS 44 retained Editable HDR controls"),
        ("checks/retained-legacy.log","PASS 6074 actual retained standard source export controls"),
        ("checks/native-authoring.log","Native authoring package: 28 checks"),
        ("checks/legacy-budget.log","Native HDR aggregate field budget: 4 checks"),
        ("checks/legacy-emission.log","Native HDR export: 32 checks"),
    ):
        assert text in (root/(prefix+log)).read_text()
        keep(prefix+log)
    negatives=(root/(prefix+"checks/retained.log")).read_text()
    for line in ("differs from its emitted primitive or coordinate","FLOAT coefficients differ",
                 "omitted a visible physical material"):
        assert line in negatives
    assert "HDR member differs from the current native scene" in (root/(prefix+"checks/plain.log")).read_text()
    for log in ("status.json","checks/status.json","archive.log","dome-sculpt-link.log",
                "emission-export.cpp.log","standard-link.log"):
        keep(prefix+log)
    for file in packages:
        digest=sha(root/(prefix+file))
        if mode=="release-final":expected[file]=digest
        else:assert digest==expected[file]
    legacy=root.parent/("release-v2" if mode=="release-final" else "asan-v2")/"checks/retained/editable-retained-hdr.glb"
    assert sha(root/(prefix+"checks/editable/editable-retained-hdr.glb"))==sha(legacy)
    report["profiles"][mode]={"app_sha256":run["app_sha256"],"checks":{"plain":90,"retained_standard":50,
        "retained_editable":44,"retained_legacy":6074,"native_authoring":28,"dense_exr_budget":4,
        "legacy_hdr":32},"files_sha256":dict(expected)}
for mode in ("wayland","software","arc"):
    folder=f"{mode}-focus-texture-set-hdr-standard-final/"
    run=read(folder+"status.json")
    assert run["terminal"] and run["exit"]==0 and run["checks"]==(7 if mode=="wayland" else 10)
    assert run["native_sha256"]==expected[packages[0]]
    for log in ("status.json","run.log","workflow/report.json"):
        keep(folder+log)
    if mode=="wayland":
        for log in ("runtime-maps.txt","client.log","compositor.log"):
            keep(folder+"workflow/"+log)
    else:
        for step in ("accept","focus"):
            for log in ("application.log","graphics.json"):
                keep(folder+f"workflow/{step}/{log}")
    report["frontends"][mode]=run
for file,warnings in zip(packages,(0,1,0,1)):
    result="release-final/"+file+".khronos.json"
    issues=read(result)["issues"]
    assert issues["numErrors"]==0 and issues["numWarnings"]==warnings
    report["khronos"][file]={"errors":0,"warnings":warnings,"report_sha256":keep(result)}
report["open"]="Typed MToon texture sets, alternate source emission coordinates, texture-set VRM export, full integrated regression, and physical headset verification remain open."
archive=dest/(name+".tar.gz")
with archive.open("wb") as raw,gzip.GzipFile(filename="",mode="wb",fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode="w") as tar:
    for filename,path in sorted(files.items()):
        payload=path.read_bytes()
        item=tarfile.TarInfo(filename)
        item.size=len(payload)
        tar.addfile(item,io.BytesIO(payload))
report["archive"]={"file":archive.name,"sha256":sha(archive),"members":len(files)}
(dest/(name+".json")).write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
print(commit,report["archive"])
