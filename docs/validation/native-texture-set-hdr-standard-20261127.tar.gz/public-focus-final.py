from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

out=Path(__file__).resolve().parent
art=out.parents[1]
mode=sys.argv[1]
method='texture-set-hdr-standard-final'
arc=mode=='arc'
profile='asan' if arc else 'release'
prior=out/(profile+'-final')
sdk=art/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
evidence={'mode':mode,'invocation':os.getenv('INVOCATION_ID')}
stage=out/(mode+'-focus-'+method)
stage.mkdir(exist_ok=True)
def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(**fields):
    evidence.update(fields)
    (stage/'status.json').write_text(json.dumps(evidence,indent=2)+'\n')
try:
    receipt=json.loads((prior/'status.json').read_text())
    assert receipt['exit']==0
    fixture=art/'hdr-editable-2048-20261127/texture-set-probe/visible-hdr-output/visible-retained-hdr.dsculpt'
    app=prior/'dome-sculpt'
    assert sha(app)==receipt['app_sha256']
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
         'LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1',
         'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
         'DOME_RECIPIENT_EXPECTED':str(prior/'probe/standard.glb'),
}
    if arc:
        node='/dev/dri/renderD129'
        prefix.extend(['--dev-bind',node,node])
        env.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
                   ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                   UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    if mode=='wayland':
        public=art/'creator-public-build-20261126'
        comp=public/'wayland-reference/dome-compositor'
        comp_proof=json.loads((comp.parent/'compositor-build-status.json').read_text())
        assert comp_proof['exit']==0 and comp_proof['source']=='acc2b70ae61dedec2a23727f67c60c0303d0f76f' and sha(comp)==comp_proof['output_sha256']
        probe=art/'combined-atlas-hdr-preview-full-20261126/build/libdome-sculpt-test-widgets.so'
        env.update(PATH=str(public/'private-bin-v3')+':/usr/bin',PYTHONPATH=str(public/'private-python'),
                   PYTHONDONTWRITEBYTECODE='1',DOME_COMPOSITOR=str(comp),
                   DOME_AFFINE_PATCH=str(fixture),DOME_CAGE_APP=str(app),DOME_CAGE_PROBE=str(probe),
                   DOME_CAGE_WL_OUT=str(stage/'workflow'),
                   LD_LIBRARY_PATH=f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:{public}/private-x11/usr/lib64:/usr/lib64')
        command=['/usr/bin/python3.14',out/'wayland.py']
        write(compositor_sha256=sha(comp),compositor_source=comp_proof['source'],probe_sha256=sha(probe))
    for k,v in env.items():prefix.extend(['--setenv',k,v])
    write(phase='run through desktop or OpenXR frontend',app_sha256=sha(app),
          input_sha256=sha(fixture),run_script_sha256=sha(command[1]))
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock,(stage/'run.log').open('w') as log:
        if arc or mode=='wayland':fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,[*prefix,*command])),file=log,flush=True)
        subprocess.run([*prefix,*command],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=540)
    report=stage/'workflow/report.json'
    checks=json.loads(report.read_text())['checks']
    assert len(checks)==7 and all(row['passed'] for row in checks),checks
    native=stage/'workflow/standard.glb'
    write(phase='complete',terminal=True,exit=0,checks=len(checks),report_sha256=sha(report),native_sha256=sha(native))
except BaseException as error:
    write(terminal=True,exit=1,error=repr(error))
    raise
