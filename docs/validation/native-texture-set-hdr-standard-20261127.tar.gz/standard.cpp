#include "dome/document.hpp"
#include "dome/emission-native.hpp"
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
#include <nlohmann/json.hpp>
int main(int argc, char **argv) try {
  using namespace dome;
  if(argc!=3)throw std::invalid_argument("Usage: editable input directory");
  const std::filesystem::path input=argv[1],dir=argv[2];
  std::filesystem::create_directories(dir);
  Document doc;
  doc.open(input);
  if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
    throw std::runtime_error(doc.frame().state->error);
  const auto file=dir/"standard.glb";
  doc.export_asset(file,AssetExportFormat::Glb).get();
  std::cout<<"Standard wrote "<<std::filesystem::file_size(file)<<" bytes"<<std::endl;
  std::ifstream stream(file,std::ios::binary);
  const std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(stream)),{});
  const auto restored=extract_native_emission(bytes);
  if(!restored||restored->encode()!=Scene::load(input).encode())
    throw std::runtime_error("Standard GLB changed native authoring data");
  std::cout<<"Standard reopens exact native Scene"<<std::endl;
  return 0;
} catch(const std::exception &e) {
  std::cerr<<"Standard failure: "<<e.what()<<std::endl;
  return 1;
}
