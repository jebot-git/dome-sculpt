from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
profile=sys.argv[1]
src=root/"source"
out=root/(profile+"-final")
art=root.parents[1]
work=out/"checks"
work.mkdir(exist_ok=True)
old=art/"native-hdr-compact-20261126"/profile/"build"
shared=art/"native-shared-bake-20261127"/profile
stream=art/"hdr-portable-streaming-20261127"/profile
sdk=art/"sdk-20261126/toolkit-sanitize" if profile=="asan" else Path("/opt/fltk-vr/toolkit")
env=dict(os.environ, LD_LIBRARY_PATH=f"{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64",
    ASAN_OPTIONS="detect_leaks=1:halt_on_error=1",UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1",
    LIBGL_ALWAYS_SOFTWARE="1", LP_NUM_THREADS="2", EGL_PLATFORM="surfaceless")
invocation=os.environ.get("INVOCATION_ID")
names={
    "dome-sculpt-texture-set-export-test":"texture-set-export.cpp",
    "dome-sculpt-texture-set-source-export-test":"texture-set-source-export.cpp",
    "dome-sculpt-native-authoring-test":"native-authoring.cpp",
    "dome-sculpt-emission-package-budget-test":"emission-package-budget.cpp",
    "dome-sculpt-emission-export-test":"emission-export.cpp",
}
def run(args,filename):
    with (work/filename).open("w") as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        subprocess.run(args,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=720)
def record(**values):
    (work/"status.json").write_text(json.dumps({"invocation":invocation,**values},indent=2)+"\n")
try:
    assert (out/"libdome-sculpt-core.a").is_file()
    db=json.loads((shared/"build/compile_commands.json").read_text())
    shared_src=art/"native-shared-bake-20261127/source"
    def build(target):
        if target=="preset":
            owner="dome-sculpt-emission-export-test"
            filename="emission-export.cpp"
        else:
            owner=target
            filename=names[target]
        row=next(c for c in db if f"/{owner}.dir/" in c["output"] and Path(c["file"]).name==filename)
        command=shlex.split(row["command"].replace(str(shared_src),str(src)))
        if target=="preset":
            command[-1]=str(root/"preset.cpp")
        obj=work/(target+".o")
        command[command.index("-o")+1]=str(obj)
        run(command,target+"-compile.log")
        args=shlex.split(subprocess.check_output(["ninja","-t","commands",owner],cwd=old,text=True).splitlines()[-1])[2:-2]
        result=[]
        for word in args:
            if word.startswith("-Wl,--dependency-file"):continue
            if f"{owner}.dir/" in word and word.endswith(".o"):word=str(obj)
            elif word=="libdome-sculpt-core.a":word=str(out/word)
            elif word=="libdome-sculpt-emission-codec.a":word=str(stream/word)
            elif not word.startswith("/") and word.endswith((".a",".o")):word=str(old/word)
            result.append(word)
        exe=work/target
        result[result.index("-o")+1]=str(exe)
        run(result,target+"-link.log")

    registry=list(names)
    record(phase="build validation fixtures",targets=registry)
    with ThreadPoolExecutor(max_workers=2) as tasks:list(tasks.map(build,registry))
    record(phase="run selected native texture-set tests",targets=registry)
    plain,retained,legacy,budget,emission=registry
    run([work/plain,work/"plain"],"plain.log")
    run([work/retained,"--retained-hdr-standard",work/"retained"],"retained.log")
    run([work/retained,"--retained-hdr-editable",work/"editable"],"editable.log")
    run([work/retained,work/"legacy"],"retained-legacy.log")
    run([work/legacy,work/"native-authoring"],"native-authoring.log")
    run([work/budget,work/"legacy-budget"],"legacy-budget.log")
    run([work/emission,work/"legacy-emission"],"legacy-emission.log")
    record(phase="complete",exit=0,terminal=True,tests=registry)
except BaseException as error:
    record(phase="failed",exit=1,terminal=True,error=repr(error))
    raise
