from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
out = root/'combined-release'
out.mkdir(exist_ok=True)
source = root/'source'
base = root.parent/'retopo-save-queue-20261127'
base_src,base_build = base/'source',base/'build'
build = out/'build'
revision = '662d889da2b3a56e36f2f58f5280a624ae798906'
sdk = '/opt/fltk-vr/toolkit'
bitmap = '/opt/fltk-vr/bdf-runtime'
start = time.monotonic()
state = {'candidate':revision,'terminal':False,'invocation':os.environ.get('INVOCATION_ID')}

def record(**fields):
    state.update(fields,elapsed_seconds=round(time.monotonic()-start,3))
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def git(src,*args):
    return subprocess.check_output(['git','-C',src,*args])

def run(args,log,timeout,check=True):
    with (out/log).open('w') as f:
        return subprocess.run(args,cwd=out,stdout=f,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check).returncode

try:
    prior=json.loads((base/'status.json').read_text())
    assert prior['terminal'] and prior['candidate'].startswith('f70483e9')
    assert sha(base_build/'CMakeCache.txt')==prior['cache_sha256']
    assert '[1780/1780]' in (base/'build.log').read_text()
    assert git(base_src,'status','--porcelain')==git(source,'status','--porcelain')==b''
    assert git(source,'rev-parse','HEAD').decode().strip()==revision
    assert git(base_src,'rev-parse','HEAD').decode().strip()==prior['candidate']
    old_app=sha(base_build/'dome-sculpt')
    old_cache=sha(base_build/'CMakeCache.txt')
    names={test['name'] for test in json.loads((base/'registered.json').read_text())['tests']}
    assert 'dome-sculpt-texture-set-export' in names and 'texture-set-export' not in names
    record(phase='reflink the completed Release build',seed_revision=prior['candidate'],
           seed_app_sha256=old_app,seed_cache_sha256=old_cache,
           seed_registration_error='texture-set-export was renamed dome-sculpt-texture-set-export')
    assert not build.exists()
    run(['cp','--archive','--reflink=always',base_build,build],'reflink.log',360)
    assert sha(build/'dome-sculpt')==old_app and sha(build/'CMakeCache.txt')==old_cache
    changed={os.fsdecode(p) for p in git(source,'diff','--name-only','-z',
                                       prior['candidate'],revision).split(b'\0') if p}
    files={os.fsdecode(p) for p in git(source,'ls-files','-z').split(b'\0') if p}
    assert {'src/render-paint-overlay.hpp','src/texture-set-export.cpp','CMakeLists.txt'}<=changed
    for name in sorted(files):
        path=source/name
        if not path.is_file() or path.is_symlink():
            continue
        if name in changed:
            os.utime(path)
        else:
            old=base_src/name
            metadata=old.stat()
            os.utime(path,ns=(metadata.st_atime_ns,metadata.st_mtime_ns))
    assert git(source,'status','--porcelain')==b''
    settings={'PATH':'/usr/bin:/bin','PKG_CONFIG_PATH':bitmap+'/lib/pkgconfig:/usr/lib64/pkgconfig',
              'LD_LIBRARY_PATH':f'{sdk}/lib:{bitmap}/lib:/usr/lib64','LIBGL_ALWAYS_SOFTWARE':'1',
              'LP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2'}
    for key,name in [('HOME','home'),('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),
                    ('XDG_DATA_HOME','data'),('XDG_RUNTIME_DIR','runtime'),('XDG_STATE_HOME','state')]:
        path=out/'private'/name
        path.mkdir(parents=True,mode=0o700,exist_ok=True)
        settings[key]=str(path)
    # Keep logical CMake paths identical inside the isolated namespace. The
    # seed source and build remain untouched outside these private mounts.
    command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
             '--bind',out,out,'--ro-bind',source,base_src,'--bind',build,base_build,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user',
             '--clearenv']
    for key,value in settings.items():
        command.extend(['--setenv',key,value])
    opts=['cmake','-S',base_src,'-B',base_build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
          f'-DFLTK_DIR={sdk}/share/fltk','-DDOME_COMPUTE_BACKEND=CPU']
    record(phase='configure latest Release with the canonical DomeD toolkit',changed_paths=sorted(changed))
    run([*command,*opts],'configure.log',240)
    record(phase='build the latest Release candidate')
    run([*command,'cmake','--build',base_build,'--parallel','4'],'build.log',7200)
    log=(out/'build.log').read_text()
    assert all(name in log for name in ('texture-set-export.cpp.o','render.cpp.o','bake-authoring.cpp.o'))
    app=sha(build/'dome-sculpt')
    assert app!=old_app and sha(base_build/'dome-sculpt')==old_app
    assert sha(base_build/'CMakeCache.txt')==old_cache and git(source,'status','--porcelain')==b''
    raw=subprocess.check_output([*command,'ctest','--test-dir',base_build,'--show-only=json-v1'],cwd=out)
    (out/'registered.json').write_bytes(raw)
    enrolled=json.loads(raw)['tests']
    names={case['name'] for case in enrolled}
    assert len(names)==len(enrolled) and all(case.get('command') for case in enrolled)
    required={'mtoon-baked-texture-sets','mtoon-texture-set-bake-openxr',
              'dome-sculpt-texture-set-export','retopology-save-handoff',
              'native-mtoon-physical','renderer-recovery','creator-shaped-vrm'}
    if not required<=names:
        raise RuntimeError(f'Missing CTest commands: {sorted(required-names)}')
    record(phase='run every registered Release test',registered=len(names),app_sha256=app,
           cache_sha256=sha(build/'CMakeCache.txt'))
    junit=out/'full.xml'
    status=run([*command,'ctest','--test-dir',base_build,'-j4','--output-on-failure',
                '--output-junit',junit],'ctest.log',14400,check=False)
    cases=ET.parse(junit).getroot().findall('.//testcase')
    assert {case.attrib['name'] for case in cases}==names and len(cases)==len(names)
    failed=sorted(c.attrib['name'] for c in cases if c.find('failure') is not None)
    skipped=sorted(c.attrib['name'] for c in cases if c.find('skipped') is not None)
    assert sha(build/'dome-sculpt')==app and sha(base_build/'dome-sculpt')==old_app
    assert git(source,'rev-parse','HEAD').decode().strip()==revision and git(source,'status','--porcelain')==b''
    record(phase='complete',terminal=True,exit=status,
           totals={'pass':len(cases)-len(failed)-len(skipped),'fail':len(failed),'skip':len(skipped)},
           failed=failed,skipped=skipped,junit_sha256=sha(junit))
except Exception as e:
    record(terminal=True,exit=1,error=repr(e))
    raise
raise SystemExit(state['exit'])
