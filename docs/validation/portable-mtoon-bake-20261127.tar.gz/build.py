from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys

recipe = Path(__file__).resolve().parents[1] / "texture-set-retained-production-20261127/admit.py"
shared_driver = recipe.read_text().split("\nchanged=")[0]
shared_driver = shared_driver.replace('elif word==codec.name:',
    'elif word=="libdome-sculpt-render.a":word=str(renderer/word)\n        elif word==codec.name:')
shared_driver = shared_driver.replace('and f"{target}.dir/" in word',
    'and f"/{target}.dir/" in "/"+word')
exec(shared_driver)
prior = artifacts / "native-mtoon-bake-20261127" / (profile+"-admit")
renderer = artifacts / "exact-overlay-gpu-budget-20261127" / (profile+"-admit")
mode = sys.argv[2]
if mode in {"product","refresh"}:
    files = ("texture-set-export.cpp","export.cpp")
    if mode == "refresh":
        files = tuple(sys.argv[3:])
    with ThreadPoolExecutor(max_workers=2) as parallel:
        changed = list(parallel.map(compile_object,files))
    if mode == "product":
        shutil.copyfile(prior/core.name,core)
    run(["ar","rs",core,*changed],"archive-"+mode)
    assert subprocess.check_output(["ar","t",core]) == subprocess.check_output(["ar","t",prior/core.name])
    assert all(subprocess.check_output(["ar","p",core,obj.name]) == obj.read_bytes() for obj in changed)
    args = shlex.split((prior/"app-link.log").read_text().splitlines()[0])
    args = [str(core) if Path(word).name==core.name else
            str(renderer/word.split("/")[-1]) if Path(word).name=="libdome-sculpt-render.a"
            else word for word in args]
    args[args.index("-o")+1] = str(out/"dome-sculpt")
    run(args,"app-link")
    run([out/"dome-sculpt","--version"],"version")
else:
    target,filename = {
        "xr-helper":("dome-sculpt-bake-recipes-test","bake-recipes.cpp"),
        "graphics":("dome-sculpt-mtoon-render-test","mtoon-render.cpp"),
        "portable":("dome-sculpt-texture-set-export-test","texture-set-export.cpp"),
        "recipe":("dome-sculpt-texture-set-bake-recipe-test","texture-set-bake-recipe.cpp"),
        "source-export":("dome-sculpt-texture-set-source-export-test","texture-set-source-export.cpp")
    }[mode]
    if mode=="graphics":
        gfx=out/"mtoon-render-fixture.cpp.o"
        row=next(row for row in entries if f"/{target}.dir/" in row["output"] and Path(row["file"]).name==filename)
        args=shlex.split(row["command"].replace(str(parent),str(source)))
        args[args.index("-o")+1]=str(gfx)
        run(args,"graphics-compile")
        binary=link(target,gfx)
        if "--compile-only" not in sys.argv:
            run([binary,"--baked-texture-sets",out/"graphics"],"graphics")
    else:
        binary=link(target,compile_object(filename,target))
        if mode != "xr-helper":
            run([binary,out/mode],mode)
