const fs = require('fs'), path = require('path');
const root = __dirname;
const validator = require(path.join(root,'../hdr-khronos-validation-20261126/module/package'));
(async () => {
  const reports = [];
  for (const name of ['ldr','varying-ldr','full-ldr','gain','hdr']) {
    for (const format of (['gain','hdr'].includes(name) ? ['editable'] : ['standard','editable'])) {
      const label = name + '/' + format + '.glb';
      const bytes = fs.readFileSync(path.join(root,'release-admit','graphics',label));
      const report = await validator.validateBytes(bytes,{uri:label,maxIssues:10000});
      reports.push({label,report});
      console.log(label, report.issues.numErrors, 'errors',report.issues.numWarnings,'warnings');
    }
  }
  fs.writeFileSync(path.join(root,'khronos.json'), JSON.stringify({version:validator.version(),reports},null,2)+'\n');
  if (reports.some(({report})=>report.issues.numErrors || report.issues.numWarnings)) process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
