from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys

stage=Path(__file__).resolve().parent
artifacts=stage.parent
project=artifacts/"xr-voxel-undo-ready-source-20261126"
build=artifacts/"vrm-consumer-combined-asan-20261126"
source=project/"tests/xr_runtime.cpp"
out=stage/sys.argv[1]
out.mkdir(mode=0o700)
entry=next(x for x in json.loads((build/"compile_commands.json").read_text())
           if x["file"].endswith("/tests/xr_runtime.cpp"))
old=str(Path(entry["file"]).parents[1])
obj=out/"runtime.o"
c=[x.replace(old,str(project)) for x in shlex.split(entry["command"])]
c[c.index("-o")+1]=str(obj)
with (out/"compile.log").open("w") as log:
    log.write(shlex.join(c)+"\n")
    log.flush()
    subprocess.run(c,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
target="libdome-sculpt-test-runtime.so"
raw=subprocess.check_output(["ninja","-C",build,"-t","commands",target],text=True).splitlines()[-1]
link=[x for x in shlex.split(raw)[2:-2] if not x.startswith("-Wl,--dependency-file=")]
link[link.index("-o")+1]=str(out/target)
link[next(i for i,x in enumerate(link) if x.endswith("/xr_runtime.cpp.o"))]=str(obj)
with (out/"link.log").open("w") as log:
    log.write(shlex.join(link)+"\n")
    log.flush()
    subprocess.run(link,cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
app=build/"dome-sculpt"
manifest=out/"runtime.json"
manifest.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{"library_path":str(out/target)}}))
node="/dev/dri/renderD129"
lib=str(artifacts/"sdk-20261126/toolkit-sanitize/lib")+":/opt/fltk-vr/bdf-runtime/lib:/usr/lib64"
env={"PATH":"/usr/bin:/bin","HOME":str(out),"LD_LIBRARY_PATH":lib,
     "DRI_PRIME":"pci-0000_03_00_0","MESA_SHADER_CACHE_DISABLE":"1",
     "ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1","UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1",
     "XR_RUNTIME_JSON":str(manifest),"DOME_XR_FIXTURE_VOXEL":"undo","DOME_XR_FIXTURE_REPORT":str(out/"replay.json")}
args=["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/","--bind",out,out,
      "--proc","/proc","--dev","/dev","--dev-bind",node,node,"--tmpfs","/tmp","--tmpfs","/run/user","--clearenv"]
for k,v in env.items():
    args.extend(["--setenv",k,v])
args.extend([app,"--xr","--save",out/"voxel-undo.dsculpt"])
with open("/tmp/dome-sculpt-arc-device.lock","rb") as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    with (out/"run.log").open("w") as log:
        log.write(shlex.join(map(str,args))+"\n")
        log.flush()
        code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=55).returncode
def project_info(data):
    return json.loads(subprocess.check_output([app,"--project-info",data],env={"LD_LIBRARY_PATH":lib}))
old=artifacts/"vrm-consumer-asan-arc-xr-20261126/workflow/baseline.dsculpt"
r=json.loads((out/"replay.json").read_text())
match=code==0 and project_info(old)["scene_hash"]==project_info(out/"voxel-undo.dsculpt")["scene_hash"]
result={"exit":code,"restores_exact_baseline":match,"report_ready":r.get("voxel_menu_seen",False) and r.get("voxel_undo_seen",False),
        "accent":r.get("voxel_undo_pixels",0),"time_gate_frames":r.get("voxel_undo_wait_frames",0),
        "frames":r.get("frames_waited",0), "exhausted":r.get("voxel_undo_gate_exhausted",False)}
(out/"status.json").write_text(json.dumps(result,indent=2)+"\n")
print(result)
raise SystemExit(int(not (match and result["report_ready"])))
