from pathlib import Path
import hashlib, json, os, subprocess
out=Path(__file__).resolve().parent
full=out.parent/'combined-atlas-hdr-preview-full-20261126'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
registration=json.loads((full/'registered.json').read_text())
test=next(t for t in registration['tests'] if t['name']=='native-key-uv-openxr')
driver=test['command'][:-1]
manifest=json.loads((full/'status.json').read_text())
assert sha(driver[2])==manifest['app_sha256']
pins={str(p):sha(p) for p in driver}
state={'candidate':manifest['candidate'],'unit':'ds-combined-native-key-uv-replay-20261126.service',
       'invocation':os.getenv('INVOCATION_ID'),'terminal':False,'inputs':pins,'runs':[]}
def save():
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')
save()
try:
    for trial in range(1,4):
        case=out/str(trial)
        case.mkdir(exist_ok=True)
        cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',case,case,'--proc','/proc',
             '--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
             '--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
             *driver,case]
        with (case/'process.log').open('w') as log:
            result=subprocess.run(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=300)
        report=json.loads((case/'report.json').read_text())
        graphic=json.loads((case/'accept/graphics.json').read_text())
        accepted=case/'accept/result.dsculpt'
        state['runs'].append({'trial':trial,'code':result.returncode,'checks':len(report['checks']),
            'failures':[v['check'] for v in report['checks'] if not v['passed']],
            'accepted_exact_original':sha(accepted)==sha(case/'accept/original.dsculpt'),
            'uv':{k:v for k,v in graphic.items() if 'uv_' in k}})
        save()
    assert all(sha(p)==h for p,h in pins.items())
    state.update(terminal=True,exit=int(any(r['code'] for r in state['runs'])))
except Exception as error:
    state.update(terminal=True,exit=1,error=repr(error))
finally:
    save()
raise SystemExit(state['exit'])
