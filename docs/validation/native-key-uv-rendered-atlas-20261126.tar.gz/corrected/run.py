from pathlib import Path
import hashlib,json,os,shlex,subprocess
out=Path(__file__).resolve().parent
root=out.parent
source=root/'native-key-uv-visible-atlas-source-20261126'
frozen=root/'combined-atlas-hdr-preview-source-20261126'
full=root/'combined-atlas-hdr-preview-full-20261126'
build=full/'build'
main_case=root/'active-texture-set-wayland-validation-20261126'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
status={'fixture_commit':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),
 'invocation':os.getenv('INVOCATION_ID'),'terminal':False,'runs':{}}
def save(**fields):
    status.update(fields)
    target=out/'status.tmp'
    target.write_text(json.dumps(status,indent=2)+'\n')
    target.replace(out/'status.json')
def run(cmd,cwd,log,timeout):
    with log.open('w') as fd:
        print(shlex.join(map(str,cmd)),file=fd,flush=True)
        subprocess.run(cmd,cwd=cwd,stdout=fd,stderr=subprocess.STDOUT,check=True,timeout=timeout)
try:
    assert status['fixture_commit']=='f787798998889b4083bbed012f49ea063041701b'
    assert not subprocess.check_output(['git','-C',source,'status','--porcelain'],text=True).strip()
    diff=subprocess.check_output(['git','-C',source,'diff','--name-only','5c977be9','HEAD','--',
                                  'tests/xr_runtime.cpp','tests/native-key-uv-xr.py','third_party/nlohmann'],text=True)
    assert diff.splitlines()==['tests/native-key-uv-xr.py','tests/xr_runtime.cpp']
    target='dome-sculpt-test-runtime'
    listing=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()
    obj=out/'xr_runtime.o';runtime=out/'libdome-sculpt-test-runtime.so'
    compile=shlex.split(listing[-2])
    output=compile[compile.index('-o')+1]
    assert compile[-1]==str(frozen/'tests/xr_runtime.cpp')
    compile=[str(obj) if word==output else str(obj)+'.d' if word==output+'.d' else word for word in compile]
    compile[-1]=str(source/'tests/xr_runtime.cpp')
    link=[word for word in shlex.split(listing[-1])[2:-2] if not word.startswith('-Wl,--dependency-file=')]
    link=[str(obj) if word==output else str(runtime) if word==runtime.name else word for word in link]
    save(phase='build the corrected fixture runtime')
    run(compile,build,out/'compile.log',180)
    run(link,build,out/'link.log',100)
    save(runtime_sha256=sha(runtime),phase='replay the isolated UV edit in both application builds')
    full_status=read(full/'status.json')
    main_status=read(main_case/'status.json')
    assert main_status['terminal'] and main_status['exit']==0
    app_roles={'broad-candidate':(build/'dome-sculpt',full_status), 'active-set-main':(main_case/'dome-sculpt',main_status)}
    fixture=build/'native-key-uv/before.dsculpt'
    inspector=build/'dome-sculpt-native-authoring-inspect'
    for label,(app,build_info) in app_roles.items():
        assert sha(app)==build_info['app_sha256']
        case=out/label;case.mkdir(exist_ok=True)
        cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',case,case,'--proc','/proc',
             '--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
             '--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
             '/usr/bin/python3.14',source/'tests/native-key-uv-xr.py',app,runtime,inspector,fixture,case]
        run(cmd,out,case/'process.log',300)
        report=read(case/'report.json')
        assert report['failed']==0 and all(row['passed'] for row in report['checks'])
        observation={name:read(case/name/'graphics.json') for name in ('accept','cancel','focus')}
        assert all(o['uv_atlas_ready'] for o in observation.values())
        status['runs'][label]={'app_source':build_info['candidate'],'app_sha256':sha(app),'checks':len(report['checks']),
          'rendered_accept_pixels':observation['accept']['uv_atlas_visible_pixels'],
          'report_sha256':sha(case/'report.json')}
        save()
    save(terminal=True,exit=0,phase='complete')
except Exception as error:
    save(terminal=True,exit=1,error=repr(error))
    raise
