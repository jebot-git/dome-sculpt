#include "dome/material-bindings.hpp"
#include "dome/render.hpp"
#include "dome/import-authoring.hpp"
#include "dome/texture-sets.hpp"
#include "graphics.h"
#include <iostream>

using namespace dome;
namespace {
constexpr int width = 128;
constexpr int height = 128;
const Mat4 identity{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
using Pixels = std::array<uint8_t,width*height*4>;

Pixels draw(SurfaceRenderer &renderer, const Scene &scene,bool pbr=false) {
  Document document;
  document.replace(scene);
  if (pbr) document.shading(false);
  if (!document.wait_asset() || !document.wait_mesh() || !document.frame().state->error.empty())
    throw std::runtime_error(document.frame().state->error);
  renderer.draw(document.frame().surface,{},identity,{0,0,2},width,height,true);
  Pixels result{};
  glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,result.data());
  if (glGetError()!=GL_NO_ERROR) throw std::runtime_error("Fixture framebuffer read failed");
  return result;
}

}

int main(int argc, char **argv) try {
  if (argc!=4&&argc!=5) return 2;
  NativeGraphics graphics;
  std::cout<<"GPU "<<glGetString(GL_RENDERER)<<'\n';
  GLuint framebuffer=0, color=0, depth=0;
  glGenFramebuffers(1,&framebuffer);
  glBindFramebuffer(GL_FRAMEBUFFER,framebuffer);
  glGenTextures(1,&color);
  glBindTexture(GL_TEXTURE_2D,color);
  glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
  glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,color,0);
  glGenRenderbuffers(1,&depth);
  glBindRenderbuffer(GL_RENDERBUFFER,depth);
  glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,width,height);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,depth);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)
    throw std::runtime_error("Incomplete fixture framebuffer");
  SurfaceRenderer renderer;
  const auto scene=Scene::load(argv[1]);
  const auto consume=[](const auto *path,bool typed) {
    auto imported=prepare_authoring_import(Scene{},path,{});
    if(imported.objects.size()!=1) throw std::runtime_error("Portable primitive import changed object count");
    for (const auto &object:imported.scene.objects())
      if (object.id!=imported.objects.front()) imported.scene.object(object.id).visible=false;
    const auto &rendered=imported.scene.object(imported.objects.front());
    if (!rendered.appearance||!rendered.material_bindings||rendered.material_bindings->has_mtoon!=typed)
      throw std::runtime_error("Package-free importer did not load the selected material interpretation");
    return imported.scene;
  };
  const auto imported_typed=consume(argv[2],true);
  if(argc==5)imported_typed.save(argv[4]);
  const auto rendered=draw(renderer,imported_typed);
  const auto native=draw(renderer,scene);
  const auto rendered_core=draw(renderer,consume(argv[3],false),true);
  const auto native_core=draw(renderer,scene,true);
  const auto compare=[](const Pixels &before,const Pixels &imported) {
    size_t opaque=0,borders=0;
    int worst=0;
    double squared=0;
    for(size_t at=0;at<before.size();at+=4){
      borders+=(before[at+3]>240)!=(imported[at+3]>240);
      if(before[at+3]<240||imported[at+3]<240) continue;
      ++opaque;
      for(size_t k=0;k<3;++k) {
        const auto d=std::abs(int(before[at+k])-imported[at+k]);
        worst=std::max(worst,d);
        squared+=double(d)*d;
      }
    }
    if(opaque<200||borders>20)throw std::runtime_error("Portable visibility differs from the native surface");
    return std::tuple{opaque,worst,std::sqrt(squared/(3*opaque))};
  };
  const auto [pixels,mtoon_max,mtoon_rms]=compare(native,rendered);
  const auto [core_pixels,core_max,core_rms]=compare(native_core,rendered_core);
  std::cout<<"PORTABLE_RENDER pixels="<<pixels<<" mtoon_max="<<mtoon_max<<" mtoon_rms="<<mtoon_rms
           <<" core_pixels="<<core_pixels<<" core_max="<<core_max<<" core_rms="<<core_rms<<std::endl;
  if(mtoon_max>3||mtoon_rms>1.2||core_max>14||core_rms>3) throw std::runtime_error("Portable material pixels deviate from native rendering");
  std::cout<<"PASS package-free MToon variant and Core PBR replay\n";
  glDeleteRenderbuffers(1,&depth);
  glDeleteTextures(1,&color);
  glDeleteFramebuffers(1,&framebuffer);
} catch (const std::exception &error) {
  std::cerr<<"FAIL "<<error.what()<<'\n';
  return 1;
}
