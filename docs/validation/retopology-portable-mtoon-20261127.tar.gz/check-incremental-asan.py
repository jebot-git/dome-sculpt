from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import re
import shlex
import shutil
import subprocess

work=Path(__file__).resolve().parent
repo=work.parent.parent
prior=work/'asan'
out=work/'exact-asan'
out.mkdir(exist_ok=True)
targets=('dome-sculpt-texture-set-source-export-test','dome-sculpt-retopo-surface-heat-test')
commands={target:subprocess.check_output(['ninja','-C',prior,'-t','commands',target],text=True).splitlines() for target in targets}

# Start from the successful whole core sanitizer build from this milestone.
# Only these translation units can observe the subsequent options/culling
# changes. Recompile them with the original toolchain commands before linking.
units=('texture-set-export.cpp','texture-set-source-export.cpp')
archive=out/'libdome-sculpt-core.a'
subprocess.run(['cp','--reflink=always',prior/archive.name,archive],check=True)


def compile(name):
    command=shlex.split(next(row for row in commands[targets[0]] if row.endswith('/'+name)))
    assert '-fsanitize=address,undefined' in command
    obj=out/(name+'.o')
    command[command.index('-o')+1]=str(obj)
    if '-MF' in command: command[command.index('-MF')+1]=str(out/(name+'.d'))
    sandbox=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
             '--bind',out,out,'--proc','/proc','--dev','/dev','--tmpfs','/tmp']
    for directory in ('src','include','tests'):
        sandbox.extend(['--ro-bind',work/'final-source'/directory,repo/directory])
    with (out/(name+'.build.log')).open('w') as log:
        subprocess.run([*sandbox,*command],cwd=prior,stdout=log,stderr=subprocess.STDOUT,check=True)
    return obj

with ThreadPoolExecutor(max_workers=4) as pool:
    objects=list(pool.map(compile,units))
subprocess.run(['ar','rs',archive,*objects[:-1]],check=True)
for target in targets:
    link=shlex.split(commands[target][-1])[2:-2]
    link[link.index('-o')+1]=str(out/target)
    if target==targets[0]:
        i=link.index(next(x for x in link if x.endswith('/texture-set-source-export.cpp.o')))
        link[i]=str(objects[-1])
    link[link.index(archive.name)]=str(archive)
    link=[x for x in link if not x.startswith('-Wl,--dependency-file=')]
    subprocess.run(link,cwd=prior,check=True)

included=re.compile(r'^(retopology-(mtoon-.*|first-material-.*|imported-(pbr|prior-bake|mtoon-.*))|native-mikk-export)$')
seed=work.parent/'retained-texture-set-shape-20261127/asan'
lines=[]
for row in (prior/'CTestTestfile.cmake').read_text().splitlines():
    match=re.match(r'^add_test\(\[=\[(\S+)\]=\]',row)
    if match and included.fullmatch(match[1]):
        lines.append(row.replace(str(seed),str(out)))
        lines.append(f'set_tests_properties({match[1]} PROPERTIES TIMEOUT 400)')
assert len(lines)==28
(out/'CTestTestfile.cmake').write_text('\n'.join(lines)+'\n')
sdk=repo/'artifacts/sdk-20261126/toolkit-sanitize'
launcher=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
     'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
     'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2'}
for name,value in env.items(): launcher.extend(['--setenv',name,value])
with (work/'asan-incremental-tests.log').open('w') as log:
    subprocess.run([*launcher,'ctest','--test-dir',out,'--parallel','3','--output-on-failure'],stdout=log,stderr=subprocess.STDOUT,check=True)
