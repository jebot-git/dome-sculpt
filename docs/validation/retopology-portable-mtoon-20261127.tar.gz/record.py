from hashlib import file_digest, sha256
import gzip
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'
previous_commit = 'a0a932f32cbda86d18d0a507dee7bcf4acbd6c78'
previous = work.parent / 'retopology-imported-mtoon-20261127'


def digest(path):
    with path.open('rb') as file:
        return file_digest(file, 'sha256').hexdigest()


def git(directory, *args):
    return subprocess.check_output(['git', '-C', directory, *args]).decode().strip()


def load(name):
    return json.loads((work / name).read_text())


def glb(path):
    data = path.read_bytes()
    assert data[:4] == b'glTF'
    end = 20 + struct.unpack_from('<I', data, 12)[0]
    return json.loads(data[20:end])


product = git(repo, 'rev-parse', 'HEAD')
assert git(repo, 'rev-parse', 'HEAD^') == previous_commit
patch = subprocess.check_output(['git', '-C', repo, 'diff', '--binary', previous_commit, product])
assert sha256(patch).hexdigest() == digest(work / 'final-source.patch')
canonical = git(repo.parent / 'DomeD', 'rev-parse', 'HEAD')
assert canonical == git(repo.parent / 'DomeD', 'ls-remote', 'origin', 'refs/heads/main').split()[0]
baseline_file = previous / 'qualified-debug-painted/raw-editable.glb'
baseline = glb(baseline_file)
baseline_primitive = baseline['meshes'][0]['primitives'][0]
assert 'TANGENT' not in baseline_primitive['attributes']
assert 'KHR_materials_variants' not in baseline.get('extensionsUsed', [])

members = ['record.py','check.sh','check-final.sh','check-incremental-asan.py',
    'khronos.cjs','khronos.log','khronos.json','mtoon-schemas.log','mtoon-schemas.json',
    'select-variant.py','render-portable.cpp','render-portable.py','run-render.py','xr-portable.py',
    'run-wayland.py','wayland-first-material.py','bind-wayland.log','wayland-first-material/report.json',
    'wayland-first-material/corners.json','release-final-build.log','release-final-tests.log',
    'asan-build.log','asan-tests.log','asan-incremental-tests.log',
    'exact-asan/texture-set-export.cpp.build.log','exact-asan/texture-set-source-export.cpp.build.log']
profiles = {}
case_comparison = {}
variants = ('painted','tinted','unprepared')
for directory, name, count in [('release','release-final-tests.log',18),
                               ('exact-asan','asan-incremental-tests.log',14)]:
    output = (work / name).read_text()
    assert f'0 tests failed out of {count}' in output
    passed = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',output)
    assert len(passed) == len(set(passed)) == count
    logs = (work / directory / 'Testing/Temporary/LastTest.log').read_text()
    cases = {}
    for variant in variants:
        case = 'retopology-imported-mtoon-' + variant
        fixture = re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.',logs,re.M | re.S)[1]
        assert case in passed
        row = re.search(r'IMPORTED_MTOON samples=(\d+) max_role=([\d.]+) max_core=([\d.]+) min_typed_dot=([\d.]+) min_core_dot=([\d.]+)',fixture)
        samples, role, core, typed_dot, core_dot = map(float,row.groups())
        checks = int(re.search(r'PASS (\d+) imported MToon retopology checks',fixture)[1])
        assert samples >= 70 and max(role, core) < .006 and min(typed_dot, core_dot) > .9997
        cases[variant] = dict(samples=int(samples),checks=checks,maximum_typed_error=role,
                              maximum_core_error=core,minimum_typed_normal_dot=typed_dot,
                              minimum_core_normal_dot=core_dot)
        member = f'{directory}-{variant}-native-controls.log'
        (work/member).write_text(fixture)
        members.append(member)
    profiles[directory] = passed
    case_comparison[directory] = cases
assert case_comparison['release'] == case_comparison['exact-asan']
assert case_comparison['release']['painted']['checks'] == 145

outputs = {}
for variant in variants:
    case = 'retopology-imported-mtoon-' + variant
    files = ['original-import.glb','raw-guide.dsculpt','raw-patch.dsculpt','raw-standard.glb','raw-editable.glb']
    if variant == 'painted': files += ['raw-scalar-paint.glb','raw-reapplied.dsculpt']
    for file in files:
        relative = Path(case) / file
        checksum = digest(work / 'release' / relative)
        assert checksum == digest(work / 'exact-asan' / relative)
        if file in ('raw-standard.glb','raw-editable.glb'):
            assert checksum == digest(work / ('current-'+variant) / file)
            portable = glb(work / 'release' / relative)
            primitive = portable['meshes'][0]['primitives'][0]
            assert 'TANGENT' in primitive['attributes']
            mapping = primitive['extensions']['KHR_materials_variants']['mappings'][0]
            assert mapping['variants'] == [0] and mapping['material'] != primitive['material']
            assert 'VRMC_materials_mtoon' in portable['materials'][mapping['material']]['extensions']
        elif file == 'raw-scalar-paint.glb':
            assert checksum == digest(work / 'current-scalar' / file)
        else:
            assert checksum == digest(previous / ('qualified-debug-'+variant) / file)
        outputs[str(relative)] = checksum

wayland = load('wayland-first-material/report.json')
assert wayland['complete'] and len(wayland['checks']) == 8 and all(check['passed'] for check in wayland['checks'])
khronos = load('khronos.json')
assert len(khronos['results']) == 13
for result in khronos['results']:
    assert result['issues']['numErrors'] == result['issues']['numWarnings'] == 0
    result['sha256'] = digest(work / result['file'])
schemas = load('mtoon-schemas.json')
assert len(schemas['files']) == 9 and len(schemas['resolver_controls']) == 3
assert all(len(file['checks']) == 1 and not file['checks'][0]['errors'] for file in schemas['files'])
assert not schemas['schema_drift'] and not schemas['schema_bytes_rewritten']

renderers = {}
for mode, renderer in [('software','llvmpipe'),('arc','Arc(tm) A770')]:
    render_log = f'render-portable-{mode}.log'
    render = (work / render_log).read_text()
    match = re.search(r'PORTABLE_RENDER pixels=(\d+) mtoon_max=(\d+) mtoon_rms=([.\d]+) core_pixels=(\d+) core_max=(\d+) core_rms=([.\d]+)',render)
    typed_pixels,typed_max,typed_rms,core_pixels,core_max,core_rms=map(float,match.groups())
    assert renderer in render and 'PASS package-free MToon variant and Core PBR replay' in render
    assert typed_pixels == core_pixels == 5754 and typed_max == 0 and core_max <= 1
    stereo = f'xr-{mode}-portable/compare.json'
    report = load(stereo)
    assert report['runtime'] == 'synthetic OpenXR' and report['exact_ordered_close']
    assert len(report['profiles']) == 2
    for profile in report['profiles']:
        assert renderer in profile['gl_renderer'] and profile['stereo_submissions'] == 6
        assert profile['acquires'] == profile['image_waits'] == profile['releases'] == 12
    assert len(report['differing_rgb_components_per_eye']) == 2
    assert all(row['maximum_channel_difference'] <= 1 for row in report['differing_rgb_components_per_eye'])
    renderers[mode] = dict(renderer=report['profiles'][0]['gl_renderer'],rendered_pixels=int(typed_pixels),
                          maximum_8_bit_difference=dict(mtoon=int(typed_max),core=int(core_max)),
                          rms_8_bit_difference=dict(mtoon=typed_rms,core=core_rms),
                          stereo_differences=report['differing_rgb_components_per_eye'],
                          exact_stereo_close=True,stereo_submissions_per_project=6)
    members += [render_log,stereo,f'verified-portable-{mode}.log']

archive = validation / (work.name + '.tar.gz')
archive_members = {}
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as output:
        for name in members:
            data = (work / name).read_bytes()
            archive_members[name] = sha256(data).hexdigest()
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            output.addfile(entry, io.BytesIO(data))

receipt = dict(product=product,previous_main=previous_commit,canonical_domed=canonical,
    canonical_compositor_sha256=digest(work.parent/'creator-public-build-20261126/wayland-reference/dome-compositor'),
    release_application_sha256=digest(work/'release/dome-sculpt'),source_patch_sha256=digest(work/'final-source.patch'),
    asan_test_sha256=digest(work/'exact-asan/dome-sculpt-texture-set-source-export-test'),
    asan_build='Source-bound whole core, then final two changed translation units and relink with the same ASan/UBSan toolchain',
    tests=profiles,native_samples=case_comparison['release'],
    baseline=dict(sha256=digest(baseline_file),primitive_attributes=list(baseline_primitive['attributes']),
                  material_variants=False),
    identical_release_and_sanitizer_outputs_sha256=outputs,
    renderers=renderers,physical_headset=False,dome_wayland=wayland,khronos=khronos,
    mtoon_schema_valid_materials=len(schemas['files']),
    portable_preview='Default Core PBR and selectable typed MToon 1 with shared explicit tangents and separate normal maps',
    archive_sha256=digest(archive),archive_members_sha256=archive_members)
(validation/(work.name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
