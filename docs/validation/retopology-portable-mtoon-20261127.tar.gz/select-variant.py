import json
from pathlib import Path
import struct
import sys

source=Path(sys.argv[1]).read_bytes()
variant=sys.argv[2]
length,=struct.unpack_from('<I',source,12)
doc=json.loads(source[20:20+length])
for mesh in doc['meshes']:
    for primitive in mesh['primitives']:
        mappings=primitive['extensions'].pop('KHR_materials_variants')['mappings']
        assert len(mappings)==1 and mappings[0]['variants']==[0]
        if variant=='mtoon': primitive['material']=mappings[0]['material']
        if not primitive['extensions']: del primitive['extensions']
for name in ('domeSculptAuthoring','domeSculptEmission'):
    doc.get('extras',{}).pop(name,None)
if not doc.get('extras'): doc.pop('extras',None)
doc['extensions'].pop('KHR_materials_variants')
if not doc['extensions']: del doc['extensions']
doc['extensionsUsed'].remove('KHR_materials_variants')
encoded=json.dumps(doc,separators=(',',':')).encode()
encoded+=b' '*((-len(encoded))%4)
bin_chunk=source[20+length:]
Path(sys.argv[3]).write_bytes(struct.pack('<5I',0x46546c67,2,20+len(encoded)+len(bin_chunk),len(encoded),0x4e4f534a)+encoded+bin_chunk)
