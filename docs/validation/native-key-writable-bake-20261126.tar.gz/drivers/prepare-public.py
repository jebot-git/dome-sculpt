from pathlib import Path
import json, shlex, subprocess

root=Path(__file__).resolve().parent
release=root/'release'
build=release/'build'
baseline=root.parent/'writable-donor-current-validation-v2-20261126/release/tests/dome-sculpt-source-writable-normal-bake-test'
receipt=json.loads((release/'status.json').read_text())
assert receipt['binaries'] and (build/'native-key-writable-bake-recipient/hdr-before.dsculpt').is_file()

def read(p):return shlex.split(p.read_text().splitlines()[0])
entry=next(e for e in json.loads((build/'compile_commands.json').read_text())
           if e['file'].endswith('/source-writable-normal-bake.cpp'))
cmd=shlex.split(entry['command'])
cmd.extend(['-MMD','-MF',str(root/'public-fixture.o.d')])
for flag,path in (('-c',root/'public-fixture.cpp'),('-o',root/'public-fixture.o'),('-MF',root/'public-fixture.o.d')):
    cmd[cmd.index(flag)+1]=str(path)
subprocess.run(cmd,check=True)
cmd=read(baseline/'link.log')
cmd=[str(root/'public-fixture.o') if w.endswith('/source-writable-normal-bake.cpp.o') else str(release/'libdome-sculpt-core.a') if w.endswith('/libdome-sculpt-core.a') else w for w in cmd]
cmd[cmd.index('-o')+1]=str(root/'public-fixture')
subprocess.run(cmd,check=True)
subprocess.run([root/'public-fixture',build/'native-key-writable-bake-recipient/hdr-before.dsculpt',
                root/'before.dsculpt',root/'expected.dsculpt'],check=True)
