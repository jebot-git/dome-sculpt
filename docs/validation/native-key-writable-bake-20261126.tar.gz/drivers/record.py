from pathlib import Path
import hashlib
import json
import re
import subprocess
import tarfile

root=Path(__file__).resolve().parent
art=root.parent
repo=art.parent
first=art/'native-key-bake-20261126'
name='native-key-writable-bake-20261126'
out=repo/'docs/validation'
archive=out/(name+'.tar.gz')
candidate=subprocess.check_output(['git','-C',repo,'rev-parse','4f7007dc'],text=True).strip()
def sha(path):
    with Path(path).open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
def object_members(path):
    result=[]
    with path.open('rb') as file:
        assert file.read(8)==b'!<arch>\n'
        while header:=file.read(60):
            name=header[:16].rstrip()
            size=int(header[48:58])
            payload=file.read(size)
            assert len(payload)==size and len(header)==60 and header[58:]==bytes([96,10])
            if size%2:file.read(1)
            if name not in (b'/',b'//',b'/SYM64/'):
                result.append((name.decode('ascii'),hashlib.sha256(payload).hexdigest()))
    return result
patch=root/'source.patch'
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',candidate])==patch.read_bytes()
members={}
def add(prefix,*paths):
    for path in paths:
        key=prefix+'/'+path.name
        assert path.is_file() and key not in members,path
        members[key]=path
def state(dir):
    return json.loads((dir/'status.json').read_text())
assert state(first/'prior')['exit']==1
assert 'This corner-color target has shading roles' in (first/'prior/run.log').read_text()
add('prior/product',first/'prior/status.json',first/'prior/compile.log',first/'prior/link.log',first/'prior/run.log')
for profile in ('release','asan'):
    dir=first/profile
    assert state(dir)['exit']==8 and 'Choose a unique UTF-8 shapekey name' in (dir/'ctest.log').read_text()
    add('prior/duplicate-key-name/'+profile,dir/'status.json',dir/'ctest.log',dir/'build/regressions.xml')
native={}
for profile in ('release','asan'):
    dir=root/profile
    s=state(dir)
    base=state(first/profile)
    assert s['terminal'] and s['exit']==0 and len(s['tests'])==9 and s['patch_sha256']==sha(patch)
    assert base['app_sha256']==s['app_sha256']
    s['matching_archive_member_count']={}
    for role in ('core','render'):
        file='libdome-sculpt-'+role+'.a'
        a,b=(object_members(folder/file) for folder in (first/profile,dir))
        assert a==b
        s['matching_archive_member_count'][role]=len(a)
    text=(dir/'ctest.log').read_text()
    assert 'PASS 49 keyed writable recipient checks' in text
    assert re.findall(r'NATIVE_KEY_RECIPIENT (\S+) projected=(\d+) preserved=(\d+)',text)==[
        ('ldr','4096','2048'),('hdr','4096','2048')]
    s['recipient_checks']=49
    native[profile]=s
    add(profile,dir/'status.json',dir/'configure.log',dir/'ctest.log',dir/'build/regressions.xml',
        dir/'app-link.log',*sorted(dir.glob('*-archive.log')),*sorted(dir.glob('*.cpp*.log')))
files={}
release=root/'release/build/native-key-writable-bake-recipient'
strict=root/'asan/build/native-key-writable-bake-recipient'
for p in sorted(release.iterdir()):
    files[p.name]=sha(p)
    assert files[p.name]==sha(strict/p.name),p
assert len(files)==12

frontends={}
for mode,profile,count in (('software','release',11),('arc','asan',11),('wayland','release',10)):
    dir=root/(mode+'-focus-recipient')
    s=state(dir)
    assert s['exit']==0 and s['checks']==count and s['app_sha256']==native[profile]['app_sha256']
    assert s['native_sha256']==sha(root/'expected.dsculpt') and s['input_sha256']==sha(root/'before.dsculpt')
    frontends[mode]=s
    add('frontend/'+mode,dir/'status.json',dir/'run.log',dir/'workflow/report.json')
    if mode=='wayland':
        add('frontend/'+mode,*(dir/'workflow'/f for f in ('client.log','compositor.log','runtime-maps.txt')))
    else:
        add('frontend/'+mode,*(dir/'workflow'/f'{phase}.{ext}' for phase in ('accept','cancel') for ext in ('json','log')))
graphics={}
for backend in ('llvmpipe','arc'):
    previous=root/('graphics-'+backend)
    assert 'FAIL The authored key visibly changes the shaded surface' in (previous/'run.log').read_text()
    add('prior/undersized-image-witness/'+backend,previous/'run.log')
    dir=root/('graphics-strong-'+backend)
    trace=(dir/'run.log').read_text()
    assert ('GPU llvmpipe' if backend=='llvmpipe' else 'Arc(tm) A770') in trace
    checks=int(re.search(r'PASS (\d+) keyed normal Bake graphical checks',trace)[1])
    values=[int(v) for v in re.findall(r'KEY_BAKE_GLB .*? delta=(\d+)',trace)]
    wrong=int(re.search(r'KEY_BAKE_WRONG_FRAME delta=(\d+)',trace)[1])
    assert len(values)==12 and max(values)<=4 and wrong>5
    graphics[backend]={'checks':checks,'glb_rgb8_max_error':max(values),'wrong_frame_delta':wrong,
                       'fixture_sha256':sha(dir/'graphics')}
    add('graphics/'+backend,dir/'compile.log',dir/'link.log',dir/'run.log')
    for p in dir.glob('images/*/*.png'):add('graphics/'+backend+'/'+p.parent.name,p)
khronos=json.loads((root/'khronos.json').read_text())
for file,report in khronos.items():
    assert file in files and report['issues']['numErrors']==0
    assert [m['code'] for m in report['issues']['messages'] if m['severity']==1]==['NODE_SKINNED_MESH_NON_ROOT']
add('format',root/'khronos.json',root/'validate.cjs')
add('drivers',patch,*(root/n for n in ('run.py','after.py','prepare-public.py','public-fixture.cpp','public-focus.py','xr-focus.py','wayland.py',
     'graphics.cpp','graphics-strong.cpp','graphics.py','graphics-strong.py','record.py')))
add('fixtures',root/'before.dsculpt',root/'expected.dsculpt')
legacy=root/'legacy-control'
assert (legacy/'run.log').read_text().startswith('LEGACY_PORTABLE_OPEN Canonical normal export:')
add('legacy',legacy/'run.log',root/'legacy-check.cpp',root/'legacy-check.py')
with tarfile.open(archive,'w:gz',compresslevel=9) as pack:
    for key,path in sorted(members.items()):pack.add(path,arcname=key)
report={
    'candidate':candidate,
    'scope':'Shared Bake against independently authored native shapekey frames and retained writable UVs. Includes matched scope, immutable render snapshots and standard/editable GLB consumers.',
    'native':native,
    'native_and_glb_byte_parity':files,
    'graphics':graphics,
    'frontends':frontends,
    'format_errors':0,
    'format_warning_per_file':'NODE_SKINNED_MESH_NON_ROOT',
    'archive':{'file':archive.name,'sha256':sha(archive),'members':{key:sha(path) for key,path in sorted(members.items())}},
}
(out/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(archive) as pack:
    assert {m.name:hashlib.sha256(pack.extractfile(m).read()).hexdigest() for m in pack.getmembers()}==report['archive']['members']
print(candidate,len(files),graphics,len(members))
