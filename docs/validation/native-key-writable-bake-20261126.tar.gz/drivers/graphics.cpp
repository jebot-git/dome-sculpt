#define DOME_NATIVE_KEY_EXPORT_NO_MAIN
#include "native-paint-key-export-render.cpp"
#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/tangents.hpp"

int main(int argc,char **argv) try {
  if(argc!=4)return 2;
  const std::filesystem::path input=argv[1],output=argv[2];
  std::filesystem::create_directories(output);
  const auto phase=Scene::load(input/"ldr-accepted.dsculpt");
  const auto edited=Scene::load(input/"ldr-edited.dsculpt");
  NativeGraphics graphics;
  const std::string renderer_name=reinterpret_cast<const char *>(glGetString(GL_RENDERER));
  std::cout<<"GPU "<<renderer_name<<std::endl;
  check(renderer_name.find(argv[3])!=std::string::npos,"Requested actual renderer is active");
  Fbo fbo;
  SurfaceRenderer native;
  prepared_normal_consumer::Renderer consumer;
  Pixels rest;
  unsigned index=0;
  for(bool after_uv:{false,true})for(float weight:{0.f,.43f,1.f}){
    auto scene=after_uv?edited:phase;
    auto deformation=*scene.active().deformation;
    deformation.morph_weights.assign(deformation.morphs->targets.size(),0);
    deformation.morph_weights.front()=weight;
    if(after_uv)deformation.morph_weights.back()=.37f;
    if(weight==.43f){
      deformation.pose.resize(2);
      deformation.pose[0].scale={1.1f,.88f,1.14f};
      deformation.pose[1].scale={.85f,1.08f,1.2f};
    }
    scene.set_deformation(scene.active().id,deformation);
    scene.active().material.roughness=.43f;
    const auto stable=scene.encode();
    Document doc;doc.replace(scene);doc.shading(false);finish(doc);fbo.bind();
    const auto got=draw(native,doc.frame().surface);
    std::set<std::array<uint8_t,4>> colors;
    size_t visible=0;
    for(size_t p=0;p<got.size();p+=4)if(got[p+3]){
      ++visible;colors.insert({got[p],got[p+1],got[p+2],got[p+3]});
    }
    check(visible>500&&colors.size()>8,"Lit authored Bake has substantial visible nonuniform pixels");
    if(!after_uv&&weight==0)rest=got;
    if(!after_uv&&weight==1)check(delta(rest,got)>2,"The authored key visibly changes the shaded surface");
    auto dir=output/std::to_string(index++);
    std::filesystem::create_directories(dir);
    capture(dir/"native.png",got);
    for(bool editable:{false,true}){
      const auto path=dir/(editable?"editable.glb":"standard.glb");
      doc.export_asset(path,editable?AssetExportFormat::EditableGlb256:AssetExportFormat::Glb).get();
      prepared_normal_consumer::Model model(path);
      const auto &primitive=model.data->meshes[0].primitives[0];
      check(primitive.targets_count==scene.active().deformation->morphs->targets.size(),
            "Independent parser sees every edited key");
      fbo.bind();consumer.render(model.data,nullptr);
      const auto emitted=read();
      auto error=delta(got,emitted);
      std::cout<<"KEY_BAKE_GLB later_uv="<<after_uv<<" weight="<<weight<<" editable="<<editable<<" delta="<<error<<std::endl;
      capture(dir/(editable?"editable.png":"standard.png"),emitted);
      check(error<=4,"Independent GLB consumer reproduces the baked normal under active keys");
      if(editable){
        const auto restored=extract_native_authoring(key_file_bytes(path));
        check(restored&&restored->encode()==stable,"Editable GLB returns exact key, UV and Bake ownership");
      }
    }
    if(!after_uv&&weight==0){
      auto wrong=std::make_shared<MeshSnapshot>(*doc.frame().surface);
      wrong->geometry_identity.reset();
      std::fill(wrong->source_tangents.begin(),wrong->source_tangents.end(),Tangent{1,0,0,1});
      auto incorrect=draw(native,wrong);
      const auto error=delta(got,incorrect);
      std::cout<<"KEY_BAKE_WRONG_FRAME delta="<<error<<std::endl;
      check(error>5,"Rendered Bake distinguishes the legacy writable tangent basis");
    }
  }
  std::cout<<"PASS "<<checks<<" keyed normal Bake graphical checks\n";
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
