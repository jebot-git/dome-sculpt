from pathlib import Path
import json,subprocess,sys,time

root=Path(__file__).resolve().parent
profile=sys.argv[1]
unit=f'ds-native-key-bake-v2-{profile}-20261126.service'
state=root/profile/'status.json'
while True:
    record=json.loads(state.read_text()) if state.is_file() else {}
    if record.get('terminal'):
        assert record['exit']==0,record
        break
    subprocess.run(['systemctl','--user','is-active','--quiet',unit],check=True)
    time.sleep(2)
script,*args=sys.argv[2:]
subprocess.run(['/usr/bin/python3',root/script,*args],check=True)
