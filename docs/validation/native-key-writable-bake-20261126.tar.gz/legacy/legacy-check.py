from pathlib import Path
import json, shlex, subprocess

root=Path(__file__).resolve().parent
release=root/'release'
build=release/'build'
baseline=root.parent/'writable-donor-current-validation-v2-20261126/release/tests/dome-sculpt-source-writable-normal-bake-test'
receipt=json.loads((release/'status.json').read_text())
assert receipt['exit']==0

def read(p):return shlex.split(p.read_text().splitlines()[0])
entry=next(e for e in json.loads((build/'compile_commands.json').read_text())
           if e['file'].endswith('/source-writable-normal-bake.cpp'))
cmd=shlex.split(entry['command'])
cmd.extend(['-MMD','-MF',str(root/'legacy-check.o.d')])
for flag,path in (('-c',root/'legacy-check.cpp'),('-o',root/'legacy-check.o'),('-MF',root/'legacy-check.o.d')):
    cmd[cmd.index(flag)+1]=str(path)
subprocess.run(cmd,check=True)
cmd=read(baseline/'link.log')
cmd=[str(root/'legacy-check.o') if w.endswith('/source-writable-normal-bake.cpp.o') else str(release/'libdome-sculpt-core.a') if w.endswith('/libdome-sculpt-core.a') else w for w in cmd]
cmd[cmd.index('-o')+1]=str(root/'legacy-check')
subprocess.run(cmd,check=True)
output=root/'legacy-control'
output.mkdir(exist_ok=True)
legacy=root.parent/'native-writable-recipient-v4-20261126/release/build/native-writable-bake-recipient/ldr-accepted.dsculpt'
with (output/'run.log').open('w') as log:
    subprocess.run([root/'legacy-check',legacy,output],stdout=log,stderr=subprocess.STDOUT,check=True)
