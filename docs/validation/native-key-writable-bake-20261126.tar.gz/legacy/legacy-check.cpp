#include "dome/document.hpp"
#include "dome/shapekey-authoring.hpp"
#include <iostream>
#include <nlohmann/json.hpp>

int main(int argc,char **argv) try {
  if(argc!=3)return 2;
  const std::filesystem::path out=argv[2];
  auto scene=dome::Scene::load(argv[1]);
  const auto bake=scene.active().painted->baked();
  dome::ShapeKeyEdit key;
  key.action=dome::ShapeKeyAction::Create;
  key.name="Later key on legacy Bake";
  dome::author_shapekey(scene,scene.active().id,key);
  key.action=dome::ShapeKeyAction::Replace;
  key.positions=scene.active().painted->mesh().positions;
  key.positions.front().z+=.07f;
  dome::author_shapekey(scene,scene.active().id,key);
  if(scene.active().painted->baked()!=bake||
     bake->normal_interpretation!=dome::BakedNormalInterpretation::CanonicalMikk)
    throw std::runtime_error("Legacy Bake was reinterpreted");
  scene.save(out/"stored.dsculpt");
  auto restored=dome::Scene::load(out/"stored.dsculpt");
  if(restored.encode().dump()!=scene.encode().dump())
    throw std::runtime_error("Legacy Bake and later key did not survive Save");
  dome::Document doc;
  doc.replace(restored);
  if(!doc.wait_mesh()||!doc.frame().state->error.empty())
    throw std::runtime_error("Legacy Bake and later key did not reach the viewport");
  try{
    doc.export_asset(out/"portable.glb").get();
  }catch(const std::invalid_argument &error){
    if(std::string_view(error.what()).starts_with("Canonical normal export:")){
      std::cout<<"LEGACY_PORTABLE_OPEN "<<error.what()<<"\n";
      return 0;
    }
    throw;
  }
  throw std::runtime_error("Legacy conversion capability changed");
}catch(const std::exception &e){std::cerr<<e.what()<<'\n';return 1;}
