import json,hashlib,subprocess,shlex,time,resource,signal,os
from pathlib import Path
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent;S=R/'artifacts/artist-cc0-witness-20261115';C=R/'artifacts/artist-cc0-witness-compile-20261115';PROVIDER=R/'artifacts/current-toolchain-guard87-release-20261115/component-from-current-whole-objects-v1/component-ready.json';NATIVE=R/'artifacts/artist-prepared-release-component-v3-20261115';pins={};state={'state':'preparing','source':'7fb2cc1c','scope':'Fresh complete current graphics fixture links only; not product execution, GL/device/whole-app acceptance. Original failures preserved. Product1bc unchanged.','steps':[],'exit':1}
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def pin(p,h=None):
 p=str(p);actual=sha(p);assert h is None or h==actual,('pin drift',p);pins[p]=actual
def save():(P/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def limits():resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
def identity(pid):
 try:
  s=Path('/proc',str(pid),'stat').read_text().split(') ',1)[1].split();return(int(s[19]),int(s[2]))
 except(FileNotFoundError,ProcessLookupError):return None
def run(name,cmd):
 row={'name':name,'command':cmd,'started':time.time()};state['steps'].append(row);save()
 with(P/(name+'.log')).open('w')as log:
  child=subprocess.Popen(cmd,cwd=P,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);ident=identity(child.pid);row.update(pid=child.pid,identity=ident);save()
  try:code=child.wait(timeout=900)
  except BaseException:
   if ident is not None and identity(child.pid)==ident and ident[1]==child.pid:
    try:os.killpg(child.pid,signal.SIGKILL)
    except ProcessLookupError:pass
   child.wait();raise
 row.update(exit=code,seconds=time.time()-row['started'],log_sha256=sha(P/(name+'.log')));save();print(name,code,flush=True);assert code==0
try:
 assert subprocess.check_output(['git','rev-parse','--short=8','HEAD'],cwd=S,text=True).strip()==state['source'] and not subprocess.check_output(['git','status','--porcelain'],cwd=S,text=True)
 pin(PROVIDER,'41a9d7a6d2318d4841d18d136f80c64c94f3006c7554a3179c8a42192cb01dd2');provider=json.loads(PROVIDER.read_text());assert provider['state']=='terminal'and provider['exit']==0
 for tag in ['current_inputs','plan']:pin(provider[tag]['path'],provider[tag]['sha256'])
 for f,h in json.loads(Path(provider['current_inputs']['path']).read_text()).items():pin(f,h)
 archives={}
 for name,row in provider['archives'].items():
  pin(row['path'],row['sha256']);archives[name]=row['path'];names=subprocess.check_output(['ar','t',row['path']],text=True).splitlines();assert names==[x['name']for x in row['members']]
  for member in row['members']:assert hashlib.sha256(subprocess.check_output(['ar','p',row['path'],member['name']])).hexdigest()==member['sha256']
 native=json.loads((NATIVE/'status.json').read_text());fixed=native['archives']['fixed'];pin(fixed['path'],fixed['sha256']);assert fixed['count']==193 and fixed['unchanged']==190
 # Full current product and private-header footprint, not merely public ABI.
 prior=R/'artifacts/artist-prepared-source-v3-20261115'
 for f in subprocess.check_output(['git','ls-files','-z'],cwd=S,text=True).split('\0'):
  if not f or not(S/f).is_file():continue
  pin(S/f)
  if f.startswith(('src/','include/','third_party/')):assert sha(S/f)==sha(prior/f),('Product footprint differs',f)
 nativepins=json.loads((NATIVE/'inputs-before-runtime.json').read_text())
 for f,h in nativepins.items():
  if Path(f).is_file()and not f.endswith(('status.json','run-component-v3.py')):pin(f,h)
 compile_state=json.loads((C/'compile-status.json').read_text());assert compile_state['state']=='terminal'and compile_state['exit']==0 and not compile_state['input_drift']
 for f,h in json.loads((C/'compile-inputs.json').read_text()).items():pin(f,h)
 for f in [C/'compile-status.json',C/'compile-plan.json',C/'compile-witness-v1.py',Path(__file__).resolve(),NATIVE/'status.json']:pin(f)
 plan=json.loads(Path(provider['plan']['path']).read_text());base=plan['links']['dome-sculpt-source8-preview-test']['command'];assert base.startswith(': && ')and base.endswith(' && :')
 products={}
 for i,name in enumerate(['artist','prepared']):
  row=compile_state['steps'][2+i];assert row['name']=='compile-'+str(i)and row['exit']==0;cmd=row['command'];obj=cmd[cmd.index('-o')+1];pin(obj);cmd=shlex.split(base[5:-5]);cmd[cmd.index(next(x for x in cmd if x.endswith('.o')))]=obj;cmd[cmd.index('-o')+1]=str(P/(name+'-render-test'))
  cmd=[('-Wl,--dependency-file='+str(P/(name+'-link.d')))if x.startswith('-Wl,--dependency-file=')else fixed['path']if x=='libdome-sculpt-core.a'else archives[x]if x in archives else x for x in cmd];run('link-'+name,cmd);pin(P/(name+'-render-test'));pin(P/(name+'-link.d'));products[name]={'path':str(P/(name+'-render-test')),'sha256':sha(P/(name+'-render-test'))}
 state.update(products=products,exit=0)
except BaseException as e:state['error']=repr(e)
finally:
 drift=[f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h];state.update(state='terminal',input_drift=drift);state['exit']=state['exit']or int(bool(drift));(P/'inputs.json').write_text(json.dumps(pins,indent=2)+'\n');save();print(json.dumps({k:state.get(k)for k in ['state','exit','error','input_drift']}),flush=True)
raise SystemExit(state['exit'])
