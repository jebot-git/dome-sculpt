"""Plan by default; explicit reviewed component graphics only."""
import argparse,fcntl,hashlib,importlib.util,json,os,re,subprocess,sys,threading,time
from pathlib import Path
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent;CONTRACT=R/'artifacts/guard87-validation-fresh-v2-20261115';sys.path.insert(0,str(CONTRACT))
from runtime_contract import read_runtime,merge_pins
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py';spec=importlib.util.spec_from_file_location('owned_graphics_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
def sha(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(path,obj):Path(path).write_text(json.dumps(obj,indent=2)+'\n')
def verify(pins):return [p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def main(a):
 review=json.loads((P/'graphics-witness-plan-review-v1.json').read_text())
 if not a.execute:print(json.dumps(review,indent=2));return 0
 assert a.reviewed_source=='7fb2cc1c'and a.output_tag and '/'not in a.output_tag
 out=P/a.output_tag;out.mkdir();linked=json.loads((P/'status.json').read_text());assert linked['state']=='terminal'and linked['exit']==0 and not linked['input_drift']and linked['source']==a.reviewed_source
 pins=json.loads((P/'inputs.json').read_text());assert not verify(pins);runtime=read_runtime();merge_pins(pins,runtime['pins'])
 for f in [P/'graphics-witness-plan-review-v1.json',Path(__file__).resolve(),M,CONTRACT/'runtime_contract.py',CONTRACT/'runtime-preflight.json',P/'status.json',P/'inputs.json']:pins[str(f)]=sha(f)
 cpu=Path(review['requires_actual_CPU_presentation0_before_GL']);actual_cpu=json.loads(cpu.read_text());assert actual_cpu['state']=='terminal'and actual_cpu['exit']==0 and not actual_cpu['input_drift']and actual_cpu['source']==review['CPU_presentation_proof']['source'];pins[str(cpu)]=sha(cpu);assert sha(cpu)==review['CPU_presentation_proof']['sha256'];summary=Path(review['CPU_presentation_proof']['verified_summary']);assert sha(summary)==review['CPU_presentation_proof']['summary_sha256'];pins[str(summary)]=sha(summary)
 forecast=review['independent_witness_forecast'];assert sha(forecast['path'])==forecast['sha256'];pins[forecast['path']]=forecast['sha256']
 for failure in review['prior_failures']:
  assert sha(failure['path'])==failure['sha256'];pins[failure['path']]=failure['sha256']
 imported=review['original_imported_GLB'];assert sha(imported['path'])==imported['sha256'];pins[imported['path']]=imported['sha256']
 state={'state':'preparing','source':a.reviewed_source,'product':'1bc13125','scope':review['scope'],'phase':a.phase,'steps':[],'exit':1,'pid':os.getpid()};lease=None;stop=threading.Event()
 observer=R/'artifacts/authoring-eligible-capacity-arc-20261111/device-auth-release.so';helper=R/'artifacts/strict-arc-20261111/control/mount_identity.py';cert=None
 if a.phase=='arc':
  build=observer.parent/'observer-build.json';j=json.loads(build.read_text());row=next(x for x in j['profiles']if x['profile']=='release');assert row['exit']==0 and sha(observer)==row['elf_sha256'];assert sha(observer.parent/'device-auth.cpp')=='f13b90442862bdc64bd0e707a728305a68ecd45d726d54a09982b6c1bdae260e';assert sha(helper)=='1e2c6a322ae8797c78f9a2693d7e2e18aab9dd8d6472babbeb81334971904c81'
  for f in [observer,build,observer.parent/'device-auth.cpp',helper]:pins[str(f)]=sha(f)
  spec=importlib.util.spec_from_file_location('certified_mount_identity',helper);cert=importlib.util.module_from_spec(spec);spec.loader.exec_module(cert)
  previous=json.loads((P/(a.software_tag) /'status.json').read_text());assert previous['state']=='terminal'and previous['exit']==0 and previous['phase']=='software'and not previous['input_drift'] and previous['source']==a.reviewed_source;pins[str(P/a.software_tag/'status.json')]=sha(P/a.software_tag/'status.json')
 env={k:v for k,v in os.environ.items()if not k.startswith(('DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for k in ['LD_PRELOAD','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','XR_RUNTIME_JSON','ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(k,None)
 env.update(LD_LIBRARY_PATH=str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',LP_NUM_THREADS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',EGL_PLATFORM='surfaceless',XR_RUNTIME_JSON=str(out/'no-physical-runtime.json'))
 if a.phase=='software':env['LIBGL_ALWAYS_SOFTWARE']='1'
 else:env.update(LD_PRELOAD=str(observer),DRI_PRIME='pci-0000_03_00_0',MESA_LOADER_DRIVER_OVERRIDE='iris',__EGL_VENDOR_LIBRARY_FILENAMES='/usr/share/glvnd/egl_vendor.d/50_mesa.json')
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(out/leaf);Path(env[key]).mkdir(mode=0o700)
 def save():write(out/'status.json',state)
 def execute(name,cmd,case_env,collect=False):
  fast={'fds':set(),'rows':set(),'samples':0};thread=None;stop.clear();root=None
  def progress(row):
   nonlocal thread,root
   state['live']={'name':name,**row};save()
   if not collect or thread:return
   root={'pid':row['pid'],'start':row['start'],'pgrp':row['pgrp']}
   def sample():
    while not stop.is_set():
     now=monitor.identity(root['pid'])
     if not now or any(now[k]!=root[k]for k in root):return
     try:
      fast['rows'].update(Path('/proc',str(root['pid']),'maps').read_text().splitlines());fast['samples']+=1
      for f in Path('/proc',str(root['pid']),'fd').iterdir():
       try:
        value=os.readlink(f)
        if value.startswith('/dev/dri/'):fast['fds'].add(value)
       except OSError:pass
     except OSError:pass
     stop.wait(.001)
   thread=threading.Thread(target=sample,daemon=True);thread.start()
  row=monitor.run(cmd,cwd=out,env=case_env,log=out/(name+'.log'),timeout=900,max_rss=4*1024**3,progress=progress);stop.set()
  if thread:thread.join(timeout=3);assert not thread.is_alive()
  row.update(name=name,log_sha256=sha(out/(name+'.log')));state['steps'].append(row);state.pop('live',None);save();print(name,row.get('exit'),flush=True);assert row['exit']==0 and 'error'not in row and not row['signals'],(name,row)
  return (out/(name+'.log')).read_text(),row,fast
 try:
  assert not verify(pins);lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);state['lease']={'owner_pid':os.getpid(),'owner_identity':monitor.identity(os.getpid()),'acquired_epoch':time.time(),'before_any_built_product':True};save()
  plain=dict(env);plain.pop('LD_PRELOAD',None)
  for name,prod in linked['products'].items():
   text,_,_=execute('ldd-'+name,['ldd',prod['path']],plain);assert 'not found'not in text
   for f in re.findall(r'(/[^\s()]+)',text):
    if Path(f).is_file():assert f in pins and sha(f)==pins[f],('Unpinned actual linked runtime provider',f)
  write(out/'inputs-before.json',pins)
  cpu_text,cpu_row,cpu_fast=execute('cpu-presentation',[linked['products']['artist']['path'],'--cc0-presentation-cpu'],plain,True);assert cpu_text.count('CC0_PRESENTATION baseline=')==4 and 'PASS 44 genuine CC0 public presentation factor controls (no GL)'in cpu_text and 'ACTUAL_RENDERER'not in cpu_text and 'Native XR graphics'not in cpu_text and not cpu_fast['fds']
  for case in review['matrix']:
   name=case['arguments'][1].split('/')[-1];binary='prepared'if case['binary'].startswith('prepared')else'artist';cmd=[linked['products'][binary]['path'],case['arguments'][0],str(out/name)];case_env=dict(env)
   if a.phase=='arc':case_env['DOME_MARKER_DEVICE_REPORT']=str(out/(name+'-device'))
   text,row,fast=execute(name,cmd,case_env,True);assert 'ACTUAL_RENDERER 'in text and 'PASS 'in text
   if a.phase=='software':assert 'llvmpipe'in text.lower(),('Software renderer not authenticated',name)
   if name=='prepared':assert text.count('PREPARED_RENDER_CASE ')==case['cases'] and text.count('PREPARED_RENDER_POINT ')==case['cases']*4
   else:assert text.count('ARTIST_RENDER_CASE ')==case['cases'] and text.count('ARTIST_RENDER_POINT ')==case['cases']*len(case['probes'])
   if name=='import':assert sha(out/name/'authored-normal-tangent.vrm')==imported['sha256'], 'Authentic imported source bytes changed'
   if name=='cc0':
    assert text.count('CC0_WITNESS_SELECTION ')==4
    for baseline,triangle in [('vroid-beta-female',36),('vroid-beta-male',56)]:
     for posed in [0,1]:assert ('CC0_WITNESS_SELECTION baseline='+baseline+' posed='+str(posed)+' triangle='+str(triangle)+' original_scene_and_pose_unchanged=1')in text
   images={str(f):sha(f)for f in (out/name).rglob('*.png')};assert len(images)==case['cases']*(1+3*len(case['probes'])),(name,'Missing full PNG witnesses',len(images));row['PNGs']=images
   rows=set(fast['rows']);device=None
   if a.phase=='arc':
    folder=out/(name+'-device');device=(folder/'device.txt').read_text();context=folder/'context-maps.txt';rows.update(context.read_text().splitlines());pins[str(context)]=sha(context);pins[str(folder/'device.txt')]=sha(folder/'device.txt')
    assert all(s in text for s in ['STRICT_MARKER_ACTUAL','STRICT_MARKER_DEVICE','STRICT_MARKER_OPEN_FD'])and'STRICT_MARKER_REFUSAL'not in text
    assert 'A770'in device and'render_node=/dev/dri/renderD129'in device and'/0000:03:00.0'in device and'vendor_id=0x8086'in device and'device_id=0x56a0'in device and'/dev/dri/renderD129'in fast['fds']and fast['samples']>0
    assert Path('/sys/dev/char/226:129/device/driver').resolve().name=='i915'
   mapped={}
   for value in rows:
    fields=value.split(None,5)
    if len(fields)!=6 or not fields[5].startswith('/')or fields[5].endswith('(deleted)'):continue
    path=Path(fields[5])
    try:
     with path.open('rb')as f:magic=f.read(4)
     if magic!=b'\x7fELF':continue
    except OSError:continue
    assert str(path)in pins and sha(path)==pins[str(path)],('Unpinned mapped ELF',str(path));record={'row':value}
    if cert:
     major,minor=(int(x,16)for x in fields[3].split(':'));record['certified_identity']=cert.certify_mapping(path,os.makedev(major,minor),int(fields[4]),pid='self')
    mapped.setdefault(str(path),{'sha256':pins[str(path)],'rows':[]})['rows'].append(record)
   if a.phase=='arc':assert str(observer)in mapped
   row.update(mapped_ELFs=mapped,live_DRM_FDs=sorted(fast['fds']),live_samples=fast['samples'],device_report=device);write(out/(name+'-map-rows.json'),sorted(rows));save()
  state['exit']=0
 except BaseException as e:state['error']=repr(e)
 finally:
  stop.set();state['input_drift']=verify(pins);state['exit']=state['exit']or int(bool(state['input_drift']));write(out/'inputs-final.json',pins)
  if lease:state['lease']['released_epoch']=time.time();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
  state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
 return state['exit']
if __name__=='__main__':
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--phase',choices=['software','arc'],required=True);a.add_argument('--output-tag');a.add_argument('--software-tag');a.add_argument('--reviewed-source');a.add_argument('--execute',action='store_true');raise SystemExit(main(a.parse_args()))
