import json,hashlib,subprocess,os,time,signal,resource,shlex
from pathlib import Path
p=Path(__file__).resolve().parent;j=json.loads((p/'compile-plan.json').read_text());source=Path(j['source']);pins={};state={'state':'running','scope':j['scope'],'steps':[],'exit':1}
def sha(f):
 with Path(f).open('rb') as s:return hashlib.file_digest(s,'sha256').hexdigest()
def save():(p/'compile-status.json').write_text(json.dumps(state,indent=2)+'\n')
def limits():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
def run(name,cmd):
 entry={'name':name,'command':cmd,'started':time.time()};state['steps'].append(entry);save()
 with (p/(name+'.log')).open('w') as f:
  proc=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,preexec_fn=limits);entry['pid']=proc.pid;save()
  try:code=proc.wait(timeout=900)
  except BaseException:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();raise
 entry.update(exit=code,seconds=time.time()-entry['started'],log_sha256=sha(p/(name+'.log')));save();print(name,code,flush=True);assert code==0
for f in subprocess.check_output(['git','ls-files','-z'],cwd=source,text=True).split('\0'):
 if f and (source/f).is_file():pins[str(source/f)]=sha(source/f)
for row in j['commands']:pins[str(source/row['file'])]=sha(source/row['file'])
for f in ['/usr/bin/c++','/usr/bin/cc','/usr/bin/ar','/usr/bin/ranlib']:pins[f]=sha(f)
pins[str(p/'compile-plan.json')]=sha(p/'compile-plan.json');pins[str(Path(__file__).resolve())]=sha(__file__)
try:
 for i,row in enumerate(j['commands']):
  cmd=row['command'].copy();dep=p/(str(i)+'.preprocess.d');pre=cmd.copy();at=pre.index('-o');del pre[at:at+2];pre.remove('-c');at=pre.index('-MF');del pre[at:at+2];pre.remove('-MMD');pre+=['-M','-MF',str(dep),'-MT','owner.o'];run('preprocess-'+str(i),pre)
  for f in shlex.split(dep.read_text().replace('\\\n',' ').split(':',1)[1]):pins[str(Path(f).resolve())]=sha(f)
 (p/'compile-inputs.json').write_text(json.dumps(pins,indent=2)+'\n')
 for i,row in enumerate(j['commands']):run('compile-'+str(i),row['command'])
 state['exit']=0
except BaseException as e:state['error']=repr(e)
finally:
 state['input_drift']=[f for f,h in pins.items()if not Path(f).is_file()or sha(f)!=h];state['exit']=state['exit']or int(bool(state['input_drift']));state['state']='terminal';save();print(json.dumps({k:state.get(k)for k in ['state','exit','input_drift','error']}),flush=True)
raise SystemExit(state['exit'])
