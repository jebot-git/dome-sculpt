"""Read-only forecast from unchanged original GLB, no product/GL execution."""
import math,struct,json,hashlib,io,re
from pathlib import Path
from PIL import Image
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent;INPUT=R/'artifacts/artist-prepared-graphics-link-20261115/software-v1/import/authored-normal-tangent.vrm';LOG=INPUT.parent.parent/'import.log'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def mul(a,s):return tuple(x*s for x in a)
def sub(a,b):return add(a,mul(b,-1))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def unit(a):
 n=math.sqrt(dot(a,a));assert n>1e-20 and math.isfinite(n);return mul(a,1/n)
def weighted(a,b):return tuple(sum(a[k][c]*b[k]for k in range(3))for c in range(len(a[0])))
def rotated(a,theta):
 c,s=math.cos(theta),math.sin(theta);return(c*a[0]+s*a[2],a[1],-s*a[0]+c*a[2])
data=INPUT.read_bytes();magic,version,size=struct.unpack_from('<III',data);assert magic==0x46546c67 and version==2 and size==len(data);length,tag=struct.unpack_from('<II',data,12);j=json.loads(data[20:20+length]);blen,btag=struct.unpack_from('<II',data,20+length);binary=data[28+length:28+length+blen]
def accessor(index):
 a=j['accessors'][index];v=j['bufferViews'][a['bufferView']];count={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']];fmt={5126:'f',5125:'I'}[a['componentType']];start=v.get('byteOffset',0)+a.get('byteOffset',0);return [struct.unpack_from('<'+fmt*count,binary,start+i*v.get('byteStride',count*4))for i in range(a['count'])]
primitive=j['meshes'][0]['primitives'][0];attrs=primitive['attributes'];positions=accessor(attrs['POSITION']);normals=accessor(attrs['NORMAL']);tangents=accessor(attrs['TANGENT']);uv1=accessor(attrs['TEXCOORD_1']);indices=[v[0]for v in accessor(primitive['indices'])];target=primitive['targets'][0];dp,dn,dt=[accessor(target[k])for k in ['POSITION','NORMAL','TANGENT']];weight=j['nodes'][1]['weights'][0];positions=[mul(add(a,mul(b,weight)),j['nodes'][1]['scale'][0])for a,b in zip(positions,dp)];normals=[unit(add(a,mul(b,weight)))for a,b in zip(normals,dn)];tangents=[unit(add(a[:3],mul(b,weight)))for a,b in zip(tangents,dt)]
mat=j['materials'][0];slot=mat['normalTexture'];transform=slot['extensions']['KHR_texture_transform'];assert transform['texCoord']==1;im=j['images'][j['textures'][slot['index']]['source']];view=j['bufferViews'][im['bufferView']];png=binary[view['byteOffset']:view['byteOffset']+view['byteLength']];image=Image.open(io.BytesIO(png)).convert('RGBA');pixels=list(image.getdata());assert image.size==(2,2)
def encoded(uv):
 u,v=uv[0]*transform['scale'][0],uv[1]*transform['scale'][1];c,s=math.cos(transform['rotation']),math.sin(transform['rotation']);u,v=c*u-s*v+transform['offset'][0],s*u+c*v+transform['offset'][1];x,y=(u-math.floor(u))*2-.5,(v-math.floor(v))*2-.5;ix,iy=math.floor(x),math.floor(y);out=[0.,0.,0.]
 for dy in range(2):
  for dx in range(2):
   w=(x-ix if dx else 1-x+ix)*(y-iy if dy else 1-y+iy);p=pixels[((iy+dy)%2)*2+(ix+dx)%2]
   for k in range(3):out[k]+=p[k]/255*w
 return out
def mapped(bary):
 ids=indices[:3];n=unit(weighted([normals[k]for k in ids],bary));t=unit(weighted([tangents[k]for k in ids],bary));b=unit(cross(n,t));uv=weighted([uv1[k]for k in ids],bary);q=encoded(uv);q=unit(((q[0]*2-1)*slot['scale'],(q[1]*2-1)*slot['scale'],q[2]*2-1));return unit(add(add(mul(t,q[0]),mul(b,q[1])),mul(n,q[2]))),n,uv
light=unit((-.4,.8,.7));g=((136/255+.055)/1.055)**2.4
def rgb(n):
 ratio=max(0,min(1,(dot(n,light)+1)/2));gi=.175+.0075*n[1];color=[g*(q+(1-q)*ratio+gi)for q in [.25,.3,.35]]
 return [round((12.92*c if c<=.0031308 else 1.055*c**(1/2.4)-.055)*255)for c in color]
pts=[positions[k]for k in indices[:3]];ex,ey=sub(pts[1],pts[0]),sub(pts[2],pts[0]);center=mul(add(add(*pts[:2]),pts[2]),1/3);axisx=unit(ex);normal=unit(cross(ex,ey));axisy=unit(cross(normal,axisx));span=max(math.sqrt(dot(a,a))for a in [ex,ey,sub(pts[2],pts[1])])*.85
def probe(x,y,theta=0):
 pos=add(center,add(mul(axisx,((x+.5)/96*2-1)*span),mul(axisy,((y+.5)/96*2-1)*span)));r=sub(pos,pts[0]);d00,d01,d11,d20,d21=dot(ex,ex),dot(ex,ey),dot(ey,ey),dot(r,ex),dot(r,ey);den=d00*d11-d01*d01;v,w=(d11*d20-d01*d21)/den,(d00*d21-d01*d20)/den;bary=(1-v-w,v,w)
 if min(bary)<=.05:return None
 mappedn,unmapped,uv=mapped(bary);mappedn,unmapped=rotated(mappedn,theta),rotated(unmapped,theta);correct,omitted,wrong=rgb(mappedn),rgb(unmapped),rgb((0,0,1));return {'xy':[x,y],'bary':bary,'sourceUV1':uv,'mapped':mappedn,'unmapped':unmapped,'world_y_rotation_radians':theta,'correct':correct,'omitted':omitted,'wrong_worldZ':wrong,'wrong_gap':max(abs(a-b)for a,b in zip(correct,wrong)),'omitted_gap':max(abs(a-b)for a,b in zip(correct,omitted))}
original=[probe(x,y)for x,y in [(48,48),(45,47),(49,45),(50,50)]];scanned=[probe(x,y)for x in range(96)for y in range(96)];scanned=[a for a in scanned if a];best=max(scanned,key=lambda a:min(a['wrong_gap'],a['omitted_gap']));rotations=[]
for degrees in [-90,-75,-60,-45,-30,-15,15,30,45,60,75,90]:
 points=[probe(x,y,math.radians(degrees))for x,y in [(48,48),(45,47),(49,45),(50,50)]];rotations.append({'degrees':degrees,'min_wrong':min(a['wrong_gap']for a in points),'min_omitted':min(a['omitted_gap']for a in points),'max_wrong':max(a['wrong_gap']for a in points),'max_omitted':max(a['omitted_gap']for a in points),'points':points})
report={'scope':'Independent read-only forecast only, not product/GL qualification. Original input and material untouched; proposed world rotation changes only rigid presentation/light relationship and matching face projection.','source_input':{'path':str(INPUT),'sha256':sha(INPUT),'original_node_weight':weight,'normal_PNG_sha256':hashlib.sha256(png).hexdigest()},'source_material':mat,'source_script_sha256':sha(__file__),'actual_log':{'path':str(LOG),'sha256':sha(LOG)},'original_fixed_probes':original,'same_view_best_interior_probe':best,'rigid_view_rotation_forecasts':rotations,'interior_probes_scanned':len(scanned)};Path(P/'forecast-v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'original':original,'best_same_view':best,'rotations':[{k:v for k,v in a.items()if k!='points'}for a in rotations]},indent=2))
