"""Read-only four-real-scene triangle forecast, independent pose/ray/shading math."""
import os,resource,time
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
import numpy as np
from pathlib import Path
P=Path(__file__).resolve().parent
prefix=(P/'forecast-cc0-v1.py').read_text().split('original=[evaluate(geometry(x,y),light)for x,y in fixed]')[0]
exec(compile(prefix,str(P/'forecast-cc0-v1.py'),'exec'),globals())
def joint_matrix(t):
 w,x,y,z=t['rotation'];m=np.eye(4);m[:3,:3]=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]];m[:3,:3]=m[:3,:3]@np.diag(t['scale']);m[:3,3]=t['translation'];return m
def hierarchy(bones,local):
 result=[None]*len(bones)
 def get(i):
  if result[i]is None:result[i]=(get(bones[i]['parent'])if bones[i]['parent']>=0 else np.eye(4))@joint_matrix(local[i])
  return result[i]
 return[get(i)for i in range(len(bones))]
def pbr_rgb(n,point):
 base=[g*v for v in sample(binding['roles'][0]['image'],point['uv'],True)];out=[.045*v for v in base];V=point['view'];directions=[unit((-.4,.8,.7)),unit((.7,.2,-.4))];power=[(3.8,3.8,3.8),(.65,.8,1)]
 for L,energy in zip(directions,power):
  H=unit(add(V,L));nv=max(dot(n,V),.0001);nl=max(dot(n,L),0);vh=max(dot(V,H),0);f=.04+.96*(1-vh)**5;geom=nv/(.5*nv+.5)*nl/(.5*nl+.5)
  for k in range(3):out[k]+=((1-f)*base[k]/math.pi+geom*f/(math.pi*max(4*nv*nl,.0001)))*energy[k]*nl
 values=[x/(x+1)for x in out];assert all(math.isfinite(x)for x in values);return[round(max(0,min(1,12.92*c if c<=.0031308 else 1.055*c**(1/2.4)-.055))*255)for c in values]
def pbr_direction(point):
 ns=[unit(normals[c])for c in corners];ts=[unit(tangents[c][:3])for c in corners];bs=[mul(cross(ns[k],ts[k]),tangents[corners[k]][3])for k in range(3)];N,T,B=unit(weighted(ns,point['bary'])),unit(weighted(ts,point['bary'])),unit(weighted(bs,point['bary']));e=sample(binding['roles'][2]['image'],point['uv']);q=((e[0]*2-1)*params['normal_scale'],(e[1]*2-1)*params['normal_scale'],e[2]*2-1);return unit(add(add(mul(T,q[0]),mul(B,q[1])),mul(N,q[2])))
def rays_front(points,tri):
 D=np.asarray(mul(face,-1));h=np.cross(np.broadcast_to(D,E2.shape),E2);det=np.einsum('ij,ij->i',E1,h);valid=np.abs(det)>1e-14;inv=np.divide(1.,det,out=np.zeros_like(det),where=valid);found=[]
 for point in points:
  origin=np.asarray(add(point,mul(face,2)));ss=origin-A;u=np.einsum('ij,ij->i',ss,h)*inv;q=np.cross(ss,E1);v=(q@D)*inv;distance=np.einsum('ij,ij->i',E2,q)*inv;ok=valid&(u>=0)&(v>=0)&(u+v<=1)&(distance>=0)&(distance<=4);dist=np.where(ok,distance,np.inf);front=int(np.argmin(dist));actual=float(dist[front]);other=dist.copy();other[tri]=np.inf;gap=float(np.min(other)-actual);found.append({'triangle':front,'distance':actual,'next_other_gap':gap})
  if front!=tri or not math.isfinite(actual):return False,found
 return True,found
reports=[]
for baseline in ['female','male']:
 for posed in [False,True]:
  started=time.monotonic();path=INPUT.parent/('vroid-beta-'+baseline+('-posed'if posed else'-rest')+'.dsculpt');j=cbor2.loads(path.read_bytes());o=next(o for o in j['objects']if'Body_00_SKIN'in o['name']);binding=j['source_materials']['bindings'][o['material_bindings']];pool=j['source_materials']['normal_frames'];set_=pool['sets'][binding['frames']];assert set_['mtoon']==set_['pbr']and not set_['targets'];frame=pool['frames'][set_['mtoon']];params=binding['material']['draft']['parameters'];assert not frame['targets'];mesh=o['painted']['mesh'];positions=unpack(mesh['positions']);normals=unpack(frame['normals']);tangents=unpack(frame['tangents'],4);uv=unpack(mesh['uv'],2);indices=[v[0]for v in unpack(mesh['indices'],1,'I')];images=j['source_images'];deform=o['deformation'];assert deform['morphs']is None and not deform['morph_weights'];assert deform['skeleton']['version']==1
  if posed:
   bones=deform['skeleton']['bones'];rest=hierarchy(bones,bones);posed_world=hierarchy(bones,deform['pose']);matrices=[a@np.linalg.inv(b)for a,b in zip(posed_world,rest)];normal_matrices=[np.linalg.inv(m[:3,:3]).T for m in matrices];weights=deform['skin']['vertices'];positions=[tuple(sum((m@np.asarray((*p,1)))[:3]*w for joint,w in weights[v]for m in [matrices[joint]]))for v,p in enumerate(positions)];normals=[tuple(sum(normal_matrices[joint]@np.asarray(n)*w for joint,w in weights[indices[c]]))for c,n in enumerate(normals)];tangents=[(*tuple(sum(matrices[joint][:3,:3]@np.asarray(t[:3])*w for joint,w in weights[indices[c]])),t[3])for c,t in enumerate(tangents)]
  triangles=np.asarray(positions)[np.asarray(indices).reshape(-1,3)];A=triangles[:,0];E1=triangles[:,1]-A;E2=triangles[:,2]-A;counts={'triangles':len(triangles),'well_conditioned':0,'old_geometry_filter':0,'all4_interior':0,'both_shader_gap14':0,'all4_frontmost':0};candidates=[];first_old=None;pbr_calibration=[]
  for triangle in range(len(triangles)):
   corners=list(range(triangle*3,triangle*3+3));ids=[indices[c]for c in corners];pts=[positions[i]for i in ids];ex,ey=sub(pts[1],pts[0]),sub(pts[2],pts[0]);lengthmax=max(math.sqrt(dot(a,a))for a in [ex,ey,sub(pts[2],pts[1])]);normalcross=cross(ex,ey)
   if math.sqrt(dot(normalcross,normalcross))<lengthmax*lengthmax*.15:continue
   counts['well_conditioned']+=1;face=unit(normalcross);axisx=unit(ex);axisy=unit(cross(face,axisx));center=mul(add(add(*pts[:2]),pts[2]),1/3);span=lengthmax*.85;camera=add(center,mul(face,2));points=[geometry(x,y)for x,y in fixed]
   if any(p is None for p in points):continue
   counts['all4_interior']+=1
   # Center role-frame condition is retained from the old source selector.
   centerpoint=geometry(47.5,47.5);pn=pbr_direction(centerpoint)
   if pn[0]<.7 or abs(pn[2])>.6 or dot(face,pn)<.3:continue
   counts['old_geometry_filter']+=1;evaluated=[evaluate(p,light)for p in points];pbr=[]
   for p in points:
    n=pbr_direction(p);correct=pbr_rgb(n,p);wrong=pbr_rgb((0,0,1),p);pbr.append({'xy':p['xy'],'normal':n,'correct_RGB':correct,'wrong_RGB':wrong,'gap':max(abs(a-b)for a,b in zip(correct,wrong))})
   if baseline=='female'and not posed and triangle==31:pbr_calibration=pbr
   rays=[add(center,add(mul(axisx,((x+.5)/96*2-1)*span),mul(axisy,((y+.5)/96*2-1)*span)))for x,y in fixed]
   if first_old is None:
    visible,hits=rays_front([center],triangle)
    if visible:first_old={'triangle':triangle,'MT0_gaps':[v['wrong_gap']for v in evaluated],'PBR_gaps':[v['gap']for v in pbr]}
   if min(v['wrong_gap']for v in evaluated)<14 or min(v['gap']for v in pbr)<14:continue
   counts['both_shader_gap14']+=1;visible,hits=rays_front(rays,triangle)
   if not visible:continue
   counts['all4_frontmost']+=1;candidates.append({'triangle':triangle,'MT0_min_gap':min(v['wrong_gap']for v in evaluated),'MT0_max_gap':max(v['wrong_gap']for v in evaluated),'PBR_min_gap':min(v['gap']for v in pbr),'PBR_max_gap':max(v['gap']for v in pbr),'frontmost':hits,'MT0_points':evaluated,'PBR_points':pbr,'face_normal':face,'camera':camera})
  report={'baseline':baseline,'posed':posed,'input':{'path':str(path),'sha256':sha(path)},'counts':counts,'first_old':first_old,'candidates':candidates,'PBR_original31_calibration':pbr_calibration,'seconds':time.monotonic()-started};reports.append(report);print(json.dumps({k:v for k,v in report.items()if k not in ['candidates','PBR_original31_calibration']}),flush=True);print('first_candidates',[(c['triangle'],c['MT0_min_gap'],c['PBR_min_gap'])for c in candidates[:8]],flush=True)
  (P/'alternative-triangles-v1.json').write_text(json.dumps({'scope':'Independent read-only genuine four-input current-normal weighted inverse-transpose pose, both shader predictions, all4 interior/frontmost rays; not GL acceptance.','source_script_sha256':sha(__file__),'reports':reports},indent=2)+'\n')
