"""Independent read-only CBOR/image/role-frame toon forecast, no product or GL."""
import cbor2,math,struct,json,hashlib,re
from pathlib import Path
R=Path('/home/blux/de-xr/dome-sculpt');P=Path(__file__).resolve().parent;INPUT=R/'artifacts/artist-prepared-release-cc0-rss-v5-20261115/cc0-bake-output/vroid-beta-female-rest.dsculpt';LOG=R/'artifacts/artist-normal-final-link-20261115/software-final-v1/cc0.log'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def mul(a,s):return tuple(x*s for x in a)
def sub(a,b):return add(a,mul(b,-1))
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def cross(a,b):return(a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def unit(a):
 n=math.sqrt(dot(a,a));assert math.isfinite(n)and n>1e-20;return mul(a,1/n)
def weighted(a,b):return tuple(sum(a[k][c]*b[k]for k in range(3))for c in range(len(a[0])))
def rotate(a,yaw):
 c,s=math.cos(yaw),math.sin(yaw);return(c*a[0]+s*a[2],a[1],-s*a[0]+c*a[2])
def unpack(b,n=3,kind='f'):return list(struct.iter_unpack('<'+kind*n,b))
j=cbor2.loads(INPUT.read_bytes());o=next(o for o in j['objects']if'Body_00_SKIN'in o['name']);mesh=o['painted']['mesh'];binding=j['source_materials']['bindings'][o['material_bindings']];set_=j['source_materials']['normal_frames']['sets'][binding['frames']];frame=j['source_materials']['normal_frames']['frames'][set_['mtoon']];params=binding['material']['draft']['parameters'];assert not o['deformation']['pose']and not o['deformation']['morph_weights']and not frame['targets']and not set_['targets'];assert o['rotation']==[0,0,0,1]and o['translation']==[0,0,0]and o['scale']==1;assert j['groups'][0]['rotation']==[0,0,0,1]and j['groups'][0]['translation']==[0,0,0]and j['groups'][0]['scale']==1
positions=unpack(mesh['positions']);normals=unpack(frame['normals']);tangents=unpack(frame['tangents'],4);uv=unpack(mesh['uv'],2);indices=[v[0]for v in unpack(mesh['indices'],1,'I')];images=j['source_images'];triangle=31;corners=list(range(triangle*3,triangle*3+3));ids=[indices[c]for c in corners];pts=[positions[i]for i in ids];ex,ey=sub(pts[1],pts[0]),sub(pts[2],pts[0]);face=unit(cross(ex,ey));axisx=unit(ex);axisy=unit(cross(face,axisx));center=mul(add(add(*pts[:2]),pts[2]),1/3);span=max(math.sqrt(dot(a,a))for a in [ex,ey,sub(pts[2],pts[1])])*.85;camera=add(center,mul(face,2));g=((136/255+.055)/1.055)**2.4;shade_factors=(g*.25,g*.30,g*.35)
def sample(index,coord,srgb=False):
 im=images[index];x,y=(coord[0]%1)*im['width']-.5,(coord[1]%1)*im['height']-.5;ix,iy=math.floor(x),math.floor(y);out=[0.,0.,0.]
 for dy in range(2):
  for dx in range(2):
   w=(x-ix if dx else 1-x+ix)*(y-iy if dy else 1-y+iy);at=(((iy+dy)%im['height'])*im['width']+(ix+dx)%im['width'])*4
   for k in range(3):
    v=im['rgba'][at+k]/255
    if srgb:v=v/12.92 if v<=.04045 else((v+.055)/1.055)**2.4
    out[k]+=w*v
 return out
def facing(n,view):
 n=unit(n);return mul(n,-1)if dot(n,view)<0 else n
def geometry(x,y,yaw=0):
 p=add(center,add(mul(axisx,((x+.5)/96*2-1)*span),mul(axisy,((y+.5)/96*2-1)*span)));r=sub(p,pts[0]);d00,d01,d11,d20,d21=dot(ex,ex),dot(ex,ey),dot(ey,ey),dot(r,ex),dot(r,ey);den=d00*d11-d01*d01;v,w=(d11*d20-d01*d21)/den,(d00*d21-d01*d20)/den;bary=(1-v-w,v,w)
 if min(bary)<=.05:return None
 ns=[unit(normals[c])for c in corners];ts=[unit(tangents[c][:3])for c in corners];bs=[mul(cross(ns[k],ts[k]),tangents[corners[k]][3])for k in range(3)];N,T,B=weighted(ns,bary),weighted(ts,bary),weighted(bs,bary);coord=weighted([uv[k]for k in ids],bary);encoded=sample(binding['roles'][2]['image'],coord);q=unit(((encoded[0]*2-1)*params['normal_scale'],(encoded[1]*2-1)*params['normal_scale'],encoded[2]*2-1));mapped=unit(add(add(mul(T,q[0]),mul(B,q[1])),mul(N,q[2])));view=unit(sub(rotate(camera,yaw),rotate(p,yaw)));return{'xy':[x,y],'bary':bary,'uv':coord,'unoriented_mapped':rotate(mapped,yaw),'mapped':facing(rotate(mapped,yaw),view),'omitted':facing(rotate(unit(N),yaw),view),'wrong':facing((0,0,1),view),'view':view,'up':rotate(axisy,yaw),'yaw_degrees':math.degrees(yaw)}
def rgb(n,point,light):
 main=sample(binding['roles'][0]['image'],point['uv'],True);shade=sample(binding['roles'][1]['image'],point['uv'],True);lit=[v*g for v in main];dark=[v*f for v,f in zip(shade,shade_factors)];ratio=max(0,min(1,(dot(n,light)-params['shift'])/(1-params['shift'])));gi=.175+.0075*n[1];color=[min(lit[k],dark[k]*(1-ratio)+lit[k]*ratio+gi*lit[k])for k in range(3)];right=unit(cross(point['view'],point['up']));up=unit(cross(right,point['view']));matcap_uv=(.5-.5*dot(right,n),.5-.5*dot(up,n));matcap=sample(binding['roles'][5]['image'],matcap_uv,True);color=[a+b for a,b in zip(color,matcap)];assert all(math.isfinite(c)for c in color);return[round(max(0,min(1,12.92*c if c<=.0031308 else 1.055*c**(1/2.4)-.055))*255)for c in color],ratio,dot(n,light)
light=unit((-.4,.8,.7));fixed=[(48,48),(45,47),(49,45),(50,50)]
def evaluate(point,light):
 out={**point}
 for k in ['mapped','omitted','wrong']:
  out[k+'_RGB'],out[k+'_ratio'],out[k+'_dot_light']=rgb(point[k],point,light)
 out['wrong_gap']=max(abs(a-b)for a,b in zip(out['mapped_RGB'],out['wrong_RGB']));out['omitted_gap']=max(abs(a-b)for a,b in zip(out['mapped_RGB'],out['omitted_RGB']));return out
original=[evaluate(geometry(x,y),light)for x,y in fixed];calibration=[]
for match in re.finditer(r'ARTIST_RENDER_POINT label=vroid-beta-femalerestMT0 pbr=0 xy=(\d+),(\d+) actual=([\d,]+) expected=([\d,]+)',LOG.read_text()):
 xy=[int(match[1]),int(match[2])];pred=next(a for a in original if a['xy']==xy);actual=list(map(int,match[3].split(',')));wanted=list(map(int,match[4].split(',')));err=max(abs(a-b)for a,b in zip(actual,pred['mapped_RGB']));calibration.append({'xy':xy,'actual':actual,'ordinary_expected':wanted,'forecast':pred['mapped_RGB'],'forecast_error':err})
assert len(calibration)==4
scanned=[geometry(x,y)for x in range(96)for y in range(96)];scanned=[evaluate(a,light)for a in scanned if a];best=max(scanned,key=lambda a:a['wrong_gap']);sweep=[]
for azimuth in range(-180,181,15):
 for altitude in [-60,-30,0,30,60,75]:
  a,b=math.radians(azimuth),math.radians(altitude);direction=(math.cos(b)*math.sin(a),math.sin(b),math.cos(b)*math.cos(a));points=[evaluate(geometry(x,y),direction)for x,y in fixed];sweep.append({'azimuth_degrees':azimuth,'altitude_degrees':altitude,'direction':direction,'min_wrong_gap':min(p['wrong_gap']for p in points),'max_wrong_gap':max(p['wrong_gap']for p in points),'points':points})
rotations=[]
for degrees in [-90,-75,-60,-45,-30,-15,15,30,45,60,75,90]:
 points=[evaluate(geometry(x,y,math.radians(degrees)),light)for x,y in fixed];rotations.append({'canvas_yaw_degrees':degrees,'min_wrong_gap':min(p['wrong_gap']for p in points),'max_wrong_gap':max(p['wrong_gap']for p in points),'points':points})
report={'scope':'Independent read-only actual native CBOR public geometry/role/image equation forecast. No product/GL execution. Current once-gray presentation exactly declared; original input immutable.','input':{'path':str(INPUT),'sha256':sha(INPUT)},'actual_log':{'path':str(LOG),'sha256':sha(LOG)},'script_sha256':sha(__file__),'triangle':triangle,'face_normal':face,'camera':camera,'params':params,'fixture_current_gray':g,'fixture_shade':shade_factors,'calibration':calibration,'original_fixed_points':original,'same_view_interior_probe_count':len(scanned),'best_same_view_interior_probe':best,'directional_light_sweep_best':max(sweep,key=lambda a:a['min_wrong_gap']),'light_sweep':sweep,'canvas_yaw_sweep':rotations};(P/'forecast-v1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'calibration':calibration,'original_ratios':[{'xy':a['xy'],'mapped_dot':a['mapped_dot_light'],'mapped_ratio':a['mapped_ratio'],'wrong':a['wrong'],'wrong_dot':a['wrong_dot_light'],'wrong_ratio':a['wrong_ratio'],'gaps':[a['wrong_gap'],a['omitted_gap']]}for a in original],'best_interior':{'xy':best['xy'],'wrong_gap':best['wrong_gap'],'omitted_gap':best['omitted_gap']},'best_light':{k:v for k,v in report['directional_light_sweep_best'].items()if k!='points'},'yaw_sweep':[{k:v for k,v in a.items()if k!='points'}for a in rotations]},indent=2))
