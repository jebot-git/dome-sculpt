from pathlib import Path
import os,json,hashlib,subprocess,resource,time,signal,shutil
out=Path(__file__).parent;os.chdir(out);plan=json.loads((out/'plan.json').read_text());pins=dict(plan['input_pins']);resource.setrlimit(resource.RLIMIT_AS,(plan['resources']['RLIMIT_AS_bytes'],)*2)
def sha(path):
 digest=hashlib.sha256()
 with Path(path).open('rb') as file:
  for chunk in iter(lambda:file.read(4*1024*1024),b''):digest.update(chunk)
 return digest.hexdigest()
status={'terminal':False,'state':'running','exit_code':None,'driver_pid':os.getpid(),'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'product':plan['product'],'fixture':plan['fixture'],'commands':[]}
def record(): (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def verify():
 drift=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h]
 if drift:raise RuntimeError('Immutable input drift: '+str(drift))
def pin(p):
 p=Path(p)
 for q in [p,p.resolve()]:
  h=sha(q)
  if str(q) in pins and pins[str(q)]!=h:raise RuntimeError('Conflicting immutable expected input: '+str(q))
  pins[str(q)]=h
 return sha(p)
def dependencies(p):return shlex.split(p.read_text().replace('\\\n',' ').split(':',1)[1])
def identity(pid):
 try:
  v=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();return (v[19],int(v[2]))
 except (OSError,ValueError):return None
def process_sample(pid):
 try:
  directory=Path('/proc')/str(pid);v=(directory/'stat').read_text().rsplit(')',1)[1].split();rss=vmpeak=0
  for line in (directory/'status').read_text().splitlines():
   if line.startswith('VmRSS:'):rss=int(line.split()[1])*1024
   if line.startswith('VmPeak:'):vmpeak=int(line.split()[1])*1024
  return {'pid':pid,'pgrp':int(v[2]),'start':v[19],'rss':rss,'vmpeak':vmpeak}
 except (OSError,ValueError):return None
def run(argv,label):
 verify();entry={'argv':argv,'cwd':str(out),'label':label,'rss_limit':3*1024**3};status['commands'].append(entry);record();start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  child=subprocess.Popen(argv,cwd=out,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),start_new_session=True);owner=identity(child.pid);entry.update(pid=child.pid,identity=owner);record();peak=vmpeak=0;owned={};guard=None
  while child.poll() is None:
   samples=[]
   for directory in Path('/proc').iterdir():
    if directory.name.isdigit():
     value=process_sample(int(directory.name))
     if value and (value['pid']==os.getpid() or value['pgrp']==child.pid):samples.append(value)
   for value in samples:owned[(value['pid'],value['start'])]=value
   rss=sum(value['rss'] for value in samples);vm=sum(value['vmpeak'] for value in samples);peak=max(peak,rss);vmpeak=max(vmpeak,vm)
   if rss>3*1024**3:guard='aggregate_RSS_3GiB'
   elif time.monotonic()-start>900:guard='command_wall_900s'
   if guard:
    if identity(child.pid)==owner and owner and owner[1]==child.pid:os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:
     if identity(child.pid)==owner and owner and owner[1]==child.pid:os.killpg(child.pid,signal.SIGKILL)
     child.wait(timeout=5)
    break
   time.sleep(.05)
  code=child.wait();entry.update(exit_code=code,elapsed_seconds=time.monotonic()-start,peak_monitored_aggregate_RSS=peak,peak_monitored_aggregate_VmPeak=vmpeak,guard=guard,owned_identities=list(owned.values()));record();verify()
 if code or guard:raise RuntimeError('Command failed: '+label+' exit '+str(code)+' guard '+str(guard))

def archive_members(path):
 result=[];names=b''
 with Path(path).open('rb') as file:
  if file.read(8)!=b'!<arch>\n':raise RuntimeError('Expected genuine whole GNU archive')
  while True:
   header=file.read(60)
   if not header:break
   if len(header)!=60 or header[58:]!=b'`\n':raise RuntimeError('Malformed archive member')
   token=header[:16].decode().strip();size=int(header[48:58]);digest=hashlib.sha256()
   if token=='//':names=file.read(size)
   elif token in ['/','/SYM64/']:file.seek(size,1)
   else:
    name=names[int(token[1:]):].split(b'/\n',1)[0].decode() if token.startswith('/') else token.rstrip('/')
    remaining=size
    while remaining:
     chunk=file.read(min(4*1024*1024,remaining))
     if not chunk:raise RuntimeError('Truncated real archive member')
     digest.update(chunk);remaining-=len(chunk)
    result.append({'name':name,'bytes':size,'sha256':digest.hexdigest()})
   if size%2:file.seek(1,1)
 return result
try:
 verify();record();new=Path(plan['new_core']);original=Path(plan['original_core']);assert not new.exists();shutil.copyfile(original,new);status['copied_core_sha256']=sha(new);assert status['copied_core_sha256']==pins[str(original)];record()
 run(plan['actual_archiver_argv'],'archive-replace3');run(plan['actual_ranlib_argv'],'archive-index')
 before=archive_members(original);after=archive_members(new);assert [x['name'] for x in before]==[x['name'] for x in after]==plan['core_roster'];changed=[]
 for left,right in zip(before,after):
  if left['sha256']!=right['sha256']:changed.append(right['name'])
 expected={Path(path).name:want for path,want in plan['replacement_sha256'].items()};assert set(changed)==set(expected)
 for item in after:
  if item['name'] in expected:assert item['sha256']==expected[item['name']]
 assert len(after)-len(changed)==plan['expected_unchanged_members'];(out/'archive-members.json').write_text(json.dumps({'before':before,'after':after,'changed':changed,'original':str(original),'original_sha256':pins[str(original)],'new':str(new),'new_sha256':pin(new)},indent=2)+'\n')
 for index,command in enumerate(plan['commands']):
  run(command['argv'],'link-'+str(index));dep=Path(command['actual_link_depfile']);logical=dep.read_text().replace('\\\n',' ').splitlines()[0];paths=__import__('shlex').split(logical.split(':',1)[1]);actual=[]
  for literal in paths:
   path=Path(literal);path=path if path.is_absolute() else out/path;actual.append({'literal':literal,'actual':str(path),'sha256':pin(path)})
  status['commands'][-1].update(elf=command['elf'],elf_sha256=sha(command['elf']),actual_link_depfile_sha256=sha(dep),actual_inputs=actual);record()
 verify();status.update(state='complete',exit_code=0)
except BaseException as error:status.update(state='failed',exit_code=1,error=str(error))
finally:
 status['input_drift']=[path for path,want in pins.items() if not Path(path).exists() or sha(path)!=want];status['terminal']=True;(out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');record()
raise SystemExit(status['exit_code'])
