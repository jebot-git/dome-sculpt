from pathlib import Path
import os,json,hashlib,shlex,subprocess,resource,time,signal,shutil
out=Path(__file__).parent;os.chdir(out);plan=json.loads((out/'plan.json').read_text());pins=dict(plan['input_pins']);resource.setrlimit(resource.RLIMIT_AS,(plan['resource']['compiler_RLIMIT_AS'],)*2)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
status={'state':'running','terminal':False,'driver_pid':os.getpid(),'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'source_product':plan['product_commit'],'source_fixture':plan['fixture_commit'],'commands':[],'compiler_environment':{k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','CPATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','CFLAGS','CXXFLAGS']}}
def record(): (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def verify():
 drift=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h]
 if drift:raise RuntimeError('Immutable input drift: '+str(drift))
def pin(p):
 p=Path(p)
 for q in [p,p.resolve()]:
  h=sha(q)
  if str(q) in pins and pins[str(q)]!=h:raise RuntimeError('Conflicting immutable expected input: '+str(q))
  pins[str(q)]=h
 return sha(p)
def dependencies(p):return shlex.split(p.read_text().replace('\\\n',' ').split(':',1)[1])
def identity(pid):
 try:
  v=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();return (v[19],int(v[2]))
 except (OSError,ValueError):return None
def run(argv,label):
 verify();entry={'argv':argv,'cwd':str(out),'label':label};status['commands'].append(entry);record();start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  child=subprocess.Popen(argv,cwd=out,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),start_new_session=True);owner=identity(child.pid);entry.update(pid=child.pid,identity=owner);record()
  try:code=child.wait(timeout=900)
  except subprocess.TimeoutExpired:
   entry['timeout']=True
   if identity(child.pid)==owner and owner and owner[1]==child.pid:os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:
    if identity(child.pid)==owner and owner and owner[1]==child.pid:os.killpg(child.pid,signal.SIGKILL)
    child.wait(timeout=5)
   code=124
 entry.update(exit_code=code,elapsed_seconds=time.monotonic()-start);record();verify()
 if code:raise RuntimeError('Command failed: '+label+' exit '+str(code))
try:
 verify();record()
 probes={}
 for name in ['cc1plus','as','collect2','ld']:
  raw=subprocess.check_output(['/usr/bin/c++','-print-prog-name='+name],text=True).strip();actual=Path(raw) if '/' in raw else Path(shutil.which(raw) or '/nonexistent')
  if str(actual) not in pins and str(actual.resolve()) not in pins:raise RuntimeError('Unpinned selected backend: '+str(actual))
  pin(actual);probes[name]={'literal':raw,'actual':str(actual),'resolved':str(actual.resolve()),'sha256':sha(actual)}
 status['selected_backends']=probes;record()
 for index,c in enumerate(plan['commands']):
  a=c['argv'];pre=[];skip=False
  for arg in a:
   if skip:skip=False;continue
   if arg in ['-o','-MT','-MF']:skip=True;continue
   if arg in ['-c','-MD']:continue
   pre.append(arg)
  pre+=['-M','-MT',c['object'],'-MF',c['full_M_precheck']];run(pre,str(index)+'-full-M')
  expected=set(dependencies(Path(c['full_M_precheck'])))
  for p in expected:pin(p)
  (out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');verify();run(a,str(index)+'-whole-TU')
  actual=set(dependencies(Path(c['actual_full_depfile'])))
  if expected!=actual:raise RuntimeError('Actual compiler MD differs from full-M precheck: '+c['source'])
  for p in actual:pin(p)
  status['commands'][-1].update(source=c['source'],object_sha256=sha(c['object']),actual_MD_sha256=sha(c['actual_full_depfile']),dependency_count=len(actual));record()
 verify();status.update(exit_code=0,state='complete')
except BaseException as error:status.update(exit_code=1,state='failed',error=str(error))
finally:
 status['input_drift']=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h];status['terminal']=True;(out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');record()
raise SystemExit(status['exit_code'])
