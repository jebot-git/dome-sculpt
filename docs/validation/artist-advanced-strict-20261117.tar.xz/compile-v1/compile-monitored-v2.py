from pathlib import Path
import os,json,hashlib,shlex,subprocess,resource,time,signal,shutil
out=Path(__file__).parent;os.chdir(out);plan=json.loads((out/'plan.json').read_text());pins=dict(plan['input_pins']);resource.setrlimit(resource.RLIMIT_AS,(plan['resource']['compiler_RLIMIT_AS'],)*2)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
status={'state':'running','terminal':False,'driver_pid':os.getpid(),'plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'source_product':plan['product_commit'],'source_fixture':plan['fixture_commit'],'commands':[],'compiler_environment':{k:os.environ.get(k) for k in ['PATH','LANG','LC_ALL','CPATH','CPLUS_INCLUDE_PATH','GCC_EXEC_PREFIX','COMPILER_PATH','LIBRARY_PATH','CFLAGS','CXXFLAGS']}}
def record(): (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def verify():
 drift=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h]
 if drift:raise RuntimeError('Immutable input drift: '+str(drift))
def pin(p):
 p=Path(p)
 for q in [p,p.resolve()]:
  h=sha(q)
  if str(q) in pins and pins[str(q)]!=h:raise RuntimeError('Conflicting immutable expected input: '+str(q))
  pins[str(q)]=h
 return sha(p)
def dependencies(p):return shlex.split(p.read_text().replace('\\\n',' ').split(':',1)[1])
def identity(pid):
 try:
  v=(Path('/proc')/str(pid)/'stat').read_text().rsplit(')',1)[1].split();return (v[19],int(v[2]))
 except (OSError,ValueError):return None
def process_sample(pid):
 try:
  directory=Path('/proc')/str(pid);v=(directory/'stat').read_text().rsplit(')',1)[1].split();rss=vmpeak=0
  for line in (directory/'status').read_text().splitlines():
   if line.startswith('VmRSS:'):rss=int(line.split()[1])*1024
   if line.startswith('VmPeak:'):vmpeak=int(line.split()[1])*1024
  return {'pid':pid,'pgrp':int(v[2]),'start':v[19],'rss':rss,'vmpeak':vmpeak}
 except (OSError,ValueError):return None
def run(argv,label):
 verify();entry={'argv':argv,'cwd':str(out),'label':label,'rss_limit':3*1024**3};status['commands'].append(entry);record();start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:
  child=subprocess.Popen(argv,cwd=out,stdout=log,stderr=subprocess.STDOUT,env=os.environ.copy(),start_new_session=True);owner=identity(child.pid);entry.update(pid=child.pid,identity=owner);record();peak=vmpeak=0;owned={};guard=None
  while child.poll() is None:
   samples=[]
   for directory in Path('/proc').iterdir():
    if directory.name.isdigit():
     value=process_sample(int(directory.name))
     if value and (value['pid']==os.getpid() or value['pgrp']==child.pid):samples.append(value)
   for value in samples:owned[(value['pid'],value['start'])]=value
   rss=sum(value['rss'] for value in samples);vm=sum(value['vmpeak'] for value in samples);peak=max(peak,rss);vmpeak=max(vmpeak,vm)
   if rss>3*1024**3:guard='aggregate_RSS_3GiB'
   elif time.monotonic()-start>900:guard='command_wall_900s'
   if guard:
    if identity(child.pid)==owner and owner and owner[1]==child.pid:os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:
     if identity(child.pid)==owner and owner and owner[1]==child.pid:os.killpg(child.pid,signal.SIGKILL)
     child.wait(timeout=5)
    break
   time.sleep(.05)
  code=child.wait();entry.update(exit_code=code,elapsed_seconds=time.monotonic()-start,peak_monitored_aggregate_RSS=peak,peak_monitored_aggregate_VmPeak=vmpeak,guard=guard,owned_identities=list(owned.values()));record();verify()
 if code or guard:raise RuntimeError('Command failed: '+label+' exit '+str(code)+' guard '+str(guard))

try:
 verify();record()
 probes={}
 for name in ['cc1plus','as','collect2','ld']:
  raw=subprocess.check_output(['/usr/bin/c++','-print-prog-name='+name],text=True).strip();actual=Path(raw) if '/' in raw else Path(shutil.which(raw) or '/nonexistent')
  if str(actual) not in pins and str(actual.resolve()) not in pins:raise RuntimeError('Unpinned selected backend: '+str(actual))
  pin(actual);probes[name]={'literal':raw,'actual':str(actual),'resolved':str(actual.resolve()),'sha256':sha(actual)}
 status['selected_backends']=probes;record()
 for index,c in enumerate(plan['commands']):
  a=c['argv'];pre=[];skip=False
  for arg in a:
   if skip:skip=False;continue
   if arg in ['-o','-MT','-MF']:skip=True;continue
   if arg in ['-c','-MD']:continue
   pre.append(arg)
  pre+=['-M','-MT',c['object'],'-MF',c['full_M_precheck']];run(pre,str(index)+'-full-M')
  expected=set(dependencies(Path(c['full_M_precheck'])))
  for p in expected:pin(p)
  (out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');verify();run(a,str(index)+'-whole-TU')
  actual=set(dependencies(Path(c['actual_full_depfile'])))
  if expected!=actual:raise RuntimeError('Actual compiler MD differs from full-M precheck: '+c['source'])
  for p in actual:pin(p)
  status['commands'][-1].update(source=c['source'],object_sha256=sha(c['object']),actual_MD_sha256=sha(c['actual_full_depfile']),dependency_count=len(actual));record()
 verify();status.update(exit_code=0,state='complete')
except BaseException as error:status.update(exit_code=1,state='failed',error=str(error))
finally:
 status['input_drift']=[p for p,h in pins.items() if not Path(p).exists() or sha(p)!=h];status['terminal']=True;(out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');record()
raise SystemExit(status['exit_code'])
