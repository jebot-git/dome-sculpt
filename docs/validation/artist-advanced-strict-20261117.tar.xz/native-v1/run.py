from pathlib import Path
import os,json,hashlib,subprocess,resource,time,fcntl,importlib.util,re,sys
sys.dont_write_bytecode=True
out=Path(__file__).parent;os.chdir(out);plan=json.loads((out/'plan.json').read_text());pins=dict(plan['input_pins']);catalog=plan['runtime_provider_expected_catalog'];lease=None

def sha(path):
 with Path(path).open('rb') as file:return hashlib.file_digest(file,'sha256').hexdigest()
def verify():
 drift=[path for path,want in pins.items() if not Path(path).is_file() or sha(path)!=want]
 if drift:raise RuntimeError('Immutable current component input drift: '+str(drift))
def add_expected(path,want):
 path=str(path)
 if path in pins and pins[path]!=want:raise RuntimeError('Conflicting immutable expected provider: '+path)
 if sha(path)!=want:raise RuntimeError('Actual selected provider drift: '+path)
 pins[path]=want
status={'state':'preparing','terminal':False,'exit_code':None,'owner_pid':os.getpid(),'product':plan['product'],'fixture':plan['fixture'],'steps':[],'providers':{},'live_sanitizer_mappings':{},'driver_sha256':sha(__file__),'plan_sha256':sha(out/'plan.json')}
def save(): (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def expected_provider(path):
 path=Path(path);resolved=path.resolve();want=pins.get(str(path)) or pins.get(str(resolved)) or catalog.get(str(path)) or catalog.get(str(resolved))
 if want is None:raise RuntimeError('Unknown actual runtime provider: '+str(path))
 add_expected(path,want);add_expected(resolved,want);return {'literal':str(path),'resolved':str(resolved),'sha256':want}
def observe_live(name,row):
 status['live']={'name':name,**row};pid=row.get('pid');start=row.get('start')
 try:
  proc=Path('/proc')/str(pid);stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
  if int(stat[19])!=start:return
  mappings={line.split(None,5)[5].strip() for line in (proc/'maps').read_text().splitlines() if len(line.split(None,5))==6 and line.split(None,5)[5].strip().startswith('/')}
  witness=status['live_sanitizer_mappings'].setdefault(name,{})
  for path in mappings:
   if re.search(r'/lib(?:asan|ubsan)\.so',path):witness[path]=expected_provider(path)
 except FileNotFoundError:pass
 finally:save()
try:
 assert resource.getrlimit(resource.RLIMIT_AS)==(resource.RLIM_INFINITY,resource.RLIM_INFINITY),'ASAN shadow requires no address-space cap'
 assert plan['environment']['ASAN_OPTIONS']=='detect_leaks=1:halt_on_error=1:abort_on_error=1' and plan['environment']['UBSAN_OPTIONS']=='halt_on_error=1:print_stacktrace=1' and not plan['environment']['LSAN_OPTIONS'] and not plan['environment']['LD_PRELOAD']
 verify();assert sha(plan['monitor']['path'])==plan['monitor']['sha256'];spec=importlib.util.spec_from_file_location('qualified_owned_monitor',plan['monitor']['path']);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
 env={k:v for k,v in os.environ.items() if not k.startswith(('LD_','DYLD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for key in ['ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(key,None)
 env.update({k:v for k,v in plan['environment'].items() if v is not None});env['XR_RUNTIME_JSON']=str(out/'no-physical-runtime.json');env['PYTHONDONTWRITEBYTECODE']='1'
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_STATE_HOME','state'),('XDG_CACHE_HOME','cache'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(out/leaf);Path(env[key]).mkdir(mode=0o700)
 status['environment']={k:env.get(k) for k in list(plan['environment'])+['DISPLAY','WAYLAND_DISPLAY','DBUS_SESSION_BUS_ADDRESS','XR_RUNTIME_JSON']};save()
 lease=Path(plan['lease'].split(' before ',1)[0]).open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);status['lease']={'acquired':time.time(),'owner_pid':os.getpid(),'before_any_ldd_or_product':True,'inode':os.fstat(lease.fileno()).st_ino};save()
 for step in plan['steps']:
  verify();name=step['name'];assert sha(step['argv'][0])==step['elf_sha256']
  row=monitor.run(['/usr/bin/ldd',step['argv'][0]],cwd=out,env=env,log=out/(name+'.ldd'),timeout=60,max_rss=plan['resources']['aggregate_RSS_bytes']);row['name']=name+'-ldd';status['steps'].append(row);save();assert row['exit']==0 and not row.get('signals') and 'error' not in row
  text=(out/(name+'.ldd')).read_text();assert 'not found' not in text;paths=re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text);assert paths;status['providers'][name]=[expected_provider(path) for path in paths];assert any('libasan.so' in x['literal'] for x in status['providers'][name]) and any('libubsan.so' in x['literal'] for x in status['providers'][name]);save()
  row=monitor.run(step['argv'],cwd=out,env=env,log=out/(name+'.log'),timeout=plan['resources']['per_command_seconds'],max_rss=plan['resources']['aggregate_RSS_bytes'],progress=lambda row:observe_live(name,row));row['name']=name;status['steps'].append(row);status.pop('live',None);save();assert row['exit']==0 and not row.get('signals') and 'error' not in row
  text=(out/(name+'.log')).read_text();assert re.search(r'^PASS '+str(step['expected_pass_count'])+r' (?:advanced source checks|prepared source controls|artist source CPU controls)$',text,re.M);assert not re.search(r'ERROR: (?:AddressSanitizer|LeakSanitizer)|SUMMARY: (?:AddressSanitizer|UndefinedBehaviorSanitizer)|runtime error:',text)
  witness=status['live_sanitizer_mappings'].get(name,{});assert any('libasan.so' in path for path in witness) and any('libubsan.so' in path for path in witness);verify()
 pairs=[];folder=out/'source-advanced-normal-bake-outputs'
 for ordered in sorted(folder.glob('*-ordered.dsculpt')):
  native=ordered.with_name(ordered.name.replace('-ordered.dsculpt','.dsculpt'));a,b=sha(ordered),sha(native);assert a==b;pairs.append({'native':str(native),'ordered':str(ordered),'sha256':a})
 assert len(pairs)==17;status['ordered_save_pairs']=pairs;verify();status.update(state='complete',exit_code=0)
except BaseException as error:status.update(state='failed',exit_code=1,error=str(error))
finally:
 status['input_drift']=[path for path,want in pins.items() if not Path(path).is_file() or sha(path)!=want];status['remaining_owned']=[]
 if 'monitor' in globals():
  for step in status['steps']:
   for proc in step.get('known_processes',[]):
    if monitor.alive(proc):status['remaining_owned'].append(proc)
 if status['input_drift'] or status['remaining_owned']:status['exit_code']=1;status['state']='failed'
 status['terminal']=True
 if lease:status['lease']['released']=time.time();save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 (out/'current-inputs.json').write_text(json.dumps(pins,indent=2)+'\n');save()
raise SystemExit(status['exit_code'])
