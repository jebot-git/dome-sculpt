from pathlib import Path
import json,hashlib,tarfile,lzma,time,subprocess
R=Path('/home/blux/de-xr/dome-sculpt');A=R/'artifacts';O=A/'hdr-strict-groups-build-v3-20261126';N=O/'native-release-groups-v1';W=A/'hdr-release-proof-20261126';D=W/'docs/validation';files=set()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(p):
 p=Path(p)
 if p.is_file():files.add(p)
def meta(p):
 for f in p.iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.txt','.log','.maps']:add(f)
 for f in (p/'compiler-records').glob('*'):add(f)
s=json.loads((N/'status.json').read_text());assert s['exit']==0 and s['terminal'] and not s['owned'] and not s['drift'];assert s['oracle_complete_coverage']['samples_per_role']==73530600
for name in ['hdr-strict-groups-build-20261126','hdr-strict-groups-build-v2-20261126','hdr-strict-groups-build-v3-20261126']:
 o=A/name;meta(o);meta(o/'native-release-groups-v1')
 for f in (o/'compiler-records').glob('*.json'):
  record=json.loads(f.read_text());add(record['depfile'])
old=A/'hdr-projection-sharing-sanitize-20261126/native-sanitize-current-v1/current2048'
add(old/'selected-target-resolution.dsculpt');add(old/'observed-source.json')
add(A/'make-hdr-group-release-proof-20261126.py')
outputs=[{'path':str(f),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(N.rglob('*')) if f.is_file() and f.suffix in ['.dsculpt']]
inventory=[{'path':str(f.relative_to(R)),'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(files)];archive=D/'hdr-bounded-phases-release-20261126.tar.xz'
with lzma.open(archive,'wb',preset=6) as out:
 with tarfile.open(fileobj=out,mode='w|') as t:
  for f in sorted(files):t.add(f,arcname=str(f.relative_to(R)),recursive=False)
r={'scope':'Actual Release preflight of independent full2048 native/oracle/Document-history groups on exact original strict inputs; source9ee test-only, product725. Not full strict/App/display admission and not a replacement of original strict900deadlinefailure.','product_source':'725ea10032981e28c7edb0c1ffdd5689e4a3ad32','fixture_source':'9ee166d43999f8006514247f3e227c99c8ffda31','invocation':'b8cdf08b070b4625a85f290f288608ee','phase_controls':sum(x['actual_checks'] for x in s['steps']),'controls_note':'Common controls repeated across independent phases; not a count of new unique functional tests or a new original47409 result.','status':s,'archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'authorities':inventory},'large_outputs_retained_at_actual_paths':outputs,'original_strict_monolithic_failure':'docs/validation/hdr-source-closure-strict-20261126.json','strict_group_runtime':'separately active, not qualified by this Release result','limitations':['Original successfulR transient unit was garbage-collected before terminal show/stop; real notfound observation, original status, liveELF/maps, invocation and journal retained; no stalePID/service assumption.','First two cheap Release group preflights fail on fixture-only source-schema and dumped-binary transport assumptions; preserved in original stages. No product guard was weakened.','Initialv1 runner aggregate typo73730600 was detected before an oracle ran and corrected prospectively to actual original73530600; v1 plan retained.','Prospective elapsed phase timings identify costs in these runs, not isolated controlled performance comparisons.'],'observed':time.time()};(D/'hdr-bounded-phases-release-20261126.json').write_text(json.dumps(r,indent=2)+'\n');print('Rphaseproof',r['phase_controls'],'authorities',len(files),'archive',archive.stat().st_size)
