import sys,pathlib,subprocess,os,time,hashlib,json,signal
out=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts/hdr-strict-groups-build-v2-20261126')
cmd=sys.argv[1:]; key=hashlib.sha256((' '.join(cmd)).encode()).hexdigest(); records=out/'compiler-records';records.mkdir(exist_ok=True)
start=time.time(); result={'command':cmd,'cwd':os.getcwd(),'started':start,'timeout_seconds':900}
with (records/(key+'.log')).open('w') as log:
 p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 result['pid']=p.pid
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  result['timeout']=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
result.update(exit=code,seconds=time.time()-start)
for flag,label in [('-o','object'),('-MF','depfile')]:
 if flag in cmd:
  path=pathlib.Path(cmd[cmd.index(flag)+1]).absolute();result[label]=str(path)
  if path.is_file():result[label+'_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
(records/(key+'.json')).write_text(json.dumps(result,indent=2)+'\n')
if code:print((records/(key+'.log')).read_text(),file=sys.stderr)
raise SystemExit(code)
