import pathlib,json,subprocess,time,concurrent.futures
O=pathlib.Path(__file__).resolve().parent;P=json.loads((O/'plan.json').read_text());S={'terminal':False,'started':time.time(),'product_source':P['product_source'],'fixture_source':P['fixture_source'],'steps':[]}
def save():(O/'status.json').write_text(json.dumps(S,indent=2)+'\n')
save()
def build(p):
 t=time.time();r=subprocess.run(['/usr/bin/python3',str(O/'compiler.py'),*p['compile']],cwd=O/p['label']);record={'profile':p['label'],'compile_exit':r.returncode}
 if r.returncode:return record
 with (O/(p['label']+'-link.log')).open('w') as f:r=subprocess.run(p['link'],cwd=O/p['label'],stdout=f,stderr=subprocess.STDOUT)
 record.update(link_exit=r.returncode,seconds=time.time()-t);return record
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for result in pool.map(build,P['profiles']):S['steps'].append(result);save();assert result.get('compile_exit')==0 and result.get('link_exit')==0
 S['exit']=0
except BaseException as e:S.update(exit=1,error=repr(e))
S.update(terminal=True,seconds=time.time()-S['started']);save();print(json.dumps(S),flush=True);raise SystemExit(S['exit'])
