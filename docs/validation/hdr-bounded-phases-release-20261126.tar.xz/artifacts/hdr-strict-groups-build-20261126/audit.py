from pathlib import Path
import json,hashlib,shlex,subprocess,time
O=Path(__file__).resolve().parent;p=json.loads((O/'plan.json').read_text());pins=json.loads((O/'before-inputs.json').read_text());errors=[];owners=[];links=[]
def sha(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
for profile in p['profiles']:
 record=next((json.loads(f.read_text()) for f in (O/'compiler-records').glob('*.json') if json.loads(f.read_text())['object']==profile['object']),None);assert record and record['exit']==0
 assert sha(record['object'])==record['object_sha256'] and sha(record['depfile'])==record['depfile_sha256']
 deps=[]
 for name in shlex.split(Path(record['depfile']).read_text().replace('\\\n',' ').split(':',1)[1]):
  if name.endswith(':'):continue
  f=Path(name);f=f if f.is_absolute() else O/profile['label']/f;k=str(f) if str(f) in pins else str(f.resolve());deps.append(str(f))
  if k not in pins or sha(f)!=pins[k]['sha256']:errors.append('Actual MD unpinned/drift '+str(f))
 assert sha(profile['parent_audit'])==profile['parent_audit_sha256'];a=json.loads(Path(profile['parent_audit']).read_text());assert a['exit']==0;archives={x['path']:x['sha256'] for x in a['archives']};inputs=[]
 for arg in profile['link']:
  if arg.endswith(('.o','.a','.so')) or '.so.' in arg:
   f=Path(arg)
   if f.is_file():
    actual=sha(f);inputs.append({'path':str(f),'sha256':actual})
    if arg.endswith('.a') and archives.get(str(f))!=actual:errors.append('Actual parent archive drift '+str(f))
 needed=subprocess.check_output(['readelf','-d',profile['executable']],text=True)
 if profile['label']=='sanitize':
  for flag in ['-O1','-g1','-fsanitize=address,undefined','-fno-omit-frame-pointer']:assert flag in record['command']
  assert 'libasan.so' in needed and 'libubsan.so' in needed
 owners.append({'profile':profile['label'],'object':record['object'],'sha256':sha(record['object']),'actual_MD':record['depfile'],'actual_dependencies':deps,'actual_record':record})
 links.append({'profile':profile['label'],'path':profile['executable'],'sha256':sha(profile['executable']),'actual_inputs':inputs,'actual_command':profile['link'],'DT_NEEDED':needed})
r={'exit':int(bool(errors)),'errors':errors,'product_source':p['product_source'],'fixture_source':p['fixture_source'],'actual_owners':owners,'links':links,'scope':p['scope'],'observed':time.time()};(O/'audit.json').write_text(json.dumps(r,indent=2)+'\n');print('audit',r['exit'],'wholeTUs',len(owners),'links',len(links),'dependencies',sum(len(x['actual_dependencies']) for x in owners));raise SystemExit(r['exit'])
