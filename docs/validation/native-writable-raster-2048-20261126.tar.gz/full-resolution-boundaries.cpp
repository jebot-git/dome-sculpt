#include "dome/scene.hpp"
#include "dome/bake-authoring.hpp"
#include "dome/shapekey-authoring.hpp"
#include <iostream>

int main(int argc,char **argv) try {
  if(argc!=3)return 2;
  {
    auto scene=dome::Scene::load(argv[1]);
    dome::ObjectBakeSettings settings;
    settings.corresponding_topology=true;
    const auto paint=scene.active().painted;
    try {
      dome::bake_object(scene,2,settings);
      std::cout<<"DEFAULT_AO accepted\n";
    } catch(const std::length_error &e) {
      if(scene.active().painted!=paint)throw;
      std::cout<<"DEFAULT_AO "<<e.what()<<'\n';
    }
  }
  {
    auto scene=dome::Scene::load(argv[2]);
    const auto paint=scene.active().painted;
    dome::ShapeKeyEdit edit;
    edit.action=dome::ShapeKeyAction::Create;
    edit.name="Key after full-resolution Bake";
    try {
      dome::author_shapekey(scene,scene.active().id,edit);
      std::cout<<"FULL_SIZE_KEY accepted\n";
    } catch(const std::length_error &e) {
      if(scene.active().painted!=paint)throw;
      std::cout<<"FULL_SIZE_KEY "<<e.what()<<'\n';
    }
  }
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
