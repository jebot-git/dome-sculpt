#include "dome/scene.hpp"
#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include <iostream>

int main(int argc,char **argv) try {
  if(argc!=3)return 2;
  auto scene=dome::Scene::load(argv[1]);
  const auto prior=scene.active().bake_recipe;
  if(!prior||!scene.active().painted->baked())return 1;
  auto settings=prior->settings;
  settings.corresponding_topology=false;
  scene.active().painted->clear_bake();
  const auto result=dome::bake_object(scene,prior->source.object,settings);
  if(result.projected!=4194304||!scene.active().bake_recipe||scene.active().bake_recipe->settings.corresponding_topology)return 1;
  scene.active().painted->clear_bake();
  scene.save(argv[2]);
  std::cout<<"PASS genuine full-size ray Bake seeds native Recall without a baked map\n";
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
