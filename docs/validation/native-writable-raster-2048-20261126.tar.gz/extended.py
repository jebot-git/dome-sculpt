from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time
root=Path(__file__).resolve().parent
art=root.parent
profile=sys.argv[1]
asan=profile=='asan'
out=root/profile
build=out/'build'
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
renderer=art/'native-key-bake-v2-20261126'/profile/'libdome-sculpt-render.a'
sdk=art/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
old=art/'legacy-key-bake-conversion-v4-20261126'/profile/'libdome-sculpt-core.a'
core=out/'libdome-sculpt-core.a'
db=json.loads((build/'compile_commands.json').read_text())
exe='dome-sculpt-'
tests=('native-paint-sampling','native-paint-sampling-faults','native-paint-sampling-transitions',
       'native-paint-rig-uv','native-key-uv','source8-preview')
def invoke(args,log,timeout=360,check=True):
    with (out/log).open('w') as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        return subprocess.run(args,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=timeout,check=check).returncode
def compile_test(test):
    target=exe+test+'-test'
    if test=='raster-allocation':target=exe+'native-paint-rig-uv-test'
    entry=next(e for e in db if target+'.dir/' in e['command'])
    original=shlex.split(entry['command'])
    obj=out/(test+'.o')
    original[original.index('-o')+1]=str(obj)
    if test=='raster-allocation':original[original.index('-c')+1]=str(root/'raster-allocation.cpp')
    original.extend(['-MMD','-MF',str(obj)+'.d'])
    invoke(original,test+'-compile.log',600)
    return test,target,obj
with ThreadPoolExecutor(max_workers=2) as pool:
    fixtures=list(pool.map(compile_test,tests+(() if asan else ('raster-allocation',))))
while not core.exists():
    if subprocess.run(['systemctl','--user','is-active','--quiet',f'ds-native-raster-2048-v3-{profile}-20261126.service']).returncode:
        raise RuntimeError('Owning build did not produce an archive')
    time.sleep(2)
while not json.loads((out/'status.json').read_text()).get('core'):
    if subprocess.run(['systemctl','--user','is-active','--quiet',f'ds-native-raster-2048-v3-{profile}-20261126.service']).returncode:
        raise RuntimeError('Owning archive did not finish verification')
    time.sleep(2)
def link(data):
    test,target,obj=data
    cmd=subprocess.check_output(['ninja','-t','commands',target],cwd=build,text=True).splitlines()[-1]
    words=[s for s in shlex.split(cmd)[2:-2] if not s.startswith('-Wl,--dependency-file')]
    def path(word):
        if word.endswith('.o'):return str(obj)
        if word=='libdome-sculpt-core.a':return str(core)
        if word=='libdome-sculpt-render.a':return str(renderer)
        if word.endswith('.a') and not word.startswith('/'):return str(support/word)
        return word
    words=list(map(path,words))
    if test=='raster-allocation':
        for variant in ('before','after'):
            chosen=[str(old) if s==str(core) and variant=='before' else s for s in words]
            chosen[chosen.index('-o')+1]=str(build/('raster-allocation-'+variant))
            invoke(chosen,'raster-allocation-'+variant+'-link.log')
    else:
        invoke(words,test+'-link.log')
with ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(link,fixtures))
isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
     'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if asan:env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for k,v in env.items():isolated.extend(['--setenv',k,v])
invoke([*isolated,'ctest','--test-dir',build,'-V','-j2','-R','^('+'|'.join(tests)+')$','--output-on-failure'],
       'extended-ctest.log',800)
if not asan:
    for phase in ('before','after'):
        for res in ('1024','2048'):
            invoke([*isolated,build/('raster-allocation-'+phase),res],f'raster-{phase}-{res}.log',
                   check=not (phase=='before' and res=='2048'))
