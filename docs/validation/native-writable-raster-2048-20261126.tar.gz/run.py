from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import time

home=Path(__file__).resolve().parent
art=home.parent
src=home/'source'
profile=sys.argv[1]
asan=profile=='asan'
out=home/profile
out.mkdir(exist_ok=True)
build=out/'build'
old=art/'legacy-key-bake-conversion-v4-20261126'/profile
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=art/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
env={**os.environ,'PKG_CONFIG_PATH':'/opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig'}
start=time.monotonic()
candidate=subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
state={'candidate':candidate,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def status(**updates):
    state.update(updates,elapsed=round(time.monotonic()-start,2))
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')
def sha(file):
    with Path(file).open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
def invoke(arguments,log,timeout=600,cwd=None,check=True):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,arguments)),file=trace,flush=True)
        return subprocess.run(arguments,cwd=cwd or build,stdout=trace,stderr=subprocess.STDOUT,
                              env=env,timeout=timeout,check=check).returncode
def first(path):
    return shlex.split(path.read_text().splitlines()[0])
try:
    patch=home/'source.patch'
    assert subprocess.check_output(['git','-C',src,'diff','--binary','HEAD'])==patch.read_bytes()
    past=json.loads((old/'status.json').read_text())
    old_core=old/'libdome-sculpt-core.a'
    old_render=art/'native-key-bake-v2-20261126'/profile/'libdome-sculpt-render.a'
    assert past['exit']==0 and sha(old_core)==past['core'] and sha(old/'build/dome-sculpt')==past['app_sha256']
    assert sha(old_render)==past['render']
    changed=subprocess.check_output(['git','-C',src,'diff','--name-only','HEAD'],text=True).splitlines()
    sources={Path(name).name for name in changed if name.startswith('src/') and name.endswith('.cpp')}
    dependencies={Path(name).name for name in changed if name.startswith('src/') and name.endswith('.hpp')}
    files=list((src/'src').glob('*.hpp'))+list((src/'src').glob('*.cpp'))
    includes={p.name:set(re.findall(r'^#\s*include\s+"([^"]+)"',p.read_text(errors='replace'),re.MULTILINE))
              for p in files}
    while True:
        affected={p for p,children in includes.items() if {Path(k).name for k in children}&dependencies}
        added={p for p in affected if p.endswith('.hpp')}-dependencies
        if not added:break
        dependencies.update(added)
    sources.update(p for p in affected if p.endswith('.cpp'))
    opts=[]
    if asan:
        opts.extend(f'-DCMAKE_{lang}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for lang in ('C','CXX'))
        opts.extend(f'-DCMAKE_{lang}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for lang in ('C','CXX'))
    status(phase='configure canonical toolkit',patch_sha256=sha(patch),prior_core=sha(old_core),private_dependencies=sorted(dependencies))
    invoke(['cmake','-S',src,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON',
            '-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*opts],'configure.log',120,home)
    db=json.loads((build/'compile_commands.json').read_text())
    suite='dome-sculpt-source-writable-normal-bake-test'
    core_entries=[entry for entry in db if 'CMakeFiles/dome-sculpt-core.dir/' in entry['command'] and Path(entry['file']).name in sources]
    render_entries=[entry for entry in db if 'CMakeFiles/dome-sculpt-render.dir/' in entry['command'] and Path(entry['file']).name in sources]
    suite_entries=[entry for entry in db if f'CMakeFiles/{suite}.dir/' in entry['command']]
    assert {Path(e['file']).name for e in core_entries+render_entries}==sources and len(suite_entries)==1
    def compile(entry):
        cmd=shlex.split(entry['command'])
        filename=Path(entry['file']).name
        obj=out/(filename+'.o')
        cmd[cmd.index('-o')+1]=str(obj)
        cmd.extend(['-MMD','-MF',str(obj)+'.d'])
        invoke(cmd,filename+'.log',900)
        return obj
    status(phase='compile owning core, renderer and fixture',sources=sorted(sources))
    with ThreadPoolExecutor(max_workers=2) as pool:
        objs=list(pool.map(compile,core_entries+render_entries+suite_entries))
    def refresh(baseline,owners):
        archive=out/baseline.name
        shutil.copyfile(baseline,archive)
        invoke(['ar','rs',archive,*owners],archive.stem+'-archive.log',300)
        assert subprocess.check_output(['ar','t',baseline])==subprocess.check_output(['ar','t',archive])
        for obj in owners:
            assert hashlib.sha256(subprocess.check_output(['ar','p',archive,obj.name])).hexdigest()==sha(obj)
        return archive
    core=refresh(old_core,objs[:len(core_entries)])
    assert not render_entries
    render=old_render
    status(phase='relink actual app and regression fixtures',core=sha(core),render=sha(render),objects={p.name:sha(p) for p in objs})
    app=build/'dome-sculpt'
    cmd=first(old/'app-link.log')
    replacement={str(old_core):str(core),str(old_render):str(render)}
    cmd=[replacement.get(w,w) for w in cmd]
    cmd[cmd.index('-o')+1]=str(app)
    invoke(cmd,'app-link.log',500,support)
    runtime=old/'build/libdome-sculpt-test-runtime.so'
    assert sha(runtime)==past['runtime_sha256']
    (build/runtime.name).symlink_to(runtime.resolve())
    targets={
      'legacy-native-key-bake-conversion':suite,
      'native-writable-bake-2048':suite,
      'legacy-native-key-bake-conversion':suite,
      'native-key-writable-bake-recipient':suite,
      'canonical-writable-bake-recipient':suite,
      'native-writable-bake-recipient':suite,
      'bake':'dome-sculpt-bake-test',
      'bake-projection-policy':'dome-sculpt-bake-projection-policy-test',
      'bake-custom-cage':'dome-sculpt-bake-cage-test',
      'texture-set-bake-recipe':'dome-sculpt-texture-set-bake-recipe-test',
      'source-artist-normal-bake':'dome-sculpt-source-artist-normal-bake-test',
      'source-prepared-normal-bake':'dome-sculpt-source-prepared-normal-bake-test',
    }
    def link_fixture(target):
        cmd=first(old/(target+'-link.log'))
        cmd=[str(core) if word==str(old_core) else str(objs[-1])
             if target==suite and word.endswith('/source-writable-normal-bake.cpp.o') else word for word in cmd]
        cmd[cmd.index('-o')+1]=str(build/target)
        invoke(cmd,target+'-link.log',600,old/'build')
        return target,sha(build/target)
    with ThreadPoolExecutor(max_workers=2) as pool:
        bins=dict(pool.map(link_fixture,sorted(set(targets.values())|{'dome-sculpt-native-authoring-inspect'})))
    status(phase='execute native Bake regressions',app_sha256=sha(app),runtime_sha256=sha(runtime),binaries=bins)
    isolated=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
              '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    runenv={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if asan:runenv.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,val in runenv.items():isolated.extend(['--setenv',key,val])
    report=build/'regressions.xml'
    exit_code=invoke([*isolated,'ctest','--test-dir',build,'-V','-j2','-R','^('+'|'.join(targets)+')$',
        '--output-on-failure','--output-junit',report],'ctest.log',650,check=False)
    status(phase='complete',terminal=True,exit=exit_code,ctest_sha256=sha(out/'ctest.log'),report_sha256=sha(report),tests=sorted(targets))
    raise SystemExit(exit_code)
except Exception as error:
    status(terminal=True,exit=1,error=repr(error))
    raise
