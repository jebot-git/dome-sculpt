from pathlib import Path
import json
import os
import shlex
import subprocess
import sys
root=Path(__file__).resolve().parent
profile=sys.argv[1]
mode=sys.argv[2]
art=root.parent
out=root/profile
build=out/'build'
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
core=out/'libdome-sculpt-core.a'
render=art/'native-key-bake-v2-20261126'/profile/'libdome-sculpt-render.a'
sdk=art/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit')
name='dome-sculpt-native-paint-sampling-transitions-test' if mode=='transitions' else 'dome-sculpt-source-writable-normal-bake-test'
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if name+'.dir/' in e['command'])
obj=out/(mode+'-second.o')
result=out/(mode+'-second')
source=(root/'public-seed.cpp') if mode=='seed' else Path('/home/blux/de-xr/dome-sculpt/tests/native-paint-sampling-transitions.cpp')
def call(words,log,check=True):
    with (out/log).open('w') as f:
        print(shlex.join(map(str,words)),file=f,flush=True)
        return subprocess.run(words,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=600,check=check,
            env={**os.environ,'HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2','LIBGL_ALWAYS_SOFTWARE':'1',
                 'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
                 'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}).returncode
argv=shlex.split(entry['command'])
argv[argv.index('-o')+1]=str(obj)
argv[argv.index('-c')+1]=str(source)
argv.extend(['-MMD','-MF',str(obj)+'.d'])
call(argv,mode+'-second-compile.log')
cmd=subprocess.check_output(['ninja','-t','commands',name],cwd=build,text=True).splitlines()[-1]
argv=[s for s in shlex.split(cmd)[2:-2] if not s.startswith('-Wl,--dependency-file')]
def map_path(arg):
    if arg.endswith('.o'):return str(obj)
    if arg=='libdome-sculpt-core.a':return str(core)
    if arg=='libdome-sculpt-render.a':return str(render)
    if arg.endswith('.a') and not arg.startswith('/'):return str(support/arg)
    return arg
argv=list(map(map_path,argv))
argv[argv.index('-o')+1]=str(result)
call(argv,mode+'-second-link.log')
call([result,*([build/'native-writable-bake-2048/baked-2048.dsculpt',out/'recipe-ready.dsculpt'] if mode=='seed' else [])],mode+'-second-run.log')
