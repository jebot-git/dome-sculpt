#include "native-paint-model.hpp"
#include <cstdlib>
#include <iostream>
#include <new>

namespace {
thread_local size_t largest=0;
thread_local bool measuring=false;
}
void *operator new(size_t bytes) {
  if(measuring)largest=std::max(largest,bytes);
  if(void *p=std::malloc(bytes?bytes:1))return p;
  throw std::bad_alloc();
}
void *operator new[](size_t size){return ::operator new(size);}
void operator delete(void *p) noexcept {std::free(p);}
void operator delete[](void *p) noexcept {std::free(p);}
void operator delete(void *p,size_t) noexcept {std::free(p);}
void operator delete[](void *p,size_t) noexcept {std::free(p);}

int main(int argc,char **argv) try{
  if(argc!=2)return 2;
  auto resolution=uint32_t(std::stoul(argv[1]));
  dome::Mesh m;
  m.positions={{-.5f,-.5f,0},{.5f,-.5f,0},{.5f,.5f,0},{-.5f,.5f,0}};
  m.normals.assign(4,{0,0,1});
  m.indices={0,1,2,0,2,3};
  m.uv={{{0,0}},{{1,0}},{{1,1}},{{0,1}}};
  dome::SculptObject object;
  object.mesh_active=true;
  object.painted=std::make_shared<dome::PaintedMesh>(m,resolution);
  auto target=m;
  for(auto &uv:target.uv){const float u=uv[0];uv={.2f+.6f*uv[1],.8f-.6f*u};}
  const std::array<uint32_t,4> map{0,1,2,3};
  measuring=true;
  const auto result=dome::detail::retain_native_paint_model(object,target,map);
  measuring=false;
  if(!result.sampling.owner->matches_current(*result.sampling.paint)||
      result.sampling.paint->mesh().uv!=target.uv||
      result.sampling.paint->surface_diagnostics().covered_texels!=size_t(resolution)*resolution)
    throw std::runtime_error("Wrong retained raster");
  std::cout<<"RASTER_ALLOCATION resolution="<<resolution<<" largest_bytes="<<largest<<'\n';
  return 0;
}catch(const std::exception &e){measuring=false;std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
