from pathlib import Path
import hashlib,json,tarfile,io
out=Path(__file__).resolve().parent;src=out.parent/'vroid-creator-public-resume-20261126'
stage=out/'public07025-milestone';stage.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(out.parent/'serialize-sculpt-objects-release-20261126/dome-sculpt')=='ad24e8d91fc977e070e151c844422cb50755c4731d5f829d3431a9e23f98b32d'
assert sha(out/'release/libdome-sculpt-creator-workspace-runtime.so')=='2cb3885e673babc4160fca528269ef30cb6ab644549693939c4d76618ed36ece'
assert sha(out/'release/dome-sculpt-creator-workspace-test')=='9c99adfdb70ece0c3fb62c247ba221c85827232710ae922c55dd69f5a786d69f'
members={};external={};cases={}
def add(name,p):
    p=Path(p);assert p.is_file();members[name]={'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
for mode,expected in [('accept',19),('cancel',19),('focus',20)]:
    case=out/('public07025-'+mode+'-v1');s=json.loads((case/'status.json').read_text());r=json.loads((case/'workflow/report.json').read_text());plan=json.loads((case/'plan.json').read_text())
    assert plan['production']=='07025cd3995626bd32a9d0a848a2564965583ada'
    assert s['terminal']and s['exit']==0 and s['actual_checks']==expected and not s['input_drift']and not s['owned_remaining']
    assert r['complete']and not r['error']and not r['drift']and r['count']==expected and all(c['passed']for c in r['checks'])
    row=next(x for x in s['steps']if x['name']=='public '+mode);assert row['exit']==0 and row['seconds']<240 and row['peak_owned_RSS_bytes']<4*1024**3 and not row['signals']
    assert len(s['observed']['actual_apps'])==2 and len(s['actual_device_reports'])==2
    cases[mode]={'actual_checks':expected,'whole_wrapper_exit':s['exit'],'actual_seconds':row['seconds'],'peak_owned_RSS_bytes':row['peak_owned_RSS_bytes'],'actual_App_roots':s['observed']['actual_apps'],'ELF_certificates':len(s['observed']['actual_mapped_ELFs']),'actual_device_reports':s['actual_device_reports'],'lease':s['lease'],'independent_free':json.loads((case/'independent-free.json').read_text()),'input_drift':s['input_drift'],'owned_remaining':s['owned_remaining'],'signals':row['signals']}
    for p in case.rglob('*'):
        if not p.is_file():continue
        relative=p.relative_to(case)
        if 'home'in relative.parts or p.suffix=='.dsculpt':
            if p.suffix=='.dsculpt':external[str(p)]={'bytes':p.stat().st_size,'sha256':sha(p)}
            continue
        add(mode+'/'+str(relative),p)
for p in [Path(__file__),out/'run-public07025-v1.py',out/'provider-witness-v3.py',out/'owned-monitor.py',out/'build-review.json',out/'review-actual-MD-owners.json',out/'review-actual-link-inputs.json']:
    if p.is_file():add('support/'+p.name,p)
for n in ['creator-workspace-xr.py','creator-workspace.cpp','creator-workspace-runtime.cpp']:
    add('fixture/'+n,src/'tests'/n)
for n in ['CMakeFiles/dome-sculpt-creator-workspace-test.dir/tests/creator-workspace.cpp.o.d','CMakeFiles/dome-sculpt-creator-workspace-runtime.dir/tests/creator-workspace-runtime.cpp.o.d']:
    if(out/'release'/n).is_file():add('fixture-actual-MDs/'+Path(n).name,out/'release'/n)
for n in ['app-build-status.json','build-status.json','build-plan.json']:
    add('App-build/'+n,out.parent/'serialize-sculpt-objects-release-20261126'/n)
seed=out/'public-fixture-v1/fixture/creator-input.dsculpt';external[str(seed)]={'bytes':seed.stat().st_size,'sha256':sha(seed)}
arc=stage/'scoped-proof.tar.xz'
with tarfile.open(arc,'w:xz',preset=6)as t:
    for name,row in sorted(members.items()):
        data=Path(row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256'];info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(arc)as t:
    for m in t.getmembers():assert hashlib.sha256(t.extractfile(m).read()).hexdigest()==members[m.name]['sha256']
receipt={'scope':'Exact07025 optimized production App genuine current05 public synthetic-XR accept/cancel/focus and ordinary reopen, all original full native fidelity/controls/tracking/resource gates. No camera/product changes, physicalHMD, combined strict-App or full-production completion claim.','production':'07025cd3995626bd32a9d0a848a2564965583ada','App_sha256':'ad24e8d91fc977e070e151c844422cb50755c4731d5f829d3431a9e23f98b32d','owning_fixture_source':'5509958f','runtime_sha256':'2cb3885e673babc4160fca528269ef30cb6ab644549693939c4d76618ed36ece','inspector_sha256':'9c99adfdb70ece0c3fb62c247ba221c85827232710ae922c55dd69f5a786d69f','fixture_build_proof':'9dd08f32','App_Wayland_build_proof':'3889efcd','original_bounds':{'seconds_each':240,'RSS_bytes_each':4*1024**3,'virtual_AS_cap':None},'actual_cases':cases,'total_actual_checks':58,'archive':{'bytes':arc.stat().st_size,'sha256':sha(arc),'members':members},'external_native_projects':external,'remaining':'Framing remediation, combined strict public UI and broader full production acceptance remain separate; no older proof is relabelled.'}
(stage/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'members':len(members),'bytes':arc.stat().st_size,'sha256':sha(arc),'cases':cases},indent=2))
for name,p in [('COMBINED07025-PUBLIC-XR-20261126.json',stage/'receipt.json'),('COMBINED07025-PUBLIC-XR-20261126-evidence.tar.xz',arc)]:
    (src/'docs/validation'/name).write_bytes(p.read_bytes())
