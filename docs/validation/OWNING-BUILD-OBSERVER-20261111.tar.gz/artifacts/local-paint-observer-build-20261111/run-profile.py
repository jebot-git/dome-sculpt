#!/usr/bin/env python3
import hashlib,json,os,shlex,subprocess,sys,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
profile=sys.argv[1];assert profile in ['release','sanitize']
DEST=OUT/(profile+'-e81');DEST.mkdir()
SOURCE=ROOT/'artifacts/local-paint-observer-20261111'
BASE=ROOT/'artifacts/authoring-production-build-20261111'/profile
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
state=json.loads((BASE.parent/(profile+'-owning-status.json')).read_text())
assert state['state']=='terminal' and next(x for x in state['steps'] if x['name']=='build')['exit']==0
assert not state['source_drift'] and not state['sdk_drift']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip().startswith('e81ac048')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True).strip()
assert not subprocess.check_output(['git','diff','a904a2d6','HEAD','--','src','include','assets','third_party'],cwd=SOURCE,text=True).strip()
pins={**state['owned'],str(SOURCE/'tests/local-surface-integration.cpp'):sha(SOURCE/'tests/local-surface-integration.cpp')}
assert all(sha(p)==h for p,h in pins.items())
item=next(x for x in json.loads((BASE/'compile_commands.json').read_text()) if x['file'].endswith('/tests/local-surface-integration.cpp'))
cmd=[x.replace(str(ROOT/'artifacts/authoring-production-union-20261111'),str(SOURCE)) for x in shlex.split(item['command'])]
cmd[cmd.index('-o')+1]=str(DEST/'native.o')
with (DEST/'compile.log').open('wb') as f:subprocess.run(cmd,cwd=DEST,stdout=f,stderr=subprocess.STDOUT,check=True)
line=subprocess.check_output(['ninja','-C',str(BASE),'-t','commands','dome-sculpt-local-surface-integration-test'],text=True).splitlines()[-1]
link=shlex.split(line);assert link[:2]==[':','&&'] and link[-2:]==['&&',':'];link=link[2:-2]
for i,x in enumerate(link):
    if x.endswith('/tests/local-surface-integration.cpp.o'):link[i]=str(DEST/'native.o')
    elif x.endswith('.a') and not x.startswith('/'):link[i]=str(BASE/x)
    elif x.startswith('-Wl,--dependency-file='):link[i]='-Wl,--dependency-file='+str(DEST/'link.d')
    if x=='-o':link[i+1]=str(DEST/'native-test')
with (DEST/'link.log').open('wb') as f:subprocess.run(link,cwd=DEST,stdout=f,stderr=subprocess.STDOUT,check=True)
env=dict(os.environ,LD_LIBRARY_PATH=str(ROOT/'artifacts/sdk-20261111'/('toolkit-'+profile)/'lib')+':/usr/lib64',LIBGL_ALWAYS_SOFTWARE='1',LP_NUM_THREADS='2')
env.pop('DRI_PRIME',None)
if profile=='sanitize':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
start=time.monotonic()
with (DEST/'native.log').open('wb') as f:
    p=subprocess.Popen([str(DEST/'native-test')],cwd=DEST,env=env,stdout=f,stderr=subprocess.STDOUT)
    (DEST/'live.json').write_text(json.dumps({'state':'running','pid':os.getpid(),'child_pid':p.pid},indent=2)+'\n')
    try:rc=p.wait(timeout=180)
    except subprocess.TimeoutExpired:p.kill();p.wait();rc=124
result={'state':'terminal','profile':profile,'exit':rc,'seconds':time.monotonic()-start,'source':'e81ac048','scope':'One complete fresh test TU/link against current frozen owninga904 profile. All product bytes unchanged. OriginalfullCTestfixturefailure preserved.','compile':cmd,'link':link,'pins':pins,'provider_drift':[p for p,h in pins.items() if sha(p)!=h],'elf_sha256':sha(DEST/'native-test'),'log_sha256':sha(DEST/'native.log'),'sanitizer_environment':{k:env.get(k) for k in ['ASAN_OPTIONS','LSAN_OPTIONS','UBSAN_OPTIONS']}}
(DEST/'status.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['pins','compile','link']}));print('\n'.join((DEST/'native.log').read_text(errors='replace').splitlines()[-2:]))
raise SystemExit(rc or bool(result['provider_drift']))
