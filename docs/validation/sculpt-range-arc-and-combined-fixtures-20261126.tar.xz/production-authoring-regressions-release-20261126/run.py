from pathlib import Path
import os,json,hashlib,re,time
from owned_monitor import run
B=Path(__file__).resolve().parent;D=B/'cpu-v1';D.mkdir();state={'base_core':'2aff79f7','fixture_commit':'c90c9fed','started':time.time(),'terminal':False,'cases':{},'no_DRI_nodes':not Path('/dev/dri').exists(),'allocator':'default','scope':'Focused native fixtures only, private/dev CPU; no graphics/devicelease or productpatch'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save():(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 assert state['no_DRI_nodes'];assert all(k not in os.environ for k in ['MALLOC_ARENA_MAX','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES'])
 pins=json.loads((B/'before-input-pins.json').read_text());assert all(sha(p)==h for p,h in pins.items());build=json.loads((B/'build-status.json').read_text());assert build['exit']==0
 env=os.environ.copy();env.update({'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2'})
 cases=[('scene-authoring','dome-sculpt-scene-test',[]),('native-live-preview','dome-sculpt-native-strokes-test',['--preview-test']),('native-strokes','dome-sculpt-native-strokes-test',[]),('sculpt-mask-document','dome-sculpt-mask-document-test',[]),('sculpt-mask-controller','dome-sculpt-mask-controller-test',[])]
 for name,t,args in cases:
  exe=B/t;assert sha(exe)==build['ELFs'][t]
  row=run([str(exe),*args],cwd=D,env=env,log=D/(name+'.log'),timeout=180,max_rss=4*1024**3);row['ELF_sha256']=sha(exe);state['cases'][name]=row;save()
 state['input_drift']=[p for p,h in pins.items() if sha(p)!=h];assert not state['input_drift'];state['exit']=int(any(r['exit'] or 'error' in r for r in state['cases'].values()))
except BaseException as e:state.update(exit=1,error=repr(e))
finally:state.update(terminal=True,finished=time.time());save()
raise SystemExit(state['exit'])
