from pathlib import Path
import json,subprocess,shlex,hashlib,time,traceback
B=Path(__file__).resolve().parent;A=B.parent;C=A/'production-full-regression-release-20261126';Old=A/'production-full-regression-source-20261126';S=A/'production-authoring-regressions-source-20261126';Q=A/'cut-current-paint-release-20261126'
targets=['dome-sculpt-scene-test','dome-sculpt-native-strokes-test','dome-sculpt-mask-document-test','dome-sculpt-mask-controller-test'];st={'base_source':'2aff79f7','fixture_commit':'c90c9fed','terminal':False,'started':time.time(),'scope':'Only4wholefixtureTUs +link; exact cut/dormant owning core, no productionrecompile/no graphics'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save():(B/'build-status.json').write_text(json.dumps(st,indent=2)+'\n')
def deps(p):return shlex.split(Path(p).read_text().replace('\\\n',' ').split(':',1)[1].split('\n')[0])
def run(a,name):
 with (B/(name+'.log')).open('w') as f:r=subprocess.run(a,cwd=B,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0,(name,r.returncode)
save()
try:
 q=json.loads((Q/'build-status.json').read_text());assert q['terminal'] and q['exit']==0;assert sha(Q/'libdome-sculpt-core.a')==q['linked_archive']['sha256']
 pins={str((Q/'libdome-sculpt-core.a').resolve()):sha(Q/'libdome-sculpt-core.a'),str((Q/'build-status.json').resolve()):sha(Q/'build-status.json')};comp=[];links=[]
 lines=subprocess.check_output(['ninja','-C',str(C),'-t','commands',*targets],text=True).splitlines()
 oldwrap='-Wl,--wrap=_ZNK4dome5Scene16preview_surfacesERKSt8functionIFbvEERKS1_IFNS_4MeshEmRKNS_6VolumeEEE';newwrap='-Wl,--wrap=_ZN4dome6detail17SculptSceneChunks7captureERKNS_5SceneENS0_23SculptSceneChunkContextERKSt10shared_ptrIKS1_ENS0_22SculptSceneChunkLimitsESt8functionIFbvEE'
 for t in targets:
  c=next(shlex.split(x) for x in lines if x.startswith('/usr/bin/') and ' -c ' in x and t+'.dir/tests/' in x);c=[x.replace(str(Old),str(S)) for x in c];c[c.index('-o')+1]=str(B/(t+'.o'));c[c.index('-MF')+1]=str(B/(t+'.o.d'));comp.append(c)
  line=next(x for x in lines if x.startswith(': && /usr/bin/c++') and ' -o '+t+' ' in x);a=shlex.split(line.removeprefix(': && ').removesuffix(' && :'))
  for i,x in enumerate(a):
   if x.endswith('.a') and not x.startswith('/'):a[i]=str(Q/x) if x=='libdome-sculpt-core.a' else str(C/x)
   elif x.endswith('.o') and not x.startswith('/'):a[i]=str(B/(t+'.o'))
   elif x.startswith('-Wl,--dependency-file='):a[i]='-Wl,--dependency-file='+str(B/(t+'.link.d'))
   elif x==oldwrap and t=='dome-sculpt-mask-controller-test':a[i]=newwrap
  a[a.index('-o')+1]=str(B/t);links.append(a)
 for i,c in enumerate(comp):
  a=[c[0]];j=1
  while j<len(c):
   if c[j] in ['-o','-MF','-MT','-MQ']:j+=2;continue
   if c[j] in ['-MD','-MMD','-c']:j+=1;continue
   a.append(c[j]);j+=1
  d=B/(str(i)+'.prospective.d');run(a+['-M','-MF',str(d),'-MT','prospective'],'scan-'+str(i))
  for p in deps(d):p=Path(p).resolve();pins[str(p)]=sha(p)
 for a in links:
  for x in a:
   p=Path(x)
   if p.is_absolute() and p.is_file():pins[str(p.resolve())]=sha(p)
 (B/'before-input-pins.json').write_text(json.dumps(pins,indent=2)+'\n');(B/'commands.json').write_text(json.dumps({'compile':comp,'link':links},indent=2)+'\n')
 for i,c in enumerate(comp):run(c,'compile-'+str(i));assert all(str(Path(p).resolve()) in pins for p in deps(c[c.index('-MF')+1]))
 for i,c in enumerate(links):run(c,'link-'+str(i))
 drift=[p for p,h in pins.items() if sha(p)!=h];assert not drift
 st.update(exit=0,objects=4,links=4,input_drift=drift,core_sha256=sha(Q/'libdome-sculpt-core.a'),ELFs={t:sha(B/t) for t in targets})
except BaseException as e:traceback.print_exc();st.update(exit=1,error=repr(e))
finally:st.update(terminal=True,seconds=time.time()-st['started']);save()
raise SystemExit(st['exit'])
