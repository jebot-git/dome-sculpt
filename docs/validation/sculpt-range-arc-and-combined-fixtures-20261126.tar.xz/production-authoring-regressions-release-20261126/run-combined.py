from pathlib import Path
import subprocess
import sys

here=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(here/'build.py')],check=True)
args=['/usr/bin/bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',str(here),str(here),
      '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
      '--setenv','PATH','/usr/bin:/bin',sys.executable,str(here/'run.py')]
raise SystemExit(subprocess.run(args).returncode)
