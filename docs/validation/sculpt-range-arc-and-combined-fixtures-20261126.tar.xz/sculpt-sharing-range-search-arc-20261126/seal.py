from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

here=Path(__file__).resolve().parent
artifacts=here.parent
run=here/'arc-independent-p1-v1'
workflow=run/'workflow'
release=artifacts/'sculpt-sharing-range-search-release-20261126'
combined=artifacts/'production-authoring-regressions-release-20261126'
docs=artifacts.parent/'docs/validation'
def sha(p):
    with p.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()
def load(p):
    return json.loads(p.read_text())
status=load(run/'status.json')
report=load(workflow/'result.json')
assert status['terminal'] and status['exit']==0 and not status['input_drift'] and not status['provider_drift'] and not status['owned_survivors']
assert status['lease']['released']>status['lease']['acquired'] and status['device_witness_final']['authenticated']
assert status['seconds']<5400 and status['peak_owned_RSS_bytes']<5*1024**3
assert status['fixed_inputs_sha256']==sha(workflow/'fixed-inputs.json')
pins=load(here/'runtime-before-input-pins.json')
assert len(pins)==977 and all(sha(Path(p))==digest for p,digest in pins.items())
assert status['executable_sha256']==sha(release/'dome-sculpt-sculpt-sustained')
assert len(report['repetitions'])==3 and report['complete_planned_counts']
rows=[json.loads(line) for line in (workflow/'raw-samples.ndjson').read_text().splitlines()]
assert len(rows)==7690
assert sum(r['kind']=='independent_checkpoint' for r in rows)==42
assert sum(r['kind']=='exact_history_and_stale_generation' for r in rows)==3
projects={str(f.relative_to(workflow)):{'bytes':f.stat().st_size,'sha256':sha(f)} for f in workflow.rglob('*.dsculpt')}
assert len(projects)==3 and all(x['sha256']=='db9c506daedc1b13992838200b95e9e4569e98155bce306142803aca6cb8edb8' for x in projects.values())
suite=load(combined/'cpu-v1/status.json')
assert suite['terminal'] and suite['exit']==0 and len(suite['cases'])==5 and not suite['input_drift']
paths=[here/p for p in ('runtime-before-input-pins.json','run-arc-independent-p1.py','seal.py')]
paths += [run/p for p in ('status.json','actual-maps.txt','product.log','provider-before-pins.json')]
paths += list(run.glob('*.ldd')) + [run/'ldd.txt']
paths += [workflow/p for p in ('result.json','raw-samples.ndjson','fixed-inputs.json','context-initial.maps')]
paths += [release/p for p in ('build-plan.json','build-status.json','app-build/status.json')]
paths += [combined/p for p in ('build.py','run.py','run-combined.py','build-status.json','commands.json','before-input-pins.json','cpu-v1/status.json')]
paths += sorted((combined/'cpu-v1').glob('*.log'))
unit='ds-sculpt-sharing-range-search-arc-20261126'
journal=here/(unit+'.journal.txt')
journal.write_bytes(subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager']))
assert b'Started' in journal.read_bytes() and b'Failed with result' not in journal.read_bytes()
paths.append(journal)
dest=docs/'sculpt-range-arc-and-combined-fixtures-20261126.tar.xz'
manifest={}
with tarfile.open(dest,'w:xz',preset=6) as ar:
    for f in paths:
        key=str(f.relative_to(artifacts))
        data=f.read_bytes()
        assert key not in manifest
        manifest[key]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        member=tarfile.TarInfo(key)
        member.size=len(data)
        ar.addfile(member,io.BytesIO(data))
with tarfile.open(dest,'r:xz') as ar:
    assert set(ar.getnames())==set(manifest)
    for member in ar:
        assert member.size==manifest[member.name]['bytes']
        assert hashlib.file_digest(ar.extractfile(member),'sha256').hexdigest()==manifest[member.name]['sha256']
receipt={'scope':'Full sustained Arc on exact f9c20398 with original allocator controls and original three repetitions, plus separate native fixture rerun at c90c9fed against the 2aff79f7 product core. Native project bytes share the archived original ec hash; application routing and physical headset behavior have separate evidence.',
         'arc_invocation':'e67dd341403048fa8e87432462165fd1','arc':status,'exact_projects':projects,
         'checkpoints':42,'history_sequences':3,'raw_rows':len(rows),
         'combined_fixtures_invocation':'d6d7d852f7f24b14b49463eeceffdccf','combined_fixtures':suite,
         'authorities':manifest,'archive':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':sha(dest)}}
dest.with_name(dest.name.replace('.tar.xz','.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(len(manifest),receipt['archive'])
