from pathlib import Path
import hashlib
import json
import subprocess
import time
import xml.etree.ElementTree as ET

where = Path(__file__).resolve().parent
build = where.parent
source = Path(json.loads((build/'build-plan.json').read_text())['source_tree'])
commit = subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'], text=True).strip()
assert commit == '07025cd3995626bd32a9d0a848a2564965583ada'
targets = ['dome-sculpt-source-joint-writable-normal-bake-test',
           'dome-sculpt-source-owning-hdr-domain-test', 'dome-sculpt-source-owning-hdr-export-test',
           'dome-sculpt-source-hdr-provenance-closure-test', 'dome-sculpt-source-retained-emission-worker-test',
           'dome-sculpt-texture-set-bake-recipe-test', 'dome-sculpt-creator-workspace-test',
           'dome-sculpt-creator-vrm-test', 'dome-sculpt-creator-archive-test']
regex = '^(source-(hdr-provenance-closure|retained-emission-worker|owning-hdr-(domain|export))|texture-set-bake-recipe|creator-(controls-output|workspace|shaped-vrm|archive))$'
command = ['/usr/bin/ninja','-d','keepdepfile','-d','keeprsp','-v','-j3',*targets]
test = ['ctest','-j1','--output-on-failure','--output-junit','regression.xml','-R',regex]
state = {'source':commit,'terminal':False,'build':{'argv':command},'ctest':{'argv':test}}
def save():
    p = where/'status.tmp'
    p.write_text(json.dumps(state, indent=2)+'\n')
    p.replace(where/'status.json')
def execute(command,cwd,log):
    start = time.monotonic()
    with (where/log).open('w') as handle:
        process = subprocess.run(command,cwd=cwd,stdout=handle,stderr=subprocess.STDOUT)
    return {'exit':process.returncode,'seconds':time.monotonic()-start}
save()
try:
    app = build/'dome-sculpt'
    with app.open('rb') as f:
        state['app_sha256'] = hashlib.file_digest(f,'sha256').hexdigest()
    assert state['app_sha256'] == 'ad24e8d91fc977e070e151c844422cb50755c4731d5f829d3431a9e23f98b32d'
    state['build'].update(execute(command,build,'build.log'))
    save()
    assert state['build']['exit'] == 0
    state['ctest'].update(execute(test,where,'ctest.log'))
    assert (where/'regression.xml').is_file()
    result = ET.parse(where/'regression.xml').getroot()
    state['ctest']['junit'] = result.attrib
    state['ctest']['cases'] = [case.attrib for case in result.findall('testcase')]
    assert result.get('tests') == '12'
    assert result.get('skipped') == result.get('failures') == result.get('disabled') == '0'
    state['exit'] = state['ctest']['exit']
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal'] = True
    save()
print(json.dumps(state),flush=True)
raise SystemExit(state['exit'])
