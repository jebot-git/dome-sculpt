from pathlib import Path
import json
import subprocess
import time
import xml.etree.ElementTree as ET

here=Path(__file__).resolve().parent
candidate=here.parent
build=here.parent.parent/'serialize-sculpt-objects-release-20261126'
source=here.parent.parent/'layered-normal-authority-source-20261126'
assert subprocess.check_output(['git','-C',str(source),'rev-parse','--short','HEAD'],text=True).strip()=='c0a67586'
assert json.loads((candidate/'result.json').read_text())['exit']==0
names=('canonical-native-pose','canonical-normal-uv','layered-normal-uv-safety',
       'layered-normal-uv-native','layered-normal-render','authoring-native-normal-union','native-paint32-export')
targets=[f'dome-sculpt-{name}-test' for name in names]
state={'fixture_source':'c0a67586','production_source':'07025cd3','terminal':False}
def save():
    p=here/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(here/'status.json')
def call(argv,log,cwd):
    start=time.monotonic()
    with (here/log).open('w') as sink:
        task=subprocess.run(argv,cwd=cwd,stdout=sink,stderr=subprocess.STDOUT)
    return {'command':argv,'seconds':time.monotonic()-start,'exit':task.returncode}
save()
try:
    state['build']=call(['/usr/bin/ninja','-j3','-d','keepdepfile','-d','keeprsp','-v',*targets],
                        'build.log',build)
    save()
    assert state['build']['exit']==0
    meta=(build/'CTestTestfile.cmake').read_text()
    old=f'"{build}/dome-sculpt-layered-normal-native-test"'
    assert meta.count(old)==1
    meta=meta.replace(old,f'"{candidate}/dome-sculpt-layered-normal-native-test"')
    for rel in ('layered-normal-native','layered-normal-uv-native','layered-normal-render',
                'authoring-native-normal-union','native-paint32-fixture.dsculpt'):
        meta=meta.replace(f'"{build}/{rel}/',f'"{here}/cases/{rel}/').replace(f'"{build}/{rel}"',f'"{here}/cases/{rel}"')
    (here/'cases').mkdir()
    (here/'CTestTestfile.cmake').write_text(meta)
    isolated=['/usr/bin/bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
              '--bind',str(here),str(here),'--dev','/dev','--proc','/proc','--tmpfs','/run/user','--tmpfs','/tmp',
              '--clearenv','--setenv','PATH','/usr/bin:/bin','--setenv','LIBGL_ALWAYS_SOFTWARE','1',
              '--setenv','LP_NUM_THREADS','2','--setenv','EGL_PLATFORM','surfaceless',
              '--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
              '/usr/bin/ctest','-j1','--test-dir',str(here),'--output-on-failure','--output-junit',str(here/'dependent.xml'),
              '-R','^(canonical-(native-pose|normal-uv)|layered-normal-(uv-native|uv-safety|render)|authoring-native-normal-union|native-paint32-fixture)$']
    state['ctest']=call(isolated,'ctest.log',here)
    xml=ET.parse(here/'dependent.xml').getroot()
    state['junit']=xml.attrib
    assert xml.get('tests')=='8'
    state['exit']=state['ctest']['exit']
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
