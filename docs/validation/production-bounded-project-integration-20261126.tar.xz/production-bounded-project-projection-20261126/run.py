from pathlib import Path
import hashlib
import json
import re
import shlex
import subprocess
import time

here = Path(__file__).resolve().parent
build = here.parent / 'serialize-sculpt-objects-release-20261126'
prior = here.parent / 'serialize-sculpt-objects-source-20261126'
current = here.parent / 'production-bounded-project-source-20261126'
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):
    return subprocess.check_output(['git','-C',str(current),*args], text=True).strip()
assert git('rev-parse','HEAD') == '2472718c898a300929240934fedbfe102b84a519'
assert git('diff','--name-only','07025cd3','HEAD') == 'tests/normal-projection-sharing.cpp'
assert not git('status','--porcelain')
archive = build/'libdome-sculpt-core.a'
archive_sha = digest(archive)
previous_review = json.loads((build/'profile-variant'/'result.json').read_text())
assert archive_sha == previous_review['archive_sha256']
source = prior/'tests/normal-projection-sharing.cpp'
commands = json.loads((build/'compile_commands.json').read_text())
first, = (c for c in commands if c['file']==str(source))
target = 'dome-sculpt-normal-projection-sharing-test'
commands = subprocess.check_output(['ninja','-t','commands',target],cwd=build,text=True)
_, command, _ = commands.splitlines()[-1].split(' && ')
base = shlex.split(command)
item = first['command']
state = {'product_source':'07025cd3995626bd32a9d0a848a2564965583ada',
         'combined_fixture_source':git('rev-parse','HEAD'), 'core_sha256':archive_sha,'cases':{},'terminal':False}
def save():
    tmp=here/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(here/'status.json')
save()
try:
    for name, path in [('original', source), ('corrected', current/'tests/normal-projection-sharing.cpp')]:
        out = here/name
        out.mkdir()
        obj = out/'normal-projection-sharing.cpp.o'
        exe = out/target
        cmd = [str(path) if x==str(source) else x for x in shlex.split(item)]
        cmd[cmd.index('-o')+1] = str(obj)
        cmd[1:1] = ['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
        link = [str(obj) if v.endswith('/tests/normal-projection-sharing.cpp.o')
                else str(exe) if v==target
                else '-Wl,--dependency-file='+str(out/'link.d') if v.startswith('-Wl,--dependency-file=')
                else v for v in base]
        row = dict(source_sha256=digest(path),compile=cmd,link=link)
        with (out/'build.log').open('w') as f:
            subprocess.run(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True)
            subprocess.run(link,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True)
        start = time.monotonic()
        result = subprocess.run([str(exe),str(out/'workflow')],cwd=build,text=True,
                                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=900)
        (out/'product.log').write_text(result.stdout)
        checks = re.findall(r'^PASS (\d+) normal projection sharing controls$',result.stdout,re.M)
        row.update(exit=result.returncode,checks=checks,seconds=time.monotonic()-start,exe_sha256=digest(exe))
        state['cases'][name]=row
        save()
        print(name,result.returncode,result.stdout.strip().splitlines()[-1],flush=True)
    current_result=state['cases']['corrected']
    assert digest(archive)==archive_sha
    state['exit']=int(not (current_result['exit']==0 and current_result['checks']==['11']))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
raise SystemExit(state['exit'])
