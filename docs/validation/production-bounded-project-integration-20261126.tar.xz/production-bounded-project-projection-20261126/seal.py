from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET

here=Path(__file__).resolve().parent
root=here.parent.parent
artifacts=here.parent
baseline=artifacts/'production-full-regression-release-20261126'
build=artifacts/'serialize-sculpt-objects-release-20261126'
regression=build/'regression-hdr-creator'
diagnostic=artifacts/'layered-normal-native-diagnostic-20261126'
corrected=artifacts/'layered-normal-authority-release-20261126'
output=root/'docs/validation/production-bounded-project-integration-20261126.tar.xz'
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def data(path):
    return json.loads(path.read_text())
def pick(folder,names):
    return [folder/p for p in names.split()]
build_result=data(baseline/'build-status.json')
assert build_result['exit']==0 and build_result['terminal']
steps=re.findall(r'^\[(\d+)/1802\] ',(baseline/'build.log').read_text(),re.M)
assert list(map(int,steps))==list(range(1,1803))
assert not re.search(r'^FAILED:',(baseline/'build.log').read_text(),re.M)
release=data(regression/'status.json')
assert release['terminal'] and release['exit']==0
xml=ET.parse(regression/'regression.xml').getroot()
assert xml.get('tests')=='12' and xml.get('skipped')==xml.get('disabled')==xml.get('failures')=='0'
assert digest(build/'dome-sculpt')==release['app_sha256']
app=data(build/'app-build-status.json')
assert app['terminal'] and app['source']==release['source'] and app['exit']==0
case=data(here/'status.json')
assert case['exit']==0 and case['terminal'] and case['cases']['original']['exit']==1
assert case['cases']['corrected']['checks']==['11']
assert data(diagnostic/'result.json')['exit']==1 and data(corrected/'result.json')['exit']==0
dependent=data(corrected/'dependents/status.json')
assert dependent['terminal'] and dependent['exit']==0 and dependent['junit']['tests']=='8'
complete=(baseline/'full-private-ctest'/'ctest.log').read_text()
first=re.search(r'^.*layered-normal-native +[.]+\*\*\*Failed.*$',complete,re.M).start()
last=complete.index('FAIL Independent prepared source cannot bypass',first)
prefix=complete[first:last].splitlines()+[complete[last:].splitlines()[0]]
(here/'broad-original-layered-failure.log').write_text('\n'.join(prefix)+'\n')
units={'full-build':'ds-production-full-regression-release-20261126',
       'current-app':'ds-serialize-sculpt-objects-app-release-20261126',
       'current-native':'ds-serialize-sculpt-objects-regression-20261126',
       'projection-fixture':'ds-production-bounded-project-projection-20261126',
       'layered-original-diagnostic':'ds-layered-normal-native-diagnostic-20261126',
       'layered-corrected':'ds-layered-normal-authority-release-20261126',
       'layered-dependents':'ds-layered-normal-authority-dependents-20261126'}
for name,unit in units.items():
    journal=subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager'])
    assert journal and b'-- No entries --' not in journal
    (here/f'{name}.journal.txt').write_bytes(journal)
paths=pick(baseline,'build-plan.json build-status.json build.log CMakeCache.txt compile_commands.json CTestTestfile.cmake')
paths+=pick(build,'app-build-status.json app-build.log CMakeFiles/dome-sculpt.dir/link.d CMakeCache.txt')
paths+=pick(regression,'run.py status.json build.log ctest.log regression.xml Testing/Temporary/LastTest.log')
paths+=pick(here,'run.py seal.py status.json broad-original-layered-failure.log')
for case_name in ('original','corrected'):
    paths+=pick(here/case_name,'build.log product.log normal-projection-sharing.cpp.o.d link.d')
for folder in (diagnostic,corrected):
    paths+=pick(folder,'plan.json result.json product.log layered-normal-native.cpp.o.d link.d')
paths+=pick(corrected/'dependents','run.py status.json build.log ctest.log dependent.xml CTestTestfile.cmake Testing/Temporary/LastTest.log')
paths+=list(sorted(here.glob('*.journal.txt')))
authorities={}
with tarfile.open(output,'w:xz',preset=6) as archive:
    for path in paths:
        name=str(path.relative_to(artifacts))
        payload=path.read_bytes()
        assert name not in authorities
        authorities[name]={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}
        item=tarfile.TarInfo(name)
        item.size=len(payload)
        archive.addfile(item,io.BytesIO(payload))
with tarfile.open(output,'r:xz') as archive:
    assert set(x.name for x in archive)==set(authorities)
    for item in archive:
        p=authorities[item.name]
        assert item.size==p['bytes'] and hashlib.file_digest(archive.extractfile(item),'sha256').hexdigest()==p['sha256']
receipt={'scope':'Fresh 1802-action predecessor Release build; exact 07025 full App and HDR/creator native12; standalone differential fixture qualification and original broad failure. Ongoing all-suite status is separate.',
         'predecessor_full_build':build_result,'app':app,'app_sha256':release['app_sha256'],'current_native':release,
         'projection':case,'layered_native':{'fixture_source':'c0a67586','product_source':'07025cd3',
                   'diagnostic_baseline_product_source':'c26a8573','refusal_owner_guard_added':True,'positive_source_and_project_roundtrip_checks_added':True,'dependent_cohort':dependent},
         'authorities':authorities,'archive':{'name':output.name,'bytes':output.stat().st_size,'sha256':digest(output)}}
output.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(authorities),receipt['archive'])
