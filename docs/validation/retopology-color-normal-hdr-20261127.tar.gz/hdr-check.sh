#!/usr/bin/bash
set -euo pipefail
profile="$1"
run="$2"
out="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$out/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/$profile"
sdk=/opt/fltk-vr/toolkit
if [[ "$profile" == asan ]]; then sdk="$repo/artifacts/sdk-20261126/toolkit-sanitize"; fi
prefix=(bwrap --die-with-parent --unshare-all --ro-bind / / --bind "$out/$profile" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH "$sdk/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64" --setenv ASAN_OPTIONS detect_leaks=1:halt_on_error=1 --setenv UBSAN_OPTIONS halt_on_error=1:print_stacktrace=1 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
if [[ "$profile" == asan ]]; then
    "${prefix[@]}" cmake -S "$repo" -B "$seed" > "$out/$profile-$run-configure.log" 2>&1
    "${prefix[@]}" python3 "$out/relink-sanitizer.py" "$seed" src/emission-export.cpp src/emission-package.cpp src/native-authoring-compiler.cpp tests/canonical-paint-color-hdr.cpp > "$out/$profile-$run-build.log" 2>&1
    "${prefix[@]}" "$seed/dome-sculpt-canonical-paint-color-hdr-test" "$seed/retopology-prepared-color-normal-uv-plain/retained-uv.dsculpt" "$seed/hdr-check-$run" > "$out/$profile-$run.log" 2>&1
else
    "${prefix[@]}" cmake --build "$seed" --parallel 4 --target dome-sculpt-native-paint32-export-test dome-sculpt dome-sculpt-xr-editable-export-test dome-sculpt-test-runtime dome-sculpt-canonical-paint-color-hdr-test dome-sculpt-retopo-surface-heat-test dome-sculpt-canonical-normal-owning-test dome-sculpt-canonical-paint-fixture-test dome-sculpt-canonical-paint-native-test dome-sculpt-canonical-paint37-emission-test dome-sculpt-canonical-paint37-emission-contracts-test dome-sculpt-canonical-paint37-emission-mixed-test dome-sculpt-canonical-paint37-emission-render-test dome-sculpt-native-paint32-emission-test dome-sculpt-native-paint32-emission-contracts-test dome-sculpt-native-paint32-emission-mixed-test dome-sculpt-native-authoring-real-test > "$out/$profile-$run-build.log" 2>&1
    "${prefix[@]}" ctest --test-dir "$seed" --parallel 3 -R '^(canonical-paint-color-hdr|retopology-prepared-color-normal-uv-affine|canonical-paint37-emission-(worker|render|mixed|contracts)|native-paint32-emission(-contracts|-mixed)?|native-authoring-real|xr-canonical-paint-color-hdr-export|xr-native-paint32-export|xr-editable-export)$' --output-on-failure > "$out/$profile-$run.log" 2>&1
fi
