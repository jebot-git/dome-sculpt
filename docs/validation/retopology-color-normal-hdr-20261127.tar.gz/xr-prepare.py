from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

work = Path(__file__).resolve().parent
build = work / "release"
mode = sys.argv[1]
slot = work / ("xr-" + mode)
slot.mkdir(exist_ok=True)
data = []
runtime_library = build / "libdome-sculpt-test-runtime.so"
for name in ("original",):
    output = slot / name
    output.mkdir(exist_ok=True)
    project = build / "canonical-paint-color-hdr" / f"{name}.dsculpt"
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="dome-retained-xr-") as temp:
        private = Path(temp)
        runtime = private / "runtime.json"
        runtime.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{
            "library_path":str(runtime_library)}}))
        metadata = output / "report.json"
        saved = output / "closed.dsculpt"
        env = dict(os.environ, HOME=temp, XR_RUNTIME_JSON=str(runtime),
                   DOME_XR_FIXTURE_PBR_VIEW="1", DOME_XR_FIXTURE_REPORT=str(metadata))
        for part in ("config", "state", "data", "cache", "runtime"):
            local = private / part
            local.mkdir(mode=0o700)
            env["XDG_" + part.upper() + ("_DIR" if part=="runtime" else "_HOME")] = str(local)
        with (output / "app.log").open("w") as log:
            subprocess.run([build/"dome-sculpt","--xr","--open",project,"--frames","7","--save",saved],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=45)
        info = json.loads(metadata.read_text())
        assert info["action_syncs"] == 7 and info["stereo_submissions"] == 6
        assert info["acquires"] == info["image_waits"] == info["releases"] == 12
        assert ("Arc(tm) A770" if mode == "arc" else "llvmpipe") in info["gl_renderer"], info["gl_renderer"]
        assert all(info["pbr_preview_images"]["6"][str(eye)]["opaque"] > 0 for eye in (0,1))
        assert project.read_bytes() == saved.read_bytes()
        data.append(info)
report = {"runtime":"synthetic OpenXR", "profiles":data, "exact_ordered_close":True}
(slot / "compare.json").write_text(json.dumps(report, indent=2)+"\n")
print(f"PASS {mode} retained HDR native project rendered and closed with exact ordered Save")
