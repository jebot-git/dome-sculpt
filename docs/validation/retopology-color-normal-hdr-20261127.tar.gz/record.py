from hashlib import sha256
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs' / 'validation'
release = work / 'release'
sanitized = work / 'asan'
label = work.name

def sha(path):
    return sha256(path.read_bytes()).hexdigest()

def revision(path):
    return subprocess.check_output(['git','-C',path,'rev-parse','HEAD'],text=True).strip()

def read(name):
    return json.loads((work / name).read_text())

def ctest():
    log = (work / 'release-controller.log').read_text()
    tests = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed',log)
    assert len(tests) == len(set(tests)) == 18, log
    assert '0 tests failed out of 18' in log
    assert 'xr-canonical-paint-color-hdr-export' in tests
    return tests

selected_release = ctest()
full_results = (release / 'Testing/Temporary/LastTest.log').read_text()
bodies = {}
for name in ['canonical-paint-color-hdr', 'xr-canonical-paint-color-hdr-export']:
    test = re.search(r'^\d+/\d+ Testing: '+name+r'\n(.*?)^Test Passed\.',full_results,re.M|re.S)
    assert test, name
    bodies[name] = test[1]
    (work / (name + '-release.log')).write_text(test[1])

sanitizer_checks = (work/'asan-validated.log').read_text().splitlines()
assert len(sanitizer_checks) == 20 and all(line.startswith('PASS ') for line in sanitizer_checks), sanitizer_checks
assert all(line in bodies['canonical-paint-color-hdr'] for line in sanitizer_checks)
assert 'Controller native HDR package recovers complete exact project' in bodies['xr-canonical-paint-color-hdr-export']
assert 'controller Cancel preserves old export bytes' in bodies['xr-canonical-paint-color-hdr-export']

outputs = {}
for name in ['original.dsculpt','standard.glb','editable.glb']:
    path = release/'canonical-paint-color-hdr'/name
    assert sha(path) == sha(sanitized/'hdr-check-validated'/name)
    outputs[name] = sha(path)

wayland = read('wayland-hdr/report.json')
assert wayland['complete'] and len(wayland["checks"]) == 9
assert all(item['passed'] for item in wayland['checks'])
xr_exports = release/'xr-canonical-paint-color-hdr-export'
assert outputs['standard.glb'] == sha(work/'wayland-hdr/Sculpt.glb') == sha(xr_exports/'choice.glb')
assert outputs['editable.glb'] == sha(xr_exports/'editable256.glb')
assert sha(work/'wayland-hdr/Project.glb') == sha(xr_exports/'editable512.glb')
assert outputs['original.dsculpt'] == sha(xr_exports/'cancel-after.dsculpt')
seed='retopology-prepared-color-normal-uv-plain/retained-uv.dsculpt'
assert sha(release/seed) == sha(sanitized/seed)

stereo = {}
for name in ['software','arc']:
    result = read(f'xr-{name}/compare.json')
    xr = result['profiles'][0]
    assert result['exact_ordered_close'] and xr['stereo_submissions']==6
    assert sha(work/f"xr-{name}/original/closed.dsculpt") == outputs['original.dsculpt']
    stereo[name] = dict(renderer=xr['gl_renderer'], stereo_submissions=xr['stereo_submissions'],
                        action_syncs=xr['action_syncs'], opaque_pixels=xr['pbr_preview_images']['6'],
                        native_save_sha256=outputs['original.dsculpt'])

khronos = read('khronos.json')
issues = {row['file']: row['issues'] for row in khronos['results']}
assert len(issues) == 4 and all(not (x['numErrors'] or x['numWarnings']) for x in issues.values())
baseline = json.loads((work.parent/'retopology-subdivide-20261127/combined-release/status.json').read_text())
assert baseline['terminal'] and baseline['totals'] == {'pass':1394,'fail':0,'skip':0}
(work/'previous-full-release.json').write_text(json.dumps(baseline,indent=2)+'\n')

files = ['hdr-check.sh','relink-sanitizer.py','canonical-paint-color-hdr-release.log','xr-canonical-paint-color-hdr-export-release.log',
         'release-controller.log','release-controller-build.log','asan-validated.log','asan-validated-build.log','asan-validated-configure.log',
         'asan-live-runtime.log','khronos.cjs','khronos.json','previous-full-release.json','record.py',
         'run-wayland.py','wayland-hdr.py','bind-wayland.log','wayland-hdr/report.json',
         'run-render.py','xr-prepare.py','xr-software/compare.json','xr-arc/compare.json']
archive = validation / (label + '.tar.gz')
archived = {}
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for name in files:
        data = (work/name).read_bytes()
        archived[name] = sha256(data).hexdigest()
        member = tarfile.TarInfo(name)
        member.size = len(data)
        tar.addfile(member, io.BytesIO(data))

receipt = {'product': revision(repo), 'canonical_domed': revision(repo.parent/'DomeD'),
           'canonical_domed_compositor_sha256': sha(work.parent/'creator-public-build-20261126/wayland-reference/dome-compositor'),
           'release_app_sha256':sha(release/'dome-sculpt'),
           'selected_release':selected_release,
           'strict_asan_ubsan':{'test':'canonical-paint-color-hdr','checks':len(sanitizer_checks),'leak_detection':True,
                               'binary_sha256':sha(sanitized/'dome-sculpt-canonical-paint-color-hdr-test')},
           'identical_release_and_sanitizer_output_sha256':outputs,
           'fixture_sha256':sha(release/seed),
           'wayland':wayland, 'synthetic_openxr':stereo, 'khronos_validator':khronos['validator'],
           'matching_wayland_xr_editable_512_sha256':sha(xr_exports/'editable512.glb'),
           'controller_checks':69,
           'khronos':{name:{k:v for k,v in row.items() if k.startswith('num')} for name,row in issues.items()},
           'earlier_full_release':baseline,'physical_headset':False,
           'archive_sha256':sha(archive), 'archive_members_sha256':archived}
(validation/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
