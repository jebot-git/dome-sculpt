const fs = require('node:fs');
const path = require('node:path');
const validator = require('../hdr-khronos-validation-20261126/module/package');
const files = ['release/canonical-paint-color-hdr/standard.glb',
               'release/canonical-paint-color-hdr/editable.glb',
               'wayland-hdr/Sculpt.glb', 'wayland-hdr/Project.glb'];
async function main() {
  const results = [];
  for (const file of files) {
    const bytes = fs.readFileSync(path.join(__dirname, file));
    const report = await validator.validateBytes(new Uint8Array(bytes), {uri: file});
    if (report.issues.numErrors || report.issues.numWarnings)
      throw new Error(JSON.stringify(report.issues));
    results.push({file, issues: report.issues});
  }
  fs.writeFileSync(path.join(__dirname, 'khronos.json'),
                   JSON.stringify({validator: validator.version(), results}, null, 2) + '\n');
  console.log('PASS Khronos zero errors or warnings on all four native-worker and GUI GLBs');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
