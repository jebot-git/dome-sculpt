"""Read-only case audit plus stopping its already-terminal, explicitly named unit."""
import argparse,fcntl,hashlib,json,os,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent
def main(a):
 out=P/('release-source-use-gui-'+a.case+'-'+a.tag)
 status=out/'status.json';s=json.loads(status.read_text())
 assert s['state']=='terminal','Refuse to stop a live case'
 unit=a.unit+'.service'if not a.unit.endswith('.service')else a.unit
 properties=subprocess.check_output(['systemctl','--user','show',unit],text=True)
 props=dict(x.split('=',1)for x in properties.splitlines()if'='in x)
 assert props['MainPID']=='0'and props['SubState']in ['exited','failed','dead']
 (out/'unit-final.txt').write_text(properties)
 (out/'unit-journal.txt').write_text(subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager'],text=True))
 subprocess.run(['systemctl','--user','stop',unit],check=True)
 (out/'unit-stopped.txt').write_text(subprocess.check_output(['systemctl','--user','show',unit,'-p','MainPID','-p','ActiveState','-p','SubState','-p','Result','-p','ExecMainStatus'],text=True))
 assert not s['remaining_owned_processes']
 apps=s.get('actual_app_pids',[])
 assert all(not(Path('/proc')/str(pid)).exists()for pid in apps)
 lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+')
 try:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(lease.fileno());nb={'epoch':time.time(),'inode':st.st_ino,'dev':st.st_dev};fcntl.flock(lease,fcntl.LOCK_UN)
 finally:lease.close()
 normals={}
 for f in(out/'workflow').glob('native-*.json'):
  value=json.loads(f.read_text());normals[f.name]=value.get('normal_oracle')
 record={'status_sha256':hashlib.sha256(status.read_bytes()).hexdigest(),'actual_exit':s['exit'],'case':a.case,'checks':s.get('checks'),'seconds':s.get('seconds'),'error':s.get('error'),'input_pins':len(s['pins']),'input_drift':s['input_drift'],'actual_App_PIDs':apps,'all_Apps_absent':True,'remaining_owned':s['remaining_owned_processes'],'unit_ExecMainStatus':int(props['ExecMainStatus']),'unit_Result':props['Result'],'unit_stopped':True,'critical_observed':s.get('critical_observed'),'Xvfb_certificates':s.get('actual_private_Xvfb'),'lease_released':s.get('lease_released_epoch'),'independent_NB_free':nb,'normal_phases':normals}
 (out/'closure-matrix-v1.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:v for k,v in record.items()if k not in ['normal_phases','Xvfb_certificates']},indent=2))
 assert s['exit']==0 and not s['input_drift']and s['checks']==16 and len(apps)==2 and props['ExecMainStatus']=='0'and props['Result']=='success'
 return 0
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--case',required=True);p.add_argument('--tag',required=True);p.add_argument('--unit',required=True);raise SystemExit(main(p.parse_args()))
