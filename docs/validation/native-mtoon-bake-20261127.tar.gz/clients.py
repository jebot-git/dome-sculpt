from pathlib import Path
import json
import os
import shlex
import subprocess
import sys

out = Path(__file__).resolve().parent
artifacts = out.parent
profile, mode = sys.argv[1:3]
built = out / (profile+'-admit')
app = built/'dome-sculpt'
helper = built/'dome-sculpt-bake-recipes-test'
public = artifacts/'creator-public-build-20261126'
compositor = public/'wayland-reference/dome-compositor'
reference = artifacts/'current-integrated-full-release-20261127/build'
source = out/'source'
toolkit = Path('/opt/fltk-vr/toolkit') if profile=='release' else artifacts/'sdk-20261126/toolkit-sanitize'
workspace = out / (profile+'-'+mode)
workspace.mkdir(exist_ok=True)
env = {
    'PATH':str(public/'private-bin-v3')+':/usr/bin:/bin', 'HOME':'/tmp',
    'PYTHONPATH':str(public/'private-python'), 'PYTHONDONTWRITEBYTECODE':'1',
    'LD_LIBRARY_PATH':f'{toolkit}/lib:/opt/fltk-vr/bdf-runtime/lib:'+str(public/'private-x11/usr/lib64')+':/usr/lib64',
    'LP_NUM_THREADS':'2', 'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1',
    'UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
}
bwrap = ['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
         '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
if mode=='arc':
    bwrap = ['flock','--timeout','240','/tmp/dome-sculpt-arc-device.lock',*bwrap]
    bwrap += ['--dev-bind','/dev/dri/renderD129','/dev/dri/renderD129']
    env.update(DRI_PRIME='pci-0000_03_00_0',EGL_PLATFORM='surfaceless',MESA_SHADER_CACHE_DISABLE='1')
    run = [built/'dome-sculpt-mtoon-render-test','--baked-texture-sets',workspace]
elif mode=='openxr':
    runtime = reference/'libdome-sculpt-test-runtime.so'
    run = ['/usr/bin/python3.14', source/'tests/bake-recipes-xr.py',
           app, runtime, helper, workspace, '--texture-set','--mtoon']
elif mode in {'wayland','wayland-diagnostic'}:
    probe = artifacts/'combined-atlas-hdr-preview-full-20261126/build/libdome-sculpt-test-widgets.so'
    env.update(DOME_COMPOSITOR=str(compositor),DOME_CAGE_APP=str(app),
               DOME_CAGE_HELPER=str(helper),DOME_CAGE_PROBE=str(probe),
               DOME_CAGE_WL_OUT=str(workspace),DOME_CAGE_TEXTURE_SET='1',DOME_BAKE_FIXTURE_MTOON='1')
    run = ['/usr/bin/python3.14',out/'wayland-observer.py' if mode=='wayland-diagnostic' else source/'tests/bake-recipes-wayland.py']
else:
    raise ValueError(mode)
for key,value in env.items():
    bwrap.extend(['--setenv',key,value])
with (out/(profile+'-'+mode+'.log')).open('w') as log:
    args = [*bwrap,*run]
    print(shlex.join(map(str,args)),file=log,flush=True)
    subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
if mode=='arc':
    log = (out/(profile+'-'+mode+'.log')).read_text()
    assert 'Arc(tm) A770' in log and 'PASS 70 baked MToon texture-set graphics checks' in log
else:
    report = json.loads((workspace/'report.json').read_text())
    assert len(report['checks']) >= 15 and all(row['passed'] for row in report['checks'])
print(profile, mode, 'PASS')
