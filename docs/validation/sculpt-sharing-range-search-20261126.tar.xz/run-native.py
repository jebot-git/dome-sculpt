from pathlib import Path
import hashlib
import json
import math
import os
import re
import statistics
import subprocess
import time
from owned_monitor import run

here=Path(__file__).resolve().parent
plan=json.loads((here/'build-plan.json').read_text())
build=json.loads((here/'build-status.json').read_text())
assert build['terminal'] and build['exit']==0 and len(build['linked_archive']['replacements'])==8
assert not Path('/dev/dri').exists()
assert not any(k in os.environ for k in ('MALLOC_ARENA_MAX','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES'))
input=here.parent/'production-sculpt-index-integration-release-20261126/native-default/sculpt/accepted.dsculpt'
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
pin=sha(input)
assert pin=='d32c725a02d3d9291f3208c879f78ecc343c33511de9e10b5c18d93bb95fd694'
out=here/'native'
out.mkdir()
state={'terminal':False,'input_sha256':pin,'diff_sha256':plan['source_diff_sha256'],'cases':{},'profile':{}}
def save():
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
save()
try:
    for k,mode in enumerate(('before','after','after','before')):
        log=out/f'stroke-{k}-{mode}.log'
        project=out/f'stroke-{k}-{mode}.dsculpt'
        exe=here/f'capture-profile-{mode}'
        row=run([str(exe),str(input),str(project)],cwd=out,env=os.environ.copy(),log=log,timeout=400,max_rss=4*1024**3)
        assert row['exit']==0 and 'error' not in row, log.read_text()
        parsed=re.findall(r'^STROKE_CAPTURE (\d+) ([0-9.e+\-]+) (\d+)$',log.read_text(),re.M)
        assert [int(x[0]) for x in parsed]==list(range(1,17))
        samples=[float(x[1]) for x in parsed]
        row.update(exe_sha256=sha(exe),samples_ms=samples,retained_bytes=[int(x[2]) for x in parsed],
                   median_ms=statistics.median(samples),project_sha256=sha(project))
        state['profile'][f'{k}-{mode}']=row
        save()
    before=state['profile']['0-before']['retained_bytes']
    after=state['profile']['1-after']['retained_bytes']
    assert before==state['profile']['3-before']['retained_bytes'] and after==state['profile']['2-after']['retained_bytes']
    assert before==after
    assert len({row['project_sha256'] for row in state['profile'].values()})==1
    for mode in ('before','after'):
        samples=[ms for k,v in state['profile'].items() if k.endswith('-'+mode) for ms in v['samples_ms']]
        s=sorted(samples)
        state[mode+'_summary']={'samples':len(s),'p50_ms':statistics.median(s),'p95_ms':s[math.ceil(.95*len(s))-1]}
    save()
    for name,exe,pattern in [('pipeline','dome-sculpt-sculpt-chunk-pipeline-test',r'^PASS total 94$'),
                             ('sculpt','dome-sculpt-sculpt-independent-workflow',r'^PASS independent production sculpt workflow checks=167')]:
        log=out/(name+'.log')
        row=run([str(here/exe),str(out/name)],cwd=out,env=os.environ.copy(),log=log,
                timeout=900,max_rss=4*1024**3)
        row.update(check_passed=bool(re.search(pattern,log.read_text(),re.M)),executable_sha256=sha(here/exe))
        state['cases'][name]=row
        save()
    assert sha(input)==pin
    assert sha(out/'sculpt'/'accepted.dsculpt')==pin
    state['exit']=int(any(x['exit']!=0 or 'error' in x or not x['check_passed'] for x in state['cases'].values()))
except BaseException as error:
    state.update(exit=1,error=repr(error))
finally:
    state['terminal']=True
    save()
print(json.dumps(state),flush=True)
raise SystemExit(state['exit'])
