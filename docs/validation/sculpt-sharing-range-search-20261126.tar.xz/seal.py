from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

here=Path(__file__).resolve().parent
docs=here.parent.parent/'docs/validation'
source=here.parent/'sculpt-sharing-range-search-source-20261126'
def load(rel):
    return json.loads((here/rel).read_text())
def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file,'sha256').hexdigest()
plan=load('build-plan.json')
diff=subprocess.check_output(['git','-C',str(source),'diff','--binary','0cdd1511','HEAD'])
head=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert head.startswith('f9c20398') and hashlib.sha256(diff).hexdigest()==plan['source_diff_sha256']
assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True)
built=load('build-status.json')
app=load('app-build/status.json')
native=load('native/status.json')
assert all(x['terminal'] and x['exit']==0 for x in (native,built,app))
assert len(built['compile'])==12 and len(built['links'])==4 and len(built['linked_archive']['replacements'])==8
assert sha(here/'dome-sculpt')==app['executables']['dome-sculpt']
assert sha(here/'dome-sculpt-sculpt-sustained')==app['executables']['dome-sculpt-sculpt-sustained']
assert set(native['cases'])=={'pipeline','sculpt'} and all(x['check_passed'] for x in native['cases'].values())
latest_projects={str(p.relative_to(here)):{'bytes':p.stat().st_size,'sha256':sha(p)}
    for p in (here/'native/sculpt').rglob('*.dsculpt')}
assert len(latest_projects)==3 and all(x['sha256']==native['input_sha256'] for x in latest_projects.values())
profiles = list(native['profile'].values())
assert len(profiles)==4 and len({tuple(x['retained_bytes']) for x in profiles})==1
outputs = {p.name:sha(p) for p in sorted((here/'native').glob('stroke-*.dsculpt'))}
assert len(outputs)==4 and len(set(outputs.values()))==1
assert set(outputs.values())=={x['project_sha256'] for x in profiles}
assert (here/'version.log').read_text().startswith('Dome Sculpt ')
units=['ds-sculpt-sharing-range-search-profile-20261126',
       'ds-sculpt-sharing-range-search-build-20261126','ds-sculpt-sharing-range-search-app-20261126']
paths=[here/p for p in ('build.py','prepare.py','capture-profile.cpp','build-app.py','run-native.py','owned_monitor.py',
              'build-plan.json','build-status.json','app-build/status.json','native/status.json','version.log','seal.py')]
paths+=sorted(here.glob('*.d'))+sorted((here/'app-build').glob('*.d'))
paths+=sorted((here/'native').glob('*.log'))
for unit in units:
    journal=subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager'])
    assert journal and b'-- No entries --' not in journal
    f=here/(unit+'.journal.txt')
    f.write_bytes(journal)
    paths.append(f)
p=docs/'sculpt-sharing-range-search-20261126.tar.xz'
manifest={}
with tarfile.open(p,'w:xz',preset=6) as archive:
    for f in paths:
        rel=str(f.relative_to(here))
        content=f.read_bytes()
        assert rel not in manifest
        manifest[rel]={'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
        item=tarfile.TarInfo(rel)
        item.size=len(content)
        archive.addfile(item,io.BytesIO(content))
with tarfile.open(p,'r:xz') as archive:
    assert set(archive.getnames())==set(manifest)
    for f in archive:
        assert manifest[f.name]['bytes']==f.size
        assert manifest[f.name]['sha256']==hashlib.file_digest(archive.extractfile(f),'sha256').hexdigest()
receipt={
 'source':head,
 'scope':'Private CPU snapshot capture for 32 actual changed strokes per build on the same saved four-object sculpt project. Alternated baseline/current/current/baseline. Exact retained size at every step and identical stroke outputs. Native pipeline and original full production sculpt passed, with matching App/render compilation, link and version.',
 'build':built,'application_build':app,'native':native,'exact_projects':latest_projects,'profile_projects':outputs,
 'authorities':manifest,'archive':{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}
}
p.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(manifest),receipt['archive'])
