#include "sculpt-scene-chunks.hpp"
#include <chrono>
#include <iostream>
#include <stdexcept>

int main(int argc, char **argv) try {
  if (argc != 3) return 2;
  auto scene = dome::Scene::load(argv[1]);
  using dome::detail::SculptSceneChunks;
  auto current = SculptSceneChunks::capture(scene, {81,0,1,true,true}).chunks;
  if (current->objects().size() != 4)
    throw std::runtime_error("Expected the four actual independent sculpt objects");
  for (uint64_t i=1; i<=16; ++i) {
    auto &volume = *scene.active().volume;
    const auto previous = volume.geometry_owner();
    dome::Brush brush;
    brush.from = brush.to = {-.14f + float(i % 8) * .038f, -.08f + float(i / 8) * .08f, .58f};
    brush.normal = {0, 0, 1};
    brush.radius = .055f;
    brush.strength = .23f;
    brush.blend = .006f;
    brush.tool = dome::Tool::Clay;
    volume.begin_stroke();
    volume.stamp(brush);
    if (!volume.end_stroke() || volume.geometry_owner() == previous)
      throw std::runtime_error("Expected an actual geometry change");
    const auto start = std::chrono::steady_clock::now();
    auto next = SculptSceneChunks::capture(scene, {81,i,1,true,true}, current).chunks;
    const auto elapsed = std::chrono::steady_clock::now() - start;
    if (next->objects().size() != current->objects().size())
      throw std::runtime_error("Stroke changed the visible object count");
    for (const auto &object : next->objects()) {
      if (object.object == scene.active().id) continue;
      const auto *previous = current->find(object.object);
      if (!previous || previous->geometry != object.geometry || previous->placed != object.placed)
        throw std::runtime_error("Stroke changed an unrelated immutable placed geometry owner");
    }
    std::cout << "STROKE_CAPTURE " << i << ' '
              << std::chrono::duration<double,std::milli>(elapsed).count() << ' '
              << next->retained_bytes() << '\n';
    current = std::move(next);
  }
  scene.save(argv[2]);
  return 0;
} catch(const std::exception &error) {
  std::cerr << error.what() << '\n';
  return 1;
}
