from pathlib import Path
import os
import subprocess
import sys
parent=Path(__file__).resolve().parent
mode=sys.argv[1]
here=parent/mode
env=dict(os.environ)
env['LD_LIBRARY_PATH']='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'
subprocess.run(['/usr/bin/python3',str(here/'build.py')],check=True,env=env)
arg=['/usr/bin/bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
     '--bind',str(here),str(here),'--proc','/proc','--dev','/dev','--tmpfs','/tmp',
     '--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
     '--setenv','LD_LIBRARY_PATH',env['LD_LIBRARY_PATH']]
if mode=='strict':
    arg+=['--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1:abort_on_error=1',
          '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1']
result=subprocess.run([*arg,'/usr/bin/python3',str(here/'run-native.py')])
raise SystemExit(result.returncode)
