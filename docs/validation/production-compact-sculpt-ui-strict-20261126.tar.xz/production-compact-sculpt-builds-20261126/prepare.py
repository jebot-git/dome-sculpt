from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys

group=Path(__file__).resolve().parent
artifacts=group.parent
mode=sys.argv[1]
assert mode in ('release','strict')
here=group/mode
source=artifacts/'production-compact-sculpt-source-20261126'
config_source=artifacts/'serialize-sculpt-objects-source-20261126'
config=artifacts/f'serialize-sculpt-objects-{mode}-20261126'
previous=artifacts/('sculpt-scene-prefix-accounting-release-20261126' if mode=='release' else
   'production-sculpt-index-integration-strict-20261126')
archive=previous/'libdome-sculpt-core.a'
def sha(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()
def git(*args):
    return subprocess.check_output(['git','-C',str(source),*args],text=True).strip()
assert git('rev-parse','HEAD')=='0cdd15114b8604a9deb91da02e4817f881f67da3'
assert not git('status','--porcelain')
record=json.loads((previous/'build-status.json').read_text())
assert record['terminal'] and record['exit']==0 and sha(archive)==record['linked_archive']['sha256']

owner_map={}
core={'src/sculpt-surface-chunks.cpp'}
test_owners={
    'dome-sculpt-sculpt-surface-chunks-test':'tests/sculpt-surface-chunks.cpp',
    'dome-sculpt-sculpt-chunk-pipeline-test':'tests/sculpt-chunk-pipeline.cpp',
    'dome-sculpt-sculpt-independent-workflow':'tests/sculpt-independent-workflow.cpp',
}
render=None
if mode=='release':
    assert git('diff','--name-only','50f7abfa','HEAD','--','src','tests')=='src/sculpt-surface-chunks.cpp'
    app=json.loads((previous/'app-build/status.json').read_text())
    assert app['terminal'] and app['exit']==0
    render=previous/'libdome-sculpt-render.a'
    assert sha(render)==app['render_sha256']
    release_ec=artifacts/'production-sculpt-index-integration-release-20261126'
    owner_map={
      test_owners['dome-sculpt-sculpt-surface-chunks-test']:release_ec/'tests/sculpt-surface-chunks.cpp.o',
      test_owners['dome-sculpt-sculpt-chunk-pipeline-test']:previous/'sculpt-chunk-pipeline.cpp.o',
      test_owners['dome-sculpt-sculpt-independent-workflow']:previous/'sculpt-independent-workflow.cpp.o',
      'src/app.cpp':previous/'app-build/app.cpp.o',
      'tests/sculpt-sustained.cpp':previous/'app-build/sculpt-sustained.cpp.o',
    }
    test_owners.update({'dome-sculpt':'src/app.cpp','dome-sculpt-sculpt-sustained':'tests/sculpt-sustained.cpp'})
else:
    by_dep=set()
    for dep in (config/'CMakeFiles/dome-sculpt-core.dir').rglob('*.d'):
        if '/sculpt-scene-chunks.hpp' in dep.read_text():
            by_dep.add('src/'+dep.name.removesuffix('.o.d'))
    assert len(by_dep)==7
    core.update(by_dep)
    core.add('src/paint.cpp')
    old_tests={
      'dome-sculpt-scene-file-test':'tests/scene-file.cpp',
      'dome-sculpt-document-recovery-test':'tests/document-recovery.cpp',
      'dome-sculpt-atomic-write-allocation-test':'tests/atomic-write-allocation.cpp',
    }
    test_owners.update(old_tests)
    unchanged={*old_tests.values(),test_owners['dome-sculpt-sculpt-surface-chunks-test']}
    assert not git('diff','--name-only','ec578e56','HEAD','--',*unchanged)
    owner_map={name:previous/'tests'/(Path(name).name+'.o') for name in unchanged}
    test_owners.update({'dome-sculpt-corner-color-uv23-domain-test':'tests/corner-color-uv23-domain.cpp',
                        'dome-sculpt-baked-emission-workflow-test':'tests/baked-emission-workflow.cpp'})

unchanged_owners={name:{'path':str(path),'sha256':sha(path)} for name,path in owner_map.items()}
commands={c['file']:c for c in json.loads((config/'compile_commands.json').read_text())}
compiles=[]
for rel in sorted(core | (set(test_owners.values())-set(owner_map))):
    argv=shlex.split(commands[str(config_source/rel)]['command'].replace(str(config_source),str(source)))
    obj=here/rel.split('/')[0]/(Path(rel).name+'.o')
    obj.parent.mkdir(exist_ok=True)
    argv[argv.index('-o')+1]=str(obj)
    argv[1:1]=['-MD','-MF',str(obj)+'.d','-MT',str(obj)]
    compiles.append({'name':rel.replace('/','-'),'argv':argv})
    owner_map[rel]=obj
links=[]
for target,rel in test_owners.items():
    _,line,_=subprocess.check_output(['ninja','-t','commands',target],cwd=config,text=True).splitlines()[-1].split(' && ')
    argv=[]
    for value in shlex.split(line):
        if value.startswith('-Wl,--dependency-file='):value=f'-Wl,--dependency-file={here}/{target}.link.d'
        elif value==target:value=str(here/target)
        elif value=='libdome-sculpt-core.a':value=str(here/value)
        elif value=='libdome-sculpt-render.a' and render:value=str(render)
        elif value.endswith('/'+rel+'.o'):value=str(owner_map[rel])
        argv.append(value)
    assert str(owner_map[rel]) in argv
    links.append({'name':target,'argv':argv})
plan={'source':git('rev-parse','HEAD'),'profile':mode,'baseline_archive':str(archive),
      'baseline_archive_sha256':record['linked_archive']['sha256'],'cwd':str(config),
      'compiler':compiles,'links':links,'replacement_objects':[str(owner_map[rel]) for rel in sorted(core)],
      'authenticated_reused_objects':unchanged_owners,'render_archive':str(render) if render else None}
(here/'build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(mode,len(compiles),len(links),len(core))
