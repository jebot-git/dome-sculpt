from pathlib import Path
import hashlib
import io
import json
import re
import subprocess
import tarfile

here=Path(__file__).resolve().parent
artifacts=here.parent
docs=artifacts.parent/'docs/validation'
creator=artifacts/'creator-public-build-20261126'
broad=artifacts/'production-full-regression-release-20261126/full-private-ctest'
strict=here/'strict'
cases={}
paths=[]
def read(path):
    return json.loads(path.read_text())
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def pick(p,items):
    return [p/key for key in items.split()]
production='0cdd15114b8604a9deb91da02e4817f881f67da3'
app_sha='85337e652c24e4c2853b7b266ebc4a31986fe12ec4fb6e7f8fee85de9ce5835e'
for leaf,count in [('combined-wayland0cdd1511-v1',14),('public0cdd1511-accept-v1',19),
                   ('public0cdd1511-cancel-v1',19),('public0cdd1511-focus-v1',20)]:
    p=creator/leaf
    d=read(p/'status.json')
    plan=read(p/'plan.json')
    assert plan.get('source',plan.get('production'))==production
    assert sha(artifacts/'production-compact-sculpt-builds-20261126/release/dome-sculpt')==app_sha
    assert d['terminal'] and d['exit']==0 and d['actual_checks']==count and not d['input_drift'] and not d['owned_remaining']
    assert d['lease']['released']>d['lease']['acquired'] and not d['steps'][-1]['signals']
    device_reports=p/'workflow/actual-device' if count==14 else p/'actual-device'
    devices=list(device_reports.glob('*/device.txt'))
    assert devices and all('/dev/dri/renderD129' in v.read_text() and 'A770' in v.read_text() for v in devices)
    paths+=pick(p,'plan.json status.json process.log workflow/report.json')
    paths+=sorted(p.glob('*.ldd'))
    for device in devices:
        paths.append(device)
        maps=device.parent/'context-maps.txt'
        if maps.exists(): paths.append(maps)
    cases[leaf]={'checks':count,'seconds':d['steps'][-1]['seconds'],'peak_owned_RSS_bytes':d['steps'][-1]['peak_owned_RSS_bytes'],
                 'native_projects':{str(x.relative_to(p)):{'bytes':x.stat().st_size,'sha256':sha(x)}
                                    for x in (p/'workflow').rglob('*.dsculpt')}}
paths+=pick(creator,'run-combined-wayland0cdd1511-v1.py run-public0cdd1511-v1.py run-public0cdd1511-round.py public0cdd1511-round-v1/status.json')
strict_result=read(strict/'native/status.json')
strict_build=read(strict/'build-status.json')
assert strict_result['terminal'] and strict_result['source']==production
assert strict_build['terminal'] and strict_build['exit']==0
assert len(strict_result['cases'])==8
assert all(x['check_passed'] and x['exit']==0 for k,x in strict_result['cases'].items() if k!='sculpt-independent-workflow')
final=strict_result['cases']['sculpt-independent-workflow']
assert final['timeout_seconds']==900 and final['RSS_limit_bytes']==4294967296
assert not final.get('owned_remaining',[])
paths+=pick(strict,'build-plan.json build-status.json run-native.py native/status.json')
paths+=sorted((strict/'native').glob('*.log'))
paths+=pick(here,'run-build-and-native.py prepare.py seal-ui-strict.py')
units=['ds-production-compact-sculpt-graphics-20261126','ds-production-compact-sculpt-strict-20261126']
for unit in units:
    record=subprocess.check_output(['journalctl','--user','-u',unit,'--no-pager'])
    assert record and b'-- No entries --' not in record
    f=here/(unit+'.journal.txt')
    f.write_bytes(record)
    paths.append(f)
archive=docs/'production-compact-sculpt-ui-strict-20261126.tar.xz'
manifest={}
with tarfile.open(archive,'w:xz',preset=6) as f:
    for p in paths:
        rel=str(p.relative_to(artifacts))
        value=p.read_bytes()
        assert rel not in manifest
        manifest[rel]={'size':len(value),'sha256':hashlib.sha256(value).hexdigest()}
        member=tarfile.TarInfo(rel)
        member.size=len(value)
        f.addfile(member,io.BytesIO(value))
with tarfile.open(archive,'r:xz') as f:
    assert set(f.getnames())==set(manifest)
    for item in f:
        assert item.size==manifest[item.name]['size']
        assert hashlib.file_digest(f.extractfile(item),'sha256').hexdigest()==manifest[item.name]['sha256']
receipt={'purpose':'Exact compact combined Release on private canonical DomeD Wayland and synthetic XR on Arc, plus its matching isolated ASan/UBSan native outcomes.',
         'app_source':production,'app_sha256':app_sha,'actual_ui_checks':cases,
         'strict_build':strict_build,'strict_native':strict_result,
         'authorities':manifest,'archive':{'file':archive.name,'size':archive.stat().st_size,'sha256':sha(archive)}}
archive.with_suffix('').with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(manifest),receipt['archive'])
