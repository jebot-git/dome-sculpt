// SPDX-License-Identifier: GPL-3.0-or-later
#define main common_bake_fixture
#include "texture-set-source-export.cpp"
#undef main
#include "texture-set-bake.hpp"

int main(int argc,char **argv)try{
 if(argc!=4||std::string_view(argv[1])!="--texture-set-xr-fixture")
  return common_bake_fixture(argc,argv);
 auto scene=source(false,true);
 const auto target=scene.active().id;
 const auto placement=scene.active().affine_edit;
 const auto world=scene.world_matrix(target);
 const auto mesh=scene.active().painted->mesh();
 const auto n=mesh.normals.at(mesh.indices.front());
 const auto normal=unit(world.normal({n.x,n.y,n.z}));
 const auto offset_mesh=[&](double distance){
  auto copy=mesh;
  const auto offset=world.inverse().direction({normal.x*distance,normal.y*distance,normal.z*distance});
  for(auto &p:copy.positions)p+=Vec3{float(offset[0]),float(offset[1]),float(offset[2])};
  return copy;
 };
 const auto donor=scene.add("Bake donor",Volume{});
 auto &high=scene.active();
 high.mesh_active=true;
 high.affine_edit=placement;
 high.material.color={.2f,.5f,.8f,1};
 auto high_mesh=offset_mesh(.057);
 const auto tilted=normalized(n+Vec3{.17f,-.25f,0});
 high_mesh.normals.assign(high_mesh.positions.size(),tilted);
 high.painted=std::make_shared<PaintedMesh>(std::move(high_mesh),64);
 create_texture_set(scene,donor,std::array<uint64_t,1>{1},"Donor paint set",64);
 scene.active().visible=false;
 scene.active().locked=true;
 const auto cage=scene.add("Full matched cage",Volume{});
 scene.active().mesh_active=true;
 scene.active().visible=false;
 scene.active().affine_edit=placement;
 scene.active().painted=std::make_shared<PaintedMesh>(offset_mesh(.075),64);
 scene.select(target);
 select_texture_set(scene,target,1);
 rename_texture_set(scene,target,1,"Right set");
 ObjectBakeSettings settings;
 settings.front_mm=80;settings.padding=0;settings.ao_samples=4;settings.cage_object=cage;
 settings.allow_backfaces=true;
 bake_object(scene,donor,settings);
 detail::clear_texture_set_bake(scene,{});
 scene.save(argv[2]);
 const auto baseline=scene.encode();
 auto replay=Scene::load(argv[2]);
 check(replay.encode()==baseline,"Retained target, native donor and cage reopen with a selected-field recipe");
 auto closed=settings;closed.front_mm=40;
 refuses([&]{bake_object(replay,donor,closed);},"Recalled cage requires the persisted outward world bounds");
 check(replay.encode()==baseline,"Rejected cage leaves the full authored project exact");
 bake_object(replay,donor,settings);
 replay.save(argv[3]);
 check(Scene::load(argv[3]).encode()==replay.encode(),"Authored bake exactly reopens from the native reference");
 const auto selected=active_texture_set(replay.active());
 const auto expected=unit(world.normal({tilted.x,tilted.y,tilted.z}));
 double error=0;
 size_t samples=0;
 for(auto triangle:selected.domain->triangles()){
  for(int i=2;i<=6;++i)for(int j=2;j<=8-i;++j){
   const std::array<double,3> bary{double(i)/10,double(j)/10,double(10-i-j)/10};
   const auto got=selected.source->normal(triangle,bary,world,true);
   error=std::max(error,double(length(got-expected)));
   ++samples;
  }
 }
 check(samples&&error<.016,"Independent reflected world-normal witness matches the newly baked normal direction");
 const auto portable=detail::make_gltf(replay.export_surfaces());
 const auto &parts=portable.json.at("meshes").at(0).at("primitives");
 for(const auto &part:parts){
  const auto id=part.at("extras").at("dome_sculpt_texture_set").at("id").get<TextureSetId>();
  const auto &material=portable.json.at("materials").at(part.at("material").get<size_t>());
  const auto field=texture_set_view(replay.active(),id);
  if(id==selected.id){
   const auto image=texture_image(portable,material.at("normalTexture"));
   check(image.rgba==field.source->source_preview()->native_bake()->rgba,
         "Portable PBR output uses the selected field's actual detail image");
  }else check(!material.contains("normalTexture"),"The unchanged field uses its inherited normals");
 }
 std::cout<<"PASS "<<checks<<" public retained-recipient witnesses, "<<samples
          <<" projected normals, maximum vector error "<<error<<'\n';

 return 0;
}catch(const std::exception &e){
 std::cerr<<"FAIL "<<e.what()<<'\n';
 return 1;
}
