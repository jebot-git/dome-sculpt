// SPDX-License-Identifier: GPL-3.0-or-later
#define main existing_sourceful_matrix
#include "texture-set-source-render.cpp"
#undef main
#include "dome/bake-authoring.hpp"
#include "texture-set-bake.hpp"

int main(int argc,char **argv)try{
 if(argc!=2)return 2;
 const std::filesystem::path out=argv[1];
 std::filesystem::create_directories(out);
 NativeGraphics graphics;
 std::cout<<"GL_RENDERER "<<glGetString(GL_RENDERER)<<'\n';
 Fbo target;
 SurfaceRenderer renderer;
 json evidence=json::array();
 for(bool reflected:{false,true})for(bool flip:{false,true}){
  auto f=fixture(false,reflected,flip);
  const auto target_id=f.object;
  check(f.scene.active().id==target_id,"Real retained mesh is the Bake recipient");
  select_texture_set(f.scene,target_id,1);
  const auto world=f.scene.world_matrix(target_id);
  const auto transform=f.scene.active().affine_edit;
  auto mesh=f.scene.active().painted->mesh();
  const V desired=flip?unit(V{.17,-.26,-.95}):unit(V{.17,.26,.95});
  // Move the complete donor just outside the selected triangle. Projection
  // still uses the real transformed normals and per-set triangle IDs.
  for(auto &point:mesh.positions)point.z+=.003f;
  mesh.normals.assign(mesh.positions.size(),vec(desired));
  const auto donor=f.scene.add("Independent normal Bake donor",Volume{});
  auto &high=f.scene.active();
  high.mesh_active=true;
  high.affine_edit=transform;
  high.painted=std::make_shared<PaintedMesh>(mesh,64);
  high.material.color={0,0,0,1};
  high.material.roughness=.5f;
  create_texture_set(f.scene,donor,std::array<uint64_t,1>{1},"Donor partition",64);
  edit_texture_set(f.scene,donor,1,[](PaintedMesh &,Material &m){
   m.color={0,0,0,1};m.roughness=.5f;return true;
  });
  f.scene.active().visible=false;
  f.scene.active().locked=true;
  f.scene.select(target_id);
  Document doc;
  doc.replace(f.scene);
  ready(doc);
  auto original=doc.frame().surface;
  const auto before=render(renderer,original,target);
  ObjectBakeSettings settings;
  settings.allow_partial=true;
  settings.allow_backfaces=true;
  settings.ao_samples=0;
  settings.padding=0;
  doc.bake_from_object(donor,settings);
  ready(doc);
  auto current=doc.frame().surface;
  const auto picked=std::find_if(current->ranges.begin(),current->ranges.end(),
                                 [=](const auto &r){return r.object==target_id&&r.texture_set==1;});
  check(picked!=current->ranges.end()&&picked->textures->polygon_surface->native_bake(),
        "Real Document render range carries the selected immutable Bake image");
  const auto after=render(renderer,current,target);
  const auto repeated=render(renderer,current,target);
  check(after==repeated,"Second eye reuses the exact newly baked pixels");
  const World placement{reflected};
  const auto samples=triangles(flip,placement);
  size_t primary=0,baked=0,witness=0;
  unsigned maximum=0;
  for(int y=0;y<side;++y)for(int x=0;x<side;++x){
   const double wx=((x+.5)*2/side-1)/projection_scale,wy=((y+.5)*2/side-1)/projection_scale;
   const size_t offset=size_t(y*side+x)*4;
   for(const auto &triangle:samples){
    auto b=barycentric(triangle,wx,wy);
    if(*std::min_element(b.begin(),b.end())<.17)continue;
    if(triangle.set==0){
     if(!std::equal(before.data()+offset,before.data()+offset+4,after.data()+offset))throw std::runtime_error(
           "Unselected field pixel is byte-identical");
     ++primary;
     continue;
    }
    V p{};
    for(size_t k=0;k<3;++k)p=p+triangle.p[k]*b[k];
    const auto normal=placement.normal(desired)*(flip?-1:1);
    const auto expect=finish(specular(normal,p),false);
    for(size_t c=0;c<4;++c){
     const auto error=unsigned(std::abs(expect[c]-after.at(offset+c)));
     maximum=std::max(maximum,error);
     if(error>4)throw std::runtime_error("Retained Bake GPU oracle pixel mismatch");
    }
    if(std::abs(int(before.at(offset))-after.at(offset))>4)++witness;
    ++baked;
   }
  }
  check(primary>400&&baked>400&&witness>120,"Independent oracle distinguishes the authored normal from inherited shading");
  const auto after_scene=doc.copy_scene().encode();
  Document reopened;
  reopened.replace(Scene::decode(after_scene));ready(reopened);
  check(render(renderer,reopened.frame().surface,target)==after,"Cold reopen preserves selected normal Bake frame bytes");
  check(doc.undo(),"Actual history operation restores inherited normal field");ready(doc);
  check(render(renderer,doc.frame().surface,target)==before,"Undo restores the actual before frame");
  const auto label=std::to_string(reflected)+std::to_string(flip);
  png(out/(label+"-baked.png"),after);
  evidence.push_back({{"case",label},{"unselected_pixels",primary},{"baked_pixels",baked},
                      {"distinguishing_pixels",witness},{"maximum_byte_error",maximum}});
 }
 std::ofstream record(out/"oracle.json");
 record<<json{{"checks",checks},{"cases",evidence}}.dump(2)<<'\n';
 std::cout<<"PASS "<<checks<<" native retained Bake renderer controls\n";
 return 0;
}catch(const std::exception &e){
 std::cerr<<"FAIL "<<e.what()<<'\n';return 1;
}
