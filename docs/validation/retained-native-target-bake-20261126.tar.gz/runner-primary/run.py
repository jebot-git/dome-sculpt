from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys,time
profile=sys.argv[1]
asan=profile=='asan'
base=Path(__file__).resolve().parent
artifacts=base.parent
source=artifacts/'retained-native-target-source-20261126'
parent=artifacts/'retained-native-target-validation-20261126'/profile
build=parent/'build'
sdk=artifacts/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
out=base/profile
out.mkdir(exist_ok=True)
candidate=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
state={'candidate':candidate,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}
def record(**m):
 state.update(m)
 temp=out/'status.tmp';temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(out/'status.json')
def sha(file):
 with file.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,log,timeout=360):
 with (out/log).open('w') as f:
  print(shlex.join(map(str,cmd)),file=f,flush=True)
  subprocess.run(cmd,cwd=build,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
try:
 record(phase='wait for sealed test and archive')
 while True:
  st=json.loads((parent/'status.json').read_text())
  if st['terminal']:break
  subprocess.run(['systemctl','--user','is-active','--quiet',f'ds-retained-native-target-{profile}-20261126.service'],check=True)
  time.sleep(1)
 assert st['candidate']==candidate and st['exit']==0
 assert sha(parent/'libdome-sculpt-core.a')==st['core_sha256']
 c=shlex.split((parent/'texture-set-source-export.cpp.o.log').read_text().splitlines()[0])
 obj=out/'fixture.o'
 c[c.index('-o')+1]=str(obj)
 c[-1]=str(base/'witness.cpp');c.insert(1,'-I'+str(source/'tests'))
 run(c,'compile.log')
 link=shlex.split((parent/'dome-sculpt-texture-set-source-export-link.log').read_text().splitlines()[0])
 link=[str(obj) if w.endswith('/texture-set-source-export.cpp.o') else w for w in link]
 binary=out/'witness'
 link[link.index('-o')+1]=str(binary)
 run(link,'link.log')
 cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
      '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv',
      '--setenv','PATH','/usr/bin:/bin','--setenv','HOME','/tmp','--setenv','LD_LIBRARY_PATH',
      f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64']
 if asan:cmd+=['--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1','--setenv','UBSAN_OPTIONS','halt_on_error=1']
 record(phase='primary field successive partial Bake and Scene41 replay',core_sha256=st['core_sha256'])
 run([*cmd,binary,out/'output'],'witness.log')
 assert ' primary retained native normal and FLOAT controls' in (out/'witness.log').read_text()
 record(terminal=True,exit=0,phase='complete',fixture_sha256=sha(binary),log_sha256=sha(out/'witness.log'))
except Exception as err:
 record(terminal=True,exit=1,error=repr(err))
 raise
