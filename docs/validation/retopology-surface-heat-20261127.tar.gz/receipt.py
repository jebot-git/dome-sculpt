from collections import Counter
from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parents[1]
destination = repo / "docs" / "validation"
stem = work.name

def read(name):
    return (work / name).read_text()

def report(name):
    return json.loads(read(name))

def sha(name):
    with (work / name).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

profiles = {}
for profile, stage in (("release", "repaired"), ("asan", "current")):
    log = read(f"{profile}-{stage}.log")
    assert "100% tests passed, 0 tests failed out of 11" in log
    names = re.findall(r"Test\s+#\d+: (\S+)\s+\.+\s+Passed", log)
    assert len(names) == 11
    raw = read(f"{profile}/Testing/Temporary/LastTest.log")
    native = {}
    for placement in ("plain", "affine"):
        case = f"retopology-surface-heat-{placement}"
        section = raw.split(f"Test: {case}\n", 1)[1].split("Test time =", 1)[0]
        labels = re.findall(r"^PASS (.*)$", section, re.M)
        assert labels.pop() == "25 retopology Surface Heat controls" and len(labels) == 25
        native[placement] = labels
    receipt = f"{profile}-native-evidence.json"
    (work / receipt).write_text(json.dumps(native, indent=2) + "\n")
    profiles[profile] = {
        "tests": sorted(names), "case_assertions": {p:len(v) for p,v in native.items()},
        "native_test_sha256":sha(profile+"/dome-sculpt-retopo-surface-heat-test"),
    }

exact = {}
for placement in ("plain","affine"):
    for name in ("patch.dsculpt","before-bind.dsculpt","bound.dsculpt","posed.dsculpt","standard.glb","editable.glb"):
        leaf = f"retopology-surface-heat-{placement}/{name}"
        release, asan = (sha(f"{profile}/{leaf}") for profile in ("release","asan"))
        assert release == asan, leaf
        exact[leaf] = release

wayland = report("wayland-bind/report.json")
assert wayland["complete"] and len(wayland["checks"]) == 9
assert all(it["passed"] for it in wayland["checks"])
expected = exact["retopology-surface-heat-plain/bound.dsculpt"]
assert sha("wayland-bind/heat-bound.dsculpt") == expected

xr = {}
for mode, renderer in (("software", "llvmpipe"), ("arc", "Arc(tm) A770")):
    bind = report(f"xr-bind-{mode}/compare.json")
    assert bind["stereo_submissions"] == 77 and bind["releases"] == 154
    assert bind["same_native_reference"] and renderer in bind["gl_renderer"]
    assert sha(f"xr-bind-{mode}/bound.dsculpt") == expected
    pose = report(f"xr-{mode}/compare.json")
    assert pose["exact_ordered_close"] and len(pose["profiles"]) == 2
    assert all(count>100 for count in pose["differing_rgb_components_per_eye"])
    assert all(renderer in item["gl_renderer"] and
               item["stereo_submissions"] == 6 and item["releases"] == 12
               for item in pose["profiles"])
    xr[mode] = {
        "renderer": bind["gl_renderer"],
        "bind": {"project_sha256":expected, "stereo_submissions":77,"image_releases":154},
        "pose": {"project_reopen_and_close_exact":True, "stereo_submissions_per_case":6,
                 "image_releases_per_case":12,
                 "different_rgb_components_per_eye":pose["differing_rgb_components_per_eye"]},
    }

consumer = report("consumer.json")
assert len(consumer) == 4
assert all(item["corners"] == 6 and item["maximum_position_error_m"] < 4e-8 and
           item["maximum_weight_error"] == 0 for item in consumer)
validation = report("khronos.json")
assert len(validation["reports"]) == 4
warnings = Counter()
for item in validation["reports"]:
    issues = item["report"]["issues"]
    assert issues["numErrors"] == 0
    warnings.update(issue["code"] for issue in issues["messages"] if issue["severity"]==1)

logs = [
    "receipt.py","check-profile.sh","run-bind.py","wayland-heat.py","run-render.py",
    "xr-bind.py","xr-pose.py","consumer.py","consumer.json","consumer.log","khronos.cjs",
    "khronos.json","khronos.log","release-repaired.log","asan-current.log",
    "release-native-evidence.json","asan-native-evidence.json","bind-wayland.log","wayland-bind/report.json",
]
for mode in xr:
    logs.extend([f"verified-bind-{mode}.log",f"verified-pose-{mode}.log",f"xr-bind-{mode}/compare.json",
                 f"xr-bind-{mode}/report.json",f"xr-{mode}/compare.json"])
archive = destination/(stem+".tar.gz")
with archive.open("wb") as output, gzip.GzipFile(filename="",fileobj=output,mode="wb",mtime=0) as zipped:
    with tarfile.open(fileobj=zipped,mode="w") as bundle:
        for name in sorted(logs):
            item = bundle.gettarinfo(str(work/name),arcname=name)
            item.uid = item.gid = item.mtime = 0
            item.uname = item.gname = ""
            item.mode = 0o644
            with (work/name).open("rb") as stream:
                bundle.addfile(item,stream)

summary = {
    "revision":subprocess.check_output(["git","-C",repo,"rev-parse","HEAD"],text=True).strip(),
    "canonical_domed_revision":"acc2b70ae61dedec2a23727f67c60c0303d0f76f",
    "release_fltk":"/opt/fltk-vr/toolkit",
    "asan_fltk":"artifacts/sdk-20261126/toolkit-sanitize",
    "release_application_sha256":sha("release/dome-sculpt"),
    "qualification":{
        "plain":"Native projected quad, pin, seam, hidden painted and rigged source, color Bake, Surface Heat, weight painting, Restore and pose",
        "affine":"Same workflow from reflected and sheared original with exact rig space and independent published patch coordinates",
        "openxr":"Bind and reopen/pose on a plain retopology patch using the application and synthetic controller/runtime",
    },
    "native":profiles,
    "sanitizer_environment":{"ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1",
                             "UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1"},
    "identical_release_asan_files_sha256":exact,
    "nested_domed_wayland_assertions":9,
    "synthetic_openxr":xr,
    "independent_glb_consumer":consumer,
    "khronos":{"version":validation["version"],"files":4,"errors":0,"warnings":dict(warnings)},
    "physical_headset_tested":False,
    "archive":{"path":archive.name,"sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),
               "members_sha256":{name:sha(name) for name in sorted(logs)}},
}
(destination/(stem+".json")).write_text(json.dumps(summary,indent=2)+"\n")
