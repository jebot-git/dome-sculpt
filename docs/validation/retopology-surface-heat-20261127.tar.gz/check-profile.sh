#!/usr/bin/bash
set -eu
profile="$1"
run="$2"
out="$(cd "$(dirname "$0")" && pwd)"
repo="$(cd "$out/../.." && pwd)"
seed="$repo/artifacts/retained-texture-set-shape-20261127/$profile"
sdk=/opt/fltk-vr/toolkit
if [[ "$profile" == asan ]]; then sdk="$repo/artifacts/sdk-20261126/toolkit-sanitize"; fi
prefix=(bwrap --die-with-parent --unshare-all --ro-bind / / --bind "$out/$profile" "$seed" --proc /proc --dev /dev --tmpfs /tmp --tmpfs /run/user --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /tmp --setenv PKG_CONFIG_PATH /opt/fltk-vr/bdf-runtime/lib/pkgconfig:/usr/lib64/pkgconfig --setenv LD_LIBRARY_PATH "$sdk/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64" --setenv ASAN_OPTIONS detect_leaks=1:halt_on_error=1 --setenv UBSAN_OPTIONS halt_on_error=1:print_stacktrace=1 --setenv LIBGL_ALWAYS_SOFTWARE 1 --setenv LP_NUM_THREADS 2)
targets=(dome-sculpt-retopo-surface-heat-test dome-sculpt-retopo-authoring-test
         dome-sculpt-retopo-affine-test dome-sculpt-retopo-save-handoff-test
         dome-sculpt-surface-heat-native-test dome-sculpt-anatomical-admission-controls-test
         dome-sculpt-native-paint-key-frames-test dome-sculpt-independent-seam-key-mirror-prepared-test
         dome-sculpt-independent-seam-key-mirror-retained-test)
if [[ "$profile" == release ]]; then targets+=(dome-sculpt dome-sculpt-test-runtime); fi
"${prefix[@]}" cmake --build "$seed" --parallel 6 --target "${targets[@]}" > "$out/$profile-$run-build.log" 2>&1
"${prefix[@]}" ctest --test-dir "$seed" ${3:+"-j$3"} -R "${4:-^texture-set-retained-posed-bake$}" --output-on-failure > "$out/$profile-$run.log" 2>&1
