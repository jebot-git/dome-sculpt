#include XATLAS_SOURCE
#include <array>
#include <cstdint>
#include <iostream>
#include <stdexcept>
#include <vector>

int main() try {
    using xatlas::internal::BitImage;
    constexpr std::array widths = {1u, 2u, 31u, 63u, 64u, 65u, 95u, 127u, 128u, 129u, 191u, 193u};
    uint64_t comparisons = 0;
    for (auto atlas_width : widths) {
        for (auto chart_width : widths) {
            for (unsigned pattern = 0; pattern < 5; ++pattern) {
                constexpr unsigned atlas_height = 9;
                constexpr unsigned chart_height = 5;
                BitImage atlas(atlas_width, atlas_height);
                BitImage chart(chart_width, chart_height);
                std::vector<uint8_t> canvas(atlas_width * atlas_height);
                std::vector<std::array<unsigned,2>> chart_pixels;
                for (unsigned y = 0; y < atlas_height; ++y) {
                    for (unsigned x = 0; x < atlas_width; ++x) {
                        const bool occupied = pattern == 1 ? x == atlas_width - 1 :
                            pattern == 2 ? x % 64 == 0 : pattern == 3 ? (x * 19 + y * 13) % 73 < 3 :
                            pattern == 4 && (x + y) % 2 == 0;
                        if (occupied) {
                            atlas.set(x, y);
                            canvas[y * atlas_width + x] = 1;
                        }
                    }
                }
                for (unsigned y = 0; y < chart_height; ++y) {
                    for (unsigned x = 0; x < chart_width; ++x) {
                        const bool occupied = pattern < 2 ? x == chart_width - 1 :
                            pattern == 2 ? x % 64 == 63 : pattern == 3 ? (x * 13 + y * 19) % 29 < 3 :
                            (x + y + 1) % 2 == 0;
                        if (occupied) {
                            chart.set(x, y);
                            chart_pixels.push_back({x, y});
                        }
                    }
                }
                for (unsigned y = 0; y <= atlas_height + 1; ++y) {
                    for (unsigned x = 0; x <= atlas_width + 1; ++x) {
                        bool expected = true;
                        for (const auto &pixel : chart_pixels) {
                            const auto cx = x + pixel[0];
                            const auto cy = y + pixel[1];
                            if (cx < atlas_width && cy < atlas_height && canvas[cy * atlas_width + cx]) {
                                expected = false;
                                break;
                            }
                        }
                        if (atlas.canBlit(chart, x, y) != expected)
                            throw std::runtime_error("Packed-pixel oracle disagrees with chart placement");
                        ++comparisons;
                    }
                }
            }
        }
    }
    std::cout << "PASS " << comparisons << " independently evaluated clipped chart overlaps\n";
} catch (const std::exception &error) {
    std::cerr << error.what() << '\n';
    return 1;
}
