from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

base=Path(__file__).resolve().parent
artifacts=base.parent
profile=sys.argv[1]
out=base/profile
out.mkdir(mode=0o700)
baselines={'reference':artifacts/'combined-atlas-hdr-preview-source-20261126',
           'wordwise':artifacts/'atlas-aligned-bit-overlap-source-20261126'}
results={}
for role,repo in baselines.items():
    source=repo/'third_party/xatlas/xatlas.cpp'
    binary=out/role
    flags=['-O1','-g1','-fsanitize=address,undefined','-fno-omit-frame-pointer'] if profile=='asan' else ['-O3','-DNDEBUG']
    with (out/(role+'.build.log')).open('w') as log:
        subprocess.run(['/usr/bin/c++','-std=c++20','-pthread',*flags,f'-DXATLAS_SOURCE="{source}"',
                        base/'grid.cpp','-o',binary],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    with (out/(role+'.log')).open('w') as log:
        env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        subprocess.run([binary],stdout=log,stderr=subprocess.STDOUT,env=env,check=True,timeout=60)
    results[role]={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'result':(out/(role+'.log')).read_text().strip()}
assert results['reference']['result']==results['wordwise']['result'] and results['reference']['result'].startswith('PASS ')
(out/'status.json').write_text(json.dumps({'terminal':True,'exit':0,'invocation':os.getenv('INVOCATION_ID'),'results':results},indent=2)+'\n')
