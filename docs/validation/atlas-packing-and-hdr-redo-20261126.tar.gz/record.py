from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

root=Path.cwd()
base=root/'artifacts'
results={}
archive={}


def take(label,path,*files):
    folder=base/path
    for name in ('status.json',*files):
        archive[f'{label}/{name}']=(folder/name).read_bytes()
    data=json.loads(archive[f'{label}/status.json'])
    assert data['terminal']
    results[label]=data
    return data


job='combined-atlas-hdr-native-history-20261126/asan-2048'
redo=take('combined-hdr-history-asan',job,'ordered-history.log','ordered-history.json')
assert redo['candidate'].startswith('5c977be9') and redo['exit']==1
trace=archive['combined-hdr-history-asan/ordered-history.log']
assert b'CHECKED_SOURCE_HISTORY undone-state-exact' in trace
assert b'CHECKED_SOURCE_REDO invoked=1 preview_ready=0' in trace and b'CHECKED_SOURCE_REDO native_exact=1' in trace
run=json.loads(archive['combined-hdr-history-asan/ordered-history.json'])
assert run['libasan_mapped'] and run['libubsan_mapped'] and run['elapsed_seconds']<900
assert hashlib.sha256(trace).hexdigest()==run['log_sha256']
redo['measured_run']=run
with (base/job/'ordered-history/000-ordered.dsculpt').open('rb') as stream:
    assert hashlib.file_digest(stream,'sha256').hexdigest()==redo['capture_inputs']['observed-second-bake.dsculpt']
probe=take('combined-hdr-preview-sampling','combined-hdr-history-preview-sampling-20261126/asan-2048',
           'preview.log','preview.json','BEGIN_RESTORED.stack-0.log','BEGIN_RESTORED.stack-1.log',
           'BEGIN_RESTORED.stack-2.log','BEGIN_RESTORED.stack-3.log')
assert probe['exit']==0 and probe['runs'][0]['libasan_mapped'] and probe['runs'][0]['libubsan_mapped']
log=archive['combined-hdr-preview-sampling/preview.log']
maps=re.findall(rb'^RANGE (?:INITIAL|RESTORED) object=4 map=(\S+)',log,re.M)
assert len(maps)==2 and maps[0]==maps[1]
assert b'RESTORED default_ready=0 first_seconds=' in log
assert b'CACHE RESTORED retained=444041876 entries=2 limit=536870912 builds=11' in log
for n in range(4):
    stack=archive[f'combined-hdr-preview-sampling/BEGIN_RESTORED.stack-{n}.log']
    assert b'color_projection_bound' in stack and b'MaterialSurfaceQuery' in stack

root_name='atlas-aligned-bit-overlap'
timing=take('wordwise-export-profile',root_name+'-timing-20261126','run.py','export.cpp','baseline/application.log','candidate/application.log')
assert timing['exit']==0 and timing['identity']
assert timing['profiles']['candidate']['source'].startswith('19f125ae')
assert all('Find location:' in ' '.join(item['stages']) for item in timing['profiles'].values())
for profile in ('release','asan'):
    pair=take('wordwise-overlap-'+profile,root_name+'-oracle-20261126/'+profile)
    assert pair['exit']==0 and all('734580 independently evaluated clipped chart overlaps' in x['result'] for x in pair['results'].values())
    native=take('wordwise-native-'+profile,root_name+'-validation-20261126/native-'+profile)
    assert native['exit']==0 and len(native['results'])==6
software=take('wordwise-software-xr',root_name+'-validation-20261126/software-release','workflow/report.json')
assert software['exit']==0 and software['checks']==153 and software['report_complete']

proposed=(('wordwise-arc-xr',root_name+'-validation-20261126/arc-asan'),
          ('wordwise-main-release','atlas-aligned-bit-main-port-validation-20261126/native-release'),
          ('wordwise-main-asan','atlas-aligned-bit-main-port-validation-20261126/native-asan'),
          ('wordwise-main-software-xr','atlas-aligned-bit-main-port-validation-20261126/software-release'),
          ('wordwise-main-arc-xr','atlas-aligned-bit-main-port-validation-20261126/arc-asan'),
          ('candidate-sort-profile','atlas-ordered-candidate-sort-timing-20261126'),
          ('candidate-sort-oracle-release','atlas-ordered-candidate-sort-oracle-20261126/release'),
          ('candidate-sort-oracle-asan','atlas-ordered-candidate-sort-oracle-20261126/asan'),
          ('candidate-sort-ties','atlas-ordered-candidate-ties-20261126'),
          ('wordwise-files-arc','atlas-word-overlap-arc-files-20261126'),
          ('worker-bound-memo-build-release','worker-color-bound-memo-validation-20261126/release'),
          ('worker-bound-memo-build-asan','worker-color-bound-memo-validation-20261126/asan'),
          ('worker-bound-memo-release','worker-color-bound-memo-runtime-20261126/release-color-bound-memo'),
          ('worker-bound-memo-asan','worker-color-bound-memo-runtime-20261126/asan-color-bound-memo'),
          ('worker-bound-memo-history-release','worker-color-bound-memo-runtime-20261126/release-ordered-history'),
          ('worker-bound-memo-history-asan','worker-color-bound-memo-runtime-20261126/asan-ordered-history'),
          ('worker-bound-memo-sampled-asan','worker-color-bound-memo-runtime-20261126/asan-clear-bake-history'))
for label, folder in proposed:
    authority=base/folder/'status.json'
    if authority.is_file() and json.loads(authority.read_text())['terminal']:
        take(label,folder)
files=results['wordwise-files-arc']
assert files['exit']==0 and files['identical_glb'] and files['identical_native']
assert len(files['runs'])==4 and all(row['arc_device'] and row['frames']==45 for row in files['runs'])
assert all((row['seconds']<40)==row['case'].startswith('wordwise') for row in files['runs'])
main_arc=results['wordwise-main-arc-xr']
assert main_arc['exit']==0 and main_arc['checks']==153 and main_arc['report_complete']
assert main_arc['arc_witnesses']['files']['node']=='/dev/dri/renderD129'
rel=results['worker-bound-memo-release']
assert rel['exit']==0 and rel['runs'][0]['checks']==[3471]
rel_history=results['worker-bound-memo-history-release']
assert rel_history['exit']==0 and rel_history['runs'][0]['checks']==[8]
assert rel_history['ordered_save_sha256']==rel_history['capture_inputs']['observed-second-bake.dsculpt']

sampled=take('worker-bound-memo-sampled-asan','worker-color-bound-memo-runtime-20261126/asan-clear-bake-history',
             'clear-bake-history.log','clear-bake-history.json')
assert sampled['candidate']=='b458d7bd4af75b0fd00cea64afc127dd9e3cfe69' and sampled['exit']==0
assert sampled['capture_inputs']==redo['capture_inputs']
assert sampled['capture_inputs']['observed-second-bake.dsculpt']==probe['source_sha256']
entry=sampled['runs'][0]
assert entry['libasan_mapped'] and entry['libubsan_mapped'] and entry['exit']==0 and entry['checks']==[1]
assert entry['peak_owned_rss']<sampled['owned_RSS_limit_bytes']
trace=archive['worker-bound-memo-sampled-asan/clear-bake-history.log']
assert hashlib.sha256(trace).hexdigest()==entry['log_sha256']
restored=re.search(rb'^RESTORED default_ready=1 first_seconds=([\d.]+)',trace,re.M)
same=re.findall(rb'^RANGE (?:INITIAL|RESTORED) object=4 map=(\S+)',trace,re.M)
assert restored and float(restored[1])==sampled['restored_seconds']<10
assert sampled['same_maps'] and len(same)==2 and same[0]==same[1]
assert b'CACHE RESTORED retained=444041876 entries=2 limit=536870912 builds=11' in trace
assert b'PASS native preview and genuine clear/undo/redo control' in trace

for file in ('grid.cpp','run.py'):
    archive['wordwise-overlap-oracle/'+file]=(base/'atlas-aligned-bit-overlap-oracle-20261126'/file).read_bytes()
archive['record.py']=Path(__file__).read_bytes()
a=root/'docs/validation/atlas-packing-and-hdr-redo-20261126.tar.gz'
with a.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed, tarfile.open(fileobj=compressed,mode='w') as tar:
    for name,data in sorted(archive.items()):
        entry=tarfile.TarInfo(name)
        entry.size=len(data)
        entry.mode=0o644
        tar.addfile(entry,io.BytesIO(data))
with tarfile.open(a) as tar:
    assert set(tar.getnames())==set(archive)
    assert all(tar.extractfile(name).read()==payload for name,payload in archive.items())
results['archive']={'path':str(a.relative_to(root)), 'sha256':hashlib.sha256(a.read_bytes()).hexdigest(),'members':len(archive)}
a.with_suffix('').with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n')
