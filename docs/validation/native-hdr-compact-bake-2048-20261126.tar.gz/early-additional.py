from pathlib import Path
import json
import os
import shlex
import shutil
import subprocess

root=Path(__file__).resolve().parent
out=root/'early-native'
initial=out/'case'
baseline=root.parent/'native-editable-2048-20261126/release'
configured=root/'release/build'
entry=next(e for e in json.loads((configured/'compile_commands.json').read_text()) if Path(e['file']).name=='source-writable-normal-bake.cpp')
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
def run(cmd,tag,check=True):
    with (out/(tag+'.log')).open('w') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        return subprocess.run(cmd,cwd=configured,stdout=log,stderr=subprocess.STDOUT,env=env,check=check,timeout=220).returncode
def build(source,target):
    obj=out/(target+'.o')
    app=out/target
    args=shlex.split(entry['command'])
    args[args.index('-c')+1]=str(source)
    args[args.index('-o')+1]=str(obj)
    run(args,target+'-compile')
    link=shlex.split((out/'link.log').read_text().splitlines()[0])
    link=[str(obj) if a.endswith('/source-writable-normal-bake.cpp.o') else a for a in link]
    link[link.index('-o')+1]=str(app)
    run(link,target+'-link')
    return app
fixture=build(root/'source/tests/source-writable-normal-bake.cpp','dense-hdr-fixture')
check_dir=out/'fixture-check'
check_dir.mkdir(exist_ok=True)
shutil.copyfile(baseline/'build/native-writable-first-key-2048/retained-2048.dsculpt',check_dir/'retained-2048.dsculpt')
fixture_rc=run([fixture,'--dense-hdr-first-key',check_dir],'dense-hdr-fixture',False)
export=build(root/'early-hdr-export.cpp','hdr-export')
export_rc=run([export,initial/'keyed-2048-hdr.dsculpt',out/'export'],'hdr-export',False)
(out/'additional.json').write_text(json.dumps({'fixture_exit':fixture_rc,'export_exit':export_rc},indent=2)+'\n')
raise SystemExit(fixture_rc or export_rc)
