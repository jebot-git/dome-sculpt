#include "dome/document.hpp"
#include "dome/native-authoring.hpp"
#include "dome/source-uv-bake.hpp"
#include <filesystem>
#include <iostream>
int main(int argc,char **argv) try {
  if(argc!=3)throw std::invalid_argument("Usage: hdr-export input output-dir");
  using namespace dome;
  const auto directory=std::filesystem::path(argv[2]);
  std::filesystem::create_directories(directory);
  Document doc;
  const auto settled=[&]{
    if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
      throw std::runtime_error(doc.frame().state->error);
  };
  doc.open(argv[1]);
  settled();
  doc.convert_baked_normals();
  doc.save_async(directory/"converted-hdr.dsculpt").get();
  settled();
  std::cout<<"HDR key conversion accepted"<<std::endl;
  doc.export_asset(directory/"standard-hdr.glb",AssetExportFormat::Glb).get();
  std::cout<<"Standard HDR GLB accepted"<<std::endl;
  try {
    doc.export_asset(directory/"editable-hdr.glb",AssetExportFormat::EditableGlb512).get();
    std::cout<<"Editable HDR GLB accepted"<<std::endl;
  }catch(const std::exception &e) {
    std::cout<<"Editable HDR GLB refusal: "<<e.what()<<std::endl;
  }
  return 0;
} catch(const std::exception &e) {
  std::cerr<<"Probe refusal: "<<e.what()<<'\n';
  return 1;
}
