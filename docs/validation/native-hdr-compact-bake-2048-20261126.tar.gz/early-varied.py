from pathlib import Path
import json
import os
import shlex
import shutil
import subprocess

root=Path(__file__).resolve().parent
out=root/'early-native'
initial=out/'case'
baseline=root.parent/'native-editable-2048-20261126/release'
configured=root/'release/build'
entry=next(e for e in json.loads((configured/'compile_commands.json').read_text()) if Path(e['file']).name=='source-writable-normal-bake.cpp')
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
def run(cmd,tag,check=True):
    with (out/(tag+'.log')).open('w') as log:
        print(shlex.join(map(str,cmd)),file=log,flush=True)
        return subprocess.run(cmd,cwd=configured,stdout=log,stderr=subprocess.STDOUT,env=env,check=check,timeout=220).returncode
def build(source,target):
    obj=out/(target+'.o')
    app=out/target
    args=shlex.split(entry['command'])
    args[args.index('-c')+1]=str(source)
    args[args.index('-o')+1]=str(obj)
    run(args,target+'-compile')
    link=shlex.split((out/'link.log').read_text().splitlines()[0])
    link=[str(obj) if a.endswith('/source-writable-normal-bake.cpp.o') else a for a in link]
    link[link.index('-o')+1]=str(app)
    run(link,target+'-link')
    return app
export=build(root/'early-varied-hdr.cpp','varied-hdr')
fixture=baseline/'build/native-writable-first-key-2048/retained-2048.dsculpt'
result=run([export,fixture,out/'varied-case'],'varied-hdr',False)
(out/'varied-hdr.json').write_text(json.dumps({'exit':result},indent=2)+'\n')
raise SystemExit(result)
