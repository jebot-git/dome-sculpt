from pathlib import Path
import fcntl
import hashlib
import json
import shlex
import subprocess
import sys
root=Path(__file__).resolve().parent
profile=sys.argv[1]
out=root/profile
sdk=root.parent/'sdk-20261126/toolkit-sanitize' if profile=='asan' else Path('/opt/fltk-vr/toolkit')
target=out/'build/dome-sculpt-baked-emission-gpu-test'
node='/dev/dri/renderD129'
device=Path('/sys/class/drm/renderD129/device')
assert (device/'vendor').read_text().strip()=='0x8086' and (device/'device').read_text().strip()=='0x56a0'
cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--proc','/proc','--dev','/dev',
     '--dev-bind',node,node,'--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
     'LIBGL_ALWAYS_SOFTWARE':'0','DRI_PRIME':'pci-0000_03_00_0','MESA_SHADER_CACHE_DISABLE':'1',
     'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
if profile=='asan':
    env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for k,v in env.items():cmd.extend(['--setenv',k,v])
with open('/tmp/dome-sculpt-arc-device.lock','rb') as lease,(out/'actual-arc.log').open('w') as trace:
    fcntl.flock(lease,fcntl.LOCK_EX)
    print(shlex.join(map(str,[*cmd,target])),file=trace,flush=True)
    p=subprocess.run([*cmd,target],stdout=trace,stderr=subprocess.STDOUT,timeout=210)
msg=(out/'actual-arc.log').read_text()
assert p.returncode==0 and 'Arc(tm) A770' in msg and '516126 checks PASS' in msg
with target.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
(out/'actual-arc.json').write_text(json.dumps({'exit':p.returncode,'exe_sha256':digest,'gpu_checks':516126,
                                           'renderer':'Intel Arc A770','gpu_device':str(device.resolve())},indent=2)+'\n')
