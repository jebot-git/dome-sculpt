from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import os
import shlex
import subprocess
root=Path(__file__).resolve().parent
build=root/'release/build'
out=root/'release/extras'
out.mkdir(exist_ok=True)
fixture=build/'native-writable-first-key-2048'
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if Path(e['file']).name=='source-writable-normal-bake.cpp')
raw=subprocess.check_output(['ninja','-t','commands','dome-sculpt-source-writable-normal-bake-test'],cwd=build,text=True).splitlines()[-1]
def run(args,label):
    with (out/(label+'.log')).open('w') as output:
        print(shlex.join(map(str,args)),file=output,flush=True)
        return subprocess.run(args,cwd=build,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180).returncode
def check(item):
    mode,source,input_name,expected=item
    obj=out/(mode+'.o')
    program=out/mode
    compile=shlex.split(entry['command'])
    compile[compile.index('-c')+1]=str(root/source)
    compile[compile.index('-o')+1]=str(obj)
    assert run(compile,mode+'-compile')==0
    link=[str(obj) if s.endswith('/source-writable-normal-bake.cpp.o') else s
          for s in shlex.split(raw)[2:-2] if not s.startswith('-Wl,--dependency-file')]
    link[link.index('-o')+1]=str(program)
    assert run(link,mode+'-link')==0
    code=run([program,fixture/input_name,out/(mode+'-case')],mode)
    assert code==1 and expected in (out/(mode+'.log')).read_text()
    return mode
with ThreadPoolExecutor(max_workers=2) as pool:
    verified=list(pool.map(check,[
        ('hdr-standard-export','early-hdr-export.cpp','keyed-2048-hdr.dsculpt','Aggregate HDR export fields exceed128MiB'),
        ('hdr-varied-first-key','early-varied-hdr.cpp','retained-2048.dsculpt','Scene paint storage budget exceeded')]))
(out/'status.json').write_text(json.dumps({'exit':0,'verified_refusals':verified},indent=2)+'\n')
