from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parent
profile=sys.argv[1]
out=root/profile
build=out/'build'
db=json.loads((build/'compile_commands.json').read_text())
target='dome-sculpt-test-runtime'
entry=next(e for e in db if target+'.dir/' in e['command'])
obj=out/'xr-portable-runtime.o'
so=out/'libdome-sculpt-portable-test-runtime.so'
def command(args,log):
    with (out/log).open('w') as f:
        print(shlex.join(map(str,args)),file=f,flush=True)
        subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=300,check=True)
args=shlex.split(entry['command'])
args[args.index('-o')+1]=str(obj)
args[args.index('-c')+1]=str(root/'xr-portable-runtime.cpp')
args.extend(['-I'+str(root/'source/tests'),'-MMD','-MF',str(obj)+'.d'])
command(args,'xr-portable-runtime-compile.log')
lines=subprocess.check_output(['ninja','-t','commands',target],cwd=build,text=True)
args=[s for s in shlex.split(lines.splitlines()[-1])[2:-2] if not s.startswith('-Wl,--dependency-file')]
args[args.index('-o')+1]=str(so)
args=[str(obj) if a.endswith('/xr_runtime.cpp.o') else a for a in args]
command(args,'xr-portable-runtime-link.log')
with so.open('rb') as f: print(hashlib.file_digest(f,'sha256').hexdigest(),so)
