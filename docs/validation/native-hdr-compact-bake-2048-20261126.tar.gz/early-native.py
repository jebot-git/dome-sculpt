from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json
import os
import re
import shlex
import shutil
import subprocess

root=Path(__file__).resolve().parent
out=root/'early-native'
out.mkdir(exist_ok=True)
configured=root/'release/build'
baseline=root.parent/'native-editable-2048-20261126/release'
probe_source=root.parent/'native-hdr-first-key-probe-20261126/probe.cpp'
core=out/'libdome-sculpt-core.a'
codec=configured/'libdome-sculpt-baked-emission.a'
paths=list((root/'source/src').glob('*.[ch]pp'))
headers={'baked-emission-access.hpp','baked-emission-codec.hpp'}
units={'paint.cpp','bake.cpp'}
pattern=re.compile(r'^#\s*include\s+"([^"]+)"',re.M)
deps={p.name:{Path(n).name for n in pattern.findall(p.read_text(errors='replace'))} for p in paths}
while True:
    used={p for p,k in deps.items() if headers&k}
    units.update(p for p in used if p.endswith('.cpp') and p!='render.cpp')
    more={p for p in used if p.endswith('.hpp')}-headers
    if not more:break
    headers.update(more)
entries=json.loads((configured/'compile_commands.json').read_text())
owners={Path(e['file']).name:e for e in entries if 'CMakeFiles/dome-sculpt-core.dir' in e['command'] and Path(e['file']).name in units}
assert set(owners)==units
suite='source-writable-normal-bake.cpp'
fixture=next(e for e in entries if Path(e['file']).name==suite)
print('recompiled diagnostic owners',sorted(owners),flush=True)
def run(command,tag,env=None,check=True):
    with (out/(tag+'.log')).open('w') as log:
        print(shlex.join(map(str,command)),file=log,flush=True)
        return subprocess.run(command,cwd=configured,stdout=log,stderr=subprocess.STDOUT,env=env,check=check,timeout=260).returncode
def compile(item):
    f,entry=item
    cmd=shlex.split(entry['command'])
    obj=out/(f+'.o')
    cmd[cmd.index('-o')+1]=str(obj)
    if f==suite:cmd[cmd.index('-c')+1]=str(probe_source)
    run(cmd,f)
    return obj
with ThreadPoolExecutor(max_workers=4) as pool:
    objects=list(pool.map(compile,list(owners.items())+[(suite,fixture)]))
shutil.copyfile(baseline/core.name,core)
run(['ar','rs',core,*objects[:-1]],'archive')
link=shlex.split((baseline/'dome-sculpt-source-writable-normal-bake-test-link.log').read_text().splitlines()[0])
def replacement(path):
    if path.endswith('/'+suite+'.o'):return str(objects[-1])
    if path.endswith('/libdome-sculpt-core.a'):return str(core)
    if path.endswith('/libdome-sculpt-baked-emission.a'):return str(codec)
    return path
link=[replacement(p) for p in link]
app=out/'probe'
link[link.index('-o')+1]=str(app)
run(link,'link')
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
fixture=baseline/'build/native-writable-first-key-2048/retained-2048.dsculpt'
rc=run([app,fixture,out/'case'],'run',env,False)
(out/'status.json').write_text(json.dumps({'exit':rc,'scope':'diagnostic refreshed core owners against prior unchanged archives','sources':sorted(owners)},indent=2)+'\n')
raise SystemExit(rc)
