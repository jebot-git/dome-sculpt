// Replay the exact retained atlas with a physical-emission donor.
#include "dome/baked-emission.hpp"
#include "dome/document.hpp"
#include <filesystem>
#include <iostream>

int main(int argc, char **argv) try {
  if(argc!=3) throw std::invalid_argument("Usage: probe retained.dsculpt output-dir");
  using namespace dome;
  const auto directory=std::filesystem::path(argv[2]);
  std::filesystem::create_directories(directory);
  auto scene=Scene::load(argv[1]);
  const auto donor=std::find_if(scene.objects().begin(),scene.objects().end(),[](const auto &o){
    return !o.visible&&o.name=="Hidden high source"&&bool(o.painted);
  });
  if(donor==scene.objects().end())throw std::invalid_argument("Matching hidden source is absent");
  const auto donor_id=donor->id;
  auto &sampled=scene.object(donor_id);
  sampled.material.emissive={8.f,.125f,2.5f};
  auto paint=sampled.painted->snapshot();
  paint->add_layer("Spatially varying physical donor");
  PaintSettings ink;ink.channel=PaintChannel::Emission;ink.emission_units=PaintEmissionUnits::Physical;
  ink.emission={15,.6f,4};ink.front_only=false;
  Brush brush;brush.from={-.2f,.14f,.02f};brush.to={.21f,-.14f,.02f};
  brush.normal={0,0,1};brush.radius=.21f;brush.strength=.73f;
  paint->begin_stroke();paint->stamp(brush,ink);
  if(!paint->end_stroke()||!paint->has_physical_emission())
    throw std::invalid_argument("Missing genuine spatially varying FLOAT donor");
  sampled.painted=std::move(paint);
  scene.validate();

  ObjectBakeSettings settings;
  settings.prepare_normals=false;
  settings.front_mm=settings.back_mm=500;
  settings.ao_samples=settings.padding=0;
  settings.corresponding_topology=true;
  const auto baked_path=directory/"baked-2048-hdr.dsculpt";
  {
    Document doc;
    doc.replace(std::move(scene));
    if(!doc.wait_mesh())throw std::runtime_error("Initial worker timeout");
    doc.bake_from_object(donor_id,settings);
    doc.save_async(baked_path).get();
    if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->error.empty())
      throw std::runtime_error(doc.frame().state->error);
    const auto baked=doc.copy_scene().active().painted->baked();
    if(!baked||!baked->emission_field||baked->coverage.size()!=2048u*2048u||
       !std::all_of(baked->coverage.begin(),baked->coverage.end(),[](uint8_t c){return c==255;}))
      throw std::runtime_error("Fixture did not produce full physical coverage");
    std::cout<<"Full HDR bake bytes "<<baked->storage_bytes()<<std::endl;
  }
  Document doc;
  doc.open(baked_path);
  if(!doc.wait_mesh())throw std::runtime_error("Cold open timeout");
  ShapeKeyEdit key;
  key.name="Full-resolution physical Bake key";
  doc.author_shape(key);
  doc.save_async(directory/"keyed-2048-hdr.dsculpt").get();
  if(!doc.wait_asset()||!doc.wait_mesh()||!doc.frame().state->can_select_shape)
    throw std::runtime_error(doc.frame().state->error);
  std::cout<<"Accepted full HDR key"<<std::endl;
} catch(const std::exception &error) {
  std::cerr<<"Probe refusal: "<<error.what()<<'\n';
  return 1;
}
