#include "dome/baked-emission.hpp"
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <stdexcept>
int main(){
  using namespace dome;
  constexpr uint32_t resolution=2048;
  constexpr size_t count=size_t(resolution)*resolution;
  constexpr size_t available=128*1024*1024-count*13;
  for(bool binary:{false,true}){
    const auto source=[&](size_t i){
      if(binary&&i%65==0)return BakedEmissionSample{};
      return BakedEmissionSample{{},{float(i&2047)/256.f+7,
          float((i/2048)&2047)*0x1p-24f,float(i%641)*.015625f},1};
    };
    const auto field=BakedEmissionField::generate(resolution,source,{available,{}});
    const auto storage=field->storage();
    if(storage.varying_mask!=56||storage.dense.size()||
       storage.binary_coverage.size()!=(binary?count/32:0))
      throw std::runtime_error("Unexpected full-resolution packed layout");
    auto file=field->encode();
    if(file.at(8)!=2||BakedEmissionField::inspect_encoded(file).retained_bytes!=field->storage_bytes())
      throw std::runtime_error("Incorrect packed retained byte count");
    const auto decoded=BakedEmissionField::decode(file);
    for(size_t i=0;i<count;++i){
      const auto value=decoded->texel(i);
      const auto expected=source(i);
      if(std::bit_cast<std::array<uint32_t,7>>(value)!=std::bit_cast<std::array<uint32_t,7>>(expected))
        throw std::runtime_error("Lost exact binary32 radiance or coverage");
    }
    std::cout<<"verified="<<count<<" binary="<<binary<<" retained="<<field->storage_bytes()<<" allowed="<<available<<'\n';
  }
}
