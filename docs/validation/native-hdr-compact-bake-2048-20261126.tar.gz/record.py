from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

root=Path(__file__).resolve().parent
repo=root.parents[1]
destination=repo/'docs/validation'
name='native-hdr-compact-bake-2048-20261126'
product=subprocess.check_output(['git','-C',repo,'rev-parse',sys.argv[1]],text=True).strip()
files={}
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def keep(path,as_path=None):
    files[as_path or str(path.relative_to(root))]=path
    return sha(path)
def read(path):return json.loads(path.read_text())
assert subprocess.check_output(['git','-C',repo,'show','--format=','--binary',product])==(root/'source.patch').read_bytes()
record={'product':product,'source_patch_sha256':keep(root/'source.patch'),'profiles':{},'frontend':{},
        'scope':'Packed lossless FLOAT channels and optional binary coverage for a full-resolution 2048 Bake. A full constant-radiance native Bake survives first shapekey, ordered Save, reopen, Undo/Redo, and exact Shape Restore. Varying HDR Bake, exact coefficient storage, and GPU contribution checks are separately scoped.'}
for n in ('run.py','record.py','compact-grid-oracle.cpp','compact-grid-oracle.log','compact-grid-oracle-asan.log',
          'emission-unit-asan.log','public-focus.py','wayland.py','xr-focus.py','first-key-extra.cpp','xr-portable-runtime.cpp',
          'xr-runtime-build.py','actual-arc.py','early-native.py','early-additional.py','early-hdr-export.cpp',
          'early-varied.py','early-varied-hdr.cpp','exact-extra.py','early-native/run.log','early-native/status.json',
          'early-native/dense-hdr-fixture.log','early-native/hdr-export.log','early-native/varied-hdr.log',
          'shader-probe/status.json','shader-probe/software.log','shader-probe/arc.log'):
    keep(root/n)
before=root.parent/'native-hdr-first-key-probe-20261126'
assert (before/'probe.log').read_text().strip()=='Probe refusal: FLOAT Bake retained channels exceed unchanged paint budget'
keep(before/'probe.cpp','baseline/probe.cpp')
keep(before/'probe.log','baseline/probe.log')
for p in ('release','asan'):
    out=root/p
    state=read(out/'status.json')
    assert state['terminal'] and state['exit']==0
    log=(out/'ctest.log').read_text()
    assert '100% tests passed, 0 tests failed out of 13' in log
    assert 'PASS 20 full-resolution physical Bake and shapekey checks' in log
    assert 'DENSE_HDR_FIRST_KEY 163992646 archive bytes; Restore exact' in log
    assert 'Baked emission GPU 516126 checks PASS' in log
    keys=('status.json','configure.log','build.log','ctest.log','build/regressions.xml','actual-arc.log','actual-arc.json')
    kept={n:keep(out/n) for n in keys}
    arc=read(out/'actual-arc.json')
    assert arc['exit']==0 and arc['gpu_checks']==516126
    record['profiles'][p]={'ctests':13,'dense_hdr_checks':20,'software_gl_checks':516126,'arc':arc,
                           'app_sha256':sha(out/'build/dome-sculpt'),'logs_sha256':kept}
case=lambda profile:root/profile/'build/native-writable-first-key-2048'
parity={}
for n in ('baked-2048-hdr.dsculpt','keyed-2048-hdr.dsculpt','restored-2048-hdr.dsculpt','editable-2048.glb'):
    parity[n]=sha(case('release')/n)
    assert parity[n]==sha(case('asan')/n)
assert parity['baked-2048-hdr.dsculpt']==parity['restored-2048-hdr.dsculpt']
record['byte_parity']=parity
for mode in ('wayland','software','arc-release','arc'):
    out=root/(mode+'-focus-hdr-first-key')
    result=read(out/'status.json')
    assert result['exit']==0 and result['checks']==10
    expected=parity['keyed-2048-hdr.dsculpt'] if mode=='wayland' else sha(case('release')/'keyed-auto-2048-hdr.dsculpt')
    assert result['native_sha256']==expected
    for n in ('status.json','run.log','workflow/report.json'):
        keep(out/n)
    if mode=='wayland':
        for n in ('client.log','compositor.log','runtime-maps.txt'):keep(out/'workflow'/n)
    else:
        profile='asan' if mode=='arc' else 'release'
        for n in ('accept.json','cancel.json','accept.log','cancel.log'):keep(out/'workflow'/n)
        result['runtime_sha256']=sha(root/profile/'libdome-sculpt-portable-test-runtime.so')
    record['frontend'][mode]=result
v1=root/'arc-release-focus-hdr-first-key-observer-v1'
assert read(v1/'status.json')['exit']==1
assert 'ASan runtime does not come first' in (v1/'workflow/accept.log').read_text()
for n in ('status.json','run.log','workflow/accept.log'):
    keep(v1/n)
for n in ('release/extras/status.json','release/extras/hdr-varied-first-key.log','release/extras/hdr-standard-export.log'):
    keep(root/n)
assert read(root/'release/extras/status.json')['exit']==0
assert 'Full HDR bake bytes 104857632' in (root/'release/extras/hdr-varied-first-key.log').read_text()
assert 'Scene paint storage budget exceeded' in (root/'release/extras/hdr-varied-first-key.log').read_text()
assert 'HDR key conversion accepted' in (root/'release/extras/hdr-standard-export.log').read_text()
assert 'Aggregate HDR export fields exceed128MiB' in (root/'release/extras/hdr-standard-export.log').read_text()
record['open']={'varied_hdr_key':'Actual varying full-grid Bake reaches 104857632 bytes, then first key reaches Scene paint storage budget.',
                'standard_glb':'Constant-radiance key converts normals; Standard HDR export reaches its aggregate 128 MiB staging limit.'}
archive=destination/(name+'.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
    for filename,path in sorted(files.items()):
        payload=path.read_bytes()
        item=tarfile.TarInfo(filename)
        item.size=len(payload)
        tar.addfile(item,io.BytesIO(payload))
record['archive']={'file':archive.name,'sha256':sha(archive),'members':len(files)}
(destination/(name+'.json')).write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(product,record['archive'])
