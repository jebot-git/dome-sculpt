from pathlib import Path
import json
import os
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
source=root/'source'
profile=sys.argv[1]
asan=profile=='asan'
out=root/profile
out.mkdir(exist_ok=True)
build=out/'build'
sdk=root.parent/'sdk-20261126/toolkit-sanitize' if asan else Path('/opt/fltk-vr/toolkit')
bdf=Path('/opt/fltk-vr/bdf-runtime')
env={**os.environ,'PKG_CONFIG_PATH':f'{bdf}/lib/pkgconfig:/usr/lib64/pkgconfig'}
start=time.monotonic()
state={'candidate':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),
       'profile':profile,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}
def status(**kwargs):
    state.update(kwargs,elapsed=round(time.monotonic()-start,2))
    p=out/'status.tmp'
    p.write_text(json.dumps(state,indent=2)+'\n')
    p.replace(out/'status.json')
def invoke(args,name,limit,check=True):
    with (out/name).open('w') as log:
        return subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=limit,check=check).returncode
try:
    assert subprocess.check_output(['git','-C',source,'diff','--binary','HEAD'])==(root/'source.patch').read_bytes()
    options=[]
    if asan:
        options.extend(f'-DCMAKE_{k}_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' for k in ('C','CXX'))
        options.extend(f'-DCMAKE_{k}_FLAGS_RELEASE=-O1 -g1 -DNDEBUG' for k in ('C','CXX'))
    status(phase='configure')
    invoke(['cmake','-S',source,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
            '-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DDOME_COMPUTE_BACKEND=CPU',f'-DFLTK_DIR={sdk}/share/fltk',*options],'configure.log',180)
    targets=('dome-sculpt','dome-sculpt-baked-emission-test','dome-sculpt-baked-emission-gpu-test',
       'dome-sculpt-baked-emission-native-test','dome-sculpt-baked-emission-workflow-test',
       'dome-sculpt-source-writable-normal-bake-test','dome-sculpt-bake-test','dome-sculpt-test-runtime')
    status(phase='build exact application and fixtures',targets=targets)
    invoke(['cmake','--build',build,'--parallel','5','--target',*targets],'build.log',4200)
    command=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',build,build,
        '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    settings={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LIBGL_ALWAYS_SOFTWARE':'1',
        'LP_NUM_THREADS':'2','LD_LIBRARY_PATH':f'{sdk}/lib:{bdf}/lib:/usr/lib64'}
    if asan:settings.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in settings.items():command.extend(['--setenv',key,value])
    pattern='^(baked-emission(|-gpu|-native|-workflow|-source|-uv1-worker)|native-writable-(hdr-first-key|first-key|editable-export)-2048|legacy-native-key-bake-conversion|native-key-writable-bake-recipient|native-writable-bake-recipient|bake)$'
    status(phase='test exact app and native fixtures')
    rc=invoke([*command,'ctest','--test-dir',build,'-V','-j1','-R',pattern,'--output-on-failure',
           '--output-junit',build/'regressions.xml'],'ctest.log',2600,False)
    status(phase='complete',terminal=True,exit=rc)
    raise SystemExit(rc)
except Exception as error:
    status(terminal=True,exit=1,error=repr(error))
    raise
