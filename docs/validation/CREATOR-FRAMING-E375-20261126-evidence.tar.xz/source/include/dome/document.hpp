// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "rig-fit-tool.hpp"
#include "vrm-expression-tool.hpp"
#include "input.hpp"
#include "import-browser.hpp"
#include "navigation.hpp"
#include "recovery.hpp"
#include "scene.hpp"
#include "object-selection.hpp"
#include "bake-authoring.hpp"
#include "uv.hpp"
#include "weight-authoring.hpp"
#include "skin-authoring.hpp"
#include "sculpt-resolution.hpp"
#include "procedural-sculpt.hpp"
#include "retopo-authoring.hpp"
#include "polygon-controls.hpp"
#include "cut-authoring.hpp"
#include "native-stroke.hpp"
#include "texture-sets.hpp"
#include "projection-tool.hpp"
#include "creator-tool.hpp"
#include "shapekey-authoring.hpp"
#include <atomic>
#include <condition_variable>
#include <future>
#include <exception>
#include <memory>
#include <mutex>
#include <span>
#include <thread>
namespace dome {
namespace detail {class SculptSceneChunks;}
class MaterialSurfaceQuery;
namespace detail {class TextureSetRangeProof;class TextureSetStrokeLease;}
struct SpatialHand {
  TrackedHand tracked;
  bool joystick = false;
  // Current button levels. Document owns press edges and modal consumption;
  // providers must not pre-filter these with changedSinceLastSync.
  bool undo = false, redo = false;
  float x = 0, y = 0;
  DeviceKind kind = DeviceKind::Controller;
};
struct SpatialView {
  CanvasTransform pose;
  // OpenXR order: left, right, down, up; radians in the physical eye frame.
  std::array<float,4> fov{};
};
struct SpatialFrame {
  uint64_t sequence = 0;
  double time = 0;
  bool focused = false, head_valid = false;
  CanvasTransform head;
  std::array<SpatialHand, 2> hands{};
  std::optional<std::array<SpatialView,2>> views;
};
struct ObjectInfo {
  uint64_t id;
  std::string name;
  bool visible, locked;
  CanvasTransform transform;
  Material material;
  bool mesh_active = false, has_mesh = false;
  bool editable = true, ghost = false;
  CanvasTransform world_transform{};bool world_transform_valid=false;
  std::optional<AffineTransform> affine_world;
  bool selected=false, active=false, hovered=false;
  uint32_t selection_accent=0x6babff;
};
// Exact accepted asset endpoint, built on the file worker before authority
// publication. It never aliases the later mutable document scene.
struct AssetAcceptedSnapshot {
  std::shared_ptr<const Scene> scene;
  uint64_t revision=0,generation=0,content=0,object=0;
  RecoverySource recovery;
};
struct AssetWork {
  std::atomic_bool cancelled{false};
  std::atomic<float> progress{0};
  bool held_weight=false; // Immutable job kind; set before queue publication.
  bool accepted_scene=false; // Scene result can be captured by a following Save.
  std::atomic_bool save_requested{false};
  std::atomic<uint32_t> morph_target{UINT32_MAX};
  // Written/read only by the ordered file worker. Shutdown observes done,
  // published with file_mutex_, even if diagnostic allocation fails.
  std::shared_ptr<const AssetAcceptedSnapshot> completed;
  std::exception_ptr failure;
  std::atomic_bool done{false};
};
struct AssetStatus { bool cancellable=false, cancelling=false; float progress=0; };
struct TextureSetInfo {uint32_t id=0;std::string name;uint32_t resolution=0;size_t triangles=0;};
struct EditorState {
  uint64_t revision = 1, generation = 1, input_epoch = 1;
  bool dirty = false, stroking = false, menu = false;
  bool native_pending = false, native_accepting = false;
  uint64_t native_gesture = 0;
  size_t native_samples = 0;
  uint64_t active_object = 1;
  std::vector<ObjectInfo> objects;
  Tool tool = Tool::Clay;
  int menu_index = 0, menu_page = 0;
  float radius = .12f;
  CanvasTransform canvas{}, panel{};
  std::array<SpatialHand, 2> hands{};
  std::string message, error;
  std::filesystem::path project_path;
  std::shared_ptr<const ImportView> importing;
  std::string recovery_error;
  std::vector<std::string> recovery_candidates;
  bool recovery_busy = false;
  size_t recovery_selected = 0;
  std::string font_file;
  int font_pixels = 16;
  bool light = false, toon = false;
  bool can_save_after_asset = false;
  bool mesh_active = false, asset_busy = false, can_undo = false,
       can_redo = false;
  std::shared_ptr<const DeformationState> deformation;
  size_t rig_joint = 0, morph_target = 0;
  SkinAuthoringOptions skin_options;
  std::vector<uint64_t> skin_sources;
  bool skin_use_locks = true, can_configure_skin = false, can_bind_skin = false;
  bool can_bake = false, can_clear_bake = false, can_cancel_asset = false, can_convert_bake = false;
  bool can_blur_color_layer=false;
  float asset_progress = 0;
  uint64_t bake_source = 0;
  std::vector<uint64_t> bake_sources;
  std::vector<uint64_t> bake_cages; // First entry0 = normal-offset projection.
  ObjectBakeSettings bake_settings;
  std::shared_ptr<const ObjectBakeRecipe> bake_recipe{};
  uint64_t bake_settings_object=0;
  Volume::SculptSettings sculpt_settings;
  CanvasTransform sculpt_transform{};
  bool can_configure_sculpt = false, sculpt_mask_visible = false;
  ProceduralSculptOptions procedural_options;
  bool can_change_resolution = false;
  double sculpt_voxel_mm = 30;
  WeightToolSettings weights;
  bool can_paint_weights = false;
  uint64_t weight_gesture = 0;
  size_t weight_samples = 0;
  bool can_voxel_remesh = false;
  bool can_export_avatar = false;
  float voxel_size_mm = 30;
  std::array<bool, 12> menu_enabled{true, true, true, true, true, true,
                                    true, true, true, true, true, true};
  PaintSettings paint;
  VrControlState controls;
  std::shared_ptr<const UvView> uv;
  std::shared_ptr<const RetopoView> retopology;
  bool can_retopologize = false;
  bool can_cut = false;
  std::shared_ptr<const CutView> cut;
  uint64_t active_sculpt_layer = 0;
  std::vector<std::string> sculpt_layers;
  std::string sculpt_layer_name;
  bool sculpt_layer_visible = true, sculpt_layer_locked = false,
       sculpt_editable = true;
  float sculpt_layer_opacity = 1;
  uint64_t active_layer = 0;
  bool layer_visible = false;
  std::vector<std::string> paint_layers;
  uint32_t accent = 0x6babff;
  int opacity = 255;
  bool object_grab_mode=false, isolate_held=false, object_grabbing=false;
  uint64_t held_object=0, edit_authority=1;
  bool selection_mode=false, selection_focus=false, hierarchy_open=false, can_select_objects=false;
  std::vector<uint64_t> selected_objects, collapsed_groups;
  std::vector<ObjectHierarchyRow> hierarchy;
  size_t hierarchy_offset=0;
  CanvasTransform hierarchy_panel{};
  bool hierarchy_anchored=false;
  std::array<uint64_t,2> selection_hover{};
  std::array<Vec3,2> selection_hit{}; // Canvas coordinates; immutable input result.
  std::array<int,2> hierarchy_hover{-1,-1};
  std::array<bool,2> selection_pressed{true,true}, selection_release{true,true};
  std::shared_ptr<const PolygonView> polygon, polygon_handoff;
  uint64_t polygon_object = 0, polygon_handoff_object = 0,
      polygon_handoff_generation = 0, polygon_handoff_revision = 0;
  PolygonControls polygon_controls;
  bool can_polygon = false, polygon_requires_conversion = false, polygon_has_source = false;
  uint32_t pending_exports = 0;
  bool can_author_shapes=false,can_restore_shapes=false,can_select_shape=false;
  bool shape_sculpt=false;
  uint64_t shape_sculpt_object=0;
  std::shared_ptr<const ProjectionView> projection;
  // Ephemeral preview policy. Authored materials remain the default.
  bool pbr_view = false;
  bool can_preview = true;
  uint64_t view_epoch = 1;
  std::shared_ptr<const RigFitView> rig_fit;
  std::shared_ptr<const VrmExpressionView> expressions;
  std::shared_ptr<const HumanoidCreatorView> creator;
  uint32_t active_texture_set=0;
  std::vector<TextureSetInfo> texture_sets;
  Material texture_material;
  bool can_edit_texture_sets=false,can_resize_bake_target=false,texture_face_select=false;
  std::vector<uint64_t> texture_faces;
};
struct SurfaceRange {
  uint64_t object;
  size_t first, count;
  Material material;
  std::shared_ptr<const TextureMaps> textures{};
  std::shared_ptr<const CreatorAppearance> appearance{};
  size_t first_vertex = 0;
  std::shared_ptr<const SourceMaterialBindings> material_bindings{};
  bool source_frame = false, canonical_frame = false, source_normal_only = false; // Private prototype.
  CanvasTransform object_world{};bool world_frame_valid=false;
  std::optional<AffineTransform> affine_world;
  bool reflected = false; // CPU query geometry retains original corner order.
  std::shared_ptr<const PaintSamplingAttachment> paint_sampling_attachment{};
  bool paint_winding_reversed=false; // Actual packed index flip, not cull mode.
  std::shared_ptr<const NormalPreviewProof> normal_preview_proof{};
  bool pbr_view = false;
  uint32_t texture_set=0; // Object-local persistent material slot, not a raw material table index.
  std::shared_ptr<const detail::TextureSetRangeProof> texture_set_proof;
};
struct SculptMeshingStats {
  size_t objects_reused=0,local_updates=0,full_rebuilds=0,history_fallbacks=0,capacity_fallbacks=0;
  size_t rebuilt_tiles=0,reused_tiles=0,samples_scanned=0,cells_evaluated=0;
  double extraction_ms=0,materialize_ms=0,worker_ms=0;
};
struct MeshSnapshot {
  uint64_t revision = 0, generation = 0;
  Mesh mesh;
  std::vector<SurfaceRange> ranges;
  // Empty: ordinary material view. Otherwise one value per packed vertex;
  // -1: ordinary material, [0,1]: unlit selected-joint weight visualization.
  std::vector<float> selected_weights;
  // Immutable protection overlay: empty ordinary view, otherwise packed vertex
  // count with -1 for other objects and [0,1] protection on the active sculpt.
  std::vector<float> sculpt_masks;
  uint64_t weight_gesture = 0;
  size_t weight_samples = 0;
  uint64_t native_gesture = 0;
  size_t native_samples = 0;
  std::shared_ptr<const MaterialSurfaceQuery> picking;
  std::vector<std::array<float,4>> tangents;
  SculptMeshingStats sculpt_meshing;
  // Opaque, strongly owned packed-geometry dependency identity. Empty snapshots
  // retain conservative legacy upload behavior. Scalars/materials are separate.
  std::shared_ptr<const void> geometry_identity;
  uint64_t cut_session = 0, cut_request = 0, clipped_object = 0;
  CutPlane clip_plane;
  std::vector<Vec3> source_normals, canonical_normals;
  std::vector<std::array<float,4>> source_tangents;
  uint64_t normal_frame_layout_builds=0; // Worker diagnostic, never native state.
  std::vector<std::array<float,4>> source_colors; // Linear RGBA, identity when absent.
  // Scene21 static source sampling: xy PBR, zw MToon. Empty for ordinary
  // geometry; packed through the exact retained-frame corner expansion.
  std::vector<std::array<float,4>> normal_coordinates;
  std::vector<std::array<float,2>> paint_coordinates; // Explicit packed vertices.
  bool pbr_view = false;
  uint64_t view_epoch = 0;
  // Genuine separate Volume preview geometry. Flat mesh/ranges keep their
  // existing meaning; no empty fake ranges or opaque-owner casts authorize
  // chunks. This appended snapshot field requires a coherent producer and
  // consumer rebuild, including frontend, renderer, query and Cut helpers.
  std::shared_ptr<const detail::SculptSceneChunks> sculpt_chunks{};
};
struct AssetSource {
  uint64_t generation = 0, revision = 0, object = 0, edit_authority = 0;
};
struct SceneDraft {
  Scene scene;
  AssetSource source;
};
enum class AssetExportFormat { Glb, Avatar, EditableGlb256, EditableGlb512, EditableGlb1024,
  EditableAvatar256, EditableAvatar512, EditableAvatar1024 };
struct EditorSnapshot {
  std::shared_ptr<const EditorState> state;
  std::shared_ptr<const MeshSnapshot> surface;
};
// Model edits are serialized; renderers only acquire immutable atomic
// snapshots. Neither meshing, UV generation nor file I/O executes in the XR
// frame loop.
class Document {
  friend struct DocumentNativeTestAccess;
  friend struct DocumentTransactionTestAccess;
public:
  Document();
  ~Document();
  Document(const Document &) = delete;
  Document &operator=(const Document &) = delete;
  EditorSnapshot frame() const;
  Volume copy_volume() const;
  Scene copy_scene() const;
  SceneDraft draft_scene() const;
  void replace(Scene, bool clean = true);
  uint64_t add_object(bool sphere = true);
  void duplicate_object();
  void delete_object();
  void select_object(uint64_t);
  void configure_selection(bool);
  void select_objects(std::span<const uint64_t>, ObjectSelection=ObjectSelection::Replace,
                      AssetSource expected={});
  void select_group(uint64_t, ObjectSelection=ObjectSelection::Replace, AssetSource expected={});
  void show_object_hierarchy(bool);
  void focus_selection(bool);
  void object_properties(uint64_t, std::string, bool visible, bool locked,
                         CanvasTransform, Material, AssetSource expected = {});
  void object_properties(uint64_t, std::string, bool visible, bool locked,
                         CanvasTransform, Material, AssetSource,
                         std::optional<std::array<float,3>> active_emission_override);
  bool object_editable(uint64_t) const;
  void configure_object_grab(bool mode, bool isolate);
  void hold_object(uint64_t);
  void release_held_object(bool accept = true);
  void object_visibility(uint64_t, bool, AssetSource expected = {});
  bool begin_object_grab(uint64_t);
  void move_held_object(CanvasTransform local);
  // Absolute world-similarity delta from the current grab/rebase anchor.
  void move_held_object_world(CanvasTransform delta);
  void end_object_grab(bool accept = true);
  std::optional<uint64_t> pick_object(Vec3,Vec3,double material_time=0) const;
  void replace(Volume, bool clean = true);
  void seed();
  void edit_texture_set(TextureSetEdit,AssetSource expected = {});
  void texture_set_action(SpatialCommand);
  bool texture_face_pointer(Vec3 origin,Vec3 direction,bool additive=false,double material_time=0);
  bool begin_native_stroke();
  void configure_shape_sculpt(bool enabled);
  void select_shape_target(uint32_t target, AssetSource expected = {});
  bool sample_native_stroke(NativeStrokeSample);
  void end_native_stroke(bool accept = true);
  bool wait_native_stroke(std::chrono::milliseconds timeout = std::chrono::seconds(60)) const;
  bool begin_desktop();
  void stamp_desktop(Brush);
  void end_desktop();
  void cancel_desktop();
  std::optional<Vec3> raycast(Vec3, Vec3) const;
  std::optional<Vec3> raycast(Vec3, Vec3, double material_time) const;
  Vec3 gradient(Vec3) const;
  bool undo();
  bool redo();
  void configure(Tool, float radius);
  void appearance(std::string file, int pixels, bool light, uint32_t accent,
                  int opacity);
  void shading(bool toon);
  void authored_shading();
  bool can_preview_expressions() const;
  void begin_expression_preview();
  void configure_expression_preview(size_t entry,float weight,uint64_t session,AssetSource expected={});
  void end_expression_preview(bool apply,uint64_t session=0,AssetSource expected={});
  void expression_action(SpatialCommand);
  void prepare_mesh(uint32_t resolution = 512);
  // Native asset operations run on the ordered worker against a detached scene.
  // No callback may retain mutable aliases or access UI/Document/model state.
  using SceneOperation = std::function<void(Scene &, const std::function<bool()> &)>;
  void edit_scene(std::string label, SceneOperation, AssetSource expected = {});
  // Creation is additive by default. Existing avatars are never regenerated
  // from their parameter record; selected settings only seed a NEW avatar.
  void create_humanoid_avatar(HumanoidControls, std::string name="Humanoid",
                             AssetSource expected={},bool keep_existing=true);
  void begin_humanoid_creator();
  void configure_humanoid_creator(HumanoidCreatorSettings,uint64_t session,AssetSource expected={});
  void end_humanoid_creator(bool apply,uint64_t session=0,AssetSource expected={});
  void humanoid_creator_action(SpatialCommand);
  void import_asset(const std::filesystem::path &, uint32_t resolution = 512);
  AssetSource begin_import() const; // Capture before opening native options.
  ProjectionToolSettings projection_settings() const;
  void configure_projection(ProjectionToolSettings, AssetSource expected={});
  void load_projection_image(const std::filesystem::path &, std::optional<ProjectionCamera> = {}, AssetSource expected={});
  void browse_projection_images(std::filesystem::path = {});
  void cancel_projection_load();
  void projection_action(SpatialCommand);
  bool wait_projection_image(std::chrono::milliseconds timeout=std::chrono::seconds(30)) const;
  void import_asset(const std::filesystem::path &, const ImportSettings &, AssetSource expected = {});
  ImportSettings import_settings() const;
  void configure_import(ImportSettings);
  void open_import_browser(std::filesystem::path = {});
  void import_action(SpatialCommand);
  void remesh_to_sculpt(float world_voxel_mm, AssetSource expected = {});
  void remesh_to_triangles(float world_edge_mm, AssetSource expected = {});
  void bake_from_object(uint64_t source, ObjectBakeSettings = {}, AssetSource expected = {});
  void clear_bake(AssetSource expected = {});
  void convert_baked_normals(AssetSource expected = {});
  void cancel_asset_work();
  void cancel_background_work();
  void author_shape(ShapeKeyEdit,AssetSource expected={});
  AssetStatus asset_status() const;
  void begin_voxel_remesh();
  void edit_voxel_size(float world_voxel_mm);
  void end_voxel_remesh(bool accept);
  void begin_triangle_remesh();
  void edit_triangle_edge(float world_edge_mm);
  void end_triangle_remesh(bool accept);
  bool wait_asset(
      std::chrono::milliseconds timeout = std::chrono::seconds(60)) const;
  void begin_uv();
  void edit_uv(UvAction, float x = 0, float y = 0);
  void end_uv(bool accept);
  void begin_polygon(bool convert_source = false, AssetSource expected = {});
  void edit_polygon(PolygonAction);
  void configure_polygon(PolygonControls);
  void polygon_pointer(Vec3 origin, Vec3 direction, PolygonAction, bool additive = false);
  void end_polygon(bool accept);
  void restore_polygon_source(AssetSource expected = {});
  bool wait_polygon(std::chrono::milliseconds timeout = std::chrono::seconds(60)) const;
  void begin_retopology();
  void edit_retopology(RetopoAction);
  void end_retopology(bool accept);
  void retopology_distance(float mm);
  bool wait_retopology(std::chrono::milliseconds timeout = std::chrono::seconds(60)) const;
  void begin_cut();
  void edit_cut(CutSettings);
  void end_cut(bool accept);
  void begin_cut_parameter(VrParameter);
  void edit_cut_parameter(int component, float normalized);
  void end_cut_parameter(bool accept);
  bool wait_cut(std::chrono::milliseconds timeout = std::chrono::seconds(60)) const;
  bool wait_uv(std::chrono::milliseconds timeout = std::chrono::seconds(60)) const;
  void use_source();
  void cancel_spatial_menu();
  void use_mesh();
  void paint_settings(PaintSettings);
  void weight_settings(WeightToolSettings, std::optional<uint32_t> joint = {}, AssetSource expected = {});
  void bind_skin(SkinAuthoringOptions, AssetSource expected = {});
  void bind_skin_selected(SkinAuthoringOptions,AssetSource expected={},
                          std::vector<uint64_t> expected_selection={});
  void fit_humanoid_rig(HumanLandmarks, RigFitOptions = {}, AssetSource expected = {});
  void begin_rig_fit();
  void configure_rig_fit(RigFitView);
  void accept_rig_fit();
  void cancel_rig_fit(AssetSource expected = {});
  void rig_fit_action(SpatialCommand);
  void paint_command(SpatialCommand);
  void blur_color_layer(PaintBlurOptions = {},AssetSource = {});
  void sculpt_command(SpatialCommand);
  void sculpt_settings(Volume::SculptSettings, AssetSource expected = {});
  void apply_procedural_sculpt(ProceduralSculptOptions, AssetSource expected = {});
  void change_sculpt_resolution(SculptResolutionOptions, AssetSource expected = {});
  void sculpt_mask_fill(float, AssetSource expected = {});
  void sculpt_mask_invert(AssetSource expected = {});
  void sculpt_layer_properties(uint64_t object, uint64_t layer, std::string,
                               bool visible, bool locked, float opacity);
  void report_error(std::string);
  void enable_recovery(std::filesystem::path = default_recovery_directory());
  void refresh_recovery();
  void restore_recovery(size_t index = 0);
  RecoveryStatus recovery_status() const;
  void submit(SpatialFrame);
  // Platform adapters may deliver a burst with original sample times. Focus
  // loss is ordered after earlier button transitions, not a queue discard.
  void submit(std::span<const SpatialFrame>);
  void finish_spatial();
  void begin_spatial();
  void rebase_space(std::optional<CanvasTransform>);
  void save(const std::filesystem::path &);
  std::future<void> save_async(const std::filesystem::path &);
  std::future<void> open_async(const std::filesystem::path &);
  // Captures a committed scene and performs ordered file work asynchronously.
  // Ignoring the returned promise never blocks the UI thread.
  std::future<void> export_asset(const std::filesystem::path &,
                                AssetExportFormat = AssetExportFormat::Glb);
  void open(const std::filesystem::path &);
  void request_save(bool export_mesh = false);
  bool
  wait_mesh(std::chrono::milliseconds timeout = std::chrono::seconds(10)) const;
  bool wait_input(
      std::chrono::milliseconds timeout = std::chrono::seconds(10)) const;

private:
  mutable std::mutex model_mutex_;
  Scene scene_;
  std::shared_ptr<Volume> bound_volume_ = scene_.active().volume;
  Volume &volume() { return *scene_.active().volume; }
  const Volume &volume() const { return *scene_.active().volume; }
  struct History {
    std::shared_ptr<Volume> sculpt;
    std::optional<Scene> before, after;
    uint64_t from = 0, to = 0;
    std::shared_ptr<PaintedMesh> paint{};
    // Only a sealed structural cut may move the corresponding held endpoint.
    uint64_t held_before=0, held_after=0;
  };
  class AuthorityTransition;
  class Transaction;
  Transaction *transaction_ = nullptr;
  std::deque<History> undo_, redo_;
  SpatialInput input_;
  CanvasNavigation navigation_, object_navigation_;
  CanvasTransform held_start_transform_{},held_preview_transform_{};
  struct HeldAffine;
  std::shared_ptr<const HeldAffine> held_affine_;
  CanvasTransform object_world_transform_locked(uint64_t) const;
  AffineTransform object_world_matrix_locked(uint64_t) const;
  void move_held_object_world_locked(CanvasTransform);
  bool object_editable_locked(uint64_t) const;
  bool invalidate_object_authority_locked();
  void finish_object_grab_locked(bool accept, bool release);
  bool begin_object_grab_locked(uint64_t);
  bool held_weight_pending_locked() const;
  void configure_object_grab_locked(bool,bool);
  void move_held_object_locked(CanvasTransform);
  void update_object_grab_locked(const SpatialFrame &);
  void require_object_editable_locked(uint64_t) const;
  bool reject_texture_paint_locked();
  void require_authority_locked(AssetSource) const;
  EditorState state_;
  uint64_t creator_serial_=0;
  struct InitialCreatorWorkspace {
    InitialCreatorWorkspace()=default;
    InitialCreatorWorkspace(uint64_t generation,uint64_t content):generation(generation),content(content){}
    uint64_t generation=0,content=0;
    bool navigated=false,seen_focused=false;
    std::shared_ptr<AssetWork> pending;
    uint64_t target_generation=0,target_revision=0,target_content=0,target_group=0,target_input_epoch=0;
  } initial_creator_{1,1};
  bool fit_initial_creator_locked(const SpatialFrame &);
  void cancel_initial_creator_fit_locked() noexcept;

  bool desktop_ = false, anchored_ = false;
  uint64_t last_volume_ = 0, last_paint_ = 0, content_ = 1, saved_content_ = 1,
           next_content_ = 2;
  std::filesystem::path path_;
  ImportSettings import_settings_;
  AssetSource import_source_{};
  std::shared_ptr<const ImportView> import_view_;
  std::atomic<uint64_t> import_request_{0};
  void import_asset_locked(const std::filesystem::path &,const ImportSettings &,AssetSource expected = {});
  void browse_import_locked(const std::filesystem::path &);
  void import_command_locked(SpatialCommand);
  bool import_command_enabled_locked(SpatialCommand) const;
  std::unique_ptr<RecoveryService> recovery_;
  std::filesystem::path recovery_root_;
  RecoverySource recovery_source_;
  std::vector<RecoveryCandidate> recovery_catalog_;
  uint64_t recovery_content_ = 0;
  std::string recovery_discovery_error_;
  void replace_locked(Scene, bool clean, std::filesystem::path = {}, std::string message = {});
  void checkpoint_locked();
  void refresh_recovery_locked();
  void restore_recovery_locked(size_t);
  std::optional<Scene> control_before_;
  PaintSettings control_settings_;
  WeightToolSettings control_weights_;
  float control_radius_ = 0;
  bool control_changed_ = false;
  uint64_t control_object_ = 0;
  AssetSource control_source_{};
  uint64_t rig_object_ = 0;
  size_t control_rig_index_ = 0;
  bool weight_stroking_ = false;
  AssetSource weight_source_{};
  uint32_t weight_joint_ = 0;
  WeightToolSettings weight_stroke_settings_{};
  std::vector<WeightBrush> weight_samples_;
  std::atomic<uint64_t> weight_epoch_{0};
  uint64_t weight_scheduled_epoch_ = 0;
  size_t weight_scheduled_samples_ = 0;
  std::shared_ptr<const MeshSnapshot> weight_base_;
  void restore_weight_view_locked(const std::shared_ptr<const MeshSnapshot> &);
  void invalidate_weight_view_locked(bool restore);
  float control_voxel_mm_ = 30;
  CutSettings cut_settings_, control_cut_settings_;
  std::vector<CutSettings> cut_undo_, cut_redo_;
  AssetSource cut_source_{};
  std::shared_ptr<const MeshSnapshot> cut_base_;
  std::shared_ptr<const BakeSource> cut_bake_source_;
  std::atomic<uint64_t> cut_session_{0}, cut_request_{0};
  struct CutJob { uint64_t session=0, request=0; AssetSource expected; CutSettings settings; };
  std::optional<CutJob> cut_job_;
  mutable std::mutex cut_mutex_;
  mutable std::condition_variable cut_changed_;
  void begin_cut_locked();
  void edit_cut_locked(CutSettings, bool remember = true);
  void end_cut_locked(bool);
  void cancel_cut_locked();
  void cut_history_locked(bool redo);
  void finish_cut_parameter_locked(bool accept);
  void cut_from_hand_locked();
  void cut_loop();
  void drain_asset_shutdown() noexcept;
  float control_resolution_voxel_ = .03f;
  AssetSource polygon_source_{};
  std::shared_ptr<const Scene> polygon_initial_;
  std::atomic<uint64_t> polygon_session_{0};
  bool polygon_stroking_ = false;
  uint32_t polygon_owner_ = 0;
  std::atomic_bool polygon_accepting_{false};
  std::atomic<size_t> polygon_pending_{0};
  struct PolygonAccept {
    mutable std::mutex mutex;
    std::condition_variable changed;
    bool done = false, success = false, held_pose = false;
    std::shared_ptr<const Scene> before, completed, original;
    std::shared_ptr<AssetWork> work;
    AssetSource source;
    uint64_t content = 0, revision = 0, isolation_target = 0;
    RecoverySource recovery_source;
    CanvasTransform pose{};
    std::shared_ptr<const NativeAffineEdit> affine_pose;
    std::array<bool,2> grips{};
    std::exception_ptr error;
  };
  std::shared_ptr<PolygonAccept> polygon_accept_;
  bool polygon_closing_ = false, polygon_predicate_locked_ = false;
  std::array<bool,2> polygon_grip_latch_{};
  struct PolygonJob {
    uint64_t session = 0;
    std::shared_ptr<const Scene> initial;
    std::shared_ptr<PolygonAccept> acceptance;
    std::optional<PolygonAction> action;
    Vec3 origin{}, direction{};
    std::optional<AffineTransform> world; // True metric/pointer frame, including held/XR placement.
    float radius = .015f, amount = .01f, maximum = 100;
    unsigned cuts = 1;
    bool accept = false, convert_source = false, additive = false;
  };
  mutable std::mutex polygon_mutex_;
  mutable std::condition_variable polygon_changed_;
  std::deque<PolygonJob> polygon_jobs_;
  void begin_polygon_locked(bool convert_source);
  void end_polygon_locked(bool accept);
  void cancel_polygon_locked(bool cancel_acceptance = true);
  void complete_polygon_accept(const std::shared_ptr<PolygonAccept> &, bool success,
      std::shared_ptr<const Scene> = {}, uint64_t content = 0, uint64_t revision = 0, std::exception_ptr = {});
  void drain_polygon_shutdown();
  bool held_polygon_pending_locked() const;
  void queue_polygon_locked(PolygonJob, bool coalescible = false);
  void polygon_pointer_locked(Vec3, Vec3, PolygonAction, bool xr, bool additive = false, uint32_t owner = 0);
  bool polygon_source_matches_locked() const;
  void rebase_polygon_transform_locked();
  void restore_polygon_source_locked(AssetSource);
  void polygon_loop();
  void process_polygon_pointer_locked(const SpatialFrame &);
  bool polygon_command_enabled_locked(SpatialCommand) const;
  void polygon_command_locked(SpatialCommand);
  float retopo_snap_mm_ = 50, control_retopo_mm_ = 50;
  AssetSource retopo_source_{};
  std::atomic<uint64_t> retopo_session_{0};
  bool retopo_stroking_ = false, retopo_sampled_ = false, retopo_accepting_ = false;
  size_t retopo_pending_ = 0;
  // Shared independent-input/file-queue handoff, protected by retopo_mutex_.
  // This is a deque element payload, not a new Document/EditorState field.
  class RetopoInputScope;
  void rebase_space_locked(std::optional<CanvasTransform>, RetopoInputScope &);
  struct RetopoStep {
    RetopoAction action;
    Vec3 point{};
    float snap_mm = 50;
    bool coalescible = false;
  };
  struct RetopoAcceptance {
    enum class Admission { Pending, Accepted, Rejected };
    Admission admission = Admission::Pending;
    std::shared_ptr<AssetWork> work;
    std::shared_ptr<bool> changed;
    std::shared_ptr<const RetopoMesh> topology;
    uint64_t source = 0;
    CanvasTransform transform{};
    std::exception_ptr error;
    bool ready = false;
    // A pending batch stays in the deque until its caller publishes. No
    // accepted payload is coalesced or otherwise modified by a later caller.
    bool input_batch = false, counted = false, cancel_workspace = false, opening = false;
    std::optional<uint64_t> next_session;
    std::vector<RetopoStep> steps;
    std::shared_ptr<AssetWork> cancel_work;
  };
  struct RetopoJob {
    uint64_t session = 0;
    std::shared_ptr<const Scene> initial;
    std::optional<RetopoAction> action;
    Vec3 point{};
    float snap_mm = 50;
    bool accept = false, coalescible = false;
    std::shared_ptr<RetopoAcceptance> acceptance{};
  };
  mutable std::mutex retopo_mutex_;
  mutable std::condition_variable retopo_changed_;
  std::deque<RetopoJob> retopo_jobs_;
  void begin_retopology_locked();
  void end_retopology_locked(bool);
  void cancel_retopology_locked();
  void queue_retopology_locked(RetopoAction, Vec3 = {}, bool coalescible = false);
  void retopo_loop();
  std::optional<UvWorkspace> uv_;
  uint64_t uv_session_ = 0;
  bool uv_accept_pending_ = false;
  bool uv_solving_ = false;
  struct UvValidationJob {
    uint64_t request, session, generation;
    std::shared_ptr<const Mesh> mesh;
    std::optional<UvAction> operation;
    std::shared_ptr<UvWorkspace> workspace;
  };
  mutable std::mutex uv_mutex_;
  mutable std::condition_variable uv_changed_;
  std::optional<UvValidationJob> uv_validation_;
  std::weak_ptr<const Mesh> uv_scheduled_;
  std::atomic<uint64_t> uv_request_{0};
  std::optional<UvValidationJob> prepare_uv_schedule_locked();
  void invalidate_uv_locked();
  bool uv_retention_requested_locked() const;
  bool uv_paint_retention_requested_locked() const;
  bool uv_paint_retention_available_locked() const;
  void restore_uv_source_locked();
  bool uv_retention_changes_locked() const;
  void uv_loop();
  void queue_uv_operation_locked(UvAction);
  void apply_uv_action_locked(UvAction, float = 0, float = 0);
  void queue_uv_locked(std::shared_ptr<const Mesh>);
  std::atomic<std::shared_ptr<const EditorState>> published_;
  std::atomic<std::shared_ptr<const MeshSnapshot>> mesh_;
  struct FileJob;
  struct ProjectionLoad {
    enum class Kind {Image,Directory};
    Kind kind=Kind::Image;
    uint64_t request=0;
    AssetSource source;
    std::filesystem::path path;
    ProjectionToolSettings settings;
    std::atomic_bool cancelled{false},done{false};
    std::exception_ptr failure;
  };
  std::shared_ptr<ProjectionLoad> projection_load_;
  std::atomic<uint64_t> projection_request_{0};
  std::atomic_bool projection_notice_pending_{false};
  void retry_projection_failure_locked() noexcept;
  bool projection_command_enabled_locked(SpatialCommand) const;
  void projection_command_locked(SpatialCommand);
  bool process_projection_spatial_locked(const SpatialFrame &);
  void load_projection_locked(const std::filesystem::path &, std::optional<ProjectionCamera>, AssetSource);
  void browse_projection_locked(const std::filesystem::path &);
  void cancel_projection_load_locked();
  void projection_file(const FileJob &);
  void capture_polygon_file(FileJob &);
  struct NativeStroke {
    uint64_t epoch = 0;
    AssetSource source;
    CanvasTransform transform;
    std::optional<AffineTransform> affine_world;
    std::shared_ptr<const DeformationState> deformation;
    std::shared_ptr<const Scene> initial;
    std::shared_ptr<const detail::TextureSetStrokeLease> texture_set;
    std::shared_ptr<const MeshSnapshot> original_preview;
    std::optional<size_t> shape_target;
    uint32_t spatial_owner=0;
    NativeStrokeSpace space=NativeStrokeSpace::Ray;
    int menu_page=24;
    std::optional<Vec3> contact_previous;
    std::shared_ptr<const HeldAffine> held_basis;
    std::atomic_bool release_held{false};
    std::atomic_bool menu_after{false};
    PaintSettings paint;
    // Projection image/options and scene visibility are immutable for the gesture.
    std::shared_ptr<const ProjectionView> projection;
    std::vector<uint64_t> projection_excluded;
    struct QueuedSample { NativeStrokeSample input; CanvasTransform world_from_reference{}; };
    std::deque<QueuedSample> samples;
    size_t submitted = 0;
    std::atomic_bool cancelled{false}, accepted{false};
    bool accepting = true, done = false;
    std::exception_ptr failure;
    std::shared_ptr<const Scene> completed;
    uint64_t revision = 0, content = 0;
    RecoverySource recovery_source;
    bool pbr_view = false;
    uint64_t view_epoch = 0;
  };
  std::shared_ptr<NativeStroke> native_stroke_;
  std::shared_ptr<const Scene> native_source_scene_;
  mutable std::mutex native_mutex_;
  mutable std::condition_variable native_changed_;
  std::deque<std::shared_ptr<NativeStroke>> native_jobs_;
  bool native_processing_ = false;
  std::atomic<uint64_t> native_epoch_{0};
  void native_loop();
  bool begin_native_locked(uint32_t spatial_owner=0,NativeStrokeSpace space=NativeStrokeSpace::Ray);
  bool sample_native_locked(NativeStrokeSample);
  void configure_shape_sculpt_locked(bool);
  void process_shape_spatial_locked(const SpatialFrame &);
  std::array<bool,2> shape_rearmed_{};
  std::array<bool,2> contact_rearmed_{};
  bool process_affine_paint_spatial_locked(const SpatialFrame &);
  void end_native_locked(bool);
  void cancel_native_locked();
  void drain_native_shutdown();
  void capture_native_file(FileJob &);
  bool expression_source_matches_locked() const;
  bool expression_command_enabled_locked(SpatialCommand) const;
  void begin_expression_preview_locked();
  void configure_expression_preview_locked(size_t,float,uint64_t,AssetSource);
  void end_expression_preview_locked(bool,uint64_t=0,AssetSource={});
  void expression_command_locked(SpatialCommand);
  bool creator_source_matches_locked() const;
  bool creator_command_enabled_locked(SpatialCommand) const;
  void begin_humanoid_creator_locked();
  void configure_humanoid_creator_locked(HumanoidCreatorSettings,uint64_t,AssetSource);
  void end_humanoid_creator_locked(bool,uint64_t=0,AssetSource={});
  void creator_command_locked(SpatialCommand);
  bool creator_history_locked(bool);
  void creator_control_locked(VrControlEvent);
  void finish_creator_control_locked(bool);
  void create_humanoid_avatar_locked(HumanoidControls,std::string,AssetSource,bool);
  struct MeshJob {
    uint64_t revision, generation;
    Scene scene;
    bool weight_view = false;
    bool linked_weights = true;
    uint32_t weight_joint = 0;
    uint64_t weight_gesture = 0;
    std::vector<WeightBrush> weight_samples;
    WeightToolSettings weight_settings;
    bool sculpt_mask_view = false;
    uint64_t native_gesture = 0;
    size_t native_samples = 0;
    bool pbr_view = false;
    uint64_t view_epoch = 0;
    std::shared_ptr<const VrmExpressionView> expressions;
  };
  mutable std::mutex mesh_mutex_;
  mutable std::condition_variable mesh_changed_;
  std::optional<MeshJob> pending_mesh_;
  mutable std::mutex input_mutex_;
  mutable std::condition_variable input_changed_;
  std::deque<std::pair<uint64_t, SpatialFrame>> inputs_;
  bool reset_input_ = false, processing_ = false, spatial_accepting_ = true;
  struct ExportWork {
    enum class Phase { Working, Cancelled, Committing, Finished };
    std::atomic<Phase> phase{Phase::Working};
    bool cancellable() const { return phase.load()==Phase::Working; }
    bool cancelled() const { return phase.load()==Phase::Cancelled; }
    bool cancel() {
      auto expected=Phase::Working;
      return phase.compare_exchange_strong(expected,Phase::Cancelled);
    }
    void begin_commit() {
      auto expected=Phase::Working;
      if(!phase.compare_exchange_strong(expected,Phase::Committing))
        throw std::runtime_error("Export cancelled");
    }
  };
  struct CutHandoff {
    uint64_t source=0, shell=0, cap=0, group=0, held_source=0;
    std::shared_ptr<const Scene> sealed;
    std::shared_ptr<const CutView> draft, accepting;
  };
  void validate_cut_handoff(const Scene &, const Scene &, const CutHandoff &) const;
  struct FileJob {
    Scene scene;
    std::filesystem::path path;
    uint64_t revision, generation, content;
    bool export_mesh;
    bool adopt_path = false;
    std::shared_ptr<std::promise<void>> completion{};
    bool open_project = false;
    bool prepare_mesh = false;
    uint64_t object = 0, source_revision = 0;
    uint32_t resolution = 512;
    std::shared_ptr<Volume> source_identity{};
    std::shared_ptr<const Mesh> uv_mesh{};
    std::shared_ptr<const std::vector<uint32_t>> uv_source_vertices{};
    std::shared_ptr<PaintedMesh> paint_identity{};
    RecoverySource recovery_source{};
    bool create_parent = false;
    bool discover_recovery = false;
    std::optional<RecoveryCandidate> restore_recovery{};

    uint64_t uv_session = 0;
    bool uv_desktop = false;
    SceneOperation scene_operation{};
    std::string operation_label{};
    std::shared_ptr<std::string> operation_report{};
    std::shared_ptr<AssetWork> work{};
    std::shared_ptr<bool> operation_changed{};
    AssetExportFormat export_format = AssetExportFormat::Glb;
    std::shared_ptr<const MeshSnapshot> rollback_preview{};
    uint64_t retopo_session = 0;
    uint64_t cut_session = 0;
    std::shared_ptr<NativeStroke> native_capture{};
    std::shared_ptr<const Scene> capture_scene{};
    uint64_t edit_authority=0,isolation_target=0;
    bool discover_import=false;
    uint64_t import_request=0;
    std::shared_ptr<PolygonAccept> polygon_capture;
    std::shared_ptr<ExportWork> export_work;
    std::shared_ptr<AssetWork> asset_capture;
    std::shared_ptr<CutHandoff> cut_handoff;
    bool uv_keep_normals=false;
    bool uv_keep_paint=false;
    std::shared_ptr<ProjectionLoad> projection_load;
    std::shared_ptr<const detail::TextureSetStrokeLease> texture_set_source;
  };
  // One running job plus the bounded eight-entry ordered file queue.
  // Protected by model_mutex_; explicit Cancel owns the phase transition.
  std::array<std::shared_ptr<ExportWork>,9> exports_{};
  struct WorkerNotice {
    std::exception_ptr error;
    std::shared_ptr<const EditorState> publication;
    std::shared_ptr<std::promise<void>> completion;
    std::string label;
    uint64_t generation=0,import_request=0,cut_session=0,retopo_session=0;
    bool input=false,discover_import=false,discover_recovery=false,cancelled=false,held_weight=false,export_job=false;
  };
  // Three bounded per-worker error records, no Scene/mesh copies. Failed UI
  // publication retries off the UI thread; promises keep original exceptions.
  std::array<std::optional<WorkerNotice>,3> worker_notices_;
  std::atomic_bool worker_notices_pending_{false},input_notice_pending_{false},worker_completion_pending_{false},native_notice_pending_{false};
  void input_worker_error_locked(std::exception_ptr) noexcept;
  void file_worker_error_locked(FileJob &,std::exception_ptr) noexcept;
  void retry_worker_notices_locked(bool input=false,bool native=false) noexcept;
  void native_worker_error_locked(const std::shared_ptr<NativeStroke>&,std::exception_ptr) noexcept;
  void signal_worker_notices_locked() noexcept;
  std::atomic<std::shared_ptr<AssetWork>> asset_work_;
  mutable std::mutex file_mutex_;
  mutable std::condition_variable file_changed_;
  std::deque<FileJob> files_;
  bool files_stopping_ = false;
  std::atomic_bool stopping_{false};
  std::thread mesh_thread_, input_thread_, file_thread_, uv_thread_, retopo_thread_, cut_thread_, native_thread_, polygon_thread_;
  void discover_import_file(const FileJob &);
  void import_listing_error(const FileJob &,const std::exception &);
  void request_worker_stop();
  void publish_locked(bool force_geometry = false, bool checkpoint = true);
  void record_locked(History);
  void record_stroke_locked();
  void scene_changed_locked(Scene before);
  bool undo_locked(bool redo);
  void bind_locked(bool preserve_menu = false);
  bool action_active_locked() const;
  bool pending_locked() const;
  void begin_action_locked();
  void stamp_action_locked(const Brush &);
  bool end_action_locked();
  void cancel_action_locked();
  void prepare_locked(uint32_t);
  void finish_locked();
  void process_locked(const SpatialFrame &);
  void shading_locked(bool pbr, bool toon);
  bool selection_ready_locked() const;
  void configure_selection_locked(bool);
  void select_objects_locked(std::span<const uint64_t>,ObjectSelection,AssetSource={});
  void select_group_locked(uint64_t,ObjectSelection,AssetSource={});
  bool process_object_selection_locked(const SpatialFrame &);
  void selection_hierarchy_locked();
  void file_locked(bool export_mesh, AssetExportFormat = AssetExportFormat::Glb);
  void queue_export_locked(FileJob);
  void retire_export_locked(const std::shared_ptr<ExportWork> &) noexcept;
  void process_uv_transfer(FileJob &);
  void command_locked(SpatialCommand);
  bool command_enabled_locked(SpatialCommand) const;
  bool parameter_enabled_locked(VrParameter) const;
  void control_event_locked(VrControlEvent);
  void finish_control_locked(bool accept);
  void mesh_loop();
  void input_loop();
  void file_loop();
  void queue_scene_operation(std::string, SceneOperation, AssetSource,
                             std::shared_ptr<std::string>);
  // Configuration belongs to the same accepted publication as its Bake job.
  // POD metadata only; no callback or permission to alter arbitrary scene data.
  struct BakeAdmission { uint64_t source=0; ObjectBakeSettings settings; };
  struct SkinAdmission {
    SkinAuthoringOptions options;
    std::vector<uint8_t> locks;
    bool use_locks=false;
  };
  void queue_texture_set_locked(TextureSetEdit,AssetSource = {});
  void queue_blur_color_locked(PaintBlurOptions,AssetSource = {});
  bool texture_face_pointer_locked(Vec3,Vec3,bool,double);
  void texture_set_command_locked(SpatialCommand);
  bool texture_set_command_enabled_locked(SpatialCommand)const;
  std::shared_ptr<const Mesh> texture_face_geometry_;
  uint64_t texture_face_object_=0;
  std::array<bool,2> texture_face_pressed_{true,true};
  void queue_scene_operation_locked(std::string, SceneOperation, AssetSource,
                                    std::shared_ptr<std::string>, std::shared_ptr<AssetWork> = {}, std::shared_ptr<bool> = {},
                                    std::shared_ptr<const MeshSnapshot> = {}, uint64_t retopo_session = 0,
                                    uint64_t cut_session = 0, std::shared_ptr<CutHandoff> = {},
                                    std::optional<BakeAdmission> = {}, uint64_t uv_restore_session = 0, std::optional<SkinAdmission> = {},
                                    std::shared_ptr<const detail::TextureSetStrokeLease> texture_set_source = {});
  std::vector<uint64_t> bake_sources_locked() const;
  bool bake_source_eligible_locked(uint64_t) const;
  std::vector<uint64_t> bake_cages_locked() const;
  bool bake_target_ready_locked() const;
  void queue_bake_locked(uint64_t, ObjectBakeSettings, AssetSource = {});
  void queue_clear_bake_locked(AssetSource = {});
  bool canonical_conversion_ready_locked() const;
  void queue_convert_bake_locked(AssetSource = {});
  void cancel_asset_work_locked();
  void cancel_background_work_locked();
  bool shape_target_ready_locked() const;
  void queue_shape_locked(ShapeKeyEdit,AssetSource expected={});
  bool sculpt_target_ready_locked() const;
  bool resolution_target_ready_locked() const;
  void queue_procedural_locked(ProceduralSculptOptions, AssetSource = {});
  void queue_resolution_locked(SculptResolutionOptions, AssetSource = {});
  void sculpt_settings_locked(Volume::SculptSettings, AssetSource = {});
  void queue_sculpt_mask_locked(std::optional<float>, AssetSource = {});
  bool rig_fit_source_matches_locked() const;
  bool rig_fit_command_enabled_locked(SpatialCommand) const;
  void rig_fit_command_locked(SpatialCommand);
  void begin_rig_fit_locked();
  void accept_rig_fit_locked();
  bool process_rig_fit_spatial_locked(const SpatialFrame &);
  bool skin_target_ready_locked() const;
  std::vector<uint64_t> skin_sources_locked(SkinAuthoringMode) const;
  bool selected_skin_ready_locked(SkinAuthoringMode) const;
  void queue_bind_skin_locked(SkinAuthoringOptions, AssetSource = {},
                              bool selected=false,std::vector<uint64_t> expected_selection={});
  void queue_voxel_sculpt_locked(float, AssetSource);
  void queue_triangle_remesh_locked(float, AssetSource);
};
} // namespace dome
