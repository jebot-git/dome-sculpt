from pathlib import Path
import subprocess

here=Path(__file__).resolve().parent
subprocess.run(['/usr/bin/python3',str(here/'build.py')],check=True)
args=['/usr/bin/bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/',
      '--bind',str(here),str(here),'--proc','/proc','--dev','/dev','--tmpfs','/tmp',
      '--tmpfs','/run/user','--clearenv','--setenv','PATH','/usr/bin:/bin',
      '--setenv','LD_LIBRARY_PATH','/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
      '--setenv','LIBGL_ALWAYS_SOFTWARE','1','--setenv','LP_NUM_THREADS','2',
      '--setenv','ASAN_OPTIONS','detect_leaks=1:halt_on_error=1:abort_on_error=1',
      '--setenv','UBSAN_OPTIONS','halt_on_error=1:print_stacktrace=1',
      '/usr/bin/python3',str(here/'run-native.py')]
raise SystemExit(subprocess.run(args).returncode)
