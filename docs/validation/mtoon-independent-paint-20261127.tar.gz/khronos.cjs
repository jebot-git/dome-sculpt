const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const validator=require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
(async()=>{
 const out=[];
 for(const filename of ['masked-standard','masked-editable','opaque-standard','opaque-editable','large-standard','large-editable','independent-alpha-editable']){
  const file=filename+'.glb';
  const bytes=fs.readFileSync(path.join(__dirname,'release','texture-set-independent-mtoon',file));
  const data=JSON.parse(bytes.toString('utf8',20,20+bytes.readUInt32LE(12)));
  const mat=data.materials[data.meshes[0].primitives[1].material];
  if(file.startsWith('independent-alpha')){
   assert(mat.extras.domeSculptNativeMaterial);
  }else{
   assert(mat.extensions.VRMC_materials_mtoon);
   assert(mat.extras.domeSculptMToonPaint.maximumLinearColorError<=.005);
   assert(mat.extras.domeSculptMToonPaint.maximumLinearShadeError<=.005);
   assert(mat.extras.domeSculptMToonPaint.maximumLinearEmissionError<=.005);
   assert(mat.extras.domeSculptMToonPaint.maximumAlphaError<=1/255);
  }
  const report=await validator.validateBytes(bytes,{uri:file,maxIssues:10000});
  assert.equal(report.issues.numErrors,0);
  console.log(file,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings',
              report.issues.messages.filter(m=>m.severity===1).map(m=>m.code));
  out.push({file,report});
 }
 fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results:out},null,2)+'\n');
})().catch(e=>{console.error(e);process.exitCode=1});
