from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parents[1]
destination = repo / "docs" / "validation"
stem = "retained-texture-set-posed-bake-20261127"
revision = subprocess.check_output(["git", "-C", repo, "rev-parse", "HEAD"], text=True).strip()
def read(name):
    return (work/name).read_text()
def json_at(name):
    return json.loads(read(name))
def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

profiles = {}
for profile, stage, expected in (("release", "selected", 12), ("asan", "current", 9)):
    log = read(f"{profile}-{stage}.log")
    assert f"100% tests passed, 0 tests failed out of {expected}" in log
    names = re.findall(r"Test #\d+: (\S+)\s+\.+\s+Passed", log)
    assert len(names)==expected
    checks = re.search(r"^PASS (\d+) posed retained Bake controls$",
                       read(f"{profile}/Testing/Temporary/LastTest.log"),re.M)
    assert checks and int(checks[1])==216
    profiles[profile] = {
        "registered_cases": sorted(names), "posed_bake_assertions": int(checks[1]),
        "native_test_sha256": sha(work/profile/"dome-sculpt-texture-set-source-export-test"),
    }

fixtures = Path("texture-set-retained-posed-bake")
exact = {}
for case in ("native-ray", "prepared-matching", "prepared-cage"):
    for name in ("before.dsculpt","baked.dsculpt","recall.dsculpt","posed-standard.glb","posed-editable.glb"):
        leaf = fixtures/case/name
        release, asan = (sha(work/profile/leaf) for profile in ("release","asan"))
        assert release==asan, str(leaf)
        exact[f"{case}/{name}"]=release
assert all(sha(work/"public-fixtures"/name)==exact[f"prepared-cage/{name}"]
           for name in ("recall.dsculpt","baked.dsculpt"))

wayland = json_at("wayland/report.json")
assert len(wayland["checks"])==15 and all(r["passed"] for r in wayland["checks"])
assert "Native Wayland client closes through normal worker and graphics/font release" in read("wayland.log")
xr = {}
for mode in ("software","arc"):
    whole = json_at(f"{mode}/report.json")
    assert len(whole["checks"])==19 and all(r["passed"] for r in whole["checks"])
    deliveries = {}
    for action in ("accept","cancel","focus"):
        result = json_at(f"{mode}/{action}.json")
        assert result["acquires"]==result["image_waits"]==result["releases"] and result["acquires"]>0
        if action=="focus":
            assert result["focus_losses"]==result["focus_regains"]==1
        assert ("Arc(tm) A770" if mode=="arc" else "llvmpipe") in result["gl_renderer"]
        deliveries[action] = {key:result[key] for key in ("gl_renderer","stereo_submissions","releases")}
    xr[mode]={"assertions":len(whole["checks"]),"cases":deliveries}
gltf = json_at("khronos.json")
assert len(gltf["reports"])==6 and all(r["report"]["issues"]["numErrors"]==r["report"]["issues"]["numWarnings"]==0
                                     for r in gltf["reports"])

members = ["receipt.py","check-profile.sh","run-public.py","xr-bake.py","wayland-bake.py",
           "release-current-build.log","asan-current-build.log","release-selected.log","asan-current.log",
           "release/Testing/Temporary/LastTest.log","asan/Testing/Temporary/LastTest.log",
           "khronos.cjs","khronos.json","khronos.log","wayland.log","wayland/report.json",
           "software.log","arc.log","software/report.json","arc/report.json",
           "public-fixtures/recall.dsculpt","public-fixtures/baked.dsculpt"]
members += [f"{mode}/{action}.json" for mode in ("software","arc") for action in ("accept","cancel","focus")]
members += [str(Path("release")/fixtures/case/"posed-standard.glb") for case in ("native-ray","prepared-matching","prepared-cage")]
archive = destination/(stem+".tar.gz")
with archive.open("wb") as output, gzip.GzipFile(filename="",fileobj=output,mode="wb",mtime=0) as compressed:
    with tarfile.open(fileobj=compressed,mode="w") as bundle:
        for name in sorted(members):
            item = bundle.gettarinfo(str(work/name),arcname=name)
            item.uid=item.gid=item.mtime=0
            item.uname=item.gname=""
            item.mode=0o644
            with (work/name).open("rb") as source:
                bundle.addfile(item,source)

report = {
    "revision":revision,
    "canonical_domed_revision":"acc2b70ae61dedec2a23727f67c60c0303d0f76f",
    "release_fltk":"/opt/fltk-vr/toolkit",
    "asan_fltk":"artifacts/sdk-20261126/toolkit-sanitize",
    "release_application_sha256":sha(work/"release/dome-sculpt"),
    "qualification":{
        "native_ray_ao":"Active morphs on donor and recipient, native N-only recipient",
        "prepared_matching":"Reflected affine active morphs and separate original paint and normal grids",
        "prepared_custom_cage":"Reflected active morphs with ordered cage placement and AO",
    },
    "native":profiles,
    "sanitizer_environment":{"ASAN_OPTIONS":"detect_leaks=1:halt_on_error=1",
                             "UBSAN_OPTIONS":"halt_on_error=1:print_stacktrace=1"},
    "nested_domed_wayland_assertions":len(wayland["checks"]),
    "synthetic_openxr":xr,
    "gltf_validator":{"version":gltf["version"],"files":6,"errors":0,"warnings":0},
    "identical_release_asan_files_sha256":exact,
    "physical_headset_tested":False,
    "archive":{"path":archive.name,"sha256":sha(archive),"members_sha256":{name:sha(work/name) for name in sorted(members)}},
}
(destination/(stem+".json")).write_text(json.dumps(report,indent=2)+"\n")
