const fs = require('fs');
const path = require('path');
const validator = require(path.join(__dirname, '../hdr-khronos-validation-20261126/module/package'));
(async () => {
    const reports = [];
    const root = path.join(__dirname, 'release/texture-set-retained-posed-bake');
    for (const name of ['native-ray', 'prepared-matching', 'prepared-cage']) {
        for (const file of ['posed-standard.glb', 'posed-editable.glb']) {
            const uri = name + '/' + file;
            const report = await validator.validateBytes(fs.readFileSync(path.join(root,uri)), {uri});
            reports.push({uri,report});
            console.log(uri,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings');
        }
    }
    fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),reports},null,2)+'\n');
    if (reports.some(item => item.report.issues.numErrors)) process.exitCode = 1;
})().catch(error => {console.error(error);process.exitCode = 1});
