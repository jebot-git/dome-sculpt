import pathlib,subprocess,sys
root=pathlib.Path('/home/blux/de-xr/dome-sculpt/artifacts');profile=sys.argv[1];out=root/'preview-recovery-focused-20261111'/profile;runner=root/'preview-recovery-run.py';items=[('dome-sculpt-render-buffers-test',[]),('dome-sculpt-render-direct-upload-test',['direct',str(out/'direct-upload')]),('dome-sculpt-source-extra-uv-render-test',[]),('dome-sculpt-normal-frame-render-test',[]),('dome-sculpt-source-color-render-test',[str(out/'source-color')]),('dome-sculpt-affine-held-render-test',[]),('dome-sculpt-affine-document-render-test',[])];fail=[]
for target,args in items:
 status=subprocess.run([sys.executable,str(runner),profile,'software',target,*args]).returncode
 if status:fail.append(target)
print('FAILED',fail);sys.exit(bool(fail))
