import subprocess,sys
profile=sys.argv[1];runner='/home/blux/de-xr/dome-sculpt/artifacts/preview-recovery-run.py';items=[('dome-sculpt-document-render-buffers-test','software-final-doc',[]),('dome-sculpt-document-render-capacity-test','software-original-capacity',[]),('dome-sculpt-document-render-capacity-test','software-large-buffer',['--large-buffer'])];fail=[]
for target,mode,args in items:
 result=subprocess.run([sys.executable,runner,profile,mode,target,*args]).returncode
 if result:fail.append(mode)
print('FINAL DOC SUITE',profile,'FAILED',fail);sys.exit(bool(fail))
