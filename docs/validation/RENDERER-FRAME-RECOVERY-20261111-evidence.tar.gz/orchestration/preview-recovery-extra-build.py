import pathlib,subprocess,shlex,json,concurrent.futures,hashlib,sys
project=pathlib.Path('/home/blux/de-xr/dome-sculpt');profile=sys.argv[1];src=project/'artifacts/preview-renderer-recovery-20261111';old=project/'artifacts/plain-gpu-preview-20261111';base=project/'artifacts/plain-gpu-preview-build-20261111'/profile;out=project/'artifacts/preview-recovery-focused-20261111'/profile
cmds=json.loads((base/'compile_commands.json').read_text());records=[]
targets=sys.argv[2:] or ['dome-sculpt-current-paint-preview-native-test','dome-sculpt-current-paint-preview-gpu-test','dome-sculpt-render-buffers-test']
def run(a,log):
 with (out/log).open('w')as f:
  f.write(shlex.join(a)+'\n');f.flush();r=subprocess.run(a,cwd=out,stdout=f,stderr=subprocess.STDOUT)
 if r.returncode:raise RuntimeError(log)
 return {'argv':a,'log':log,'exit':r.returncode}
def build(target):
 c=next(c for c in cmds if f'CMakeFiles/{target}.dir/'in c.get('output',''));argv=[a.replace(str(old),str(src))for a in shlex.split(c['command'])];name=target+'.o';argv[argv.index('-o')+1]=str(out/name);argv.insert(1,'-I'+str(src/'src'));r=run(argv,name+'.log');return target,name,r
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as e:
 jobs=[e.submit(build,t)for t in targets]
 for job in jobs:
  t,name,r=job.result();records.append(r)
  raw=subprocess.check_output(['ninja','-C',str(base),'-t','commands',t],text=True).splitlines()[-1];args=shlex.split(raw)[2:-2];a=[]
  for x in args:
   if x.startswith('-Wl,--dependency-file='):continue
   if x.endswith('.cpp.o'):x=str(out/name)
   elif x==t:x=str(out/t)
   elif x.endswith('.a')and not x.startswith('/'):x=str(out/x)if(out/x).exists()else str(base/x)
   a.append(x)
  
  if t=='dome-sculpt-document-render-buffers-test':a+=['-Wl,--wrap=glBufferSubData','-Wl,--wrap=glCopyBufferSubData','-Wl,--wrap=glDrawArrays']
  records.append(run(a,t+'.link.log'))
(out/('extra-build-'+str(len(targets))+'.json')).write_text(json.dumps({'profile':profile,'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=src,text=True).strip(),'commands':records,'elf_sha256':{t:hashlib.sha256((out/t).read_bytes()).hexdigest()for t in targets}},indent=2)+'\n')
print('EXTRA BUILD PASS',profile,*targets)
