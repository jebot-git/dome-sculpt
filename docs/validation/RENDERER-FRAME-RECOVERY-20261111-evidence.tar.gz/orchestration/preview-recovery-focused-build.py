import concurrent.futures,hashlib,json,pathlib,shlex,shutil,subprocess,sys,time
project=pathlib.Path('/home/blux/de-xr/dome-sculpt')
source=project/'artifacts/preview-renderer-recovery-20261111'
old=project/'artifacts/plain-gpu-preview-20261111'
profile=sys.argv[1]
provider=project/'artifacts/plain-gpu-preview-build-20261111'/profile
out=project/'artifacts/preview-recovery-focused-20261111'/profile
out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=source,text=True).strip()
def run(argv,log,cwd=out):
 with open(out/log,'w') as f:
  f.write(shlex.join(argv)+'\n');f.flush();p=subprocess.run(argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(f'{log} failed {p.returncode}')
 return {'argv':argv,'log':log,'exit':p.returncode}
assert not git('status','--porcelain')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=old,text=True).strip().startswith('f47348eb')
changes=git('diff','--name-only','f47348eb..HEAD','--','include','src','third_party').splitlines()
assert set(changes)==set(['src/current-paint-preview.cpp','src/polygon-surface-gpu.hpp','src/render-current-paint-preview.hpp','src/render-paint-overlay.hpp','src/render-source-pack.hpp','src/render-store-ledger.hpp','src/render.cpp','src/sculpt-gpu-arena-layout.hpp','src/sculpt-gpu-arena.hpp']),changes
paths=git('ls-files','include','src','third_party').splitlines()
# Authenticate actual regular files against source commits rather than trusting paths/build labels.
for tree,commit in ((old,'f47348eb'),(source,'HEAD')):
 for name in subprocess.check_output(['git','ls-tree','-r','--name-only',commit,'--','include','src','third_party'],cwd=source,text=True).splitlines():
  p=tree/name
  expected=subprocess.check_output(['git','rev-parse',commit+':'+name],cwd=source,text=True).strip()
  actual=subprocess.check_output(['git','hash-object',str(p)],cwd=source,text=True).strip()
  assert expected==actual,(str(p),expected,actual)
commands=json.loads((provider/'compile_commands.json').read_text())
core=[c for c in commands if 'CMakeFiles/dome-sculpt-core.dir/' in c.get('output','')]
record={'source':git('rev-parse','HEAD'),'provider_source':'f47348eb12b573799880f2bb8fb4946b4aa9731e','profile':profile,'changed_source':changes,'core_provider_count':len(core),'providers':{},'commands':[],'scope':'Focused own whole-TU replacement only. Fresh whole composed build remains required.'}
for p in sorted(provider.glob('*.a')):
 record['providers'][str(p)]={'sha256':sha(p),'members':subprocess.check_output(['ar','t',str(p)],text=True).splitlines()}
for name in ['libdome-sculpt-core.a','libdome-sculpt-render.a']:shutil.copyfile(provider/name,out/name)
def compile_job(original,new,output):
 c=next(c for c in commands if c['file']==str(old/original))
 argv=shlex.split(c['command']);argv=[a.replace(str(old),str(source)) for a in argv]
 argv[argv.index('-o')+1]=str(out/output);argv[-1]=str(source/new)
 return run(argv,output+'.log')
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
 jobs=[executor.submit(compile_job,'src/render.cpp','src/render.cpp','render.cpp.o'),executor.submit(compile_job,'src/current-paint-preview.cpp','src/current-paint-preview.cpp','current-paint-preview.cpp.o')]
 for j in jobs:record['commands'].append(j.result())
for archive,member in [('libdome-sculpt-core.a','current-paint-preview.cpp.o'),('libdome-sculpt-render.a','render.cpp.o')]:
 run(['ar','r',str(out/archive),str(out/member)],archive+'.replace.log')
 oldmembers=subprocess.check_output(['ar','t',str(provider/archive)],text=True).splitlines();newmembers=subprocess.check_output(['ar','t',str(out/archive)],text=True).splitlines();assert oldmembers==newmembers
 for m in oldmembers:
  if m==member:continue
  a=subprocess.check_output(['ar','p',str(provider/archive),m]);b=subprocess.check_output(['ar','p',str(out/archive),m]);assert a==b,m
 record['providers'][str(out/archive)]={'sha256':sha(out/archive),'replaced':member,'unchanged_members':len(oldmembers)-1}
record['commands'].append(compile_job('tests/current-paint-preview-gpu.cpp','tests/renderer-recovery.cpp','renderer-recovery.cpp.o'))
raw=subprocess.check_output(['ninja','-C',str(provider),'-t','commands','dome-sculpt-current-paint-preview-gpu-test'],text=True).splitlines()[-1]
argv=shlex.split(raw);argv=argv[2:-2]
clean=[]
for a in argv:
 if a.startswith('-Wl,--wrap=') or a.startswith('-Wl,--dependency-file='):continue
 if a.endswith('current-paint-preview-gpu.cpp.o'):a=str(out/'renderer-recovery.cpp.o')
 elif a=='dome-sculpt-current-paint-preview-gpu-test':a=str(out/'dome-sculpt-renderer-recovery-test')
 elif a.endswith('.a') and not a.startswith('/'):
  a=str(out/a) if (out/a).exists() else str(provider/a)
 clean.append(a)
wraps='GenBuffers GenTextures GenSamplers GenVertexArrays BufferData TexBuffer TexImage2D GenerateMipmap FenceSync ClientWaitSync DrawElements MultiDrawElementsBaseVertex DrawArrays ReadPixels GetTexImage GetBufferSubData Finish'.split()
clean+=['-Wl,--wrap=gl'+v for v in wraps]
record['commands'].append(run(clean,'recovery.link.log'))
record['elf']={'path':str(out/'dome-sculpt-renderer-recovery-test'),'sha256':sha(out/'dome-sculpt-renderer-recovery-test')}
record['source_end']=git('rev-parse','HEAD');assert record['source']==record['source_end'] and not git('status','--porcelain')
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'profile':profile,'source':record['source'],'elf':record['elf'],'owning_whole_TUs':3,'matched_unchanged_core_members':record['providers'][str(out/'libdome-sculpt-core.a')]['unchanged_members']},indent=2))
