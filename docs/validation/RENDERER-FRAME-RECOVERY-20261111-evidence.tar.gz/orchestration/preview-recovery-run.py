import fcntl,hashlib,json,os,pathlib,re,resource,signal,subprocess,sys,time
root=pathlib.Path('/home/blux/de-xr/dome-sculpt');src=root/'artifacts/preview-renderer-recovery-20261111';profile=sys.argv[1];mode=sys.argv[2];target=sys.argv[3]if len(sys.argv)>3 else'dome-sculpt-renderer-recovery-test';out=root/'artifacts/preview-recovery-focused-20261111'/profile;stem=target+'-'+mode;extra=sys.argv[4:];cmd=[str(out/target),*extra];hardware=mode=='arc'
if hardware and '--hardware'not in extra:cmd.append('--hardware')
env=os.environ.copy()
for key in list(env):
 if key in ['DRI_PRIME','LIBGL_ALWAYS_SOFTWARE','GALLIUM_DRIVER','MESA_LOADER_DRIVER_OVERRIDE','MESA_VK_DEVICE_SELECT','VK_ICD_FILENAMES','LSAN_OPTIONS','ASAN_OPTIONS','UBSAN_OPTIONS']:env.pop(key,None)
env.update(LD_LIBRARY_PATH='/usr/lib64',LP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2')
if hardware:env['DRI_PRIME']='pci-0000_03_00_0'
else:env['LIBGL_ALWAYS_SOFTWARE']='1'
if profile=='sanitize':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
lease=None
if hardware:
 lease=open('/tmp/dome-sculpt-arc-device.lock','a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=src,text=True).strip()
capacity=target=='dome-sculpt-document-render-capacity-test';rss_limit=(4 if profile=='release'else 8)*1024**3 if capacity else None;deadline=240 if capacity else(60 if hardware else 180);rss_guard=False
commit=git('rev-parse','HEAD');assert not git('status','--porcelain')
elf=sha(cmd[0]);maps=set();fds=set();samples=0;start=time.monotonic();killed=False
with (out/(stem+'.log')).open('w')as log:
 p=subprocess.Popen(cmd,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll()is None:
  try:
   for line in pathlib.Path(f'/proc/{p.pid}/maps').read_text().splitlines():
    parts=line.split(None,5)
    if len(parts)==6 and parts[5].startswith('/') and not parts[5].endswith('(deleted)'):maps.add(parts[5])
   for fd in pathlib.Path(f'/proc/{p.pid}/fd').iterdir():
    try:
     name=os.readlink(fd)
     if name.startswith('/dev/dri/'):fds.add(name)
    except OSError:pass
   samples+=1
  except OSError:pass
  if rss_limit:
   try:
    line=next(v for v in pathlib.Path(f'/proc/{p.pid}/status').read_text().splitlines()if v.startswith('VmRSS:'));rss=int(line.split()[1])*1024
    if rss>rss_limit:os.killpg(p.pid,signal.SIGKILL);rss_guard=True;break
   except (OSError,StopIteration):pass
  if time.monotonic()-start>deadline:os.killpg(p.pid,signal.SIGKILL);killed=True;break
  time.sleep(.01)
 status=p.wait()
elapsed=time.monotonic()-start
if lease:fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
text=(out/(stem+'.log')).read_text();record={'source':commit,'source_end':git('rev-parse','HEAD'),'source_drift':git('status','--porcelain'),'profile':profile,'mode':mode,'argv':cmd,'environment':{k:env.get(k)for k in ['LD_LIBRARY_PATH','DRI_PRIME','LIBGL_ALWAYS_SOFTWARE','LP_NUM_THREADS','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']},'exit':status,'external_timeout':killed,'chosen_timeout_seconds':deadline,'chosen_rss_limit_bytes':rss_limit,'rss_guard_fired':rss_guard,'seconds':elapsed,'maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'elf_sha256':elf,'elf_end_sha256':sha(cmd[0]),'log_sha256':sha(out/(stem+'.log')),'live_map_samples':samples,'actual_drm_fds':sorted(fds),'live_providers':{m:sha(m)for m in sorted(maps)if pathlib.Path(m).is_file()},'pass_lines':re.findall(r'^PASS .+$',text,re.M)[-4:]}
if rss_limit and record['maxrss_kib']*1024>rss_limit:record['rss_guard_fired']=True
record['drift']=record['source']!=record['source_end']or bool(record['source_drift'])or record['elf_sha256']!=record['elf_end_sha256'];(out/(stem+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['source','profile','mode','exit','external_timeout','seconds','maxrss_kib','actual_drm_fds','drift','pass_lines']},indent=2))
if record['drift']or status or record['rss_guard_fired']:sys.exit(1)
