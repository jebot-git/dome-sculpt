#include "dome/bake-authoring.hpp"
#include "dome/bake-recipe.hpp"
#include "dome/source-placement.hpp"
#include "dome/texture-sets.hpp"
#include <iostream>
#include <nlohmann/json.hpp>

using namespace dome;
int main(int argc,char **argv)try {
  if(argc!=2)throw std::invalid_argument("Expected the checked affine source project");
  auto scene=Scene::load(argv[1]);
  const auto original=scene.encode();
  const auto active=active_texture_set(scene.active());
  const auto recipe=active.bake_recipe;
  if(!recipe||!recipe->cage||!scene.has_affine_placement(scene.active().id))
    throw std::runtime_error("Expected the genuine affine donor, target and cage recipe");
  auto shifted=scene.snapshot();
  for(const auto &object:scene.objects()){
    auto matrix=object.affine_edit->matrix().matrix();
    matrix[12]+=4194304;matrix[13]-=4194304;matrix[14]+=2097152;
    shifted.object(object.id).affine_edit=std::make_shared<const NativeAffineEdit>(AffineTransform(matrix));
  }
  auto baseline=scene.snapshot();
  const auto a=bake_object(baseline,recipe->source.object,recipe->settings);
  const auto b=bake_object(shifted,recipe->source.object,recipe->settings);
  const auto first=active_texture_set(baseline.active()).painted->baked();
  const auto second=active_texture_set(shifted.active()).painted->baked();
  if(!first||!second||a.projected!=b.projected||a.missed!=b.missed||a.rays!=b.rays||
     first->coverage!=second->coverage||first->maps.color.rgba!=second->maps.color.rgba||
     first->maps.metal_rough.rgba!=second->maps.metal_rough.rgba||
     first->maps.normal.rgba!=second->maps.normal.rgba||
     first->maps.emission.rgba!=second->maps.emission.rgba||scene.encode()!=original)
    throw std::runtime_error("Common translation changed the affine Bake");
  std::cout<<"PASS "<<a.projected<<" projected texels and "<<a.rays
           <<" projection and AO rays retain exact raster bytes after common 4,194 km translation\n";
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
