"""Prepared CPU/native producer and direct-loader gate; root review required."""
import argparse,fcntl,hashlib,importlib.util,json,os,re,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parents[1]
EXPECTED_PLAN='074cdd83fe5408ef08234c94ba2b8ca336ed78d33b8fe987d4f39f5996a11bd0'
CONTRACT=R/'artifacts/guard87-validation-fresh-v2-20261115'
sys.path.insert(0,str(CONTRACT));from runtime_contract import read_runtime,merge_pins
M=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py'
spec=importlib.util.spec_from_file_location('advanced_public_native_monitor',M);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def drift(pins):return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def add(pins,p,h=None):
 p=str(p);v=sha(p);assert h is None or v==h,('Input drift',p);assert p not in pins or pins[p]==v,('Conflicting expected pin',p);pins[p]=v
def main(a):
 assert sha(P/'plan.json')==EXPECTED_PLAN
 plan=json.loads((P/'plan.json').read_text())
 if not a.execute:print(json.dumps(plan,indent=2));return 0
 assert a.reviewed_plan==EXPECTED_PLAN and a.output_tag and '/'not in a.output_tag
 out=P/a.output_tag;out.mkdir(exist_ok=False)
 linked=json.loads(Path(plan['link_status']).read_text());assert linked['state']=='terminal'and linked['exit']==0 and not linked['input_drift']and linked['source']==plan['source']
 pins=json.loads(Path(plan['link_inputs']).read_text());merge_pins(pins,read_runtime()['pins'])
 for k,h in plan['prerequisites'].items():add(pins,k,h)
 for k in [Path(__file__).resolve(),M,P/'plan.json',CONTRACT/'runtime_contract.py',CONTRACT/'runtime-preflight.json']:add(pins,k)
 prior_loader=json.loads(Path(plan['old_loader_status']).read_text());assert prior_loader['state']=='terminal'and prior_loader['exit']==0 and not prior_loader['input_drift'];merge_pins(pins,prior_loader['pins'])
 prior_native=json.loads(Path(plan['old_native_status']).read_text());assert prior_native['state']=='terminal'and prior_native['exit']==0 and not prior_native['input_drift']
 for product in plan['products'].values():add(pins,product['path'],product['sha256'])
 assert not drift(pins)
 state={'state':'preparing','exit':1,'driver_pid':os.getpid(),'source':plan['source'],'scope_tuple':plan['scope_tuple'],'scope':plan['scope'],'steps':[],'providers':{},'outputs':{}};lease=None
 env={k:v for k,v in os.environ.items()if not k.startswith(('DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for k in ['LD_PRELOAD','DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','__EGL_VENDOR_LIBRARY_FILENAMES']:env.pop(k,None)
 env.update(LD_LIBRARY_PATH=str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',LP_NUM_THREADS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',XR_RUNTIME_JSON=str(out/'physical-xr-blocked.json'))
 for key,leaf in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime')]:env[key]=str(out/leaf);Path(env[key]).mkdir(mode=0o700)
 state['environment']=env
 def save():write(out/'status.json',state)
 def run(name,argv,expected=0,loader=False):
  def progress(row):state['live']={'name':name,**row};save()
  row=monitor.run(argv,cwd=out,env=env,log=out/(name+'.log'),timeout=30 if loader else 900,max_rss=4*1024**3,progress=progress)
  row.update(name=name,log_sha256=sha(out/(name+'.log')));state['steps'].append(row);state.pop('live',None);save();print(name,row.get('exit'),flush=True)
  assert row.get('exit')==expected and 'error'not in row and not row['signals'],(name,row)
  return(out/(name+'.log')).read_text()
 inspector=plan['products']['native']['path'];font=plan['products']['font']['path']
 try:
  lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  st=os.fstat(lease.fileno());state['lease']={'owner_identity':monitor.identity(os.getpid()),'acquired_epoch':time.time(),'inode':st.st_ino,'dev':st.st_dev,'before_any_ldd_or_built_product':True};save()
  for role,product in plan['products'].items():
   text=run('ldd-'+role,['/usr/bin/ldd',product['path']],loader=True);assert 'not found'not in text
   providers=[]
   for literal in re.findall(r'(/[^\s()]+)',text):
    if not Path(literal).is_file():continue
    resolved=str(Path(literal).resolve());want=pins.get(literal,pins.get(resolved));assert want is not None and sha(literal)==want,('Actual loader provider outside expected current closure',literal,resolved)
    providers.append({'literal':literal,'resolved':resolved,'sha256':want})
   state['providers'][role]=providers
   if role=='app':
    reference=json.loads(Path(plan['expected_App_providers']).read_text());expected={x['loader_path']:x['sha256']for x in reference['rows']};actual={x['literal']:x['sha256']for x in providers};assert len(expected)==72 and actual==expected,('App actual72provider closure differs',actual,expected)
  version=run('version',[plan['products']['app']['path'],'--version'],loader=True);assert version==Path(plan['version_stdout_reference']).read_text()
  write(out/'inputs-before.json',pins)
  text=run('native17',[inspector,str(out/'native17')]);assert plan['unchanged_native17_exact_check_count']==263495 and re.search(r'^PASS 263495 advanced source checks$',text,re.M)
  names=[a+'-'+b+'-'+c+'-'+d for a in ['mt0','mt1']for b in ['rest','posed']for c in ['seam','shared']for d in ['raster','retained']]+['mt1-posed-seam-retained-three-edits'];state['native17_ordered_pairs']={}
  for name in names:
   a=out/'native17'/(name+'.dsculpt');b=out/'native17'/(name+'-ordered.dsculpt');assert a.read_bytes()==b.read_bytes();state['native17_ordered_pairs'][name]={'expected_sha256':sha(a),'ordered_sha256':sha(b)}
  assert len(state['native17_ordered_pairs'])==17
  text=run('source-use-producer',[inspector,'--advanced-public-fixtures',str(out/'source-use')]);assert re.search(r'PASS [1-9][0-9]* advanced public normal capsules',text)
  suite=json.loads((out/'source-use/manifest.json').read_text());assert suite['kind']=='advanced-prepared-normal-public-suite'and suite['case_count']==8 and suite['new_targets']==0 and not suite['UI_execution']and set(suite['families'])=={'raster','retained'}
  counts={'source_use_positive':0,'source_use_wrong_Original':0,'uv_creation_positive':0,'uv_creation_wrong_method':0};families={}
  for family,relative in suite['families'].items():
   root=out/'source-use';mf=root/relative;group=json.loads(mf.read_text());assert group['kind']=='advanced-prepared-normal-public-family'and len(group['cases'])==4 and group['existing_native17_unchanged'];families[family]=mf
   for name,relative_case in group['cases'].items():
    case=mf.parent/relative_case;m=json.loads(case.read_text());assert m['source_uv_applied']and m['all_three_objects_retained']and m['source_choice_initial']==m['original_source']and m['source_choice_required']==m['prepared_source']and m['genuine_first_bake_source']==m['original_source']
    for route in ['desktop','xr']:
     files=m['routes'][route];expected=case.parent/files['expected']
     for phase,file in [('accepted',expected),('undone',case.parent/m['before']),('redone',expected),('reopened',expected)]:
      value=json.loads(run(name+'-'+route+'-'+phase,[inspector,'--verify-advanced-public',str(case),route,phase,str(file)]));assert value['verified'];counts['source_use_positive']+=1
     text=run(name+'-'+route+'-wrong-original',[inspector,'--verify-advanced-public',str(case),route,'accepted',str(case.parent/files['wrong_original'])],expected=1);assert 'FAIL Actual advanced UI must match the prepared endpoint and reject independently baked wrong Original' in text;counts['source_use_wrong_Original']+=1
  text=run('uv-creation-producer',[inspector,'--advanced-uv-fixtures',str(out/'uv-creation')]);assert re.search(r'PASS [1-9][0-9]* advanced public UV capsules',text)
  suite=json.loads((out/'uv-creation/manifest.json').read_text());assert suite['kind']=='advanced-normal-uv-authoring-suite'and len(suite['cases'])==8 and suite['new_targets']==0 and not suite['UI_execution']
  for name,relative_case in suite['cases'].items():
   case=out/'uv-creation'/relative_case;m=json.loads(case.read_text());assert not m['UI_execution']
   for route in ['desktop','xr']:
    files=m['routes'][route];expected=case.parent/files['expected']
    for phase,file in [('accepted',expected),('undone',case.parent/m['before']),('redone',expected),('reopened',expected)]:
     value=json.loads(run('uv-'+name+'-'+route+'-'+phase,[inspector,'--verify-advanced-uv',str(case),route,phase,str(file)]));assert value['verified'];counts['uv_creation_positive']+=1
    text=run('uv-'+name+'-'+route+'-wrong-method',[inspector,'--verify-advanced-uv',str(case),route,'accepted',str(case.parent/files['wrong_method'])],expected=1);assert 'FAIL Actual public UV creation matches exact native endpoint and rejects wrong-method operation' in text;counts['uv_creation_wrong_method']+=1
  assert counts=={'source_use_positive':64,'source_use_wrong_Original':16,'uv_creation_positive':64,'uv_creation_wrong_method':16}
  default=out/'titles-default.json';run('font-default',[font,str(default)]);d=json.loads(default.read_text());assert d==json.loads(Path(plan['font_default_reference']).read_text())and set(d['masks'])=={'Dome Sculpt','Objects','Mesh tools','Mesh baking'}
  for family,mf in families.items():
   group=json.loads(mf.read_text());requests=mf.parent/group['label_requests'];labels=json.loads(requests.read_text());assert len(labels)==22 and len({r['key']for r in labels})==22
   target=out/('titles-'+family+'.json');run('font-'+family,[font,str(target),str(requests)]);e=json.loads(target.read_text());assert e['font_file']==d['font_file']and e['font_pixels']==d['font_pixels']==16 and e['unit']==d['unit']==1 and e['width']==e['height']==640 and e['opacity']==255 and set(e['masks'])==set(d['masks'])|{x['key']for x in labels}
   for key,v in d['masks'].items():assert e['masks'][key]==v
   for label in labels:assert e['masks'][label['key']]['ink']and all(0<=x<640 and 0<=y<640 for x,y in e['masks'][label['key']]['ink'])
  add(pins,d['font_file']);state['summary']={'native17':17,**counts,'source_use_cases':8,'UV_creation_cases':8,'normal_bound_unchanged':.035,'source_use_negative_normal_bound_unchanged':.05,'font_default4_exact':True,'font_families':2,'font_labels_each':22,'App_provider_count':len(state['providers']['app']),'public_actions_executed':False}
  state['outputs']={str(p):sha(p)for p in out.rglob('*')if p.is_file()and p.suffix in ['.dsculpt','.json']and p.name not in ['status.json','inputs-before.json','inputs-final.json']};state['exit']=0
 except BaseException as error:state['error']=repr(error)
 finally:
  state['input_drift']=drift(pins);state['exit']=state['exit']or int(bool(state['input_drift']));write(out/'inputs-final.json',pins)
  state['remaining_owned']=[v for row in state['steps']for v in row.get('known_processes',[])if monitor.alive(v)];state['exit']=state['exit']or int(bool(state['remaining_owned']))
  if lease:
   if 'lease'in state:state['lease']['released_epoch']=time.time()
   fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
  state['state']='terminal';save();print('TERMINAL',state['exit'],state.get('error'),flush=True)
 return state['exit']
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--reviewed-plan');p.add_argument('--output-tag');raise SystemExit(main(p.parse_args()))
