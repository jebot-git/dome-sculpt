from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent.parent / "mtoon-static-normal-uv-20261127"
source = root / "combined-source"
out = root / "combined-release"
out.mkdir(exist_ok=True)
build = out / "build"
sdk = "/opt/fltk-vr/toolkit"
bitmap = "/opt/fltk-vr/bdf-runtime"
start = time.monotonic()
def git(*args):
    return subprocess.check_output(["git", "-C", source, *args], text=True).strip()
state = {"candidate":git("rev-parse", "HEAD"),"terminal":False,
         "invocation":os.environ.get("INVOCATION_ID")}
def record(**fields):
    state.update(fields, elapsed_seconds=round(time.monotonic()-start, 3))
    temp = out / "status.tmp"
    temp.write_text(json.dumps(state, indent=2)+"\n")
    temp.replace(out / "status.json")
def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()
settings = {"PATH":"/usr/bin:/bin", "PKG_CONFIG_PATH":f"{bitmap}/lib/pkgconfig:/usr/lib64/pkgconfig",
            "LD_LIBRARY_PATH":f"{sdk}/lib:{bitmap}/lib:/usr/lib64","LIBGL_ALWAYS_SOFTWARE":"1",
            "LP_NUM_THREADS":"2","OPENBLAS_NUM_THREADS":"2","OMP_NUM_THREADS":"2"}
for variable, name in [("HOME","home"),("XDG_CACHE_HOME","cache"),("XDG_CONFIG_HOME","config"),
                       ("XDG_DATA_HOME","data"),("XDG_RUNTIME_DIR","runtime"),("XDG_STATE_HOME","state")]:
    directory = out / "private" / name
    directory.mkdir(parents=True, mode=0o700, exist_ok=True)
    settings[variable] = str(directory)
prefix = ["bwrap","--die-with-parent","--unshare-all","--ro-bind","/","/",
          "--bind",out,out,"--proc","/proc","--dev","/dev","--tmpfs","/tmp",
          "--tmpfs","/run/user","--clearenv"]
for variable, value in settings.items():
    prefix.extend(["--setenv",variable,value])
def run(command, name, timeout, check=True):
    with (out/name).open("w") as log:
        return subprocess.run([*prefix,*command],cwd=out,stdout=log,stderr=subprocess.STDOUT,
                              timeout=timeout,check=check).returncode
retries = Path(__file__).resolve().parent
command = [*prefix, 'ctest','--test-dir',build,'-R','^resolution-quality-host-aggregate$', '--repeat','until-fail:3','--output-on-failure']
with (retries/'older-exact-retry.log').open('w') as log:
    result=subprocess.run(command,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=560)
raise SystemExit(result.returncode)
