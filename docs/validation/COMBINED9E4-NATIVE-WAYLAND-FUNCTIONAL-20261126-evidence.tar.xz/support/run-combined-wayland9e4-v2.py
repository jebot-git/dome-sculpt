"""Exact combined App through current canonical nested DomeD; no active session changes."""
from pathlib import Path
import fcntl,hashlib,importlib.util,json,os,re,subprocess,sys,time,traceback
sys.dont_write_bytecode=True
out=Path(__file__).resolve().parent;root=out.parent.parent
build=root/'artifacts/production-hdr-combined-release-20261126'
source=Path('/home/blux/de-xr/dome-sculpt/artifacts/production-hdr-integration-20261126')
reference=out/'wayland-reference';case=out/'combined-wayland9e4-v2'
case.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
monitor=load('wayland_owned_monitor',out/'owned-monitor.py');providers=load('wayland_provider_witness',out/'provider-witness-v4.py')
app=build/'dome-sculpt';compositor=reference/'dome-compositor';observer=reference/'device-auth-native-wayland.so';scenario=reference/'dome-menu-native-gpu-v3.py'
review=json.loads((build/'build-review.json').read_text());status=json.loads((build/'build-status.json').read_text())
assert status['terminal']and status['exit']==0 and review['source']=='9e4f79f6c37ac4c4ca52cc6a0c0f288b60454d55'
expected_app=next(v['sha256']for v in review['outputs']if Path(v['path']).name=='dome-sculpt');assert sha(app)==expected_app
comp_build=json.loads((reference/'compositor-build-status.json').read_text());assert comp_build['exit']==0 and not comp_build['source_drift']and sha(compositor)==comp_build['output_sha256']
assert json.loads((reference/'observer-build.json').read_text())['exit']==0
pins={}
def pin(p):
    p=Path(p)
    if p.is_file():pins[str(p.resolve())]=sha(p)
for p in [app,compositor,observer,scenario,Path(__file__),out/'owned-monitor.py',out/'provider-witness-v4.py',out/'private-bin-v3/Xvfb',out/'private-x11/usr/bin/Xvfb',out/'private-x11/usr/bin/xkbcomp',build/'build-review.json',build/'build-status.json',reference/'compositor-build-status.json',reference/'current-compositor-artifact.json',reference/'observer-build.json','/usr/bin/python3.14','/usr/bin/bwrap','/usr/bin/dbus-run-session','/usr/bin/dbus-daemon','/usr/share/vulkan/icd.d/intel_icd.x86_64.json','/usr/lib64/libvulkan_intel.so']:
    pin(p)
for directory in [Path('/usr/lib64'),Path('/usr/lib64/dri'),Path('/opt/fltk-vr/toolkit/lib'),Path('/opt/fltk-vr/bdf-runtime/lib'),out/'private-x11/usr/lib64']:
    for p in (directory.rglob('*.so*')if directory==Path('/usr/lib64')else directory.glob('*')):
        if p.is_file():
            try:
                with p.open('rb')as f:
                    if f.read(4)==b'\x7fELF':pin(p)
            except PermissionError:pass
for directory in [out/'private-python',Path('/usr/lib/python3.14/site-packages/Xlib'),Path('/usr/lib64/python3.14/site-packages/PIL')]:
    for p in directory.rglob('*'):
        if p.is_file()and p.suffix in ['.py','.so']:pin(p)
for p in subprocess.check_output(['git','ls-files','-z'],cwd=source,text=True).split('\0'):
    if p:pin(source/p)
for name,digest in json.loads((reference/'compositor-source-before.json').read_text()).items():
    path=Path('/home/blux/de-xr/DomeD')/name;assert sha(path)==digest;pin(path)
env={k:v for k,v in os.environ.items()if not k.startswith(('LD_','DOME_','MESA_','LIBGL_','GALLIUM_','DRI_','DYLD_'))}
for k in ['DISPLAY','WAYLAND_DISPLAY','WAYLAND_SOCKET','DBUS_SESSION_BUS_ADDRESS','XR_RUNTIME_JSON','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS']:env.pop(k,None)
settings={'PATH':str(out/'private-bin-v3')+':/usr/local/bin:/usr/bin','PYTHONPATH':str(out/'private-python'),'PYTHONDONTWRITEBYTECODE':'1','LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:'+str(out/'private-x11/usr/lib64')+':/usr/lib64','DOME_SCULPT_TEST_ROOT':str(source),'DOME_SCULPT_TEST_BUILD':str(build),'DOME_COMPOSITOR':str(compositor),'DOME_WAYLAND_TEST_OUTPUT':str(case/'workflow'),'DOME_WAYLAND_TEST_OBSERVER':str(observer),'DOME_TEST_VULKAN_ICD':'/usr/share/vulkan/icd.d/intel_icd.x86_64.json','DOME_TEST_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:'+str(out/'private-x11/usr/lib64')+':/usr/lib64','DOME_START_XR':'0','DOME_START_TRAY':'0','DOME_START_IME':'0','DOME_SESSION_RESTORE':'0','XR_RUNTIME_JSON':str(case/'no-physical-runtime.json'),'LP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','OMP_NUM_THREADS':'2'}
bus_home=case/'private-bus-home'
for key,leaf in [('XDG_RUNTIME_DIR','runtime'),('XDG_CONFIG_HOME','config'),('XDG_STATE_HOME','state'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data')]:
    directory=bus_home/leaf;directory.mkdir(parents=True,mode=0o700);settings[key]=str(directory)
env.update(settings);command=['/usr/bin/python3.14',str(scenario)]
plan={'source':review['source'],'App_sha256':expected_app,'compositor_source':comp_build['source'],'compositor_sha256':sha(compositor),'observer_sha256':sha(observer),'command':command,'cwd':str(case),'environment':settings,'pins':pins,'timeout_seconds':360,'RSS_limit_bytes':6*1024**3,'virtual_AS_cap':None,'scope':'Combined9e4 native Wayland App/current canonical DomeD actual fourteen public/menu/text/GL/desktop-side checks. Nested diagnostic Xvfb presentation includes a copy; no physical headset or native DRM scanout claim.'}
(case/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s={'terminal':False,'state':'preparing','steps':[],'source':review['source'],'plan_sha256':sha(case/'plan.json')};lease=None
app_witness=providers.Witness(pins,app,out/'private-x11/usr/bin/Xvfb');comp_witness=providers.Witness(pins,compositor,out/'private-x11/usr/bin/Xvfb')
def save():(case/'status.json').write_text(json.dumps(s,indent=2)+'\n')
def drift():return[p for p,h in pins.items()if not Path(p).is_file()or sha(p)!=h]
def live(row):
    app_witness.observe(row,monitor);comp_witness.observe(row,monitor);s['live']=row;s['actual_App']=app_witness.result();s['actual_compositor']=comp_witness.result();save()
try:
    assert not drift()
    lease=open('/tmp/dome-sculpt-arc-device.lock','a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);st=os.fstat(lease.fileno());s['lease']={'acquired':time.time(),'device':st.st_dev,'inode':st.st_ino,'before_any_ldd_or_product':True};save()
    for p in [app,compositor,observer]:
        row=monitor.run(['/usr/bin/ldd',str(p)],cwd=case,env=env,log=case/(p.name+'.ldd'),timeout=30,max_rss=6*1024**3);s['steps'].append({'name':'loader '+p.name,**row});assert row['exit']==0 and not row.get('error')
        text=(case/(p.name+'.ldd')).read_text();assert'not found'not in text
        for name in re.findall(r'(?:=>\s*)?(/\S+)\s+\(',text):assert str(Path(name).resolve())in pins and sha(name)==pins[str(Path(name).resolve())]
    row=monitor.run(command,cwd=case,env=env,log=case/'process.log',timeout=360,max_rss=6*1024**3,progress=live);s['steps'].append({'name':'actual combined native Wayland14',**row});s.pop('live',None);s['actual_App']=app_witness.result();s['actual_compositor']=comp_witness.result();save();assert row['exit']==0 and not row.get('error')and not row['signals']
    report=json.loads((case/'workflow/report.json').read_text());assert report['complete']and report['failed']==0 and all(v['passed']for v in report['checks']);assert len(report['checks'])==14
    assert len(app_witness.apps)==1 and len(comp_witness.apps)==1 and app_witness.xvfbs
    assert any(any(fd['target']=='/dev/dri/renderD129'for fd in v['fds'])for v in app_witness.drm.values())
    assert any(any(fd['target']=='/dev/dri/renderD129'for fd in v['fds'])for v in comp_witness.drm.values())
    devices=list((case/'workflow/actual-device').glob('*/device.txt'));assert devices
    for p in devices:
        d=dict(line.split('=',1)for line in p.read_text().splitlines()if'='in line and not line.startswith('fd='));assert d['vendor']=='Intel'and'Arc'in d['renderer']and'A770'in d['renderer']and d['render_node']=='/dev/dri/renderD129'and d['pci'].endswith('/0000:03:00.0')and d['vendor_id']=='0x8086'and d['device_id']=='0x56a0';assert int(d['egl_display'],16)and int(d['egl_context'],16)and re.search(r'^fd=\d+$',p.read_text(),re.M)
    assert not drift();s.update(state='complete',exit=0,actual_checks=14,actual_device_reports={str(p):sha(p)for p in devices})
except BaseException as error:s.update(state='failed',exit=1,error=repr(error),traceback=traceback.format_exc())
finally:
    s['input_drift']=drift();s['owned_remaining']=[]
    for row in s['steps']:
        for record in row.get('known_processes',[]):
            if monitor.alive(record):s['owned_remaining'].append(record)
    if s['input_drift']or s['owned_remaining']:s.update(state='failed',exit=1)
    s['terminal']=True
    if lease:
        if'lease'in s:s['lease']['released']=time.time()
        save();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
    save()
raise SystemExit(s['exit'])
