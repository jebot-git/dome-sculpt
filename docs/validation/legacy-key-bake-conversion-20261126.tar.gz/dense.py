from pathlib import Path
import json
import shlex
import subprocess
import sys
root=Path(__file__).resolve().parent
old=root.parent/'legacy-key-bake-conversion-v3-20261126/release'
build=old/'build'
out=root/'dense'
out.mkdir(exist_ok=True)
exe=out/'dense'
object=out/'dense.o'
db=json.loads((build/'compile_commands.json').read_text())
entry=next(e for e in db if 'dome-sculpt-source-writable-normal-bake-test.dir/' in e['command'])
def command(args,log):
    with (out/log).open('w') as f:
        print(shlex.join(map(str,args)),file=f,flush=True)
        subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=500,check=True)
args=shlex.split(entry['command'])
args[args.index('-o')+1]=str(object)
args[args.index('-c')+1]=str(root/'dense.cpp')
args.extend(['-I'+str(root/'source/tests'),'-MMD','-MF',str(object)+'.d'])
command(args,'compile.log')
args=shlex.split((old/'dome-sculpt-source-writable-normal-bake-test-link.log').read_text().splitlines()[0])
args[args.index('-o')+1]=str(exe)
args=[str(object) if arg.endswith('/source-writable-normal-bake.cpp.o') else arg for arg in args]
command(args,'link.log')
command(['/usr/bin/time','-v',exe,sys.argv[1]],'run.log')
