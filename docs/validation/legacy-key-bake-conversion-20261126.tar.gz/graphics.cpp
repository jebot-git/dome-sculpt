#define DOME_NATIVE_KEY_EXPORT_NO_MAIN
#include "native-paint-key-export-render.cpp"
#include "dome/shapekey-authoring.hpp"

int main(int argc,char **argv) try {
  if(argc!=4)return 2;
  const std::filesystem::path input=argv[1],output=argv[2];
  std::filesystem::create_directories(output);
  NativeGraphics graphics;
  const std::string renderer=reinterpret_cast<const char *>(glGetString(GL_RENDERER));
  std::cout<<"GPU "<<renderer<<std::endl;
  check(renderer.find(argv[3])!=std::string::npos,"Requested renderer is active");
  Fbo fbo;
  SurfaceRenderer native;
  prepared_normal_consumer::Renderer consumer;
  for(const std::string name:{"ldr","hdr"}){
    const auto old=Scene::load(input/(name+"-before.dsculpt"));
    const auto accepted=Scene::load(input/(name+"-ordered.dsculpt"));
    const auto edited=Scene::load(input/(name+"-edited.dsculpt"));
    auto publish=[](Document &document,const Scene &scene){
      document.replace(scene);
      document.shading(false);
      finish(document);
    };
    Document legacy;
    publish(legacy,old);
    fbo.bind();
    const auto before=draw(native,legacy.frame().surface);
    legacy.convert_baked_normals();
    check(legacy.wait_asset()&&legacy.wait_mesh()&&legacy.frame().state->error.empty(),
          "Live document conversion publishes a new render snapshot");
    fbo.bind();
    const auto after=draw(native,legacy.frame().surface);
    check(legacy.undo()&&legacy.wait_mesh(),"Live renderer restores historical bake through Undo");
    fbo.bind();
    check(draw(native,legacy.frame().surface)==before,"Undo uploads and renders exact historical geometry and normals");
    check(legacy.redo()&&legacy.wait_mesh(),"Live renderer restores converted bake through Redo");
    fbo.bind();
    check(draw(native,legacy.frame().surface)==after,"Redo uploads and renders exact converted geometry and normals");
    Document modern;
    capture(output/(name+"-before.png"),before);
    capture(output/(name+"-after.png"),after);
    const int difference=delta(before,after);
    std::cout<<"REST "<<name<<" delta="<<difference<<std::endl;
    check(difference<=3,"Legacy and converted rest renders agree through projected and empty regions");
    size_t lit=0;
    for(size_t p=0;p<after.size();p+=4)lit+=after[p+3]!=0;
    check(lit>500,"Substantial visible native fixture");
    for(bool edit:{false,true}){
      auto phase=edit?edited:accepted;
      if(edit){
        ShapeKeyEdit key;
        key.action=ShapeKeyAction::Replace;
        key.target=0;
        key.positions=phase.active().painted->mesh().positions;
        for(auto &p:key.positions){p.x+=.08f*p.y;p.z+=.16f*p.x-.12f*p.y;}
        author_shapekey(phase,phase.active().id,key);
      }
      publish(modern,phase);
      fbo.bind();
      const auto snapshot=modern.frame().surface;
      const auto native_pixels=draw(native,snapshot);
      if(edit)check(delta(after,native_pixels)>5,"Visible skin and shapekey deformation");
      const auto mode=edit?"-edited":"-rest";
      for(bool editable:{false,true}){
        const auto path=output/(name+mode+(editable?"-editable.glb":".glb"));
        modern.export_asset(path,editable?AssetExportFormat::EditableGlb256:AssetExportFormat::Glb).get();
        prepared_normal_consumer::Model model(path);
        const auto &p=model.data->meshes[0].primitives[0];
        check(p.targets_count==phase.active().deformation->morphs->targets.size(),"Independent GLB sees all authored morph channels");
        fbo.bind();
        consumer.render(model.data,nullptr);
        const auto actual=read();
        const auto error=delta(native_pixels,actual);
        std::cout<<"GLB "<<name<<mode<<" editable="<<editable<<" delta="<<error<<std::endl;
        check(error<=4,"Standard or Editable GLB matches the independently drawn native fixture");
        if(editable){
          const auto restored=extract_native_authoring(key_file_bytes(path));
          check(restored&&restored->encode()==phase.encode(),"Editable GLB retains the complete native project");
        }
      }
    }
  }
  std::cout<<"PASS "<<checks<<" legacy normal conversion graphical checks\n";
  return 0;
}catch(const std::exception &error){std::cerr<<"FAIL "<<error.what()<<'\n';return 1;}
