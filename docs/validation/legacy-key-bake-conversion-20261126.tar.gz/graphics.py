from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys

root=Path(__file__).resolve().parent
art=root.parent
renderer=sys.argv[1]
profile='release'
out=root/('graphics-strong-'+renderer)
out.mkdir(exist_ok=True)
build=root/profile/'build'
receipt=json.loads((root/profile/'status.json').read_text())
core=root/profile/'libdome-sculpt-core.a'
prior=art/'writable-donor-current-validation-v2-20261126'/profile
support=art/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
source=root/'source'
def sha(p):
    with p.open('rb') as data:return hashlib.file_digest(data,'sha256').hexdigest()
assert sha(core)==receipt['core']
objects=json.loads((build/'compile_commands.json').read_text())
fixture='native-paint-key-export-render'
target='dome-sculpt-'+fixture+'-test'
entry=next(e for e in objects if target+'.dir/' in e['command'])
obj=out/'graphics.o'
exe=out/'graphics'
env={**os.environ,'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
def invoke(args,name):
    with (out/name).open('w') as log:
        print(shlex.join(map(str,args)),file=log,flush=True)
        return subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=360)
cmd=shlex.split(entry['command'])
cmd[cmd.index('-o')+1]=str(obj)
cmd[cmd.index('-c')+1]=str(root/'graphics.cpp')
cmd.extend(['-I'+str(source/'tests'),'-MMD','-MF',str(obj)+'.d'])
invoke(cmd,'compile.log')
command=subprocess.check_output(['ninja','-C',build,'-t','commands',target],text=True).splitlines()[-1]
cmd=[w for w in shlex.split(command)[2:-2] if not w.startswith('-Wl,--dependency-file=')]
for i,word in enumerate(cmd):
    if word.endswith('.o'):cmd[i]=str(obj)
    elif word=='libdome-sculpt-core.a':cmd[i]=str(core)
    elif word=='libdome-sculpt-render.a':cmd[i]=str(art/'native-key-bake-v2-20261126'/profile/word)
    elif word.startswith('lib') and word.endswith('.a'):cmd[i]=str(support/word)
cmd[cmd.index('-o')+1]=str(exe)
invoke(cmd,'link.log')
bwrap=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
       '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
fields={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
       'LD_LIBRARY_PATH':env['LD_LIBRARY_PATH'],'LIBGL_ALWAYS_SOFTWARE':'1'}
name='llvmpipe'
if renderer=='arc':
    node='/dev/dri/renderD129'
    bwrap.extend(['--dev-bind',node,node])
    name='Arc(tm) A770'
    fields.update(LIBGL_ALWAYS_SOFTWARE='0',DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1')
for key,value in fields.items():bwrap.extend(['--setenv',key,value])
with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock:
    if renderer=='arc':fcntl.flock(lock,fcntl.LOCK_EX)
    invoke([*bwrap,exe,build/'legacy-native-key-bake-conversion',out/'images',name],'run.log')
