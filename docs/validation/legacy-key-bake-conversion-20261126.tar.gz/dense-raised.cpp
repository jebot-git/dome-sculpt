#define main full_native_fixture_entry
#include "source-writable-normal-bake.cpp"
#undef main
#include <chrono>

int main(int argc,char **argv) try {
  if(argc!=2)return 2;
  const auto size=uint32_t(std::stoul(argv[1]));
  auto scene=writable_source::source(false);
  auto mesh=scene.active().painted->mesh();
  scene.active().painted=std::make_shared<PaintedMesh>(mesh,size);
  auto target=mesh;
  for(auto &p:target.uv){const auto u=p[0];p={.2f+.6f*p[1],.8f-.6f*u};}
  const std::array<uint32_t,4> corners{0,1,2,3};
  PaintSamplingLimits limits;
  limits.max_work=128'000'000;
  auto retained=detail::retain_native_paint_model(scene.active(),target,corners,limits);
  scene.active().material_bindings=detail::bind_native_paint(retained.sampling.owner,{});
  scene.active().painted=std::move(retained.sampling.paint);
  scene.active().deformation=std::move(retained.deformation);
  scene.validate();
  for(auto &p:mesh.positions)p.z=.02f;
  mesh.normals.assign(mesh.positions.size(),normalized(Vec3{-.33f,.27f,1}));
  const auto donor=scene.add("Dense historical donor",Volume{});
  scene.active().mesh_active=true;
  scene.active().painted=std::make_shared<PaintedMesh>(std::move(mesh),64);
  scene.active().visible=false;
  scene.select(1);
  auto settings=writable_source::settings();
  settings.prepare_normals=false;
  settings.corresponding_topology=true;
  const auto start=std::chrono::steady_clock::now();
  const auto bake=bake_object(scene,donor,settings);
  const auto baked=std::chrono::steady_clock::now();
  writable_source::key_pose(scene,true,false);
  const auto source=scene.active().painted->baked();
  const auto result=detail::convert_native_baked_normals(scene.active(),{});
  const auto after=std::chrono::steady_clock::now();
  const auto converted=result.paint->baked();
  if(bake.projected!=size_t(size)*size||converted->coverage!=source->coverage||
      converted->maps.normal.rgba==source->maps.normal.rgba||result.maximum_sample_error>.02)
    throw std::runtime_error("Dense conversion check failed");
  std::cout<<"PASS dense "<<size<<" projected="<<bake.projected<<" bake_sec="
    <<std::chrono::duration<double>(baked-start).count()<<" authored_and_converted_sec="
    <<std::chrono::duration<double>(after-baked).count()<<" max_sampled_degrees="
    <<result.maximum_sample_error*57.29577951308232<<'\n';
  return 0;
}catch(const std::exception &e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
