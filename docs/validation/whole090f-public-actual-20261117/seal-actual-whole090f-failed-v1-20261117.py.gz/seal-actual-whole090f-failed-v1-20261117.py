"""Seal actual current component UI results; never promote whole090f acceptance."""
from pathlib import Path
import hashlib,json,tarfile,io,lzma,time
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stable_sha(p):
 p=Path(p);a=p.stat()
 with p.open('rb')as stream:value=hashlib.file_digest(stream,'sha256').hexdigest()
 b=p.stat();assert(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns),('File changed during seal',str(p));return value
pins={};rows=[];evidence={};pids=set()
def member(p):
 p=Path(p);key=str(p.relative_to(P));assert key not in evidence or evidence[key]==stable_sha(p);evidence[key]=stable_sha(p)
for phase,want in [('gui',16),('xr',65)]:
 for case in ['mt1-rest','mt1-posed','mt0-rest','mt0-posed']:
  root=P/f'release-{phase}-{case}-whole090f-v3-20261117';status=root/'status.json';j=json.loads(status.read_text());assert j['state']=='terminal'and j['exit']==0 and not j['input_drift']and not j['remaining_owned_processes']and j['checks']==want and len(j['actual_app_pids'])==2
  assert j['lease_released_epoch']>=j['lease_acquired_epoch'];assert len(j['source_tuple'])==4
  for path,digest in j['pins'].items():assert path not in pins or pins[path]==digest,('Conflicting expected pin',path);pins[path]=digest
  report=root/'workflow/report.json';r=json.loads(report.read_text());assert r['complete']and not r['error']and not r['drift']and len(r['checks'])==want and all(x['passed']for x in r['checks'])
  assert not(pids&set(j['actual_app_pids']));pids.update(j['actual_app_pids'])
  native=[]
  for f in root.rglob('native-*.json'):
   v=json.loads(f.read_text());assert v['verified']and v['all_sources_and_first_recipe_exact'];native.append({'file':str(f.relative_to(P)),'sha256':stable_sha(f),'phase':v['phase'],'normal_oracle':v['normal_oracle']})
  assert len(native)==4
  if phase=='xr':
   assert len(j['device_reports'])==2
   cache=json.loads((root/'workflow/shader-code-cache-provenance.json').read_text());assert cache['initially_empty']and len(cache['events'])==2 and cache['events'][0]['disk_misses']>0 and cache['events'][1]['disk_hits']>0
   runtimes=[json.loads(f.read_text())for f in (root/'workflow').rglob('runtime.json')];assert len(runtimes)==2
   frames=sum(x['frames_waited']for x in runtimes);assert frames<=6000
  else:assert j['actual_private_Xvfb'];cache=None;frames=None
  for f in root.rglob('*'):
   if not f.is_file():continue
   rel=f.relative_to(root);parts=set(rel.parts)
   if any(x in parts for x in ['mesa-shader-code-cache','cache']):continue
   if f.suffix in ['.json','.jsonl','.txt','.log','.png','.ppm','.rgba','.dsculpt']or 'gates'in parts:member(f)
  for kind in ['launch','terminal','journal']:
   f=P/f'whole090f-{phase}-{case}-unit-{kind}-20261117.{"json"if kind=="launch"else"txt"}'
   assert f.is_file(),f;member(f)
  rows.append({'phase':phase,'case':case,'checks':want,'actual_exit':0,'seconds':j['seconds'],'status':str(status),'status_sha256':stable_sha(status),'app_pids':j['actual_app_pids'],'critical_ELFs':j['critical_observed'],'lease_acquired_epoch':j['lease_acquired_epoch'],'lease_released_epoch':j['lease_released_epoch'],'native_endpoints':native,'total_synthetic_frames':frames,'cache_events':[{k:v for k,v in e.items()if k not in ['cache_files']}for e in cache['events']]if cache else None,'device_reports':j.get('device_reports'),'private_Xvfb':j.get('actual_private_Xvfb')})
for name in ['run-v3.py','cohort_v3.py','cohort_v2.py','scenario-provenance.json','root-whole-gui-review-v3-20261117.json','root-whole-xr-review-v3-20261117.json','whole090f-matrix-v3-actual-20261117.json','whole090f-matrix-explicit-lease-handoff-20261117.json','whole-app-prepared-review-v3.json','scenarios/source-prepared-public-menu.py','scenarios/source-prepared-public-xr.py']:member(P/name)
for pid in pids:assert not Path('/proc',str(pid)).exists(),('Old app PID exists; inspect identity',pid)
bad=[path for path,want in pins.items()if not Path(path).is_file()or stable_sha(path)!=want];assert not bad,bad
out=P/'actual-whole090f-UI64-XR260-seal-20261117';out.mkdir(exist_ok=False)
write=lambda f,j:Path(f).write_text(json.dumps(j,indent=2)+'\n')
summary={'state':'terminal','exit':0,'scope':'Actual complete sealed whole090f Release application, productionbody1bc; separate fixturef1e193c7 and unchanged6c8 runtime/font/scenarios. Desktop software private-Xvfb64 and authenticatedArc real-loader syntheticXR260. Earlier component64/260 are distinct. No wholeSAN, physical headset, native Wayland, installation or full production completion.','source_tuple':j['source_tuple'],'GUI_checks':64,'XR_checks':260,'fresh_distinct_app_pids':sorted(pids),'unique_expected_input_pins':len(pins),'uncached_postseal_input_drift':bad,'all_recorded_app_pids_absent':True,'cases':rows,'evidence_members':evidence,'authoritative_native_prerequisite':j['native_admission'],'whole_application_loader_admission':j['whole_application_loader_admission']}
write(out/'summary.json',summary)
with lzma.open(out/'actual-evidence.tar.xz','wb',preset=6)as compressed:
 with tarfile.open(fileobj=compressed,mode='w|')as archive:
  for key in sorted(evidence):
   file=P/key;assert stable_sha(file)==evidence[key];info=archive.gettarinfo(str(file),arcname=key);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   with file.open('rb')as stream:archive.addfile(info,stream)
write(out/'archive.json',{'archive_sha256':stable_sha(out/'actual-evidence.tar.xz'),'summary_sha256':stable_sha(out/'summary.json'),'bytes':(out/'actual-evidence.tar.xz').stat().st_size,'members':len(evidence)})
print('SEALED',len(evidence),'members',(out/'actual-evidence.tar.xz').stat().st_size,'bytes',len(pins),'pins',stable_sha(out/'summary.json'),flush=True)
