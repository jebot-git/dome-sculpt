from pathlib import Path
import fcntl
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
art=base.parent
profile=sys.argv[1]
arc=profile=='asan'
out=base/profile
out.mkdir(exist_ok=True)
candidate='59f6c278f94c0f31f45b092673e22ea57cebea47'
parent='90c10c285038fdfdf5e415ca8efbc7c494debb34'
source=art/'paint-source-grid-sampling-source-20261126'
old=art/'current-creator-vrm0-validation-v3-20261126'/profile
new=art/'paint-source-grid-sampling-validation-20261126'/profile
old_core=art/'current-creator-vrm0-validation-v2-20261126'/profile/'libdome-sculpt-core.a'
new_core=new/'libdome-sculpt-core.a'
sdk=art/'sdk-20261126/toolkit-sanitize' if arc else Path('/opt/fltk-vr/toolkit')
state={'candidate':candidate,'parent':parent,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}

def save(**fields):
    state.update(fields)
    tmp=out/'status.tmp'
    tmp.write_text(json.dumps(state,indent=2)+'\n')
    tmp.replace(out/'status.json')

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def run(args,log,timeout,cwd):
    with (out/log).open('w') as trace:
        print(shlex.join(map(str,args)),file=trace,flush=True)
        subprocess.run(args,cwd=cwd,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=timeout)

try:
    save(phase='wait for rebuilt paint core')
    while True:
        token=new/'status.json'
        if token.exists():
            current=json.loads(token.read_text())
            if 'core_sha256' in current or current['terminal']:break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        f'ds-paint-source-grid-sampling-{profile}-20261126.service'],check=True)
        time.sleep(2)
    assert current['candidate']==candidate and current['donor']==parent
    assert current['core_sha256']==sha(new_core) and current['parent_core_sha256']==sha(old_core)
    restored=json.loads((old/'status.json').read_text())
    assert restored['candidate']==parent and restored['terminal'] and restored['exit']==0
    assert restored['core_sha256']==sha(old_core)

    fixture=source/'tests/normal-frame-vrm-consumer.cpp'
    assert subprocess.check_output(['git','-C',source,'diff','--name-only',parent,'HEAD','--',
        'tests/normal-frame-vrm-consumer.cpp','tests/normal-frame-consumer.hpp','tests/mtoon-render.cpp'],text=True)==''
    code=fixture.read_text()
    snippet='check(document.wait_mesh(std::chrono::seconds(30)),"Actual avatar worker accepts explicitly authored flat frames and rigid skinning before the low-level atlas fixture");'
    assert code.count(snippet)==1
    timing=snippet[snippet.index(',"')+1:-2]
    code=code.replace(snippet,'''const auto initial=document.wait_mesh(std::chrono::seconds(30));
      std::cerr<<"CANONICAL_ORIGINAL_DEADLINE "<<initial<<'\\n';
      if(!initial) {
        const auto error=document.frame().state->error;
        std::cerr<<"CANONICAL_WORKER_DIAGNOSTIC "<<error<<'\\n';
        check(error.empty() && document.wait_mesh(std::chrono::seconds(90)),'''+timing+''');
      }
      std::cerr<<"CANONICAL_WORKER_MS "<<document.frame().surface->sculpt_meshing.worker_ms<<'\\n';
      check(true,'''+timing+''');''')
    generated=out/'timed-normal-frame.cpp'
    generated.write_text(code)
    target='dome-sculpt-normal-frame-vrm-consumer-test'
    row=next(row for row in json.loads((new/'build/compile_commands.json').read_text())
             if f'CMakeFiles/{target}.dir/' in row['command'])
    compile=shlex.split(row['command'])
    compile[1:1]=['-I',str(fixture.parent)]
    obj=out/'timed-normal-frame.cpp.o'
    compile[compile.index('-o')+1]=str(obj)
    compile[compile.index('-c')+1]=str(generated)
    run(compile,'compile.log',300,new/'build')
    link=shlex.split((old/'tests'/target/'link.log').read_text().splitlines()[0])
    assert sum(Path(item).name==old_core.name for item in link)>0
    for key,core in (('parent',old_core),('candidate',new_core)):
        output=out/key
        output.mkdir(exist_ok=True)
        cmd=[str(core) if Path(word).name==core.name else str(obj) if word.endswith('/normal-frame-vrm-consumer.cpp.o')
             else word for word in link]
        cmd[cmd.index('-o')+1]=str(output/'consumer')
        run(cmd,key+'-link.log',300,old/'build')

    sandbox=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
             '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    variables={'PATH':'/usr/bin:/bin','HOME':'/tmp','EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2',
               'LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1',
               'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if arc:
        node='/dev/dri/renderD129'
        sandbox.extend(['--dev-bind',node,node])
        variables.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
                         ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
                         UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in variables.items():sandbox.extend(['--setenv',key,value])
    baseline=old/'build/frame-vrm-consumer-canonical.vrm'
    save(phase='run serial cold canonical avatar captures',fixture_sha256=sha(generated),
         expected_vrm_sha256=sha(baseline))
    results=[]
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock:
        if arc:fcntl.flock(lock,fcntl.LOCK_EX)
        order=('parent','candidate','candidate','parent')
        for i,key in enumerate(order):
            binary=out/key/'consumer'
            prefix=out/key/f'sample-{i}'
            label=str(prefix.relative_to(out))+'.log'
            run([*sandbox,binary,prefix,'--canonical-only'],label,220,out)
            capture=(out/label).read_text()
            elapsed=float(re.search(r'CANONICAL_WORKER_MS ([0-9.e+]+)',capture)[1])
            met_deadline=re.search(r'CANONICAL_ORIGINAL_DEADLINE ([01])',capture)[1]=='1'
            renderer=re.search(r'^GPU (.*)$',capture,re.M)[1]
            image_error=int(re.search(r'CANONICAL_VRM_CONSUMER maxerror=(\d+)',capture)[1])
            file=prefix.with_name(prefix.name+'-canonical.vrm')
            assert image_error<=4 and sha(file)==state['expected_vrm_sha256']
            assert ('Arc(tm) A770' if arc else 'llvmpipe') in renderer
            if key=='candidate':assert met_deadline
            results.append({'core':key,'worker_ms':elapsed,'deadline':met_deadline,'renderer':renderer,
                            'image_error':image_error,'file_sha256':sha(file)})
            save(results=results)
    save(phase='complete',terminal=True,exit=0)
except Exception as error:
    save(terminal=True,exit=1,error=repr(error))
    raise
