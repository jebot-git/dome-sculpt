from pathlib import Path
import fcntl
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
art=base.parent
profile=sys.argv[1]
arc=profile=='arc'
out=base/profile
out.mkdir(exist_ok=True)
native=art/'paint-source-grid-sampling-validation-20261126/release'
runtime=art/'retained-texture-set-public-validation-20261126/release'
source=art/'paint-source-grid-sampling-source-20261126'
candidate='59f6c278f94c0f31f45b092673e22ea57cebea47'
status={'candidate':candidate,'profile':profile,'terminal':False,'invocation':os.getenv('INVOCATION_ID')}
def save(**fields):
    status.update(fields)
    (out/'status.json').write_text(json.dumps(status,indent=2)+'\n')
def sha(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data,'sha256').hexdigest()
try:
    save(phase='wait for validated Release')
    while True:
        status_file=native/'status.json'
        if status_file.is_file():
            sealed=json.loads(status_file.read_text())
            if sealed['terminal']:break
        subprocess.run(['systemctl','--user','is-active','--quiet',
                        'ds-paint-source-grid-sampling-release-20261126.service'],check=True)
        time.sleep(2)
    assert sealed['candidate']==candidate and sealed['exit']==0 and sealed['tests']==10
    app=native/'build/dome-sculpt'
    assert sha(app)==sealed['app_sha256']
    assert not subprocess.check_output(['git','-C',source,'diff','--name-only',
        '33bd2460','HEAD','--','tests/xr_runtime.cpp'],text=True)
    fixture=art/'current-creator-vrm0-validation-v3-20261126/release/build/creator-shaped-vrm/vroid-beta-female.dsculpt'
    synthetic=runtime/'libdome-sculpt-test-runtime.so'
    assert sha(synthetic)==json.loads((runtime/'status.json').read_text())['runtime_sha256']
    manifest=out/'manifest.json'
    manifest.write_text(json.dumps({'file_format_version':'1.0.0','runtime':{'library_path':str(synthetic)}}))
    prefix=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
            '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    report=out/'runtime.json'
    environment={'PATH':'/usr/bin:/bin','HOME':'/tmp','XDG_RUNTIME_DIR':'/tmp',
                 'XR_RUNTIME_JSON':str(manifest),'DOME_XR_FIXTURE_REPORT':str(report),
                 'EGL_PLATFORM':'surfaceless','LP_NUM_THREADS':'2','LIBGL_ALWAYS_SOFTWARE':'0' if arc else '1',
                 'LD_LIBRARY_PATH':'/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    if arc:
        node='/dev/dri/renderD129'
        prefix.extend(['--dev-bind',node,node])
        environment.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1')
    for k,v in environment.items():prefix.extend(['--setenv',k,v])
    destination=out/'reopened.dsculpt'
    command=[*prefix,app,'--xr','--open',fixture,'--frames','6','--save',destination]
    save(phase='open the shaped creator project through the actual OpenXR loader',app_sha256=sha(app),
         immutable_project_sha256=sha(fixture),runtime_sha256=sha(synthetic))
    with open('/tmp/dome-sculpt-arc-device.lock','rb') as lock,(out/'xr.log').open('w') as trace:
        if arc:fcntl.flock(lock,fcntl.LOCK_EX)
        print(shlex.join(map(str,command)),file=trace,flush=True)
        subprocess.run(command,cwd=out,stdout=trace,stderr=subprocess.STDOUT,check=True,timeout=120)
    observed=json.loads(report.read_text())
    name=observed['gl_renderer']
    assert ('Arc(tm) A770' if arc else 'llvmpipe') in name
    assert observed['acquires']==observed['image_waits']==observed['releases']>=10
    assert observed['left_eye_nonblank']==observed['right_eye_nonblank'] and 2*observed['left_eye_nonblank']==observed['releases']
    assert sha(destination)==status['immutable_project_sha256']==sha(fixture)
    save(phase='complete',terminal=True,exit=0,renderer=name,
         nonblank={'left':observed['left_eye_nonblank'],'right':observed['right_eye_nonblank']},
         releases=observed['releases'],report_sha256=sha(report))
except Exception as error:
    save(terminal=True,exit=1,error=repr(error))
    raise
