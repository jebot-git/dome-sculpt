// SPDX-License-Identifier: GPL-3.0-or-later
#define main existing_material_renderer_suite
#include "mtoon-render.cpp"
#undef main
#include "dome/creation.hpp"
#include "dome/material-bindings.hpp"
#include "dome/material-visibility.hpp"
#include "dome/source-uv-bake.hpp"
#include "dome/vrm.hpp"
#include "normal-frame-consumer.hpp"
#include <fstream>
namespace {
void flat_materials(Scene &scene,uint64_t group){for(const auto &item:scene.objects())if(item.group==group){auto &o=scene.object(item.id);auto b=std::make_shared<SourceMaterialBindings>(*o.material_bindings);auto &m=b->material;for(auto &t:m.textures)t.index=-1;b->roles={};m.textures[2].index=0;b->roles[2].image=image({230,153,204,255});m.parameters.normal_enabled=true;m.parameters.normal_scale=1;m.parameters.base_color={.6f,.4f,.2f,1};m.parameters.shade_color={.1f,.05f,.02f};m.parameters.toony=.5f;m.parameters.shift=-.2f;m.parameters.indirect_intensity=0;m.parameters.light_color_attenuation=0;m.parameters.emission={};m.parameters.rim_color={};m.parameters.outline=MToonOutline::None;m.parameters.cull=MToonCull::Back;m.parameters.scroll={};m.parameters.rotation_speed=0;b->validate();o.material_bindings=b;o.material.color=b->native_reference.color;o.material.emissive=b->native_reference.emission;o.material.alpha=Material::AlphaMode::Opaque;}}
void native_target(Scene &scene,uint64_t group){
 for(const auto &item:scene.objects())if(item.group==group && item.deformation->morphs && !item.deformation->morphs->targets.empty() && item.deformation->morphs->targets.size()<128){
  auto &o=scene.object(item.id);auto b=std::make_shared<SourceMaterialBindings>(*o.material_bindings);auto set=std::make_shared<NormalFrameSet>(*b->normal_frames);uint64_t id=set->next_target++;std::vector<Vec3> delta(o.painted->mesh().positions.size(),Vec3{.001f,0,0});set->targets.push_back({id,std::nullopt,std::nullopt,delta});set->current_targets.insert(set->current_targets.begin(),id);
  std::map<const NormalFrames*,std::shared_ptr<const NormalFrames>> copies;auto copy=[&](const std::shared_ptr<const NormalFrames>&f)->std::shared_ptr<const NormalFrames>{if(!f)return {};if(copies.contains(f.get()))return copies.at(f.get());auto edited=std::make_shared<NormalFrames>(*f);edited->targets.push_back({id,std::vector<Vec3>(f->normals.size(),Vec3{0,.02f,0}),{}});copies[f.get()]=edited;return edited;};set->pbr=copy(set->pbr);set->mtoon=copy(set->mtoon);set->canonical=copy(set->canonical);b->normal_frames=set;b->validate();o.material_bindings=b;
  auto d=*o.deformation;d.morphs->targets.insert(d.morphs->targets.begin(),MorphTarget{"Native extra before original slots",delta});d.morph_weights.assign(d.morphs->targets.size(),0);scene.set_deformation(o.id,std::move(d));check(o.appearance->source_morph_targets.size()+1==o.deformation->morphs->targets.size(),"Native-only target insertion deliberately leaves historical source slots untouched and uses explicit frame identities");return;
 }
 throw std::runtime_error("No actual source morph part available");
}
void unwrap(Scene &scene,uint64_t group){for(const auto &item:scene.objects())if(item.group==group){auto &o=scene.object(item.id);SourceUvBakeInput in;in.paint=o.painted;in.appearance=o.appearance;in.current_material=o.material_bindings;in.current_deformation=o.deformation;const auto &old=o.painted->mesh();in.target=old;dome::unwrap(in.target,512,4);in.source_vertices.assign(in.target.positions.size(),UINT32_MAX);for(size_t c=0;c<old.indices.size();++c){auto v=in.target.indices[c],source=old.indices[c];if(in.source_vertices[v]!=UINT32_MAX&&in.source_vertices[v]!=source)throw std::runtime_error("Actual atlas lost exact source corner mapping");in.source_vertices[v]=source;}SourceUvBakeOptions options;options.resolution=512;auto a=adopt_source_uv_bake(bake_source_uv(in,options));o.painted=a.paint;o.material_bindings=a.material_bindings;o.appearance=a.appearance;o.deformation=a.deformation;}scene.validate();}
void refuses_forged_atlas(std::vector<ObjectSurface> objects,std::filesystem::path path) {
  auto part=std::find_if(objects.begin(),objects.end(),[](const auto &o){
    return o.appearance && o.appearance->source_vertices!=o.material_bindings->uv_origin->appearance->source_vertices;
  });
  check(part!=objects.end(),"Re-atlasing changes the current accessor layout through an actual seam remap");
  auto appearance=std::make_shared<CreatorAppearance>(*part->appearance);
  const auto vertex=part->mesh.indices.front();
  const auto source=appearance->source_vertices[vertex];
  const auto other=std::find_if(appearance->source_vertices.begin(),appearance->source_vertices.end(),
                                [=](auto value){return value!=source;});
  check(other!=appearance->source_vertices.end(),"The forged remap uses a different valid accessor of the same source");
  appearance->source_vertices[vertex]=*other;
  part->appearance=std::move(appearance);
  path+="-forged-source.vrm";
  {std::ofstream previous(path,std::ios::binary);previous<<"previous export";}
  bool refused=false;
  try{export_vrm(objects,path);}catch(const std::invalid_argument &error){
    refused=std::string_view(error.what()).find("creator UV remap changes the original source corners")!=std::string_view::npos;
  }
  std::ifstream saved(path,std::ios::binary);
  const std::string saved_bytes{std::istreambuf_iterator<char>(saved),{}};
  check(refused&&saved_bytes=="previous export","Creator export refuses a changed corner accessor without replacing the output");
}
void canonical_avatar(Scene &scene,uint64_t group) {
 uint32_t resolution=64;auto solid=[resolution](std::array<uint8_t,4>pixel){Image out{resolution,resolution,std::vector<uint8_t>(size_t(resolution)*resolution*4)};for(size_t n=0;n<out.rgba.size();++n)out.rgba[n]=pixel[n%4];return out;};
 for(const auto &item:scene.objects())if(item.group==group){auto &o=scene.object(item.id);auto b=std::make_shared<SourceMaterialBindings>(*o.material_bindings);auto set=std::make_shared<NormalFrameSet>(*b->normal_frames);auto frame=std::make_shared<NormalFrames>(*set->pbr);frame->normals.assign(frame->normals.size(),{0,0,1});frame->tangents.assign(frame->normals.size(),{1,0,0,1});for(auto &target:frame->targets){target.normals.clear();target.tangents.clear();}set->pbr=set->mtoon=frame;auto canonical=std::make_shared<NormalFrames>(*frame);canonical->transport=NormalFrameTransport::CanonicalMikk;canonical->generated_tangents=false;canonical->generated_uv.reset();set->canonical=canonical;b->normal_frames=set;o.material_bindings=b;
  BakedTextures bake;bake.maps.color=solid({255,255,255,255});bake.maps.metal_rough=solid({255,255,255,255});bake.maps.emission=solid({0,0,0,255});bake.maps.normal=solid({128,204,230,255});bake.coverage.assign(size_t(resolution)*resolution,255);o.painted=o.painted->snapshot();o.painted->install_bake(std::move(bake));auto state=*o.deformation;auto joint=state.humanoid->joints.at("hips");state.skin->vertices.assign(o.painted->mesh().positions.size(),{{joint,1}});state.pose.clear();for(const auto &bone:state.skeleton->bones)state.pose.push_back(bone.rest);state.pose[joint].scale={1.5f,1,.7f};scene.set_deformation(o.id,std::move(state));
 }scene.validate();
}
}
int main(int argc,char**argv)try {
 if(argc<2)return 2;std::filesystem::path prefix=argv[1];NativeGraphics graphics;std::string device=reinterpret_cast<const char*>(glGetString(GL_RENDERER));std::cout<<"GPU "<<device<<'\n';check(argc<3||std::string(argv[2])!="--hardware"||device.find("llvmpipe")==std::string::npos,"Actual VRM consumer runs on requested graphics hardware");Fbo framebuffer;framebuffer.bind();SurfaceRenderer native;frame_consumer::Renderer consumer;
 Scene original;auto group=append_humanoid(original,humanoid_baseline_defaults("vroid-beta-female"),"Consumer avatar",{},64);original.group(group).transform.scale=.8f;original.group(group).transform.position.y=-.7f;native_target(original,group);flat_materials(original,group);
 for(int stage=0;stage<(argc>2 && std::string(argv[2])=="--canonical-only"?0:2);++stage){
  auto scene=original;
  if(stage){
    unwrap(scene,group);
    const auto exact=scene.encode();
    auto path=prefix;
    path+="-re-atlased.dsculpt";
    scene.save(path);
    scene=Scene::load(path);
    check(scene.encode()==exact,"The edited UV layout and original corner authority survive native Save and reopen exactly");
  }
  for(float weight:{0.f,.35f,1.f}){for(const auto &item:scene.objects())if(item.group==group){auto d=*item.deformation;d.pose.clear();for(const auto &bone:d.skeleton->bones)d.pose.push_back(bone.rest);d.pose[d.humanoid->joints.at("hips")].scale={1.5f,1,.7f};if(d.morphs&&!d.morphs->targets.empty()){d.morph_weights.assign(d.morphs->targets.size(),0);d.morph_weights[0]=weight;}scene.set_deformation(item.id,std::move(d));}
   Document document;document.replace(scene);check(document.wait_mesh(std::chrono::seconds(30)),"Actual nineteen-part source avatar publishes posed original frames before export");auto objects=scene.preview_surfaces();std::erase_if(objects,[&](const auto&o){return o.groups.empty()||o.groups.back().id!=group;});auto path=prefix;path+="-"+std::to_string(stage)+"-"+std::to_string(int(weight*100))+".vrm";
   auto report=export_vrm(objects,path);
   if(stage&&weight==0)refuses_forged_atlas(objects,prefix);
   frame_consumer::Model parsed(path);check(report.normal_targets_recomputed==0 && parsed.data->meshes_count==19,"Independent cgltf accepts all actual VRM meshes with explicit native normal/tangent keys and no geometric replacement");auto wanted=draw(native,document.frame().surface);framebuffer.bind();consumer.render(parsed.data,&parsed.json.at("extensions").at("VRM"),*objects[0].appearance->source_basis_quaternion);auto actual=read();int error=delta(wanted,actual);std::cout<<"VRM_CONSUMER stage="<<stage<<" morph="<<weight<<" maxerror="<<error<<" vertices="<<consumer.vertices<<'\n';check(error<=4,"Independent parsed VRM0 raw-TBN graphical consumer matches current native morph/anisotropic-skin output");}
 }
 {auto scene=original;canonical_avatar(scene,group);Document document;document.replace(scene);const auto initial=document.wait_mesh(std::chrono::seconds(30));
      std::cerr<<"CANONICAL_ORIGINAL_DEADLINE "<<initial<<'\n';
      if(!initial) {
        const auto error=document.frame().state->error;
        std::cerr<<"CANONICAL_WORKER_DIAGNOSTIC "<<error<<'\n';
        check(error.empty() && document.wait_mesh(std::chrono::seconds(90)),"Actual avatar worker accepts explicitly authored flat frames and rigid skinning before the low-level atlas fixture");
      }
      std::cerr<<"CANONICAL_WORKER_MS "<<document.frame().surface->sculpt_meshing.worker_ms<<'\n';
      check(true,"Actual avatar worker accepts explicitly authored flat frames and rigid skinning before the low-level atlas fixture");auto objects=scene.preview_surfaces();std::erase_if(objects,[&](const auto&o){return o.groups.empty()||o.groups.back().id!=group;});
 bool guarded=false;try{auto unavailable=prefix;unavailable+="-uncovered.vrm";export_vrm(objects,unavailable);}catch(const std::invalid_argument &e){guarded=std::string(e.what()).find("coverage is not fully opaque")!=std::string::npos;}check(guarded,"Actual native paint output with unowned tiny original UV faces remains guarded instead of silently filling normal coverage");
 // This low-level fixture deliberately supplies a fully defined immutable atlas
 // payload. Native Paint padding of tiny original UV faces is separately guarded;
 // this does not claim that a native paint bake filled those unowned texels.
 auto full=std::make_shared<MeshSnapshot>(*document.frame().surface);auto solid=[](std::array<uint8_t,4>p){Image image{64,64,std::vector<uint8_t>(64*64*4)};for(size_t n=0;n<image.rgba.size();++n)image.rgba[n]=p[n%4];return image;};
 for(auto &o:objects){auto maps=std::make_shared<TextureMaps>(*o.textures);maps->color=solid({255,255,255,255});maps->metal_rough=solid({255,255,255,255});maps->emission=solid({0,0,0,255});maps->normal=maps->baked_normal=solid({128,204,230,255});maps->color_coverage=maps->emission_coverage=maps->baked_coverage=solid({255,0,0,255});o.textures=maps;for(auto &r:full->ranges)if(r.object==o.id)r.textures=maps;}
 auto path=prefix;path+="-canonical.vrm";auto report=export_vrm(objects,path);frame_consumer::Model parsed(path);auto wanted=draw(native,full);framebuffer.bind();consumer.render(parsed.data,&parsed.json.at("extensions").at("VRM"),*objects[0].appearance->source_basis_quaternion);int error=delta(wanted,read());std::cout<<"CANONICAL_VRM_CONSUMER maxerror="<<error<<'\n';check(report.normal_targets_recomputed==0 && error<=4,"Independent parsed VRM0 consumer matches an explicitly complete low-level canonical atlas without normal recomputation");}
 std::cout<<"Actual VRM frame consumer checks "<<checks<<'\n';return 0;
}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
