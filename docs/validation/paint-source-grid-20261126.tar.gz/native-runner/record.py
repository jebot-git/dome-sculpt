from pathlib import Path
from xml.etree import ElementTree
import gzip
import hashlib
import json
import statistics
import subprocess
import tarfile

native=Path(__file__).resolve().parent
art=native.parent
root=art.parent
benchmark=art/'paint-source-grid-sampling-benchmark-20261126'
wayland=art/'paint-source-grid-sampling-wayland-v2-20261126'
xr=art/'paint-source-grid-sampling-openxr-20261126'
parent=art/'current-creator-vrm0-validation-v3-20261126'
save=root/'docs/validation'
candidate='59f6c278f94c0f31f45b092673e22ea57cebea47'
baseline='90c10c285038fdfdf5e415ca8efbc7c494debb34'
files={}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def add(prefix,folder,*members):
    for name in members:
        item=folder/name
        assert item.is_file(),item
        files[prefix+'/'+name]=item

def git(*args):
    return subprocess.check_output(['git','-C',root,*args],text=True).strip()

assert candidate==git('rev-parse',candidate)
assert not git('diff','--name-only',candidate,'HEAD','--','src','include','tests','assets','third_party','CMakeLists.txt')
byte_names=[f'frame-vrm-consumer-{layout}-{weight}.vrm' for layout in range(2) for weight in (0,35,100)]
byte_names.append('frame-vrm-consumer-canonical.vrm')
results={}
for profile in ('release','asan'):
    direction=native/profile
    perf=benchmark/profile
    state=read(direction/'status.json')
    timing=read(perf/'status.json')
    assert state['candidate']==timing['candidate']==candidate
    assert state['donor']==timing['parent']==baseline
    assert state['terminal'] and state['exit']==0 and state['tests']==10 and not state['failures']
    assert sha(direction/'build/dome-sculpt')==state['app_sha256']
    xml=direction/'build/paint-grid-tests.xml'
    assert sha(xml)==state['junit_sha256'] and sha(direction/'ctest.log')==state['ctest_sha256']
    cases=ElementTree.parse(xml).getroot().findall('.//testcase')
    assert len(cases)==10 and all(test.find('failure') is None and test.find('skipped') is None for test in cases)
    assert 'Prepared and scalar source samplers retain exact float taps' in (direction/'ctest.log').read_text()
    assert timing['terminal'] and timing['exit']==0 and len(timing['results'])==4
    assert all(x['image_error']==0 and x['file_sha256']==timing['expected_vrm_sha256'] for x in timing['results'])
    prior=[x['worker_ms'] for x in timing['results'] if x['core']=='parent']
    current=[x['worker_ms'] for x in timing['results'] if x['core']=='candidate']
    assert len(prior)==len(current)==2
    if profile=='release':assert max(current)<min(prior)
    assert all(x['deadline'] for x in timing['results'] if x['core']=='candidate')
    comparison={}
    for name in byte_names:
        digest=sha(direction/'build'/name)
        assert digest==sha(parent/profile/'build'/name),name
        comparison[name]=digest
    add(profile+'/native',direction,'status.json','configure.log','paint.cpp.log','source-maps.cpp.log',
        'core-index.log','dome-sculpt-link.log','ctest.log','build/paint-grid-tests.xml')
    add(profile+'/benchmark',perf,'status.json','timed-normal-frame.cpp','compile.log','candidate-link.log','parent-link.log',
        *[f'{row["core"]}/sample-{i}.log' for i,row in enumerate(timing['results'])])
    results[profile]={'matrix':state,'reference_files':comparison,'worker':timing,
                      'median_ms':{'parent':statistics.median(prior),'candidate':statistics.median(current)}}
assert results['release']['reference_files']==results['asan']['reference_files']
display=read(wayland/'status.json')
assert display['candidate']==candidate and display['exit']==0 and display['checks']==10
assert display['app_sha256']==results['release']['matrix']['app_sha256']
previous=read(art/'current-creator-vrm0-wayland-v2-20261126/status.json')
assert display['output_sha256']==previous['output_sha256']==sha(wayland/'workflow/Avatar.vrm')
add('wayland',wayland,'run.py','replay.py','status.json','wayland.log','workflow/report.json','workflow/focus-trace.json')
add('first-wayland-focus',art/'paint-source-grid-sampling-wayland-20261126','status.json','wayland.log','workflow/report.json')
replays={}
for profile in ('software','arc'):
    record=read(xr/profile/'status.json')
    assert record['candidate']==candidate and record['exit']==0
    assert record['app_sha256']==results['release']['matrix']['app_sha256']
    assert record['nonblank']['left']==record['nonblank']['right'] and record['releases']==2*record['nonblank']['left']
    assert record['immutable_project_sha256']==sha(xr/profile/'reopened.dsculpt')
    add(profile+'/openxr',xr/profile,'status.json','xr.log','runtime.json')
    replays[profile]=record
add('xr-runner',xr,'run.py')
add('native-runner',native,'run.py','record.py')
add('benchmark-runner',benchmark,'run.py')
archive=save/'paint-source-grid-20261126.tar.gz'
with archive.open('wb') as stream,gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as packed:
    with tarfile.open(fileobj=packed,mode='w') as tar:
        for name,item in sorted(files.items()):
            info=tar.gettarinfo(str(item),arcname=name)
            info.uid=info.gid=info.mtime=0
            info.mode=0o644
            info.uname=info.gname=''
            with item.open('rb') as content:
                tar.addfile(info,content)
members={name:sha(item) for name,item in sorted(files.items())}
with tarfile.open(archive,'r:gz') as check:
    assert {item.name for item in check.getmembers()}==set(members)
    for name,digest in members.items():
        assert hashlib.sha256(check.extractfile(name).read()).hexdigest()==digest
receipt={'candidate':candidate,'production_parent':baseline,'main_merge':git('rev-parse','HEAD'),
         'profiles':results,'wayland':display,'synthetic_openxr':replays,
         'numeric_grid_checks_per_profile':183816,
         'archive':{'file':archive.name,'sha256':sha(archive),'members':members}}
(save/'paint-source-grid-20261126.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(len(members),'archived evidence files',sha(archive))
print({profile:summary['median_ms'] for profile,summary in results.items()})
