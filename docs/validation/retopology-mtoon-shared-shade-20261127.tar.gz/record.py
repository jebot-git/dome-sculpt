from hashlib import sha256
import gzip
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

work = Path(__file__).resolve().parent
repo = work.parent.parent
validation = repo / 'docs/validation'


def digest(path):
    with path.open('rb') as file:
        from hashlib import file_digest
        return file_digest(file, 'sha256').hexdigest()


def head(path):
    return subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip()


def read(name):
    return json.loads((work / name).read_text())


previous = 'd12c59f31e4745137be2c4285d863af83f0ba4d6'
verdict = 'Apply and cold Open preserve Base/Shade sharing only when the source samplers agree'
assert f'FAIL {verdict}' in (work / 'baseline-fixture.log').read_text()
probe = (work / 'imported-probe.log').read_text().splitlines()
assert probe == ['ORIGINAL 1 has_typed_material=1', 'RESULT has_typed_material=0 texture_atlas=512']
assert (work / 'imported-probe-current.log').read_text().splitlines() == probe
files = [
    'record.py', 'baseline-fixture.log', 'check.sh', 'release-build.log', 'release-tests.log',
    'check-incremental-asan.py', 'incremental-asan.log',
    'imported-probe.cpp', 'imported-probe.py', 'imported-probe.log', 'imported-probe-current.log', 'imported-mtoon1.glb',
    'render-shade.cpp', 'render-shade.py', 'run-render.py', 'xr-shade.py',
    'khronos.cjs', 'khronos.json', 'khronos.log',
]
release = (work / 'release-tests.log').read_text()
release_tests = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', release)
assert len(release_tests) == len(set(release_tests)) == 15 and '0 tests failed out of 15' in release
release_controls = (work / 'release/Testing/Temporary/LastTest.log').read_text()
strict_controls = (work / 'incremental-asan.log').read_text()
measure = (r'^MTOON_TRANSFER samples=(\d+) role_error=([\d.]+) '
           r'normal_error=([\d.]+)$')
measurements = {}
artifacts = {}
for mode in ('plain', 'affine', 'v0', 'detached'):
    case = f'retopology-mtoon-{mode}'
    match = re.search(rf'^\d+/\d+ Testing: {case}\n(.*?)^Test Passed\.', release_controls, re.M | re.S)
    assert match
    native = match[1]
    strict = re.search(rf'^mtoon-{mode}\n(.*?)(?=^mtoon-|\Z)', strict_controls, re.M | re.S)[1]
    assert native.count(f'PASS {verdict}') == strict.count(f'PASS {verdict}') == 2
    metrics = re.search(measure, native, re.M).groups()
    assert metrics == re.search(measure, strict, re.M).groups()
    samples, role_error, normal_error = metrics
    assert int(samples) > 4000 and float(role_error) < .005 and float(normal_error) < .018
    measurements[mode] = {'role_samples': int(samples), 'max_role_error': float(role_error),
                          'max_normal_vector_error': float(normal_error)}
    log = case + '-controls.log'
    (work / log).write_text(native)
    files.append(log)
    outputs = ['mtoon-before.dsculpt', 'mtoon-retopo.dsculpt']
    if mode != 'v0':
        outputs += ['mtoon-portable.glb', 'mtoon-retopo.glb']
    for name in outputs:
        path = Path(case) / name
        actual = digest(work / 'release' / path)
        assert actual == digest(work / 'incremental-asan' / path)
        artifacts[str(path)] = actual

regular_asan = None
if (work / 'asan-tests.log').is_file():
    log = (work / 'asan-tests.log').read_text()
    if '0 tests failed out of 11' in log:
        tests = re.findall(r'Test +#\d+: (\S+) +\.+ +Passed', log)
        assert len(tests) == len(set(tests)) == 11
        for name, actual in artifacts.items():
            assert digest(work / 'asan' / name) == actual
        regular_asan = {'tests': tests, 'instrumented_binary_sha256': digest(
            work / 'asan/dome-sculpt-retopo-surface-heat-test')}
        files += ['asan-build.log', 'asan-tests.log']

renderers = {}
for gpu, label in (('arc','Arc(tm) A770'),('software','llvmpipe')):
    rendered = f'render-shade-{gpu}.log'
    log = (work / rendered).read_text()
    assert label in log
    pixels,delta = re.search(r'PASS paint contributes to shared shade on the saved patch pixels=(\d+) max_rgb=(\d+)',log).groups()
    xr = f'xr-{gpu}-shade/compare.json'
    report = read(xr)
    assert report['runtime'] == 'synthetic OpenXR' and report['exact_ordered_close']
    assert len(report['profiles']) == 2
    for profile in report['profiles']:
        assert label in profile['gl_renderer'] and profile['stereo_submissions'] == 6
        assert profile['acquires'] == profile['image_waits'] == profile['releases'] == 12
    renderers[gpu] = {'renderer': report['profiles'][0]['gl_renderer'], 'affected_legacy_shadow_pixels': int(pixels),
                      'maximum_channel_difference_8bit': int(delta), 'unpainted_control_identical': True,
                      'stereo_differing_components_per_eye': report['differing_rgb_components_per_eye'],
                      'stereo_submissions_per_project': 6, 'stereo_exact_ordered_close': True}
    files += [rendered, xr, f'verified-shade-{gpu}.log']

khronos = read('khronos.json')
assert len(khronos['results']) == 7
for result in khronos['results']:
    assert result['issues']['numErrors'] == result['issues']['numWarnings'] == 0
    result['sha256'] = digest(work / result['file'])
archive = validation / (work.name + '.tar.gz')
members = {}
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, filename='', mode='wb', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as output:
        for name in files:
            data = (work / name).read_bytes()
            members[name] = sha256(data).hexdigest()
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            output.addfile(entry, io.BytesIO(data))

receipt = {
    'product': head(repo), 'previous_main': previous, 'canonical_domed': head(repo.parent / 'DomeD'),
    'release_app_sha256': digest(work / 'release/dome-sculpt'), 'release_tests': release_tests,
    'asan_ubsan_incremental': {'based_on': previous, 'instrumented_binary_sha256':
        digest(work / 'incremental-asan/dome-sculpt-retopo-surface-heat-test'),
        'tests': list(measurements)}, 'native_oracle': measurements,
    'identical_release_and_sanitizer_artifacts_sha256': artifacts,
    'renderers': renderers, 'physical_headset': False,
    'imported_mtoon_open_regression': {'tested_revisions': [previous, head(repo)], 'probe_observations': probe},
    'khronos': khronos, 'archive_sha256': digest(archive), 'archive_members_sha256': members,
}
if regular_asan:
    receipt['asan_ubsan_ninja'] = regular_asan
(validation / (work.name + '.json')).write_text(json.dumps(receipt, indent=2)+'\n')
