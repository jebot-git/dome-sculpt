from concurrent.futures import ThreadPoolExecutor
import os
from pathlib import Path
import shlex
import shutil
import subprocess

work=Path(__file__).resolve().parent
repo=work.parent.parent
previous=work.parent/'retopology-imported-prior-bake-20261127/asan'
source_profile=work/'asan'
out=work/'incremental-asan'
out.mkdir(exist_ok=True)
commands=subprocess.check_output(['ninja','-C',previous,'-t','commands','dome-sculpt-retopo-surface-heat-test'],text=True).splitlines()

def compile(name):
    command=shlex.split(next(line for line in commands if line.endswith('/'+name)))
    assert '-fsanitize=address,undefined' in command
    obj=out/(name+'.o')
    command[command.index('-o')+1]=str(obj)
    if '-MF' in command: command[command.index('-MF')+1]=str(out/(name+'.d'))
    with (out/(name+'.build.log')).open('w') as log:
        subprocess.run(command,cwd=previous,stdout=log,stderr=subprocess.STDOUT,check=True)
    return obj

# Reuse the exact ASan/UBSan objects for the previous milestone's unchanged
# sources. The regular separate Ninja build remains independently in flight.
# Paint has already completed compilation in that new build under its own
# cached toolchain configuration. Its new helper is also a recorded dependency.
paint_relative=Path('CMakeFiles/dome-sculpt-core.dir/src/paint.cpp.o')
assert 'Building CXX object '+str(paint_relative) in (work/'asan-build.log').read_text()
paint=shutil.copyfile(source_profile/paint_relative,out/'paint.cpp.o')
with ThreadPoolExecutor(max_workers=2) as pool:
    export,test=pool.map(compile, ('texture-set-export.cpp','retopo-surface-heat.cpp'))
archive=out/'libdome-sculpt-core.a'
subprocess.run(['cp','--reflink=always',previous/archive.name,archive],check=True)
subprocess.run(['ar','rs',archive,paint,export],check=True)
link=shlex.split(commands[-1])[2:-2]
app=out/'dome-sculpt-retopo-surface-heat-test'
link[link.index('-o')+1]=str(app)
index=link.index(next(x for x in link if x.endswith('/retopo-surface-heat.cpp.o')))
link[index]=str(test)
link[link.index(archive.name)]=str(archive)
link=[x for x in link if not x.startswith('-Wl,--dependency-file=')]
subprocess.run(link,cwd=previous,check=True)
sdk=repo/'artifacts/sdk-20261126/toolkit-sanitize'
launcher=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',
     'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1',
     'LIBGL_ALWAYS_SOFTWARE':'1','LP_NUM_THREADS':'2'}
for name,value in env.items(): launcher.extend(['--setenv',name,value])
with (work/'incremental-asan.log').open('w') as log:
    for mode in ('plain','affine','v0','detached'):
        case='mtoon-'+mode
        print(case,file=log,flush=True)
        subprocess.run([*launcher,app,out/('retopology-'+case),case],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=480)
