#include "dome/document.hpp"
#include "dome/import-authoring.hpp"
#include "dome/material-bindings.hpp"
#include "dome/retopo-authoring.hpp"
#include <iostream>

int main(int argc, char **argv) try {
  using namespace dome;
  if (argc!=3) return 2;
  ImportAuthoringOptions options;
  options.paint_resolution=64;
  options.prepare_texture_atlas=true;
  auto imported=prepare_authoring_import(Scene{},argv[1],options);
  auto scene=std::move(imported.scene);
  const auto id=imported.objects.front();
  for (const auto &object:scene.objects()) if (object.id!=id) scene.object(object.id).visible=false;
  scene.select(id);
  const auto &guide=scene.active();
  const auto binding=guide.material_bindings;
  if (!binding || !binding->has_mtoon || !binding->roles[size_t(MToonSlot::Normal)].image ||
      !guide.painted->source_sampling_prepared() || !guide.deformation ||
      guide.deformation->morph_weights.front()<.5f)
    throw std::runtime_error("Expected an authenticated posed MToon 1 model with original UV1 and a writable atlas");
  const auto geometry=guide.deformation->preview(guide.painted->mesh());
  const auto world=scene.world_matrix(id);
  Document document;
  document.replace(scene);
  if (!document.wait_mesh() || !document.frame().state->error.empty())
    throw std::runtime_error(document.frame().state->error);
  document.begin_retopology();
  const auto drafted=[&]{
    if (!document.wait_retopology() || !document.frame().state->retopology->error.empty())
      throw std::runtime_error(document.frame().state->retopology->error);
  };
  drafted();
  for (const auto p:geometry.positions) {
    if (!document.begin_desktop()) throw std::runtime_error("Could not start native point gesture");
    const auto q=world.point({p.x*.83,p.y*.83,p.z});
    Brush brush;
    brush.from=brush.to={float(q[0]),float(q[1]),float(q[2])};
    brush.radius=.01f;
    document.stamp_desktop(brush);
    document.end_desktop();
    drafted();
  }
  document.edit_retopology(RetopoAction::Face);
  drafted();
  document.end_retopology(true);
  document.save_async(argv[2]).get();
  const auto saved=Scene::load(argv[2]);
  const auto &patch=saved.active();
  if (!patch.retopology || patch.retopology->source!=id || saved.object(id).visible)
    throw std::runtime_error("Native retopology did not publish the patch and hidden guide");
  std::cout<<"ORIGINAL "<<binding->material.textures[size_t(MToonSlot::Base)].texcoord<<" has_typed_material="<<binding->has_mtoon<<'\n';
  std::cout<<"RESULT has_typed_material="<<(patch.material_bindings&&patch.material_bindings->has_mtoon)<<" texture_atlas="<<patch.painted->resolution()<<'\n';
} catch (const std::exception &error) {
  std::cerr<<"FAIL "<<error.what()<<'\n';
  return 1;
}
