#include "dome/material-bindings.hpp"
#include "dome/render.hpp"
#include "dome/texture-sets.hpp"
#include "graphics.h"
#include <iostream>

using namespace dome;
namespace {
constexpr int width = 128;
constexpr int height = 128;
const Mat4 identity{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};
using Pixels = std::array<uint8_t,width*height*4>;

Pixels draw(SurfaceRenderer &renderer, const Scene &scene) {
  Document document;
  document.replace(scene);
  if (!document.wait_asset() || !document.wait_mesh() || !document.frame().state->error.empty())
    throw std::runtime_error(document.frame().state->error);
  renderer.draw(document.frame().surface,{},identity,{0,0,2},width,height,true);
  Pixels result{};
  glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,result.data());
  if (glGetError()!=GL_NO_ERROR) throw std::runtime_error("Fixture framebuffer read failed");
  return result;
}

Scene split_shade(Scene scene, TextureSetId slot) {
  const auto field=texture_set_view(scene.active(),slot);
  auto material=*field.material_bindings;
  auto &shade=material.roles[size_t(MToonSlot::Shade)].image;
  if (shade!=material.roles[size_t(MToonSlot::Base)].image)
    throw std::runtime_error("Cold project lost its genuine shared Base/Shade texture");
  shade=std::make_shared<const Image>(*shade);
  if (!bind_texture_set_mtoon(scene,scene.active().id,slot,material))
    throw std::runtime_error("Counterfactual binding did not publish");
  return scene;
}
}

int main(int argc, char **argv) try {
  if (argc!=2 && argc!=3) return 2;
  NativeGraphics graphics;
  std::cout<<"GPU "<<glGetString(GL_RENDERER)<<'\n';
  GLuint framebuffer=0, color=0, depth=0;
  glGenFramebuffers(1,&framebuffer);
  glBindFramebuffer(GL_FRAMEBUFFER,framebuffer);
  glGenTextures(1,&color);
  glBindTexture(GL_TEXTURE_2D,color);
  glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA8,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
  glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,color,0);
  glGenRenderbuffers(1,&depth);
  glBindRenderbuffer(GL_RENDERBUFFER,depth);
  glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT24,width,height);
  glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,depth);
  if (glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)
    throw std::runtime_error("Incomplete fixture framebuffer");
  SurfaceRenderer renderer;
  auto scene=Scene::load(argv[1]);
  const auto slot=scene.active().texture_sets->additional().front().id;
  const auto field=texture_set_view(scene.active(),slot);
  if (!field.painted->has_paint_data() || field.material_bindings->material.version()!=MToonVersion::V0)
    throw std::runtime_error("Fixture needs the painted V0 retopology patch");
  const auto authoritative=draw(renderer,scene);
  const auto split=split_shade(scene,slot);
  const auto counterfactual=draw(renderer,split);
  if (argc==3) split.save(argv[2]);
  size_t affected=0;
  int maximum=0;
  for (size_t i=0;i<authoritative.size();i+=4) {
    if (authoritative[i+3]!=counterfactual[i+3])
      throw std::runtime_error("Splitting Shade should not change visibility");
    int distance=0;
    for (size_t k=0;k<3;++k) distance=std::max(distance,std::abs(int(authoritative[i+k])-counterfactual[i+k]));
    affected+=distance>1;
    maximum=std::max(maximum,distance);
  }
  if (!edit_texture_set(scene,scene.active().id,slot,[](PaintedMesh &paint, Material &) {
        paint.delete_layer(); return !paint.has_paint_data();
      })) throw std::runtime_error("Could not clear cloned paint layer");
  const auto unpainted=draw(renderer,scene);
  const auto unpainted_split=draw(renderer,split_shade(scene,slot));
  if (unpainted!=unpainted_split || affected<15 || maximum<4)
    throw std::runtime_error("Expected a measurable painted shadow difference only");
  std::cout<<"PASS paint contributes to shared shade on the saved patch pixels="<<affected<<" max_rgb="<<maximum<<'\n';
  glDeleteRenderbuffers(1,&depth);
  glDeleteTextures(1,&color);
  glDeleteFramebuffers(1,&framebuffer);
} catch (const std::exception &error) {
  std::cerr<<"FAIL "<<error.what()<<'\n';
  return 1;
}
