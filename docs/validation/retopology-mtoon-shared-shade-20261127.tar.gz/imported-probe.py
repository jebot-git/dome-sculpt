import json
import os
from pathlib import Path
import shlex
import struct
import subprocess
import sys

work=Path(__file__).resolve().parent
previous=work.parent/'retopology-imported-prior-bake-20261127/release'
source=(previous/'retopology-imported-prior-bake/original-import.glb').read_bytes()
length,=struct.unpack_from('<I',source,12)
doc=json.loads(source[20:20+length])
doc['extensionsUsed'].append('VRMC_materials_mtoon')
material=doc['materials'][0]
base=material['pbrMetallicRoughness']['baseColorTexture']
material['extensions']['VRMC_materials_mtoon']={'specVersion':'1.0',
    'shadeColorFactor':[.36,.58,.8], 'shadeMultiplyTexture':base,
    'rimMultiplyTexture':{'index':0,'texCoord':0}, 'parametricRimColorFactor':[.2,.3,.1],
    'shadingShiftTexture':{'index':0,'texCoord':1,'scale':.4}}
encoded=json.dumps(doc,separators=(',',':')).encode()
encoded+=b' '*((-len(encoded))%4)
remainder=source[20+length:]
fixture=work/'imported-mtoon1.glb'
fixture.write_bytes(struct.pack('<5I',0x46546c67,2,20+len(encoded)+len(remainder),len(encoded),0x4e4f534a)+encoded+remainder)
profile=sys.argv[1] if len(sys.argv)>1 else 'baseline'
assert profile in ('baseline','current')
build=previous if profile=='baseline' else work/'release'
commands=subprocess.check_output(['ninja','-C',build,'-t','commands','dome-sculpt-texture-set-source-export-test'],text=True).splitlines()
compile=shlex.split(next(line for line in commands if line.endswith('/tests/texture-set-source-export.cpp')))
includes=[flag for flag in compile if flag.startswith(('-I','-D'))]
link=shlex.split(commands[-1])[2:-2]
libs=['-lgcc_s' if flag=='-lgcc_s_asneeded' else flag for flag in link[link.index('libdome-sculpt-core.a'):]]
app=work/('imported-probe-'+profile)
env=dict(os.environ, LD_LIBRARY_PATH='/opt/fltk-vr/toolkit/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64')
with (work/('imported-probe.log' if profile=='baseline' else 'imported-probe-current.log')).open('w') as log:
    subprocess.run(['/usr/bin/c++','-std=c++20','-O2',*includes,work/'imported-probe.cpp','-o',app,*libs],cwd=build,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run([app,fixture,work/('imported-probe-'+profile+'.dsculpt')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
