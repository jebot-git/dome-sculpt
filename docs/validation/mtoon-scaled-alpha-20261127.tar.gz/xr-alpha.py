from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile

work = Path(__file__).resolve().parent
build = work / "release"
mode = sys.argv[1]
case = sys.argv[2]
srgb = sys.argv[3:] == ["srgb"]
slot = work / ("xr-" + mode + "-" + case + ("-srgb" if srgb else ""))
slot.mkdir(exist_ok=True)
data = []
for name in ("native","imported","solid-control"):
    output = slot / name
    output.mkdir(exist_ok=True)
    project = build / "texture-set-mtoon-alpha" / f"{case}-{name}.dsculpt"
    with tempfile.TemporaryDirectory(dir="/tmp", prefix="dome-retained-xr-") as temp:
        private = Path(temp)
        runtime = private / "runtime.json"
        runtime.write_text(json.dumps({"file_format_version":"1.0.0","runtime":{
            "library_path":str(build / "libdome-sculpt-test-runtime.so")}}))
        metadata = output / "report.json"
        saved = output / "closed.dsculpt"
        env = dict(os.environ, HOME=temp, XR_RUNTIME_JSON=str(runtime),
                   DOME_XR_FIXTURE_PBR_VIEW="1", DOME_XR_FIXTURE_REPORT=str(metadata))
        if srgb:
            env["DOME_XR_FIXTURE_SRGB"] = "1"
        for part in ("config", "state", "data", "cache", "runtime"):
            local = private / part
            local.mkdir(mode=0o700)
            env["XDG_" + part.upper() + ("_DIR" if part=="runtime" else "_HOME")] = str(local)
        with (output / "app.log").open("w") as log:
            subprocess.run([build/"dome-sculpt","--xr","--open",project,"--frames","7","--save",saved],
                           env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=45)
        info = json.loads(metadata.read_text())
        assert info["swapchain_format"] == (0x8C43 if srgb else 0x8058)
        assert info["action_syncs"] == 7 and info["stereo_submissions"] == 6
        assert info["acquires"] == info["image_waits"] == info["releases"] == 12
        assert ("Arc(tm) A770" if mode == "arc" else "llvmpipe") in info["gl_renderer"], info["gl_renderer"]
        assert all(info["pbr_preview_images"]["6"][str(eye)]["opaque"] > 0 for eye in (0,1))
        assert project.read_bytes() == saved.read_bytes()
        data.append(info)
def rgb(path):
    return path.read_bytes().split(b"\n", 3)[3]
# The synthetic runtime encodes its linear RGBA8 capture as sRGB on disk.
# Recover unambiguous raw codes for dark components amplified by this step.
def display_byte(code):
    x = code / 255
    return round(255 * (x * 12.92 if x <= .0031308 else 1.055 * x**(1/2.4) - .055))
raw_codes = {}
for code in range(256):
    raw_codes.setdefault(display_byte(code), []).append(code)

def is_single_linear_step(a, b):
    first, second = raw_codes.get(a, []), raw_codes.get(b, [])
    return len(first) == len(second) == 1 and abs(first[0]-second[0]) == 1

def compare(other):
    outcomes=[]
    for eye in (0,1):
        before,after=[rgb(slot/name/f"report.json.pbr-6-{eye}.ppm") for name in ("native",other)]
        assert len(before)==len(after)
        delta=sorted(abs(a-b) for a,b in zip(before,after))
        amplified = [(a,b) for a,b in zip(before,after) if abs(a-b)>4]
        linear_steps = sum(is_single_linear_step(a,b) for a,b in amplified) if not srgb else 0
        outcomes.append(dict(amplified_linear_steps=linear_steps,
                             unexplained_over_four=len(amplified)-linear_steps,
                             changed=sum(v!=0 for v in delta), maximum=delta[-1],
                             mean=round(sum(delta)/len(delta),6), p99=delta[len(delta)*99//100]))
    return outcomes
different=compare("imported")
control=compare("solid-control")
assert all(e["changed"]>500 and e["maximum"]>16 for e in control),control
print("comparison", different, "control", control)
assert all(e["unexplained_over_four"]==0 and e["p99"]<=3 for e in different),different
report = {"runtime":"synthetic OpenXR", "profiles":data,
          "source_vs_reimport_rgb_error":different, "solid_alpha_control":control,
          "exact_ordered_close":True}
(slot / "compare.json").write_text(json.dumps(report, indent=2)+"\n")
print(f"PASS {mode} stereo native and Standard GLB import render with balanced submissions and exact close", different, "solid-control control", control)
