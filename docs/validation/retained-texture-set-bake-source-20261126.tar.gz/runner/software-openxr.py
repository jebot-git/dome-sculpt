from pathlib import Path
import fcntl,hashlib,json,os,shlex,signal,subprocess,sys,time

profile=sys.argv[1]
hardware=profile=='asan'
out=Path(__file__).resolve().parent/profile
out.mkdir(exist_ok=True)
base=out.parent.parent
source=base/'retained-texture-set-bake-coexistence-source-20261126'
donor=base/'retained-texture-set-coexistence-validation-20261126'/profile
support=base/'texture-set-recipe-and-hdr-validation-20261126'/profile/'build'
sdk=base/'sdk-20261126/toolkit-sanitize' if hardware else Path('/opt/fltk-vr/toolkit')
arc='/dev/dri/renderD129'
def git(*args):
    return subprocess.check_output(['git','-C',source,*args],text=True).strip()
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    return json.loads(p.read_text())
status={'candidate':git('rev-parse','HEAD'),'profile':profile,'invocation':os.getenv('INVOCATION_ID'),'terminal':False}
def record(**fields):
    status.update(fields)
    target=out/'status.tmp'
    target.write_text(json.dumps(status,indent=2)+'\n')
    target.replace(out/'status.json')
def run(command,log,timeout,cwd=None):
    with (out/log).open('w') as f:
        print(shlex.join(map(str,command)),file=f,flush=True)
        subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,cwd=cwd or out,check=True,timeout=timeout)
def children(pid):
    yield pid
    try:
        descendants=Path(f'/proc/{pid}/task/{pid}/children').read_text().split()
    except (FileNotFoundError,ProcessLookupError):
        return
    for child in descendants:yield from children(int(child))

try:
    assert status['candidate'].startswith('5ff0da2b') and not git('status','--porcelain')
    assert git('diff','--name-only','ce28f896','HEAD','--','tests/xr_runtime.cpp','tests/bake-recipes-xr.py')==''
    record(phase='wait for exact core and application')
    unit=f'ds-retained-texture-set-coexistence-{profile}-20261126.service'
    while True:
        receipt=donor/'status.json'
        if receipt.is_file():
            build_info=read(receipt)
            if build_info['terminal']:break
        assert subprocess.check_output(['systemctl','--user','is-active',unit],text=True).strip()=='active'
        time.sleep(2)
    assert build_info['candidate'].startswith('5ff0da2b') and build_info['exit']==0
    app=donor/'build'/'dome-sculpt'
    assert build_info['app_sha256']==sha(app)
    record(phase='compile fixture and synthetic runtime',product=build_info['candidate'],app_sha256=sha(app),
           core_sha256=build_info['core_sha256'])
    helper=donor/'build'/'dome-sculpt-texture-set-source-export-test'
    assert sha(helper)==build_info['binaries']['dome-sculpt-texture-set-source-export']
    original=base/'retained-texture-set-public-validation-20261126'/profile
    runtime=original/'libdome-sculpt-test-runtime.so'
    assert read(original/'status.json')['runtime_sha256']==sha(runtime)
    runner=source/'tests/bake-recipes-xr.py'
    if hardware:
        script=runner.read_text()
        assert script.count("'LIBGL_ALWAYS_SOFTWARE':'1'")==1 and script.count("'llvmpipe'")==1
        runner=out/'arc-xr.py'
        runner.write_text(script.replace("'LIBGL_ALWAYS_SOFTWARE':'1'","'LIBGL_ALWAYS_SOFTWARE':'0'").replace("'llvmpipe'","'arc'").replace('explicit software renderer','Intel Arc renderer'))
    workflow=out/'workflow'
    workflow.mkdir(exist_ok=True)
    settings={'PATH':'/usr/bin:/bin','HOME':'/tmp',
        'LD_LIBRARY_PATH':f'{sdk}/lib:/opt/fltk-vr/bdf-runtime/lib:/usr/lib64'}
    cmd=['bwrap','--die-with-parent','--unshare-all','--ro-bind','/','/','--bind',out,out,'--proc','/proc',
         '--dev','/dev','--tmpfs','/tmp','--tmpfs','/run/user','--clearenv']
    if hardware:
        cmd.extend(['--dev-bind',arc,arc])
        settings.update(DRI_PRIME='pci-0000_03_00_0',MESA_SHADER_CACHE_DISABLE='1',
            ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    for key,value in settings.items():cmd.extend(['--setenv',key,value])
    cmd.extend(['/usr/bin/python3.14',runner,app,runtime,helper,workflow,'--texture-set'])
    record(phase='replay selected-set Recall, bake and Save in the real loader',runtime_sha256=sha(runtime),
       fixture_sha256=sha(helper),runner_sha256=sha(runner))
    witnesses={}
    if hardware:
        lease=open('/tmp/dome-sculpt-arc-device.lock','rb')
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    try:
        with (out/'xr.log').open('w') as log:
            print(shlex.join(map(str,cmd)),file=log,flush=True)
            proc=subprocess.Popen(cmd,cwd=out,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            deadline=time.monotonic()+600
            try:
                while proc.poll() is None:
                    if time.monotonic()>deadline:raise TimeoutError('selected-set loader deadline')
                    if hardware:
                        for pid in children(proc.pid):
                            path=Path('/proc')/str(pid)
                            try:
                                if (path/'exe').resolve()!=app:continue
                                maps=(path/'maps').read_text()
                                args=(path/'cmdline').read_bytes().split(b'\0')
                                if b'--save' not in args or not all(n in maps for n in ('libasan.so','libubsan.so','libgallium')):continue
                                fds=[]
                                for fd in (path/'fd').iterdir():
                                    try:fds.append(os.readlink(fd))
                                    except FileNotFoundError:continue
                                if arc not in fds:continue
                                marker=Path(os.fsdecode(args[args.index(b'--save')+1])).stem
                                if marker not in witnesses:
                                    witnesses[marker]={'pid':pid,'node':arc}
                                    record(witnesses=witnesses)
                            except (FileNotFoundError,ProcessLookupError,PermissionError):
                                continue
                    time.sleep(.1 if hardware else .3)
            finally:
                if proc.poll() is None:
                    os.killpg(proc.pid,signal.SIGTERM)
                    proc.wait(timeout=15)
        assert proc.returncode==0
    finally:
        if hardware:lease.close()
    report=workflow/'report.json'
    detail=read(report)
    assert len(detail['checks'])==19 and all(c['passed'] for c in detail['checks'])
    if hardware:assert set(witnesses)=={'accept','cancel','focus'}
    record(terminal=True,exit=0,checks=19,report_sha256=sha(report),phase='complete')
except Exception as exc:
    record(terminal=True,exit=1,error=repr(exc))
    raise
