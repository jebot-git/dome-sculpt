const fs = require('fs');
const path = require('path');
const validator = require(path.join(__dirname,'../hdr-khronos-validation-20261126/module/package'));
(async () => {
  const results = [];
  for (const placement of ['plain','affine']) for (const form of ['standard','editable']) {
    const file = path.join(__dirname,'release', 'retopology-material-seam-'+placement,form+'.glb');
    const report = await validator.validateBytes(fs.readFileSync(file), {uri:placement+'-'+form+'.glb',maxIssues:10000});
    results.push({placement,form,report});
    console.log(placement,form,report.issues.numErrors,'errors',report.issues.numWarnings,'warnings');
  }
  fs.writeFileSync(path.join(__dirname,'khronos.json'),JSON.stringify({version:validator.version(),results},null,2)+'\n');
  if (results.some(({report}) => report.issues.numErrors)) process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1});
