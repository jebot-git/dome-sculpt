from pathlib import Path
import hashlib,json,shlex,subprocess,difflib
P=Path(__file__).resolve().parent;R=P.parents[1];O=R/'artifacts/whole090f-wayland-seal-20261117';O.mkdir(exist_ok=True);D=Path('/home/blux/de-xr/DomeD')
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
status=P/'native-arc-v4-driver-status.json';assert sha(status)=='845e7c89ab7902771a9c33fe00a891d4b456e0d3f3a9c33c31092677459343ca';s=json.loads(status.read_text());assert s['state']=='terminal'and s['exit']==0 and s['checks']==14 and not s['input_drift']
report=json.loads((P/'native-arc-v4/report.json').read_text());assert report['complete']and report['failed']==0 and len(report['checks'])==14 and all(x['passed']for x in report['checks'])
source=json.loads((P/'compositor-source-before.json').read_text());drift=[p for p,h in source.items()if not(D/p).is_file()or sha(D/p)!=h];assert len(source)==1037 and not drift
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=D,text=True).strip()=='acc2b70ae61dedec2a23727f67c60c0303d0f76f'and not subprocess.check_output(['git','status','--porcelain'],cwd=D,text=True)
build=json.loads((P/'compositor-build-status.json').read_text());assert build['exit']==0 and not build['source_drift'];elfs=[Path(build['output']),P/'dome-compositor-current',P/'dome-compositor'];assert all(sha(p)==build['output_sha256']for p in elfs)and len({(p.stat().st_dev,p.stat().st_ino)for p in elfs})==3;assert all(p.stat().st_nlink==1 for p in elfs[1:])
app=R/'artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/dome-sculpt';assert sha(app)=='9143ea5921d35a3612ab452c16eee086403813343a88b3d775196a8507eb8af1'
inputs=json.loads((P/'native-arc-v4-inputs-final.json').read_text());assert inputs==json.loads((P/'native-arc-v4-inputs-before.json').read_text());bad=[p for p,h in inputs.items()if not Path(p).is_file()or sha(p)!=h];assert not bad
rec=json.loads((P/'native-observer-compile-v1.json').read_text());assert rec['exit']==0 and sha(P/'device-auth-native-wayland-v1.cpp')==rec['source_sha256']and sha(P/'device-auth-native-wayland-v1.so')==rec['binary_sha256']and sha(P/'device-auth-native-wayland-v1.d')==rec['actual_depfile_sha256'];assert '-MD'in rec['command']and '-MF'in rec['command']
raw=(P/'device-auth-native-wayland-v1.d').read_text().replace('\\\n',' ');target,body=raw.split(':',1);assert shlex.split(target)==[str((P/'device-auth-native-wayland-v1.so').resolve())];deps=[]
for name in shlex.split(body):
 p=Path(name);p=p if p.is_absolute()else Path(rec['cwd'])/p;h=sha(p);assert inputs[str(p)]==h;deps.append({'literal':name,'resolved':str(p.resolve()),'sha256':h})
props=dict(line.split('=',1)for line in(P/'native-arc-v4-unit-terminal.txt').read_text().splitlines());assert props['Result']=='success'and props['ExecMainStatus']=='0'and props['MainPID']=='0'and props['ExecMainPID']=='2547653'and props['InvocationID']=='6152d98f86ef4efcb671abc4501a015a'
unitcurrent=subprocess.check_output(['systemctl','--user','show','ds-whole090f-native-wayland-arc-v4-20261117.service','--property=LoadState,ActiveState,MainPID'],text=True);assert 'LoadState=not-found'in unitcurrent
owned=[]
for step in s['steps']:
 assert step['exit']==0 and not step['signals']
 for row in step['known_processes']:
  q=Path('/proc')/str(row['pid'])/'stat'
  if q.exists():assert int(q.read_text().split(') ',1)[1].split()[19])!=row['start'],('same-start survivor',row)
  owned.append(row)
assert s['lease']['released_epoch']>s['lease']['acquired_epoch']
maps=json.loads((P/'native-arc-v4/runtime-maps.json').read_text());mapped={role:sorted({line.split()[-1]for line in lines})for role,lines in maps.items()}
for paths in mapped.values():
 for p in paths:assert inputs[p]==sha(p)
original=R/rec['original_source'];assert sha(original)==rec['original_source_sha256'];scenario=json.loads((P/'scenario-derivation-v1.json').read_text());assert sha(scenario['original_source'])==scenario['original_sha256']
(O/'observer-original-to-v4.diff').write_text(''.join(difflib.unified_diff(original.read_text().splitlines(True),(P/'device-auth-native-wayland-v1.cpp').read_text().splitlines(True),fromfile=str(original),tofile='device-auth-native-wayland-v1.cpp')))
summary={'state':'sealed-actual-runtime-pass','source':'090f009ede2c0623ca616fe892223b4f68f1c2c4','application':{'path':str(app),'sha256':sha(app)},'canonical_compositor_build':build,'staged_independent_ELFs':[{'path':str(p),'sha256':sha(p),'device':p.stat().st_dev,'inode':p.stat().st_ino,'links':p.stat().st_nlink}for p in elfs],'source_recheck':{'files':len(source),'drift':drift},'actual_runtime':{'status_path':str(status),'status_sha256':sha(status),'exit':0,'checks':14,'input_pin_count':len(inputs),'uncached_current_recheck_drift':bad,'steps_seconds':[r['seconds']for r in s['steps']]},'observer_compile':rec,'actual_MD_dependencies':deps,'mapped_canonical_libraries':mapped,'captured_unit_terminal':props,'current_unit_state':unitcurrent,'unit_capture_scope':'Root captured successful terminal props and journal before stopping only the completed v4 unit. Unit already not-found at sealing start; seal stops/recreates no unit.','all_recorded_owned_same_start_absent':True,'recorded_owned_count':len(owned),'lease':s['lease'],'lease_scope':'Completed run released lease; parent independently verified NB-free and handed slot to artist. Seal does not reacquire reassigned lease.','actual_checks':report['checks'],'limitations':['Private Xvfb host and nested diagnostic copy, no native DRM zero-copy/scanout or physical HMD claim','Cargo dependencies may reuse real fingerprints; optimized mainartifact is fresh, not fresh-all-crates','No install or active session restart'],'preserved_failures':{'v1':'missing staged compositor','v2':'old Xvfb path missing its private dependency','v3':'old observer never queried because desktop does not call glGetString(GL_RENDERER)'},'observer_scope':'Original strict GL query/device/fd checks plus standard eglMakeCurrent forwarder querying only after successful binding; no product source/header/ABI/drawing/context creation change'}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'status':sha(status),'source_files':len(source),'input_pins':len(inputs),'MD_dependencies':len(deps),'owned_records':len(owned),'runtime_checks':14,'source_drift':drift,'input_drift':bad,'summary_sha256':sha(O/'summary.json')},indent=2))
