from pathlib import Path
import json,hashlib,os,fcntl,subprocess,importlib.util,time
P=Path(__file__).resolve().parent;R=P.parents[1];OUT=P/'native-arc-v4';STATUS=P/'native-arc-v4-driver-status.json';MON=R/'artifacts/artist-prepared-strict-monitor-20261115/owned_monitor_v2.py'
def sha(p):
 with Path(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
inputs=json.loads((R/'artifacts/prepared-public-operational-20261117/whole090f-loader-v1-20261117/inputs-final.json').read_text());state={'state':'preparing','exit':1,'steps':[]};lease=None
assert sha(MON)=='b510ef5655e3214bd38e7b5f56022c37a79879070c3733f2dd059bad74f21269'
spec=importlib.util.spec_from_file_location('owned',MON);monitor=importlib.util.module_from_spec(spec);spec.loader.exec_module(monitor)
def save():STATUS.write_text(json.dumps(state,indent=2)+'\n')
def pin(path,want=None):
 path=str(path);v=sha(path);assert want is None or want==v,(path,'pin drift');assert path not in inputs or inputs[path]==v,(path,'conflicting input');inputs[path]=v
try:
 build=json.loads((P/'compositor-build-status.json').read_text());assert build['exit']==0 and not build['source_drift'];assert not OUT.exists()
 health=R/'artifacts/guard87-xvfb-private-20261115/health-v2/status.json';pin(health,'b5e8c05b161194e64d721cae422badcde8b395a38d82c74c7bd1b9f1bc3c64eb');hv=json.loads(health.read_text());assert hv['exit']==0 and not hv['input_drift']
 for f,h in hv['pins'].items():pin(f,h)
 app=R/'artifacts/native90-release-planning-20261115/release-090f00-20261117-owning/dome-sculpt';comp=P/'dome-compositor';observer=P/'device-auth-native-wayland-v1.so'
 compile_record=json.loads((P/'native-observer-compile-v1.json').read_text());assert compile_record['exit']==0 and sha(observer)==compile_record['binary_sha256'] and sha(P/'device-auth-native-wayland-v1.cpp')==compile_record['source_sha256']
 for f in [P/'native-observer-compile-v1.json',P/'device-auth-native-wayland-v1.cpp',P/'device-auth-native-wayland-v1.d']:pin(f)
 import shlex
 raw=(P/'device-auth-native-wayland-v1.d').read_text().replace(chr(92)+chr(10),' ');target,body=raw.split(':',1);assert shlex.split(target)==[str(observer.resolve())]
 for f in shlex.split(body):pin(Path(f)if Path(f).is_absolute()else R/f)
 for f in [Path(__file__).resolve(),MON,P/'dome-menu-native-gpu-v2.py',P/'compositor-build-status.json',comp,observer,Path('/usr/share/vulkan/icd.d/intel_icd.x86_64.json'),Path('/usr/lib64/libvulkan_intel.so')]:pin(f)
 pin(app,'9143ea5921d35a3612ab452c16eee086403813343a88b3d775196a8507eb8af1');pin(comp,build['output_sha256'])
 assert not[f for f,h in inputs.items()if not Path(f).is_file()or sha(f)!=h]
 env={k:v for k,v in os.environ.items()if not k.startswith(('DOME_','MESA_','LIBGL_','GALLIUM_','DRI_'))}
 for k in ['LD_PRELOAD','ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS','WAYLAND_DISPLAY','WAYLAND_SOCKET','DISPLAY','DBUS_SESSION_BUS_ADDRESS']:env.pop(k,None)
 env.update(PATH=str(R/'artifacts/guard87-xvfb-private-20261115/bin')+':'+str(R/'artifacts/prepared-public-operational-20261117/bin')+':'+str(R/'artifacts/gui-recovery-20261111/bin')+':/usr/bin:/bin',LD_LIBRARY_PATH=str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',DOME_SCULPT_TEST_ROOT=str(R/'artifacts/authoring-normal-integration-20261115'),DOME_SCULPT_TEST_BUILD=str(app.parent),DOME_COMPOSITOR=str(comp),DOME_WAYLAND_TEST_OUTPUT=str(OUT),DOME_WAYLAND_TEST_OBSERVER=str(observer),DOME_TEST_VULKAN_ICD='/usr/share/vulkan/icd.d/intel_icd.x86_64.json',DOME_TEST_LIBRARY_PATH=str(R/'artifacts/sdk-20261111/toolkit-release/lib')+':/opt/fltk-vr/bdf-runtime/lib:/usr/lib64',DOME_START_XR='0',DOME_START_TRAY='0',DOME_START_IME='0',DOME_SESSION_RESTORE='0',XR_RUNTIME_JSON=str(P/'no-physical-runtime.json'),LP_NUM_THREADS='2',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1')
 lease=Path('/tmp/dome-sculpt-arc-device.lock').open('a+');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);state['lease']={'owner_pid':os.getpid(),'acquired_epoch':time.time(),'before_any_ldd_or_product':True};save()
 def run(name,cmd,seconds):
  def progress(row):state['live']={'name':name,**row};save()
  row=monitor.run(cmd,cwd=P,env=env,log=P/(name+'.log'),timeout=seconds,max_rss=6*1024**3,progress=progress);row['name']=name;state['steps'].append(row);state.pop('live',None);save();assert row['exit']==0 and not row['signals']and 'error'not in row and not[r for r in row['known_processes']if monitor.alive(r)],(name,row)
 run('v4-compositor-ldd',['/usr/bin/ldd',str(comp)],30)
 for line in(P/'v4-compositor-ldd.log').read_text().splitlines():
  assert 'not found'not in line
  for value in line.split():
   if value.startswith('/')and Path(value).is_file():pin(value);pin(Path(value).resolve())
 (P/'native-arc-v4-inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
 run('v4-native-wayland-arc',[str(R/'artifacts/gui-recovery-20261111/venv/bin/python'),str(P/'dome-menu-native-gpu-v2.py')],360)
 report=json.loads((OUT/'report.json').read_text());assert report['complete']and not report['failed']and all(x['passed']for x in report['checks']);state.update(exit=0,checks=len(report['checks']),scope='Actual native Wayland App090f + canonical DomeD acc, Arc GL app/Vulkan compositor, original menu/text/desktop-side controls and ordinary close. Private Xvfb host and diagnostic presentation copy; no native DRM scanout or physical headset claim.')
except BaseException as e:state['error']=repr(e)
finally:
 state['input_drift']=[f for f,h in inputs.items()if not Path(f).is_file()or sha(f)!=h];state['exit']=state['exit']or int(bool(state['input_drift']));(P/'native-arc-v4-inputs-final.json').write_text(json.dumps(inputs,indent=2)+'\n')
 if lease:state['lease']['released_epoch']=time.time();fcntl.flock(lease,fcntl.LOCK_UN);lease.close()
 state['state']='terminal';save();print(json.dumps({k:state.get(k)for k in ['state','exit','checks','error','input_drift']}),flush=True)
raise SystemExit(state['exit'])
